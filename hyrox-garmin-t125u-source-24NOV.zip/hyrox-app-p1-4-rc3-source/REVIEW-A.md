# REVIEW-A — Branch A (P11.3 food: free USDA US foods + optional fiber/sodium)

Reviewer: Grok Bot (independent RC1 reviewer), 19 Nov 2026 (Asia/Qatar, UTC+3). Owner instruction t100u.
Input (read-only, not modified): /workspace/hyrox-p11-3, branch p11-3/integration, HEAD 966217a, base 96832ff
(= Claude P11.2 source zip 6e2b2cae…, tree-identical). Reviewed copy: /workspace/hyrox-rc1 branch rc1/a-p11-3 → rc1/a-review.

Labels: CONFIRMED = reproduced/verified by a test or byte check this review; INFERRED = from reading code, not exercised;
UNKNOWN = cannot be decided here (needs a real iPhone, live data, or the owner).

## Verdict
No CRITICAL/HIGH/MEDIUM defect. Two LOW defects found and repaired (A-01, A-02), each with a fail-first e2e and one commit.
Everything else in scope verified as described by the branch's own docs.

## Defects and repairs
| ID | Severity | Status | Finding | Repair (commit on rc1/a-review) |
|---|---|---|---|---|
| A-01 | LOW | CONFIRMED (fail-first: 2 `<script>` elements for food-db-us.js; no retry after a failed load) | `loadFoodDbUs` could be entered by two callers (Add foods open + Describe) before the first load finished → a second `<script>` for the 1.3 MB file. If the US file failed once (offline/abort), the food index stayed at 8,167 foods for the whole session (no retry). | b556a29: one shared in-flight load (`usWaiters` queue), failed `<script>` removed; an index built after a failed load (`usLoad 'failed'`, 0 US foods) is rebuilt on the next Add foods open; if the retry fails again, the 8,167-food index stays usable. Test tests/e2e/rc1-review-a01.spec.js (390/320): exactly one script element and one request; abort → retry succeeds → 13,598. |
| A-02 | LOW | CONFIRMED (fail-first: typed fiber 1.5 cleared after a kcal edit) | On a USDA-provenance item, changing kcal/macros cleared fiber/sodium even when the OWNER had typed those numbers (input loss; the rule should only drop USDA-derived values). | 8680c45: owner-typed extras are tracked per item (`typedExtra` WeakMap, in-memory, nothing new stored); a kcal/macro change clears only USDA-derived fiber/sodium. Test tests/e2e/rc1-review-a02.spec.js (390/320): 4 eggs, type fiber 1.5, kcal → 300: fiber kept, USDA sodium cleared with the note. |

Fail-first logs: rc1-logs/A-failfirst-rc1-review-a.txt (6 failed on 966217a) → A-fixed-rc1-review-a.txt (6 pass).

## Focus areas
### Saved foods (My foods / favourites) — CONFIRMED
- Every 11.3 writer (Save to My foods, favourite/unfavourite, rename, delete, Settings save) re-reads the settings record and
  keeps unknown fields (planBlocks, future fields): p11-3-fibersodium "unknown settings field survives every 11.3 write", and
  RC1 rc1-cross with a REAL activated Block 2.
- Fiber/sodium on saved foods survive damaged-settings Replace, export/restore and History Copy (p11-3-fibersodium; rc1-cross;
  rc1-activation-clock backup test).
- Older builds (Claude P11.2 c85d8247…, Claude P11 b8275adb…, P10b da206f89…) opened on the same origin keep myFoods/favFoods
  and the per-item fields when they save settings and export (p11-3-older-ui; rc1-activation-clock downgrade ×3).
- On A alone (before integration) the damaged-settings Replace path dropped OTHER unknown fields such as planBlocks (branch
  documented this as the INTEGRATION NOTE). CONFIRMED fixed by integration: the Phase 12 `repairCarry` keeps every other valid
  field; the INTEGRATION NOTE e2e is flipped to `toEqual(PB)` and passes.

### Settings persistence (A side) — CONFIRMED / INFERRED
- CONFIRMED: no new storage key; data v2; hyrox-data.js / hyrox-nutrition.js unchanged; no image bytes stored.
- INFERRED: per-item `{value,state}` sodium × quantity in `myFoodComponent` can exceed the data-layer bound (100000 mg) for
  absurd quantities and then reads "unknown" (never wrong-zero). LOW note, not repaired (no realistic input reaches it).
- INFERRED: a fiber/sodium edit updates the meal's `updatedAt`, which marks the day's "All food & drink entered" attestation
  stale. That is consistent with the existing kcal behaviour. OK.

### Food data — CONFIRMED (byte level)
- food-db.js and food-db.json are byte-identical to Claude P11.2 (sha 312e75c5… / a7071ae5…). The FNDDS source zip sha is
  dfb06ae7…; `tools/food-db/build_food_db_us.py` rebuilds food-db-us.{json,js} byte-identically (rc1-logs/A-food-db-us-rebuild.txt).
- 5,431 US foods (1 excluded) + 8,167 = 13,598; fdcIds 2705384–2710814, all unique; 6 rows spot-checked against the source zip
  (description, kcal, protein, fiber, sodium) match exactly. Gzip ~193 KB.
- '4 boiled eggs' → SR hard-boiled egg first, FNDDS boiled egg next; '1 can tuna' → canned tuna. Big Mac FN row labelled
  "Chain item · USDA survey estimate (US)", never official. USDA values stored as ESTIMATED.
- No network request during search (rc1-cross asserts only the static food-db files load; no /api request).

### Low / cosmetic notes (not repaired)
- INFERRED LOW ranking: "fries" ranks "Fry sauce" first.
- INFERRED LOW: Recent/Favourite rows that point at FNDDS items are hidden while the US file is unavailable (list itself kept;
  they reappear once it loads — and A-01 now retries).
- KNOWN (branch-documented): an older UI kcal edit keeps the now-stale USDA fiber/sodium on that item.

### Out of scope / unchanged (verified untouched)
Block 1 content, historical record semantics, photo AI, same-origin protection: no diff in those files from A.

## Tests on A (before integration, Chrome emulation, not Safari)
Unit 1449/1449, 0 skip. e2e 412 pass, 1 skip (p4-regress-meal-totals "150% page-zoom proxy": needs a dedicated 320 project
that is not configured — pre-existing), 1 fail = p6-text-estimate-real 320 banana, a timeout while A and B suites ran in
parallel; rerun 3× → 60/60 pass (rc1-logs/A-e2e-rerun-p6-real-x3.txt). Not a product defect.
