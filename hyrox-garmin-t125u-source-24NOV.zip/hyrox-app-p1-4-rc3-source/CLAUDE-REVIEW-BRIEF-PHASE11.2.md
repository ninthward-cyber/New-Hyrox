# Claude review brief — Phase 11.2 (= all Phase 11.1 scope + 11.2 P0 food search)

Please independently review, test and repair (if needed) this candidate. **It is not deploy, spend or merge approval.** Base: your reviewed Phase 11, git-archive commit `bdab182` (source zip `ffa58d1a…`, deploy `b8275adb…`; both re-verified, and the deploy matches a fresh build of the source). Read `CHANGES-PHASE11.2.md` (split by part) and `DEPLOY-PHASE11.2.md`.

## Commits (review each alone, in order)
1. `b60b713` 11.1 P0 diary navigation after Add > Meal · 2. `ba4fec8` healthy-habit rows · 3. `0ff6dd0` Trends presentation · 4. `18a2d4d` Add foods search + My foods · then a tooling-only screenshot script.
The patch vs `bdab182` is in the package; `functions/`, `netlify/`, `hyrox-data.js`, `hyrox-foodcalc.js`, `food-db.*` and the AI stub/live provider are byte-identical to baseline.

## Please check especially
1. **Diary return (part 1):** every path into a confirmed Add > Meal save (Manual, Describe, Photo, Add foods) lands on the meal's own date, right category or Uncategorized, entry shown once and focused; History Edit/Copy, Save draft and failed saves behave as before. Late photo/description replies after discard must not reach the next meal.
2. **Category preservation risk:** an older UI (P10b and earlier) that edits a P11/P11.2 meal — does `mealCategory` survive? (Our data-layer round trips keep it; the risk is older *UI* edit paths rebuilding the record.) Same question for the owner-settings record holding `myFoods`/`favFoods`: older Settings save mutates the stored record (keeps them), but "Replace the saved settings" on a damaged record would rebuild it without them.
3. **Schema choice (owner decision, not decided unilaterally):** research recommended a version-3 stamp + new `savedFoods` collections so older builds *refuse* rather than strip. We instead kept data version 2 and stored `myFoods`/`favFoods` as optional fields of the existing settings record, after testing that P11, P10b and P9 data layers do **not** strip them (restore + re-export intact). Please confirm or recommend v3.
4. **Search honesty:** ranking never auto-picks; typo matches are labelled; restaurant rows (USDA SR Legacy 2018) say they are not the official figure; no fake `fdcId`; USDA values stay ESTIMATED; unknown kcal stays unknown (not 0) in totals; Save to My foods copies values (later edits never change meals).
5. **No network on typing / offline** (e2e asserts zero requests during keystrokes and search with the context offline). Index is in memory only; nothing big in localStorage.
6. **Habits & Trends:** presentation only — no new computation, no fabricated points, water intentionally absent (no volume field).
7. Accessibility at 320/390: 16 px inputs, ≥44 px targets, focus after Add/Done/Confirm, VoiceOver labels on result buttons.

## Please state explicitly in your report
- Every **skipped** test and why (our runs: 1 skipped in the existing e2e suite — the 150 % zoom proxy; no new skips).
- **WebKit / real-iPhone limits:** all e2e is **Chrome mobile emulation, not Safari/WebKit**; iOS keyboard, VoiceOver, Larger Text and Home Screen behaviour are only covered by the owner's device QA.
- Whether the one timing test that failed once in our full run (`p5-claude-review` "year of daily logging…", passed 4/4 in isolation and in the re-run) reproduces for you.

## Not in this build (flagged)
FNDDS 2021-2023 sibling file and fiber/sodium storage (current USDA bundle has no fiber/sodium); water tracking; restaurant official values; FatSecret; server-side FDC; any paid web search. No deploy, no push, no paid calls were made.
