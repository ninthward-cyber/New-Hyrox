# P1.1-RC1: deploy and rollback (owner only, after the owner's explicit go-ahead)

**This package is not deploy approval and not approval of Block 2 training content.** Nobody but the owner deploys.
Command Center currently recommends a release HOLD until F-1 (quantity lost when typing fast in Add foods) is fixed and
verified. F-1 is in RC2 and P0-RC3 as well; P1.1 neither fixes nor worsens it.
- Site: `hyrox-phase7-private-test` (ID `99f0deb7-0526-46f6-b432-9c3bfc2c86d2`). Same origin as today, so saved data stays.
- Zip: `hyrox-app-p1-1-rc1-deploy.zip`; its SHA256, every file's SHA256 and the **source id** are in `SHA256SUMS-p1-1-rc1.txt`.
- No env change, no migration, data version 2, no new storage key. 17 static app files (one new: `src/data/hyrox-morning.js`).
- **Timing:** Block 2 benchmark 11 Dec, first start Mon 14 Dec. Do not deploy in that week.

## A. Read-only: confirm what is live now
Netlify → site → Deploys → Published deploy → file browser sizes:
| `src/ui/app-ext.js` | `src/ui/style.css` | Live build |
|---|---|---|
| 308980 | 42553 | P0-RC3 (also shows itself under Settings → About this build) |
| 303150 | 42154 | RC2 |
| 302942 | 42154 | RC1 |
| 258287 | 41683 | Claude P11.2 |
| 223896 | 39561 | Claude P11 |
| anything else | | stop and report the sizes |
Write down the published deploy ID: it is the fastest rollback target.

## B. Backup first (mandatory)
iPhone → the **Home Screen icon** → Settings → **Export JSON backup**. Keep the file and check it is in Files.

## C. Deploy
```powershell
cd $HOME\Downloads
Get-FileHash .\hyrox-app-p1-1-rc1-deploy.zip -Algorithm SHA256   # must equal its line in SHA256SUMS-p1-1-rc1.txt, otherwise STOP
Expand-Archive .\hyrox-app-p1-1-rc1-deploy.zip -DestinationPath .\hyrox-p1-1-rc1 -Force
cd .\hyrox-p1-1-rc1\hyrox-p1-1-rc1-deploy
npm ci
npx netlify-cli login
npx netlify-cli sites:list --json | ConvertFrom-Json | Where-Object { $_.id -eq '99f0deb7-0526-46f6-b432-9c3bfc2c86d2' } | Select-Object name, url, id
# must show hyrox-phase7-private-test, otherwise STOP
npx netlify-cli deploy --site 99f0deb7-0526-46f6-b432-9c3bfc2c86d2 --dir publish --functions netlify/functions --message "P1.1-RC1 draft"
```
Draft URL (new Safari tab, not the icon): quick look only, then clear that tab's website data. Then production:
`npx netlify-cli deploy --prod --site 99f0deb7-0526-46f6-b432-9c3bfc2c86d2 --dir publish --functions netlify/functions --message "P1.1-RC1"`.

## D. Smoke test on the Home Screen icon (real iPhone; all browser tests ran in Chrome emulation, not Safari)
1. **Build label:** Settings → About this build shows `Build P1.1-RC1 · source <id> · …`. The id must equal the "source id"
   line in `SHA256SUMS-p1-1-rc1.txt`. "Development copy" means the wrong files were published: stop.
2. **Home is as before:** no new card. Nutrition, Steps, Exercise, Weight, readiness and the plan are where they were.
3. **Morning log:** Add → Morning. The headings name today and yesterday. Type weight, sleep, resting HR, yesterday's steps
   and Garmin intensity minutes (the number Garmin shows, not doubled) → Save morning log. The message lists what was
   saved and under which date. The fields now show the saved values.
4. **Blank is safe:** clear one field, Save → "Nothing to save" or only the other changes; the cleared value is still there
   after leaving and returning.
5. **Edit:** change intensity minutes, Save. Trends → "Intensity minutes — weekly" shows the new weekly sum and the count
   of recorded days; nothing is added for workouts.
6. **Old routes:** Today → Log steps, Add → Check-in, Add → Quick log still save as before, and the morning log shows them.
7. **Pounds:** Settings → Units → Pounds. Today's Weight row, Trends and Quick log show lb. Add a weight in lb. Switch back
   to kg: every earlier weight reads exactly as before.
8. **Midnight (optional):** nothing to do; if the form is open across midnight it refuses to save and shows the new day.
9. **Backup/restore preview:** Settings → Export JSON backup, then Restore → pick it → preview appears. Cancel.
10. Close the app from the app switcher, reopen from the icon: everything above is still there.

## E. Rollback (no env change, no migration)
Export a backup first. Fastest: Netlify → Deploys → the deploy ID from A → Publish deploy. From a zip (check the hash; same
`npm ci` + `deploy --prod` as in C):
| Order | Target | SHA256 |
|---|---|---|
| 1 | P0-RC3 `hyrox-app-p0-rc3-deploy.zip` | `34251d47a6978d80ddac6f4fa157399c8163f083816ea02002e5822fee1593cb` |
| 2 | RC2 `hyrox-app-rc2-deploy.zip` | `3662afd4c1a059a9a2935d6152d6620c44bf23c38cb4032a1361a3ee1d5153cb` |
| 3 | RC1 `hyrox-app-rc1-deploy.zip` | `129583156454de49c3acbf5e2a4d7bae08124ac1862c982f6c6e7b646f409d7c` |
| 4 | Claude P11.2 `hyrox-app-phase11-2-deploy-claude.zip` | `c85d82479e02a6e20a585ac9b9a9418b4ba736792cc98136e011f403b1b85e61` |
| 5 | Claude P11 `hyrox-app-phase11-deploy-claude.zip` | `b8275adb58a5f435983be4b7752714c45e13ed04ed12c18ae37a5406fe458b82` |
| 6 | P10b `hyrox-app-phase10b-deploy-claude.zip` | `da206f891229ae43b73a04722d2a2a37f2ca92aba7df31accbf19c2016e8cf72` |
What an older build does with P1.1 data (tested at the data layer for RC2/P0-RC3, P11.2, P11, P10b, P9; RC2 UI in a browser):
- Intensity minutes stay stored in each check-in and survive that build's own saves of the check-in, its export and its
  restore. The older build does not display them. Roll forward again and they are back.
- The lb preference stays stored in the settings record and survives that build's baseline save. The older build shows kg.
- Weights were always kg. Nothing to convert.
- Do not use "Replace the saved settings" (repair of a damaged settings record) on P11.2 or older: that repair keeps only
  the fields that build knows (existing caution from DEPLOY-RC2.md section E; it would also drop the lb preference).
The older-build cautions in DEPLOY-RC2.md section E and DEPLOY-P0-RC3.md section E still apply.
