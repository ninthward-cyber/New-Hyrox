# HYROX Phase 3 — independent QA repair report

Date: 2026-11-11 · Prepared by: Claude (local work only) · For: owner review
Status: **NOT merged, NOT pushed, NOT deployed.** No accounts, purchases, real photos or real model calls.

Baseline: Phase 2 local integration `64427c2` (supplied ZIP, SHA-256 `8533f8f1…d11a`, verified).
Starting point: Emergent Phase 3 clean ZIP (SHA-256 `de9be14f…62fe`, verified), committed unmodified on top of the baseline.

## 1. What was verified before any change

| Check | Result |
|---|---|
| SHA-256 of Phase 3 ZIP, Phase 3 patch, Phase 2 inner ZIP | match the manifest / handoff |
| `node --test tests/*.test.js` on the unmodified Phase 3 source | 245 pass, 0 fail (Node v22.23.4) |
| `python -m pytest -q ai-test-backend/test_food_photo_adapter.py` | 8 pass (Python 3.13.18) |
| P0-A and P0-B | both reproduced: 28 of the 40 new regression tests fail on the unmodified source (log 01) |

Results on the repaired tree (raw logs in `test-results/claude-qa/`):

| Suite | Result |
|---|---|
| JavaScript unit tests | 338 pass, 0 fail (245 original + 93 new) — log 02 |
| Python adapter tests | 8 pass — log 03 |
| Browser journeys, installed Chrome 153, 390×844 phone emulation | 26 pass, 0 fail (15 original + 11 new) — log 04 |

## 2. The two reproduced defects

**P0-A — malformed Phase 3 collection silently replaced.** Fixed in `src/data/hyrox-data.js`.
- A Phase 3 collection that is present but is not a list now makes the stored data "damaged", exactly like a damaged classic list. This applies to all eight collections.
- The first save copies the original text byte-for-byte to `hyrox.v1.corrupt-backup` and verifies it. If that copy cannot be made, or a different recovery copy already exists, the save is refused and nothing changes.
- Delete and export refuse to act on damaged data. Restore still works and keeps the exact damaged text in the pre-import slot; a failed restore rolls back to it.
- Damaged *records inside* a healthy list are hidden from screens (they could crash History), stay in storage, are counted in the export notice, and are left out of the export. Before this, such an export could not be restored at all.

**P0-B — source omission masked a logged Thursday session.** Fixed in `src/data/hyrox-plan.js`.
- `slotStatus` now reports two independent facts: `omission` (the source cascade omitted the prescription) and `session` (what was actually logged). A logged COMPLETED / PARTIAL / IN_PROGRESS session keeps its status and is flagged as "logged on a source-omitted slot".
- No skip is ever invented: an omitted slot with nothing logged is `SOURCE_OMITTED`, never `SKIPPED`.
- `cascadeConflicts` lists, without changing anything, where cascade events and logs disagree, and says when the cascade was entered after the session.
- Related fix: a later skip record no longer hides work actually done for the same slot.
- The planned slot is never modified.

## 3. The five owner rules (hyroxowner.md)

| Rule | Implemented | Where |
|---|---|---|
| 1. Resting-HR baseline 76 bpm, configurable | Default 76 (shown as "owner default"), editable in Settings → My baselines. Configured and observed 7-day mean are shown separately; missing readings stay missing. | wellness `rhrAssessment`, data `ownerSettings`, Settings + Today |
| 2. Eaten fraction | Meal-level 25/50/75/100% or custom, applied to kcal, protein, carbs and fat. Per-item override. Photographed meals have no default; totals stay unknown and Confirm is refused (UI and data layer) until stated. AI estimate stays editable; the model's own "eaten" guess is discarded. | nutrition `eatenFractionOf`, meal form |
| 3. Water-only day | Asked on Today for yesterday and in History for unanswered days of the last 7. Confirmed full-day fast → 0 kcal, new state "Confirmed full-day fast". Not logged / unanswered → calories unknown, excluded from averages. Fasting days counted separately in Trends. Adding food later withdraws the fast. | nutrition `dayState`, `dayAverages` |
| 4. Missed sessions | Saving an explicit skip of a planned session requires a choice: reschedule / skip permanently / adjust the week. The app recommends; it never decides. Source cascade untouched; both-missed stays unresolved; original slot kept; reschedule stored separately. | plan `skipAdvice`, `rescheduleCheck`, workout form |
| 5. Step targets | Baseline = median of recorded daily totals (last 14 days) or a manual number. Adjusted for load and recovery, per-day override, weekly trend and consistency, missing never zero, no make-up. Walk steps count only when no daily total exists. | wellness `stepTarget`, `weeklySteps` |

## 4. Other changes

- **Downgrade guard.** Data and backups containing Phase 3 collections are now schema version 2; classic-only data stays version 1. Tested against the real `64427c2` data layer: it refuses a version-2 backup and refuses to write or export version-2 storage. Version-1 backups made by the Emergent Phase 3 build still restore.
- **Photo AI.** Default remains "not configured". Switching on the real-model provider now needs an explicit confirmation and is labelled as not approved for real photos. No key in client code or storage; backups and storage contain no image data (tested). No real call was made.
- **Phone layout.** A photo meal awaiting confirmation made the History page 699 px wide on a 390 px screen and covered its own "Review & confirm" button. Rows now wrap.
- **Storage banner** refreshes after detailed saves and deletes.
- **Existing tests changed:** seven assertions and one fixture that used "version 2" to mean "unsupported future version" now use version 3. One browser test now selects 100% eaten before expecting photo totals. Nothing else in the existing suites was altered.

## 5. Decisions made here that need owner confirmation

These are not in the source or in hyroxowner.md. They are defaults I chose so the rules could work.

1. **Step numbers:** +10% on a day with no session, −15% the day of / after a demanding session (RPE ≥ 7, or intervals / race skills when no RPE), −30% when soreness ≥ 6, pain ≥ 4 or readiness ≤ 4. Baseline needs at least 3 recorded days in 14. Rounded to 100.
2. **RHR flag:** raised when a reading is 7+ bpm above the configured baseline *or* above the observed 7-day mean. The source rule refers to a weekly baseline and the owner rule sets 76; using either keeps the source flag alive and never hides one. It counts as one flag.
3. **Fasting state:** added as an extra state beside D1–D5 rather than changing D4/D5. A day with no food recorded can no longer be declared "complete" without answering the question.
4. **"Never stack"** is enforced as "never two sessions on one day". Back-to-back days are not blocked. Monday–Thursday sessions may be rescheduled to a free weekend day (with a caution); a Friday may not (source rule).
5. **"Adjust the rest of the week"** is offered only where the source defines it (missed Monday or Wednesday). For Tuesday, Thursday and Friday it is shown but disabled, and the recommendation is to leave the session skipped.
6. **One damaged collection marks the whole store damaged** (same as Phase 2 for classic lists). The recovery copy is kept, but there is still no in-app tool to read it back.

## 6. Not done, not tested, still open

- **Real iPhone Safari: not tested.** Browser journeys ran in installed Chrome 153 with phone emulation only. Playwright's WebKit could not be downloaded here, so Emergent's 30/30 WebKit + Chromium result was not reproduced on WebKit.
- **Live API tests (Emergent's 10/10): not run.** They need the test backend; no model call was made.
- **Training source documents on Drive were not opened in this pass.** Source rules were taken as encoded in the supplied code and the handoff.
- Running-workout steps: workout blocks have no step field, so only walk records can contribute steps.
- The fasting question covers yesterday and the last 7 days; older empty days are never asked about.
- 45/25-minute fallback prescriptions: still not implemented (variants are labels only).
- Official 17/20 numerator and both-missed Monday/Wednesday rule: still open owner decisions; nothing invented.
- No new block after 6 Dec 2026.
- Cross-tab races and browser storage eviction: not solved. No claim of transactional durability.
- `ai-test-backend` must not be deployed: no authentication or rate limiting. The endpoint field in Settings accepts any URL.
- Security review was a static read and a credential scan only.
- Stubs only: login, cloud sync, Garmin / Apple Health, food catalogue.

## 7. How to check locally

From the extracted `hyrox-app` folder:

```
node --test tests/*.test.js
python -m pytest -q ai-test-backend/test_food_photo_adapter.py
```

Browser journeys (optional), with `@playwright/test` 1.49.1 installed in some folder `<dir>`:

```
# Playwright browsers available (WebKit iPhone-13 emulation + Chromium):
NODE_PATH=<dir>/node_modules npx playwright test -c tests/playwright.emergent.config.js
# or an installed Chrome only:
HYROX_CHROME=/usr/bin/google-chrome NODE_PATH=<dir>/node_modules npx playwright test -c tests/playwright.local-chrome.config.js
```

To rebuild this tree from the baseline:

```
unzip hyrox-app-phase2-p0-64427c2.zip && git init -q && git add -A && git commit -qm baseline
git apply --binary --check claude-phase3-repair-vs-64427c2.patch
git apply --binary claude-phase3-repair-vs-64427c2.patch
```

To see only what changed relative to Emergent's Phase 3: `claude-repair-vs-emergent-phase3.patch`.

Before using with real health logs: run `tests/IPHONE-SAFARI-P2-CHECKLIST.md` on the phone, then export a backup, and add these checks — confirm a photo meal from History, answer the fasting question, skip a session and pick each option, set a step override, change the RHR baseline, export and restore.
