# HYROX Phase 4 — Meron independent QA (overnight pass, owner t59u)

Date: 11 Nov 2026, ~20:10 Asia/Qatar. Reviewer: Meron. Local only: no push, no GitHub, no deploy, no real AI/model/API calls, synthetic data only.

Baseline: `/workspace/hyrox-p4/base/hyrox-app` @ **`b21cf93d09cbbc82eb1d5c210002363bf002f7fb`** (`p4/r2-baseline`, Claude R2 zip sha256 `f15c268c…`). I did not edit the baseline, `src/`, or any existing test.

My work is on `/workspace/hyrox-p4/wt/qa` (`p4/qa` @ `327c8e676efb13bd3c0e2f57b831744dd4436167`): **new test files only**, plus this report and raw logs under `/workspace/hyrox-p4/results/meron-*.txt`.

Every browser result below is **Chrome emulation, not Safari/WebKit** (`/usr/bin/google-chrome`, 390×844, `127.0.0.1` only, Playwright from `/workspace/hyrox-p2/tools/node_modules`). Python via `/workspace/hyrox-p3/tools/pyvenv`. `test_food_photo_api_live.py` was not run.

## A) Unmodified baseline `b21cf93` — independently rerun

| Suite | tests | pass | fail | skipped | log |
|---|---|---|---|---|---|
| `node --test tests/*.test.js` (I ran this) | 591 | **591** | 0 | 0 | `results/meron-baseline-node.txt` |
| Python adapter `test_food_photo_adapter.py` (I ran this; live test not run) | 8 | **8** | 0 | 0 (1 StarletteDeprecationWarning) | `results/meron-baseline-python.txt` |
| Chrome-emulation e2e @ 390px | 40 | **40** | 0 | 0 | Tewodros: `results/00-baseline-e2e-chrome390.txt` (complete, exit=0, all 40 named and passed). I did not duplicate this run. That log has no tree SHA in the header. |

Claude's 38 new unit regressions (`tests/r2-claude-integrity.test.js`): I ran them alone on the unmodified baseline — **38 pass / 0 fail / 0 skipped** (`results/meron-baseline-r2-regressions.txt`).

## B) The 38 new Claude regression tests

All 38 are real `it(...)` cases in `tests/r2-claude-integrity.test.js` (plus 7 related journeys in `tests/e2e/r2-claude-repairs.spec.js`, not part of the "38"). I read every test body.

- None skipped, none empty, none `assert.ok(true)`, none a catch-all `try/catch` that swallows failures, none that only assert a constant against itself.
- They assert stored bytes, write counts, concrete field values, status codes, and refusal details. They can fail (and, per Claude's log, 26 of 38 did fail on `ed7ad84`; I did not rerun that, as instructed).
- Verdict: **not vacuous**. They pass on `b21cf93`.

## C) Weak or tautological tests (new and changed)

No tautological assertions found in the 38, in the rewritten "was a characterization" tests (`tests/p3-meron-t47u-r2-adversarial.test.js`, `tests/e2e/p3-t54u-ui.spec.js`), or in `r2-claude-repairs.spec.js`.

**Weak coverage, not vacuous:** the last part of `r2-claude-repairs.spec.js` ("Today at a glance…") also checks that the tab bar's `y > 700` and that the last visible Settings button's bounding box sits above the tab bar. That can fail, but it only inspects one control on one screen and does not use `elementFromPoint`. I added a stronger Chrome e2e that hit-tests every in-panel control on every screen after `scrollIntoView`; it passed (see F).

## D) Normal vs emergency backup separation

**Holds for an unmodified emergency file.** On `b21cf93`:

- A normal `exportJSON()` is a `hyrox-app` backup: no `kind`, no `format`, no `sources`. It is not parseable as raw recovery.
- `rawRecoveryExport()` is identifiable (`app`/`kind` = `hyrox-raw-recovery`, `format` 1, filename `hyrox-RAW-RECOVERY-…`, warning that it is not a normal backup). The copy of `hyrox.v1` inside it is byte-exact.
- `previewImport` / `applyImport` of that file return `raw_recovery_file` and write nothing, including when extra flags such as `approveCorrection: true` are passed. Leading/trailing whitespace is still refused as `raw_recovery_file`. The inner stored payload is `not_hyrox` (it has no `app: hyrox-app` wrapper).

**DEFECT (HIGH, data-loss footgun) — named failing test left in place, `src/` not changed.**

- Repro: take a valid emergency raw file; change `app` to `hyrox-app`; delete `kind`; add `version: 2` and empty `weight`/`workouts`/`nutrition` arrays. `previewImport` accepts it (`ok: true`, warning "7 unknown top-level fields will be ignored"). `applyImport` with `confirm: 'REPLACE'` **replaces live data with empty lists** (a stored weight is wiped). The emergency copies in `sources` are not restored.
- User impact: someone editing the emergency file to try to make Restore accept it can erase what is on the device instead of recovering it. The unmodified file is still refused correctly.
- Test: `tests/p4-meron-adversarial.test.js` — `DEFECT: a relabelled emergency raw recovery file can be imported as an empty normal backup and wipe live data`.

A UTF-8 BOM on an otherwise valid raw file is refused as `not_json` (also writes nothing). That is current behaviour, not a defect.

## E) `ai-test-backend` and real-AI evidence

**Verdict: not on the deploy path; evidence files are not used by the app or by the tests I ran.**

- `DEPLOY-FILES.txt` lists only `index.html` and `src/**` as the app, and lists `ai-test-backend/`, `tests/`, `test-results/` and docs under **NEVER SERVE OR DEPLOY**.
- There are no deploy scripts, CI configs, service workers, precache lists, Docker/Make/zip packaging, or other manifests in this tree besides `DEPLOY-FILES.txt` and `tests/E2E-DEPENDENCIES.txt` (test notes). No service worker / Workbox / `cache.addAll` in `src/` or `index.html`.
- `src/` and `index.html` do not reference `ai-test-backend`, `ai_call_ledger.jsonl`, or `real-ai-call-response.json`.
- Unit tests use synthetic fixtures and a fake `fetch`. They do not read the evidence files.
- **Flag (present, not used by the app):** `test-results/ai_call_ledger.jsonl` and `test-results/real-ai-call-response.json` exist as historical evidence (documented in `test-results/README.txt`). I did not quote them. `ai-test-backend/test_food_photo_api_live.py` hard-codes a path to the ledger; I did not run that file.

## F) Adversarial probes (new tests only)

New files:

- `tests/p4-meron-adversarial.test.js` (14 unit tests: 13 pass, 1 intended DEFECT fail)
- `tests/e2e/p4-meron-approval-and-nav.spec.js` (2 Chrome e2e, both pass)

**Damaged-record approval / silent-overwrite guard.** Current behaviour is strict and holds in the data layer and the check-in UI:

- `putRecord` / Settings / check-in write nothing unless `opts.approveCorrection === true`. Stand-ins (`'true'`, `1`, `'yes'`, `{ok:true}`, `approveDamaged: true`, a flag on the record body) are refused, storage is byte-identical, write count 0.
- `removeRecord` accepts only `approveDamaged === true`.
- Approval does not bypass entry rules: pain 11 is still refused.
- A later damaged record does not inherit a previous approval (no latched replay).
- UI (`daily-approve-correction`): the box is created unchecked; `?approveCorrection=true&approveDamaged=true#approveCorrection` does not pre-check it; Save without a tick writes nothing; changing the date and back clears a previous tick; ticking and saving keeps valid sleep/steps and writes foot pain 2. (Chrome e2e, passed.)
- History delete and walk correction use `window.confirm` and then pass the strict flag. That is explicit confirmation, not a pre-ticked box. Current behaviour, not filed as a defect.

**PAIN_INVALID.** An invalid stored general pain (`pain` 14) is marked INVALID, readiness cannot be confirmed, copy says pain is unknown (not 0) and "Do not treat today as pain-free", `stepReferenceGoal` is `DO_NOT_FORCE` with `PAIN_INVALID`, and no optional 10k is offered. A *missing* (not invalid) general pain does **not** hold the goal (`ACTIVE`) — that remains an open owner item.

**Sleep range.** 0 h is a real FAIL; 6 and 24 PASS; values outside 0–24 (24.0000001, 24.5, 99, −1, `NaN`, strings) are UNKNOWN/invalid. A stored `sleepH` 99 is salvaged as INVALID and the rest of the check-in is still used.

**Fractional walk steps.** New 10.5 / 10.0000001 writes are refused and write nothing; 10 and 0 are accepted. A stored legacy 10.5 is kept byte-exact, not counted or rounded; a same-day whole count of 3000 stays 3000. Daily-total 10.5 remains refused on entry and restore (F7 / t54u unchanged).

**Bottom nav at 390px.** I hit-tested every visible in-panel `button`/`input`/`select`/`textarea`/`[role=button|tab]` on Today, all six Add modes (including the damaged check-in approval box), all History filters, Trends, and Settings: `scrollIntoView`, then `elementFromPoint` at the control's centre. Trends is display-only (no in-panel controls). The five tab-bar buttons are themselves hittable. **No coverage defect at 390px in Chrome emulation.** This is not Safari/WebKit and not a real iPhone.

## Counts on my tree (`p4/qa`, src = baseline)

| Suite | tests | pass | fail | skipped | log |
|---|---|---|---|---|---|
| `node --test tests/*.test.js` | 605 | **604** | **1** (the named DEFECT above) | 0 | `results/meron-qa-node.txt` |
| Python adapter (live test not run) | 8 | **8** | 0 | 0 | `results/meron-qa-python.txt` |
| Chrome-emulation e2e @ 390px | 42 | **42** | 0 | 0 | `results/meron-qa-chrome.txt` |

605 = baseline 591 + 14 new unit tests. 42 = baseline 40 + 2 new e2e. No existing test was edited.

## G) Dawit's and Liya's changes

### Dawit (`p4/data` @ `f2f0336`) — verified

Commit `f2f0336` ("P4 data: fix two prototype-key defects (P4-D1 dailyNutritionTotals, P4-D2 stored __proto__ field); add integrity attack tests"). Diff vs `b21cf93`: 8 lines in `src/data/hyrox-data.js` (`dailyNutritionTotals` uses `Object.create(null)`; `classifyRaw` copies top-level keys with `defineProperty` so a stored `"__proto__"` stays an own field) plus two new test files. I did not edit his tree.

I copied the new tests onto a scratch checkout of unmodified `b21cf93` (src untouched) and ran them; then ran them, and the full `node --test tests/*.test.js`, on his branch. Logs: `results/meron-dawit-tests-on-baseline.txt`, `results/meron-dawit-on-branch.txt`, plus the earlier proto-only logs.

| Tests | Unmodified baseline `b21cf93` (scratch) | Dawit `p4/data` @ `f2f0336` |
|---|---|---|
| `p4-dawit-proto-keys.test.js` (6) | **5 fail, 1 pass**, 0 skipped | **6 pass** |
| `p4-dawit-integrity.test.js` + proto (108) | **103 pass / 5 fail** (the 5 fails are exactly the proto regressions; the 1 proto "unchanged behaviour" case and all 102 integrity cases already pass on the baseline) | **108 pass** |
| Full `node --test tests/*.test.js` | (not re-run as 591+these; baseline alone was 591/591) | **699 pass / 0 fail / 0 skipped** (591 + 108) |

The 5 failing-first regressions are real: on the baseline, nutrition dated `__proto__` / `constructor` / `hasOwnProperty` pollutes `Object.prototype` (P4-D1, sessions can vanish), and a stored top-level `"__proto__"` is not kept as ordinary data (P4-D2). The sixth proto test ("a restore still ignores a top-level `__proto__` in a backup file") is explicitly unchanged behaviour and already passed on the baseline. The integrity file is attack/characterization coverage of already-correct behaviour (fault injection, preview/cancel, export/import, schema, raw recovery, cross-tab counts); it is **not** a failing-first set.

Dawit's integrity case "a raw recovery file renamed to app hyrox-app or stripped of its kind is still never restored" also already passed on the baseline. It covers weaker relabels than my DEFECT (he keeps `kind` when changing `app`, or strips `kind` while leaving `app` as `hyrox-raw-recovery`). It does **not** catch the wipe footgun where *both* identifiers are changed and empty `weight`/`workouts`/`nutrition` lists are added. That DEFECT remains on this data-layer patch as well (his 8-line fix does not touch `parseImport`).

### Liya (`p4/ui`) — still pending

`/workspace/hyrox-p4/wt/ui` is still **`b21cf93`**, clean, no commits after the baseline, no UI report. She has baseline rerun logs (`results/liya-00-baseline-b21cf93-*.txt`) and a WebKit availability check (`results/liya-webkit-check.txt`). Those are not source edits for me to fail-on-baseline / pass-on-branch.

`p4/integration` (`/workspace/hyrox-p4/build`) was still `b21cf93` when last checked.

**Pending:** Liya's eventual `p4/ui` commits and regression tests.

## Honesty box

**Proven (I ran it):** baseline node 591/591 and Python 8/8 on `b21cf93`; Claude's 38 unit regressions 38/38 on `b21cf93`; p4/qa node 605 / 604 / 1; p4/qa Python 8/8; p4/qa Chrome-emulation e2e 42/42 at 390px; approval-tickbox and nav hit-tests; D (including the relabelled-raw DEFECT); E path scan.

**Taken from Tewodros, not re-run by me:** baseline Chrome e2e 40/40 in `results/00-baseline-e2e-chrome390.txt` (complete list, exit=0; no SHA in that log).

**Unproven / could not verify:** WebKit / Safari (Playwright WebKit has been blocked here before; I did not launch it); a real iPhone; live AI (`test_food_photo_api_live.py` not run; no real model or API calls); any behaviour after 2026-12-06; Liya's landed UI edits (none to verify at this time). Dawit `f2f0336` was verified as above.

**Held owner items (unchanged, not decided here):** 17-of-20 closeout; both-Monday-and-Wednesday-missed; training after 2026-12-06; fasting DF vs D1–D5; legacy CONFIRMED photo meal with no eaten fraction; in-app emergency raw-copy restore; older fractional *daily* backup migration; week-4 failure outcome; 'demanding' definition; step percentages; whether a *missing* (not invalid) general pain should hold the reference goal.

## Recommendation (for Tewodros / the owner)

The R2 baseline suites pass as claimed. Approval, PAIN_INVALID, sleep range, fractional walks, and the 390px Chrome nav hit-test hold. One new HIGH data-loss defect: a relabelled emergency raw recovery file can be imported as an empty normal backup and wipe live data. I am not calling this tree ready to merge until that is fixed (or explicitly accepted) and Dawit's/Liya's eventual edits have been checked. **HOLD on merge.** Ready for owner iPhone testing only with a fresh normal export in hand, and with the emergency-file footgun understood.

## Verify 5e5d18f (Dawit's top-level `sources` refusal) — 11 Nov 2026, late evening Asia/Qatar

p4/qa after this work: **`8eb5fabff009c15fc779699b1322a44474b9fe69`**. Target: `p4/data` @ **`5e5d18f848dbd5dac09ec83e04c249fba4d27a9f`**, parent `f2f0336d5288b5b5b8cbbad33c85a99d9b07eac2`. I did not edit `p4/data`, `src/`, or any existing test. Temporary worktrees of `5e5d18f`, `f2f0336` and `b21cf93` were used and then removed with `git worktree remove --force`; official worktrees were left clean.

The fix is five new lines in `parseImport`: after `isRawRecovery`, any own top-level `sources` field is refused as `raw_recovery_file` (even if `app`/`kind` were edited). Normal backups never have that field.

Logs: `results/meron-verify-5e5d18f-on-5e5d18f.txt`, `...-on-f2f0336.txt`, `...-on-b21cf93.txt`, `...-bypass.txt`, `...-full-node.txt`, `...-qa-node.txt`.

### 1–2) DEFECT test and Dawit's new test, per tree

Copied `tests/p4-meron-adversarial.test.js` (p4/qa) and `tests/p4-dawit-edited-raw-file.test.js` (p4/data) into each temp tree (src untouched). Combined: 33 tests (14 Meron + 19 Dawit).

| Tree | tests | pass | fail | skipped |
|---|---|---|---|---|
| `5e5d18f` (the fix) | 33 | **33** | 0 | 0 |
| `f2f0336` (parent) | 33 | 20 | **13** | 0 |
| `b21cf93` (baseline) | 33 | 20 | **13** | 0 |

Dawit's new file alone is 19 tests: **19 pass** on `5e5d18f`; **7 pass / 12 fail** on both `f2f0336` and `b21cf93`. The 12 failures are the new refusal assertions (including the copied Meron DEFECT). The 7 passes were already true before the fix (kind kept / app still raw / untouched raw message / `parseRawRecovery` on an edited file / genuine normal, round-trip, and empty backups).

My original DEFECT (`previewImport/applyImport of a relabelled raw file wipes the live store; this must be refused`) **PASSES on `5e5d18f`** and still **FAILS on `f2f0336` and `b21cf93`**. The original repro (app → `hyrox-app`, `kind` removed, empty lists, `sources` kept) is fixed.

### 3) Bypass attempts

New file on `p4/qa` @ this commit: `tests/p4-meron-sources-bypass.test.js`. Run against `5e5d18f` (src untouched): **15 tests, 10 pass, 5 fail, 0 skipped**.

**The fix holds** when a top-level own property named exactly `sources` is present, on both `previewImport` and `applyImport` called directly (confirm + expectCurrent, no preview). Refused, nothing written, live data byte-identical, for: the original disguise; `sources` set to `null`, `{}`, `[]`, or `""`; kind/app/version edits plus empty lists; `__proto__` / `constructor` mixed in *alongside* `sources`; duplicate JSON keys whose last `sources` value is `null` or `[]`; a unicode-escaped `sources` key (`\u0073ources`); whitespace padding. A leading BOM is refused as `not_json` and writes nothing. A genuine normal backup without a `sources` field is still accepted and restores (no false refusal). A genuine empty backup still previews ok (existing policy).

**DEFECT still open (HIGH, data-loss footgun).** `5e5d18f` only inspects an own top-level property named exactly `sources`. If that key is renamed, moved, or deleted, the file is accepted as a normal backup and **replaces live data** with empty or planted lists. Repro (synthetic; both preview and direct apply; live weight 80 / walk 3000 are wiped or replaced):

- Rename `sources` to `Sources`, `SOURCES`, ` sources`, `sources`+ZWSP, `sour`+ZWSP+`ces`, Cyrillic look-alikes, `sources`+nbsp, or a BOM in the key name; keep the emergency copies under that look-alike key; relabel `app`, drop `kind`, add empty lists.
- Move `sources` under a `wrapper`, to `meta.deep`, or inside a weight entry; delete the top-level field.
- Delete `sources` but leave identifiable raw-recovery fields (`warning`, `format`, `normalExport`, `omitted`, `omittedTotal`, `state`).
- Remove top-level `sources` and stuff the copies under a JSON `"__proto__"` key.
- Delete `sources` and plant a partial `weight` list (live 80 kg is replaced by the planted 70 kg).

These five cases are left as clearly named failing DEFECT tests in `tests/p4-meron-sources-bypass.test.js`. `src/` was not changed.

**Characterization (not a DEFECT):** a file stripped of *every* recovery marker (`app`/`kind`/`sources`/`warning`/`format`/`normalExport`/`omitted`) is indistinguishable from a genuine empty normal backup and still previews ok — same empty-replace policy Dawit already recorded.

### 4) Existing assertions

`git diff b21cf93 5e5d18f -- tests/` and `git diff f2f0336 5e5d18f -- tests/`: **no modified or deleted test files, no changed existing assertion lines.** Only new files (additive):

- vs `f2f0336`: `tests/p4-dawit-edited-raw-file.test.js` (+186)
- vs `b21cf93`: that file, plus `tests/p4-dawit-integrity.test.js` and `tests/p4-dawit-proto-keys.test.js` from `f2f0336`

`src/` change vs `f2f0336` is the five new `parseImport` lines only.

### Full node suites

| Tree | tests | pass | fail | skipped | log |
|---|---|---|---|---|---|
| `5e5d18f` temp worktree + Meron tests copied | 747 | **742** | **5** (the bypass DEFECTs above) | 0 | `meron-verify-5e5d18f-full-node.txt` |
| `p4/qa` (src still `b21cf93`; new tests included, fix not merged here) | 620 | 607 | 13 | 0 | `meron-verify-5e5d18f-qa-node.txt` |

747 = 591 baseline + 108 Dawit (f2f0336) + 19 Dawit edited-raw + 14 Meron adversarial + 15 Meron bypass. The 5 failures on `5e5d18f` are only the bypass DEFECTs. The 13 failures on `p4/qa` are expected: src there does not include `5e5d18f` (1 original DEFECT + 7 "fix holds" guards + 5 bypass DEFECTs). The two genuine-backup tests in the new file pass on both trees.

### Verdict

The original Meron repro is fixed on `5e5d18f` and fail-first on `f2f0336` / `b21cf93`. The top-level exact-name `sources` check holds on both import paths and does not false-refuse a normal backup. A HIGH bypass remains: an edited emergency file can still wipe or replace live data if `sources` is renamed, nested, or removed, including when other raw-recovery fields or the emergency copies themselves are still in the file. No existing assertion was changed.


## Verify 9e9f2e1 (Dawit's extended emergency-marker refusal) — 11 Nov 2026, evening Asia/Qatar

p4/qa after this work: **`d385cf4f1d70d9821c6300dae39c4a864d6f998e`**. Target: `p4/data` @ **`9e9f2e13431d85d2404b08fc63de9264459ba741`**, parent `5e5d18f848dbd5dac09ec83e04c249fba4d27a9f`. I did not edit `p4/data`, `src/`, Dawit's worktree, or any existing test. Temporary worktrees of `9e9f2e1` and `5e5d18f` were used and then removed with `git worktree remove --force`; official worktrees were left clean.

The fix replaces the exact top-level `sources` check with `rawMarker()`: keys are compared after NFKC, stripping a fixed invisible-character set, trim, and lower-case (Cyrillic / other look-alike letters are not folded — accepted limit P4-L1). It refuses a normalized `sources` key at the top level; any of `warning` / `normalExport` / `omitted` / `omittedTotal` alone at the top level; `format` together with `state` at the top level; a sources-like key in a top-level wrapper object up to 3 levels down; and a sources-like key on a weight / workouts / nutrition entry. Phase 3 entries are not scanned (Dawit DECLINED: `putRecord` keeps unknown fields and `exportJSON` writes them back).

Logs: `results/meron-verify-9e9f2e1-meron-bypass.txt`, `...-meron-all.txt`, `...-dawit-on-9e9f2e1.txt`, `...-dawit-on-5e5d18f.txt`, `...-false-refusal.txt`, `...-bypass-r2.txt`, `...-full-node.txt`, `...-existing-assertions.txt`.

### 1) My 5 bypass DEFECTs, the rest of my p4/qa tests, and the full node suite on 9e9f2e1

Copied my p4/qa test files into a temp worktree of `9e9f2e1` (src untouched).

| Suite on `9e9f2e1` | tests | pass | fail | skipped |
|---|---|---|---|---|
| `tests/p4-meron-sources-bypass.test.js` (the 9 holds + 5 DEFECTs + 1 characterization) | 15 | **15** | 0 | 0 |
| All my p4/qa meron node files after this work (`adversarial` + `sources-bypass` + `false-refusal` + `sources-bypass-r2`) | 46 | **41** | **5** | 0 |
| Full `node --test tests/*.test.js` (Dawit's tests already in the tree + my files copied in) | 802 | **797** | **5** | 0 |

Before the new files were added, the same tree with only my then-existing meron tests was **785 / 785**. 802 = 785 + 6 false-refusal + 11 further-bypass. The 5 failures are only the new residual-bypass DEFECTs in `tests/p4-meron-sources-bypass-r2.test.js` (section 5).

**All 5 of my previous bypass DEFECTs are fixed** on `9e9f2e1` (they fail on `5e5d18f`, as already recorded). That includes: renamed / case / ZWSP / nbsp / BOM-in-key `sources` (leftover top-level markers also still present in that case); `sources` under a wrapper, at depth 2, or inside a weight/workouts/nutrition entry; leftover top-level `warning`/`format`/`normalExport`/`omitted` after deleting `sources`; stuffing `sources` under a JSON `"__proto__"` key; deleting `sources` and planting a partial weight list. My original relabel DEFECT in `tests/p4-meron-adversarial.test.js` still passes.

### 2) Dawit's new tests (`tests/p4-dawit-sources-bypass.test.js`)

38 tests. Fail-first holds:

| Tree | tests | pass | fail | skipped |
|---|---|---|---|---|
| `5e5d18f` (parent; file copied in, src untouched) | 38 | 13 | **25** | 0 |
| `9e9f2e1` (the fix) | 38 | **38** | 0 | 0 |

The 25 failures on the parent are the new refusal assertions (including copies of my five DEFECT titles, lone leftover markers, normalized / nested sources-like keys, and format+state). The 13 passes were already true before this commit (untouched raw message, exact top-level `sources`, constructor-name unknown fields, genuine format-only / lone-state backups, wrappers without sources, the Phase 3 `sources` DECLINED case, false-refusal rich/empty/v1 exports, and the two P4-L1 characterizations).

### 3) False-refusal hunt

New file: `tests/p4-meron-false-refusal.test.js` (6 tests) plus fixture `tests/fixtures/p3-phase3-export.json` (generated with `/workspace/hyrox-p3/build` @ `ed7ad84`, read-only; I wrote nothing into that tree). Run against `9e9f2e1`: **6 pass / 0 fail**.

The new build's own APIs produced a rich synthetic dataset covering weight, workouts, nutrition, daily (steps / pain / sleep), walks, sessions with `runSteps` and variants (`ORIGINAL_60`, `SOURCE_25_MIN`, `NONE`), weekend actual work (Sat completed + Sun partial), a manual meal, and a `PHOTO_AI` meal with eaten fractions. Notes / labels / text fields contain the words `sources`, `warning`, `format`, `normalExport`, `omitted`, `kind`, `raw_recovery_file`, and the JSON-looking text `{"sources":1}`. This build's normal export of that dataset is accepted on preview and on direct `applyImport`, and the restored store re-exports deep-equal minus `exportedAt`. A legacy v1 backup, an empty-device export, and the Phase 3 fixture are also accepted and restore. The emergency `rawRecoveryExport` of the same rich dataset is refused as `raw_recovery_file` on both paths; nothing is written; live data is unchanged.

**No false refusal found.**

### 4) Existing assertions

`git diff 5e5d18f 9e9f2e1 -- tests/` and `git diff b21cf93 9e9f2e1 -- tests/`: **no modified or deleted test files, no changed existing assertion lines.** Only new (additive) files:

- vs `5e5d18f`: `tests/p4-dawit-sources-bypass.test.js` (+290 / 0 deletions)
- vs `b21cf93`: that file, plus the three earlier Dawit test files (`p4-dawit-edited-raw-file.test.js`, `p4-dawit-integrity.test.js`, `p4-dawit-proto-keys.test.js`)

### 5) Further bypasses (not P4-L1)

New file: `tests/p4-meron-sources-bypass-r2.test.js`. Run against `9e9f2e1`: **11 tests, 6 pass, 5 fail, 0 skipped**. Holds that pass: NFKC fullwidth / soft-hyphen / ideographic space / narrow nbsp around a sources-like key; unicode-escaped and duplicate `sources` keys; `constructor.prototype.sources` at depth 3; an array root (including a raw envelope wrapped in an array) refused as `not_hyrox`; type confusion on `app` / `version` / `kind` does not bypass a present marker and writes nothing when there is no marker (`not_hyrox`); a 4000-deep nest with a genuine weight list completed in well under 5 s, failed closed on any throw, and otherwise restored 79 kg. Every refusal was checked on both `previewImport` and direct `applyImport` (confirm + expectCurrent); a refusal never wrote, and live data stayed byte-identical.

**Residual HIGH DEFECTs still open** (left as clearly named failing tests; `src/` not changed). An edited emergency file can still replace live data when a recovery marker is still in the file but sits outside `rawMarker()`'s scan:

- `sources` buried at wrapper depth 4 or deeper (the scanner stops at depth 3).
- `sources` hidden inside an array wrapper (the scanner only walks plain objects, so `wrapper: [{ sources }] ` and `meta.list[0].sources` are accepted).
- Leftover emergency markers moved off the top level: `warning` / `normalExport` / `omitted` under a wrapper or in an array, or the `format`+`state` combination under a wrapper. (The same names at the top level are refused.)
- Planting the emergency `sources` *copies* (array of `{key, raw, checksum, length}`) on a Phase 3 record (`daily`, `walks`, `body`, `dayStates`, or a valid photo meal) and emptying the core lists. Dawit DECLINED a blanket refusal of any Phase 3 field named `sources`, because a genuine `putRecord`+`exportJSON` can carry `sources: ['x']`. This DEFECT is narrower: a shape-aware check on the emergency copies would close it without false-refusing that genuine export.

Not filed as defects (accepted limit P4-L1, or existing policy): a Cyrillic or other un-folded look-alike (Greek omicron, a hyphen in the middle of the key) with every other marker stripped; a file with every marker removed (including a typo of `kind`) plus empty or planted lists; a deep / huge unknown field on a genuine empty backup, which still previews as an empty replace.

### Verdict

`9e9f2e1` fixes all five of the `5e5d18f` bypasses I filed, fail-first on the parent, does not change any existing assertion, and does not false-refuse a rich normal export, a legacy v1 backup, an empty-device export, or a Phase 3 export. A HIGH bypass remains: an edited emergency file can still wipe or replace live data if `sources` is buried deeper than 3 wrapper levels or hidden in an array, if leftover markers (`warning` / `normalExport` / `omitted` / `format`+`state`) are moved off the top level, or if the emergency sources copies are planted on a Phase 3 record.
