HISTORICAL EVIDENCE ONLY - NOT FRESH TEST RESULTS, NOT PART OF THE APP

Files directly in this folder were inherited from the Emergent Phase 3 build:
  real-ai-call-response.json, ai_call_ledger.jsonl  - record of ONE earlier owner-approved live-model test
                                                      with a synthetic illustration (no real photo).
                                                      They hold a macro estimate, an image hash and sizes.
                                                      No image bytes, no keys (re-scanned 2026-11-11).
  e2e-webkit-chromium.txt, pytest-*.txt, unit-node-all.txt - Emergent's own logs of that time.
claude-qa/     - round 1 logs (repair of the Emergent build).
claude-qa-r2/  - round 2 logs (review and repair of Grok ed7ad84). These are the current results.

None of this folder, tests/, ai-test-backend/ or the *.md files belongs in a deployed copy.
The app itself is only: index.html and src/ (see DEPLOY-FILES.txt).
