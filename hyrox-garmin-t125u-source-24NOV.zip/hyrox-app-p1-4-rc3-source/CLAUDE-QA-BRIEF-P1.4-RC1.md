# Claude QA brief: P1.4-RC1 (Combined Value Sprint integrated candidate) and the Garmin design

**From:** Grok sprint integrator, 23 Nov 2026 (Asia/Qatar).

**Gate 5:** you QA the full final source before anyone asks the owner for device QA or deploy approval. Agent messages are not approval. Synthetic data only.
- Do NOT run `ai-test-backend/test_food_photo_api_live.py` or make any live photo, Garmin or paid call.
- No Netlify, GitHub or Google Cloud writes.

## 1. Inputs (Drive folder 05_INDEPENDENT_QA; hashes in SHA256SUMS-p1-4-rc1.txt)
- `hyrox-app-p1-4-rc1-source.zip`: the full source tree at the final commit of branch `sprint`, including tests, tools, docs and `ai-test-backend/`. Use `git archive` and no `.git`.
- `hyrox-p1-4-rc1-sprint.bundle`: git bundle of `sprint`, `aa8d48d` (RC3 baseline) to final. `git clone hyrox-p1-4-rc1-sprint.bundle` gives every commit for per-commit review.
- `hyrox-app-p1-4-rc1-deploy.zip`: the deploy package. Source id `f7f66257b5fa`.
- `p1-4-rc1-per-commit-patches.zip`: one patch per sprint commit, plus RC3 to final.
- `p1-4-rc1-raw-logs.zip`: every fail-first, regression, stress and rollback log, plus evidence scripts.
- `p1-4-rc1-screenshots.zip`: screenshots at 320 and 390 px (A before/after, B note, C fold, D panel states). Chrome emulation.
- `CHANGES-P1.4-RC1.md`: QA report and the explicit Done / Deferred / Broken-unknown / Needs credentials / Needs real iPhone QA table. Also `DEPLOY-P1.4-RC1.md`, and the four `CHANGES-SPRINT-*.md` files inside the source.
- Specs:
  - Coaching export plan HNC-E-COACH-001 v1.0: Drive doc `1U_NMp8r3taEqyr3n-78X12y4dW3XbxT3ulvfkx-TRig`.
  - Garmin design `DESIGN-GARMIN-PERSONAL-API-23NOV.md`: Drive file `14iiakuaLe1Jj7urCVBn_zquY7BbwwPU_`.
  - Handover `CC-COMBINED-VALUE-SPRINT-23NOV`.

## 2. Reproduce first
1. **Check hashes.** `sha256sum -c SHA256SUMS-p1-4-rc1.txt`.
2. **Recompute the source id.** sha256 over the 19 `index.html|src/...` lines of DEPLOY-FILES.txt, each fed as path+NUL+bytes+NUL. The first 12 hex characters must be `f7f66257b5fa`.
3. **Rebuild the package.** Run `node tools/build-deploy-package.mjs <out>/hyrox-p1-4-rc1-deploy`.
   - Zip it with sorted paths, timestamp 2026-11-23 00:00:00, mode 0644, deflate 9 and prefix `hyrox-p1-4-rc1-deploy/`. The script is in the logs zip as `detzip.py`.
   - The sha256 must be `d43492de5f807bb63a69a84056cd207a845ff8263570dcd8eafa6931568d49ff`.
   - Or compare the unpacked tree file by file with SHA256SUMS.
4. **Run the tests:**
   - Unit: `node --test tests/*.test.js`. Expect 1634 pass.
   - Python, fake model: `pytest -q ai-test-backend/test_food_photo_adapter.py`. Expect 8.
   - Browser: `playwright test -c tests/playwright.local-chrome.config.js`. Expect 655 pass and 1 skip.
   - Stress: F-1 `--repeat-each 15` gives 240. The four sprint specs `--repeat-each 5` give 205.
   - Rollback specs: `tests/rollback/*.spec.js` (the log QA-F6 shows how they were run on 4 older builds).
5. **Look for hidden skips.** The one skip is pre-existing (it is also in the RC3 baseline log `00-baseline-chrome.log`). Confirm it.

## 3. Review targets (please look hardest here)
**A: photo + note** (`netlify/lib/openai.mjs`, `netlify/lib/handler.mjs`, `src/ai/photo-ai.js`, `src/ui/app-ext.js`)
- Prompt and request: the note is data, not instructions (prompt injection). The schema still limits output.
- No photo retention, consent and sanitising unchanged. Caps, reserve, owner code, origin check and model are unchanged (config, image, store and food-photo are byte-identical to RC3).
- "Not accounted for": the acknowledgement semantics. Confirm is gated; a DRAFT may be parked. Older data loads unchanged.

**B: workout draft** (`app-ext.js`: loadDraft, saveDraft, workoutDraftNote, sessionConflict, the storage listener)
- The envelope stays backward compatible: older builds restore it (tested on 4).
- Conflict detection compares the stored `updatedAt` with the edit's base, or a missing record.
- The two-tab guard and 200000-char limit. Qatar start day across midnight. Invalid drafts are never auto-restored.
- **Decision for the owner:** meal-draft persistence is HELD because it needs a new UI key. Review options M1–M4 in CHANGES-SPRINT-B and recommend one.

**C: settings fold**
- Presentation only. `stubs.js` is unchanged, and nothing became interactive.
- Photo analysis is still clearly separate and working.

**D: Export for AI Coaching** (`src/data/hyrox-coach-export.js`, `app-ext.js` section "Sprint D", `tests/p1-4-coach-export.test.js`, `tests/e2e/p1-4-coach-export.spec.js`)
- **Read-only:** `collect` uses only the store's read methods, and no storage key changes (tested). There is no network call; it is tested offline with a request listener.
- **Privacy:**
  - It never exports the owner code, AI settings, pre-import backup, workout draft or photos (planted SECRETS test).
  - Recovery, symptoms and free text are OFF by default. Free text covers notes, description, label, portion, preparation and uncertainty.
- **Semantics** against plan section 6:
  - Unknown stays null, never 0. Only CONFIRMED meals carry numbers.
  - Day codes and D5 averages come from HN.dayState.
  - Planned slots come only from Block 1 and **activated** blocks. The Block 2 lock is respected via HB.activated.
  - DAMAGED records are excluded and counted.
  - Qatar date boundaries and unique file names are applied.
- **Deliberate deviation:** the workout block field `omitted` is exported as `omittedByOwner`. Otherwise the restore path would classify the snapshot as an "emergency raw recovery copy". Confirm that this is better than the plan's name. Restore refusal was checked on current and 4 older data layers (`not_hyrox`).
- **Labels:** no "uploaded", "synced", "saved to Drive" or "backed up". Cancel, fallback and error are honest. Residual: "Share again" also appears after a download fallback (it downloads again). Is that acceptable, or should it be fixed before device QA?
- **Not built:** direct Drive/OAuth. It is deferred by the handover. Confirm that deferring it is right.

**Packaging and test re-points**
- 18 to 19 app files, and the label P1.4-RC1. Every changed assertion carries a `RE-POINTED` comment.
- One pre-existing commented-out assertion was found in `tests/p1-3-package.test.js` (`APP_FILES.length !== 18`, swallowed by a trailing `//` comment before this sprint). It is noted, not changed.
- README-DEPLOY: the "byte-identical to RC2" sentence is now qualified for A's three files.
- Allowed storage keys are unchanged. There is no migration and the data version is still 2.

## 4. Garmin design review (`DESIGN-GARMIN-PERSONAL-API-23NOV.md`, design only)
- Confirm that **no Garmin code** is in the candidate. Grep for `garmin` under `src/` and `netlify/`: the only hits should be the existing GARMIN_MANUAL morning log and the inactive stub text.
- Security review of the proposed architecture:
  - key only in Function env;
  - owner-code-gated, same-origin proxy;
  - server-side token cache keyed by a key fingerprint;
  - one in-flight request, 15-minute spacing, a hard stop on `retryInSeconds: -1`;
  - no calorie import.
- Data mapping (section 5.3):
  - provenance kept inside the existing observed objects, with no enum change;
  - `stepsSource` stays DEVICE|MANUAL;
  - manual intensity is never overwritten without an explicit per-day Replace;
  - **rollback: API-sourced intensity reads INVALID on older readers** (open question 9).
- Consistency with this candidate:
  - C keeps the `health-import` stub inactive (design 5.1).
  - D lists device-imported activity as unavailable (`unavailable.deviceImportedActivity`).
  - A future Garmin source should flow into D's steps and training categories with provenance. Flag anything in D that would block that.
- Answer or route the open questions (section 9, 1–9) that need owner decisions. Live work needs its own explicit owner permission after your security review. This candidate does not request it.

## 5. What we ask back
1. Findings by severity, with file and line.
2. Confirm or adjust the explicit table in CHANGES-P1.4-RC1.md, especially the "Needs real iPhone QA" rows.
3. A recommendation on the meal-draft key (M1–M4) and on the "Share again" residual.
4. Garmin design: a security verdict and the conditions for a later implementation.
5. GO / NO-GO for asking the owner for real-iPhone QA of P1.4-RC1. This is not deploy approval; only the owner decides that.
