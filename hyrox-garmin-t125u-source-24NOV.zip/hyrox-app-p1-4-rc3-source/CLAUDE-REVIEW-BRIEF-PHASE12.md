# Claude review brief: Phase 12 Block 2 planner (release candidate, not content approval)

**Base:** Claude P11.2 source (zip sha256 `6e2b2cae384ce8475f831e9a6a73aff1eeb974ec9198249f8f7ec229ec862bd7`) = commit `e86371a`.
**Patch:** `hyrox-app-phase12.patch` (vs `e86371a`). **Binding decisions:** CC-BLOCK2-RESPONSE-19NOV D1–D12.
**Rules for the review:**
- No paid calls and no deployment.
- Stub provider only. `test_food_photo_api_live.py` was not run.
- Keep the release-candidate verdict separate from Block 2 training-content approval. The owner approves the content in-app after the 11 Dec benchmark; this build only ships the Hold draft template and the mechanics.

## CC review focus: where to look
| Focus | Where | Evidence |
|---|---|---|
| Block 1 hash pins unchanged | no existing `src/data/*` file changed | `p12-blocks.test.js` "changes no existing data-layer file", plus the existing p8/p9/p10/p11 pins (all pass) |
| Data integrity | `HB.validateBlock`/`readBlocks` (invalid entries reported and kept), `writeBlocks` (refuses a non-list `planBlocks` or damaged settings) | unit "corrupt or duplicate…", "writers…"; e2e "corrupt planBlocks…" |
| Exact midnight boundaries | `HD.todayQatar` + ISO date compare | unit + e2e 13/14 Dec 23:59:59/00:00 +03, 10/11 Jan |
| No cross-block cascade | block events in `block.events`; legacy `planEvents` never read or written for Block 2; the ADJUST_WEEK save writes the block only | unit "cascade events are block-scoped"; e2e calendar + skip/adjust (planEvents stays empty) |
| No accidental activation | create ≠ activate; activation only ≥ 11 Dec, with approval tick, confirm dialog, preview-hash + settings-stamp STALE guards, ALREADY_ACTIVE/OVERLAP/START_IN_PAST/BOTH_NOT_CONFIRMED | unit "activation…"; e2e 11 Dec flow |
| Drafts have no effect | `slotById`/`blockForDate`/`plannedOn` resolve ACTIVATED blocks only | unit "a draft (or cancelled block) has no effect"; e2e (Today text identical; no Block 2 slot in the session form) |
| Old-backup warnings | `HB.restoreNote` → `import-preview-plan-blocks` | unit + e2e restore preview |
| Settings writers preserve fields | the baselines save now re-reads at click time (**P11.2 lost data here; fail-first e2e proves it**); the damaged Replace path uses `HB.repairCarry`; `saveFoodPrefs` unchanged (already fresh) | e2e "stale screen", "damaged settings"; unit repairCarry / P11.3-style field |
| 15-min machine cap + fallbacks | `holdLines`, `LOW_IMPACT`, `variantPrescription` (§9 45/25 mapped to the v2.1 W2/W4 slot) | unit "15-minute cap" (every slot, option, fallback, revision); Benchmark 3 fallback marked not comparable |
| Pain/readiness guards | `hyrox-wellness.js` byte-identical; readiness is plan-independent; the planner shows the stop rules and changes none | e2e glance readiness text identical with and without a block |

## Please pressure-test
1. **Activation gate ≥ 11 Dec.** The owner may want a 7 Dec staging test. That is an open owner item; it is deliberately not relaxed here.
2. **Shared adaptive step logic.** `stepContext` now counts a Block 2 planned session as "planned today", so the adaptive light-day logic behaves as in Block 1. ST0 only removes the plan reference goal.
3. **Block 2 fallback-family check is UI-only.** It is `HB.variantFamilyError` in the save handler, because the data layer's check only knows v2.1 ids and the data layer is byte-pinned.
4. **Block size.** A block is about 10 KB; 18 max-length owner revisions still pass `containsImageBytes` (string ≤ 4000, depth ≤ 8).
5. **Stale stamp.** It is a checksum of the whole settings record (not `updatedAt`), so a write in the same millisecond is still detected.
6. **Not built:** a dedicated make-up day picker beyond the existing skip/reschedule flow; editing an activated block's options (revise per session instead).

## Real-iPhone limits (not tested here)
All e2e ran in **Chrome emulation, not Safari/WebKit**. Untested on a device:
- `confirm()` dialogs in standalone Home Screen mode
- `<details>` folds with VoiceOver
- radio and checkbox tap targets at Larger Text
- the midnight rollover while the app sits in the background (the existing `checkDay` re-renders on the next tab tap)
- Safari tab vs Home Screen storage separation (two "devices")

## Test results (raw logs in the tests zip)
- **JS unit:** 1449/1449 pass, 0 skipped. This includes `p12-blocks.test.js` (26), with rollback restores on the Claude P11.2, P11 (bdab182 zip ffa58d1a…) and P10b (34bdf3d) data layers.
- **Python stub adapter:** 8/8 pass.
- **e2e (Chrome emulation, not Safari):** 398 passed, 1 skipped (pre-existing p4 "meal totals at the 150% page-zoom proxy"); baseline e86371a: 383 passed, same 1 skipped. p12-planner: 15 tests (3 at both 390 and 320, plus 9 at 390), stable over 3 consecutive runs.
- **Fail-first:** on baseline `e86371a` the p12 unit file fails (module missing) and all 15 p12 e2e fail. That includes the stale settings writer losing `planBlocks`/foods, and the damaged-settings Replace path dropping `planBlocks` (`failfirst-*.txt`).
