# Phase 11.2: owner checks, deploy and rollback (Windows PowerShell + iPhone)

**This package is not deploy approval.** Deploy only after Claude's review and the owner's explicit go-ahead. Only the owner runs these steps, with his own logins. **Site:** `hyrox-phase7-private-test`, ID `99f0deb7-0526-46f6-b432-9c3bfc2c86d2` — same site, same Home Screen icon. Phase 5 site out of scope.

**No env change** (no variable, secret, key, model, price or cap change). **No migration**, data version stays 2. New: one static file `src/data/hyrox-foodsearch.js` (13 app files instead of 12). Saved foods live as optional fields of the settings record; nothing old is rewritten.

> Never paste into any chat: your OpenAI key, owner code, any `Authorization` header, photos, or what you ate.

## A. Read-only: confirm what is live now
Netlify → site → Deploys → Published deploy, at the time of writing: `6afec2db01dca13a10f07237` (production, "Build from drop deployment", published 19 Nov 2026 12:35 Qatar). Deploy file browser → sizes:
| `src/ui/app-ext.js` | `src/ui/style.css` | Live build |
|---|---|---|
| 223896 | 39561 | **Claude P11** (`b8275adb…`) — expected |
| 256080 | 41683 | Phase 11.2 (this package) |
| anything else | | stop and report the sizes |

## B. Backup first (mandatory)
iPhone → Home Screen icon → Settings → **Export**. Keep the file. Do not continue without it.

## C. Deploy Phase 11.2
```powershell
cd $HOME\Downloads
Get-FileHash .\hyrox-app-phase11-2-deploy.zip -Algorithm SHA256   # must equal its line in SHA256SUMS-phase11-2.txt
Expand-Archive .\hyrox-app-phase11-2-deploy.zip -DestinationPath .\hyrox-p11-2-deploy -Force
cd .\hyrox-p11-2-deploy\hyrox-phase11-2-deploy
npm ci
npx netlify-cli login
npx netlify-cli sites:list --json | ConvertFrom-Json | Where-Object { $_.id -eq '99f0deb7-0526-46f6-b432-9c3bfc2c86d2' } | Select-Object name, url, id
# must show hyrox-phase7-private-test, otherwise STOP
npx netlify-cli deploy --site 99f0deb7-0526-46f6-b432-9c3bfc2c86d2 --dir publish --functions netlify/functions --message "Phase 11.2 draft"
```
1. **Draft check** in a new Safari tab on the draft URL (not the icon; AI stays off without the code):
   - Add → Meal → Manual → one item → Confirm → lands on **Today**, diary open, the meal shown **once** (Uncategorized if no category).
   - Today → Lunch "+ Log" → **Add foods (search)** → type `banana` → tap result → Add to meal → type `egg` → Add → **‹ Meal** → 2 items → Confirm → Lunch shows 1 entry.
   - Trends → Summary card, 4 weeks / 12 weeks / All switch.
   - Clear that tab's website data.
2. **Production:** `npx netlify-cli deploy --prod --site 99f0deb7-0526-46f6-b432-9c3bfc2c86d2 --dir publish --functions netlify/functions --message "Phase 11.2"`. Open the icon, close and reopen: all data still there.

## D. Owner device QA (real iPhone Safari; all e2e ran in Chrome emulation, not Safari)
1. Add foods: type quickly, then airplane mode and search again — still works (search is on the phone; no data used).
2. Search `big mac`: badge "Restaurant · US 2018"; "Macros and source" says it is not McDonald's official figure.
3. Log two foods + one manual item in one meal, set the eaten amount to half, Confirm once → one entry, totals halved.
4. History → a confirmed meal → **Save to My foods** → Add foods → My foods shows it; rename it → old meal unchanged.
5. Today glance: Steps / Exercise / Weight rows; tap Log weight → weight field focused.
6. Larger Text + zoom: nothing clipped; tapping inputs does not zoom. VoiceOver: after Confirm, focus is on the new diary entry.
7. Settings → Export → Restore preview: no duplicates; My foods still listed after restore.

## E. Rollback (no env change, no migration; Blobs budget counters kept)
**Fastest:** Netlify → Deploys → click `6afec2db01dca13a10f07237` (live before this; "2 new files uploaded" on top of P10b, i.e. Claude P11 — confirm with the sizes in A) → **Publish deploy**.
From a zip (check the hash, then the same `npm ci` + `deploy --prod` as in C):
| Order | Target | SHA256 |
|---|---|---|
| 1 | Claude P11 `hyrox-app-phase11-deploy…` | `b8275adb58a5f435983be4b7752714c45e13ed04ed12c18ae37a5406fe458b82` |
| 2 | Claude P10b `hyrox-app-phase10b-deploy…` | `da206f891229ae43b73a04722d2a2a37f2ca92aba7df31accbf19c2016e8cf72` |
After rollback: meals saved via Add foods stay normal meals; `myFoods`/`favFoods` stay inside the settings record (tested on P11, P10b, P9 data layers) and come back if you redeploy 11.2. Risk: on an older build, choosing "Replace the saved settings" for a damaged settings record would rebuild it without the saved foods.
