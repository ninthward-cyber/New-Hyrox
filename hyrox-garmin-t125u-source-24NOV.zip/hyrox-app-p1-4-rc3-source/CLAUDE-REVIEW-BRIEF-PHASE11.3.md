# Claude review brief — Phase 11.3 (Grok, 19 Nov 2026)

**Base:** Claude P11.2 source `6e2b2cae384ce8475f831e9a6a73aff1eeb974ec9198249f8f7ec229ec862bd7`, git `96832ff`.
- A fresh build reproduces Claude's deploy `publish/` byte for byte.
- All C-01..C-06 repairs are kept, and their tests pass unchanged.

**Patch:** `phase11-3-vs-claude-p11-2.patch`. Commits are split per part:
- part 1 (US foods)
- follow-ups
- part 2 (fiber/sodium)
- QA

## Please check
1. **Data.** `tools/food-db/build_food_db_us.py` and `src/data/FOOD-DB-US-PROVENANCE.md`.
   - FNDDS 2021-2023 (FDC 2024-10-31) is pinned by sha `dfb06ae7…`.
   - Portion parsing drops "guideline amount" rows.
   - The chain-dish portion order is changed (Big Mac only).
   - SR/FF fiber/sodium use nutrient ids 1079/1093 and 291/307.
   - CC0 terms are quoted from the FDC API guide.
2. **Search** (`hyrox-foodsearch.js`):
   - the two ranking bonuses (head-full +40, unit hint +70) and their effect on older queries
   - `restaurantKind`: FN "(Chain)" suffix, SR prefix list, generic /fast food|restaurant/
   - the labels must never read as official
3. **Fiber/sodium:**
   - `hyrox-fibersodium.js` `dayTotal`: COMPLETE only when D4/D5 and every confirmed consumed item is known; an unstated photo fraction counts as unknown; fraction 0 is excluded.
   - The eaten fraction must match `HN.eatenFractionOf` (unit test compares them).
4. **No data-layer validation** of fiberG/sodiumMg. `hyrox-data.js` is byte-pinned, so invalid values are treated as unknown at read time. Is that acceptable, or should Phase 12 integration add validation?
5. **Edit rule.** A changed kcal or macro number clears USDA-derived extras; a typed (KNOWN) value is kept. Older UIs keep stale extras (documented, and e2e-pinned as KNOWN RISK).
6. **Settings.** No settings writer was changed. Unknown fields (`planBlocks`) survive the 11.3 writes. C-01 Replace still drops non-food fields (INTEGRATION NOTE test).
7. **Test edit.** `p11-2-food-search.spec.js` Big Mac flow now selects the SR row by name. Is that acceptable?

## Tests (raw logs in the logs zip)
- **Unit:** see `unit.txt` (baseline 1423). 0 fail, 0 skip.
- **Py stub:** 8 passed. The live API test was never run.
- **Chrome e2e:** 413 passed, 1 skipped.
  - The skip is `p4-regress-meal-totals.spec.js:38`, which needs a 320 project; this config has only the mobile 390 project.
  - The new 30 specs cover 390 + 320 px.
- **Fail-first:** the new specs were run on the baseline tree: 28 failed, and 2 passed as expected (the INTEGRATION NOTE pins unchanged behaviour).
- **Rollback data layers:** Claude P11.2, P11 and P10b were checked in unit tests and in a same-origin older-UI e2e.
