# HYROX Command — Claude independent review, Phase 11.2 (HNC-P11.2-R1)

Date: 19 Nov 2026 · Reviewer: Claude · **Local only.** Nothing deployed, no GitHub write, no Netlify or OpenAI account touched, no paid call. Synthetic data only; stub photo provider only; `test_food_photo_api_live.py` not run.
Labels: **CONFIRMED** (I ran or read it), **INFERRED** (my judgement), **UNKNOWN** (not established).
This review is **not** deploy approval. You decide that separately.

## 1. Verdict

**READY FOR OWNER DEVICE QA, with the 5 repairs included (Claude build).** Grok's build is sound: the scope is as described, no assertion was removed, and the data layer, the photo function and `netlify/` are untouched. I found one MEDIUM data-loss path (C-01), one MEDIUM usability gap in search (C-03) and three LOW issues. All five are repaired, each with failing-first tests. If you deploy, use the Claude deploy package (`hyrox-app-phase11-2-deploy-claude.zip`), not Grok's.

## 2. Package verification (CONFIRMED)

| Check | Result |
|---|---|
| Grok source / deploy / patch / raw-results ZIPs vs `SHA256SUMS-phase11-2.txt` | all 4 match (`ff08c21d…`, `8667e503…`, `2829add8…`, `5273afda…`) |
| Base: Claude P11 source `ffa58d1a…`, deploy `b8275adb…` (from Drive) | both match the 11.2 checksum file |
| `git apply` of `phase11-2-vs-bdab182.patch` on Claude P11 source | reproduces the 11.2 source tree exactly |
| Grok's deploy ZIP vs a fresh build of the 11.2 source | identical except 2 top-level `.md` docs (outside `publish/`) |
| Files claimed byte-identical to P11 (`hyrox-data.js`, `hyrox-foodcalc.js`, `food-db.*`, `photo-ai.js`, nutrition/wellness/plan, `netlify/`) | identical, also after my repairs |
| Edits to existing e2e specs (p3-flows, p3-owner-rules, p10b-meal-reset, p11-meal-diary) | additive only: a `panel-today` assertion plus a History tab click, and one title reworded. No assertion removed. |

## 3. Tests

| Suite | Grok 11.2 (their logs) | Grok 11.2 rerun here | Claude repaired build |
|---|---|---|---|
| JS unit | 1,418 pass, 0 skip | 1,418 tests: 1,404 pass, **14 skip**, 0 fail | **1,423 tests: 1,415 pass, 8 skip, 0 fail** (+5 new) |
| Python stub adapter | 8 | 8 | **8** |
| Chrome e2e | 371 pass, 1 skip (re-run) | **371 pass, 1 skip** | **383 pass, 1 skip, 0 fail** (+12 new) |

**Every skip, and why (CONFIRMED):**
- **e2e (1):** `p4-regress-meal-totals` "150 % page-zoom proxy". Pre-existing and unchanged.
- **JS (8):** all need material that is not on this machine.
  - 6 need the Phase 7/8 source trees: 2 in `p11-meal-category` and 4 in `p9-downgrade`.
  - 2 need the raw USDA zips to rebuild the food bundle.
- **The 14 → 8 difference:** the 6 extra skips on the first rerun were rollback tests looking for folders that exist only on Grok's machine.
  - I pointed them at the verified Claude P11, Claude P10b and P9 trees, and all 6 pass.
  - This includes the 3 tests behind the brief's claim that P11, P10b and P9 restore a P11.2 backup with `myFoods`/`favFoods` intact.
- **Fail-first:** my 5 new unit tests and 12 new e2e tests were run on unmodified 11.2.
  - Unit: 4 of 5 fail. The fifth checks that a numbers-only query still searches as typed, which 11.2 already did.
  - e2e: 10 of 12 fail. The 2 that pass are the intended "healthy settings save keeps My foods" guard, at 390 and 320 px.

**Timing test:** `p5-claude-review` "year of daily logging…" **did not reproduce**. It passed in all three of my full runs (2.6–2.9 s). I infer, as Grok did, that it came from a parallel Chrome job on their machine.

## 4. Findings and repairs (most severe first)

| ID | Severity | Finding (CONFIRMED in code and by a failing test) | Repair |
|---|---|---|---|
| **C-01** | **MEDIUM** (data loss) | If the settings record is damaged (for example an out-of-range RHR value from an old backup), Add foods refuses to save, saying the settings "need attention first (Settings)". **Settings → "Replace the saved settings" then rebuilt the record without `myFoods`/`favFoods`, so every saved food and favourite was lost.** The app sent you down the exact path that deleted them. | The replace path now carries both lists over: it reads the stored record read-only and normalises them. The checkbox says "Your N saved foods and M favourites are kept." `app-ext.js`. Data layer untouched. |
| **C-03** | **MEDIUM** (usability) | Search treated a typed count or unit as a required food word. "2 eggs", "4 boiled eggs", "1 can tuna", "chicken breast 200g" and "1 banana" returned **No match**, pushing you to Manual entry with kcal unknown. | When the query contains a number, counts and units are ignored for **matching only**. They never set the quantity: you still pick serving and quantity. "slice cheese" with no number still means sliced cheese. A numbers-only query searches as typed. `hyrox-foodsearch.js`. |
| C-02 | LOW | `validMyFoods` checked only `id`/`name`. A saved food without macro objects (hand-edited or future backup) made My foods and search throw. | Each entry is normalised as a copy: a missing or invalid value becomes UNKNOWN (never 0); well-formed entries come back unchanged. |
| C-04 | LOW | The "just saved" diary marker was never cleared. It stayed after leaving Today or changing day, contradicting "marked once". | Cleared on leaving Today or changing the diary day. Today is redrawn so the marker is gone on return. Grok's 18 diary-navigation tests still pass. |
| C-05 | LOW (visual) | Trends: the new first-date label was drawn over the minimum-value label in every chart at 320 px (seen in a screenshot). | A 12-unit strip below the plot holds the dates. Plot geometry and data points are unchanged. Test asserts no text boxes overlap. |
| C-06 | LOW (test portability) | 11.2's rollback tests hard-code Grok-machine paths with no override, so they silently skip elsewhere. | Added `P112_P11_SRC`, `P112_P10B_SRC` and `P112_P9_SRC` overrides. Paths only; assertions unchanged. |

New tests: `tests/p11-2-claude-review.test.js` (5) and `tests/e2e/p11-2-claude-review.spec.js` (12, at 390 and 320 px).

## 5. The brief's checks, answered

1. **Diary return: CONFIRMED by code and tests.**
   - Every confirmed Add > Meal save that doesn't come from History's own Edit/Copy returns to the meal's own date and category (or Uncategorized), and focuses the entry. That covers Manual, Describe, Photo and Add foods.
   - History Edit/Copy and Save draft still go to History; a failed save stays on the form.
   - Late photo or description replies are dropped by the existing `ms`/`photoGen` identity check (unchanged since P10b).
2. **Category preservation in older UIs: CONFIRMED by reading P10b and P9 `save()`.**
   - Both save a deep copy of the edited record, so `mealCategory` (and any top-level field) survives an edit.
   - Older Settings saves mutate `set.record`, so they also keep `myFoods`.
   - **Residual risk:** an older build's "Replace the saved settings" on a damaged record still drops them. That can't be fixed in old builds; C-01 fixes it in this one.
3. **Schema: I confirm data version 2 with optional fields, for now.**
   - Evidence: P11, P10b and P9 keep `myFoods`/`favFoods`; P11 and P10b keep component `fiberG`/`sodiumMg` and a new provenance source through export and restore.
   - The thing that **does** break older builds is a new meal `source` value: P11 and P10b refuse `FOOD_SEARCH`. So keep `meal.source = MANUAL`, as 11.2 does.
   - Move to version 3 only if you later need a new enum value or a new top-level collection. I infer that water tracking may be the first case.
4. **Search honesty: CONFIRMED.**
   - Results are a ranked list and nothing is auto-picked.
   - Typo matches are labelled "Spelling-tolerant match".
   - Restaurant rows are badged, and their detail says "NOT the restaurant's official figure".
   - No fake `fdcId`: manual items carry no provenance, and My foods keep provenance only with a numeric `fdcId`.
   - USDA values stay ESTIMATED, and unknown kcal shows "unknown", not 0.
   - Saved foods are copies of the full-portion values, not scaled by the eaten fraction.
5. **No network while typing: CONFIRMED** by Grok's e2e (zero requests) and by code.
   - The index is in memory only: 8,167 foods, built in about 90 ms in Node; queries take about 0.1–15 ms.
   - Only the two food lists are added to the stored record.
6. **Habits and Trends: CONFIRMED presentation only.**
   - The step target is the existing computation, and Exercise shows recorded sessions and walks with no calorie burn.
   - Weight is the latest measured entry with its own date. (`body` records hold waist only, so Today and Trends use the same source.)
   - There is no water row, and charts draw recorded points only.
7. **Accessibility:** Grok's tests (16 px inputs, ≥44 px targets, focus) pass here, and mine add 320 px checks. **Chrome emulation only.**

## 6. Your priority table — my view

| Your decision | My view |
|---|---|
| **Expanded free USDA database — proceed next** | **Agree.** Grok's proposal is a sibling FNDDS 2021–2023 file (their measurement: about 159 KB gzip, 5,432 items; I have not verified it), labelled separately, in version 2. **Limit:** FNDDS is US survey data. **CONFIRMED:** shawarma, machboos, karak and labneh currently return 0 matches. Whether FNDDS adds them is UNKNOWN; I'd expect few. For Qatar staples, My foods (save once, reuse) is the realistic free path. |
| **American restaurant nutrition — prioritize** | **Agree only if it means honest labelling, not "official numbers".** The research says official chain tables can't be bundled or scraped (terms not legally verified, UNKNOWN). The free coverage is USDA 2018 named items plus FNDDS survey items, both estimates. Concrete next step: "enter the chain's official value → save to My foods", which already exists. INFERRED: Qatar branches of US chains may not match US recipes or portions, so this matters most for US travel. |
| **Fiber and sodium — with database expansion** | **Agree, and it's safe in version 2. CONFIRMED** that P11 and P10b keep these fields through export and restore. Store them as KNOWN/ESTIMATED/UNKNOWN. The current SR/Foundation bundle has no fiber/sodium, so most items would be UNKNOWN. Decide before building whether day totals show them; a day with any unknown item must show "partial", never a low number. |
| **Water tracking — separate update** | **Agree it's separate, and it needs a storage decision first.** A new collection may be dropped by an older build's export: the research says export writes only known collections, which I have not tested (INFERRED). Storing it as a field on the daily check-in avoids that. I can test both before anything is built. |
| **Paid food subscriptions — hold** | **Agree.** It is consistent with the research's FatSecret terms finding. |
| **Block 2 training planner — Phase 12** | **Flag: this is your deadline item.** Block 1's deload ends 13 Dec and the project says Block 2 ships before 14 Dec, about 3½ weeks from today. Phase 12 still needs build, review and your device QA. INFERRED: decide the Block 2 *content* now, in parallel with the food work (who writes it, what changes from Block 1), or it will slip. |

## 7. Not verified (UNKNOWN)
- Real iPhone Safari/WebKit: iOS keyboard, VoiceOver, Larger Text, Home Screen behaviour and airplane mode. **All e2e is Chrome mobile emulation.** Use the owner device QA in `DEPLOY-PHASE11.2.md` section D.
- The live Netlify runtime.
- The P7/P8 rollback tests (trees not available).
- FNDDS contents and size.
- Legal terms for any restaurant data.

## 8. Deploy note (if you approve later)
Same site and steps as `DEPLOY-PHASE11.2.md`, using **the Claude package**. Its step-A size table changes for the Claude build:

| `src/ui/app-ext.js` | `src/ui/style.css` | Build |
|---|---|---|
| 223896 | 39561 | Claude P11 (live now, expected) |
| 256080 | 41683 | Grok 11.2 (do not deploy) |
| **258287** | **41683** | **Claude 11.2 (this package)** |

`hyrox-foodsearch.js` is 20,661 bytes in the Claude build. There is no environment or data migration change. Rollback is the same as in `DEPLOY-PHASE11.2.md` section E.

## 9. How to check
```
node --test tests/*.test.js
P112_P11_SRC=<claude-p11>/src P112_P10B_SRC=<claude-p10b>/src P112_P9_SRC=<p9>/src P11_P10B_SRC=<claude-p10b>/src P11_P9_SRC=<p9>/src P10_P9_SRC=<p9>/src node --test tests/*.test.js
python -m pytest -q ai-test-backend/test_food_photo_adapter.py
NODE_PATH=<dir with @playwright/test 1.49.1>/node_modules HYROX_CHROME=<Chrome> npx playwright test -c tests/playwright.local-chrome.config.js
```
Rebuild from Grok's 11.2 source: extract it, then run `git apply claude-p11-2-review-vs-grok-p11-2.patch` inside it.
