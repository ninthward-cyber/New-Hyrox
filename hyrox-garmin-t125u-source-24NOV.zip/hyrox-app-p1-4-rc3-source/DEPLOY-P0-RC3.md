# P0-RC3: deploy and rollback (owner only, after the owner's explicit go-ahead)

**This package is not deploy approval and not approval of Block 2 training content.** Nobody but the owner deploys.
- Site: `hyrox-phase7-private-test` (ID `99f0deb7-0526-46f6-b432-9c3bfc2c86d2`). Same origin as today, so the saved data stays.
- Zip: `hyrox-app-p0-rc3-deploy.zip`; its SHA256, every file's SHA256 and the **source id** are in `SHA256SUMS-p0-rc3.txt`.
- No env change, no migration, data version 2. 16 static app files. Only `index.html`, `src/ui/app.js`, `src/ui/app-ext.js`
  and `src/ui/style.css` differ from RC2. The Block 2 activation lock (`src/data/hyrox-blocks.js`) is byte-identical to RC2.
- **Timing:** the Block 2 benchmark is 11 Dec and the first start is Mon 14 Dec. Avoid deploying in that week; deploy well
  before it or after the 14th.

## A. Read-only: confirm what is live now
The live build is NOT known to the reviewer. Netlify → site → Deploys → Published deploy → file browser sizes:
| `src/ui/app-ext.js` | `src/ui/style.css` | Live build |
|---|---|---|
| 303150 | 42154 | RC2 |
| 302942 | 42154 | RC1 |
| 258287 | 41683 | Claude P11.2 |
| 223896 | 39561 | Claude P11 |
| anything else | | stop and report the sizes (P10b or older) |
Write down the published deploy ID: it is the fastest rollback target. From P0-RC3 onward the app names itself:
Settings → About this build.

## B. Backup first (mandatory)
iPhone → the **Home Screen icon** (same origin as your data, not a Safari tab) → Settings → **Export JSON backup**. Keep the
file, and check it is in Files. (On P0-RC3 the app will afterwards show when a download was last started; it cannot see
whether the file was kept.)

## C. Deploy
```powershell
cd $HOME\Downloads
Get-FileHash .\hyrox-app-p0-rc3-deploy.zip -Algorithm SHA256   # must equal its line in SHA256SUMS-p0-rc3.txt, otherwise STOP
Expand-Archive .\hyrox-app-p0-rc3-deploy.zip -DestinationPath .\hyrox-p0-rc3 -Force
cd .\hyrox-p0-rc3\hyrox-p0-rc3-deploy
npm ci
npx netlify-cli login
npx netlify-cli sites:list --json | ConvertFrom-Json | Where-Object { $_.id -eq '99f0deb7-0526-46f6-b432-9c3bfc2c86d2' } | Select-Object name, url, id
# must show hyrox-phase7-private-test, otherwise STOP
npx netlify-cli deploy --site 99f0deb7-0526-46f6-b432-9c3bfc2c86d2 --dir publish --functions netlify/functions --message "P0-RC3 draft"
```
Draft URL (new Safari tab, not the icon): quick look only, then clear that tab's website data. Then production:
`npx netlify-cli deploy --prod --site 99f0deb7-0526-46f6-b432-9c3bfc2c86d2 --dir publish --functions netlify/functions --message "P0-RC3"`.

## D. Smoke test on the Home Screen icon (real iPhone; all browser tests ran in Chrome emulation, not Safari)
1. **Build label:** Settings → About this build shows `Build P0-RC3 · source <id> · built Sun, 22 Nov 2026`. The id must equal
   the "source id" line in `SHA256SUMS-p0-rc3.txt`. If it says "Development copy", the wrong files were published: stop.
2. **Home:** one Nutrition row with the day's status, **Log meal** and **Photo meal**. No Meals / Breakfast / Lunch list on
   Today. Steps, Exercise, Weight, readiness and the plan are where they were. Compare with your screenshot IMG_3543.
3. **Old meals:** Log meal → the diary. Step back a few days with ‹. Earlier meals, their names and categories are as before;
   meals without a category are under "Uncategorized / Earlier meals".
4. **Log lunch:** Log meal → Lunch "+ Log" → no "Meal name" box → add a food → Confirm. You land on the diary, Lunch open,
   the meal shown once. Today's Nutrition row shows the new total once.
5. **Photo meal** from Today → photo logger opens directly; the "Diary meal" row offers the four meals and Uncategorized.
   Selecting photos sends nothing. (Only analyse a photo if you intend the paid call.)
6. **Backdated:** diary ‹ to yesterday → Dinner "+ Log" → Confirm → still on yesterday's diary; History lists it under yesterday.
7. **Custom name:** open an older meal that has a name → "Edit details: custom name" is open with the name; Back without saving.
8. **Unfinished entry:** start typing a meal, go to Today, tap Log meal → the half-typed meal is still under the diary. Tap
   "+ Log" on another meal → you are asked Keep / Discard. Choose Keep.
9. **Backup note:** Settings → Backup shows "Last backup file prepared on this device: …" (or "no record (unknown)" before
   the first export on this build). Export → the line updates and says the app cannot check the file was kept.
10. **Restore preview** (optional): Settings → Restore → pick the backup from step B → the preview appears as before. Cancel.
11. Close the app from the app switcher, reopen from the icon: meals, diary and totals are unchanged.
12. Larger Text and VoiceOver, if you use them: the diary heading is announced after Log meal; buttons are reachable.

## E. Rollback (no env change, no migration)
Export a backup first. Fastest: Netlify → Deploys → the deploy ID you wrote down in A → Publish deploy. From a zip (check the
hash; same `npm ci` + `deploy --prod` as in C):
| Order | Target | SHA256 |
|---|---|---|
| 1 | RC2 `hyrox-app-rc2-deploy.zip` | `3662afd4c1a059a9a2935d6152d6620c44bf23c38cb4032a1361a3ee1d5153cb` |
| 2 | RC1 `hyrox-app-rc1-deploy.zip` | `129583156454de49c3acbf5e2a4d7bae08124ac1862c982f6c6e7b646f409d7c` |
| 3 | Claude P11.2 `hyrox-app-phase11-2-deploy-claude.zip` | `c85d82479e02a6e20a585ac9b9a9418b4ba736792cc98136e011f403b1b85e61` |
| 4 | Claude P11 `hyrox-app-phase11-deploy-claude.zip` | `b8275adb58a5f435983be4b7752714c45e13ed04ed12c18ae37a5406fe458b82` |
| 5 | P10b `hyrox-app-phase10b-deploy-claude.zip` | `da206f891229ae43b73a04722d2a2a37f2ca92aba7df31accbf19c2016e8cf72` |
P0-RC3 writes no new record shape: meals, settings and backups are exactly what RC2 writes. Its one new storage key,
`hyrox.backup-note`, is outside the saved records; older builds never read it and it is not in any backup. After a rollback
the diary is on Today again and the Meal name box returns. The older-build cautions in DEPLOY-RC2.md section E still apply
(do not edit skipped Block 2 workouts or use "Replace the saved settings" on P11.2 or older).
