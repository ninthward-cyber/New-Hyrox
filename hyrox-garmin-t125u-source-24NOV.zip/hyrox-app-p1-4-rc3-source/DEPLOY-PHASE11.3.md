# Phase 11.3: owner checks, deploy and rollback (Windows PowerShell + iPhone)

**This package does not approve a deploy.** Deploy only after Claude's review and the owner's explicit go-ahead. Only the owner runs these steps, with his own logins.

**Site:** `hyrox-phase7-private-test`, ID `99f0deb7-0526-46f6-b432-9c3bfc2c86d2`. This is the same site with the same Home Screen icon. The Phase 5 site is out of scope.

**No env change.** No variable, secret, key, model, price or cap changes. **No migration:** the data version stays 2.

There are 2 new static files, so the app now has 15 files instead of 13:
- `src/data/food-db-us.js` (1.25 MB raw, about 193 KB gzip)
- `src/data/hyrox-fibersodium.js`

> Never paste any of these into a chat: your OpenAI key, your owner code, any `Authorization` header, photos, or what you ate.

## A. Read-only: confirm what is live now
Open Netlify → Deploys → Published deploy → file browser, and compare the sizes:

| `src/ui/app-ext.js` | `src/ui/style.css` | Live build |
|---|---|---|
| 258287 | 41683 | **Claude P11.2** (`c85d8247…`) |
| 223896 | 39561 | Claude P11 (`b8275adb…`) |
| 265808 | 42154 | Phase 11.3 (this package) |
| anything else | | stop and report the sizes |

Note the published deploy ID: it is the one-click rollback target.

## B. Back up first (mandatory)
On the iPhone, open the Home Screen icon → Settings → **Export**, and keep the file.

## C. Deploy
```powershell
cd $HOME\Downloads
Get-FileHash .\hyrox-app-phase11-3-deploy.zip -Algorithm SHA256   # must equal its line in SHA256SUMS-phase11-3.txt
Expand-Archive .\hyrox-app-phase11-3-deploy.zip -DestinationPath .\hyrox-p11-3-deploy -Force
cd .\hyrox-p11-3-deploy\hyrox-phase11-3-deploy
npm ci
npx netlify-cli login
npx netlify-cli sites:list --json | ConvertFrom-Json | Where-Object { $_.id -eq '99f0deb7-0526-46f6-b432-9c3bfc2c86d2' } | Select-Object name, url, id
# must show hyrox-phase7-private-test, otherwise STOP
npx netlify-cli deploy --site 99f0deb7-0526-46f6-b432-9c3bfc2c86d2 --dir publish --functions netlify/functions --message "Phase 11.3 draft"
```
1. **Draft check.** Open the draft URL in a new Safari tab, not the Home Screen icon.
   - Today → Lunch "+ Log" → Add foods.
   - The status shows "13,598 foods".
   - Search `4 boiled eggs` and pick "Egg, whole, boiled or poached". The quantity is 1 until you change it. Set it to 4: 286 kcal, then Add → Meal → Confirm.
   - The diary shows "Fiber: 0 g so far" and "Sodium: 258 mg so far".
   - Clear that tab's website data afterwards.
2. **Production:** run the same command with `--prod --message "Phase 11.3"`. Then close and reopen the icon and check that all your data is still there.

## D. Owner device QA (real iPhone Safari; all e2e tests ran in Chrome emulation, not Safari)
1. Search `4 boiled eggs`, `1 can tuna` and `chicken breast 200g`. Each should show sensible results. You always choose the quantity and serving yourself.
2. Search `big mac`. The first row is "Big Mac (McDonalds)", labelled "Chain item · USDA survey estimate (US)", and its default serving is 205 g. The details say it is not the official figure. Search `chicken nuggets` and check that some rows are labelled "Restaurant-style · generic USDA".
3. In airplane mode, search again after Add foods has loaded once. It should still work.
4. Log an item with no fiber typed. Fiber should read "known subtotal — incomplete" or "unknown", never 0. A manual item with an unknown kcal stays unknown.
5. In History → All food & drink entered, with every item having a value, the day line reads "complete day total".
6. Type a chain's official value manually, confirm it, then use Save to My foods. In Settings, use Export and then the Restore preview. My foods, including sodium, should still be there.
7. Turn on Larger Text: the Fiber & sodium fold is not clipped, and tapping its inputs does not zoom the page.

## E. Rollback (no env change, no migration; Blobs budget counters kept)
**Fastest:** Netlify → Deploys → the deploy that was published before this one (from A) → **Publish deploy**.

From a zip, check the hash first, then run the same `npm ci` + `deploy --prod` as in C. Try in this order:

| Order | Target | SHA256 |
|---|---|---|
| 1 | Claude P11.2 `hyrox-app-phase11-2-deploy-claude.zip` | `c85d82479e02a6e20a585ac9b9a9418b4ba736792cc98136e011f403b1b85e61` |
| 2 | Claude P11 `hyrox-app-phase11-deploy…` | `b8275adb58a5f435983be4b7752714c45e13ed04ed12c18ae37a5406fe458b82` |
| 3 | P10b `hyrox-app-phase10b-deploy…` | `da206f891229ae43b73a04722d2a2a37f2ca92aba7df31accbf19c2016e8cf72` |

**After a rollback:**
- `fiberG` and `sodiumMg` stay inside meals and saved foods. The older builds ignore them but keep them through edits and exports (Chrome e2e on Claude P11.2, P11 and P10b), and they show again when you redeploy 11.3.
- **Known risk:** if you change an item's kcal in an older build, its USDA note is removed but its old fiber/sodium stays, still marked as an estimate. Re-check those items after you redeploy 11.3.
- On older builds, "Replace the saved settings" for a damaged settings record keeps only saved foods and favourites. This is the same as Claude P11.2.
