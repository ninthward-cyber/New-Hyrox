# Phase 11 (Grok): meal diary + compact accessible typography (P0 only)

**Built on:** Claude P10b source `34bdf3d` (`claude-p10b-source.zip`, sha256 e94fd8bd…, zip comment = commit 34bdf3dfed24…). Its build equals the reviewed deploy `da206f89…cf72` (verified; only 3 docs differ). Local branch `p11/integration` on `p11/baseline` (tag `claude-p10b-34bdf3d`).

**Changed:** `src/ui/app-ext.js`, `src/ui/style.css`, one build-script label. **New:** `tests/e2e/p11-meal-diary.spec.js` (13 tests × 390/320 px), `tests/p11-meal-category.test.js` (6 tests), `tools/p11-screens.cjs` (screenshot driver).
- **No** change to `src/data/*` (byte-identical, enforced by a test), server/function, provider, pricing, caps, env, backup format.
- No earlier assertion edited or weakened. No live/paid OpenAI call; `test_food_photo_api_live.py` not run. Nothing deployed, pushed or merged. Synthetic data only.
- P1 **not started** (P0 is stable, but P1 was left for a separate review cycle).

## 1. Live deploy check (read-only Netlify reader tools, 19 Nov 2026, Asia/Qatar)
| Item | Finding | Status |
|---|---|---|
| Published deploy | `6afe8c4ea9bec4f7b197d344`, "Build from drop deployment", production, published **19 Nov 08:42:50 Qatar** | Confirmed |
| Change vs previous deploy | Netlify summary: "2 new files uploaded / 2 assets changed". Claude P10 → Claude P10b changes exactly 2 files (`app-ext.js`, `style.css`); Grok P10b would be 1, Grok P10 → Claude P10b 3 | **Consistent, not proof** |
| Function | `food-photo` same digest (beafdf9b…) and size (379369) as the 18 Nov deploy → server unchanged, as expected (P10b had no server change) | Confirmed unchanged |
| Exact bytes of live app files | Site behind team SSO; not readable by the reader tools | **Unconfirmed** — owner check in DEPLOY-PHASE11 §A |
| Secret scan on the deploy | 0 matches (2898 files) | Confirmed |
| Analyze calls 18 Nov 20:00 → 19 Nov ~09:13 Qatar | **0** analyze, 0 status requests (control query reproduced the known 18 Nov 19:46 Qatar `analyze_ok`, so the filter works) | Confirmed: no spend in the window |
| Owner P10b smoke test | No server trace (meal saves are local) | **Pending — owner only** |

## 2. Schema decision
- Inspected first: meals have `id, date, time, label, source, description, eatenFraction, components, ai, lifecycle, confirmedAt` — **no category**. `putRecord`/export/restore keep unknown fields by design.
- Added **one optional field** `mealCategory` ∈ `BREAKFAST | LUNCH | DINNER | SNACKS`, written only when the owner picks a category. **No data-layer code change, no migration, no rewrite of any stored record.**
- Missing field → listed under **"Uncategorized / Earlier meals"** for that day. An unrecognised value (e.g. from a hand-edited backup) is kept exactly and listed there with a note; History shows "Unrecognised category".
- **Never assigned from time or label** — an old meal named "Lunch" stays uncategorized.
- Categories only group: totals come from the same confirmed-only `dayState`, tested with and without categories.
- Rollback: Claude P10b, P9, P8 and P7 data layers restore a Phase 11 backup with `mealCategory` intact and export it again (unit test). Editing a meal in an older UI copies the whole record, so the field survives.

## 3. What shipped (P0)
**Today → "Meals" diary card** (after the alerts, before "Why?")
- Asia/Qatar date navigation: ‹ / › (› disabled at today), "Today" button; a past day shows a "not today" badge.
- Day line: "Nothing confirmed for this day — calories unknown, not 0." / "N kcal confirmed so far — not a full day." / "— complete day." (only when the day is marked complete). Macros use the existing qualified values (`+?`).
- Breakfast / Lunch / Dinner / Snacks: subtotal + entry count, or "Not logged"; "n not confirmed (not counted)" when drafts exist. Uncategorized / Earlier meals row only when such meals exist.
- Rows expand (aria-expanded) to show entries with Edit / Review (legacy nutrition entries are read-only). "View diary" expands all.
**Dedicated logger** ("+ Log" on a row)
- Full-screen Add subview: sticky header "‹ Back" + "Log lunch" + date ("Thu 19 Nov · today" or a "not today" badge). App header and Add mode tabs hidden; bottom tabs kept.
- Category chips (pre-selected, changeable), then the existing paths: Photo + description (1–3 photos) / Description only / Manual / Reuse. Same single description field, one review, one explicit save; all warnings, portion/eaten-fraction, consent and privacy logic unchanged.
- Save → back to the same day's diary, category open, record shown exactly once. Next Log = fresh draft in the last-used input path (edits don't change the preference). No stale photos/estimate/consent/request id. Adding to a category makes another record; Edit loads only that record ("Edit lunch").
- Back/Cancel with unsaved input (incl. unanalysed photos) → in-app Keep/Discard dialog; untouched Back just closes. Choosing a category alone is not "unsaved work".
- P10b guards kept: failed save keeps everything for retry; late AI answers for a discarded draft are ignored; double tap saves once.
**Midnight (Asia/Qatar)**: untouched "today" logger follows the new day; dirty draft keeps its date with the P10b notice; a deliberately opened past day is never redated; the diary returns to the new today unless a past day was chosen; copy keeps items and the logger's date/category.
**Existing paths**: Today "Log meal"/"Photo meal" open the logger (no category preset). Add → Meal is the same form with explicit category chips (none preset) and still returns to History. Today/Add/History/Trends/Settings routes, training/weight/steps unchanged. History rows show a category badge.
**Typography (compact, accessible)**: body 15px, secondary 12–13px, section headings 18px, logger title 22px; inputs 16px (no iOS zoom); buttons/chips/segments ≥44px; visible `:focus-visible`; card padding 14px; no zoom disabling (viewport unchanged). No restyle of colours or navigation.

## 4. Discrepancy found in the baseline
- **Claude P10b Keep/Discard dialog was unreadable** (`.choice-box` used `var(--surface,#fff)` — undefined, so a white box with inherited light text). Fixed to the card colours; an e2e test now checks its contrast. Owner should confirm on device.

## 5. Tests (this box; e2e is **Chrome emulation, not Safari**)
| Suite | Baseline 34bdf3d | Phase 11 |
|---|---|---|
| node unit | 1395 pass / 0 skip | **1401 pass / 0 fail / 0 skip** (+6) |
| pytest adapter (stub) | 8 pass | **8 pass** |
| Chrome e2e | 293 pass / 1 skip | **319 pass / 1 skip / 0 fail** (+26 = 13 × 2 widths) |
| netlify dev offline verify | — | **pass** (exit 0, stub provider) |
New e2e cover: category/date selection, duplicate prevention, multiple records per category, editing one record, Back/Keep/Discard (text and unanalysed photos), path preference, 1/2/3 photos = one consented request each, late response, failed save + retry, Qatar midnight, deliberate past day, older uncategorized backup, unknown category kept, export/restore with qualified totals and no duplicates, previous direct Add path, no zoom-disable / ≥16px inputs / ≥44px taps / no horizontal overflow at 320 & 390, dialog contrast.

## 6. Owner decisions needed
1. Require a category on the direct **Add → Meal** path? (Now optional → Uncategorized.)
2. After a direct Add save: keep going to **History** (as P10b) or go to the diary?
3. "View diary" = expand-all on Today (no separate screen). OK?
4. Bottom tab bar stays visible in the logger. OK?
5. Accept the dialog contrast fix.
6. Add strict data-layer validation of `mealCategory` later? (Now none, deliberately, so rollback stays lenient.)
7. Start P1 (habits summary, Trends simplification, text-only draft recovery, remaining native confirms) after this is reviewed?
