# Sprint B: P1.2 local draft recovery

Grok sprint integrator, 23 Nov 2026. Sprint B is a separate, revertible commit on top of the Sprint A fix (229a4b5). Synthetic data only. All browser evidence is Chrome emulation, not Safari.

## Contract used
- **Handover (CC Combined Value Sprint, Priority B):**
  - Recover unfinished meal and workout drafts after a reload or interruption.
  - Never treat a draft as confirmed, consumed or completed. Never change day totals, and never silently replace a saved record.
  - Use a same-origin, bounded local store with conflict resolution, explicit Resume/Discard, date and revision awareness (Asia/Qatar), and clearing on a successful save.
  - Store no photo bytes, credentials or raw photos.
  - "If implementation contracts require a new storage key/migration, HOLD and report exact alternatives instead of silently changing v2."
- **CC decision log (P10b/P11 entries):**
  - Draft recovery must preserve privacy, never save photo bytes or consent, and never silently confirm a meal.
  - Clearing happens only after a successful confirmed save.
- There is no separate written P1.2 specification in the CC decision log or the Claude RC3 handoff. These two sources are the whole contract.

## What exists already (RC3)
- An unsaved **workout** is already kept across a reload in the UI-only key `hyrox.ui.workout-draft`.
  - It is outside `hyrox.v1`, outside backups and outside the data version.
  - The allowlist tests already accept this key.
- An unsaved **meal** is held in memory only. A reload loses it, but the app warns before it abandons a dirty meal.

## Done: workout drafts (existing key, no new key, no migration)
- **Format:** same key and same `{savedAt, ws}` envelope, plus two optional fields:
  - `day`: the Qatar date the draft was started.
  - `draftId`: random; used to notice a save made in another tab.
  - Older builds ignore both fields. A rollback test on 4 older builds passes.
- **Explicit Resume and two-step Discard** on Today: "Discard…" → "Yes, discard it" / "Keep it". Saved workouts are never touched.
- **Midnight:** a draft started on an earlier Qatar day says so. Its workout date is never moved to today automatically.
- **Invalid partial draft** (junk shape, unreadable JSON, or larger than 200,000 characters):
  - The app opens normally and nothing is restored.
  - Today says the draft could not be read and offers Discard.
  - Oversized drafts are never written.
- **Revision awareness:** before an edit replaces a stored workout, the app checks whether that workout has changed (another tab or a restore) or has gone (restore or rollback).
  - Save is refused until the owner chooses "Keep my version (replace it)" / "Save it again", or "Load the saved version".
  - Either way there is still exactly one record.
- **Two tabs (duplicate prevention):**
  - If another tab saves or discards the same new workout, this tab shows a warning and refuses Save.
  - The owner then chooses "Discard this copy" or "Keep it as a separate workout".
  - The draft is not re-created behind the other tab.
- **Unchanged:**
  - The draft is cleared only after a successful save (or an explicit Discard / Clear form).
  - It never enters `hyrox.v1` or the backup file, and it never counts as done.

## HELD: meal-draft persistence (needs a new storage key)
Persisting an unsaved meal across a reload needs storage. The only existing places are `hyrox.v1` (records and backups) and `hyrox.ui.workout-draft` (workout only). Per the handover, this is HELD. Exact alternatives, for the CC or owner to choose:

| # | Option | Storage change | Rollback | Risk |
|---|---|---|---|---|
| M1 (recommended) | New UI-only key `hyrox.ui.meal-draft` with the same rules as the workout draft: bounded; text and numbers only, with **no photo bytes, no consent flags, no AI owner code**; date and revision aware; explicit Resume/Discard. | One new key outside `hyrox.v1` and outside backups. No data-version change, no migration. The two allowlist tests must add the key. | Older builds ignore the key. A stale key stays harmless until cleared. | Lowest. |
| M2 | Store the meal draft inside the existing `hyrox.ui.workout-draft` envelope (e.g. `meal: {...}`). | No new key, but the key is used for a second purpose. | **An older build's workout save or Clear form deletes the whole key, so a meal draft can be lost silently after a rollback.** | Medium; not recommended. |
| M3 | Auto-save the unsaved meal as a lifecycle DRAFT meal record in `hyrox.v1`. | No new key, but records are created without a save tap. They appear in backups and in the diary as drafts. | Older builds show these drafts. | Changes data semantics; not recommended. |
| M4 | `sessionStorage`. | No persistent key. | n/a | Survives a reload in the same tab only. iOS discards it when the Home Screen app is killed, so it does not meet "app interruption". |

## Tests
- **New:** `tests/e2e/p1-2-draft-recovery.spec.js`, 13 browser tests:
  - abrupt reload, Resume, two-step Discard (390 and 320 px)
  - save clears once
  - midnight
  - 3 invalid partial drafts
  - 2 revision conflicts
  - restore/rollback removed the record
  - two-tab duplicate
  - older-format draft
  - draft not in records or backup
- **Fail-first on 229a4b5:** 10 of 13 fail. The 3 that pass are guards that must hold both before and after: save clears, older-format draft restored, not in backup.
- **Rollback:** `tests/rollback/p1-2-draft-older-build.spec.js` passes on RC3 b1de280e2a65, P1.1-RC2, Claude P11.2 96832ff and RC1 01b1e85.

## Needs a real iPhone
- A Home Screen app killed while a workout is half-entered, then reopened.
- VoiceOver on the Discard confirmation and the conflict alert.
- Two Safari tabs are rare on a phone; the two-tab case is emulation only.
