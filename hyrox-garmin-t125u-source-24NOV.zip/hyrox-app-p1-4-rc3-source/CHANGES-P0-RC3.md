# P0-RC3 — Home meal surface, diary on Add > Meal, no routine Meal name, build label, backup note

Base: RC2 source `hyrox-app-rc2-source.zip` sha256 `70f751201cccfe0893494d21e25ab50f0bd68d642a8ef5cf37e198362ddddb55`
(upstream commit 6992c7f). Authorised by the owner on 22 Nov 2026 ("Let's do p0 and p1") for local implementation and
testing only. **Not deployed, not pushed.** Release and Block 2 content approval stay with the owner.

Data version stays 2. No migration, no schema change, no env/secret/key/model/price/cap change.
App files changed: `index.html`, `src/ui/app.js`, `src/ui/app-ext.js`, `src/ui/style.css`. Every other app and server file is
byte-identical to RC2 (pinned by `tests/p0-rc3.test.js` + `tests/fixtures/rc2-unchanged-pins.json`), including the data
layer, nutrition, plan, the Block 2 lock (`src/data/hyrox-blocks.js`), estimator, food data, photo AI and `netlify/`.

## What changed
1. **Today has one meal surface.** The Nutrition row (truthful status, macro grid, Log meal, Photo meal) is unchanged.
   The second "Meals" card is gone from Today.
2. **The diary lives on Add > Meal.** "Log meal" opens it: date navigation, Breakfast / Lunch / Dinner / Snacks,
   "Uncategorized / Earlier meals", edit/review, View diary, plus a "Photo meal" shortcut for the diary's date. The general
   meal form is still under it, so every earlier way of entering a meal still works. A dedicated logger, a saved meal being
   edited, or a History copy shows the form alone.
3. **After a confirmed save** the app returns to the diary of the meal's own date with its category open and the meal
   listed once. Back from a logger also returns to the diary.
4. **Unfinished entries are never dropped by "Log meal".** It shows the diary with the unfinished entry still under it. The
   Keep / Discard question comes when a new meal is started from the diary ("+ Log").
5. **No routine "Meal name".** The field is now "Edit details: custom name (optional)", closed by default. A meal that
   already has a name opens with the fold open and the name kept exactly. Nothing derived from the category is written to
   storage (new meals store `label: ""`, exactly as RC2 did when the field was left empty).
6. **Display only:** History titles a meal with no custom name by its diary meal ("Lunch"); meals with no category and no
   name show "Meal" as before. No category is inferred for any stored meal.
7. **Explicit "Uncategorized"** in the category picker. It stores no `mealCategory` (what an unfiled meal always had).
8. **Settings > About this build:** release, 12-character source id, build date. The source tree says "Development copy";
   `tools/build-deploy-package.mjs` stamps the packaged `index.html` with the first 12 hex digits of the SHA-256 over the
   16 app files as they are in the source. The label never claims to be the newest or the live build.
9. **Quiet backup note.** New storage key `hyrox.backup-note` (outside `hyrox.v1` and outside every backup) records when a
   normal backup download was last started on this device. Settings shows it, or "no record (unknown)". Today shows one
   muted line only when records exist and no download was started in the last 7 days. The wording never says a backup was
   saved, uploaded or verified. Export and restore behave exactly as in RC2; the export file is unchanged.

## Tests
- New, fail-first on RC2: `tests/e2e/p0-rc3.spec.js` (9 tests × 390/320 px = 18; all 18 fail on RC2) and
  `tests/p0-rc3.test.js` (5 unit tests; the build-label and README ones fail on RC2, the byte-pin and rebuild ones guard).
- Re-pointed, none removed: diary navigation, post-save landing and meal-name typing in 15 existing specs now go through
  Add > Meal and the optional name fold (helpers `diary(page)` and `nameField(page)`). Two draft-protection tests in
  `p10b-meal-reset.spec.js` now also assert that "Log meal" does not ask or drop anything, and that "+ Log" does ask.
- `tests/rc1-no-override.test.js`: `hyrox.backup-note` added to the known storage keys, with the reason in the file.
- Results: see `CLAUDE-QA-REPORT-P0-RC3.md` next to the ZIPs.

## Not changed
Nutrition calculations, day states, unknown-vs-zero, provenance, eaten fractions, photo consent / caps / reset, late-reply
and midnight guards, backup format, restore, My foods and favourites, plan blocks and the Block 2 date lock.
