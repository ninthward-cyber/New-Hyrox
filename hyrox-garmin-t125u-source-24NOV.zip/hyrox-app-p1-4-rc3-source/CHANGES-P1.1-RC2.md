# P1.1-RC2 — F-1 fix: a typed quantity in Add foods is never silently stored as 1x

Base: P1.1-RC1, local commit `980add45831935866f8f6dbdac15a09cc3f24e9c`, build source id `6c43fa133f2b`, source ZIP sha256
`7ffb1bc1064d6a823f04a6a3c109c93fce4b44c8237049e58bbfe962de505101`. Authorised by the owner on 22 Nov 2026 (Execution
Addendum, item 1: narrow fix). **Not deployed, not pushed.** Data version 2, no migration, no storage or schema change.
App file changed: `src/ui/app-ext.js` (Add foods screen only) and the release label in `index.html`. Nothing else.

## Root cause (confirmed by a deterministic reproduction, not inferred)
The search box redraws the result list 120 ms after the last keystroke. That pending redraw was **not cancelled when a
result was picked**. If the owner typed, tapped a result and tapped Quantity before the 120 ms ran out (or the phone was
busy and the timer ran late), the redraw rebuilt the open detail. The quantity field with the cursor in it was replaced by
a new, unfocused field showing 1; the digits typed next went nowhere; Add to meal stored 1x. Nothing was shown as wrong
except the field itself reading 1. A second, visible variant: the redraw landing between finger-down and finger-up on a
result swallowed the tap (nothing opened, nothing stored).
The bug is in RC2, P0-RC3 and P1.1-RC1 alike.

## Fix
1. Every explicit action on the Add foods screen (pick a result, switch tab, Add, Favorite, open, leave) cancels the
   pending typing redraw. The typing redraw also refuses to run while a detail is open.
2. The typing redraw waits while a finger is down on the result list (a press older than 1.5 s is ignored, so the search
   can never get stuck).
3. Add to meal computes the item from what the Quantity field shows at that moment.
No default was changed: a newly opened result still starts at a visible 1; an empty or zero quantity is still refused with
a message and nothing is added.

## Evidence
- `tests/e2e/f1-food-quantity.spec.js`: 8 scenarios x 2 widths. The 120 ms timer is held and released at an exact point.
  On P1.1-RC1 (980add4): 10 of 16 fail (5 scenarios x 2 widths). On this build: 16 of 16 pass.
- The previously flaky test, 100 runs with 6 parallel workers: P1.1-RC1 97 pass / 3 fail (2 x stored 1x, 1 x swallowed
  tap); this build 100 pass / 0 fail.
- Asserted: typed quantity survives pick-while-redraw-pending, serving change, Favorite toggle (redraw), leaving and
  reopening Add foods, and Confirm; stored portion, kcal, grams and macros equal the reviewed values.

## Limits
- Chrome mobile emulation only. Not Safari, not a physical iPhone.
- One behaviour to know: if you type, then tap a result before the list has caught up with the last letters, the list
  stays as you saw it until your next action.
