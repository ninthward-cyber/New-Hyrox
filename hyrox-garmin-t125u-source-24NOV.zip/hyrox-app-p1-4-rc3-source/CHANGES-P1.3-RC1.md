# P1.3-RC1 — Home nutrition closeout and Nutrition Coach (local release candidate)

Base: P1.1-RC2, final commit `6829b05b11d27844c36bb818bcbdaad36d5311f6` (imported here as `fa84951`), build source id
`3079cb300d1f`, deploy ZIP sha256 `56f7a2c12c998d0c48ce9632764cf77454bd89e56ffab6f5f3411d60ccb2e143`.
Implemented from the Command Center P1.3 Execution Order (23 Nov 2026). **Not deployed, not pushed.** Data version 2, no
migration, no new storage key. The release name and source id of this build are in `SHA256SUMS-p1-3-rc1.txt`.
Independently reviewable commits: `940952f` (A), `5d464c2` (B), `592c3de` (C), `9087414` (D), then QA aids and packaging.

## A. Home nutrition closeout (`940952f`)
- "All food & drink entered" and "Day is incomplete" for **today** (Asia/Qatar date) sit directly under the compact Nutrition
  section on Home. History keeps per-date access and Clear. One shared component; no duplicate controls on Home.
- Each press re-reads storage and refuses, writing nothing, if: midnight passed since the screen was drawn; the meals changed
  since it was drawn (another tab); the declaration is damaged; a meal is still pending (complete); the day has only water
  (complete → the fasting question instead); the same declaration is already current. A failed save says "Not saved".
- Nothing is declared automatically. Day states, totals and the data layer are untouched.

## B. Settings > Nutrition Coach: profile, goals, confirmed targets (`5d464c2`)
- New file `src/data/hyrox-coach.js` (no network, no storage of its own). The coach is one optional field
  `nutritionCoach` in the existing settings record; it is **off until you turn it on**.
- Profile: height (cm, or ft + in stored as cm), age in whole years (no birth date; asked to confirm yearly, never advanced
  automatically), sex only for the equation, activity in plain words. Goal: lose about 1 lb a week (recommended), lose about
  2 lb a week (always gated; never computed), maintain, gain about 1 lb a week.
- Your own target: arithmetic is checked (macros can never exceed calories), warnings are shown, then a confirm screen with
  effective date (today to +14 days). **Cancel writes nothing.** Each confirmation keeps origin, inputs, reason, the values it
  replaced and a capped history. Until a target is confirmed (and while the coach is off) the provisional reference
  2,400 kcal / protein 190 g (protein floor 170 g) stays in force exactly as before. [Corrected 23 Nov 2026 by the independent
  review (C1): this line labelled the 170 g figure as carbohydrate. 170 g is the provisional PROTEIN floor; the reference has no carbohydrate figure.
  The code was always right.]
- Writes keep every other settings field, check a stamp (two tabs cannot overwrite each other) and are read back.
- Restore preview adds one line when a backup would replace or remove the coach. A damaged coach field can be reset alone.

## C. Starting estimate, personal estimate and guarded proposals (`592c3de`)
- **Starting estimate (approximate, not measured maintenance):** Mifflin–St Jeor resting estimate (Mifflin et al., Am J
  Clin Nutr 1990;51:241–247: 10 × kg + 6.25 × cm − 5 × age + 5 men / − 161 women) × a plain activity assumption
  (1.3 / 1.45 / 1.6 / 1.75, **provisional**). Weight = the mean of weigh-in days in the last 7 days, else the latest within
  14 days, else none (it then asks for a weight). No uncertainty band is shown; no step, workout or Garmin calories are
  added, so nothing is counted twice.
- **Personal estimate:** completed review weeks (Qatar dates; Sunday–Saturday in RC1, Monday–Sunday since P1.3-RC2, see
  CHANGES-P1.3-RC2.md). A week counts with ≥3 weigh-in days, ≥4 complete
  (D5) food days and ≥1 weekend D5 day; 3 such weeks of the last 4 are needed. Intake mean from D5 days only (fasts kept
  apart), weight trend from the same weeks (7,700 kcal per kg), estimated-food share shown. Otherwise it names exactly what
  is missing.
- **Proposal:** goal offset 500 kcal/day per lb/week; protein kept from the reference in force; fat 25 % of calories
  (rounded); carbs = the remainder rounded down. Screens (all **provisional**) only withhold or warn: floor (max of
  1,500 men / 1,200 women and the resting estimate), deficit > 30 %, rate > 1 %/week withheld (> 0.7 % warned), carbs
  < 130 g, impossible combinations. A **lower** target is held while any concern is open and until 2 qualifying weeks
  under the current target show slower loss than the goal. Nothing is applied without the confirm screen.

## D. Home status line and Trends weekly review (`9087414`)
- Coach on only. One line inside Home's Nutrition section for the **last completed week** (never today's partial day):
  red (recovery flags on ≥3 days, pain ≥5, low intake on ≥3 complete days, loss > 1.5 %/week for 2 weeks — always "no
  reduction is suggested"), amber (loss > 1 %/week for 2 weeks, fewer than half the planned sessions, comparable strength
  down 2 weeks, outside the goal band 2 weeks, low food coverage 2 weeks), gray (no goal, < 3 weigh-in days, < 3 weeks in a
  row: "one week is not a trend"), green (0.5–1.5 × goal rate; maintain ± 0.25 %/week). Icon, word and text, contrast ≥ 4.5.
- Trends > Weekly review (coach): weekly weight means vs the latest reading, waist and waist-to-height (NICE NG246
  rec. 1.9.14, information only), comparable strength sets, food coverage, Garmin intensity minutes as typed (never
  doubled), steps, planned vs completed sessions from the existing plan, recovery from the existing readiness rules,
  concerns and explicit gaps.

## Corrections to earlier notes (made here; historical files are left as delivered)
- `CHANGES-P1.1-RC2.md`, last bullet, said that after tapping a result before the list caught up
  "the list stays as you saw it until your next action". That is wrong: the pending redraw is cancelled and the list is **redrawn at the tap**
  (the typed quantity is still kept).
- `DEPLOY-P1.1-RC2.md` began "If P1.1-RC1 is live…" and its live-build table topped out at P1.1-RC1. Which build is
  actually live on the iPhone is **not confirmed**; `DEPLOY-P1.3-RC1.md` assumes nothing, adds P1.1-RC2 to the table and
  makes P1.1-RC2 the first rollback target.

## Not changed
Plan, Block 2 lock (no date override, no early activation), nutrition day states and totals, food calculation, the photo
estimator, photo AI, every netlify/ file, keys, caps and budget: byte-identical (20 pinned files). No network call added.

## Limits
- All browser testing is Chrome mobile emulation at 320 and 390 px. Not Safari, not a physical iPhone.
- Every threshold above marked provisional is an owner decision (see the owner brief).
