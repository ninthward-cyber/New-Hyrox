// Phase 11.2 before/after screenshots at 390 px (Chrome, not Safari). Synthetic data; fixed clock; no network beyond the local static server.
// Usage: NODE_PATH=<playwright node_modules> node tools/p11-2-screens.cjs <baseUrl> <outDir> <before|after>
const { chromium } = require('playwright');
const fs = require('fs');
const [base, out, phase] = process.argv.slice(2);
const T = '2026-11-19T05:00:00.000Z';
const SEED = { version: 2, workouts: [], nutrition: [],
  weight: [['2026-10-22', 81.2], ['2026-11-05', 80.4], ['2026-11-12', 80.1], ['2026-11-18', 79.6]].map((x, i) => ({ id: 'w' + i, createdAt: T, date: x[0], kg: x[1] })),
  daily: [['2026-11-16', 7200], ['2026-11-17', 8400], ['2026-11-18', 6900]].map((x) => ({ id: 'daily-' + x[0], createdAt: T, date: x[0], steps: { state: 'OBSERVED', value: x[1] } })),
  sessions: [{ id: 's1', createdAt: T, updatedAt: T, date: '2026-11-19', title: 'Aerobic HYROX', status: 'COMPLETED', modified: false, variant: 'ORIGINAL_60', planSlotId: 'v2.1-W1-THU', planVersion: 'v2.1', scheduledDate: '2026-11-19', durationMin: 55, blocks: [] }],
  walks: [{ id: 'wk1', createdAt: T, updatedAt: T, date: '2026-11-19', durationMin: 30 }] };
(async () => {
  const b = await chromium.launch({ executablePath: process.env.HYROX_CHROME || '/usr/bin/google-chrome' });
  const ctx = await b.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  const p = await ctx.newPage();
  await p.clock.setFixedTime(new Date('2026-11-19T09:00:00.000Z'));
  const tap = []; const shot = async (n) => { await p.waitForTimeout(400); await p.screenshot({ path: `${out}/${phase}-390-${n}.png` }); tap.push('  [screenshot ' + n + ']'); };
  const T_ = (id, what) => { tap.push('tap ' + id + (what ? ' — ' + what : '')); return p.getByTestId(id).click(); };
  await p.goto(base); await p.evaluate((d) => { localStorage.clear(); localStorage.setItem('hyrox.v1', JSON.stringify(d)); }, SEED); await p.reload();
  tap.push('seed synthetic data (weights 22 Oct–18 Nov, steps 16–18 Nov, one session + one walk today)');
  await p.getByTestId('today-glance').scrollIntoViewIfNeeded(); await shot('01-today-habits');
  // diary after a direct Add > Meal save
  await T_('tab-add'); await T_('add-mode-meal'); await T_('meal-path-manual');
  if (await p.getByTestId('meal-cat-lunch').count()) await T_('meal-cat-lunch');
  await p.getByTestId('meal-label').fill('Synthetic lunch'); await p.getByTestId('component-name').first().fill('rice bowl'); await p.getByTestId('component-kcal').first().fill('520');
  tap.push('type meal-label "Synthetic lunch", component "rice bowl" 520 kcal');
  await T_('meal-confirm', 'Add > Meal confirmed save');
  await shot('02-after-add-meal-save');
  await T_('tab-trends'); await shot('03-trends');
  if (phase === 'after') {
    await T_('tab-today'); await T_('diary-log-dinner'); await T_('meal-add-foods', 'opens Add foods');
    await p.getByTestId('foods-q').fill('big mac'); tap.push('type foods-q "big mac"');
    await shot('04-add-foods-results');
    await p.getByTestId('food-pick').first().click(); tap.push('tap food-pick (first result)');
    await shot('05-food-detail');
    await T_('food-add'); await p.getByTestId('foods-q').fill('fries'); tap.push('type foods-q "fries"');
    await p.getByTestId('food-result').filter({ hasText: "McDONALD'S, french fries" }).getByTestId('food-pick').click(); tap.push("tap McDONALD'S french fries");
    await T_('food-add'); await T_('foods-done', 'back to the meal');
    await shot('06-meal-with-2-foods');
    await T_('meal-confirm'); await shot('07-diary-after-food-save');
  }
  fs.writeFileSync(`${out}/${phase}-tap-path.txt`, `--- ${phase} (390px, Chrome emulation not Safari) ---\n` + tap.join('\n') + '\n');
  await b.close();
})().catch((e) => { console.error(e); process.exit(1); });
