// Phase 11.3 before/after screenshots at 390 px (Chrome emulation, not Safari). Synthetic data; fixed clock; local static server only.
// Usage: NODE_PATH=<playwright node_modules> node tools/p11-3-screens.cjs <baseUrl> <outDir> <before|after>
const { chromium } = require('playwright');
const fs = require('fs');
const [base, out, phase] = process.argv.slice(2);
const T = '2026-11-19T05:00:00.000Z', K = (v) => ({ value: v, state: 'KNOWN' });
const item = (name, kcal, x) => Object.assign({ name, role: 'MAIN', portion: '', preparation: '', eatenFraction: null, kcal: K(kcal), proteinG: K(20), carbsG: K(40), fatG: K(10) }, x || {});
const SEED = { version: 2, weight: [], workouts: [], nutrition: [],
  meals: [{ id: 'm1', createdAt: T, updatedAt: T, date: '2026-11-19', time: '08:00', label: 'Oats', source: 'MANUAL', description: '', eatenFraction: 1, lifecycle: 'CONFIRMED', confirmedAt: T, ai: null, mealCategory: 'BREAKFAST',
    components: [item('Oats with milk', 380, { fiberG: K(8), sodiumMg: K(120) }), item('Coffee', 10)] }] };
(async () => {
  fs.mkdirSync(out, { recursive: true });
  const b = await chromium.launch({ executablePath: process.env.HYROX_CHROME || '/usr/bin/google-chrome' });
  const ctx = await b.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  const p = await ctx.newPage(); const errs = []; p.on('pageerror', (e) => errs.push(e.message));
  await p.clock.setFixedTime(new Date('2026-11-19T09:00:00.000Z'));
  const log = []; const shot = async (n) => { await p.waitForTimeout(400); await p.screenshot({ path: `${out}/${phase}-390-${n}.png` }); log.push('[screenshot ' + n + ']'); };
  await p.goto(base); await p.evaluate((d) => { localStorage.clear(); localStorage.setItem('hyrox.v1', JSON.stringify(d)); }, SEED); await p.reload();
  await p.getByTestId('today-diary').scrollIntoViewIfNeeded(); await shot('01-diary-day-totals');
  await p.getByTestId('diary-log-lunch').click(); await p.getByTestId('meal-add-foods').click();
  await p.waitForFunction(() => !/Loading/.test((document.querySelector('[data-testid=foods-status]') || {}).textContent || 'Loading'));
  for (const [i, q] of [['02', '4 boiled eggs'], ['03', '1 can tuna'], ['04', 'chicken breast 200g'], ['05', 'big mac'], ['06', 'chicken nuggets']]) {
    await p.getByTestId('foods-q').fill(q); await p.waitForTimeout(700);
    const names = await p.locator('[data-testid=food-result] .food-name').allTextContents();
    log.push('search "' + q + '": ' + names.length + ' rows shown; top 3: ' + names.slice(0, 3).join(' | ') + ' | status: ' + (await p.getByTestId('foods-status').textContent()));
    await shot(i + '-search-' + q.replace(/\W+/g, '-'));
  }
  await p.getByTestId('foods-q').fill('4 boiled eggs'); await p.waitForTimeout(700);
  const fn = p.getByTestId('food-result').filter({ hasText: 'Egg, whole, boiled or poached' });
  if (await fn.count()) {
    await fn.getByTestId('food-pick').click(); await p.getByTestId('food-qty').fill('4');
    await p.getByTestId('food-more').locator('summary').click(); await shot('07-egg-detail-fiber-sodium');
    await p.getByTestId('food-add').click(); await p.getByTestId('foods-done').click();
    const ex = p.getByTestId('component-extra').first(); if (await ex.count()) { if (!(await ex.evaluate((d) => d.open))) await ex.locator('summary').click(); await ex.scrollIntoViewIfNeeded(); log.push('fold count ' + (await p.getByTestId('component-extra').count()) + ' open ' + (await ex.evaluate((d) => d.open))); }
    await shot('08-meal-form-fiber-sodium-fold');
    await p.getByTestId('meal-confirm').click(); await p.getByTestId('today-diary').scrollIntoViewIfNeeded(); await shot('09-diary-after-eggs');
  }
  fs.writeFileSync(`${out}/${phase}-390-log.txt`, log.concat(['page errors: ' + JSON.stringify(errs)]).join('\n') + '\n');
  await b.close();
})();
