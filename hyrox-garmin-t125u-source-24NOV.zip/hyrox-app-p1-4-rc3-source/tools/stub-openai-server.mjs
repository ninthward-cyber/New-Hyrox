#!/usr/bin/env node
// Local STUB of POST /v1/responses for offline verification. Never contacts OpenAI. Records only counts.
// Usage: node tools/stub-openai-server.mjs [port]   (default 9911)  Modes via header-less env STUB_MODE: ok | slow | error500 | bad
import http from 'node:http';
const port = Number(process.argv[2] || 9911);
let calls = 0, lastAuthOk = false;
const good = { items: [
  { name: 'Grilled chicken breast', role: 'MAIN', preparation: 'grilled', portion: 'about one palm', notVisible: false, kcal: 220, proteinG: 40, carbsG: 0, fatG: 5, confidence: 'MEDIUM', uncertainty: 'portion +-30%' },
  { name: 'White rice', role: 'SIDE', preparation: 'boiled', portion: 'about one cup', notVisible: false, kcal: 240, proteinG: 5, carbsG: 53, fatG: 1, confidence: 'MEDIUM', uncertainty: 'portion +-30%' },
  { name: 'Cooking oil', role: 'OIL', preparation: null, portion: null, notVisible: true, kcal: null, proteinG: null, carbsG: null, fatG: null, confidence: 'LOW', uncertainty: 'not knowable from a photo' }],
  warnings: ['STUB response: not a real analysis.'] };
http.createServer((req, res) => {
  if (req.url === '/__stats') { res.end(JSON.stringify({ calls, lastAuthOk })); return; }
  let n = 0; req.on('data', (d) => { n += d.length; }); req.on('end', () => {
    calls++; lastAuthOk = /^Bearer sk-/.test(req.headers.authorization || '');
    const mode = process.env.STUB_MODE || 'ok';
    const send = () => {
      if (mode === 'error500') { res.writeHead(500, { 'content-type': 'application/json' }); res.end('{"error":{"message":"stub failure"}}'); return; }
      res.writeHead(200, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ id: 'resp_stub', status: 'completed', output: [{ type: 'message', content: [{ type: 'output_text', text: mode === 'bad' ? 'not json' : JSON.stringify(good) }] }], usage: { input_tokens: 2700, output_tokens: 900 } }));
    };
    mode === 'slow' ? setTimeout(send, 60000) : send();
  });
}).listen(port, '127.0.0.1', () => console.log('stub openai on ' + port));
