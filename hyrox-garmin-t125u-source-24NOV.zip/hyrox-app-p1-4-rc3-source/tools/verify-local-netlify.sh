#!/usr/bin/env bash
# Verifies, WITHOUT logging in to Netlify and WITHOUT any real OpenAI call, that the deploy package bundles and runs in the
# real Netlify local runtime (netlify-cli `netlify dev --offline`) with a local stub standing in for OpenAI.
# Usage: tools/verify-local-netlify.sh <netlify-cli-bin> <work-dir> <log-file>
set -u
CLI="$1"; WORK="$2"; LOG="$3"; PORT=8899
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
export HOME="$WORK/home"; mkdir -p "$HOME"
rm -rf "$WORK/pkg"; node "$ROOT/tools/build-deploy-package.mjs" "$WORK/pkg" >/dev/null
( cd "$WORK/pkg" && npm ci --ignore-scripts >/dev/null 2>&1 )
CODE=$(node "$WORK/pkg/tools/make-owner-code.mjs" | grep -m1 'hx1-' | tr -d ' '); HASH=$(printf %s "$CODE" | node "$WORK/pkg/tools/make-owner-code.mjs" --hash)
node "$ROOT/tools/stub-openai-server.mjs" 9911 >"$WORK/stub.log" 2>&1 & STUB=$!
( cd "$WORK/pkg" && HYROX_PHOTO_ENABLED=true OPENAI_API_KEY=sk-LOCAL-STUB-NOT-A-REAL-KEY-000000 HYROX_OWNER_CODE_HASH=$HASH HYROX_OPENAI_BASE_URL=http://127.0.0.1:9911 \
  HYROX_MIN_GAP_SECONDS=0 CI=true NETLIFY_CLI_DISABLE_UPDATE_CHECK=1 exec "$CLI" dev --offline --port $PORT --no-open --telemetry-disable >"$WORK/dev.log" 2>&1 ) & DEV=$!
cleanup() { kill $DEV $STUB 2>/dev/null; pkill -f "netlify dev" 2>/dev/null; pkill -f stub-openai-server 2>/dev/null; }
trap cleanup EXIT
for i in $(seq 1 60); do grep -q "Loaded function food-photo" "$WORK/dev.log" 2>/dev/null && break; sleep 1; done
B=http://localhost:$PORT; IMG=$(base64 -w0 "$ROOT/tests/fixtures/p9-clean-square.jpg")
{
echo "# Local Netlify runtime verification ($(date -u +%FT%TZ) UTC; Asia/Qatar $(TZ=Asia/Qatar date +%FT%T) +03)"
echo "# netlify-cli: $($CLI --version 2>/dev/null)   node: $(node -v)   NO Netlify login, NO real OpenAI call (stub on 127.0.0.1:9911)"
echo "# function log line: $(grep -m1 'Loaded function' "$WORK/dev.log")"
echo; echo "## 1. static app is served from publish/"; curl -s -o /dev/null -w "GET / -> %{http_code}\n" $B/
echo; echo "## 2. status, anonymous"; curl -s -w "\nHTTP %{http_code}\n" $B/api/food-photo/status
echo; echo "## 3. status, owner code"; curl -s -w "\nHTTP %{http_code}\n" $B/api/food-photo/status -H "Authorization: Bearer $CODE" | sed "s/$CODE/<code>/"
echo; echo "## 4. analyze, unauthenticated (must be refused)"; curl -s -w "\nHTTP %{http_code}\n" -X POST $B/api/food-photo/analyze -H 'Content-Type: application/json' -H 'X-Hyrox-Consent: send-once' -d '{}'
echo; echo "## 5. analyze, fake headers only (must be refused)"; curl -s -w "\nHTTP %{http_code}\n" -X POST $B/api/food-photo/analyze -H 'Content-Type: application/json' -H 'X-Hyrox-Consent: send-once' -H "Origin: $B" -H "Referer: $B/" -H 'X-Forwarded-For: 127.0.0.1' -d '{}'
echo; echo "## 6. analyze, wrong code (must be refused)"; curl -s -w "\nHTTP %{http_code}\n" -X POST $B/api/food-photo/analyze -H 'Authorization: Bearer hx1-wrong' -H 'Content-Type: application/json' -H 'X-Hyrox-Consent: send-once' -d '{}'
echo; echo "## 7. analyze, foreign Origin with the right code (must be refused)"; curl -s -w "\nHTTP %{http_code}\n" -X POST $B/api/food-photo/analyze -H "Authorization: Bearer $CODE" -H 'Origin: https://evil.example' -H 'Content-Type: application/json' -H 'X-Hyrox-Consent: send-once' -d '{}'
echo; echo "## 8. analyze, owner code + synthetic JPEG -> schema v1 (stub provider)"
curl -s -w "\nHTTP %{http_code}\n" -X POST $B/api/food-photo/analyze -H "Authorization: Bearer $CODE" -H 'Content-Type: application/json' -H 'X-Hyrox-Consent: send-once' -d "{\"imageBase64\":\"$IMG\",\"mimeType\":\"image/jpeg\",\"description\":\"\",\"consent\":true,\"requestId\":\"local-run-0001\"}" | cut -c1-600
echo; echo "## 9. same request id again -> replay, no second provider call"; curl -s -D - -o /dev/null -X POST $B/api/food-photo/analyze -H "Authorization: Bearer $CODE" -H 'Content-Type: application/json' -H 'X-Hyrox-Consent: send-once' -d "{\"imageBase64\":\"$IMG\",\"mimeType\":\"image/jpeg\",\"description\":\"\",\"consent\":true,\"requestId\":\"local-run-0001\"}" | grep -i "^HTTP/\|x-hyrox-replay"
echo "stub provider calls so far (expect 1): $(curl -s http://127.0.0.1:9911/__stats)"
echo; echo "## 10. non-image payload -> refused before any provider call"; curl -s -w "\nHTTP %{http_code}\n" -X POST $B/api/food-photo/analyze -H "Authorization: Bearer $CODE" -H 'Content-Type: application/json' -H 'X-Hyrox-Consent: send-once' -d "{\"imageBase64\":\"$(printf 'hello this is text not an image' | base64 -w0)\",\"mimeType\":\"image/jpeg\",\"consent\":true,\"requestId\":\"local-run-0002\"}"
echo "stub provider calls (still 1): $(curl -s http://127.0.0.1:9911/__stats)"
A=$(base64 -w0 "$ROOT/tests/fixtures/p10-view-a.jpg"); Bi=$(base64 -w0 "$ROOT/tests/fixtures/p10-view-b.jpg"); C=$(base64 -w0 "$ROOT/tests/fixtures/p10-view-c.jpg")
im() { printf '{"imageBase64":"%s","mimeType":"image/jpeg","label":"%s"}' "$1" "$2"; }
post() { curl -s -w "\nHTTP %{http_code}\n" -X POST $B/api/food-photo/analyze -H "Authorization: Bearer $CODE" -H 'Content-Type: application/json' -H 'X-Hyrox-Consent: send-once' --data-binary @- | cut -c1-400; }
echo; echo "## 10a. P10: three labelled photos in ONE request -> one component list (stub provider)"
printf '{"images":[%s,%s,%s],"description":"curry","consent":true,"requestId":"local-multi-0001"}' "$(im $A BEFORE)" "$(im $Bi AFTER)" "$(im $C EXTRA_DISH)" | post
echo "stub provider calls (expect 2): $(curl -s http://127.0.0.1:9911/__stats)"
echo; echo "## 10b. P10: same ordered set + note + id again -> replay, no provider call"
printf '{"images":[%s,%s,%s],"description":"curry","consent":true,"requestId":"local-multi-0001"}' "$(im $A BEFORE)" "$(im $Bi AFTER)" "$(im $C EXTRA_DISH)" | curl -s -D - -o /dev/null -X POST $B/api/food-photo/analyze -H "Authorization: Bearer $CODE" -H 'Content-Type: application/json' -H 'X-Hyrox-Consent: send-once' --data-binary @- | grep -i "^HTTP/\|x-hyrox-replay"
echo; echo "## 10c. P10: same id, different ORDER -> refused 409 (no provider call)"
printf '{"images":[%s,%s,%s],"description":"curry","consent":true,"requestId":"local-multi-0001"}' "$(im $Bi AFTER)" "$(im $A BEFORE)" "$(im $C EXTRA_DISH)" | post
echo; echo "## 10d. P10: four photos -> refused before any provider call"
printf '{"images":[%s,%s,%s,%s],"description":"","consent":true,"requestId":"local-multi-0002"}' "$(im $A SAME_PLATE)" "$(im $Bi SAME_PLATE)" "$(im $C SAME_PLATE)" "$(im $IMG SAME_PLATE)" | post
echo; echo "## 10e. P10: the same photo twice -> refused"
printf '{"images":[%s,%s],"description":"","consent":true,"requestId":"local-multi-0003"}' "$(im $A SAME_PLATE)" "$(im $A AFTER)" | post
echo "stub provider calls (still 2): $(curl -s http://127.0.0.1:9911/__stats)"
echo; echo "## 11. usage ledger persisted in (local) Netlify Blobs"; curl -s $B/api/food-photo/status -H "Authorization: Bearer $CODE" | sed "s/$CODE/<code>/"; echo
echo; echo "## 12. the function's own log lines contain no secrets"; 
if grep -q -e "$CODE" -e "$HASH" -e "sk-LOCAL" -e "$IMG" -e "${A:0:200}" -e "${C:0:200}" -e "curry" "$WORK/dev.log"; then echo "FAIL: secret found in function log"; else echo "OK: owner code, hash, API key and image data absent from function log"; fi
echo; echo "## dev server function log (excerpt)"; grep '^{"evt"' "$WORK/dev.log" | head -20
} >"$LOG" 2>&1
cat "$LOG"
