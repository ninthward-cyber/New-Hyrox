'use strict';
// Phase 8: Today-screen screenshots at 320 and 390 px in Chrome emulation (NOT Safari/WebKit). Synthetic data only.
// Usage: HYROX_CHROME=... NODE_PATH=<node_modules with playwright> node shots.js <appRoot> <port> <ISO now> <outDir> <label>
const { chromium } = require('playwright');
const { spawn } = require('child_process');
const path = require('path');
const [root, port, nowIso, out, label] = process.argv.slice(2);
(async () => {
  const srv = spawn(process.execPath, [path.join(root, 'tests/static-server.js')], { env: Object.assign({}, process.env, { HYROX_APP_ROOT: root, HYROX_APP_PORT: port }), stdio: 'ignore' });
  await new Promise((r) => setTimeout(r, 800));
  const browser = await chromium.launch({ executablePath: process.env.HYROX_CHROME || '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  try {
    for (const w of [320, 390]) {
      const ctx = await browser.newContext({ viewport: { width: w, height: 844 }, isMobile: true, hasTouch: true, deviceScaleFactor: 2, timezoneId: 'Asia/Qatar', locale: 'en-US' });
      const page = await ctx.newPage();
      await page.clock.setFixedTime(new Date(nowIso));
      await page.goto('http://127.0.0.1:' + port + '/');
      await page.waitForSelector('[data-testid="tab-today"]');
      const today = await page.evaluate(() => {
        const HD = window.HyroxData, st = HD.createStore(), d = HD.todayQatar(), ts = new Date().toISOString();
        const k = (v) => ({ value: v, state: 'KNOWN' });
        const r1 = st.putRecord('meals', { id: 'shot-meal', createdAt: ts, date: d, time: '08:00', label: '4 boiled eggs', description: '4 boiled eggs', source: 'MANUAL', lifecycle: 'CONFIRMED', confirmedAt: ts,
          components: [{ name: 'Boiled egg', role: 'OTHER', portion: '4 eggs', preparation: '', eatenFraction: null, kcal: k(310), proteinG: k(25), carbsG: k(1.6), fatG: k(21) }] });
        const r2 = st.putRecord('walks', { id: 'shot-walk', date: d, durationMin: 60, steps: 7500 });
        return { d, r1: r1.ok, r2: r2.ok };
      });
      await page.reload();
      await page.waitForSelector('[data-testid="tab-today"]');
      await page.waitForTimeout(400);
      await page.screenshot({ path: path.join(out, label + '-today-' + w + 'px-fold.png') });
      await page.addStyleTag({ content: '.tabbar{position:static !important}' }); // full-page capture only: the fixed tab bar would overlay the middle
      await page.screenshot({ path: path.join(out, label + '-today-' + w + 'px-full.png'), fullPage: true });
      const h = await page.evaluate(() => document.documentElement.scrollHeight);
      console.log(label, w, JSON.stringify(today), 'pageHeight', h);
      await ctx.close();
    }
  } finally { await browser.close(); srv.kill(); }
})().catch((e) => { console.error(e); process.exit(1); });
