#!/usr/bin/env python3
"""Phase 8 one-off: shift ISO date literals 2026-11-DD / 2026-12-DD by +7 days in the given test files.
Used because the plan was re-anchored by +7 days (Week 1 = 16-22 Nov). Relationships between dates inside a
test are preserved; no expected value other than a date is touched. Usage: shift-test-dates.py FILE..."""
import re, sys, datetime
pat = re.compile(r'2026-(11|12)-(\d\d)')
def sh(m):
    d = datetime.date(2026, int(m.group(1)), int(m.group(2))) + datetime.timedelta(days=7)
    return d.isoformat()
for f in sys.argv[1:]:
    s = open(f, encoding='utf-8').read()
    n = len(pat.findall(s))
    open(f, 'w', encoding='utf-8').write(pat.sub(sh, s))
    print('%s: %d date literals shifted' % (f, n))
