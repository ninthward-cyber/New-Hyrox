#!/usr/bin/env python3
"""Phase 8 one-off companion of shift-test-dates.py: shifts 'Thu 12 Nov' style labels (same weekday) by +7 days in the given test files."""
import re, sys, datetime
pat = re.compile(r'\b(Mon|Tue|Wed|Thu|Fri|Sat|Sun) (\d{1,2}) (Nov|Dec)\b')
M = {'Nov': 11, 'Dec': 12}; N = {11: 'Nov', 12: 'Dec'}
def sh(m):
    d = datetime.date(2026, M[m.group(3)], int(m.group(2)))
    if d.strftime('%a') != m.group(1): return m.group(0)   # not a 2026 weekday label: leave alone
    d += datetime.timedelta(days=7)
    return '%s %d %s' % (m.group(1), d.day, N[d.month])
for f in sys.argv[1:]:
    s = open(f, encoding='utf-8').read(); n = len(pat.findall(s))
    open(f, 'w', encoding='utf-8').write(pat.sub(sh, s)); print('%s: %d labels checked' % (f, n))
