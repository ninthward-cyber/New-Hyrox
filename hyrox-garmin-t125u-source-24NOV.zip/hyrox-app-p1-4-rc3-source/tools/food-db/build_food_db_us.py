#!/usr/bin/env python3
"""Phase 11.3: build src/data/food-db-us.json and src/data/food-db-us.js (window.HyroxFoodDbUs).

Two parts, both from USDA FoodData Central bulk downloads (CC0 1.0, public domain), Python standard library only,
offline (no network; the zips must already be on disk), deterministic (running twice gives byte-identical files):

1. "foods": USDA FNDDS 2021-2023 (Food and Nutrient Database for Dietary Studies, the survey foods behind
   What We Eat in America / NHANES), FDC release 2024-10-31, dataset code "FN". Row:
     [fdcId, "FN", description, kcal, proteinG, carbsG, fatG, [[amount, "unit text", grams], ...], fiberG, sodiumMg]
   Values per 100 g (FNDDS nutrient numbers 208 kcal, 203, 205, 204, 291 fiber, 307 sodium). fiberG / sodiumMg are null
   when USDA gives no value (never 0). A food missing kcal/protein/carbohydrate/fat is excluded, never filled in.
   Portions: FNDDS portionDescription. "1 egg" -> [1, "egg", 50]. "Quantity not specified" -> [1, "serving (USDA default,
   quantity not specified)", g]. Dietary Guidelines "Guideline amount ..." rows are dropped (they are reference amounts,
   not servings). Portion order = USDA sequenceNumber.
2. "fs": fiber (g) and sodium (mg) per 100 g for the foods ALREADY in src/data/food-db.json (SR Legacy 2018-04 nutrient
   ids 1079 / 1093; Foundation 2026-10-29 numbers 291 / 307), as {"SR": [[fdcId, fiberG|null, sodiumMg|null], ...], "FF": [...]}.
   Only foods present in food-db.json and with at least one of the two values. food-db.json itself is NOT changed.

Duplicate policy: FNDDS rows are never merged with SR Legacy / Foundation rows, even when the description is identical
(different USDA analyses, different fdcIds, different data types). Both are kept and each is labelled with its source.
The count of identical descriptions is written to meta.duplicateDescriptions.

Usage:
  python3 tools/food-db/build_food_db_us.py [--src DIR] [--fndds DIR] [--db FILE] [--out DIR]
    --src    directory with the SR Legacy CSV + Foundation JSON zips (default /workspace/hyrox-p6/food-data-feasibility)
    --fndds  directory with FoodData_Central_survey_food_json_2024-10-31.zip (default /workspace/p11-3-usda)
    --db     the existing food-db.json (default <repo>/src/data/food-db.json)
    --out    output directory (default <repo>/src/data)
Get the FNDDS zip (free, no account, no key):
  curl -LO https://fdc.nal.usda.gov/fdc-datasets/FoodData_Central_survey_food_json_2024-10-31.zip
  sha256 must be dfb06ae7ddc397ccd570b91c14b75438ab2ba39f64f22d321f61d4a52a77f3eb (checked; a mismatch stops the build).
"""
import argparse
import csv
import hashlib
import io
import json
import os
import re
import sys
import zipfile

FN_ZIP = 'FoodData_Central_survey_food_json_2024-10-31.zip'
FN_SHA = 'dfb06ae7ddc397ccd570b91c14b75438ab2ba39f64f22d321f61d4a52a77f3eb'
FN_JSON = 'surveyDownload.json'
FN_URL = 'https://fdc.nal.usda.gov/fdc-datasets/' + FN_ZIP
SR_ZIP = 'FoodData_Central_sr_legacy_food_csv_2018-04.zip'
SR_DIR = 'FoodData_Central_sr_legacy_food_csv_2018-04/'
FF_ZIP = 'FoodData_Central_foundation_food_json_2026-10-29.zip'
FF_JSON = 'FoodData_Central_foundation_food_json_2026-10-29.json'
DB_VERSION = 'usda-fndds-2021-2023-fdc-2024-10-31+fs-srlegacy-2018-04-foundation-2026-10-29'
LICENSE = 'CC0 1.0 Universal (public domain)'
CITATION = 'U.S. Department of Agriculture, Agricultural Research Service. FoodData Central. fdc.nal.usda.gov.'
FN_KCAL, FN_P, FN_C, FN_F, FN_FIB, FN_NA = '208', '203', '205', '204', '291', '307'
SR_FIB, SR_NA = '1079', '1093'
FF_FIB, FF_NA = '291', '307'
DEFAULT_TEXT = 'serving (USDA default, quantity not specified)'

csv.field_size_limit(10 ** 9)


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def num(x, nd):
    if x is None:
        return None
    r = round(float(x), nd)
    return int(r) if r == int(r) else r


def clean(t):
    return ' '.join(str(t or '').split())


AMOUNT = re.compile(r'^(\d+(?:\.\d+)?|\d+/\d+|\d+ \d+/\d+)\s+(.+)$')


def parse_amount(s):
    if ' ' in s:
        w, fr = s.split(' ', 1)
        return float(w) + parse_amount(fr)
    if '/' in s:
        a, b = s.split('/')
        return float(a) / float(b)
    return float(s)


CHAIN_DISH = re.compile(r'^(.+?)\s*\(([^()]+)\)$')


def fn_portions(food, stats):
    out = []
    for q in sorted(food.get('foodPortions', []), key=lambda q: (q.get('sequenceNumber') or 0, q.get('id') or 0)):
        d = clean(q.get('portionDescription'))
        g = q.get('gramWeight')
        if not d or not (isinstance(g, (int, float)) and g > 0):
            stats['portionsDropped'] += 1
            continue
        if 'guideline amount' in d.lower():
            stats['guidelineDropped'] += 1
            continue
        m = AMOUNT.match(d)
        if m:
            amount, text = parse_amount(m.group(1)), m.group(2)
        elif d.lower() == 'quantity not specified':
            amount, text = 1, DEFAULT_TEXT
        else:
            amount, text = 1, d
        if not amount > 0:
            stats['portionsDropped'] += 1
            continue
        row = [num(amount, 4), text, num(g, 2)]
        if row not in out:
            out.append(row)
            stats['portions'] += 1
    # A chain dish ("Big Mac (McDonalds)"): USDA lists sibling sizes first ("1 MCDonald's Mac Jr"). The portion that names
    # the dish itself goes first so the default serving is the named item (stable; nothing dropped or changed).
    cm = CHAIN_DISH.match(clean(food.get('description')))
    if cm:
        dish = cm.group(1).strip().lower()
        out.sort(key=lambda r: 0 if dish in r[1].lower() else 1)
        if out and dish in out[0][1].lower():
            stats['chainPortionsReordered'] = stats.get('chainPortionsReordered', 0) + 1
    return out


def build_fndds(path, stats):
    zf = zipfile.ZipFile(path)
    j = json.loads(zf.read(FN_JSON).decode('utf-8'))
    items = sorted(j['SurveyFoods'], key=lambda f: int(f['fdcId']))
    out, excluded = [], []
    for f in items:
        m = {}
        for n in f.get('foodNutrients', []):
            k = (n.get('nutrient') or {}).get('number')
            if k in (FN_KCAL, FN_P, FN_C, FN_F, FN_FIB, FN_NA) and n.get('amount') is not None:
                m[k] = float(n['amount'])
        if None in (m.get(FN_KCAL), m.get(FN_P), m.get(FN_C), m.get(FN_F)):
            excluded.append({'fdcId': int(f['fdcId']), 'description': clean(f['description'])})
            continue
        out.append([int(f['fdcId']), 'FN', clean(f['description']), num(m[FN_KCAL], 1), num(m[FN_P], 2), num(m[FN_C], 2), num(m[FN_F], 2),
                    fn_portions(f, stats), num(m.get(FN_FIB), 2), num(m.get(FN_NA), 1)])
    pubs = sorted(set(f.get('publicationDate') for f in items))
    return out, excluded, len(items), pubs


def rows(zf, name):
    with zf.open(name) as raw:
        for r in csv.DictReader(io.TextIOWrapper(raw, encoding='utf-8', newline='')):
            yield r


def build_fs(src, existing):
    want_sr = set(str(r[0]) for r in existing if r[1] == 'SR')
    want_ff = set(r[0] for r in existing if r[1] == 'FF')
    sr = {}
    zf = zipfile.ZipFile(os.path.join(src, SR_ZIP))
    for r in rows(zf, SR_DIR + 'food_nutrient.csv'):
        if r['fdc_id'] in want_sr and r['nutrient_id'] in (SR_FIB, SR_NA) and r['amount'] != '':
            sr.setdefault(int(r['fdc_id']), {})[r['nutrient_id']] = float(r['amount'])
    ff = {}
    j = json.loads(zipfile.ZipFile(os.path.join(src, FF_ZIP)).read(FF_JSON).decode('utf-8'))
    for f in j['FoundationFoods']:
        fid = int(f['fdcId'])
        if fid not in want_ff:
            continue
        for n in f.get('foodNutrients', []):
            k = (n.get('nutrient') or {}).get('number')
            if k in (FF_FIB, FF_NA) and n.get('amount') is not None:
                ff.setdefault(fid, {})[k] = float(n['amount'])
    out = {'SR': [[i, num(sr[i].get(SR_FIB), 2), num(sr[i].get(SR_NA), 1)] for i in sorted(sr)],
           'FF': [[i, num(ff[i].get(FF_FIB), 2), num(ff[i].get(FF_NA), 1)] for i in sorted(ff)]}
    cover = {}
    for ds, lst in out.items():
        cover[ds] = {'withFiber': sum(1 for r in lst if r[1] is not None), 'withSodium': sum(1 for r in lst if r[2] is not None),
                     'foodsInDb': len(want_sr) if ds == 'SR' else len(want_ff)}
    return out, cover


def dumps(db):
    head = json.dumps(db['meta'], sort_keys=True, separators=(',', ':'), ensure_ascii=True)
    foods = ',\n'.join(json.dumps(r, separators=(',', ':'), ensure_ascii=True) for r in db['foods'])
    fs = json.dumps(db['fs'], sort_keys=True, separators=(',', ':'), ensure_ascii=True)
    return '{"meta":' + head + ',"foods":[\n' + foods + '\n],"fs":' + fs + '}'


def main(argv):
    here = os.path.dirname(os.path.abspath(__file__))
    repo = os.path.abspath(os.path.join(here, '..', '..'))
    ap = argparse.ArgumentParser(description=__doc__.split('\n')[0])
    ap.add_argument('--src', default='/workspace/hyrox-p6/food-data-feasibility')
    ap.add_argument('--fndds', default='/workspace/p11-3-usda')
    ap.add_argument('--db', default=os.path.join(repo, 'src', 'data', 'food-db.json'))
    ap.add_argument('--out', default=os.path.join(repo, 'src', 'data'))
    a = ap.parse_args(argv)
    fn_path = os.path.join(a.fndds, FN_ZIP)
    got = sha256_file(fn_path)
    if got != FN_SHA:
        sys.exit('FNDDS zip sha256 mismatch: ' + got + ' (expected ' + FN_SHA + '). Not building.')
    existing = json.load(open(a.db, encoding='utf-8'))['foods']
    stats = {'portions': 0, 'portionsDropped': 0, 'guidelineDropped': 0}
    foods, excluded, total, pubs = build_fndds(fn_path, stats)
    fs, cover = build_fs(a.src, existing)
    names = set(r[2].lower() for r in existing)
    dup = sum(1 for r in foods if r[2].lower() in names)
    meta = {
        'schema': 1, 'dbVersion': DB_VERSION, 'license': LICENSE, 'citation': CITATION,
        'sources': [
            {'dataset': 'FNDDS 2021-2023 (Survey)', 'code': 'FN', 'release': '2024-10-31', 'publicationDates': pubs, 'file': FN_ZIP, 'sha256': FN_SHA, 'url': FN_URL,
             'foodsInSource': total, 'foodCount': len(foods), 'excluded': excluded,
             'portionRows': stats['portions'], 'guidelineAmountRowsDropped': stats['guidelineDropped'], 'otherPortionRowsDropped': stats['portionsDropped'], 'chainDishNamedPortionFirst': stats.get('chainPortionsReordered', 0)},
            {'dataset': 'SR Legacy (fiber 1079, sodium 1093 only)', 'release': '2018-04', 'file': SR_ZIP, 'sha256': sha256_file(os.path.join(a.src, SR_ZIP)),
             'url': 'https://fdc.nal.usda.gov/download-datasets', 'coverage': cover['SR']},
            {'dataset': 'Foundation (fiber 291, sodium 307 only)', 'release': '2026-10-29', 'file': FF_ZIP, 'sha256': sha256_file(os.path.join(a.src, FF_ZIP)),
             'url': 'https://fdc.nal.usda.gov/download-datasets', 'coverage': cover['FF']},
        ],
        'baseDb': {'file': 'food-db.json', 'sha256': sha256_file(a.db), 'foodCount': len(existing)},
        'foodCount': len(foods),
        'fnddsWithFiber': sum(1 for r in foods if r[8] is not None), 'fnddsWithSodium': sum(1 for r in foods if r[9] is not None),
        'duplicateDescriptions': dup,
        'duplicatePolicy': 'FNDDS rows are never merged with SR Legacy / Foundation rows, even with an identical description; both are kept and labelled by source.',
        'notes': ('Values per 100 g. FNDDS foods are survey food codes (generic US foods and mixed dishes as reported in NHANES/WWEIA); '
                  'items naming a restaurant chain are USDA survey estimates, NOT the chain\'s official nutrition. fiberG/sodiumMg null = not given by USDA (unknown, never 0).'),
    }
    text = dumps({'meta': meta, 'foods': foods, 'fs': fs})
    os.makedirs(a.out, exist_ok=True)
    with open(os.path.join(a.out, 'food-db-us.json'), 'w', encoding='ascii', newline='\n') as f:
        f.write(text + '\n')
    with open(os.path.join(a.out, 'food-db-us.js'), 'w', encoding='ascii', newline='\n') as f:
        f.write('/* GENERATED by tools/food-db/build_food_db_us.py - do not edit. USDA FoodData Central (CC0): FNDDS 2021-2023 + fiber/sodium for food-db.json. Same data as food-db-us.json. */\n')
        f.write('(typeof window !== "undefined" ? window : globalThis).HyroxFoodDbUs = ' + text + ';\n')
    print('FNDDS foods %d of %d (excluded %d); fs SR %d FF %d; identical descriptions %d' % (len(foods), total, len(excluded), len(fs['SR']), len(fs['FF']), dup))


if __name__ == '__main__':
    main(sys.argv[1:])
