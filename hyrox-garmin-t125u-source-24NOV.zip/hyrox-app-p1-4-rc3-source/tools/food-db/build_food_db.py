#!/usr/bin/env python3
"""Build src/data/food-db.json and src/data/food-db.js from the USDA FoodData Central bulk files.

Python standard library only. Offline: reads the two zip files directly (no network, no unzip step).
Deterministic: no timestamps, stable sort, sorted JSON keys, ASCII-only output; running it twice gives
byte-identical files.

Usage:
  python3 tools/food-db/build_food_db.py [--src DIR] [--out DIR]
    --src  directory holding the two zips (default /workspace/hyrox-p6/food-data-feasibility)
    --out  output directory (default <repo>/src/data)

Inputs (CC0 1.0, USDA FoodData Central, https://fdc.nal.usda.gov/download-datasets):
  FoodData_Central_sr_legacy_food_csv_2018-04.zip       SR Legacy, CSV  (nutrient ids 1008/2047/2048 kcal, 1003, 1005, 1004)
  FoodData_Central_foundation_food_json_2026-10-29.zip  Foundation Foods, JSON (nutrient numbers 208/957/958 kcal, 203, 205, 204)

Output food row: [fdcId, "SR"|"FF", description, kcal, proteinG, carbsG, fatG, [[amount, "unit text", grams], ...]]
(values per 100 g). A food missing ANY of the four values is excluded and counted; nothing is ever filled in.
"""
import argparse
import csv
import hashlib
import io
import json
import os
import sys
import zipfile

SR_ZIP = 'FoodData_Central_sr_legacy_food_csv_2018-04.zip'
FF_ZIP = 'FoodData_Central_foundation_food_json_2026-10-29.zip'
SR_DIR = 'FoodData_Central_sr_legacy_food_csv_2018-04/'
FF_JSON = 'FoodData_Central_foundation_food_json_2026-10-29.json'
DB_VERSION = 'usda-srlegacy-2018-04+foundation-2026-10-29'
LICENSE = 'CC0 1.0 Universal (public domain)'
CITATION = 'U.S. Department of Agriculture, Agricultural Research Service. FoodData Central. fdc.nal.usda.gov.'
NOTES = ('Values are per 100 g of the USDA reference food. Energy is kcal (SR Legacy nutrient 1008, else Atwater 2047/2048; '
         'Foundation 208, else 957/958). Protein, carbohydrate (by difference) and total fat are grams. '
         'Portions are USDA household measures as [amount, unit text, grams]. Foods missing any of the four values are excluded, never filled. '
         'Estimates only: real dishes vary and USDA coverage of Middle-Eastern foods is patchy.')

# SR Legacy nutrient ids (kcal in priority order), Foundation nutrient numbers
SR_KCAL = ('1008', '2047', '2048')
SR_P, SR_C, SR_F = '1003', '1005', '1004'
FF_KCAL = ('208', '957', '958')
FF_P, FF_C, FF_F = '203', '205', '204'

csv.field_size_limit(10 ** 9)


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def num(x, nd):
    """Round; integral values become ints so the JSON stays compact and stable."""
    r = round(float(x), nd)
    if r == int(r):
        return int(r)
    return r


def clean(t):
    return ' '.join(str(t or '').split())


def label(unit_name, modifier, description):
    parts = []
    u = clean(unit_name)
    if u and u.lower() != 'undetermined':
        parts.append(u)
    for t in (modifier, description):
        t = clean(t)
        if t and t not in parts:
            parts.append(t)
    return ', '.join(parts)


def add_portion(lst, amount, text, grams):
    try:
        amount = float(amount)
        grams = float(grams)
    except (TypeError, ValueError):
        return
    if not (amount > 0 and grams > 0) or not text:
        return
    row = [num(amount, 4), text, num(grams, 2)]
    if row not in lst:
        lst.append(row)


def rows(zf, name):
    with zf.open(name) as raw:
        for r in csv.DictReader(io.TextIOWrapper(raw, encoding='utf-8', newline='')):
            yield r


def first_present(m, keys):
    for k in keys:
        if m.get(k) is not None:
            return m[k]
    return None


def build_sr(path):
    zf = zipfile.ZipFile(path)
    foods = {}
    for r in rows(zf, SR_DIR + 'food.csv'):
        if r['data_type'] == 'sr_legacy_food':
            foods[r['fdc_id']] = clean(r['description'])
    want = set(SR_KCAL) | {SR_P, SR_C, SR_F}
    nut = {}
    for r in rows(zf, SR_DIR + 'food_nutrient.csv'):
        if r['nutrient_id'] in want and r['fdc_id'] in foods and r['amount'] != '':
            nut.setdefault(r['fdc_id'], {})[r['nutrient_id']] = float(r['amount'])
    units = {r['id']: r['name'] for r in rows(zf, SR_DIR + 'measure_unit.csv')}
    por = {}
    for r in sorted(rows(zf, SR_DIR + 'food_portion.csv'), key=lambda r: (int(r['fdc_id']), int(r['seq_num'] or 0), int(r['id']))):
        if r['fdc_id'] in foods:
            add_portion(por.setdefault(r['fdc_id'], []), r['amount'] or 1,
                        label(units.get(r['measure_unit_id']), r['modifier'], r['portion_description']), r['gram_weight'])
    out, excluded = [], []
    for fid in sorted(foods, key=int):
        m = nut.get(fid, {})
        k = first_present(m, SR_KCAL)
        p, c, f = m.get(SR_P), m.get(SR_C), m.get(SR_F)
        if None in (k, p, c, f):
            excluded.append(int(fid))
            continue
        out.append([int(fid), 'SR', foods[fid], num(k, 1), num(p, 2), num(c, 2), num(f, 2), por.get(fid, [])])
    return out, excluded, len(foods)


def build_ff(path):
    zf = zipfile.ZipFile(path)
    j = json.loads(zf.read(FF_JSON).decode('utf-8'))
    items = sorted(j['FoundationFoods'], key=lambda f: int(f['fdcId']))
    out, excluded = [], []
    for f in items:
        m = {}
        for n in f.get('foodNutrients', []):
            num_ = (n.get('nutrient') or {}).get('number')
            if num_ in FF_KCAL + (FF_P, FF_C, FF_F) and n.get('amount') is not None:
                m[num_] = float(n['amount'])
        k = first_present(m, FF_KCAL)
        p, c, fat = m.get(FF_P), m.get(FF_C), m.get(FF_F)
        if None in (k, p, c, fat):
            excluded.append(int(f['fdcId']))
            continue
        por = []
        for q in sorted(f.get('foodPortions', []), key=lambda q: (q.get('sequenceNumber') or 0, q.get('id') or 0)):
            mu = q.get('measureUnit') or {}
            add_portion(por, q.get('amount', q.get('value')) or 1,
                        label(mu.get('name'), q.get('modifier'), q.get('portionDescription')), q.get('gramWeight'))
        out.append([int(f['fdcId']), 'FF', clean(f['description']), num(k, 1), num(p, 2), num(c, 2), num(fat, 2), por])
    return out, excluded, len(items)


def dumps_db(db):
    """Stable text: meta on one line, one food per line, ASCII only, sorted meta keys."""
    head = json.dumps(db['meta'], sort_keys=True, separators=(',', ':'), ensure_ascii=True)
    lines = [json.dumps(r, separators=(',', ':'), ensure_ascii=True) for r in db['foods']]
    return '{"meta":' + head + ',"foods":[\n' + ',\n'.join(lines) + '\n]}'


def main(argv):
    here = os.path.dirname(os.path.abspath(__file__))
    repo = os.path.abspath(os.path.join(here, '..', '..'))
    ap = argparse.ArgumentParser(description=__doc__.split('\n')[0])
    ap.add_argument('--src', default='/workspace/hyrox-p6/food-data-feasibility')
    ap.add_argument('--out', default=os.path.join(repo, 'src', 'data'))
    a = ap.parse_args(argv)
    sr_path, ff_path = os.path.join(a.src, SR_ZIP), os.path.join(a.src, FF_ZIP)
    sr, sr_ex, sr_total = build_sr(sr_path)
    ff, ff_ex, ff_total = build_ff(ff_path)
    foods = sr + ff  # SR by fdcId, then FF by fdcId (stable)
    meta = {
        'schema': 1,
        'dbVersion': DB_VERSION,
        'sources': [
            {'dataset': 'SR Legacy', 'release': '2018-04', 'file': SR_ZIP, 'sha256': sha256_file(sr_path),
             'url': 'https://fdc.nal.usda.gov/download-datasets', 'foodsInSource': sr_total, 'foodCount': len(sr), 'excludedCount': len(sr_ex)},
            {'dataset': 'Foundation', 'release': '2026-10-29', 'file': FF_ZIP, 'sha256': sha256_file(ff_path),
             'url': 'https://fdc.nal.usda.gov/download-datasets', 'foodsInSource': ff_total, 'foodCount': len(ff), 'excludedCount': len(ff_ex)},
        ],
        'license': LICENSE,
        'citation': CITATION,
        'notes': NOTES,
        'foodCount': len(foods),
        'excludedCount': len(sr_ex) + len(ff_ex),
        'excludedReason': 'missing at least one of energy, protein, carbohydrate, total fat',
    }
    db = {'meta': meta, 'foods': foods}
    text = dumps_db(db)
    os.makedirs(a.out, exist_ok=True)
    with open(os.path.join(a.out, 'food-db.json'), 'w', encoding='ascii', newline='\n') as f:
        f.write(text + '\n')
    js = ('/* GENERATED by tools/food-db/build_food_db.py - do not edit. USDA FoodData Central (CC0). Same data as food-db.json. */\n'
          '(typeof window !== "undefined" ? window : globalThis).HyroxFoodDb = ' + text + ';\n')
    with open(os.path.join(a.out, 'food-db.js'), 'w', encoding='ascii', newline='\n') as f:
        f.write(js)
    print('foods %d (SR %d, FF %d) excluded %d (SR %d, FF %d) -> %s' % (len(foods), len(sr), len(ff), len(sr_ex) + len(ff_ex), len(sr_ex), len(ff_ex), a.out))
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
