// Phase 11 before/after screenshots (synthetic data, no network, Chrome mobile emulation — NOT Safari/WebKit).
// Usage: NODE_PATH=<dir with playwright>/node_modules node tools/p11-screens.cjs <appRoot> <outDir> <before|after>
'use strict';
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');
const { chromium } = require('playwright');
const [root, out, phase] = process.argv.slice(2);
const PORT = 4460 + (phase === 'after' ? 1 : 0);
fs.mkdirSync(out, { recursive: true });
const steps = [];
(async () => {
  const srv = spawn(process.execPath, [path.join(root, 'tests', 'static-server.js')], { env: { ...process.env, HYROX_APP_ROOT: root, HYROX_APP_PORT: String(PORT) }, stdio: 'ignore' });
  await new Promise((r) => setTimeout(r, 800));
  const browser = await chromium.launch({ executablePath: process.env.HYROX_CHROME || '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  try {
    for (const W of [390, 320]) {
      const ctx = await browser.newContext({ viewport: { width: W, height: W === 320 ? 568 : 844 }, isMobile: true, hasTouch: true, deviceScaleFactor: 2, timezoneId: 'Asia/Qatar', locale: 'en-US' });
      const page = await ctx.newPage();
      await page.clock.setFixedTime(new Date('2026-11-19T09:00:00Z')); // 12:00 Asia/Qatar
      await page.goto(`http://127.0.0.1:${PORT}/`);
      await page.evaluate(() => localStorage.clear()); await page.reload();
      const shot = async (name, testid) => {
        if (testid) await page.getByTestId(testid).first().scrollIntoViewIfNeeded();
        await page.waitForTimeout(400); // let the .15 s tab/colour transitions finish
        await page.screenshot({ path: path.join(out, `${phase}-${W}-${name}.png`) });
      };
      const tap = async (id, note) => { await page.getByTestId(id).first().click(); if (W === 390) steps.push(`tap ${id}${note ? ' — ' + note : ''}`); };
      const fill = async (loc, v, id) => { await loc.fill(v); if (W === 390) steps.push(`type in ${id}: "${v}"`); };
      const manual = async (label, items) => {
        await fill(page.getByTestId('meal-label'), label, 'meal-label');
        for (let i = 0; i < items.length; i++) {
          if (i) await tap('meal-add-component');
          await fill(page.getByTestId('component-name').nth(i), items[i][0], 'component-name #' + (i + 1));
          await fill(page.getByTestId('component-kcal').nth(i), String(items[i][1]), 'component-kcal #' + (i + 1));
        }
      };
      if (W === 390) steps.push(`--- ${phase} (${W}px) ---`);
      // setup (no network): Settings → AI provider Mock → scenario "Butter chicken"
      await tap('tab-settings'); await page.getByTestId('ai-provider-mock').check(); await page.getByTestId('ai-mock-scenario').selectOption('butterChicken');
      if (W === 390) steps.push('Settings: AI provider = Mock, scenario = Butter chicken (no network)');
      await tap('tab-today');
      const top = async () => { await page.evaluate(() => window.scrollTo(0, 0)); await shot('01-today'); };
      const photoLunch = async () => {
        await tap('meal-path-photo_ai');
        await fill(page.getByTestId('meal-description'), 'butter chicken, all chicken eaten, 60% sauce', 'meal-description');
        await page.getByTestId('photo-library-input').setInputFiles(path.join(root, 'tests', 'fixtures', 'p10-view-a.jpg'));
        if (W === 390) steps.push('choose 1 photo (synthetic fixture p10-view-a.jpg)');
        await tap('photo-privacy-ack'); await page.getByTestId('photo-send-consent').check(); if (W === 390) steps.push('tick photo-send-consent');
        await tap('photo-send', 'Run MOCK TEST (no network)');
        await page.getByTestId('meal-review-box').waitFor();
        await tap('meal-note-fractions-apply'); await tap('meal-eaten-100');
      };
      if (phase === 'before') {
        await shot('02-nutrition', 'today-glance');
        await tap('today-add-meal', 'opens Add → Meal');
        await tap('meal-path-manual');
        await shot('03-add-meal');
        await manual('Synthetic oats', [['oats', 350]]);
        await tap('meal-confirm', 'saves breakfast; app jumps to History');
        await tap('tab-today'); await top();
        await tap('today-photo-meal', 'opens Add → Meal on Photo');
        await photoLunch();
        await shot('04-review', 'meal-review-box');
        await tap('meal-confirm', 'saves lunch; app jumps to History');
        await shot('05-after-save');
        await tap('tab-today'); await shot('06-today-after', 'today-glance');
      } else {
        await tap('diary-log-breakfast', 'opens "Log breakfast" for Thu 19 Nov');
        await tap('meal-path-manual');
        await manual('Synthetic oats', [['oats', 350]]);
        await tap('meal-confirm', 'saves; returns to the Today diary');
        await top();
        await shot('02-diary', 'today-diary');
        await tap('diary-log-lunch', 'opens "Log lunch"');
        await shot('03-log-lunch');
        await photoLunch();
        await shot('04-review', 'meal-review-box');
        await tap('meal-confirm', 'saves; returns to the diary with Lunch open');
        await shot('05-after-save', 'diary-row-lunch');
        await tap('diary-log-dinner', 'opens a fresh "Log dinner"');
        await fill(page.getByTestId('meal-label'), 'Half typed', 'meal-label');
        await tap('logger-back', 'unsaved input → Keep/Discard dialog');
        await shot('06-keep-discard');
        await tap('choice-keep', 'keeps the draft');
        await tap('meal-discard'); await tap('choice-yes', 'discards it');
        await tap('logger-back', 'back to the diary');
        await tap('diary-prev', 'diary shows Wed 18 Nov (not today)');
        await shot('07-diary-yesterday', 'today-diary');
      }
      await ctx.close();
    }
  } finally { await browser.close(); srv.kill(); }
  fs.writeFileSync(path.join(out, `${phase}-tap-path.txt`), steps.join('\n') + '\n');
  console.log('screens done: ' + phase);
})().catch((e) => { console.error(e); process.exit(1); });
