// RC1 screenshots at 390 and 320 px (Chrome emulation, not Safari). Synthetic data; Playwright test clock only; local server.
// Usage: NODE_PATH=<@playwright/test node_modules> node tools/rc1-screens.cjs <baseUrl> <outDir>
const { chromium } = require('@playwright/test');
const fs = require('fs');
const [base, out] = process.argv.slice(2);
(async () => {
  fs.mkdirSync(out, { recursive: true });
  const b = await chromium.launch({ executablePath: process.env.HYROX_CHROME || '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  const log = [];
  for (const W of [390, 320]) {
    const ctx = await b.newContext({ viewport: { width: W, height: W === 320 ? 568 : 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, timezoneId: 'Asia/Qatar', locale: 'en-US' });
    const p = await ctx.newPage(); const errs = []; p.on('pageerror', (e) => errs.push(e.message)); p.on('dialog', (d) => d.accept());
    const shot = async (n, full) => { await p.waitForTimeout(300); await p.screenshot({ path: `${out}/rc1-${W}-${n}.png`, fullPage: !!full }); log.push(W + ' ' + n); };
    const at = async (iso) => { await p.clock.setFixedTime(new Date(iso)); await p.reload(); await p.getByTestId('today-glance').waitFor(); };
    const planner = async () => { const d = p.getByTestId('today-planner'); await d.waitFor({ state: 'attached' }); if (!(await d.evaluate((e) => e.open))) await p.getByTestId('today-planner-toggle').click(); await d.scrollIntoViewIfNeeded(); };
    await p.clock.setFixedTime(new Date('2026-11-19T09:00:00+03:00'));
    await p.goto(base); await p.evaluate(() => localStorage.clear()); await p.reload(); await p.getByTestId('today-glance').waitFor();
    await p.getByTestId('diary-log-lunch').click(); await p.getByTestId('meal-add-foods').click();
    await p.waitForFunction(() => /13,598/.test((document.querySelector('[data-testid=foods-status]') || {}).textContent || ''), null, { timeout: 15000 }).catch(() => {});
    for (const q of ['4 boiled eggs', '1 can tuna']) { await p.getByTestId('foods-q').fill(q); await p.waitForTimeout(600); await p.getByTestId('food-result').first().scrollIntoViewIfNeeded(); await p.evaluate(() => window.scrollBy(0, -120)); await shot('search-' + q.replace(/\W+/g, '-')); }
    await p.getByTestId('food-pick').first().click(); await p.getByTestId('food-add').click(); await p.getByTestId('foods-done').click();
    await p.getByTestId('meal-confirm').click(); await p.getByTestId('today-diary').scrollIntoViewIfNeeded(); await shot('diary-return');
    await planner(); await p.getByTestId('planner-create').click(); await p.getByTestId('planner-preview-toggle').click(); await shot('19nov-draft-preview-locked', true);
    await at('2026-12-11T09:00:00+03:00'); await planner(); await p.getByTestId('planner-preview-toggle').click(); await p.getByTestId('planner-approve').check(); await shot('11dec-approved-ready', true);
    await p.getByTestId('planner-activate').click(); await p.getByTestId('planner-active').waitFor(); await shot('11dec-activated');
    await at('2026-12-14T07:00:00+03:00'); await p.evaluate(() => window.scrollTo(0, 0)); await shot('14dec-today-block2-w1'); await p.getByTestId('today-card').scrollIntoViewIfNeeded(); await shot('14dec-today-card');
    log.push(W + ' page errors: ' + JSON.stringify(errs));
    await ctx.close();
  }
  fs.writeFileSync(`${out}/rc1-screens-log.txt`, log.join('\n') + '\n');
  await b.close();
})().catch((e) => { console.error(e); process.exit(1); });
