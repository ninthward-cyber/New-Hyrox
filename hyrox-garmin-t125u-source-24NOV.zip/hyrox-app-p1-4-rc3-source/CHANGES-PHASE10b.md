# Phase 10b: findings, cost check and the meal-form fix

**Built on:** branch `p10b/meal-reset`, commit after `f27bfc4`. `f27bfc4` is Grok P10 `0d81adf` plus Claude's P10 review patch. Its tree is identical to `hyrox-app-phase10-claude-review-source.zip` (9172d1d1…), and it builds Claude's deploy `911c4b1e…`.

**Code changed:** one app file, `src/ui/app-ext.js` (+51/−7 lines). One build-script label changed, and one new e2e test file was added.
- No server, function, data-layer, backup-format, env, secret or cap change.
- No assertion in any earlier test was edited or weakened.
- No live or paid OpenAI call was made, and `test_food_photo_api_live.py` was not run.
- Nothing was deployed or pushed.

## 1. Status line (18 Nov 2026, Asia/Qatar)

| Area | Status | Evidence |
|---|---|---|
| SELECT / UPLOAD (choose 2–3 photos) | **Works, owner-reported only** | The owner said "The multi picture upload worked". The P9 client had no `multiple` on the library input, so multi-select means a P10 client is live. |
| ANALYZE | **Works on live: 1 two-photo request** | Netlify function log, 18 Nov 16:46:54Z (19:46 Qatar): `analyze_ok`, images 2, items 4, 3528 in / 642 out tokens, $0.000674. That cost is **computed by the server from provider-returned usage; it is not an OpenAI invoice**. Whether the 4 items were right, and not double-counted, only the owner can say. |
| MEAL SAVE | **Unverified on live, and a P0 bug is present in the live code** | Reproduced in Chrome emulation on the live candidate code (`f27bfc4`). The first meal saves, but the Add form keeps showing it while the draft behind it is gone, so a second meal is lost or throws. 22 of 22 new tests fail on the old code and pass on the fix. The fix is **not deployed**. |
| BACKUP (export/restore) | **Unverified on live; owner only** | Synthetic e2e: history → export → restore → reopen shows every meal once (total 700 kcal). No device check exists. |

## 2. Discrepancies

| # | What the brief or earlier files said | What was found | Effect |
|---|---|---|---|
| D1 | Read the handover file `5e00d385….txt` | It is the owner's private attachment and only the parent agent can read it. | Worked from the parent's brief only. Anything that is in the handover but not in the brief is not covered. |
| D2 | `0d81adf` is the newest candidate, and it matches deploy `af019198…` | `0d81adf` does match `af019198` (verified). But **Claude's P10 review (`911c4b1e…`) is newer** and is the recommended deploy. | P10b is built on Claude's P10 (`f27bfc4`), the most likely live code. |
| D3 | The deploy given to the owner is `af019198…` | Netlify production deploy `6afd66ab8c61fa7eb0bfa15d` ("Build from drop deployment", published 18 Nov 11:50 Qatar). Its function bundle is 379369 bytes. Local zip-it-and-ship-it builds came to 379393 bytes for Claude's code and 379080 bytes for Grok's. Neither digest matches, because the toolchain differs. | The size suggests Claude's build (Δ24 bytes vs Δ289) but **does not prove it**. The owner checks in §4 confirm it. |
| D4 | "No Netlify access" | The owner connected Netlify read-only later. Only reader tools were used: no deploy, settings, env or access change. | Logs were used as evidence. |
| D5 | 17 Nov 14:58:20Z (17:58 Qatar), request `01M7N086XDST1DWTTXWCW0A5DZ`: 200 with no `analyze_ok` | The function took 7.27 s and returned 1100 B. A replay returns in under 1 s and logs `analyze_replay`. P9 used a new request id on every tap. So this was **a real provider call whose `analyze_ok` log line was lost**. The 18 Nov call also lost its `req` line, which proves lines can drop. | Cost is unknown. It is about $0.0003–0.0005 if usage was returned, and $0.004 (the reserve) if it was not. The ledger's `total.calls` and `total.usd` settle it (§4). |
| D6 | The size limits are "2.4 MB / 1.65 MB" | Those are server limits, not what the app sends. **Request body:** 2.4 MB raw. **Single photo:** ≤ 1.65 MB decoded, JPEG, ≤ 1600 px (Claude added the 1600 px cap; P9 allowed 4096 px). **Photo set:** ≤ 600 KB each, ≤ 1.65 MB in total, 1–3 photos, duplicates refused. **Note:** ≤ 500 chars. **Netlify:** 6 MB / 60 s. **App:** encodes to about 500 KB at 1280 px, refuses over 550 KB per photo or 1.5 MB per set. | No change. |
| D7 | Claude reported 1388 pass / 7 skip | This box: 1395 pass / 0 skip on the same tree. The 7 tests that Claude's machine skipped run here. | Not a failure; the environment differs. |
| D8 | Settings → Check shows "about $X.XX of budget" | `remainingUsd` = min($5 − total, $3 − month) − reserved, **rounded to cents**. The monthly $3 cap is the smaller one, so the app shows about **$3.00**, and sub-cent spend is invisible. | Not changed (cosmetic). Read the JSON in §4 for exact figures. |
| D9 | The P0 addendum | The Drive spec document has no addendum. The requirement came only from the brief. | Implemented as the brief stated it. |

## 3. Cost

| Item | Value | Basis |
|---|---|---|
| 15 Nov 14:54Z, 17 Nov 14:47Z | 502 PROVIDER_ERROR, cost $0 | function log `costUsd 0` (not billed → refunded) |
| 17 Nov 14:57:17Z, 1 photo | 1844 in / 420 out = **$0.000394** | server-logged from provider usage (P9-era log format) |
| 17 Nov 14:58:20Z | **unknown, $0.0003–$0.004** | see D5 |
| 18 Nov 16:46:54Z, 2 photos | 3528 in / 642 out = **$0.000674** | server-logged from provider usage; provider request id `req_08eb9d0d…` |
| Ledger total (estimate) | **$0.0014–$0.0051** | sum of the above; the site said NOT_CONFIGURED until 15 Nov, so there were very likely no earlier calls |
| Remaining | **≈ $4.995–$4.999 of $5 total; ≈ $2.995–$2.999 of $3 this month** | ≈ $5 − ledger. The exact figure comes only from the status JSON or the ledger blob |
| ESTIMATE: 1 call with 3 photos | typical ≈ 4950 in + 650 out ≈ **$0.0008–$0.0010**; ≤ $0.002 even at the 3000-token output cap; server hard ceiling $0.00377 | Method: the real logs imply about 620 text tokens and about 1200–1350 per photo. Uncertain because the photo pixel sizes are not logged. A request whose worst case is over $0.004 is refused before sending. |
| ESTIMATE: 1 call with 2 photos | ≈ $0.0007 (logged $0.000674) | |

**Decision 1, the 2.5 tokens-per-patch bound.** The code's worst-case input for 2 × 1280×960 photos is about 9270 tokens; the real figure was 3528, about 38%. Even if the app had sent smaller photos, the bound held with a wide margin. **Recommend keeping 2.5 and the $0.004 reserve.**

**Code checks.**
- Choosing or previewing photos makes **no** network call. It is a local decode and resize only; the photo path may call `GET /status`, which is free and makes no OpenAI call.
- One Analyze tap makes one POST, with one request id and one reservation. That reservation is settled to the provider usage before the reply; it is charged at the reserve if usage is missing, and refunded if the call was not billed.
- A retry of the same photos and note reuses the request id: the server replays, or answers 409 while the first call is in flight. A new meal gets a new id.
- The 18 Nov logs show exactly one POST.

## 4. Mock / synthetic matrix (all no-network or stubbed)

| Case | Covered by |
|---|---|
| 1, 2 and 3 photos, one request each | p10-function, p10b e2e (live UI with a stubbed fetch: one POST per meal, a new requestId, no photo bytes stored) |
| Same plate from several angles → one meal; before/after not double-counted; a distinct second dish; labels and note respected | Contract level only: MULTI_INSTRUCTIONS/LABEL_TEXT sent, one list returned, client overlap warnings, eaten fractions applied once (p10-function, p10-claude-review, p10 e2e). **Model behaviour is owner-only.** |
| 4 or more files refused | p10-function, p10 e2e |
| HEIC: converted, or an undecodable file refused with nothing sent; picker cancel keeps the draft | p9/p10 e2e, p10b e2e (new) |
| Offline, timeout, malformed payload, missing usage → charged at the reserve, outage → fails closed (no provider call) | p9-function, p10-function, netlify dev offline 10a–10e |
| Privacy (no EXIF/GPS, no photo or code in the export) | p9/p10 e2e, p10b e2e |
| Ordered-set hash, idempotency, overlapping retry 409, concurrency | p10-function, p9-function |
| Size limits (D6), durable caps $5/$3/20/300 | p9-function, p10-function, p10-claude-review |
| **P0 meal reset:** two meals in a row; Add→save→Add; edit old→new; tabs keep an unsaved draft; discard confirm; failed save keeps input and photos; 1/2/3-photo analysis then a new meal; late estimate not applied; Qatar midnight; history/export/restore/reopen with no duplicates | `tests/e2e/p10b-meal-reset.spec.js`, 12 tests × 390/320 px |

## 5. What changed (src/ui/app-ext.js)
1. **After a verified save, the meal form becomes an empty draft.** It is rebuilt at once, and it stays on Photo or Description when that was the path used. Everything is cleared: items, note, portions, fractions, estimate, photos and their bytes, consent, request id and messages. Saved meals are never touched.
2. **An unsaved draft is never lost silently.** Starting a new meal, Edit, Copy, or switching the input path with typed or analysed content asks "Discard the meal you have not saved yet?…". Moving between tabs keeps the draft. A failed save keeps everything.
3. **Opening the Add tab always shows the current draft**, never a saved or discarded meal.
4. **Late-estimate guard:** an answer that arrives after the meal was saved or replaced is not put into the next meal; a toast explains this.
5. **Qatar midnight:** with the app left open, Today, History and Add switch to the new date (on tab tap, return to the app, or a 30 s check). An untouched new draft moves to the new date; an unsaved one keeps its date.

## 6. Tests

| Suite | Result |
|---|---|
| JS unit (`node --test tests/*.test.js`) | **1395 pass, 0 fail, 0 skip** |
| Python adapter (pytest) | **8 passed** |
| e2e, **Chrome emulation, not Safari** (390 + 320 px) | **281 pass, 1 skip, 0 fail** (257 earlier + 24 new) |
| New tests on the OLD code (`f27bfc4`) | **22 / 22 fail** (before the HEIC case was added), which proves the bug |
| netlify dev --offline with a stub provider | all P9 checks plus 10a–10e as expected; no secret in the logs |

**Assertions changed:** none in Phase 10b. Claude's P10 review had edited assertions in p10-function, p9-function (`HYROX_RESERVE_USD=0.02`), p10-local and the p10 e2e; see CLAUDE-QA-REPORT-P10.md.

**Downgrade risk:** none. There is no data-layer or storage change.
