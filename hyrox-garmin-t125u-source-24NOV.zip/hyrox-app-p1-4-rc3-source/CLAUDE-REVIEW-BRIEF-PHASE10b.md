# Claude review brief: Phase 10b

**Base and scope.**
- Base: `f27bfc4`, which is Claude's P10 review applied to Grok `0d81adf`. Its tree is identical to your `hyrox-app-phase10-claude-review-source.zip`.
- P10b changes only `src/ui/app-ext.js` (meal draft lifecycle). It also adds `tests/e2e/p10b-meal-reset.spec.js` and relabels the build script.
- Patch: `hyrox-phase10b-vs-claude-p10.patch`.

**Please check independently. Do not trust Grok's claims.**
1. **Bug and fix.** Before the fix, a confirmed save set `ms = null` but never re-rendered Add, because tabs only toggle `hidden`. Confirm that bug, and that the fix really clears every part of a draft:
   - items, description, eatenFraction and eatenCustom
   - estimate, `lastAiWarnings`
   - photos and their bytes, `draftNonce` / requestId
   - consent, error text

   Confirm too that it never deletes or changes a saved meal.
2. **`mealDirty` and the discard confirm.**
   - Is any real unsaved input discarded without a prompt? Check Edit, Copy, Start, the path switch, a timed-out analysis and an in-flight photo decode.
   - Is the path switch's `ignorePhotos` acceptable? It drops photos that were never analysed without asking.
   - Is a `window.confirm` acceptable in an iOS standalone PWA?
3. **Late estimate guard** (`forMs`/`forGen`). An answer for a saved draft must not reach the new draft. Also confirm the server still charges that request exactly once (idempotency is unchanged).
4. **Midnight.**
   - `checkDay` runs on a tab tap, `visibilitychange`, `pageshow` and a 30 s interval. Check it for iOS background or BFCache gaps and for excess re-renders.
   - An untouched draft moves to the new date. A dirty draft keeps its date: is that right, or should it warn?
5. **After a save, the next draft stays on Photo or Description** when that was the path used; Edit and Copy go to Manual. Is that the right UX?
6. **Run on real WebKit/Safari if you can.** Grok's e2e is Chrome emulation only (281 pass, 1 skip). Unit: 1395/0. pytest: 8.
7. **Cost evidence (CHANGES §3).**
   - The 17 Nov 14:58:20Z request returned 200 in 7.27 s with no `analyze_ok` line. Grok concluded it was a real billed call with a dropped log line. Check this against the P9 handler code.
   - The 2-photo real usage was 3528 in, against a code bound of about 9270. Is keeping the 2.5 tokens-per-patch bound and the $0.004 reserve justified?
8. **Live build identity** (CHANGES D3). The live function is 379369 bytes, against local builds of 379393 (yours) and 379080 (Grok's). This is not proof; the owner's `photo-ai.js` size or `foodWords` check decides it.
9. No server, env, cap or data-layer change. Verify with `git diff f27bfc4 -- netlify src/data deploy`, which must be empty.
