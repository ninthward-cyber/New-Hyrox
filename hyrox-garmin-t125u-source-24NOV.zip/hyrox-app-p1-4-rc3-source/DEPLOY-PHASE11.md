# Phase 11: owner checks, deploy and rollback (Windows PowerShell + iPhone)

Only the owner runs these steps, with his own logins. **Site:** `hyrox-phase7-private-test`, site ID `99f0deb7-0526-46f6-b432-9c3bfc2c86d2` — the **same site and the same Home Screen icon** (do not add a new icon). The Phase 5 site is out of scope.

**No env change** (no variable, secret, key, model or cap change; caps stay $5 total, $3/month, 20/day, 300/month). **No migration**: Phase 11 adds an optional `mealCategory` field only to meals you log after the update; old meals are not rewritten.

> Never paste into any chat: your OpenAI key, owner code, any `Authorization` header, photos, or what you ate.

## A. Read-only: confirm what is live now
Netlify → site → **Deploys** → Published deploy should be `6afe8c4ea9bec4f7b197d344` (19 Nov, 08:42 Qatar). Deploy file browser → sizes:
| `src/ui/app-ext.js` | `src/ui/style.css` | Live build |
|---|---|---|
| 207434 | 34275 | **Claude P10b** (`da206f89…`) — expected |
| 222695 | 39561 | Phase 11 (this package) |
| anything else | | stop and report the sizes |
Also do the **pending P10b smoke test** first if not yet done (DEPLOY-PHASE10b §D).

## B. Backup first (mandatory)
iPhone → Home Screen icon → Settings → **Export**. Keep the file (Files app). Do not continue without it.

## C. Deploy Phase 11
```powershell
cd $HOME\Downloads
Get-FileHash .\hyrox-app-phase11-deploy.zip -Algorithm SHA256   # must equal its line in SHA256SUMS-phase11.txt
Expand-Archive .\hyrox-app-phase11-deploy.zip -DestinationPath .\hyrox-p11-deploy -Force
cd .\hyrox-p11-deploy\hyrox-phase11-deploy
npm ci
npx netlify-cli login
npx netlify-cli sites:list --json | ConvertFrom-Json | Where-Object { $_.id -eq '99f0deb7-0526-46f6-b432-9c3bfc2c86d2' } | Select-Object name, url, id
# must show hyrox-phase7-private-test, otherwise STOP
npx netlify-cli deploy --site 99f0deb7-0526-46f6-b432-9c3bfc2c86d2 --dir publish --functions netlify/functions --message "Phase 11 draft"
```
1. **Draft check** in a new Safari tab on the draft URL (not the icon; AI stays off without the code):
   - Today → Meals card shows Breakfast/Lunch/Dinner/Snacks "Not logged" and "calories unknown, not 0".
   - Lunch "+ Log" → "Log lunch · today" screen → Manual → one item → Confirm → back on Today, Lunch shows 1 entry once.
   - Lunch "+ Log" again → empty form → type something → ‹ Back → dialog is readable → Discard.
   - Clear that tab's website data.
2. **Production:**
   ```powershell
   npx netlify-cli deploy --prod --site 99f0deb7-0526-46f6-b432-9c3bfc2c86d2 --dir publish --functions netlify/functions --message "Phase 11"
   ```
   Open the Home Screen icon, close and reopen: all data still there; older meals appear under "Uncategorized / Earlier meals".

## D. Owner device QA (real iPhone Safari; e2e ran in Chrome emulation, not Safari)
1. Log breakfast and lunch; each appears once in its row; totals say "so far — not a full day".
2. Edit one entry → only that entry changes. Add a second lunch → 2 entries.
3. ‹ to yesterday → "not today" badge → + Log → header shows yesterday's date → save lands on yesterday.
4. Text size: Settings → Accessibility → Larger Text, reopen: nothing clipped; pinch zoom still works; tapping inputs does not zoom.
5. Leave the app open past midnight Qatar: Today and the diary show the new date.
6. Settings → Export → Restore preview: no duplicate meals.

## E. Rollback (no env change, no migration; Blobs budget counters kept; categories stay in records and are simply ignored)
**Fastest:** Netlify → Deploys → click `6afe8c4ea9bec4f7b197d344` (Claude P10b) → **Publish deploy**.
From a zip (check the hash, then the same `npm ci` + `deploy --prod` as in C):
| Order | Target | SHA256 |
|---|---|---|
| 1 | Claude P10b `hyrox-app-phase10b-deploy…` | `da206f891229ae43b73a04722d2a2a37f2ca92aba7df31accbf19c2016e8cf72` |
| 2 | Claude P10 `hyrox-app-phase10-deploy-claude.zip` | `911c4b1e4dce2b65c48fb0174f5e55d79b950e86d5246c64d392ba96d39ffad5` |
| 3 | Claude P9 (corrected) | `5bac0b1c328672a2ba0ff07c07a4659c9191eb8d04b2ae4950bd338956971d35` |
Rolling back to P10 or P9 brings back the P10b meal-form bug; saved meals are not lost.
