# HYROX Phase 3, round 2 — independent review and repair report

Date: 2026-11-11 · Reviewer: Claude · For: owner approval
Status: **local only. Not pushed, not merged, not deployed.** No real photo, no model call, no spending.

Baseline: Grok source `ed7ad84` (nested ZIP SHA-256 `e740ef5c…1191`; outer handover ZIP `14af2fd1…1281`). Both hashes and all 36 manifest entries verified.

## Recommendation

**READY FOR OWNER IPHONE TESTING. HOLD on merge.**

- Ready for testing because every confirmed defect below is repaired with a regression test that fails on `ed7ad84`, and all suites pass.
- Hold on merge because nothing here has run on WebKit or a real iPhone, and five owner-policy questions are still open (section 4).
- Test with a fresh export in hand, and with sample data before real health logs.

## 1. Verified (re-run here, not taken on trust)

| Check | Unmodified `ed7ad84` | Repaired tree |
|---|---|---|
| JavaScript unit tests | 553 pass, 0 fail | 591 pass, 0 fail, 0 skipped |
| Python adapter tests | 8 pass | 8 pass |
| Browser journeys, installed Chrome 153, 390×844 emulation | 33 pass (ChatGPT had not re-run these) | 40 pass |
| New regression tests | 26 of 38 fail (log 01) | 38 pass |

Also verified by direct probes or existing tests, no change needed:
- No Saturday or Sunday is ever offered as a make-up for a weekday session; Friday rule and the Monday/Wednesday cascades are intact.
- An easy walk and a gym session coexist on one day; two demanding sessions are flagged, never blocked and never created automatically.
- A weekend workout that was really done is stored as actual work and does not complete the missed weekday slot.
- 45/25-minute variant drafts start as NOT_STARTED with no loads, reps or splits filled in; a mismatched variant kind is refused.
- One resting-HR reading above both baselines is one flag, with both comparisons labelled.
- P0-A, P0-B, rollback, pre-import copy and the version-2 downgrade guard from round 1 are untouched and still pass.
- Credential and image-data scan of the whole tree: clean. The two inherited AI evidence files hold a macro estimate, an image hash and sizes only.

## 2. Repaired

**P0-1 — one bad value hid a whole daily record.** This traced back to a round-1 rule of mine (any record failing validation was hidden and left out of exports).
- A stored check-in whose only problems are in independent fields is now shown and used. Each bad field is marked INVALID in the working copy; the rest is intact.
- The stored text is never changed by reading. Tests assert byte-identical storage and zero writes.
- Invalid pain is UNKNOWN in the 10k gate and named as invalid. A real failure on another input still gives FAIL.
- Invalid general pain no longer reads as "no flags": readiness says it cannot be confirmed, the reference goal becomes DO_NOT_FORCE (new code `PAIN_INVALID`), no optional 10k is offered, and the adaptive target is not raised.
- The normal backup keeps the record with the bad field marked INVALID and a note of the exact original value. That backup restores.
- The emergency raw copy still holds the exact bytes and now says when the normal backup altered a value.
- Settings shows a "Records needing attention" list with collection, date, field, stored value and rule.

**Silent overwrite of a damaged record (found during this review, not in the brief).** On `ed7ad84`, saving a check-in or pressing "Set my target for today" for a date whose stored record was hidden replaced that record without warning, valid values included. Replacing or deleting any stored record that is not valid as stored now needs explicit approval; the check-in form asks for it with a tick box.

**P1-4 — fractional walk steps.** New fractional counts are refused. A stored legacy value such as 10.5 is shown, flagged, not counted and not rounded; the owner corrects it in History. `daySteps` ignores any count that is not a whole number 0–200,000 and reports how many it ignored.

**P1-5 — gate accepted impossible sleep.** Sleep outside 0–24 h passed the sleep check (99 h → PASS). It is now invalid/UNKNOWN.

**Smaller fixes**
- A damaged saved-settings record blocked saving settings with no way forward; it now explains and asks for approval.
- Resting-HR difference displayed as `-0.29999999999999716 bpm`; now rounded to one decimal.
- Compiled Python caches removed from the tree; `.gitignore`, `DEPLOY-FILES.txt` and `test-results/README.txt` added.

**Tests changed, and why.** Two unit tests and one browser test were "characterizations" that passed while asserting the behaviour the brief said not to preserve. They were rewritten to assert the repaired behaviour and are marked as replacements. No other existing assertion was edited.

## 3. Improved (owner-authorised appearance work)

Appearance and layout only; no id, test id or rule changed.
- Navigation moved to a bottom bar on phones, with icons, inside the safe area. A test checks it never covers the last control on a page.
- "Today at a glance" tiles for session, steps, readiness and confirmed kcal. Unknown shows as a dash and the word unknown, never 0.
- Refreshed colour, type, cards, badges, notes, inputs and focus rings.
- Before/after screenshots are in `screens/`.

## 4. Owner-policy questions — still on HOLD, nothing decided here

| Question | Current behaviour (unchanged) | Proposed answer | Compatibility note |
|---|---|---|---|
| Old CONFIRMED photo meal with no eaten amount | Not counted, not shown, left out of the normal backup, refused on restore. Now listed in "Records needing attention". | Keep the exact record and treat it as NEEDS_REVIEW, uncounted, until the amount is confirmed. Never default to 100%. | With only a normal backup, such a meal is lost if the device is lost. The Emergent build always wrote a numeric amount, so this only affects hand-edited or outside-generated data. |
| Fast-day state: sixth code `DF` or D1–D5 plus a flag | `DF` kept; `canonicalCode` gives D1–D5 | Keep `DF` for now | `DF` is computed, never stored, so backups are unaffected either way |
| In-app restore of an emergency raw copy | Not built; file is labelled not restorable | Build later as a separate, explicitly confirmed path | None until built |
| Restore of older backups with a fractional walk count | Still accepted, stored exactly, with a warning; count not used | Decide whether to refuse, as already decided for daily totals | Refusing would block old backups until edited by hand |
| Fractional daily total in an old backup | Refused whole (owner t54u) | No change proposed | Hand-editing JSON on an iPhone is untested |
| 17-of-20 numerator; both Monday and Wednesday missed; anything after 6 Dec 2026 | Not built; nothing invented | Owner to define | — |
| Week-4 gate failure beyond DO_NOT_FORCE; definition of "demanding"; step percentages | Unchanged and labelled as app defaults | Owner to confirm or set | — |
| Should a missing (not invalid) general pain value hold the reference goal? | No hold | Owner to decide | Would mark the goal DO_NOT_FORCE on any day pain is not logged |

One decision I did make, for your confirmation: an **invalid** stored pain value now holds the reference goal (`PAIN_INVALID`). It is the cautious reading of corrupt data, but it is a new code in Grok's contract.

## 5. Still open or unverified

- **WebKit and real iPhone Safari: not tested.** Camera, HEIC, Add to Home Screen, storage eviction and restore on the phone remain the owner's manual check (`docs` checklist in the Grok handover, plus the round-2 items below).
- Live photo-AI tests: not run.
- A record broken beyond its independent fields (bad date, wrong shape, session or meal rule failures) is still hidden and left out of the normal backup. It is now listed and is in the raw copy, but there is no in-app way to repair it.
- The unsaved-workout draft is kept in a separate browser key and is in neither backup.
- Today is still long. The explanatory text was left in place because tests and earlier decisions depend on its wording; collapsing it is a possible next step.
- Correction help text is English only.
- Cross-tab races and browser storage eviction are not solved.
- `ai-test-backend` has no authentication or rate limiting and must never be deployed.

## 6. How to check

From the extracted `hyrox-app` folder:

```
node --test tests/*.test.js
python -m pytest -q ai-test-backend/test_food_photo_adapter.py
HYROX_CHROME=/usr/bin/google-chrome NODE_PATH=<dir with @playwright/test 1.49.1>/node_modules \
  npx playwright test -c tests/playwright.local-chrome.config.js
```

To rebuild from the Grok source: extract `hyrox-app-phase3-local-source-ed7ad84.zip`, `git init`, then `git apply --binary claude-r2-repair-vs-grok-ed7ad84.patch`.

Extra iPhone checks for this round, on clean data: (1) confirm the bottom bar clears the home indicator and the keyboard, (2) save a check-in and reopen it, (3) export, and restore that export, (4) open Settings and confirm "Records needing attention" is absent on clean data.
