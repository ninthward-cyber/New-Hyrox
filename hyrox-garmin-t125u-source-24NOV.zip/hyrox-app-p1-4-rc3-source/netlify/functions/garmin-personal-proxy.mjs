// Netlify function entry (not deployed in this offline pass). Same-origin only when later wired.
export { handler } from '../lib/garmin-personal-proxy.mjs';
