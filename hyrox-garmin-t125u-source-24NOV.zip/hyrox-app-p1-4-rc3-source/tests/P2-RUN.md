# Phase 2 P0 test runs (local only)

Playwright lives **outside** the repo, in `/workspace/hyrox-p2/tools`. There is no app `package.json` and no Playwright dependency in this tree. Do not push, do not use GitHub, do not run against a paid or remote host.

## Tool versions (installed 2026-11-10)

- Node `v24.22.1`, npm `11.21.1`
- `@playwright/test` `1.65.0` (depends on `playwright` `1.65.0` and `playwright-core` `1.65.0`)
- WebKit **27.2** (Playwright WebKit build **v2388**), cached at `/home/box/.cache/ms-playwright/webkit-2388` — **cannot launch here** (missing host libraries; see below)
- FFmpeg Playwright build v1013
- **Chromium substitute, not Safari:** system `/usr/bin/google-chrome` **156.0.8078.47** (headless launch of `about:blank` succeeded). This is a stand-in only; it does not prove iPhone Safari.

## Projects

- `iphone-webkit` — Playwright WebKit, 390×844, iPhone 13-style device. Keep for when the libraries exist.
- `chromium-substitute` — **Chromium substitute, not Safari.** Same 6 e2e specs, 390×844, `isMobile` / `hasTouch`, iPhone-like UA, `executablePath` `/usr/bin/google-chrome`. List, HTML report, and test annotations are labeled "Chromium substitute, not Safari".

Real iPhone Safari is an owner checklist: `tests/IPHONE-SAFARI-P2-CHECKLIST.md`.

## WebKit host libraries (blocker)

`npx playwright install webkit` downloaded the browser, but a headless launch of `about:blank` failed. `npx playwright install-deps --dry-run webkit` also failed (no sudo was used; apt cannot locate several packages in this environment).

Launch error, missing libraries:

- `libevent-2.1.so.7`
- `libgstgl-1.0.so.0`
- `libgstcodecparsers-1.0.so.0`
- `libavif.so.16`
- `libmanette-0.2.so.0`
- `libenchant-2.so.2`

`install-deps --dry-run` additionally reported apt could not locate / had no candidate for: `libsoup-3.0-0`, `gstreamer1.0-libav`, `gstreamer1.0-plugins-bad`, `gstreamer1.0-plugins-base`, `gstreamer1.0-plugins-good`, `libenchant-2-2`, `libgstreamer-gl1.0-0`, `libmanette-0.2-0`, `libproxy1v5`, `libwoff1`, `libevent-2.1-7t64`, `libavif16`, `fonts-unifont`, `xfonts-scalable`, `fonts-ipafont-gothic`, `fonts-wqy-zenhei`, `fonts-tlwg-loma-otf`, `fonts-freefont-ttf`.

The `iphone-webkit` project cannot be executed here until those libraries are present. Unit tests and the Chromium substitute do not need WebKit.

## Commands (from the qa worktree; run suites only when Tewodros says)

    cd /workspace/hyrox-p2/wt/qa
    export NODE_PATH=/workspace/hyrox-p2/tools/node_modules
    PW=/workspace/hyrox-p2/tools/node_modules/.bin/playwright

List e2e tests (does not execute them; both projects):

    NODE_PATH=$NODE_PATH $PW test --config tests/playwright.config.js --list

List only the Chromium substitute, not Safari:

    NODE_PATH=$NODE_PATH $PW test --config tests/playwright.config.js --project=chromium-substitute --list

Data-layer adversarial unit tests (point at the Phase 2 data module when it exists):

    HYROX_DATA_PATH=/workspace/hyrox-p2/build/src/data/hyrox-data.js \
      node --test tests/import-adversarial.test.js

Existing Phase 1 unit tests:

    node --test tests/hyrox-data.test.js

E2e against the integration build (localhost static server, never public).

Chromium substitute, not Safari (6 specs):

    HYROX_APP_ROOT=/workspace/hyrox-p2/build \
    NODE_PATH=$NODE_PATH \
      $PW test --config tests/playwright.config.js --project=chromium-substitute

WebKit (when host libraries exist):

    HYROX_APP_ROOT=/workspace/hyrox-p2/build \
    NODE_PATH=$NODE_PATH \
      $PW test --config tests/playwright.config.js --project=iphone-webkit

App root defaults to this worktree if `HYROX_APP_ROOT` is unset. Override `HYROX_APP_PORT` (default 4173) if needed.
