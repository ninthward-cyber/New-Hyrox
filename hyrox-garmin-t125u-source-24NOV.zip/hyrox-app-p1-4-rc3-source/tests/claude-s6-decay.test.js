'use strict';
// Claude's original S6 probe hard-coded out(false, 'NO-DECAY', ...) so it can never
// pass as written (see tests/probes/s6_probe.original-hardcoded-fail.js). This file
// is the regression for the real contract: after 7+ quiet days the next lock is
// the base length again, and the helper is importable as ESM.
const test = require('node:test');
const assert = require('node:assert/strict');
const { pathToFileURL } = require('node:url');
const path = require('node:path');
const crypto = require('node:crypto');

const MJS = path.resolve(__dirname, '../netlify/lib/auth-lockout-shared.mjs');
const HASH = crypto.createHash('sha256').update('correct-owner-code-16ch').digest('hex');
const NOW = Date.UTC(2026, 10, 24, 5, 0, 0);

async function load() {
  return import(pathToFileURL(MJS).href);
}
function wrong(L, store, ip, n, now) {
  return L.checkCode({
    store, ip, now, ownerHash: HASH, code: 'wrong-code',
    reserveId: 'r-' + ip + '-' + n,
    compareFn: function () { return false; }
  });
}

test('S6 helper is importable as ESM (path used inside the deploy package)', async () => {
  const L = await load();
  assert.equal(typeof L.checkCode, 'function');
  assert.equal(typeof L.createFakeStore, 'function');
  assert.equal(typeof L.maybeDecay === 'function' || typeof L.readState === 'function', true);
  assert.equal(L.DECAY_AFTER_MS, 7 * 24 * 60 * 60 * 1000);
});

test('S6 lock lengths decay back down after 7 quiet days (30 min base)', async () => {
  const L = await load();
  const store = L.createFakeStore();
  const ip = '203.0.113.60';
  let now = NOW;
  for (let i = 0; i < 5; i++) await wrong(L, store, ip, i, now);
  const st = await L.readState(store, L.lockKeyIp(ip), now, 'perIp');
  assert.equal(st.doc.until - now, 30 * 60 * 1000, 'first lock is 30 min');
  now = st.doc.until + 1;
  for (let i = 0; i < 5; i++) await wrong(L, store, ip, 10 + i, now);
  const st2 = await L.readState(store, L.lockKeyIp(ip), now, 'perIp');
  assert.equal(st2.doc.until - now, 60 * 60 * 1000, 'second lock escalates to 60 min');
  now = st2.doc.until + L.DECAY_AFTER_MS;
  for (let i = 0; i < 5; i++) await wrong(L, store, ip, 20 + i, now);
  const st3 = await L.readState(store, L.lockKeyIp(ip), now, 'perIp');
  assert.equal(st3.doc.until - now, 30 * 60 * 1000, 'after 7 quiet days the next lock is 30 min again');
});
