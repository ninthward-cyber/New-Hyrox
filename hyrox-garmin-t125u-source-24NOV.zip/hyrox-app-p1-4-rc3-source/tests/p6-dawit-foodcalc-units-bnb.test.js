'use strict';
// P6 (Dawit) follow-up: (a) fl oz / quart input units, (b) narrow "bread and butter" exclusion.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const FC = require(path.resolve(__dirname, '../src/data/hyrox-foodcalc.js'));
const DB = require(path.resolve(__dirname, '../src/data/food-db.json'));

const r2 = (n) => Math.round(n * 100) / 100;
const one = (t, db) => FC.estimate(t, db || DB).items[0];
const tiny = (foods) => ({ meta: { schema: 1, dbVersion: 'test-db' }, foods });
const MILK = DB.foods.find((f) => f[1] === 'SR' && f[0] === 171265); // whole milk
const CUP = MILK[7].find((p) => p[1] === 'cup'), FLOZ_ROW = MILK[7].find((p) => p[1] === 'fl oz');
const CUP_ML = 236.5882365, FLOZ_ML = 29.5735, QT_ML = 946.353;

describe('P6 units: fl oz and quart (typed volume -> grams through the food\'s own USDA volume row)', () => {
  it('premise: milk has bare cup and fl oz rows in the DB', () => { assert.ok(CUP && FLOZ_ROW); assert.equal(CUP[0], 1); });
  it('1 fl oz and 2 fl oz milk: grams agree with cup row x 29.5735 / 236.588 (milk also has its own fl oz row, which is used directly)', () => {
    for (const n of [1, 2]) {
      const i = one(n + ' fl oz milk'); assert.equal(i.status, 'matched'); assert.equal(i.unit, 'fl oz'); assert.equal(i.amount, n);
      assert.ok(Math.abs(i.grams - n * CUP[2] * FLOZ_ML / CUP_ML) < 0.05, 'cup-row derived grams ' + i.grams);
      assert.equal(i.grams, r2(n * FLOZ_ROW[2] / FLOZ_ROW[0]), 'direct USDA fl oz row');
      assert.equal(i.portion.basis, 'usda_portion'); assert.equal(i.portion.grams, i.grams);
    }
    assert.equal(one('1 fl oz milk').grams, 30.5); assert.equal(one('2 fl oz milk').grams, 61);
  });
  it('without a fl oz row the cup row is scaled exactly: grams = amount x 29.5735 x cupGrams / 236.5882365 (tiny DB)', () => {
    const db = tiny([[10, 'SR', 'Juice test', 50, 1, 10, 0, [[1, 'cup', 250]]]]);
    for (const n of [1, 2, 0.5]) { const i = one(n + ' fl oz juice test', db); assert.equal(i.status, 'matched'); assert.equal(i.grams, r2(n * FLOZ_ML * 250 / CUP_ML)); assert.match(i.message, /Fluid ounces converted with the USDA "cup" row/); }
    assert.equal(one('1 fl oz juice test', db).grams, 31.25);
  });
  it('1 quart milk: cup row x 946.353 / 236.588 (~4 cups), not the DB\'s "quart" count row', () => {
    const i = one('1 quart milk'); assert.equal(i.status, 'matched'); assert.equal(i.unit, 'quart'); assert.equal(i.amount, 1);
    assert.equal(i.grams, r2(946.353 * CUP[2] / CUP[0] / CUP_ML)); assert.ok(Math.abs(i.grams - 4 * CUP[2]) < 1);
    assert.equal(one('2 qt milk').grams, r2(2 * 946.353 * CUP[2] / CUP_ML)); assert.equal(one('2 quarts of milk').status, 'matched');
    assert.match(i.message, /Quarts converted/);
    assert.equal(i.nutrients.kcal, Math.round(i.grams * MILK[3] / 100));
  });
  it('spelling variants of fl oz all parse to the same unit', () => {
    for (const u of ['fl oz', 'fl. oz', 'fl.oz', 'FL OZ', 'fluid ounce', 'fluid ounces', 'floz', 'fluid oz']) { const p = FC.parse('2 ' + u + ' milk').items[0]; assert.equal(p.unit, 'fl oz', u); assert.equal(p.food, 'milk', u); assert.equal(p.amount, 2); }
    for (const u of ['qt', 'qts', 'quart', 'quarts']) assert.equal(FC.parse('2 ' + u + ' milk').items[0].unit, 'quart', u);
  });
  it('a volume unit on a food with NO volume row is no_portion, asks for grams, no number, no water density', () => {
    const db = tiny([[20, 'SR', 'Flour test', 360, 10, 76, 1, [[1, 'slice', 30]]]]);
    for (const q of ['1 fl oz flour test', '2 quarts flour test', '1 qt flour test', '250 ml flour test']) {
      const i = one(q, db); assert.equal(i.status, 'no_portion', q); assert.equal(i.grams, null); assert.equal(i.nutrients, null); assert.match(i.message, /no density is guessed/); assert.match(i.message, /Enter grams/);
    }
    assert.match(one('1 fl oz flour test', db).message, /fluid ounces/); assert.match(one('1 qt flour test', db).message, /quarts/);
    const chicken = one('8 fl oz chicken breast'); assert.equal(chicken.status, 'no_portion'); assert.equal(chicken.grams, null);
    assert.equal(one('1 fl oz flour test', db).portion, null);
  });
  it('the owner can still enter grams for such a food (user_grams)', () => {
    const c = FC.estimateItem('1 qt chicken breast', DB, { grams: 100 }); assert.equal(c.status, 'matched'); assert.equal(c.grams, 100); assert.equal(c.portion.basis, 'user_grams');
  });
  it('"fl oz" is never parsed as weight "oz"; plain oz stays weight (28.3495 g)', () => {
    const f = one('8 fl oz chicken breast'); assert.equal(f.unit, 'fl oz'); assert.notEqual(f.portion && f.portion.basis, 'mass');
    const w = one('8 oz chicken breast'); assert.equal(w.status, 'matched'); assert.equal(w.unit, 'oz'); assert.equal(w.portion.basis, 'mass'); assert.equal(w.grams, r2(8 * 28.3495));
    assert.equal(one('1 ounce chicken breast').grams, 28.35); assert.equal(one('1 lb chicken breast').grams, 453.59);
    assert.equal(FC.parse('8 oz flour').items[0].food, 'flour', 'a food word starting with "fl" after "oz" is not a unit');
    assert.equal(FC.parse('1 oz floz cheese').items[0].unit, 'oz');
  });
  it('estimateItem accepts the new unit words as an override', () => {
    const a = FC.estimateItem('milk', DB, { amount: 2, unit: 'fl oz' }), b = FC.estimateItem('milk', DB, { amount: 1, unit: 'qt' });
    assert.equal(a.status, 'matched'); assert.equal(a.grams, 61); assert.equal(b.grams, one('1 quart milk').grams);
  });
  it('ml and cup behaviour is unchanged', () => {
    assert.equal(one('250 ml milk').grams, r2(250 * CUP[2] / CUP_ML)); assert.match(one('250 ml milk').message, /Millilitres converted/);
    assert.equal(one('1 cup milk').grams, 244);
  });
  it('deterministic', () => { for (const t of ['1 fl oz milk', '1 quart milk', '8 oz chicken breast']) assert.deepEqual(FC.estimate(t, DB), FC.estimate(t, DB)); });
});

describe('P6 "bread and butter": splits into bread + butter unless pickles are named', () => {
  const foods = (t) => FC.estimate(t, DB).items.map((i) => i.food);
  it('bread and butter / Bread AND Butter / bread & butter all give two items (bread, butter)', () => {
    for (const t of ['bread and butter', 'Bread AND Butter', 'BREAD  and  BUTTER', 'bread & butter', 'bread &butter']) {
      const r = FC.estimate(t, DB); assert.equal(r.items.length, 2, t); assert.deepEqual(r.items.map((i) => i.food.toLowerCase()), ['bread', 'butter'], t);
      assert.ok(r.items.every((i) => i.status === 'unparsed' && i.chosen), 'no quantity: asks for one, never counted');
      assert.ok(r.items.every((i) => !i.joined));
    }
  });
  it('with quantities each side is estimated on its own', () => {
    const r = FC.estimate('2 slices bread and 1 tbsp butter', DB); assert.deepEqual(r.items.map((i) => i.status), ['matched', 'matched']);
    assert.deepEqual(foods('2 slices bread and butter'), ['bread', 'butter']);
  });
  it('a segment that names pickle/pickles stays whole (as before), with "and" or "&"', () => {
    for (const t of ['bread and butter pickles', '1 bread and butter pickle', 'Bread & Butter Pickles']) {
      assert.equal(FC.estimate(t, DB).items.length, 1, t);
    }
    assert.equal(FC.estimate('pickles, bread and butter', DB).items.length, 3, 'the test is per segment: pickle in another comma segment does not protect it');
    const w = one('bread and butter pickles'); assert.equal(w.food, 'bread and butter pickles'); assert.equal(w.joined, undefined); assert.ok(w.candidates.length >= 1); assert.match(w.candidates[0].description, /bread and butter/i);
    assert.equal(FC.parse('bread & butter pickles', DB).items[0].food, 'bread and butter pickles');
  });
  it('the exclusion is for this phrase only: other joined phrases are unchanged', () => {
    assert.deepEqual(foods('mac and cheese'), ['macaroni and cheese']); assert.deepEqual(foods('1 cup mac and cheese'), ['macaroni and cheese']);
    assert.deepEqual(foods('rice and beans'), ['rice and beans']); assert.deepEqual(foods('chicken and rice'), ['chicken and rice']);
    assert.deepEqual(foods('2 eggs and 1 banana'), ['eggs', 'banana']); assert.deepEqual(foods('salt and pepper'), ['salt', 'pepper']);
    assert.deepEqual(foods('bread and butter and jelly'), ['bread', 'butter', 'jelly']);
    assert.deepEqual(foods('whole wheat bread and butter'), ['whole wheat bread', 'butter']);
    assert.deepEqual(foods('bread and peanut butter'), ['bread', 'peanut butter'].map((x) => x), 'not the phrase');
  });
  it('commas and an alias still behave as before; deterministic', () => {
    assert.deepEqual(foods('bread, butter'), ['bread', 'butter']);
    for (const t of ['bread and butter', 'bread and butter pickles', 'bread & butter, 1 egg']) assert.deepEqual(FC.estimate(t, DB), FC.estimate(t, DB));
  });
});
