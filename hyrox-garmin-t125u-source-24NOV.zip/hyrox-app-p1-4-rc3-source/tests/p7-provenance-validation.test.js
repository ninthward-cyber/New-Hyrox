'use strict';
// P7: validation of the optional meals components[].provenance on save, preview, restore and rollback.
// Synthetic data only. No live AI. Storage is an in-memory fake; nothing touches a real browser or key.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const HD = require(path.resolve(__dirname, '../src/data/hyrox-data.js'));
const HN = require(path.resolve(__dirname, '../src/data/hyrox-nutrition.js'));
const FC = require(path.resolve(__dirname, '../src/data/hyrox-foodcalc.js'));
const DB = require(path.resolve(__dirname, '../src/data/food-db.json'));

const NOW = new Date('2026-11-13T09:00:00Z'), ts = NOW.toISOString(), DAY = '2026-11-12';
const KEY = HD.STORAGE_KEY;
const mem = (init) => {
  const m = Object.assign({}, init || {});
  return { m, calls: [], getItem(k) { return Object.prototype.hasOwnProperty.call(m, k) ? m[k] : null; }, setItem(k, v) { this.calls.push(['set', k]); m[k] = String(v); }, removeItem(k) { delete m[k]; } };
};
const mk = (s) => HD.createStore(s, { now: () => NOW });
const comps = (text) => FC.toComponents(FC.estimate(text || '2 eggs, 150 g rice, 1 cup milk', DB)).components;
const meal = (extra) => Object.assign({ id: 'm1', createdAt: ts, date: DAY, time: '12:30', label: 'Synthetic', description: 'x', source: 'DESCRIPTION', lifecycle: 'DRAFT', components: comps() }, extra || {});
const ordinary = (id) => ({ id: id || 'm-ord', createdAt: ts, date: DAY, time: '08:00', label: 'Ordinary', description: 'toast', source: 'MANUAL', lifecycle: 'CONFIRMED', confirmedAt: ts,
  components: [{ name: 'Toast', role: 'OTHER', portion: '2 slices', preparation: '', eatenFraction: null,
    kcal: { value: 160, state: 'KNOWN' }, proteinG: { value: 6, state: 'KNOWN' }, carbsG: { value: 30, state: 'KNOWN' }, fatG: { value: 2, state: 'KNOWN' } }] });
const goodProv = () => JSON.parse(JSON.stringify(comps('150 g rice')[0].provenance));
const withProv = (prov) => { const c = comps('150 g rice'); if (prov === undefined) delete c[0].provenance; else c[0].provenance = prov; return meal({ components: c }); };
const cycle = (target, text) => {
  const p = target.previewImport(text); assert.equal(p.ok, true, JSON.stringify(p));
  return target.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt });
};
// A backup file text holding exactly this meal (built by hand, as an edited or foreign file would be).
const fileWith = (m) => JSON.stringify({ app: 'hyrox-app', version: HD.VERSION, exportedAt: ts, weight: [], workouts: [], nutrition: [], meals: [m] });

describe('P7 provenance: what the estimator writes is accepted', () => {
  it('every provenance written for every food and every USDA portion passes the limits (whole food database)', () => {
    let n = 0, maxLen = 0, maxDesc = 0, maxPortion = 0;
    for (const f of DB.foods) {
      const rows = f[7].length ? f[7] : [[1, 'g', 1]];
      for (const r of rows) {
        const prov = { source: 'USDA_FDC', dataset: f[1], fdcId: f[0], description: f[2], portion: '0.3333333333333333 ' + r[1] + ' [usda_portion]', grams: 5717 * 100000, dbVersion: DB.meta.dbVersion };
        const c = { name: 'x', role: 'OTHER', portion: '1', preparation: '', eatenFraction: null, provenance: prov };
        for (const k of ['kcal', 'proteinG', 'carbsG', 'fatG']) c[k] = { value: 1, state: 'ESTIMATED' };
        const res = mk(mem()).putRecord('meals', meal({ components: [c] }));
        assert.equal(res.ok, true, f[0] + ' ' + JSON.stringify(res)); n++;
        maxLen = Math.max(maxLen, JSON.stringify(prov).length); maxDesc = Math.max(maxDesc, f[2].length); maxPortion = Math.max(maxPortion, prov.portion.length);
      }
    }
    assert.ok(n > 8000); assert.ok(maxDesc <= 200 && maxPortion <= 200 && maxLen < 2048, [maxDesc, maxPortion, maxLen].join());
  });
  it('real estimator output for typical and household-portion text is accepted on save', () => {
    for (const t of ['2 eggs, 150 g rice, 1 cup milk, 1 tbsp olive oil, half an avocado', '1000 g olive oil', '1 medium banana', '250 ml milk', '3 slices bread']) {
      const m = meal({ components: comps(t) }); assert.ok(m.components.length >= 1, t);
      const r = mk(mem()).putRecord('meals', m); assert.equal(r.ok, true, t + ' ' + JSON.stringify(r));
    }
  });
  it('a meal without provenance (ordinary meal, user-edited estimate) is accepted; null is treated as absent', () => {
    assert.equal(mk(mem()).putRecord('meals', ordinary()).ok, true);
    assert.equal(mk(mem()).putRecord('meals', withProv(undefined)).ok, true);
    assert.equal(mk(mem()).putRecord('meals', withProv(null)).ok, true);
  });
});

describe('P7 provenance: export -> import round trip, byte-exact', () => {
  it('ordinary and estimated meals (DRAFT and CONFIRMED) survive export + restore with provenance unchanged', () => {
    const src = mk(mem());
    assert.equal(src.putRecord('meals', ordinary('m-ord')).ok, true);
    assert.equal(src.putRecord('meals', meal({ id: 'm-est-draft' })).ok, true);
    assert.equal(src.putRecord('meals', meal({ id: 'm-est-conf', lifecycle: 'CONFIRMED', confirmedAt: ts })).ok, true);
    const x = src.exportChecked(); assert.equal(x.restorable, true, JSON.stringify(x));
    const dst = mk(mem()); const r = cycle(dst, x.text); assert.equal(r.ok, true, JSON.stringify(r));
    for (const id of ['m-ord', 'm-est-draft', 'm-est-conf']) {
      assert.equal(JSON.stringify(dst.records('meals').find((g) => g.id === id).components), JSON.stringify(src.records('meals').find((g) => g.id === id).components), id);
    }
    assert.equal(dst.damagedRecords().length, 0);
  });
  it('estimated component with the optional clamp marker and note round-trips unchanged', () => {
    const prov = Object.assign(goodProv(), { carbsClampedToZero: true, note: 'USDA lists a slightly negative carbohydrate-by-difference for this food; it is counted as 0 g.' });
    const src = mk(mem()); assert.equal(src.putRecord('meals', withProv(prov)).ok, true);
    const dst = mk(mem()); assert.equal(cycle(dst, src.exportJSON()).ok, true);
    assert.deepEqual(dst.records('meals')[0].components[0].provenance, prov);
  });
  it('bounded unknown keys are preserved exactly, never dropped (forward compatibility)', () => {
    const prov = Object.assign(goodProv(), { futureField: 'abc', futureNum: 3.5, futureFlag: false, futureNull: null });
    const src = mk(mem()); assert.equal(src.putRecord('meals', withProv(prov)).ok, true);
    const dst = mk(mem()); assert.equal(cycle(dst, src.exportJSON()).ok, true);
    assert.equal(JSON.stringify(dst.records('meals')[0].components[0].provenance), JSON.stringify(prov));
  });
});

describe('P7 provenance: the clamp case (negative USDA carbohydrate counted as 0)', () => {
  const neg = DB.foods.filter((f) => f[5] < 0);
  it('the database keeps the USDA negative value and the estimator counts 0 g with a visible note', () => {
    assert.ok(neg.length >= 1);
    for (const f of neg) {
      const it = FC.estimateItem('100 g ' + f[2], DB);
      if (it.status !== 'matched' || it.chosen.fdcId !== f[0]) continue; // ambiguity: another food won; the direct check below still covers the clamp
      assert.equal(it.nutrients.carbsG, 0); assert.match(it.message, /counted as 0 g/);
    }
  });
  it('a clamped component (carbs 0 ESTIMATED) with its provenance saves, exports and restores; with and without the marker', () => {
    const f = neg[0], base = { source: 'USDA_FDC', dataset: f[1], fdcId: f[0], description: f[2], portion: '100 g [mass]', grams: 100, dbVersion: DB.meta.dbVersion };
    for (const prov of [base, Object.assign({}, base, { carbsClampedToZero: true, note: 'counted as 0 g' })]) {
      const c = [{ name: 'Clamped', role: 'OTHER', portion: '100 g', preparation: '', eatenFraction: null, provenance: prov,
        kcal: { value: 120, state: 'ESTIMATED' }, proteinG: { value: 22, state: 'ESTIMATED' }, carbsG: { value: 0, state: 'ESTIMATED' }, fatG: { value: 3, state: 'ESTIMATED' } }];
      const src = mk(mem()); assert.equal(src.putRecord('meals', meal({ components: c })).ok, true);
      const dst = mk(mem()); assert.equal(cycle(dst, src.exportJSON()).ok, true);
      assert.deepEqual(dst.records('meals')[0].components, c);
    }
  });
  it('a negative carbohydrate VALUE is still refused (the clamp is the estimator, not the validator)', () => {
    const m = withProv(goodProv()); m.components[0].carbsG = { value: -0.3, state: 'ESTIMATED' };
    assert.equal(mk(mem()).putRecord('meals', m).ok, false);
  });
  it('clamp marker must be exactly true when present', () => {
    for (const bad of [false, 1, 'true', {}]) assert.equal(mk(mem()).putRecord('meals', withProv(Object.assign(goodProv(), { carbsClampedToZero: bad }))).ok, false, String(bad));
  });
});

describe('P7 provenance: an old backup without provenance still restores', () => {
  it('Phase 3 / Phase 5 style backup (no provenance anywhere) restores onto an empty device', () => {
    const src = mk(mem()); src.putRecord('meals', ordinary()); src.putRecord('meals', withProv(undefined));
    const text = src.exportJSON(); assert.ok(!text.includes('provenance'));
    const dst = mk(mem()); assert.equal(cycle(dst, text).ok, true); assert.equal(dst.records('meals').length, 2);
  });
  it('the shipped Phase 3 export fixture still previews as restorable', () => {
    const fs = require('node:fs'); const t = fs.readFileSync(path.resolve(__dirname, 'fixtures/p3-phase3-export.json'), 'utf8');
    assert.equal(mk(mem()).previewImport(t).ok, true);
  });
});

describe('P7 provenance: malformed values are refused with a clear, located error', () => {
  const refused = (prov, partOfMsg) => {
    const text = fileWith(withProv(prov));
    const p = mk(mem()).previewImport(text);
    assert.equal(p.ok, false, JSON.stringify(prov).slice(0, 120));
    assert.equal(p.code, 'invalid_records');
    const d = p.details[0]; assert.equal(d.collection, 'meals'); assert.match(d.field, /^components\[0\]\.provenance/);
    assert.match(d.message, /provenance/); assert.match(d.howToCorrect, /Nothing on this device was changed/);
    if (partOfMsg) assert.match(d.message, partOfMsg);
    assert.equal(mk(mem()).putRecord('meals', withProv(prov)).ok, false, 'also refused on save');
    return d;
  };
  it('wrong type: string, number, array, boolean', () => {
    for (const v of ['USDA', 42, [1], ['USDA_FDC'], true, false]) refused(v, /must be a record/);
  });
  it('bad field types and ranges', () => {
    const cases = [['source', 7], ['source', ''], ['dataset', {}], ['fdcId', '171287'], ['fdcId', 1.5], ['fdcId', 0], ['fdcId', -3], ['fdcId', NaN], ['fdcId', 2147483648],
      ['description', 5], ['portion', ['1 cup']], ['portion', { label: 'cup' }], ['grams', '150'], ['grams', 0], ['grams', -1], ['grams', 1e10], ['dbVersion', 12], ['note', 1], ['carbsClampedToZero', 'yes']];
    for (const [k, v] of cases) {
      const p = goodProv(); p[k] = v;
      const text = JSON.stringify({ app: 'hyrox-app', version: HD.VERSION, exportedAt: ts, weight: [], workouts: [], nutrition: [], meals: [withProv(p)] });
      const r = mk(mem()).previewImport(text);
      assert.equal(r.ok, false, k + '=' + String(v)); assert.equal(r.details[0].field, 'components[0].provenance.' + k, k);
    }
  });
  it('required fields missing', () => {
    for (const k of ['source', 'fdcId']) { const p = goodProv(); delete p[k]; const d = refused(p, /is required/); assert.equal(d.field, 'components[0].provenance.' + k); }
    refused({}, /is required/);
  });
  it('oversize: each text limit, the number of extra fields, and the total size', () => {
    refused(Object.assign(goodProv(), { description: 'd'.repeat(201) }), /up to 200/);
    refused(Object.assign(goodProv(), { portion: 'p'.repeat(201) }), /up to 200/);
    refused(Object.assign(goodProv(), { source: 's'.repeat(41) }), /1 to 40/);
    refused(Object.assign(goodProv(), { dbVersion: 'v'.repeat(81) }), /1 to 80/);
    refused(Object.assign(goodProv(), { note: 'n'.repeat(301) }), /up to 300/);
    const many = goodProv(); for (let i = 0; i < 7; i++) many['extra' + i] = 'x'; refused(many, /more than 6 extra fields/);
    const six = goodProv(); for (let i = 0; i < 6; i++) six['extra' + i] = 'x'.repeat(200); // 6 allowed extras at the text cap, still under the size bound
    assert.equal(mk(mem()).putRecord('meals', withProv(six)).ok, true);
    const big = Object.assign(goodProv(), { description: 'd'.repeat(200), portion: 'p'.repeat(200), note: 'n'.repeat(300) }); for (let i = 0; i < 6; i++) big['extra' + i] = 'x'.repeat(200);
    assert.ok(JSON.stringify(big).length > 2048); refused(big, /too large/);
  });
  it('unknown keys: nested objects, arrays, long text, odd names and functions-as-text are refused, not dropped', () => {
    refused(Object.assign(goodProv(), { extra: { a: 1 } }), /extra field/);
    refused(Object.assign(goodProv(), { extra: [1, 2] }), /extra field/);
    refused(Object.assign(goodProv(), { extra: 'x'.repeat(201) }), /extra field/);
    refused(Object.assign(goodProv(), { 'bad key': 1 }), /field name/);
    refused(Object.assign(goodProv(), { '': 1 }), /field name/);
    refused(Object.assign(goodProv(), { ['k'.repeat(41)]: 1 }), /field name/);
    refused(Object.assign(goodProv(), { '1abc': 1 }), /field name/);
  });
  it('prototype-pollution keys (__proto__, constructor, prototype) are refused as own keys and never pollute', () => {
    for (const k of ['__proto__', 'constructor', 'prototype']) {
      const raw = JSON.stringify({ app: 'hyrox-app', version: HD.VERSION, exportedAt: ts, weight: [], workouts: [], nutrition: [], meals: [withProv(goodProv())] })
        .replace('"source":"USDA_FDC"', '"' + k + '":{"polluted":true},"source":"USDA_FDC"');
      assert.ok(raw.includes('"' + k + '":{'), k);
      const s = mk(mem()); const p = s.previewImport(raw);
      assert.equal(p.ok, false, k); assert.match(p.details[0].message, /reserved name/); assert.equal(p.details[0].field, 'components[0].provenance.' + k);
      assert.equal(s.applyImport(raw, { confirm: 'REPLACE' }).ok, false);
      assert.equal({}.polluted, undefined); assert.equal(Object.prototype.polluted, undefined);
    }
    // same keys with scalar values are also refused
    refused(JSON.parse('{"__proto__": 1, "source": "USDA_FDC", "fdcId": 5}'), /reserved name/);
  });
  it('several problems are all reported (not just the first), still before anything is stored', () => {
    const p = goodProv(); p.fdcId = 'x'; p.grams = -1; p.description = 4;
    const r = mk(mem()).previewImport(fileWith(withProv(p)));
    assert.equal(r.ok, false); assert.equal(r.details.length, 3);
  });
});

describe('P7 provenance: a refused or failed import leaves stored data byte-identical', () => {
  const populated = () => {
    const m = mem(); const s = mk(m);
    s.addWeight({ date: '2026-11-10', kg: 80 }); s.putRecord('meals', ordinary('keep-1')); s.putRecord('meals', meal({ id: 'keep-2' }));
    return { m, s, snap: () => JSON.stringify(Object.keys(m.m).sort().map((k) => [k, m.m[k]])) };
  };
  const badFile = () => fileWith(withProv(Object.assign(goodProv(), { fdcId: 'not a number' })));
  it('malformed provenance: preview and apply refuse; every storage key (incl. hyrox.v1) is byte-identical, no write at all', () => {
    const { m, s, snap } = populated(); const before = snap(); m.calls.length = 0;
    const text = badFile();
    assert.equal(s.previewImport(text).ok, false);
    const cur = s.previewImport(fileWith(ordinary('z'))).preview;
    const r = s.applyImport(text, { confirm: 'REPLACE', expectCurrent: cur.current, expectCurrentExt: cur.currentExt });
    assert.equal(r.ok, false); assert.equal(r.code, 'invalid_records');
    assert.equal(snap(), before); assert.equal(m.calls.length, 0, 'not one setItem call');
  });
  it('a good meal next to a bad one: the whole file is refused, nothing is half-restored', () => {
    const { m, s, snap } = populated(); const before = snap();
    const text = JSON.stringify({ app: 'hyrox-app', version: HD.VERSION, exportedAt: ts, weight: [], workouts: [], nutrition: [], meals: [ordinary('good'), withProv(Object.assign(goodProv(), { grams: 'x' }))].map((x, i) => Object.assign(x, { id: 'mm' + i })) });
    const cur = s.previewImport(fileWith(ordinary('q'))).preview;
    assert.equal(s.applyImport(text, { confirm: 'REPLACE', expectCurrent: cur.current, expectCurrentExt: cur.currentExt }).ok, false);
    assert.equal(snap(), before);
  });
  it('quota failure while saving a VALID provenance restore: previous data is put back byte-identical (rollback)', () => {
    const src = mk(mem()); src.putRecord('meals', meal({ id: 'incoming' })); const text = src.exportJSON();
    const m = mem(); const s = mk(m); s.addWeight({ date: '2026-11-10', kg: 80 }); s.putRecord('meals', ordinary('keep-1'));
    const before = m.m[KEY]; const cur = s.previewImport(text).preview;
    let armed = true; const real = m.setItem.bind(m);
    m.setItem = function (k, v) { if (armed && k === KEY) { armed = false; throw new Error('QuotaExceededError'); } return real(k, v); };
    const r = s.applyImport(text, { confirm: 'REPLACE', expectCurrent: cur.current, expectCurrentExt: cur.currentExt });
    armed = false;
    assert.equal(r.ok, false); assert.equal(r.code, 'write_failed'); assert.equal(r.rolledBack, true);
    assert.equal(m.m[KEY], before, 'hyrox.v1 byte-identical');
    assert.equal(mk(m).records('meals').some((x) => x.id === 'incoming'), false);
  });
  it('a torn write during a provenance restore is detected and rolled back to the exact earlier bytes', () => {
    const src = mk(mem()); src.putRecord('meals', meal({ id: 'incoming' })); const text = src.exportJSON();
    const m = mem(); const s = mk(m); s.addWeight({ date: '2026-11-10', kg: 80 });
    const before = m.m[KEY]; const cur = s.previewImport(text).preview;
    let torn = true; const real = m.setItem.bind(m);
    m.setItem = function (k, v) { if (torn && k === KEY) { m.m[k] = String(v).slice(0, 20); torn = false; return; } return real(k, v); };
    const r = s.applyImport(text, { confirm: 'REPLACE', expectCurrent: cur.current, expectCurrentExt: cur.currentExt });
    assert.equal(r.ok, false); assert.equal(r.rolledBack, true); assert.equal(m.m[KEY], before);
  });
  it('the empty-backup second confirmation, and the safety copy, are unaffected by provenance validation', () => {
    const m = mem(); const s = mk(m); s.addWeight({ date: '2026-11-10', kg: 80 }); s.putRecord('meals', meal({ id: 'keep' }));
    const empty = JSON.stringify({ app: 'hyrox-app', version: HD.VERSION, exportedAt: ts, weight: [], workouts: [], nutrition: [] });
    const p = s.previewImport(empty); assert.equal(p.ok, true);
    const r = s.applyImport(empty, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt });
    assert.equal(r.ok, false); assert.equal(r.code, 'empty_replace_not_confirmed');
    assert.equal(s.records('meals').length, 1);
  });
  it('oversize backup text: previewImport/applyImport on huge provenance text refuses fast and changes nothing', () => {
    const { m, s, snap } = populated(); const before = snap();
    const huge = Object.assign(goodProv(), { description: 'd'.repeat(3000000) });
    const text = fileWith(withProv(huge));
    const t0 = Date.now(); const p = s.previewImport(text); assert.equal(p.ok, false); assert.ok(Date.now() - t0 < 2000);
    assert.equal(snap(), before);
  });
});

describe('P7 provenance: nothing else changed', () => {
  it('a confirmed estimated meal still counts toward the day; a draft still does not', () => {
    const s = mk(mem()); s.putRecord('meals', meal({ id: 'd1' })); s.putRecord('meals', meal({ id: 'c1', lifecycle: 'CONFIRMED', confirmedAt: ts }));
    const d = HN.dayState(DAY, s.records('meals'), null); assert.equal(d.confirmedCount, 1);
  });
  it('validator rejects a provenance on a meal whose other fields are fine, without touching other validation messages', () => {
    const r = mk(mem()).putRecord('meals', Object.assign(withProv(goodProv()), { lifecycle: 'WHATEVER' }));
    assert.equal(r.ok, false);
  });
});
