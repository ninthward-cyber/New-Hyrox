'use strict';
// P5 Meron RED tests for P4-F01: an export this build's own restore would refuse must never
// be labelled verified/restorable. Check is parseImport of the exact export text. Raw recovery
// bytes are preserved; nothing is rewritten to make the export pass.
// Against baseline df5bb7b these must FAIL for the right reason (exportChecked is missing
// and/or restorable is not reported false).
// Contract: /workspace/hyrox-p5/CONTRACT.md. Synthetic data only. Does not edit src/.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const {
  HD, TS, KEY, PRE, RECOVERY,
  mem, mk, validWeight, plant,
} = require('./p5-meron-helpers.js');

function baseData(extra) {
  return Object.assign({
    version: 2,
    weight: [],
    workouts: [],
    nutrition: [],
  }, extra || {});
}

function planted(data) {
  const raw = JSON.stringify(data);
  const s = mem();
  plant(s, raw);
  return { s, st: mk(s), raw, before: s.snapshot() };
}

function mustBeUnrestorable(st, s, before, why) {
  assert.equal(typeof st.exportChecked, 'function',
    'store.exportChecked() must exist (missing on baseline) — ' + why);
  const chk = st.exportChecked();
  assert.equal(chk.ok, true, why + ': exportChecked failed: ' + JSON.stringify(chk).slice(0, 300));
  assert.equal(typeof chk.text, 'string');
  assert.equal(chk.restorable, false,
    why + ': exportChecked.restorable must be false when this build would refuse the exact export text');
  assert.ok(Array.isArray(chk.reasons), why + ': reasons must be an array');
  assert.ok(chk.reasons.length >= 1, why + ': reasons must name why restore would refuse');
  assert.equal(typeof chk.reasonsTotal, 'number');
  assert.equal(typeof chk.reasonsTruncated, 'boolean');
  // The check is over the exact export text: this build's restore must refuse that text.
  const p = st.previewImport(chk.text);
  assert.equal(p.ok, false, why + ': sanity: this build accepted its own export, so the fixture is wrong: ' + JSON.stringify(p).slice(0, 200));

  // exportSummary() is UNCHANGED (an existing test pins its exact shape). The restorable
  // flag lives on exportChecked() and on the rawRecoveryExport() result object.
  const rec = st.rawRecoveryExport();
  assert.equal(rec.ok, true, why + ': rawRecoveryExport must still succeed');
  assert.equal(rec.normalRestorable, false, why + ': rawRecoveryExport.normalRestorable must be false');
  assert.ok(Array.isArray(rec.normalRestorableReasons));
  assert.ok(typeof rec.warning === 'string' && rec.warning.length > 0);
  const sources = rec.sources || [];
  const keySrc = sources.find((x) => x && x.key === KEY);
  assert.ok(keySrc, why + ': raw recovery must include the hyrox.v1 source');
  assert.equal(JSON.parse(rec.text).sources.find((x) => x.key === KEY).raw, s.getItem(KEY),
    why + ': raw recovery must preserve the exact stored hyrox.v1 bytes');
  assert.equal(s.snapshot(), before, why + ': export/check/raw recovery must not write');
  return { chk, p, rec };
}

describe('P4-F01 holds: a clean export of valid data is restorable; raw recovery is read-only', () => {
  it('a device with one valid weight exports a file this build accepts, and may be labelled restorable once exportChecked exists', () => {
    const { s, st, before } = planted(baseData({ weight: [validWeight()] }));
    const text = st.exportJSON();
    const p = st.previewImport(text);
    assert.equal(p.ok, true, 'clean export must still restore: ' + JSON.stringify(p).slice(0, 200));
    const a = st.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt });
    assert.equal(a.ok, true);
    // Re-plant for a read-only check if the API exists.
    plant(s, baseData({ weight: [validWeight()] }));
    if (typeof st.exportChecked === 'function') {
      const chk = st.exportChecked();
      assert.equal(chk.ok, true);
      assert.equal(chk.restorable, true, 'clean export must be restorable: ' + JSON.stringify(chk.reasons || chk).slice(0, 200));
      const rec = st.rawRecoveryExport();
      assert.equal(rec.ok, true);
      assert.equal(rec.normalRestorable, true);
    }
  });
});

describe('DEFECT P4-F01: exports this build would refuse must not be labelled verified/restorable; raw bytes preserved', () => {
  it('duplicate classic ids: exportJSON text is refused by restore and must be restorable:false', () => {
    const { s, st, before } = planted(baseData({
      weight: [validWeight('dup', 80), validWeight('dup', 81, '2026-11-09')],
    }));
    const text = st.exportJSON();
    const p = st.previewImport(text);
    assert.equal(p.ok, false, 'sanity: this build must refuse duplicate ids, got ' + JSON.stringify(p).slice(0, 200));
    assert.equal(p.code, 'duplicate_ids');
    const { chk } = mustBeUnrestorable(st, s, before, 'duplicate ids');
    assert.ok(chk.reasons.some((r) => r && (r.code === 'duplicate_ids' || /duplicate/i.test(String(r.code) + String(r.message)))),
      'reasons should mention duplicate ids: ' + JSON.stringify(chk.reasons).slice(0, 300));
    // exportJSON itself is unchanged and must not have rewritten storage.
    assert.equal(s.getItem(KEY), JSON.stringify(baseData({
      weight: [validWeight('dup', 80), validWeight('dup', 81, '2026-11-09')],
    })));
  });

  it('date skew (stored future date included in the export): restore refuses and restorable must be false', () => {
    const future = validWeight('w-fut', 80, '2027-06-01');
    const { s, st, before } = planted(baseData({ weight: [future] }));
    const text = st.exportJSON();
    const exported = JSON.parse(text);
    assert.ok(exported.weight.some((w) => w.date === '2027-06-01'), 'exportJSON should include the stored future-dated entry (isValidEntry is loose)');
    const p = st.previewImport(text);
    assert.equal(p.ok, false, 'sanity: this build must refuse the future date, got ' + JSON.stringify(p).slice(0, 200));
    assert.equal(p.code, 'invalid_records');
    mustBeUnrestorable(st, s, before, 'date skew / future date');
  });

  it('invalid classic entry that still passes isValidEntry (kg out of range) is exported, refused on restore, and must be restorable:false', () => {
    const bad = { id: 'w-bad', createdAt: TS, date: '2026-11-10', kg: 999 };
    const { s, st, before } = planted(baseData({ weight: [bad] }));
    const text = st.exportJSON();
    assert.ok(JSON.parse(text).weight.some((w) => w.kg === 999), 'kg 999 is still a stored entry with id+date, so exportJSON includes it');
    const p = st.previewImport(text);
    assert.equal(p.ok, false, 'sanity: this build must refuse kg 999, got ' + JSON.stringify(p).slice(0, 200));
    assert.equal(p.code, 'invalid_records');
    mustBeUnrestorable(st, s, before, 'invalid classic kg');
  });

  it('exportChecked does not omit, rewrite, or delete records just to make the text restorable', () => {
    const { st } = planted(baseData({
      weight: [validWeight('dup', 80), validWeight('dup', 81, '2026-11-09')],
    }));
    assert.equal(typeof st.exportChecked, 'function', 'exportChecked() must exist (missing on baseline)');
    const chk = st.exportChecked();
    assert.equal(chk.ok, true);
    const exported = JSON.parse(chk.text);
    assert.equal(exported.weight.length, 2, 'both duplicate entries must still be in the export text; the check must not drop one to make it pass');
    assert.equal(chk.restorable, false);
    const p = st.previewImport(chk.text);
    assert.equal(p.ok, false);
  });
});

describe('P4-F01 consistency: restorable flag must match this build\'s own previewImport of the exact export text', () => {
  it('exportChecked.restorable is true only when previewImport accepts the exact text, and false only when it refuses (vice versa)', () => {
    const fixtures = [
      ['clean', { weight: [validWeight()] }],
      ['duplicate ids', { weight: [validWeight('dup', 80), validWeight('dup', 81, '2026-11-09')] }],
      ['future date', { weight: [validWeight('w-fut', 80, '2027-06-01')] }],
      ['invalid kg', { weight: [{ id: 'w-bad', createdAt: TS, date: '2026-11-10', kg: 999 }] }],
    ];
    for (const [name, extra] of fixtures) {
      const { st } = planted(baseData(extra));
      assert.equal(typeof st.exportChecked, 'function', 'exportChecked() must exist (missing on baseline)');
      const chk = st.exportChecked();
      assert.equal(chk.ok, true, name + ': ' + JSON.stringify(chk).slice(0, 200));
      const p = st.previewImport(chk.text);
      assert.equal(chk.restorable, p.ok, name + ': restorable=' + chk.restorable + ' but previewImport.ok=' + p.ok + ' ' + JSON.stringify({ code: p.code, reasons: chk.reasons }).slice(0, 250));
    }
  });
});

