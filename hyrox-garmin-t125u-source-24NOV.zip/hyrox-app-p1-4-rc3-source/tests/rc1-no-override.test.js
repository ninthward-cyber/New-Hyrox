'use strict';
// RC1: the deploy package must ship NO date/clock override, feature flag, query parameter, hash switch or debug hook.
// Block 2 activation is tested only with Playwright's test clock (tests/e2e/rc1-activation-clock.spec.js).
// This builds the deploy package fresh and greps every publish/ file.
// P0 (22 Nov 2026, owner-authorised): 'hyrox.backup-note' joins the known storage keys - the date of the last backup download
// started on this device. It is read for one reminder line only and can switch nothing on.
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs'), os = require('os'), path = require('path'), { execFileSync } = require('child_process');

const ROOT = path.join(__dirname, '..');
const FORBIDDEN = [
  [/location\s*\.\s*(search|hash|href)\b/, 'reads the URL (query/hash)'],
  [/URLSearchParams/, 'query parameter parsing'],
  [/\bhashchange\b|\bpopstate\b/, 'hash/history switch'],
  [/\bdebugger\b/, 'debugger statement'],
  [/\b(DEBUG|__DEV__|__TEST__|TEST_MODE|FAKE_?NOW|MOCK_?DATE|testClock|fakeClock|clockOverride|dateOverride|overrideDate|overrideToday|simulat\w*Date|nowOverride)\b/i, 'debug/test flag or clock override'],
  [/(^|[^\w.$])(window\s*\.\s*)?Date\s*=(?!=)|\bDate\.now\s*=(?!=)|\bDate\.prototype\.\w+\s*=(?!=)/, 'Date replacement'],
  [/window\s*\.\s*(__\w+|hyroxDebug|HyroxDebug|HyroxTest)\b/, 'global debug hook'],
  [/sessionStorage|document\.cookie/, 'other storage used as a switch'],
  [/['"]hyrox\.(?!v1['"]|v1\.corrupt-backup['"]|v1\.pre-import-backup['"]|ai-settings['"]|ai-owner-code['"]|ui\.workout-draft['"]|ui\.meal-draft['"]|backup-note['"])[A-Za-z0-9.\-]+['"]/, 'unknown storage key'], /* RE-POINTED by Sprint B2 (owner decision M1, 23 Nov 2026): + UI-only key hyrox.ui.meal-draft */
];
function scan(text) { const hits = []; for (const [re, why] of FORBIDDEN) { const m = text.match(re); if (m) hits.push(why + ': ' + m[0]); } return hits; }

let out;
test.before(() => { out = fs.mkdtempSync(path.join(os.tmpdir(), 'rc1-nooverride-')); execFileSync(process.execPath, [path.join(ROOT, 'tools/build-deploy-package.mjs'), out]); });
test.after(() => fs.rmSync(out, { recursive: true, force: true }));

test('RC1-NO-OVERRIDE: the scanner itself catches each kind of hook (self-check)', () => {
  for (const s of ["var q = new URLSearchParams(location.search);", "if (location.hash === '#dec') {}", "window.__now = 1;", "var FAKE_NOW = '2026-12-11';",
    "Date.now = function(){};", "window.Date = FakeDate;", "Date = X;", "localStorage.getItem('hyrox.debug-date')", "debugger;", "sessionStorage.x", "function overrideToday(){}"]) assert.ok(scan(s).length > 0, s);
  assert.deepStrictEqual(scan("var KEY = 'hyrox.v1'; localStorage.getItem('hyrox.ai-settings'); location.reload(); location.protocol; var nowDate = 1; if (x.Date === y) {}"), []);
});

test('RC1-NO-OVERRIDE: publish/ is exactly the app files (17 since P1.1, 18 since P1.3) and none contains an override, flag, query parameter or debug hook', () => {
  const pub = path.join(out, 'publish'); const files = [];
  (function walk(d) { for (const f of fs.readdirSync(d)) { const p = path.join(d, f); fs.statSync(p).isDirectory() ? walk(p) : files.push(path.relative(pub, p)); } })(pub);
  assert.strictEqual(files.length, 20); // RE-POINTED R8 (24 Nov 2026): +src/integrations/garmin-import.js -> 20; Sprint D added hyrox-coach-export.js; P1.3 added hyrox-coach.js
  const all = [];
  // t111u: the Garmin test hook is no longer in product/deploy code. Offline e2e
  // injects isEnabled after load. Any debug hook in publish/ fails this test.
  for (const f of files) for (const h of scan(fs.readFileSync(path.join(pub, f), 'utf8'))) {
    all.push(f + ' → ' + h);
  }
  assert.deepStrictEqual(all, []);
});

test('RC1-NO-OVERRIDE: dates are the shipped constants and "today" is the real Asia/Qatar clock with no parameter', () => {
  const blocks = fs.readFileSync(path.join(out, 'publish/src/data/hyrox-blocks.js'), 'utf8');
  assert.match(blocks, /var FIRST_START = '2026-12-14';/);
  assert.match(blocks, /var DECISION_FROM = '2026-12-11';/);
  const ext = fs.readFileSync(path.join(out, 'publish/src/ui/app-ext.js'), 'utf8');
  assert.match(ext, /function today\(\) \{ return HD\.todayQatar\(\); \}/);
  const data = fs.readFileSync(path.join(out, 'publish/src/data/hyrox-data.js'), 'utf8');
  assert.match(data, /timeZone: 'Asia\/Qatar'/);
  // the netlify function and lib must not carry a client date switch either
  for (const f of ['netlify/functions/food-photo.mjs']) assert.deepStrictEqual(scan(fs.readFileSync(path.join(out, f), 'utf8')).filter((h) => !/storage key/.test(h)), []);
});
