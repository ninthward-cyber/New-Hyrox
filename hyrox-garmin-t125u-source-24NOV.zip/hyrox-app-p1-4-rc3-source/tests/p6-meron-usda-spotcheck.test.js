'use strict';
// P6 Meron: spot-check ~50 bundled food-DB rows against the authoritative USDA
// source files in /workspace/hyrox-p6/food-data-feasibility/ (no API key, no DEMO_KEY).
// Fixture tests/fixtures/p6-usda-spotcheck.json lists the FDC IDs and the official
// per-100 g values + portions independently extracted from those zips.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const FIXTURE = path.join(__dirname, 'fixtures/p6-usda-spotcheck.json');
const DB_PATH = path.resolve(__dirname, '../src/data/food-db.json');
const fixture = JSON.parse(fs.readFileSync(FIXTURE, 'utf8'));
const db = JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
const byId = new Map((db.foods || []).map((row) => [row[0], row]));

const REF = [171287, 168878, 171265, 171413];
const TOL = fixture.tolerance;
const FIELDS = [
  ['kcal', 3],
  ['proteinG', 4],
  ['carbsG', 5],
  ['fatG', 6],
];

function diffsFor(food) {
  const row = byId.get(food.fdcId);
  const diffs = [];
  if (!row) {
    diffs.push({ field: 'presence', db: null, usda: 'present in USDA extract', diff: 'MISSING_FROM_DB' });
    return diffs;
  }
  if (row[1] !== food.dataset) {
    diffs.push({ field: 'dataset', db: row[1], usda: food.dataset, diff: 'dataset' });
  }
  for (const [key, idx] of FIELDS) {
    const dbv = row[idx];
    const usdav = food[key];
    if (dbv !== usdav) {
      const d = (typeof dbv === 'number' && typeof usdav === 'number') ? +(dbv - usdav).toFixed(6) : 'ne';
      diffs.push({ field: key, db: dbv, usda: usdav, usdaRaw: food[key + 'Raw'], diff: d });
    }
  }
  const dbPor = row[7] || [];
  const usdaPor = food.portions || [];
  if (JSON.stringify(dbPor) !== JSON.stringify(usdaPor)) {
    diffs.push({ field: 'portions', db: dbPor, usda: usdaPor, diff: 'portions' });
  }
  return diffs;
}

describe('P6 Meron USDA spot-check of the bundled food DB (no API key)', () => {
  it('the fixture lists 50 FDC IDs including the four reference foods and has official values for each', () => {
    assert.equal(fixture.ids.length, 50);
    assert.equal(fixture.foods.length, 50);
    assert.deepEqual(new Set(fixture.ids), new Set(fixture.foods.map((f) => f.fdcId)));
    for (const id of REF) assert.ok(fixture.ids.includes(id), 'missing reference FDC ' + id);
    assert.equal(TOL.kcalAbs, 0);
    assert.equal(TOL.macroGAbs, 0);
    assert.match(String(TOL.per100g), /exact match after the documented DB rounding/i);
  });

  it('every listed food matches the official USDA extract exactly after documented rounding (kcal 1 decimal, macros 2 decimals, portion grams 2 decimals)', () => {
    const mismatches = [];
    for (const food of fixture.foods) {
      const diffs = diffsFor(food);
      if (diffs.length) mismatches.push({ fdcId: food.fdcId, dataset: food.dataset, description: food.description, diffs });
    }
    if (mismatches.length) {
      const lines = mismatches.map((m) => {
        const bits = m.diffs.map((d) => d.field + ': db=' + JSON.stringify(d.db) + ' usda=' + JSON.stringify(d.usda) + ' diff=' + JSON.stringify(d.diff));
        return 'FDC ' + m.fdcId + ' (' + m.dataset + ' ' + m.description + '): ' + bits.join('; ');
      });
      assert.fail(mismatches.length + ' of ' + fixture.foods.length + ' foods differ from the USDA extract.\nTolerance: exact after documented rounding.\n' + lines.join('\n'));
    }
    assert.equal(mismatches.length, 0);
    assert.equal(fixture.foods.length, 50);
  });

  it('the four reference foods keep their official per-100 g values and key portions', () => {
    const expect = {
      171287: { kcal: 143, proteinG: 12.56, carbsG: 0.72, fatG: 9.51, portion: [1, 'large', 50] },
      168878: { kcal: 130, proteinG: 2.69, carbsG: 28.17, fatG: 0.28, portion: [1, 'cup', 158] },
      171265: { kcal: 61, proteinG: 3.15, carbsG: 4.8, fatG: 3.25, portion: [1, 'cup', 244] },
      171413: { kcal: 884, proteinG: 0, carbsG: 0, fatG: 100, portion: [1, 'tablespoon', 13.5] },
    };
    for (const id of REF) {
      const food = fixture.foods.find((f) => f.fdcId === id);
      const row = byId.get(id);
      assert.ok(food && row, 'reference FDC ' + id);
      const exp = expect[id];
      assert.equal(row[3], exp.kcal);
      assert.equal(row[4], exp.proteinG);
      assert.equal(row[5], exp.carbsG);
      assert.equal(row[6], exp.fatG);
      assert.equal(food.kcal, exp.kcal);
      assert.equal(food.proteinG, exp.proteinG);
      assert.deepEqual(row[7].find((p) => p[0] === exp.portion[0] && p[1] === exp.portion[1]), exp.portion);
    }
  });

  it('Foundation FDC 2727566 keeps the official slightly negative carbohydrate-by-difference (estimator clamp is separate)', () => {
    const food = fixture.foods.find((f) => f.fdcId === 2727566);
    const row = byId.get(2727566);
    assert.ok(food && row);
    assert.ok(food.carbsG < 0, 'USDA carbs should be negative: ' + food.carbsG);
    assert.equal(row[5], food.carbsG);
  });
});
