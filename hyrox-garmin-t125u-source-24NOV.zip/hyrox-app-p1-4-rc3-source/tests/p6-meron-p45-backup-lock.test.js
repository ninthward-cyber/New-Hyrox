'use strict';
// P6 Meron regression lock: every Phase 4/5 backup protection, plus Claude's 10M import
// cap and the NOT-RESTORABLE export filename pattern. Must PASS on baseline c5cdd73
// and still pass after Phase 6. Independent of existing p4/p5 files (those are not edited).
// Synthetic data only. Byte-exact messages and constants where the source pins them.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const {
  HD, TS, KEY, PRE,
  mem, faultStorage, mk, validWeight, storedPopulated, emptyBackup, backup, plant, applyReplace,
} = require('./p6-meron-helpers.js');

const EMPTY_MSG = 'Not restored: this backup is empty, and restoring it would replace the data on this device with nothing. Nothing was changed. Confirm a second time to restore an empty backup.';
const PRIOR_MSG = 'Not restored: an earlier restore did not finish, and the only saved copy of your previous data is kept in this browser under ' + PRE + '. A new restore would overwrite it, so nothing was changed. Save a raw recovery copy first and do not clear site data.';
const TOO_LARGE_MSG = 'This file is too large to be a HYROX backup (limit 10 million characters, about 10 MB).';

describe('P6 lock P4-O1: empty replace needs confirmEmptyReplace === true', () => {
  it('IMPORT constants and the exact empty_replace_not_confirmed message are unchanged', () => {
    assert.deepEqual({ ...HD.IMPORT_LIMITS }, { maxBytes: 10000000, maxPerList: 10000 });
    assert.equal(HD.STORAGE_KEY, 'hyrox.v1');
    assert.equal(HD.IMPORT_BACKUP_KEY, 'hyrox.v1.pre-import-backup');
    assert.equal(HD.RECOVERY_KEY, 'hyrox.v1.corrupt-backup');
  });

  it('preview flags emptyReplacesPopulated and replaceSummary for an empty file onto populated data', () => {
    const s = mem();
    plant(s, storedPopulated());
    const st = mk(s);
    const p = st.previewImport(emptyBackup());
    assert.equal(p.ok, true);
    assert.equal(p.preview.emptyReplacesPopulated, true);
    assert.equal(p.preview.replaceSummary.incoming.total, 0);
    assert.ok(p.preview.replaceSummary.current.total >= 1);
    assert.equal(p.preview.replaceSummary.current.weight, 1);
    assert.equal(s.getItem(KEY), storedPopulated());
  });

  it('applyImport with only confirm:REPLACE is refused, writes nothing, and uses the exact message', () => {
    const s = mem();
    const raw = plant(s, storedPopulated());
    const before = s.snapshot();
    const st = mk(s);
    const a = applyReplace(st, emptyBackup());
    assert.equal(a.ok, false);
    assert.equal(a.code, 'empty_replace_not_confirmed');
    assert.equal(a.message, EMPTY_MSG);
    assert.equal(a.rolledBack, false);
    assert.equal(a.backupKey == null, true);
    assert.equal(s.getItem(KEY), raw);
    assert.equal(s.snapshot(), before);
  });

  it('confirmEmptyReplace is a strict boolean: "true", 1, "YES", and {} are refused and write nothing', () => {
    for (const bad of ['true', 1, 'YES', {}]) {
      const s = mem();
      const raw = plant(s, storedPopulated());
      const before = s.snapshot();
      const a = applyReplace(mk(s), emptyBackup(), { confirmEmptyReplace: bad });
      assert.equal(a.ok, false, String(bad));
      assert.equal(a.code, 'empty_replace_not_confirmed', String(bad));
      assert.equal(s.getItem(KEY), raw);
      assert.equal(s.snapshot(), before);
    }
  });

  it('confirmEmptyReplace:true with confirm:REPLACE restores an empty backup onto populated data', () => {
    const s = mem();
    plant(s, storedPopulated());
    const st = mk(s);
    const a = applyReplace(st, emptyBackup(), { confirmEmptyReplace: true });
    assert.equal(a.ok, true);
    assert.equal(st.list('weight').length, 0);
  });

  it('empty onto empty still restores with only confirm:REPLACE (no second confirm)', () => {
    const s = mem();
    const st = mk(s);
    const a = applyReplace(st, emptyBackup());
    assert.equal(a.ok, true);
    assert.equal(st.list('weight').length, 0);
  });

  it('confirmEmptyReplace:true is ignored on a non-empty restore', () => {
    const s = mem();
    plant(s, storedPopulated());
    const st = mk(s);
    const text = backup({ weight: [validWeight('w-in', 77)] });
    const a = applyReplace(st, text, { confirmEmptyReplace: true });
    assert.equal(a.ok, true);
    assert.equal(st.list('weight')[0].kg, 77);
  });
});

describe('P6 lock P4-F02: pending pre-import slot fails closed and is not overwritten', () => {
  it('after rollback_failed, a second restore is prior_copy_unresolved with the exact message; the slot is byte-identical', () => {
    // First KEY set is truncated (write_failed); later KEY sets throw so rollback fails.
    let keySets = 0;
    const s = faultStorage({ [KEY]: storedPopulated() }, {
      set: (k) => {
        if (k !== KEY) return;
        keySets += 1;
        if (keySets === 1) return 'truncate';
        return 'throw';
      },
    });
    const st = mk(s);
    const first = applyReplace(st, backup({ weight: [validWeight('w-x', 70)] }));
    assert.equal(first.ok, false);
    assert.equal(first.code, 'rollback_failed');
    const slot = s.getItem(PRE);
    assert.ok(typeof slot === 'string' && slot.length > 0);
    const env = JSON.parse(slot);
    assert.equal(env.restoreState, 'pending');
    const snap = s.snapshot();
    const second = applyReplace(st, backup({ weight: [validWeight('w-y', 71)] }));
    assert.equal(second.ok, false);
    assert.equal(second.code, 'prior_copy_unresolved');
    assert.equal(second.message, PRIOR_MSG);
    assert.equal(second.backupKey, PRE);
    assert.equal(s.getItem(PRE), slot);
    assert.equal(s.snapshot(), snap);
  });

  it('a planted pending slot whose raw differs from live KEY blocks restore and is not overwritten', () => {
    const original = storedPopulated();
    const liveNow = JSON.stringify({ version: 2, weight: [validWeight('w-torn', 1)], workouts: [], nutrition: [] });
    const slot = JSON.stringify({ kind: 'hyrox-pre-import', savedAt: TS, raw: original, restoreState: 'pending' });
    const s = mem({ [KEY]: liveNow, [PRE]: slot });
    const st = mk(s);
    const before = s.snapshot();
    const p = st.previewImport(backup({ weight: [validWeight('w-x', 70)] }));
    assert.equal(p.ok, true);
    assert.equal(p.preview.priorCopy.blocksRestore, true);
    assert.equal(p.preview.priorCopy.restoreState, 'pending');
    const a = applyReplace(st, backup({ weight: [validWeight('w-x', 70)] }));
    assert.equal(a.ok, false);
    assert.equal(a.code, 'prior_copy_unresolved');
    assert.equal(s.getItem(PRE), slot);
    assert.equal(s.getItem(KEY), liveNow);
    assert.equal(s.snapshot(), before);
  });

  it('the first ordinary restore on a device with no pre-import slot still succeeds', () => {
    const s = mem();
    plant(s, storedPopulated());
    const st = mk(s);
    const a = applyReplace(st, backup({ weight: [validWeight('w-x', 70)] }));
    assert.equal(a.ok, true);
    const env = JSON.parse(s.getItem(PRE));
    assert.ok(env.restoreState === 'completed' || env.restoreState === 'pending' || env.restoreState === undefined);
    assert.equal(st.list('weight')[0].id, 'w-x');
  });
});

describe('P6 lock P4-F01: exportChecked restorable/reasons and rawRecoveryExport', () => {
  it('a clean export is restorable; raw recovery is read-only and preserves KEY bytes', () => {
    const s = mem();
    const raw = plant(s, storedPopulated());
    const st = mk(s);
    const before = s.snapshot();
    const chk = st.exportChecked();
    assert.equal(chk.ok, true);
    assert.equal(chk.restorable, true);
    assert.ok(Array.isArray(chk.reasons));
    const recov = st.rawRecoveryExport();
    assert.equal(recov.ok, true);
    assert.equal(recov.normalRestorable, true);
    const file = JSON.parse(recov.text);
    const src = file.sources.find((x) => x.key === KEY);
    assert.equal(src.raw, raw);
    assert.equal(s.snapshot(), before);
  });

  it('duplicate ids: exportChecked.restorable is false, reasons are present, raw bytes preserved, no writes', () => {
    const stored = {
      version: 2,
      weight: [validWeight('w-dup', 80), validWeight('w-dup', 81)],
      workouts: [], nutrition: [],
    };
    const s = mem();
    const raw = plant(s, stored);
    const before = s.snapshot();
    const st = mk(s);
    const chk = st.exportChecked();
    assert.equal(chk.ok, true);
    assert.equal(chk.restorable, false);
    assert.ok(chk.reasons.length >= 1);
    const p = st.previewImport(chk.text);
    assert.equal(p.ok, false);
    const recov = st.rawRecoveryExport();
    assert.equal(recov.normalRestorable, false);
    const file = JSON.parse(recov.text);
    assert.equal(file.sources.find((x) => x.key === KEY).raw, raw);
    assert.equal(s.snapshot(), before);
  });

  it('date skew and an invalid classic kg are unrestorable and the restorable flag matches previewImport', () => {
    for (const entry of [
      { id: 'w-future', createdAt: TS, date: '2027-06-01', kg: 80 },
      { id: 'w-heavy', createdAt: TS, date: '2026-11-12', kg: 999 },
    ]) {
      const s = mem();
      plant(s, { version: 2, weight: [entry], workouts: [], nutrition: [] });
      const st = mk(s);
      const before = s.snapshot();
      const chk = st.exportChecked();
      const p = st.previewImport(chk.text);
      assert.equal(chk.ok, true);
      assert.equal(chk.restorable, false);
      assert.equal(chk.restorable, p.ok);
      assert.ok(chk.reasons.length >= 1);
      assert.equal(s.snapshot(), before);
    }
  });
});

describe('P6 lock Claude 10M import cap', () => {
  it('IMPORT_LIMITS.maxBytes is exactly 10000000 and the too_large message is byte-exact', () => {
    assert.equal(HD.IMPORT_LIMITS.maxBytes, 10000000);
    const s = mem();
    const st = mk(s);
    const oversized = '{' + ' '.repeat(HD.IMPORT_LIMITS.maxBytes) + '}'; // length = maxBytes + 2
    assert.equal(oversized.length > HD.IMPORT_LIMITS.maxBytes, true);
    const p = st.previewImport(oversized);
    assert.equal(p.ok, false);
    assert.equal(p.code, 'too_large');
    assert.equal(p.message, TOO_LARGE_MSG);
  });

  it('a file of length maxBytes+1 is refused as too_large before JSON.parse runs', () => {
    const st = mk(mem());
    const text = 'x'.repeat(HD.IMPORT_LIMITS.maxBytes + 1);
    const orig = JSON.parse;
    let parsed = 0;
    JSON.parse = function () { parsed += 1; return orig.apply(this, arguments); };
    let r;
    try { r = st.previewImport(text); } finally { JSON.parse = orig; }
    assert.equal(r.code, 'too_large');
    assert.equal(r.message, TOO_LARGE_MSG);
    assert.equal(parsed, 0);
  });

  it('a valid backup of exactly maxBytes characters is not refused as too_large', () => {
    const st = mk(mem());
    const base = JSON.stringify(Object.assign({
      app: 'hyrox-app', version: 2, exportedAt: TS,
      weight: [validWeight()], workouts: [], nutrition: [], pad: '',
    }), null, 2);
    const text = base.replace('"pad": ""', '"pad": "' + 'x'.repeat(HD.IMPORT_LIMITS.maxBytes - base.length) + '"');
    assert.equal(text.length, HD.IMPORT_LIMITS.maxBytes);
    const p = st.previewImport(text);
    assert.notEqual(p.code, 'too_large');
    assert.equal(p.ok, true);
  });
});

describe('P6 lock NOT-RESTORABLE export filename pattern (data layer + documented UI rule)', () => {
  it('the UI rule is a suffix on the normal backup name: hyrox-backup-<today>-NOT-RESTORABLE.json when not restorable', () => {
    // The data layer does not name the normal export file; the UI (app.js downloadText) does.
    // Lock the exact source string so Phase 6 cannot drop the suffix.
    const src = require('node:fs').readFileSync(require('node:path').resolve(__dirname, '../src/ui/app.js'), 'utf8');
    const m = src.match(/downloadText\(text,\s*'hyrox-backup-'\s*\+\s*today\(\)\s*\+\s*\(checked\s*&&\s*!checked\.restorable\s*\?\s*'-NOT-RESTORABLE'\s*:\s*''\)\s*\+\s*'\.json'\)/);
    assert.ok(m, 'app.js must keep the NOT-RESTORABLE suffix on unrestorable exports');
    assert.match(src, /its name ends in NOT-RESTORABLE/);
  });
});
