'use strict';
// Claude's 22 S1-S5 probes (11 were FAIL on the prior candidate). Regression: spawn the committed probe.
const test = require('node:test');
const assert = require('node:assert/strict');
const { spawnSync } = require('node:child_process');
const path = require('node:path');
const fs = require('node:fs');

const ROOT = path.resolve(__dirname, '..');
const PROBE = path.join(__dirname, 'probes/s1s5_probe.js');
const FIX = path.join(__dirname, 'fixtures/garmin');
const OLD = process.env.P13_RC3_SRC || '/workspace/hyrox-garmin-build/vendor/p1-3-rc3-b1de280e2a65';

test('Claude S1-S5 probes: 22/22 PASS (including the 11 formerly failing checks)', (t) => {
  if (!fs.existsSync(OLD)) { t.skip('P1.3-RC3 vendor tree not present at ' + OLD); return; }
  const r = spawnSync(process.execPath, [PROBE, ROOT, FIX, OLD], { encoding: 'utf8', timeout: 20000 });
  const out = (r.stdout || '') + (r.stderr || '');
  const passes = (out.match(/^PASS /gm) || []).length;
  const fails = (out.match(/^FAIL /gm) || []).length;
  assert.equal(r.status, 0, out);
  assert.equal(fails, 0, out);
  assert.equal(passes, 22, out);
  assert.match(out, /SUMMARY: 0 failing probe\(s\)/);
});
