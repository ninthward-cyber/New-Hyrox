'use strict';
// P4-D5 (Dawit): ONE recursive (iterative) emergency-marker scan in parseImport, replacing the
// depth-limited scanner of 9e9f2e1. Covers Meron's r2 bypasses (p4/qa 5d2c527): sources at any
// wrapper depth or in array wrappers, leftover markers at depth, planted emergency copies
// {key, raw, checksum, length} inside Phase 3 records; plus a fail-closed depth cap (64).
// Synthetic data only.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const { HD, KEY, PRE, mem, mk, O, K, ts, backup, restore } = require('./p3-helpers.js');

const D = '2026-11-10', WED = '2026-11-04', SAT = '2026-11-07', SUN = '2026-11-08';
const snapAll = (s) => JSON.stringify(Object.keys(s.m).sort().map((k) => [k, s.m[k]]));
const ok = (r, what) => { assert.equal(r.ok, true, what + ': ' + JSON.stringify(r)); return r; };

function liveDevice() {
  const s = mem();
  const st = mk(s);
  ok(st.addWeight({ date: D, kg: 80 }), 'weight');
  ok(st.putRecord('walks', { date: D, durationMin: 30, steps: 3000 }), 'walk');
  const p = ok(st.previewImport(st.exportJSON()), 'self preview');
  return { s, st, current: p.preview.current, currentExt: p.preview.currentExt, before: snapAll(s), writes: s.writes };
}
function emptyCore(extra) {
  return Object.assign({ app: 'hyrox-app', version: 2, exportedAt: ts, weight: [], workouts: [], nutrition: [] }, extra || {});
}
// Real emergency copies, taken from rawRecoveryExport of a seeded device.
function realCopies() {
  const s = mem(); const st = mk(s);
  ok(st.addWeight({ date: D, kg: 81 }), 'seed');
  const r = ok(st.rawRecoveryExport(), 'raw export');
  const o = JSON.parse(r.text);
  assert.ok(Array.isArray(o.sources) && o.sources.length >= 1);
  assert.deepEqual(Object.keys(o.sources[0]).sort(), ['checksum', 'key', 'length', 'raw']);
  return o.sources;
}
// Refused on BOTH paths with raw_recovery_file; zero writes; every storage key byte-identical.
function refused(text, re) {
  const { s, st, current, currentExt, before, writes } = liveDevice();
  const p = st.previewImport(text);
  assert.equal(p.ok, false, 'previewImport must refuse: ' + JSON.stringify(p).slice(0, 300));
  assert.equal(p.code, 'raw_recovery_file');
  assert.match(p.message, /emergency raw recovery/i);
  assert.match(p.message, /not a normal backup/);
  assert.match(p.message, /nothing was changed/i);
  if (re) assert.match(p.message, re);
  assert.ok(p.message.length < 400, p.message.length);
  assert.equal(s.writes, writes, 'preview writes nothing');
  assert.equal(snapAll(s), before);
  const a = st.applyImport(text, { confirm: 'REPLACE', expectCurrent: current, expectCurrentExt: currentExt });
  assert.equal(a.ok, false, 'applyImport must refuse: ' + JSON.stringify(a).slice(0, 300));
  assert.equal(a.code, 'raw_recovery_file');
  assert.equal(a.message, p.message);
  assert.equal(s.writes, writes, 'apply writes nothing');
  assert.equal(snapAll(s), before);
  assert.equal(Object.prototype.hasOwnProperty.call(s.m, PRE), false, 'no pre-import slot written');
  assert.equal(st.list('weight').length, 1);
  assert.equal(st.list('weight')[0].kg, 80);
  assert.equal(st.records('walks').length, 1);
  return p;
}
function accepted(text) {
  const { st } = liveDevice();
  const p = st.previewImport(text);
  assert.equal(p.ok, true, 'must be accepted: ' + JSON.stringify(p).slice(0, 400));
  return p;
}
const nestObj = (n, leaf) => { let v = leaf; for (let i = 0; i < n; i++) v = { n: v }; return v; };
const nestArr = (n, leaf) => { let v = leaf; for (let i = 0; i < n; i++) v = [v]; return v; };

describe('P4-D5 refusals: sources-like keys and leftover markers at any wrapper depth, objects or arrays', () => {
  it('sources at wrapper depth 4, 5, 10 and 40 is refused and the path is named', () => {
    const c = realCopies();
    refused(JSON.stringify(emptyCore({ a: { b: { c: { d: { sources: c } } } } })), /inside a\.b\.c\.d/);
    refused(JSON.stringify(emptyCore({ a: { b: { c: { d: { e: { sources: c } } } } } })));
    refused(JSON.stringify(emptyCore({ w: nestObj(10, { sources: c }) })));
    refused(JSON.stringify(emptyCore({ w: nestObj(40, { SOURCES: [] }) })), /reads as "sources"/);
  });
  it('sources inside array wrappers (top-level array, nested arrays, arrays of objects of arrays) is refused', () => {
    const c = realCopies();
    refused(JSON.stringify(emptyCore({ wrapper: [{ sources: c }] })), /wrapper\[0\]/);
    refused(JSON.stringify(emptyCore({ meta: { list: [{ sources: c }] } })), /meta\.list\[0\]/);
    refused(JSON.stringify(emptyCore({ w: [[[{ x: [{ 'So\u200Burces': c }] }]]] })));
    refused(JSON.stringify(emptyCore({ w: nestArr(30, { sources: 1 }) })));
  });
  it('leftover warning / normalExport / omitted / omittedTotal at depth (objects and arrays) are refused', () => {
    refused(JSON.stringify(emptyCore({ wrapper: { warning: 'It is NOT a normal backup' } })), /"warning"/);
    refused(JSON.stringify(emptyCore({ meta: { deep: { normalExport: 'complete' } } })), /"normalExport"/);
    refused(JSON.stringify(emptyCore({ x: { omitted: { daily: 1 } } })), /"omitted"/);
    refused(JSON.stringify(emptyCore({ x: [{ y: { omittedTotal: 0 } }] })), /"omittedTotal"/);
    refused(JSON.stringify(emptyCore({ wrapper: [{ warning: 'NOT a normal backup' }] })));
    refused(JSON.stringify(emptyCore({ w: nestObj(20, { 'Normal\u00ADExport': 'partial' }) })), /reads as "normalExport"/);
  });
  it('format + state together in one wrapper object at depth is refused; each alone in a wrapper is not a marker', () => {
    refused(JSON.stringify(emptyCore({ x: { format: 1, state: { note: 'raw' } } })), /together/);
    refused(JSON.stringify(emptyCore({ x: [{ y: { FORMAT: 1, ' state ': 'ok' } }] })));
    // Only one of the pair (no other marker): an unknown wrapper, ignored like any unknown top-level field.
    accepted(JSON.stringify(emptyCore({ x: { format: 1 } })));
    accepted(JSON.stringify(emptyCore({ x: [{ state: 'ok' }] })));
  });
  it('the whole emergency envelope moved under a wrapper (kind/app relabelled) is refused', () => {
    const s = mem(); const st = mk(s); ok(st.addWeight({ date: D, kg: 81 }), 'seed');
    const env = JSON.parse(st.rawRecoveryExport().text);
    delete env.kind; env.app = 'x';
    refused(JSON.stringify(emptyCore({ meta: [env] })));
    refused(JSON.stringify(emptyCore({ a: { b: { c: { d: { e: env } } } } })));
  });
});

describe('P4-D5 refusals: planted emergency copies {key, raw, checksum, length} anywhere in records', () => {
  const recs = (c) => ({
    daily: [{ id: 'd1', createdAt: ts, date: D, steps: O(1), sources: c }],
    walks: [{ id: 'w1', createdAt: ts, date: D, durationMin: 30, sources: c }],
    body: [{ id: 'b1', createdAt: ts, date: D, metric: 'waist_cm', state: 'OBSERVED', value: 90, sources: c }],
    dayStates: [{ id: 'ds1', createdAt: ts, date: D, attestation: 'INCOMPLETE', basis: '0:x', sources: c }],
    planEvents: [{ id: 'pe1', createdAt: ts, date: D, kind: 'MISSED_MONDAY', week: 1, sources: c }],
  });
  it('on each Phase 3 list, under the field name sources, with empty core lists', () => {
    const c = realCopies();
    for (const [t, list] of Object.entries(recs(c))) refused(JSON.stringify(emptyCore({ [t]: list })), new RegExp('emergency copy .*' + t + '\\[0\\]'));
  });
  it('under any other field name, nested deeper in a record, on a core entry, or on a session block', () => {
    const c = realCopies();
    refused(JSON.stringify(emptyCore({ walks: [{ id: 'w1', createdAt: ts, date: D, durationMin: 30, backupCopies: c }] })));
    refused(JSON.stringify(emptyCore({ walks: [{ id: 'w1', createdAt: ts, date: D, durationMin: 30, x: { y: [[c[0]]] } }] })), /walks\[0\]\.x\.y\[0\]\[0\]/);
    refused(JSON.stringify(emptyCore({ weight: [{ id: 'x1', createdAt: ts, date: D, kg: 70, extra: c }] })));
    refused(JSON.stringify(emptyCore({ sessions: [{ id: 's1', createdAt: ts, date: D, status: 'COMPLETED', blocks: [{ kind: 'run', copy: c[0] }] }] })));
  });
  it('a copy with a non-matching checksum or length still counts (shape, not integrity)', () => {
    refused(JSON.stringify(emptyCore({ daily: [{ id: 'd1', createdAt: ts, date: D, sources: [{ key: 'hyrox.v1', raw: '{}', length: 99, checksum: 'nope' }] }] })));
  });
  it('a partial look-alike (missing one of the four fields, or key/raw not text) is NOT an emergency copy', () => {
    for (const x of [{ key: 'k', raw: 'r', checksum: 'c' }, { key: 'k', raw: 'r', length: 1 }, { raw: 'r', checksum: 'c', length: 1 },
      { key: 1, raw: 'r', checksum: 'c', length: 1 }, { key: 'k', raw: { t: 1 }, checksum: 'c', length: 1 }]) {
      accepted(backup({ walks: [{ id: 'w1', createdAt: ts, date: D, durationMin: 30, items: [x] }] }));
    }
  });
});

describe('P4-D5 depth cap (64) fails closed', () => {
  const MSG = /nested too deeply \(more than 64 levels\)/;
  it('nesting within the cap without markers is accepted (unknown top-level field ignored)', () => {
    accepted(JSON.stringify(emptyCore({ deep: nestObj(60, { v: 1 }) })));
    accepted(JSON.stringify(emptyCore({ deep: nestArr(60, 1) })));
  });
  it('exactly at the boundary: a container at depth 64 is accepted, at depth 65 refused', () => {
    // root=0, deep=1, so nestObj(n) puts the innermost object at depth n+1.
    accepted(JSON.stringify(emptyCore({ deep: nestObj(63, {}) })));
    refused(JSON.stringify(emptyCore({ deep: nestObj(64, {}) })), MSG);
    refused(JSON.stringify(emptyCore({ deep: nestArr(64, []) })), MSG);
  });
  it('deep nesting inside a Phase 3 record and a 4000-deep nest are refused fast, with a genuine weight list present', () => {
    refused(JSON.stringify(emptyCore({ walks: [{ id: 'w1', createdAt: ts, date: D, durationMin: 30, x: nestArr(80, 1) }] })), MSG);
    const text = '{"app":"hyrox-app","version":2,"exportedAt":"' + ts + '","weight":[{"id":"n1","createdAt":"' + ts + '","date":"' + D + '","kg":79}],"workouts":[],"nutrition":[],"deep":' +
      '{"n":'.repeat(4000) + '1' + '}'.repeat(4000) + '}';
    const t0 = Date.now();
    refused(text, MSG);
    assert.ok(Date.now() - t0 < 2000);
  });
  it('a marker hidden beyond the cap is still refused (fail closed, not skipped)', () => {
    refused(JSON.stringify(emptyCore({ deep: nestObj(100, { sources: realCopies() }) })), MSG);
  });
});

// A rich genuine export: every list, unicode, notes with marker words, legit collisions
// (session block `omitted`, body record `state`, daily {state, value}, unknown record fields).
const WORDS = 'sources warning format omitted omittedTotal normalExport state kind raw_recovery_file {"sources":[{"key":"k","raw":"r","checksum":"c","length":1}]}';
function richDevice() {
  const s = mem(); const st = mk(s);
  ok(st.addWeight({ date: D, kg: 80.4 }), 'weight');
  ok(st.addWorkout({ date: D, activity: 'Run ü 走る 🏃', durationMin: 42, notes: WORDS }), 'workout');
  ok(st.addNutrition({ date: D, label: 'Lunch sources warning format omitted', calories: 510, proteinG: 32.5 }), 'nutrition');
  ok(st.putRecord('daily', { date: D, steps: O(8123), footPain: O(2), stairKneePain: O(1), sleepH: O(7.5), limp: { state: 'OBSERVED', value: false }, note: WORDS,
    warning: 'user note field', format: 'v', omitted: false, sources: ['x'], source: 'watch', sourcesCount: 2 }), 'daily');
  ok(st.putRecord('walks', { date: D, durationMin: 30, steps: 3000, notes: 'sources: shoes; ' + WORDS, sources: ['x'] }), 'walk');
  ok(st.putRecord('body', { date: D, metric: 'waist_cm', state: 'OBSERVED', value: 90, notes: WORDS, format: 'tape' }), 'body (state + format)');
  ok(st.putRecord('dayStates', { date: D, attestation: 'INCOMPLETE', basis: '0:' + WORDS }), 'dayState');
  ok(st.putRecord('planEvents', { date: '2026-11-02', kind: 'MISSED_MONDAY', week: 1 }), 'planEvent');
  ok(st.putRecord('sessions', { date: WED, status: 'COMPLETED', modified: true, variant: 'SOURCE_25_MIN', planSlotId: 'v2.1-W1-WED', runSteps: 2000, runStepsSource: 'MANUAL',
    blocks: [{ kind: 'run', durationSec: 600, notes: WORDS }, { kind: 'row', omitted: true, optional: true }], notes: WORDS }), 'session with omitted block');
  ok(st.putRecord('sessions', { date: SAT, status: 'COMPLETED', modified: false, variant: 'NONE', blocks: [{ kind: 'run', durationSec: 900 }], notes: 'weekend actual work' }), 'sat');
  ok(st.putRecord('sessions', { date: SUN, status: 'PARTIAL', modified: false, variant: 'NONE', blocks: [{ kind: 'skierg', durationSec: 400, omitted: false }] }), 'sun');
  ok(st.putRecord('meals', { date: D, label: 'Photo plate: sources warning format omitted state', source: 'PHOTO_AI', lifecycle: 'CONFIRMED', confirmedAt: ts, eatenFraction: 0.75,
    components: [{ name: 'Rice normalExport', role: 'SIDE', eatenFraction: 0.75, kcal: K(240), proteinG: K(5), carbsG: K(53), fatG: K(1) }] }), 'photo meal');
  ok(st.putRecord('ownerSettings', { id: HD.SETTINGS_ID, date: D, rhrBaselineBpm: 76 }), 'settings');
  return { s, st };
}

describe('P4-D5 no false refusal of genuine exports', () => {
  it('a rich export with every list (and legit `omitted`/`state`/`format`/`warning`/`sources:[x]` record fields) previews, restores and re-exports identically', () => {
    const { st } = richDevice();
    const text = st.exportJSON();
    const o = JSON.parse(text);
    for (const t of ['weight', 'workouts', 'nutrition'].concat(HD.EXT_TYPES)) assert.ok(Array.isArray(o[t]) && o[t].length >= 1, t);
    assert.equal(o.sessions.find((x) => x.date === WED).blocks[1].omitted, true);
    assert.equal(o.body[0].state, 'OBSERVED'); assert.equal(o.body[0].format, 'tape');
    assert.deepEqual(o.daily[0].sources, ['x']); assert.equal(o.daily[0].warning, 'user note field');
    const { s: s2, st: st2 } = liveDevice();
    const r = restore(st2, text);
    assert.equal(r.ok, true, JSON.stringify(r).slice(0, 400));
    const strip = (t) => { const x = JSON.parse(t); delete x.exportedAt; return x; };
    assert.deepEqual(strip(st2.exportJSON()), strip(text));
    assert.ok(s2.writes > 0);
  });
  it('a genuine record with sources:["x"], and unknown fields source / sourcesCount, are accepted', () => {
    accepted(backup({ walks: [{ id: 'w1', createdAt: ts, date: D, durationMin: 30, sources: ['x'] }] }));
    accepted(backup({ walks: [{ id: 'w1', createdAt: ts, date: D, durationMin: 30, source: 'watch', sourcesCount: 3 }] }));
    accepted(backup({ daily: [{ id: 'd1', createdAt: ts, date: D, steps: O(5), sources: [{ name: 'watch' }] }] }));
    accepted(backup({ source: 'x', sourcesCount: 1 }));
  });
  it('an empty-device export and a legacy v1 export are accepted', () => {
    accepted(mk(mem()).exportJSON());
    const s = mem(); const st = mk(s); ok(st.addWeight({ date: D, kg: 70 }), 'w');
    const t = st.exportJSON(); assert.equal(JSON.parse(t).version, 1); accepted(t);
  });
  it('the emergency export of the rich device itself is still refused', () => {
    const { st } = richDevice();
    const env = JSON.parse(st.rawRecoveryExport().text);
    refused(JSON.stringify(env));
    delete env.kind; env.app = 'hyrox-app'; env.version = 2; env.weight = []; env.workouts = []; env.nutrition = [];
    refused(JSON.stringify(env));
  });
});

describe('P4-D5 performance: one pass over a near-2 MB file', () => {
  // 10,000 entries in each of two lists (weight + walks) is the most that fits under the 2 MB
  // limit (a minimal valid entry is ~75 characters); walk notes pad the file to ~1.95 MB.
  it('10,000 weight + 10,000 walks entries, ~1.95 MB: genuine accepted and a planted copy on the last walk refused, each well under 2 s', () => {
    const T = '2026-11-11T09:00:00Z';
    const build = (pad) => emptyCore({
      weight: Array.from({ length: 10000 }, (_, i) => ({ id: 'w' + i, createdAt: T, date: D, kg: 80 })),
      walks: Array.from({ length: 10000 }, (_, i) => ({ id: 'a' + i, createdAt: T, date: D, durationMin: 1, notes: pad })),
    });
    const base = JSON.stringify(build('')).length;
    // Claude P5: kept at the original ~1.95M-character scale (the limit was 2,000,000 when this was written;
    // padding to the new 10M limit would break the 300-character notes rule). Near-limit timing: p5-claude-review.test.js.
    const SCALE = 2000000;
    const pad = 'p'.repeat(Math.floor((SCALE * 0.975 - base) / 10000));
    const o = build(pad);
    const text = JSON.stringify(o);
    assert.ok(text.length <= SCALE && text.length > SCALE * 0.95, String(text.length));
    const st = mk(mem());
    let t0 = Date.now();
    const p = st.previewImport(text);
    const tAccept = Date.now() - t0;
    assert.equal(p.ok, true, JSON.stringify(p).slice(0, 300));
    assert.deepEqual(p.preview.counts, { weight: 10000, workouts: 0, nutrition: 0 });
    o.walks[9999].x = [{ key: 'hyrox.v1', raw: '', length: 0, checksum: '811c9dc5' }];
    const text2 = JSON.stringify(o);
    assert.ok(text2.length <= HD.IMPORT_LIMITS.maxBytes);
    t0 = Date.now();
    const q = st.previewImport(text2);
    const tRefuse = Date.now() - t0;
    assert.equal(q.ok, false); assert.equal(q.code, 'raw_recovery_file');
    assert.match(q.message, /walks\[9999\]\.x\[0\]/);
    assert.ok(tAccept < 2000 && tRefuse < 2000, tAccept + 'ms / ' + tRefuse + 'ms');
    console.log('# perf: ' + text.length + ' chars; accept ' + tAccept + 'ms; refuse ' + tRefuse + 'ms');
  });
});

describe('P4-D5 kept behaviour', () => {
  it('top-level messages from 9e9f2e1 are unchanged and an array root is still not_hyrox', () => {
    const { st } = liveDevice();
    assert.match(st.previewImport(backup({ sources: [] })).message, /it has a "sources" field\)/);
    assert.match(st.previewImport(backup({ warning: 'x' })).message, /a "warning" field, which only emergency copies have/);
    assert.equal(st.previewImport(JSON.stringify([emptyCore({ sources: [] })])).code, 'not_hyrox');
  });
  it('P4-L1 kept: a look-alike (Cyrillic) top-level key holding the copies with every other marker removed is accepted (characterized, not a defect)', () => {
    accepted(backup({ '\u0441ources': realCopies() }));
  });
  it('the untouched raw file keeps its original refusal and parseRawRecovery still reads it', () => {
    const s = mem(); const st = mk(s); ok(st.addWeight({ date: D, kg: 81 }), 'seed');
    const text = st.rawRecoveryExport().text;
    assert.equal(st.previewImport(text).message, 'This is an emergency raw recovery copy, not a normal backup, so it cannot be restored here. Keep it safe; nothing was changed.');
    assert.equal(HD.parseRawRecovery(text).ok, true);
  });
});
