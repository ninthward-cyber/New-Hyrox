'use strict';
// Dawit t54u: per-record import refusal details (F7 stays refused) + pain outside 0-10 is UNKNOWN. Synthetic data only.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const HW = require(path.resolve(__dirname, '../src/data/hyrox-wellness.js'));
const { mem, mk, O, ts, backup, KEY, PRE, RECOVERY } = require('./p8-helpers.js');

const day = (date, o, id) => Object.assign({ id: id || 'daily-' + date, createdAt: ts, date }, o);
const snap = (s) => JSON.stringify(Object.keys(s.m).sort().map((k) => [k, s.m[k]]));
function seeded() {
  const s = mem({ [RECOVERY]: '{corrupt-sentinel', [PRE]: '{"kind":"older-slot"}' });
  const st = mk(s);
  assert.equal(st.addWeight({ date: '2026-11-17', kg: 81 }).ok, true);
  assert.equal(st.putRecord('daily', { id: 'live-1', date: '2026-11-17', steps: O(9000) }).ok, true);
  return { s, st };
}
const fracText = backup({ daily: [day('2026-11-17', { steps: O(10.5) }, 'd-frac')] });

describe('t54u: fractional daily step total is refused with an exact per-record detail', () => {
  it('previewImport: invalid_records, errors kept, details identify collection/id/date/path/value/rule/how', () => {
    const { st } = seeded();
    const r = st.previewImport(fracText);
    assert.equal(r.ok, false); assert.equal(r.code, 'invalid_records');
    assert.deepEqual(r.errors, [{ list: 'daily', index: 0, field: 'steps', message: 'Daily steps must be a whole number.' }]);
    assert.equal(r.detailsTotal, 1); assert.equal(r.detailsTruncated, false); assert.equal(r.details.length, 1);
    const d = r.details[0];
    assert.equal(d.collection, 'daily'); assert.equal(d.index, 0); assert.equal(d.id, 'd-frac'); assert.equal(d.date, '2026-11-17');
    assert.equal(d.field, 'steps.value'); assert.strictEqual(d.value, 10.5); assert.equal(d.valueType, 'number'); assert.equal(d.valueTruncated, false);
    assert.equal(d.rule, 'must be a whole number 0..200000'); assert.equal(d.code, 'WHOLE_NUMBER_0_200000');
    assert.match(d.howToCorrect, /steps\.value/); assert.match(d.howToCorrect, /whole number/); assert.match(d.howToCorrect, /restore again/);
    assert.doesNotMatch(d.howToCorrect, /to 1[01]\b/, 'no rounded suggestion is offered');
  });
  it('applyImport refusal carries the same details; preview and refused apply write nothing (all keys snapshotted)', () => {
    const { s, st } = seeded();
    const before = snap(s), writes = s.writes;
    const p = st.previewImport(fracText);
    const a = st.applyImport(fracText, { confirm: 'REPLACE', expectCurrent: { weight: 1, workouts: 0, nutrition: 0 } });
    assert.equal(a.ok, false); assert.equal(a.code, 'invalid_records'); assert.deepEqual(a.details, p.details);
    assert.equal(a.detailsTotal, 1); assert.equal(a.rolledBack, false);
    assert.equal(snap(s), before); assert.equal(s.writes, writes);
    assert.equal(s.m[RECOVERY], '{corrupt-sentinel'); assert.equal(s.m[PRE], '{"kind":"older-slot"}');
    assert.equal(st.records('daily')[0].steps.value, 9000);
  });
  it('a whole-number total in the same file restores fine (no repair/normalize path exists)', () => {
    const { st } = seeded();
    const ok = backup({ daily: [day('2026-11-17', { steps: O(10) }, 'd-ok')] });
    const p = st.previewImport(ok); assert.equal(p.ok, true);
    assert.equal(st.applyImport(ok, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt }).ok, true);
    assert.equal(st.records('daily')[0].steps.value, 10);
  });
});

describe('t54u: details cap, safety and other causes', () => {
  it('caps at 20 details with total count and truncated flag', () => {
    const { st } = seeded();
    const daily = Array.from({ length: 25 }, (_, i) => day('2026-11-0' + (1 + (i % 9)), { steps: O(i + 0.25) }, 'f' + i));
    const r = st.previewImport(backup({ daily }));
    assert.equal(r.details.length, 20); assert.equal(r.detailsTotal, 25); assert.equal(r.detailsTruncated, true);
    assert.equal(r.errors.length, 20);
    assert.deepEqual(r.details.slice(0, 3).map((d) => [d.id, d.value]), [['f0', 0.25], ['f1', 1.25], ['f2', 2.25]]);
  });
  it('long strings and objects are clipped and marked; ids clipped; nothing throws', () => {
    const { st } = seeded();
    const long = 'x'.repeat(3000);
    const r = st.previewImport(backup({ daily: [day('2026-11-17', { notes: long }, 'n1'), day('2026-11-17', { steps: { state: 'OBSERVED', value: { a: 'y'.repeat(500) } } }, 'o1')] }));
    assert.equal(r.code, 'invalid_records');
    const n = r.details.find((d) => d.id === 'n1' && d.field === 'notes');
    assert.equal(n.valueType, 'string'); assert.equal(n.valueTruncated, true); assert.equal(n.valueLength, 3000); assert.ok(n.value.length <= 121);
    const o = r.details.find((d) => d.id === 'o1');
    assert.equal(o.field, 'steps.value'); assert.equal(o.valueType, 'object'); assert.equal(o.valueTruncated, true); assert.ok(typeof o.value === 'string' && o.value.length <= 121);
  });
  it('other causes: out-of-range observation, string value, walk steps, session runSteps, macro, duplicate ids, legacy weight, non-record', () => {
    const { st } = seeded();
    const r = st.previewImport(backup({
      weight: [{ id: 'w1', date: '2026-11-17', kg: 'heavy', createdAt: ts }],
      daily: [day('2026-11-17', { footPain: O(11) }, 'p1'), day('2026-11-16', { sleepH: O('7') }, 's1'), 42],
      walks: [{ id: 'wk1', createdAt: ts, date: '2026-11-17', durationMin: 30, steps: 250001 }],
      sessions: [{ id: 'se1', createdAt: ts, date: '2026-11-17', status: 'COMPLETED', modified: false, variant: 'ORIGINAL_60', blocks: [], runSteps: 12.5, runStepsSource: 'DEVICE' }],
    }));
    assert.equal(r.code, 'invalid_records');
    const by = (c, id, f) => r.details.find((d) => d.collection === c && d.id === id && d.field === f);
    const p = by('daily', 'p1', 'footPain.value'); assert.strictEqual(p.value, 11); assert.equal(p.rule, 'must be a number from 0 to 10'); assert.equal(p.date, '2026-11-17');
    const s = by('daily', 's1', 'sleepH.value'); assert.strictEqual(s.value, '7'); assert.equal(s.valueType, 'string');
    assert.strictEqual(by('walks', 'wk1', 'steps').value, 250001);
    const se = by('sessions', 'se1', 'runSteps'); assert.strictEqual(se.value, 12.5); assert.equal(se.code, 'WHOLE_NUMBER_0_200000');
    const w = by('weight', 'w1', 'kg'); assert.strictEqual(w.value, 'heavy');
    const nr = r.details.find((d) => d.collection === 'daily' && d.index === 2); assert.equal(nr.id, null); assert.strictEqual(nr.value, 42); assert.equal(nr.field, 'entry');
    const dup = st.previewImport(backup({ daily: [day('2026-11-17', {}, 'same'), day('2026-11-16', {}, 'same')] }));
    assert.equal(dup.code, 'duplicate_ids'); assert.equal(dup.details[0].code, 'DUPLICATE_ID'); assert.equal(dup.details[0].id, 'same'); assert.equal(dup.details[0].index, 1);
  });
  it('macro value path points at .value', () => {
    const { st } = seeded();
    const meal = { id: 'm1', createdAt: ts, date: '2026-11-17', lifecycle: 'DRAFT', source: 'MANUAL', components: [{ name: 'Rice', role: 'CARB', kcal: { value: 20000, state: 'KNOWN' }, proteinG: { value: null, state: 'UNKNOWN' }, carbsG: { value: null, state: 'UNKNOWN' }, fatG: { value: null, state: 'UNKNOWN' } }] };
    const r = st.previewImport(backup({ meals: [meal] }));
    assert.equal(r.ok, false);
    const d = r.details.find((x) => x.field === 'components[0].kcal.value');
    assert.ok(d, JSON.stringify(r.details)); assert.strictEqual(d.value, 20000);
  });
  it('non-record failures (not JSON, too large) keep their old shape and add no details', () => {
    const { st } = seeded();
    const r = st.previewImport('{nope');
    assert.equal(r.code, 'not_json'); assert.equal(r.details, undefined);
  });
});

describe('t54u: pain outside 0-10 is UNKNOWN, never PASS or FAIL; limp still FAILs', () => {
  const ok = { limp: false, sleepH: 7 };
  it('step10kGate: 10 is valid (FAILs as > 2), 10.5 / 11 / 1000 are UNKNOWN and listed as invalid', () => {
    assert.equal(HW.step10kGate(Object.assign({ footPain: 10, stairKneePain: 0 }, ok)).status, 'FAIL');
    for (const v of [10.01, 11, 1000, Infinity]) {
      const g = HW.step10kGate(Object.assign({ footPain: v, stairKneePain: 0 }, ok));
      assert.equal(g.status, 'UNKNOWN', String(v)); assert.equal(g.pass, false); assert.deepEqual(g.missing, ['footPain']);
      if (isFinite(v)) assert.deepEqual(g.invalid, ['footPain']);
      const k = HW.step10kGate(Object.assign({ footPain: 0, stairKneePain: v }, ok));
      assert.equal(k.status, 'UNKNOWN'); assert.deepEqual(k.missing, ['stairKneePain']);
    }
    assert.deepEqual(HW.step10kGate({ footPain: 0, limp: false, stairKneePain: 0, sleepH: 7 }).invalid, []);
  });
  it('a real failure still wins over an out-of-range pain', () => {
    const g = HW.step10kGate({ footPain: 11, limp: true, stairKneePain: 0, sleepH: 7 });
    assert.equal(g.status, 'FAIL'); assert.deepEqual(g.failed, ['limp']);
    assert.equal(HW.step10kGate({ footPain: 11, limp: false, stairKneePain: 5, sleepH: 7 }).status, 'FAIL');
  });
  it('daily-record path (tenKGate, stepReferenceGoal, stepTarget) treats a stored pain 11 as UNKNOWN and never raises a target', () => {
    const rec = (d) => [day(d, { footPain: O(11), limp: O(false), stairKneePain: O(0), sleepH: O(7) })];
    assert.equal(HW.tenKGate('2026-12-08', rec('2026-12-08')).status, 'UNKNOWN');
    const w4 = HW.stepReferenceGoal('2026-12-08', { dailies: rec('2026-12-08') });
    assert.deepEqual(w4.doNotForce, ['READINESS_GATE_UNKNOWN']);
    const w1 = HW.stepReferenceGoal('2026-11-18', { dailies: rec('2026-11-18') });
    assert.equal(w1.optional10k.offered, false);
    const m = { stepBaselineMode: 'MANUAL', stepBaselineManual: 8000 };
    const t = HW.stepTarget('2026-12-08', { settings: m, plannedToday: 0, dailies: rec('2026-12-08') });
    assert.equal(t.gateHold, 'READINESS_GATE_UNKNOWN'); assert.ok(t.target <= 8000);
  });
  it('storage still refuses pain 11 on entry and on restore (unchanged)', () => {
    const { s, st } = seeded();
    assert.equal(st.putRecord('daily', { date: '2026-11-18', stairKneePain: O(11) }).ok, false);
    const before = snap(s);
    assert.equal(st.previewImport(backup({ daily: [day('2026-11-17', { stairKneePain: O(11) })] })).ok, false);
    assert.equal(snap(s), before); assert.ok(s.m[KEY]);
  });
});
