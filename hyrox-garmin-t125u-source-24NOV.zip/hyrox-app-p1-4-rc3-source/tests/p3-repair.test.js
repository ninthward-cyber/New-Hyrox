'use strict';
// Regression tests for the two defects reproduced by the independent audit (P0-A, P0-B),
// the schema-version downgrade guard, and data-layer rules behind the five owner decisions.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const HD = require(path.resolve(__dirname, '../src/data/hyrox-data.js'));
const HP = require(path.resolve(__dirname, '../src/data/hyrox-plan.js'));
// The real Phase 2 data layer (local integration 64427c2), kept as a fixture to prove the downgrade guard.
const OLD = require(path.resolve(__dirname, 'fixtures/legacy/hyrox-data-64427c2.js'));

const NOW = new Date('2026-11-18T09:00:00Z');
const KEY = 'hyrox.v1', RECOVERY = 'hyrox.v1.corrupt-backup', PRE = 'hyrox.v1.pre-import-backup';
function mem(init, fail) {
  const m = Object.assign({}, init || {});
  return {
    m, writes: 0,
    getItem(k) { return Object.prototype.hasOwnProperty.call(m, k) ? m[k] : null; },
    setItem(k, v) { if (fail && fail(k, v)) throw new Error('QuotaExceeded'); this.writes++; m[k] = String(v); },
    removeItem(k) { delete m[k]; },
  };
}
const mk = (s) => HD.createStore(s, { now: () => NOW });
const mkOld = (s) => OLD.createStore(s, { now: () => NOW });
const U = { value: null, state: 'UNKNOWN' };
const K = (v) => ({ value: v, state: 'KNOWN' });
const SESSION = { date: '2026-11-18', status: 'PARTIAL', modified: false, variant: 'NONE', blocks: [] };
const VALID = {
  sessions: SESSION,
  meals: { date: '2026-11-18', label: 'Lunch', source: 'MANUAL', lifecycle: 'CONFIRMED', confirmedAt: NOW.toISOString(),
    components: [{ name: 'Rice', role: 'SIDE', kcal: K(240), proteinG: K(5), carbsG: U, fatG: K(0) }] },
  body: { date: '2026-11-18', metric: 'waist_cm', state: 'OBSERVED', value: 90 },
  daily: { date: '2026-11-18', steps: { state: 'OBSERVED', value: 8000 } },
  walks: { date: '2026-11-18', durationMin: 30 },
  dayStates: { date: '2026-11-18', attestation: 'INCOMPLETE', basis: '0:x' },
  planEvents: { date: '2026-11-16', kind: 'MISSED_MONDAY', week: 1 },
  ownerSettings: { id: HD.SETTINGS_ID, date: '2026-11-18', rhrBaselineBpm: 76 },
};
const AUDIT_RAW = '{"version":1,"weight":[],"workouts":[],"nutrition":[],"sessions":{"historic":"keep-me"}}';

describe('P0-A: a malformed Phase 3 collection is never silently replaced', () => {
  it('the exact audit reproduction: status is not ok, and the save keeps a byte-exact recovery copy', () => {
    const s = mem({ [KEY]: AUDIT_RAW }); const st = mk(s);
    const status = st.status();
    assert.equal(status.ok, false); assert.equal(status.state, 'corrupt'); assert.equal(status.damagedList, 'sessions');
    assert.equal(s.writes, 0, 'reading and status never write');
    const r = st.putRecord('sessions', SESSION);
    assert.equal(r.ok, true);
    assert.equal(s.m[RECOVERY], AUDIT_RAW, 'the original text, including {"historic":"keep-me"}, is preserved byte for byte');
    assert.equal(st.records('sessions').length, 1);
  });
  it('holds for every Phase 3 collection and every non-list shape', () => {
    assert.deepEqual(HD.EXT_TYPES, ['sessions', 'meals', 'body', 'daily', 'walks', 'dayStates', 'planEvents', 'ownerSettings']);
    HD.EXT_TYPES.forEach((t) => {
      [{ historic: 'keep-me' }, 'text', 7, true].forEach((bad) => {
        const raw = JSON.stringify({ version: 1, weight: [], workouts: [], nutrition: [], [t]: bad });
        const s = mem({ [KEY]: raw }); const st = mk(s);
        assert.equal(st.status().state, 'corrupt', t + ' ' + JSON.stringify(bad));
        assert.equal(st.status().damagedList, t);
        assert.deepEqual(st.records(t), []);
        assert.equal(s.m[KEY], raw, 'reads leave storage untouched');
        const r = st.putRecord(t, VALID[t]);
        assert.equal(r.ok, true, t + ' ' + JSON.stringify(r.errors));
        assert.equal(s.m[RECOVERY], raw);
      });
    });
  });
  it('a classic save (weight) on such data also preserves the raw text first', () => {
    const s = mem({ [KEY]: AUDIT_RAW }); const st = mk(s);
    assert.equal(st.addWeight({ date: '2026-11-18', kg: 80 }).ok, true);
    assert.equal(s.m[RECOVERY], AUDIT_RAW);
  });
  it('write is REFUSED and nothing changes when a different recovery copy already exists', () => {
    const s = mem({ [KEY]: AUDIT_RAW, [RECOVERY]: '{"older":"damage"}' }); const st = mk(s);
    const r = st.putRecord('sessions', SESSION);
    assert.equal(r.ok, false); assert.match(r.errors.storage, /damaged/);
    assert.equal(s.m[KEY], AUDIT_RAW); assert.equal(s.m[RECOVERY], '{"older":"damage"}');
    assert.equal(st.addWeight({ date: '2026-11-18', kg: 80 }).ok, false);
    assert.equal(s.m[KEY], AUDIT_RAW);
  });
  it('write is REFUSED and nothing changes when the recovery copy cannot be written', () => {
    const s = mem({ [KEY]: AUDIT_RAW }, (k) => k === RECOVERY); const st = mk(s);
    assert.equal(st.putRecord('sessions', SESSION).ok, false);
    assert.equal(s.m[KEY], AUDIT_RAW); assert.equal(s.m[RECOVERY], undefined);
  });
  it('delete and export refuse to touch or misrepresent the damaged data', () => {
    const s = mem({ [KEY]: AUDIT_RAW }); const st = mk(s);
    assert.equal(st.removeRecord('sessions', 'x'), false);
    assert.throws(() => st.exportJSON(), /damaged/);
    assert.equal(st.exportSummary().state, 'corrupt');
    assert.equal(s.m[KEY], AUDIT_RAW);
  });
  it('restore over the damaged data keeps the exact raw text in the pre-import slot and the recovery slot', () => {
    const good = mk(mem()); good.addWeight({ date: '2026-11-17', kg: 80 }); good.putRecord('walks', VALID.walks);
    const text = good.exportJSON();
    const s = mem({ [KEY]: AUDIT_RAW }); const st = mk(s);
    const p = st.previewImport(text);
    assert.equal(p.ok, true); assert.equal(p.preview.currentState, 'corrupt');
    assert.equal(s.m[KEY], AUDIT_RAW, 'preview writes nothing');
    const r = st.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt });
    assert.equal(r.ok, true);
    assert.equal(JSON.parse(s.m[PRE]).raw, AUDIT_RAW);
    assert.equal(s.m[RECOVERY], AUDIT_RAW);
    assert.equal(st.records('walks').length, 1);
  });
  it('a failed restore over the damaged data rolls back to the exact damaged text', () => {
    const good = mk(mem()); good.putRecord('walks', VALID.walks);
    const text = good.exportJSON();
    let armed = false;
    const s = mem({ [KEY]: AUDIT_RAW }, (k, v) => armed && k === KEY && v !== AUDIT_RAW); const st = mk(s);
    const p = st.previewImport(text);
    armed = true;
    const r = st.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt });
    assert.equal(r.ok, false); assert.equal(r.rolledBack, true);
    assert.equal(s.m[KEY], AUDIT_RAW);
  });
  it('a backup whose Phase 3 list is malformed is refused and nothing is written', () => {
    const s = mem(); const st = mk(s);
    st.putRecord('walks', VALID.walks);
    const before = s.m[KEY];
    const bad = JSON.stringify({ app: 'hyrox-app', version: 2, exportedAt: NOW.toISOString(), weight: [], workouts: [], nutrition: [], sessions: { historic: 'x' } });
    const p = st.previewImport(bad);
    assert.equal(p.ok, false); assert.equal(p.code, 'invalid_records');
    const r = st.applyImport(bad, { confirm: 'REPLACE', expectCurrent: { weight: 0, workouts: 0, nutrition: 0 } });
    assert.equal(r.ok, false);
    assert.equal(s.m[KEY], before); assert.equal(s.m[PRE], undefined);
  });
  it('an empty or null Phase 3 collection is healthy, not damage', () => {
    [null, []].forEach((v) => {
      const s = mem({ [KEY]: JSON.stringify({ version: 1, weight: [], workouts: [], nutrition: [], sessions: v }) });
      assert.equal(mk(s).status().state, 'ok');
      assert.equal(mk(s).putRecord('sessions', SESSION).ok, true);
      assert.equal(s.m[RECOVERY], undefined);
    });
  });
});

describe('P0-A: invalid records inside a Phase 3 list', () => {
  function seeded() {
    const good = Object.assign({ id: 'ok1', createdAt: NOW.toISOString() }, SESSION);
    const broken = { id: 'bad1', createdAt: NOW.toISOString(), date: '2026-11-17', status: 'BOGUS' }; // no blocks, bad status
    const junk = 'not-a-record';
    const raw = JSON.stringify({ version: 1, weight: [], workouts: [], nutrition: [], sessions: [good, broken, junk] });
    return { s: mem({ [KEY]: raw }), raw };
  }
  it('are hidden from lists (so the UI cannot crash on them) but stay stored through later saves', () => {
    const { s } = seeded(); const st = mk(s);
    assert.equal(st.status().state, 'ok');
    assert.deepEqual(st.records('sessions').map((x) => x.id), ['ok1']);
    assert.equal(st.putRecord('walks', VALID.walks).ok, true);
    const stored = JSON.parse(s.m[KEY]).sessions;
    assert.equal(stored.length, 3); assert.equal(stored[1].id, 'bad1'); assert.equal(stored[2], 'not-a-record');
  });
  it('are reported as omitted, left out of the export, and the export still restores', () => {
    const { s } = seeded(); const st = mk(s);
    assert.deepEqual(st.exportSummary().omittedExt, { sessions: 2 });
    const text = st.exportJSON();
    assert.deepEqual(JSON.parse(text).sessions.map((x) => x.id), ['ok1']);
    const s2 = mem(); const st2 = mk(s2);
    const p = st2.previewImport(text);
    assert.equal(p.ok, true, JSON.stringify(p));
    assert.equal(st2.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt }).ok, true);
    assert.deepEqual(st2.records('sessions').map((x) => x.id), ['ok1']);
  });
  it('healthy data reports no omitted Phase 3 records', () => {
    const st = mk(mem()); st.putRecord('walks', VALID.walks);
    assert.equal(st.exportSummary().omittedExt, undefined);
  });
});

describe('schema version: downgrade guard', () => {
  it('classic-only data stays version 1 in storage and in exports', () => {
    const s = mem(); const st = mk(s);
    st.addWeight({ date: '2026-11-17', kg: 80 });
    assert.equal(JSON.parse(s.m[KEY]).version, 1);
    assert.equal(JSON.parse(st.exportJSON()).version, 1);
  });
  it('data with any Phase 3 collection is version 2 in storage and in exports', () => {
    const s = mem(); const st = mk(s);
    st.addWeight({ date: '2026-11-17', kg: 80 });
    st.putRecord('walks', VALID.walks);
    assert.equal(JSON.parse(s.m[KEY]).version, 2);
    assert.equal(JSON.parse(st.exportJSON()).version, 2);
    st.addWeight({ date: '2026-11-18', kg: 80.5 });
    assert.equal(JSON.parse(s.m[KEY]).version, 2, 'later classic saves keep version 2');
  });
  it('existing version-1 storage that already holds Phase 3 lists (Emergent build) is readable and upgrades on the next save', () => {
    const raw = JSON.stringify({ version: 1, weight: [], workouts: [], nutrition: [], walks: [Object.assign({ id: 'w', createdAt: NOW.toISOString() }, VALID.walks)] });
    const s = mem({ [KEY]: raw }); const st = mk(s);
    assert.equal(st.status().state, 'ok'); assert.equal(st.records('walks').length, 1);
    assert.equal(s.m[KEY], raw, 'no write on read');
    st.putRecord('walks', { date: '2026-11-18', durationMin: 10 });
    assert.equal(JSON.parse(s.m[KEY]).version, 2); assert.equal(st.records('walks').length, 2);
  });
  it('a version-1 backup that carries Phase 3 lists (made by the Emergent build) still restores, as version 2', () => {
    const text = JSON.stringify({ app: 'hyrox-app', version: 1, exportedAt: NOW.toISOString(), weight: [], workouts: [], nutrition: [],
      walks: [Object.assign({ id: 'w', createdAt: NOW.toISOString() }, VALID.walks)] });
    const s = mem(); const st = mk(s);
    const p = st.previewImport(text);
    assert.equal(p.ok, true); assert.equal(p.preview.version, 2);
    assert.equal(st.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt }).ok, true);
    assert.equal(JSON.parse(s.m[KEY]).version, 2); assert.equal(st.records('walks').length, 1);
  });
  it('a Phase 2 backup restores as version 1 with no Phase 3 keys', () => {
    const text = JSON.stringify({ app: 'hyrox-app', version: 1, exportedAt: NOW.toISOString(), weight: [{ id: 'w1', createdAt: NOW.toISOString(), date: '2026-11-17', kg: 80 }], workouts: [], nutrition: [] });
    const s = mem(); const st = mk(s);
    const p = st.previewImport(text);
    assert.equal(st.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt }).ok, true);
    assert.deepEqual(Object.keys(JSON.parse(s.m[KEY])), ['version', 'weight', 'workouts', 'nutrition']);
    assert.equal(JSON.parse(s.m[KEY]).version, 1);
  });
  it('version 3 is still refused, in storage and on restore', () => {
    const s = mem({ [KEY]: JSON.stringify({ version: 3, weight: [] }) });
    assert.equal(mk(s).status().state, 'newer');
    const text = JSON.stringify({ app: 'hyrox-app', version: 3, exportedAt: NOW.toISOString(), weight: [], workouts: [], nutrition: [] });
    assert.equal(mk(mem()).previewImport(text).code, 'unsupported_version');
  });

  describe('the real Phase 2 build (64427c2) against Phase 3 data', () => {
    function phase3() {
      const s = mem(); const st = mk(s);
      st.addWeight({ date: '2026-11-17', kg: 80 });
      st.putRecord('walks', VALID.walks); st.putRecord('sessions', SESSION);
      return { s, st };
    }
    it('refuses to restore a Phase 3 backup instead of discarding the new collections', () => {
      const { st } = phase3();
      const text = st.exportJSON();
      const os = mem({ [KEY]: JSON.stringify({ version: 1, weight: [], workouts: [], nutrition: [] }) });
      const before = os.m[KEY];
      const old = mkOld(os);
      const p = old.previewImport(text);
      assert.equal(p.ok, false); assert.equal(p.code, 'unsupported_version');
      const r = old.applyImport(text, { confirm: 'REPLACE', expectCurrent: { weight: 0, workouts: 0, nutrition: 0 } });
      assert.equal(r.ok, false);
      assert.equal(os.m[KEY], before); assert.equal(os.m[PRE], undefined);
    });
    it('treats Phase 3 storage as newer: no save, no export, bytes untouched', () => {
      const { s } = phase3();
      const before = s.m[KEY];
      const old = mkOld(s);
      assert.equal(old.status().state, 'newer');
      assert.equal(old.addWeight({ date: '2026-11-18', kg: 81 }).ok, false);
      assert.equal(old.remove('weight', JSON.parse(before).weight[0].id), false);
      assert.throws(() => old.exportJSON());
      assert.equal(s.m[KEY], before);
    });
    it('proof the guard matters: without the version bump the old build would silently drop the collections', () => {
      const { st } = phase3();
      const asV1 = JSON.parse(st.exportJSON()); asV1.version = 1; // what the Emergent Phase 3 build exported
      const os = mem(); const old = mkOld(os);
      const p = old.previewImport(JSON.stringify(asV1));
      assert.equal(p.ok, true, 'old build accepts a version-1 file');
      old.applyImport(JSON.stringify(asV1), { confirm: 'REPLACE', expectCurrent: p.preview.current });
      assert.equal(JSON.parse(os.m[KEY]).walks, undefined, 'and discards walks/sessions');
    });
    it('classic-only data written by this build is still fully usable by the Phase 2 build', () => {
      const s = mem(); mk(s).addWeight({ date: '2026-11-17', kg: 80 });
      const old = mkOld(s);
      assert.equal(old.status().state, 'ok');
      assert.equal(old.addWeight({ date: '2026-11-18', kg: 81 }).ok, true);
      assert.equal(mk(s).list('weight').length, 2);
    });
  });
});

describe('legacy data is not misread', () => {
  it('records written by the Emergent Phase 3 build stay valid, visible and unchanged in total', () => {
    const HN = require(path.resolve(__dirname, '../src/data/hyrox-nutrition.js'));
    const E = (v) => ({ value: v, state: 'ESTIMATED' });
    const photoMeal = { id: 'm1', createdAt: NOW.toISOString(), updatedAt: NOW.toISOString(), date: '2026-11-18', label: 'Plate', source: 'PHOTO_AI',
      lifecycle: 'CONFIRMED', confirmedAt: NOW.toISOString(), ai: { mode: 'MOCK', provider: 'mock-fixture', model: 'm' },
      components: [{ name: 'Rice', role: 'SIDE', eatenFraction: 1, kcal: E(240), proteinG: E(5), carbsG: E(53), fatG: E(1) },
        { name: 'Chicken', role: 'MAIN', eatenFraction: 0.5, kcal: E(220), proteinG: E(40), carbsG: E(0), fatG: E(5) }] };
    const skipped = { id: 's1', createdAt: NOW.toISOString(), date: '2026-11-17', status: 'SKIPPED', skipConfirmed: true, modified: false, variant: 'NONE', blocks: [], planSlotId: 'v2.1-W1-TUE' };
    const att = { id: 'd1', createdAt: NOW.toISOString(), date: '2026-11-17', attestation: 'COMPLETE', basis: '0:x' };
    const raw = JSON.stringify({ version: 1, weight: [], workouts: [], nutrition: [], meals: [photoMeal], sessions: [skipped], dayStates: [att] });
    const st = mk(mem({ [KEY]: raw }));
    assert.equal(st.status().state, 'ok');
    assert.equal(st.records('meals').length, 1); assert.equal(st.records('sessions').length, 1); assert.equal(st.records('dayStates').length, 1);
    assert.equal(HN.mealTotals(st.records('meals')[0]).kcal.value, 350);
    assert.equal(st.exportSummary().omittedExt, undefined);
  });
  it('a Phase 2 top-level "settings" object is unknown data, not a damaged collection', () => {
    const raw = JSON.stringify({ version: 1, weight: [], workouts: [], nutrition: [], settings: { unit: 'kg' } });
    const s = mem({ [KEY]: raw }); const st = mk(s);
    assert.equal(st.status().state, 'ok');
    st.addWeight({ date: '2026-11-18', kg: 80 });
    assert.deepEqual(JSON.parse(s.m[KEY]).settings, { unit: 'kg' });
    assert.equal(JSON.parse(s.m[KEY]).version, 1);
  });
});

describe('P0-B: a source omission never masks an actual logged session', () => {
  const MON = [{ id: 'e1', kind: 'MISSED_MONDAY', week: 1, date: '2026-11-16', createdAt: '2026-11-19T18:00:00.000Z' }];
  const WED = [{ id: 'e2', kind: 'MISSED_WEDNESDAY', week: 1, date: '2026-11-18', createdAt: '2026-11-18T18:00:00.000Z' }];
  const thu = (status, extra) => Object.assign({ id: 's-thu', planSlotId: 'v2.1-W1-THU', date: '2026-11-19', status, modified: false, variant: 'ORIGINAL_60',
    blocks: [], createdAt: '2026-11-19T10:00:00.000Z', updatedAt: '2026-11-19T10:00:00.000Z' }, extra || {});

  it('the exact audit reproduction: COMPLETED Thursday + MISSED_MONDAY stays COMPLETED with its session', () => {
    const st = HP.slotStatus('v2.1-W1-THU', [thu('COMPLETED')], MON);
    assert.equal(st.code, 'COMPLETED');
    assert.equal(st.session.id, 's-thu');
    assert.equal(st.omission, 'MISSED_MONDAY_CASCADE', 'the prescribed slot is still reported as source-omitted');
    assert.equal(st.conflict, 'ACTUAL_SESSION_ON_SOURCE_OMITTED_SLOT');
  });
  it('PARTIAL and IN_PROGRESS Thursday sessions are kept the same way, for either cascade', () => {
    ['PARTIAL', 'IN_PROGRESS'].forEach((status) => [MON, WED].forEach((ev) => {
      const st = HP.slotStatus('v2.1-W1-THU', [thu(status)], ev);
      assert.equal(st.code, status); assert.ok(st.session); assert.ok(st.omission); assert.ok(st.conflict);
    }));
  });
  it('a cascade entered AFTER the session was logged (retroactive) does not hide it and is called out', () => {
    const sessions = [thu('COMPLETED')];
    assert.equal(HP.slotStatus('v2.1-W1-THU', sessions, []).code, 'COMPLETED');
    assert.equal(HP.slotStatus('v2.1-W1-THU', sessions, MON).code, 'COMPLETED');
    const c = HP.cascadeConflicts(1, sessions, MON);
    assert.equal(c.length, 1); assert.equal(c[0].code, 'ACTUAL_SESSION_ON_SOURCE_OMITTED_SLOT');
    assert.match(c[0].text, /entered after this session was logged/);
  });
  it('a session logged AFTER the cascade is shown too, without the retroactive note', () => {
    const late = thu('COMPLETED', { createdAt: '2026-11-20T08:00:00.000Z', updatedAt: '2026-11-20T08:00:00.000Z' });
    const c = HP.cascadeConflicts(1, [late], MON);
    assert.equal(c.length, 1); assert.doesNotMatch(c[0].text, /entered after/);
  });
  it('summary counts the logged work once, never as source-omitted, and flags the overlap', () => {
    const sum = HP.summary([thu('COMPLETED')], MON);
    assert.equal(sum.COMPLETED, 1); assert.equal(sum.SOURCE_OMITTED, 0); assert.equal(sum.omittedWithActual, 1);
    assert.equal(sum.NOT_LOGGED, 19); assert.equal(sum.SKIPPED, 0); assert.equal(sum.denominator, 20);
    const total = sum.COMPLETED + sum.PARTIAL + sum.SKIPPED + sum.SOURCE_OMITTED + sum.NOT_LOGGED + sum.NOT_STARTED + sum.IN_PROGRESS;
    assert.equal(total, 20, 'every slot is counted exactly once');
  });
  it('with no session the omitted slot is SOURCE_OMITTED and never invented as skipped', () => {
    const st = HP.slotStatus('v2.1-W1-THU', [], MON);
    assert.equal(st.code, 'SOURCE_OMITTED'); assert.equal(st.session, null);
    assert.equal(HP.summary([], MON).SKIPPED, 0); assert.equal(HP.summary([], MON).SOURCE_OMITTED, 1);
  });
  it('a NOT_STARTED placeholder on an omitted slot shows as source-omitted but keeps its record', () => {
    const st = HP.slotStatus('v2.1-W1-THU', [thu('NOT_STARTED')], MON);
    assert.equal(st.code, 'SOURCE_OMITTED'); assert.equal(st.session.id, 's-thu');
  });
  it('the owner\'s own SKIPPED record stays SKIPPED and distinct from the source omission', () => {
    const st = HP.slotStatus('v2.1-W1-THU', [thu('SKIPPED', { skipConfirmed: true })], MON);
    assert.equal(st.code, 'SKIPPED'); assert.equal(st.omission, 'MISSED_MONDAY_CASCADE'); assert.equal(st.conflict, undefined);
  });
  it('the original planned slot is never changed by events or sessions', () => {
    const before = JSON.stringify(HP.SLOTS);
    HP.slotStatus('v2.1-W1-THU', [thu('COMPLETED')], MON); HP.effectiveWeek(1, MON); HP.summary([thu('COMPLETED')], MON);
    assert.equal(JSON.stringify(HP.SLOTS), before);
    assert.equal(HP.slotById('v2.1-W1-THU').date, '2026-11-19');
    assert.equal(HP.effectiveWeek(1, MON).days[3].omitted[0].slot.id, 'v2.1-W1-THU');
  });
  it('sequence conflicts are reported honestly: Monday marked missed but logged as done on Monday', () => {
    const mon = { id: 's-mon', planSlotId: 'v2.1-W1-MON', date: '2026-11-16', status: 'COMPLETED', modified: false, variant: 'ORIGINAL_60', blocks: [], createdAt: '2026-11-16T10:00:00.000Z' };
    const c = HP.cascadeConflicts(1, [mon], MON);
    assert.deepEqual(c.map((x) => x.code), ['MISSED_DAY_HAS_ACTUAL_SESSION']);
    const movedOk = Object.assign({}, mon, { date: '2026-11-17' }); // done on Tuesday, as the cascade says
    assert.deepEqual(HP.cascadeConflicts(1, [movedOk], MON), []);
  });
  it('both-missed stays unresolved: nothing moved, nothing omitted, no conflict invented', () => {
    const both = MON.concat(WED);
    assert.equal(HP.slotStatus('v2.1-W1-THU', [], both).code, 'NOT_LOGGED');
    assert.ok(HP.effectiveWeek(1, both).unresolved);
    assert.deepEqual(HP.cascadeConflicts(1, [thu('COMPLETED')], both), []);
  });
  it('a later skip or note never hides work that was actually done on the same slot', () => {
    const done = thu('COMPLETED');
    const laterSkip = thu('SKIPPED', { id: 's-skip', skipConfirmed: true, createdAt: '2026-11-20T08:00:00.000Z', updatedAt: '2026-11-20T08:00:00.000Z' });
    assert.equal(HP.slotStatus('v2.1-W1-THU', [done, laterSkip], []).code, 'COMPLETED');
    assert.equal(HP.benchmarks([]).length, 2);
  });
});

describe('backup round-trip with every collection and the new owner-rule fields', () => {
  function full() {
    const s = mem(); const st = mk(s);
    st.addWeight({ date: '2026-11-17', kg: 80 });
    st.addWorkout({ date: '2026-11-17', activity: 'Run', durationMin: 30 });
    st.addNutrition({ date: '2026-11-17', label: 'Oats', calories: 350, proteinG: 12 });
    const put = (t, r) => { const res = st.putRecord(t, r); assert.equal(res.ok, true, t + ' ' + JSON.stringify(res.errors)); };
    put('sessions', { date: '2026-11-17', status: 'SKIPPED', skipConfirmed: true, skipDecision: 'RESCHEDULE', rescheduledTo: '2026-11-21', modified: false, variant: 'NONE', blocks: [], planSlotId: 'v2.1-W1-TUE', scheduledDate: '2026-11-17' });
    put('meals', { date: '2026-11-18', label: 'Plate', source: 'PHOTO_AI', lifecycle: 'CONFIRMED', confirmedAt: NOW.toISOString(), eatenFraction: 0.33, ai: { mode: 'MOCK', provider: 'mock-fixture', model: 'm' },
      components: [{ name: 'Rice', role: 'SIDE', eatenFraction: null, kcal: { value: 240, state: 'ESTIMATED' }, proteinG: U, carbsG: U, fatG: U },
        { name: 'Chicken', role: 'MAIN', eatenFraction: 1, kcal: { value: 220, state: 'ESTIMATED' }, proteinG: U, carbsG: U, fatG: U }] });
    put('body', VALID.body);
    put('daily', { id: 'daily-2026-11-18', date: '2026-11-18', steps: { state: 'OBSERVED', value: 8000 }, rhr: { state: 'MISSING', value: null }, stepTargetOverride: 9000 });
    put('walks', VALID.walks);
    put('dayStates', { date: '2026-11-16', attestation: 'COMPLETE', basis: '0:x', fast: 'CONFIRMED_FULL_DAY_FAST' });
    put('planEvents', VALID.planEvents);
    put('ownerSettings', { id: HD.SETTINGS_ID, date: '2026-11-18', rhrBaselineBpm: 74, stepBaselineMode: 'MANUAL', stepBaselineManual: 7500 });
    return { s, st };
  }
  it('export -> restore on a fresh device reproduces every record exactly', () => {
    const { st } = full();
    const text = st.exportJSON();
    assert.equal(JSON.parse(text).version, 2);
    assert.equal(/data:image|base64/i.test(text), false);
    const s2 = mem(); const st2 = mk(s2);
    const p = st2.previewImport(text);
    assert.equal(p.ok, true, JSON.stringify(p));
    assert.deepEqual(Object.keys(s2.m), [], 'preview writes nothing');
    assert.deepEqual(p.preview.extCounts, { sessions: 1, meals: 1, body: 1, daily: 1, walks: 1, dayStates: 1, planEvents: 1, ownerSettings: 1 });
    const r = st2.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt });
    assert.equal(r.ok, true);
    HD.EXT_TYPES.forEach((t) => assert.deepEqual(st2.records(t), st.records(t), t));
    ['weight', 'workouts', 'nutrition'].forEach((t) => assert.deepEqual(st2.list(t), st.list(t), t));
    assert.equal(st2.settings().rhrBaselineBpm, 74);
    assert.equal(st2.exportJSON().replace(/"exportedAt": "[^"]+"/, ''), text.replace(/"exportedAt": "[^"]+"/, ''), 'a second export is identical');
  });
  it('a failed restore puts back the exact previous text, new fields included', () => {
    const { st } = full();
    const text = st.exportJSON();
    let armed = false, calls = 0;
    const s2 = mem(null, (k) => armed && k === KEY && ++calls === 1); const st2 = mk(s2);
    st2.putRecord('ownerSettings', { id: HD.SETTINGS_ID, date: '2026-11-18', rhrBaselineBpm: 70 });
    const before = s2.m[KEY];
    const p = st2.previewImport(text);
    armed = true;
    const r = st2.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt });
    assert.equal(r.ok, false); assert.equal(r.code, 'write_failed'); assert.equal(r.rolledBack, true);
    assert.equal(s2.m[KEY], before);
    assert.equal(JSON.parse(s2.m[PRE]).raw, before);
    assert.equal(st2.settings().rhrBaselineBpm, 70);
  });
  it('a restore that reads back with the wrong content is rolled back (verify covers Phase 3 lists)', () => {
    const { st } = full();
    const text = st.exportJSON();
    // storage that silently drops the walks list from what it stores
    const s2 = mem(); const real = s2.setItem.bind(s2); let armed = false;
    s2.setItem = (k, v) => real(k, armed && k === KEY && v.includes('"walks"') ? JSON.stringify(Object.assign(JSON.parse(v), { walks: [] })) : v);
    const st2 = mk(s2);
    const p = st2.previewImport(text);
    armed = true;
    const r = st2.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt });
    assert.equal(r.ok, false, 'never reports success for a restore that did not land intact');
  });
});
