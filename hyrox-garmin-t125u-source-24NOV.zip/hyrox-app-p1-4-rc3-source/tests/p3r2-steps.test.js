'use strict';
// Dawit R2 / D1: v2.1 §6 reference goals + 10k gate, separate from adaptive guidance. Synthetic data only.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const HW = require(path.resolve(__dirname, '../src/data/hyrox-wellness.js'));
const { HD, mem, mk, O, MISSING, ts, backup, restore } = require('./p8-helpers.js');

const day = (date, o) => Object.assign({ id: 'daily-' + date, createdAt: ts, date }, o);
const okGate = { footPain: O(1), limp: O(false), stairKneePain: O(0), sleepH: O(7) };
const ref = (date, dailyExtra, ctx) => HW.stepReferenceGoal(date, Object.assign({ dailies: dailyExtra ? [day(date, dailyExtra)] : [] }, ctx));

describe('reference goals by plan week (v2.1 §6)', () => {
  it('W1 7000, W2 8000, W3 9000 floors; W4 10000 only if tolerated; boundaries exact', () => {
    const cases = [['2026-11-16', 1, 7000, 'FLOOR'], ['2026-11-22', 1, 7000, 'FLOOR'], ['2026-11-23', 2, 8000, 'FLOOR'], ['2026-11-29', 2, 8000, 'FLOOR'],
      ['2026-11-30', 3, 9000, 'FLOOR'], ['2026-12-06', 3, 9000, 'FLOOR'], ['2026-12-07', 4, 10000, 'TARGET_IF_TOLERATED'], ['2026-12-13', 4, 10000, 'TARGET_IF_TOLERATED']];
    for (const [d, w, g, k] of cases) {
      const r = ref(d);
      assert.equal(r.week, w, d); assert.equal(r.goal, g, d); assert.equal(r.goalKind, k, d);
      assert.equal(r.kind, 'REFERENCE_GOAL'); assert.equal(r.source, 'HNC-BASE-v2.1 §6');
    }
  });
  it('Day 0 is a baseline day with no goal; before the block and after 2026-12-13 there is no goal (no plan invented)', () => {
    const d0 = ref('2026-11-15');
    assert.equal(d0.week, 0); assert.equal(d0.goal, null); assert.equal(d0.goalKind, 'BASELINE_DAY'); assert.equal(d0.status, 'NOT_APPLICABLE');
    for (const d of ['2026-11-14', '2026-12-14', '2027-01-15']) {
      const r = ref(d);
      assert.equal(r.week, null); assert.equal(r.goal, null); assert.equal(r.goalKind, 'NONE'); assert.equal(r.status, 'NOT_APPLICABLE'); assert.equal(r.met, null);
      assert.deepEqual(r.doNotForce, []);
    }
  });
});

describe('10k readiness gate', () => {
  it('step10kGate: PASS only when all four checks are recorded and pass; each failure fails it', () => {
    assert.equal(HW.step10kGate({ heelArchAchillesPain: 2, limp: false, stairKneePain: 2, sleepH: 6 }).status, 'PASS');
    assert.equal(HW.step10kGate({ footPain: 3, limp: false, stairKneePain: 0, sleepH: 8 }).status, 'FAIL');
    assert.deepEqual(HW.step10kGate({ footPain: 0, limp: true, stairKneePain: 0, sleepH: 8 }).failed, ['limp']);
    assert.deepEqual(HW.step10kGate({ footPain: 0, limp: false, stairKneePain: 3, sleepH: 8 }).failed, ['stairKneePain']);
    assert.deepEqual(HW.step10kGate({ footPain: 0, limp: false, stairKneePain: 0, sleepH: 5.9 }).failed, ['sleepH']);
    const u = HW.step10kGate({ footPain: 0, limp: false });
    assert.equal(u.status, 'UNKNOWN'); assert.equal(u.pass, false); assert.deepEqual(u.missing, ['stairKneePain', 'sleepH']);
    assert.equal(HW.step10kGate({ footPain: 5 }).status, 'FAIL', 'a recorded failure wins over missing checks');
    assert.equal(HW.step10kGate({}).status, 'UNKNOWN', 'nothing recorded is unknown, never PASS');
  });
  it('tenKGate reads the daily record; MISSING is unknown, not fine', () => {
    assert.equal(HW.tenKGate('2026-12-07', [day('2026-12-07', okGate)]).status, 'PASS');
    assert.equal(HW.tenKGate('2026-12-07', [day('2026-12-07', Object.assign({}, okGate, { limp: MISSING }))]).status, 'UNKNOWN');
    assert.equal(HW.tenKGate('2026-12-07', []).status, 'UNKNOWN');
  });
});

describe('status / doNotForce: a reference goal never forces walking through symptoms or a hard day', () => {
  it('W1–W3 floor is ACTIVE without symptoms even if gate data is missing', () => {
    const r = ref('2026-11-18');
    assert.equal(r.status, 'ACTIVE'); assert.deepEqual(r.doNotForce, []);
    assert.equal(r.optional10k.offered, false, 'optional 10k needs a passed gate');
  });
  it('optional 10k is offered in W1–W3 only with a passed gate and nothing else in the way', () => {
    assert.equal(ref('2026-11-18', okGate).optional10k.offered, true);
    assert.equal(ref('2026-11-18', okGate, { toughDay: true }).optional10k.offered, false);
  });
  it('each doNotForce code', () => {
    assert.deepEqual(ref('2026-11-18', { footPain: O(4) }).doNotForce, ['READINESS_GATE_FAILED']);
    assert.ok(ref('2026-11-18', { sleepH: O(5) }).doNotForce.includes('READINESS_FLAGS'));
    assert.deepEqual(ref('2026-11-18', { pain: O(4) }).doNotForce, ['PAIN_OVER_3']);
    assert.deepEqual(ref('2026-11-18', { pain: O(3) }).doNotForce, [], 'pain 3/10 does not exceed 3');
    assert.deepEqual(ref('2026-11-18', { soreness: O(7) }).doNotForce, ['READINESS_FLAGS']);
    assert.deepEqual(ref('2026-11-18', null, { toughDay: true }).doNotForce, ['TOUGH_TRAINING_DAY']);
    assert.deepEqual(ref('2026-11-18', null, { recentSessions: [{ date: '2026-11-18', status: 'COMPLETED', rpe: 8 }] }).doNotForce, ['TOUGH_TRAINING_DAY']);
    assert.deepEqual(ref('2026-11-18', null, { recentSessions: [{ date: '2026-11-18', status: 'PARTIAL', rpe: null, type: 'RACE' }] }).doNotForce, ['TOUGH_TRAINING_DAY']);
    assert.deepEqual(ref('2026-11-18', null, { recentSessions: [{ date: '2026-11-18', status: 'COMPLETED', rpe: 5 }] }).doNotForce, []);
    assert.deepEqual(ref('2026-11-18', null, { recentSessions: [{ date: '2026-11-18', status: 'SKIPPED', rpe: 9 }] }).doNotForce, [], 'a skipped session is not load');
    assert.deepEqual(ref('2026-11-18', null, { recentSessions: [{ date: '2026-11-17', status: 'COMPLETED', rpe: 9 }] }).doNotForce, [], 'reference goal looks at today only');
    assert.equal(ref('2026-11-18', { footPain: O(4) }).status, 'DO_NOT_FORCE');
  });
  it('W4: gate PASS -> ACTIVE 10000; gate FAIL or UNKNOWN -> DO_NOT_FORCE, goal still 10000 (no lower number invented)', () => {
    const pass = ref('2026-12-08', okGate);
    assert.equal(pass.status, 'ACTIVE'); assert.equal(pass.goal, 10000); assert.equal(pass.optional10k.offered, false);
    const fail = ref('2026-12-08', Object.assign({}, okGate, { stairKneePain: O(5) }));
    assert.equal(fail.status, 'DO_NOT_FORCE'); assert.deepEqual(fail.doNotForce, ['READINESS_GATE_FAILED']); assert.equal(fail.goal, 10000);
    const unk = ref('2026-12-08');
    assert.equal(unk.status, 'DO_NOT_FORCE'); assert.deepEqual(unk.doNotForce, ['READINESS_GATE_UNKNOWN']);
    assert.match(unk.note, /Do not force/);
  });
});

describe('met: measured steps vs the reference goal only', () => {
  const D = '2026-11-23'; // W2, goal 8000
  it('complete daily total at/above goal -> true; below -> false', () => {
    assert.equal(ref(D, { steps: O(8000) }).met, true);
    assert.equal(ref(D, { steps: O(7999) }).met, false);
  });
  it('lower bound at/above goal -> true; below -> null (unknown, not missed); nothing recorded -> null, never 0', () => {
    const walks = (n) => [{ id: 'w', date: D, durationMin: 30, steps: n }];
    assert.equal(ref(D, null, { walks: walks(8200) }).met, true);
    assert.equal(ref(D, null, { walks: walks(5000) }).met, null);
    const none = ref(D);
    assert.equal(none.met, null); assert.equal(none.steps.total, null);
  });
  it('DO_NOT_FORCE never turns met true', () => {
    const r = ref(D, { steps: O(4000), footPain: O(5) });
    assert.equal(r.status, 'DO_NOT_FORCE'); assert.equal(r.met, false);
  });
  it('a lowered adaptive target is met, but the reference goal is not (no retroactive satisfaction)', () => {
    const ctx = { dailies: [day(D, { steps: O(7000) })], walks: [], sessions: [], settings: { stepBaselineMode: 'MANUAL', stepBaselineManual: 8000 },
      plannedToday: 1, recentSessions: [{ date: D, status: 'COMPLETED', rpe: 8, type: 'INTERVALS' }] };
    const g = HW.stepGoals(D, ctx);
    assert.equal(g.guidance.target, 6800); assert.equal(g.guidance.met, true);
    assert.equal(g.reference.goal, 8000); assert.equal(g.reference.met, false);
    assert.equal(g.guidance.kind, 'ADAPTIVE_GUIDANCE'); assert.equal(g.reference.kind, 'REFERENCE_GOAL');
  });
  it('no inference from distance/time and no double counting: run blocks with distance add nothing; daily total wins', () => {
    const sess = [{ id: 's', date: D, status: 'COMPLETED', blocks: [{ kind: 'run', distanceM: 8000, durationSec: 3000 }] }];
    assert.equal(ref(D, null, { sessions: sess }).steps.total, null);
    const r = ref(D, { steps: O(9000) }, { walks: [{ id: 'w', date: D, durationMin: 30, steps: 4000 }], sessions: [Object.assign({ runSteps: 3000, runStepsSource: 'DEVICE' }, sess[0])] });
    assert.equal(r.steps.total, 9000); assert.equal(r.met, true);
  });
});

describe('no catch-up', () => {
  it('earlier missed or low days never change a later reference goal or adaptive target', () => {
    const D = '2026-11-25';
    const base = ref(D).goal;
    const low = HW.stepReferenceGoal(D, { dailies: ['2026-11-23', '2026-11-24'].map((d) => day(d, { steps: O(500) })) }).goal;
    const missing = HW.stepReferenceGoal(D, { dailies: ['2026-11-23', '2026-11-24'].map((d) => day(d, { steps: MISSING })) }).goal;
    assert.equal(base, 8000); assert.equal(low, 8000); assert.equal(missing, 8000);
  });
});

describe('adaptive guidance: labelled, configurable app suggestions; conservative fallback; gate priority', () => {
  const hist = (date, vals) => vals.map((v, i) => day(new Date(Date.parse(date) - (vals.length - i) * 86400000).toISOString().slice(0, 10), { steps: O(v) }));
  it('is labelled as not from v2.1 and reports the rules in use', () => {
    const t = HW.stepTarget('2026-11-18', { dailies: hist('2026-11-18', [8000, 8000, 8000]), plannedToday: 1 });
    assert.equal(t.heuristics.fromSource, false); assert.equal(t.heuristics.configurable, true);
    assert.match(t.heuristics.label, /NOT from HNC-BASE v2\.1/);
    assert.deepEqual(t.heuristics.rules, { lightDayPct: 10, afterDemandingPct: -15, highFatiguePct: -30, historyDays: 14, minObservations: 3, demandingRpe: 7 });
    assert.equal(t.fallback, null);
  });
  it('owner settings change the suggestion; out-of-range settings fall back to defaults', () => {
    const d = hist('2026-11-18', [8000, 8000, 8000]);
    assert.equal(HW.stepTarget('2026-11-18', { dailies: d, plannedToday: 0, settings: { stepLightDayPct: 0 } }).target, 8000);
    assert.equal(HW.stepTarget('2026-11-18', { dailies: d, plannedToday: 0, settings: { stepLightDayPct: 99 } }).target, 8800);
    assert.equal(HW.stepTarget('2026-11-18', { dailies: d, settings: { stepHighFatiguePct: -50 }, recentSessions: [] , plannedToday: 1 }).target, 8000);
    const sore = d.concat([day('2026-11-18', { soreness: O(8) })]);
    assert.equal(HW.stepTarget('2026-11-18', { dailies: sore, settings: { stepHighFatiguePct: -50 }, plannedToday: 1 }).target, 4000);
    assert.equal(HW.stepTarget('2026-11-18', { dailies: d, settings: { stepMinObservations: 5 }, plannedToday: 1 }).target, null);
  });
  it('sparse history: no invented number, explicit SPARSE_HISTORY fallback; a manual baseline is not sparse', () => {
    const t = HW.stepTarget('2026-11-18', { dailies: hist('2026-11-18', [9000]), plannedToday: 0 });
    assert.equal(t.target, null); assert.equal(t.fallback.code, 'SPARSE_HISTORY'); assert.equal(t.fallback.target, null);
    assert.equal(HW.stepTarget('2026-11-18', { settings: { stepBaselineMode: 'MANUAL', stepBaselineManual: 6000 } }).fallback, null);
  });
  it('a FAILED gate (any week) or UNKNOWN gate in W4 never raises the suggestion; recovery reductions still apply', () => {
    const m = { stepBaselineMode: 'MANUAL', stepBaselineManual: 8000 };
    assert.equal(HW.stepTarget('2026-11-18', { settings: m, plannedToday: 0 }).target, 8800, 'W1 unknown gate: light-day raise allowed');
    const failW1 = HW.stepTarget('2026-11-18', { settings: m, plannedToday: 0, dailies: [day('2026-11-18', { footPain: O(4) })] });
    assert.equal(failW1.target, 8000); assert.equal(failW1.gateHold, 'READINESS_GATE_FAILED');
    const unkW4 = HW.stepTarget('2026-12-09', { settings: m, plannedToday: 0 });
    assert.equal(unkW4.target, 8000); assert.equal(unkW4.gateHold, 'READINESS_GATE_UNKNOWN');
    const passW4 = HW.stepTarget('2026-12-09', { settings: m, plannedToday: 0, dailies: [day('2026-12-09', okGate)] });
    assert.equal(passW4.target, 8800); assert.equal(passW4.gateHold, null);
    const failSore = HW.stepTarget('2026-12-09', { settings: m, plannedToday: 0, dailies: [day('2026-12-09', { soreness: O(8), sleepH: O(5) })] });
    assert.equal(failSore.target, 5600, 'recovery reduction is kept, never raised');
  });
});

describe('storage: new daily gate fields and step-rule settings are validated; old data stays valid', () => {
  it('footPain / stairKneePain 0–10, limp boolean', () => {
    const st = mk(mem());
    assert.equal(st.putRecord('daily', { date: '2026-11-18', footPain: O(2), stairKneePain: O(1), limp: O(false) }).ok, true);
    assert.equal(st.putRecord('daily', { date: '2026-11-18', footPain: O(11) }).ok, false);
    assert.equal(st.putRecord('daily', { date: '2026-11-18', limp: O(1) }).ok, false);
    assert.equal(st.putRecord('daily', { date: '2026-11-18', limp: { state: 'MISSING', value: true } }).ok, false);
    assert.equal(st.putRecord('daily', { date: '2026-11-18', limp: { state: 'MISSING', value: null } }).ok, true);
  });
  it('owner step-rule settings: whole numbers within range; settings() fills defaults', () => {
    const st = mk(mem());
    assert.deepEqual([st.settings().stepLightDayPct, st.settings().stepAfterDemandingPct, st.settings().stepHighFatiguePct, st.settings().stepHistoryDays, st.settings().stepMinObservations], [10, -15, -30, 14, 3]);
    assert.equal(st.putRecord('ownerSettings', { id: HD.SETTINGS_ID, date: '2026-11-18', stepLightDayPct: 40 }).ok, false);
    assert.equal(st.putRecord('ownerSettings', { id: HD.SETTINGS_ID, date: '2026-11-18', stepMinObservations: 2 }).ok, false);
    assert.equal(st.putRecord('ownerSettings', { id: HD.SETTINGS_ID, date: '2026-11-18', stepAfterDemandingPct: -10.5 }).ok, false);
    assert.equal(st.putRecord('ownerSettings', { id: HD.SETTINGS_ID, date: '2026-11-18', stepAfterDemandingPct: -10, stepHistoryDays: 21 }).ok, true);
    assert.equal(st.settings().stepAfterDemandingPct, -10); assert.equal(st.settings().stepHistoryDays, 21);
  });
  it('a v2 backup with the new fields round-trips; an invalid one is refused with nothing written', () => {
    const st = mk(mem());
    assert.equal(restore(st, backup({ daily: [day('2026-11-18', okGate)] })).ok, true);
    assert.equal(st.records('daily')[0].limp.value, false);
    const s2 = mem(); const st2 = mk(s2); st2.addWeight({ date: '2026-11-18', kg: 80 });
    const before = JSON.stringify(s2.m);
    assert.equal(restore(st2, backup({ daily: [day('2026-11-18', { limp: O('no') })] })).ok, false);
    assert.equal(JSON.stringify(s2.m), before);
  });
});
