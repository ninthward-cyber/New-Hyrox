'use strict';
// Meron (QA): OWNER-DECISIONS-t47u.txt Decision 2 — weekend make-up and never-stack.
// F3 is resolved by that owner decision: "A gentle walk and a strength workout can
// coexist on the same day; 'never stack' prohibits the automatic stacking of two
// demanding sessions, not truthful logging of easy activity."
// Do not change rescheduleCheck in src/. Synthetic data only. New file.

const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const HP = require(path.resolve(__dirname, '../src/data/hyrox-plan.js'));
const HD = require(path.resolve(__dirname, '../src/data/hyrox-data.js'));
const { mem, mk } = require('./p8-helpers.js');

const TODAY = '2026-11-18'; // Wednesday W1
const SAT = '2026-11-21';
const SUN = '2026-11-22';
const NOW_FRI = new Date('2026-11-20T09:00:00Z');
const NOW_SAT = new Date('2026-11-21T09:00:00Z');
const mkAt = (now) => HD.createStore(mem(), { now: () => now });

function session(over) {
  return Object.assign({
    date: SAT, status: 'COMPLETED', modified: false, variant: 'NONE', blocks: [],
    title: 'Made-up session', rpe: 7, planSlotId: null,
  }, over);
}

describe('Decision 2 (already on this build): Friday skip, Mon/Wed cascade, optional weekend mobility, truthful weekend actuals, no auto-stack of two demanding sessions', () => {
  it('a missed Friday has no weekend make-up (unchanged source rule)', () => {
    // "Keep the approved missed-Monday/Wed cascade and Friday skip rules."
    const fri = HP.rescheduleCheck('v2.1-W1-FRI', SAT, [], [], TODAY);
    assert.equal(fri.ok, false);
    assert.match(fri.reason, /no weekend make-up/i);
    assert.deepEqual(HP.rescheduleDates('v2.1-W1-FRI', [], [], TODAY), []);
    const advice = HP.skipAdvice('v2.1-W1-FRI', [], [], TODAY);
    assert.match(advice.recommendation, /no weekend make-up/i);
  });

  it('the approved missed-Monday and missed-Wednesday cascades are unchanged', () => {
    const mon = HP.effectiveWeek(1, [{ kind: 'MISSED_MONDAY', week: 1 }]);
    assert.ok(!mon.unresolved);
    const tue = mon.days.filter((d) => d.date === '2026-11-17')[0];
    const thu = mon.days.filter((d) => d.date === '2026-11-19')[0];
    assert.ok(tue.show.some((x) => x.slot.id === 'v2.1-W1-MON' || (x.movedFrom === 'MON')));
    assert.ok(thu.omitted.some((o) => o.reason === 'MISSED_MONDAY_CASCADE'));
    const wed = HP.effectiveWeek(1, [{ kind: 'MISSED_WEDNESDAY', week: 1 }]);
    const thu2 = wed.days.filter((d) => d.date === '2026-11-19')[0];
    assert.ok(thu2.omitted.some((o) => o.reason === 'MISSED_WEDNESDAY_CASCADE'));
  });

  it('optional light Saturday activity from W2 and Sunday mobility remain available and are not counted as gym make-ups', () => {
    // "Optional light Saturday activity from W2 onward and Sunday mobility are not gym-session make-ups and remain available."
    assert.equal(HP.effectiveWeek(1, []).weekend, null, 'W1: source says no Saturday machines');
    const w2 = HP.effectiveWeek(2, []).weekend;
    assert.ok(w2);
    assert.equal(w2.counted, false);
    assert.match(w2.text, /optional/i);
    assert.match(w2.text, /Sunday mobility/i);
  });

  it('a weekend gym workout that is actually logged is stored as truthful ACTUAL work; the original missed prescription is neither erased nor relabelled', () => {
    // "If the owner really performs a weekend gym workout, preserve it as truthful ACTUAL work
    // without falsely presenting it as a source-approved reschedule or erasing/relabeling the original missed prescription."
    const st = mkAt(NOW_SAT);
    const skippedFri = session({
      date: '2026-11-20', planSlotId: 'v2.1-W1-FRI', status: 'SKIPPED', skipConfirmed: true,
      skipDecision: 'SKIP_PERMANENT', title: 'Made-up Friday skip', rpe: null, scheduledDate: '2026-11-20',
    });
    assert.equal(st.putRecord('sessions', skippedFri).ok, true);
    const weekendWork = session({
      date: SAT, planSlotId: null, status: 'COMPLETED', title: 'Made-up unplanned weekend gym work', rpe: 6,
    });
    assert.equal(st.putRecord('sessions', weekendWork).ok, true);
    const recs = st.records('sessions');
    const fri = recs.filter((s) => s.planSlotId === 'v2.1-W1-FRI')[0];
    const sat = recs.filter((s) => s.date === SAT)[0];
    assert.equal(fri.status, 'SKIPPED');
    assert.equal(fri.skipDecision, 'SKIP_PERMANENT');
    assert.equal(fri.date, '2026-11-20');
    assert.equal(sat.status, 'COMPLETED');
    assert.equal(HP.isActualWork(sat), true);
    const friStatus = HP.slotStatus('v2.1-W1-FRI', recs, []);
    assert.equal(friStatus.code, 'SKIPPED');
    assert.notEqual(friStatus.code, 'RESCHEDULE');
    // Not a source-approved reschedule of Friday: Friday skip stays, Saturday has no planSlotId.
    assert.equal(sat.planSlotId, null);
    assert.equal(sat.skipDecision, undefined);
  });

  it('two demanding planned sessions are not automatically stacked on one day', () => {
    // "'never stack' prohibits the automatic stacking of two demanding sessions"
    const chk = HP.rescheduleCheck('v2.1-W1-TUE', '2026-11-19', [], [], TODAY); // Thursday already has aerobic
    assert.equal(chk.ok, false);
    assert.match(chk.reason, /already has|never stacked/i);
    const logged = [session({ id: 'hard', date: SAT, title: 'Made-up intervals', rpe: 8, planSlotId: null, status: 'COMPLETED' })];
    const ontoLogged = HP.rescheduleCheck('v2.1-W1-TUE', SAT, logged, [], TODAY);
    assert.equal(ontoLogged.ok, false);
  });

  it('the data layer already accepts an easy walk record plus a strength session on the same weekday', () => {
    // "A gentle walk and a strength workout can coexist on the same day"
    const st = mkAt(new Date('2026-11-18T09:00:00Z'));
    assert.equal(st.putRecord('walks', { date: '2026-11-17', durationMin: 30, steps: 4000, notes: 'Easy walking' }).ok, true);
    const res = st.putRecord('sessions', session({
      date: '2026-11-17', planSlotId: 'v2.1-W1-TUE', title: 'Made-up strength session', rpe: 7, scheduledDate: '2026-11-17',
    }));
    assert.equal(res.ok, true, JSON.stringify(res));
    assert.equal(st.records('walks')[0].date, st.records('sessions')[0].date);
  });

  it('truthful logging: an easy walk *session* plus a strength workout on the same day is accepted by the data layer', () => {
    // Decision 2: "A gentle walk and a strength workout can coexist on the same day"
    const st = mkAt(new Date('2026-11-18T09:00:00Z'));
    const walkSess = session({
      date: '2026-11-17', title: 'Easy walking', rpe: 2, planSlotId: null, status: 'COMPLETED',
    });
    const strength = session({
      date: '2026-11-17', planSlotId: 'v2.1-W1-TUE', title: 'Made-up strength session', rpe: 7, scheduledDate: '2026-11-17',
    });
    assert.equal(st.putRecord('sessions', walkSess).ok, true);
    const res = st.putRecord('sessions', strength);
    assert.equal(res.ok, true, JSON.stringify(res));
    assert.equal(st.records('sessions').length, 2);
    assert.equal(st.records('sessions')[0].date, st.records('sessions')[1].date);
  });

});

describe('Decision 2: do not offer Sat/Sun as a make-up for any missed Mon–Fri gym session', () => {
  ['v2.1-W1-MON', 'v2.1-W1-TUE', 'v2.1-W1-WED', 'v2.1-W1-THU', 'v2.1-W1-FRI'].forEach((id) => {
    it('does not offer Sat or Sun as a make-up for ' + id, () => {
      const sat = HP.rescheduleCheck(id, SAT, [], [], TODAY);
      const sun = HP.rescheduleCheck(id, SUN, [], [], TODAY);
      const expectCode = id.endsWith('-FRI') ? 'FRIDAY_NO_WEEKEND_MAKEUP' : 'WEEKEND_NO_GYM_MAKEUP';
      assert.equal(sat.ok, false, id + ' Saturday: ' + JSON.stringify(sat));
      assert.equal(sat.code, expectCode, id + ' Saturday code: ' + JSON.stringify(sat));
      assert.equal(sun.ok, false, id + ' Sunday: ' + JSON.stringify(sun));
      assert.equal(sun.code, expectCode, id + ' Sunday code: ' + JSON.stringify(sun));
      const dates = HP.rescheduleDates(id, [], [], TODAY);
      assert.ok(!dates.includes(SAT) && !dates.includes(SUN), 'rescheduleDates still lists weekend: ' + dates.join(','));
      assert.match(sat.reason, /no weekend make-up/i);
    });
  });
});

describe('Decision 2 / F3: an easy walk session plus a workout on one weekday is allowed', () => {
  it('rescheduleCheck allows a planned session onto a weekday that only has an easy (low-RPE walk) session', () => {
    // Saturday cannot be used under Decision 2 (no weekend gym make-up). Date changed
    // to cascade-freed Monday 2026-11-23 (W2 Monday freed by a MISSED_MONDAY event).
    const DATE = '2026-11-23';
    const ev = [{ kind: 'MISSED_MONDAY', week: 2 }];
    const easyWalk = session({
      id: 'walk-mon', date: DATE, title: 'Easy walking', rpe: 2,
      planSlotId: null, status: 'COMPLETED', blocks: [{ kind: 'walk' }],
    });
    const chk = HP.rescheduleCheck('v2.1-W1-TUE', DATE, [easyWalk], ev, TODAY);
    assert.equal(chk.ok, true, JSON.stringify(chk));
    assert.equal(chk.code, 'OK');
  });
});

describe('Decision 2 open item (a): weekend-linked work no longer completes a weekday slot', () => {
  // Current behaviour, documented: a Saturday COMPLETED session pointing at a weekday
  // planSlotId is kept as actual work but does not mark the weekday slot COMPLETED.
  it('a Saturday session with a Tuesday planSlotId leaves Tuesday SKIPPED/NOT_LOGGED and is reported as weekendWork', () => {
    const skipped = session({
      date: '2026-11-17', planSlotId: 'v2.1-W1-TUE', status: 'SKIPPED', skipConfirmed: true,
      skipDecision: 'SKIP_PERMANENT', title: 'Made-up Tuesday skip', rpe: null, scheduledDate: '2026-11-17',
    });
    const satWork = session({
      date: SAT, planSlotId: 'v2.1-W1-TUE', status: 'COMPLETED', title: 'Made-up weekend attempt',
      rpe: 6, modified: true, variant: 'OTHER_EXECUTION',
    });
    const status = HP.slotStatus('v2.1-W1-TUE', [skipped, satWork], []);
    assert.equal(status.code, 'SKIPPED');
    assert.notEqual(status.code, 'COMPLETED');
    assert.equal(status.offPlan, 'WEEKEND_ACTUAL_NOT_SOURCE_RESCHEDULE');
    assert.equal(status.weekendWork.length, 1);
    assert.equal(status.weekendWork[0].date, SAT);
    assert.equal(HP.summary([skipped, satWork], []).COMPLETED, 0);
    assert.equal(HP.summary([skipped, satWork], []).weekendActual, 1);
  });
});
