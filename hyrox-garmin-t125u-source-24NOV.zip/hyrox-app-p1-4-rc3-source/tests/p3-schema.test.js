'use strict';
// DAWIT 4: schema v2 downgrade guard, and older (v1) backups keep their meaning,
// including photo-meal confirmation state and numeric NULL vs 0.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const HN = require(path.resolve(__dirname, '../src/data/hyrox-nutrition.js'));
const OLD = require(path.resolve(__dirname, 'fixtures/legacy/hyrox-data-64427c2.js'));
const { HD, NOW, KEY, PRE, mem, mk, O, MISSING, U, K, ts, backup, restore } = require('./p3-helpers.js');

const D = '2026-11-10';
const mkOld = (s) => OLD.createStore(s, { now: () => NOW });
const photo = (o) => Object.assign({ id: 'p', createdAt: ts, date: D, source: 'PHOTO_AI', lifecycle: 'CONFIRMED', confirmedAt: ts, ai: { mode: 'MOCK' },
  components: [{ name: 'rice', role: 'MAIN', kcal: K(400), proteinG: K(10), carbsG: U, fatG: K(0) }] }, o);

describe('schema version guard', () => {
  it('constants: this build writes 2 and still reads 1', () => {
    assert.equal(HD.VERSION, 2); assert.equal(HD.LEGACY_VERSION, 1);
  });
  it('a v1 backup that carries Phase 3 lists is stored as v2, so the Phase 2 build then refuses it', () => {
    const s = mem(); const st = mk(s);
    assert.equal(restore(st, backup({ walks: [{ id: 'w', createdAt: ts, date: D, durationMin: 30, steps: 100 }] }, 1)).ok, true);
    assert.equal(JSON.parse(s.m[KEY]).version, 2);
    assert.equal(mkOld(s).status().state, 'newer');
    assert.equal(mkOld(s).addWeight({ date: D, kg: 80 }).ok, false);
    assert.equal(JSON.parse(s.m[KEY]).walks.length, 1);
  });
  it('v2 storage is never stamped back down, even when every Phase 3 record is deleted', () => {
    const s = mem(); const st = mk(s);
    const w = st.putRecord('walks', { date: D, durationMin: 30 }).entry;
    assert.equal(st.removeRecord('walks', w.id), true);
    st.addWeight({ date: D, kg: 80 });
    assert.equal(JSON.parse(s.m[KEY]).version, 2);
    assert.equal(JSON.parse(st.exportJSON()).version, 2);
  });
  it('a stored version 2 without Phase 3 lists is kept at 2 on save (never lowered)', () => {
    const s = mem({ [KEY]: '{"version":2,"weight":[],"workouts":[],"nutrition":[]}' }); const st = mk(s);
    st.addWeight({ date: D, kg: 80 });
    assert.equal(JSON.parse(s.m[KEY]).version, 2);
  });
  it('newer data (v3) is refused in storage and on restore, and the bytes are untouched', () => {
    const raw = '{"version":3,"weight":[],"workouts":[],"nutrition":[],"future":[1]}';
    const s = mem({ [KEY]: raw }); const st = mk(s);
    assert.equal(st.status().state, 'newer');
    assert.equal(st.addWeight({ date: D, kg: 80 }).ok, false);
    assert.equal(st.putRecord('walks', { date: D, durationMin: 30 }).ok, false);
    assert.throws(() => st.exportJSON());
    const r = st.applyImport(backup({}), { confirm: 'REPLACE', expectCurrent: { weight: 0, workouts: 0, nutrition: 0 } });
    assert.equal(r.ok, false); assert.equal(r.code, 'storage_newer');
    assert.equal(s.m[KEY], raw); assert.equal(s.m[PRE], undefined);
    assert.equal(mk(mem()).previewImport(backup({}, 3)).code, 'unsupported_version');
    assert.equal(mk(mem()).previewImport(backup({}, 0)).code, 'unsupported_version');
    assert.equal(mk(mem()).previewImport(backup({}, '2')).code, 'unsupported_version');
  });
  it('the Phase 2 build refuses a v2 backup that contains the new step fields (no silent drop)', () => {
    const st = mk(mem());
    st.putRecord('sessions', { date: D, status: 'COMPLETED', modified: false, variant: 'NONE', blocks: [], runSteps: 5000, runStepsSource: 'DEVICE' });
    const os = mem(); const p = mkOld(os).previewImport(st.exportJSON());
    assert.equal(p.ok, false); assert.equal(p.code, 'unsupported_version'); assert.equal(os.writes, 0);
  });
});

describe('older (v1) backups keep their meaning', () => {
  it('classic v1 backup: NULL vs 0 and all fields round-trip exactly; stays v1 and Phase 2 readable', () => {
    const text = backup({ weight: [{ id: 'w', createdAt: ts, date: D, kg: 80.5 }],
      workouts: [{ id: 'k', createdAt: ts, date: D, activity: 'Run', durationMin: 30, partial: true, notes: '' }],
      nutrition: [{ id: 'n0', createdAt: ts, date: D, label: 'water', calories: 0, proteinG: 0 }, { id: 'n1', createdAt: ts, date: D, label: 'x', calories: 500, proteinG: 30.5 }] }, 1);
    const s = mem(); const st = mk(s);
    assert.equal(restore(st, text).ok, true);
    const stored = JSON.parse(s.m[KEY]);
    assert.equal(stored.version, 1);
    const orig = JSON.parse(text);
    ['weight', 'workouts', 'nutrition'].forEach((t) => assert.deepEqual(stored[t], orig[t]));
    assert.equal(stored.nutrition[0].calories, 0, 'a recorded 0 stays 0');
    assert.equal(mkOld(s).status().state, 'ok');
    const legacy = HN.legacyToMeal(stored.nutrition[0]);
    assert.equal(legacy.components[0].carbsG.value, null, 'classic entries never recorded carbs: unknown (null), not 0');
    assert.equal(legacy.components[0].kcal.value, 0);
  });
  it('Phase 3 v1 backup (Emergent-era shape): NULL/0 in macros, daily obs and walk steps keep their meaning', () => {
    const meal = { id: 'm', createdAt: ts, date: D, source: 'MANUAL', lifecycle: 'CONFIRMED', confirmedAt: ts,
      components: [{ name: 'tea', role: 'DRINK', kcal: K(0), proteinG: K(0), carbsG: U, fatG: { value: 0, state: 'ESTIMATED' } }] };
    const daily = { id: 'd', createdAt: ts, date: D, steps: O(0), sleepH: MISSING, rhr: { state: 'DECLINED', value: null } };
    const walks = [{ id: 'w0', createdAt: ts, date: D, durationMin: 20, steps: 0 }, { id: 'w1', createdAt: ts, date: D, durationMin: 20, steps: null }];
    const text = backup({ meals: [meal], daily: [daily], walks }, 1);
    const s = mem(); const st = mk(s);
    assert.equal(restore(st, text).ok, true);
    const back = JSON.parse(st.exportJSON());
    assert.deepEqual(back.meals[0], meal); assert.deepEqual(back.daily[0], daily);
    assert.deepEqual(back.walks.sort((a, b) => a.id < b.id ? -1 : 1), walks);
    const t = HN.mealTotals(back.meals[0]);
    assert.equal(t.kcal.value, 0); assert.equal(t.kcal.state, 'KNOWN'); assert.equal(t.carbsG.value, null); assert.equal(t.carbsG.state, 'UNKNOWN');
    assert.equal(back.walks.find((w) => w.id === 'w1').steps, null);
  });
  it('photo meals: DRAFT / NEEDS_REVIEW stay unconfirmed and never count; CONFIRMED with a stated fraction counts scaled', () => {
    const meals = [photo({ id: 'a', lifecycle: 'DRAFT', confirmedAt: undefined }), photo({ id: 'b', lifecycle: 'NEEDS_REVIEW', confirmedAt: undefined }),
      photo({ id: 'c', eatenFraction: 0.5 })];
    const text = backup({ meals }, 1);
    const s = mem(); const st = mk(s);
    assert.equal(restore(st, text).ok, true);
    const got = st.records('meals');
    assert.deepEqual(got.map((m) => m.id + ':' + m.lifecycle).sort(), ['a:DRAFT', 'b:NEEDS_REVIEW', 'c:CONFIRMED']);
    const ds = HN.dayState(D, got, null);
    assert.equal(ds.confirmedCount, 1); assert.equal(ds.draftCount, 2);
    assert.equal(ds.subtotal.kcal.value, 200, 'only the confirmed meal, at 50%');
    assert.equal(got.find((m) => m.id === 'c').eatenFraction, 0.5);
  });
  it('FINDING: an older CONFIRMED photo meal with no stated eaten fraction is never counted as eaten whole — import refuses the file; in storage it is hidden, counted as omitted, and kept byte-exact for raw recovery', () => {
    const old = photo({ id: 'legacy-photo' }); // no eatenFraction anywhere: pre-owner-rule-2 shape
    const text = backup({ meals: [old] }, 1);
    const s0 = mem(); const st0 = mk(s0); st0.addWeight({ date: D, kg: 80 }); const before = s0.m[KEY];
    const p = st0.previewImport(text);
    assert.equal(p.ok, false); assert.equal(p.code, 'invalid_records'); assert.equal(p.errors[0].field, 'eatenFraction');
    assert.equal(s0.m[KEY], before);
    const raw = JSON.stringify({ version: 1, weight: [], workouts: [], nutrition: [], meals: [old] });
    const s = mem({ [KEY]: raw }); const st = mk(s);
    assert.equal(st.status().state, 'ok');
    assert.equal(st.records('meals').length, 0, 'not shown, not totalled');
    assert.deepEqual(st.exportSummary().omittedExt, { meals: 1 });
    const r = st.rawRecoveryExport();
    assert.equal(r.omittedTotal, 1);
    assert.equal(HD.parseRawRecovery(r.text).sources[0].raw, raw);
    assert.equal(s.m[KEY], raw, 'nothing rewritten');
  });
  it('unknown fields on v1 Phase 3 records are kept through restore and export', () => {
    const walk = { id: 'w', createdAt: ts, date: D, durationMin: 20, futureField: { a: 1 } };
    const s = mem(); const st = mk(s);
    assert.equal(restore(st, backup({ walks: [walk] }, 1)).ok, true);
    assert.deepEqual(JSON.parse(st.exportJSON()).walks[0], walk);
  });
});
