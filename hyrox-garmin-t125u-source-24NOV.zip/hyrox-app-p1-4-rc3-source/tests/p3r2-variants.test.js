'use strict';
// Dawit R2 / D3: HNC-BASE v2.1 §9 45/25-minute fallbacks. Synthetic data only.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const HD = require(path.resolve(__dirname, '../src/data/hyrox-data.js'));
const HP = require(path.resolve(__dirname, '../src/data/hyrox-plan.js'));
const { mem } = require('./p8-helpers.js');

const txt = (p) => p.prescription.join('\n');
const LOADS = /\b\d+(\.\d+)?\s*(kg|lb)\b/i;
const mkst = () => HD.createStore(mem(), { now: () => new Date('2026-12-12T10:00:00Z') });

describe('variantPrescription / fallbackPrescription', () => {
  it('fallbackPrescription is the same function; unknown slot or a variant without a prescription -> null', () => {
    assert.equal(HP.fallbackPrescription, HP.variantPrescription);
    assert.equal(HP.variantPrescription('v2.1-W5-MON', 'SOURCE_45_MIN'), null);
    assert.equal(HP.variantPrescription('v2.1-W1-MON', 'OTHER_EXECUTION'), null);
    assert.equal(HP.variantPrescription('v2.1-W1-MON', 'NONE'), null);
    assert.equal(HP.variantPrescription(HP.slotById('v2.1-W1-MON'), 'SOURCE_25_MIN').variantKind, 'STRENGTH_25');
  });
  it('variantKind and prescribed minutes match workout type for all 20 slots', () => {
    for (const sl of HP.SLOTS) {
      const strength = sl.type === 'STRENGTH_A' || sl.type === 'STRENGTH_B';
      const p45 = HP.variantPrescription(sl.id, 'SOURCE_45_MIN'), p25 = HP.variantPrescription(sl.id, 'SOURCE_25_MIN'), p60 = HP.variantPrescription(sl.id, 'ORIGINAL_60');
      assert.equal(p45.variantKind, strength ? 'MAIN_LIFT_45' : 'MAIN_CIRCUIT_45'); assert.equal(p45.prescribedDurationMin, 45);
      assert.equal(p25.variantKind, strength ? 'STRENGTH_25' : 'HYROX_25'); assert.equal(p25.prescribedDurationMin, 25);
      assert.equal(p60.variantKind, 'ORIGINAL'); assert.deepEqual(p60.prescription, sl.prescription);
      for (const p of [p45, p25]) {
        assert.equal(p.source, 'HNC-BASE-v2.1 §9');
        assert.doesNotMatch(txt(p), LOADS, 'no loads invented: ' + sl.id);
        for (const b of p.blocks) for (const k of ['sets', 'reps', 'loadKg', 'distanceM', 'durationSec']) assert.equal(b[k], undefined, sl.id + ' ' + b.label + ' ' + k);
      }
    }
  });
});

describe('45 minutes: main lift OR main HYROX circuit; accessories dropped', () => {
  it('Strength A: back squat with that week\'s sets; bench/row optional-unspecified; back extension and dead bug dropped', () => {
    for (const [w, sets] of [[1, 2], [2, 3], [3, 3], [4, 2]]) {
      const p = HP.variantPrescription('v2.1-W' + w + '-MON', 'SOURCE_45_MIN');
      assert.match(txt(p), /Main lift — Back squat/);
      assert.doesNotMatch(txt(p), /dead bug|back extension|farmer|deadlift/i);
      assert.deepEqual(p.drop, ['Back extension', 'Dead bug']);
      const squat = p.blocks.filter((b) => b.exercise === 'Back squat')[0];
      assert.equal(squat.prescribedSets, sets); assert.equal(squat.sourceStatus, 'SOURCE');
      assert.ok(p.blocks.filter((b) => b.optional).every((b) => b.sourceStatus === 'UNSPECIFIED'));
      assert.ok(p.unspecified.some((u) => u.key === 'secondaryCompound'));
    }
  });
  it('Strength B: deadlift main lift; incline DB press and farmer carries dropped', () => {
    const p = HP.variantPrescription('v2.1-W2-WED', 'SOURCE_45_MIN');
    assert.match(txt(p), /Main lift — Deadlift/); assert.doesNotMatch(txt(p), /incline|farmer|squat/i);
    assert.equal(p.blocks.some((b) => b.kind === 'farmer_carry'), false);
  });
  it('Tuesday keeps the run/SkiErg rounds of the week; sled is optional-unspecified', () => {
    const p = HP.variantPrescription('v2.1-W3-TUE', 'SOURCE_45_MIN');
    assert.match(txt(p), /4 rounds: 500 m controlled run/);
    assert.equal(p.blocks.filter((b) => b.kind === 'skierg').length, 4);
    assert.ok(p.blocks.filter((b) => b.kind === 'sled_push' || b.kind === 'sled_pull').every((b) => b.optional && b.sourceStatus === 'UNSPECIFIED'));
  });
  it('Thursday keeps run-walk, rower and SkiErg and trims mobility; Friday keeps the rounds and drops sled technique', () => {
    const thu = HP.variantPrescription('v2.1-W1-THU', 'SOURCE_45_MIN');
    assert.equal(thu.blocks.some((b) => b.kind === 'mobility'), false);
    assert.deepEqual(thu.blocks.filter((b) => b.machine).map((b) => b.kind), ['run', 'row', 'skierg']);
    const fri = HP.variantPrescription('v2.1-W2-FRI', 'SOURCE_45_MIN');
    assert.match(txt(fri), /2 rounds/); assert.deepEqual(fri.drop, ['Optional light sled technique']);
    assert.match(txt(fri), /not benchmark-comparable/);
  });
});

describe('25 minutes', () => {
  it('Strength: brief warm-up + 2 working sets each of squat+bench (A) or deadlift+press (B); reps/loads unspecified', () => {
    const mon = HP.variantPrescription('v2.1-W1-MON', 'SOURCE_25_MIN'), wed = HP.variantPrescription('v2.1-W3-WED', 'SOURCE_25_MIN');
    assert.deepEqual(mon.blocks.map((b) => [b.kind, b.exercise || null, b.prescribedSets || null]), [['warmup', null, null], ['strength_set', 'Back squat', 2], ['strength_set', 'Bench press', 2]]);
    assert.deepEqual(wed.blocks.map((b) => [b.kind, b.exercise || null, b.prescribedSets || null]), [['warmup', null, null], ['strength_set', 'Deadlift', 2], ['strength_set', 'Overhead press', 2]]);
    assert.doesNotMatch(txt(mon), /deadlift/i); assert.doesNotMatch(txt(wed), /squat/i);
    assert.ok(mon.unspecified.some((u) => u.key === 'repsLoadRpe'));
  });
  it('matches the PLANNED session type even when the cascade moves it (Strength A on Tuesday stays squat+bench)', () => {
    const eff = HP.effectiveWeek(1, [{ kind: 'MISSED_MONDAY', week: 1 }]);
    const moved = eff.days[1].show[0].slot;
    assert.equal(moved.id, 'v2.1-W1-MON');
    const p = HP.variantPrescription(moved.id, 'SOURCE_25_MIN');
    assert.match(txt(p), /Back squat: 2 working sets/); assert.match(txt(p), /Bench press: 2 working sets/);
    assert.equal(HP.variantDraft(moved.id, 'SOURCE_25_MIN', '2026-11-17').scheduledDate, '2026-11-16');
  });
  it('HYROX (Tue/Thu/Fri): 5 min warm-up, 2 short run + station rounds, 3 min cooldown; distance and station unspecified', () => {
    for (const d of ['TUE', 'THU', 'FRI']) {
      const p = HP.variantPrescription('v2.1-W2-' + d, 'SOURCE_25_MIN');
      assert.deepEqual(p.prescription.slice(0, 3).map((l) => l.slice(0, 12)), ['5 min warm-u', '2 short roun', '3 min cooldo']);
      assert.deepEqual(p.blocks.map((b) => b.kind), ['warmup', 'run', 'other', 'run', 'other', 'cooldown']);
      assert.equal(p.blocks[0].prescribedDurationSec, 300); assert.equal(p.blocks[5].prescribedDurationSec, 180);
      assert.ok(p.blocks.filter((b) => b.kind === 'other').every((b) => b.sourceStatus === 'UNSPECIFIED' && b.stationOptions.length > 0));
      assert.doesNotMatch(txt(p), /squat|deadlift|bench press/i);
      assert.deepEqual(p.unspecified.map((u) => u.key), ['runDistance', 'station']);
    }
  });
});

describe('logging: prescribed variant vs actual duration vs actual completion', () => {
  it('variantDraft is NOT_STARTED with no actual duration, and is accepted by the store as is', () => {
    const st = mkst();
    for (const v of ['ORIGINAL_60', 'SOURCE_45_MIN', 'SOURCE_25_MIN']) {
      const d = HP.variantDraft('v2.1-W2-THU', v);
      assert.equal(d.status, 'NOT_STARTED'); assert.equal(d.durationMin, null); assert.equal(d.prescribedDurationMin, { ORIGINAL_60: 60, SOURCE_45_MIN: 45, SOURCE_25_MIN: 25 }[v]);
      const r = st.putRecord('sessions', d);
      assert.equal(r.ok, true, JSON.stringify(r.errors));
    }
    assert.equal(HP.variantDraft('v2.1-W2-THU', 'NONE'), null);
  });
  it('a saved draft is not a completed session; summary keeps 20 planned and no qualifying numerator', () => {
    const st = mkst();
    st.putRecord('sessions', HP.variantDraft('v2.1-W1-MON', 'SOURCE_25_MIN'));
    let sum = HP.summary(st.records('sessions'), []);
    assert.equal(sum.COMPLETED, 0); assert.equal(sum.NOT_STARTED, 1); assert.equal(sum.planned, 20); assert.equal(sum.denominator, 20);
    assert.equal(sum.qualifyingNumerator, null); assert.equal(sum.numeratorStatus, 'OWNER_DECISION_PENDING');
    assert.deepEqual(sum.variants.SOURCE_25_MIN, { NOT_STARTED: 1 });
    const done = Object.assign(HP.variantDraft('v2.1-W1-TUE', 'SOURCE_45_MIN'), { status: 'PARTIAL', durationMin: 38 });
    st.putRecord('sessions', done);
    sum = HP.summary(st.records('sessions'), []);
    assert.deepEqual(sum.variants.SOURCE_45_MIN, { PARTIAL: 1 }); assert.equal(sum.fallback, 2); assert.equal(sum.qualifyingNumerator, null);
    assert.match(sum.note, /OPEN owner decision/);
    const s = HP.slotStatus('v2.1-W1-TUE', st.records('sessions'), []);
    assert.equal(s.variantKind, 'MAIN_CIRCUIT_45'); assert.equal(s.prescribedDurationMin, 45); assert.equal(s.session.durationMin, 38);
  });
  it('validation: prescribedDurationMin must match variant; variantKind must match variant and slot type', () => {
    const st = mkst();
    const base = { date: '2026-11-16', planSlotId: 'v2.1-W1-MON', status: 'COMPLETED', modified: false, blocks: [] };
    const put = (o) => st.putRecord('sessions', Object.assign({}, base, o)).ok;
    assert.equal(put({ variant: 'SOURCE_25_MIN', prescribedDurationMin: 45 }), false);
    assert.equal(put({ variant: 'OTHER_EXECUTION', prescribedDurationMin: 25 }), false);
    assert.equal(put({ variant: 'SOURCE_25_MIN', variantKind: 'MAIN_LIFT_45' }), false);
    assert.equal(put({ variant: 'SOURCE_25_MIN', variantKind: 'HYROX_25' }), false, 'HYROX fallback on a strength slot');
    assert.equal(put({ variant: 'SOURCE_45_MIN', variantKind: 'MAIN_CIRCUIT_45', planSlotId: 'v2.1-W1-WED' }), false);
    assert.equal(put({ variant: 'SOURCE_45_MIN', variantKind: 'MAIN_LIFT_45', planSlotId: 'v2.1-W1-TUE', date: '2026-11-17' }), false, 'strength fallback on a HYROX slot');
    assert.equal(put({ variant: 'SOURCE_25_MIN', variantKind: 'BOGUS' }), false);
    assert.equal(put({ variant: 'SOURCE_25_MIN', variantKind: 'STRENGTH_25', prescribedDurationMin: 25, durationMin: 31 }), true, 'actual may differ from prescribed');
    assert.equal(put({ variant: 'SOURCE_25_MIN', planSlotId: null, variantKind: 'HYROX_25' }), true, 'no slot: kind must only match the variant');
    assert.equal(put({ variant: 'SOURCE_45_MIN' }), true, 'older variant records without the new fields stay valid');
    assert.equal(put({ variant: 'NONE', blocks: [{ kind: 'strength_set', prescribedSets: -1 }] }), false);
    assert.equal(put({ variant: 'NONE', blocks: [{ kind: 'other', sourceStatus: 'MAYBE' }] }), false);
    assert.equal(put({ variant: 'NONE', blocks: [{ kind: 'other', stationOptions: 'SkiErg' }] }), false);
    assert.equal(put({ variant: 'NONE', blocks: [{ kind: 'other', optional: 'yes' }] }), false);
  });
  it('the 15-minute per-machine check still applies to variant blocks (never clipped)', () => {
    const p = HP.variantPrescription('v2.1-W1-THU', 'SOURCE_45_MIN');
    const row = Object.assign({}, p.blocks.filter((b) => b.kind === 'row')[0]);
    assert.equal(HP.machineCompliance(row), 'UNVERIFIED');
    assert.equal(HP.machineCompliance(Object.assign({}, row, { durationSec: 900 })), 'WITHIN_LIMIT');
    const over = Object.assign({}, row, { durationSec: 960 });
    assert.equal(HP.machineCompliance(over), 'OVERRUN'); assert.equal(over.durationSec, 960);
    const station = Object.assign({}, HP.variantPrescription('v2.1-W1-THU', 'SOURCE_25_MIN').blocks[2], { kind: 'row', durationSec: 1000 });
    assert.equal(HP.machineCompliance(station), 'OVERRUN');
  });
  it('variantBlocks: invalid type/week/variant -> null; ORIGINAL_60 -> the normal template', () => {
    assert.equal(HP.variantBlocks('YOGA', 1, 'SOURCE_25_MIN'), null);
    assert.equal(HP.variantBlocks('RACE', 5, 'SOURCE_25_MIN'), null);
    assert.equal(HP.variantBlocks('RACE', 1, 'NONE'), null);
    assert.deepEqual(HP.variantBlocks('RACE', 2, 'ORIGINAL_60'), HP.templateBlocks('RACE', 2));
  });
});
