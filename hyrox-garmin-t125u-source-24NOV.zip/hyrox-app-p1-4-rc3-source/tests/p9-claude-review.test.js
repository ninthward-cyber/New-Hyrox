'use strict';
// Claude Phase 9 independent review: the spend ledger must never record $0 for a call that OpenAI answered.
// FAILS on Grok's Phase 9: a successful response with no `usage` object was settled at $0 (the reservation was released).
const test = require('node:test');
const assert = require('node:assert/strict');

test('a successful answer without a usage figure is charged the reservation, never $0', async () => {
  const H = await import('./p9-helpers.mjs');
  const ctx = H.setup({ script: () => { const r = H.openaiOk(); delete r.body.usage; return r; } });
  const res = await ctx.handle(H.analyzeReq());
  assert.equal(res.status, 200);
  const L = ctx.store.m.get('ledger/v1').data;
  assert.equal(L.total.calls, 1);
  assert.equal(L.total.usd, 0.004, 'charged at HYROX_RESERVE_USD (default 0.004)');
  assert.equal(L.month.usd, 0.004);
  assert.deepEqual(L.inflight, {});
});

test('with a usage figure the real cost is charged (unchanged), and an unbilled provider rejection still costs nothing', async () => {
  const H = await import('./p9-helpers.mjs');
  const ok = H.setup();
  await ok.handle(H.analyzeReq());
  assert.equal(ok.store.m.get('ledger/v1').data.total.usd, (2700 * 0.10 + 900 * 0.50) / 1e6);
  const rej = H.setup({ script: () => ({ status: 401, body: { error: { code: 'invalid_api_key' } } }) });
  await rej.handle(H.analyzeReq());
  const L = rej.store.m.get('ledger/v1').data;
  assert.equal(L.total.usd, 0); assert.equal(L.total.calls, 0, 'unbilled rejection does not count as a call');
});
