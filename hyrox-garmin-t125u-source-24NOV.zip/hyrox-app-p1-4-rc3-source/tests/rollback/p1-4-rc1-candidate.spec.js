'use strict';
// P1.4-RC1 integrated round trip, run AGAINST THE CANDIDATE (copied into a clean candidate copy's tests/e2e).
// P14_MODE=write : open P14_IN (candidate storage), resume the Sprint B draft envelope check, export the candidate backup -> P14_CAND_BACKUP.
// P14_MODE=forward : open the storage an older build wrote back (P14_IN_STORAGE) -> every record kept, 766 kcal photo meal, Export for
//   AI Coaching still builds a snapshot from it; then Restore the older build's backup (P14_IN_BACKUP) through the candidate's preview.
// CHROME MOBILE EMULATION, NOT SAFARI/WEBKIT. Synthetic data.
const { test, expect } = require('@playwright/test');
const fs = require('fs');
const CAND = JSON.parse(fs.readFileSync(process.env.P14_IN, 'utf8'));
const ids = (v) => { const o = {}; for (const k of Object.keys(v).sort()) if (Array.isArray(v[k])) o[k] = v[k].map((r) => (r && (r.id || r.date)) || '?').sort(); return o; };
const stored = (page) => page.evaluate(() => JSON.parse(localStorage.getItem('hyrox.v1') || '{}'));
const want = ids(JSON.parse(CAND['hyrox.v1']));
test.beforeEach(async ({ page }) => { await page.clock.setFixedTime(new Date('2026-11-18T09:00:00.000Z')); });
if (process.env.P14_MODE === 'write') test('candidate: storage opens, the draft is offered, and the candidate backup keeps every record', async ({ page }) => {
  const errs = []; page.on('pageerror', (e) => errs.push(e.message));
  await page.goto('./');
  await page.evaluate((s) => { localStorage.clear(); for (const k of Object.keys(s)) localStorage.setItem(k, s[k]); }, CAND);
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
  await expect(page.getByTestId('today-workout-draft')).toBeVisible();
  const [dl] = await Promise.all([page.waitForEvent('download'), page.getByTestId('tab-settings').click().then(() => page.getByTestId('export-btn').click())]);
  const text = fs.readFileSync(await dl.path(), 'utf8');
  for (const k of Object.keys(want)) expect(ids(JSON.parse(text))[k] || [], k).toEqual(want[k]);
  fs.writeFileSync(process.env.P14_CAND_BACKUP, text);
  expect(errs).toEqual([]);
});
if (process.env.P14_MODE === 'forward') test('candidate reads what an older build wrote back, exports a coaching snapshot from it, and restores that build\'s backup', async ({ page }) => {
  const errs = []; page.on('pageerror', (e) => errs.push(e.message));
  const back = JSON.parse(fs.readFileSync(process.env.P14_IN_STORAGE, 'utf8'));
  await page.addInitScript(() => { Object.defineProperty(navigator, 'canShare', { value: undefined, configurable: true }); Object.defineProperty(navigator, 'share', { value: undefined, configurable: true }); });
  await page.goto('./');
  await page.evaluate((s) => { localStorage.clear(); localStorage.setItem('hyrox.v1', JSON.stringify(s)); }, back);
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
  await expect(page.getByTestId('damaged-banner')).toHaveCount(0);
  expect(ids(await stored(page))).toEqual(want);
  await page.getByTestId('tab-history').click();
  await expect(page.getByTestId('history-meal').filter({ hasText: '766' })).toHaveCount(1);
  await page.getByTestId('tab-settings').click();
  await expect(page.getByTestId('ce-preview')).toBeVisible();
  const [dl] = await Promise.all([page.waitForEvent('download'), page.getByTestId('ce-create').click()]);
  const snap = JSON.parse(fs.readFileSync(await dl.path(), 'utf8'));
  expect(snap.kind).toBe('hyrox-coaching-snapshot');
  expect(snap.nutrition.meals.some((m) => m.id === 'meal-p0-1')).toBe(true);
  await page.getByTestId('import-file').setInputFiles({ name: 'hyrox-backup.json', mimeType: 'application/json', buffer: fs.readFileSync(process.env.P14_IN_BACKUP) });
  await expect(page.getByTestId('import-preview')).toBeVisible();
  await page.getByTestId('import-confirm').click();
  await expect.poll(async () => JSON.stringify(ids(await stored(page)))).toBe(JSON.stringify(want));
  expect(errs).toEqual([]);
});
