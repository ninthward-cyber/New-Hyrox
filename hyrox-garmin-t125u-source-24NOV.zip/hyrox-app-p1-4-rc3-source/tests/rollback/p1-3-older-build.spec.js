'use strict';
// P1.3 downgrade check, run AGAINST AN OLDER BUILD (a copy of it; this file is copied into that copy's tests/e2e): storage written by
// P1.3 (nutritionCoach on the settings record, Home closeout declarations, plan blocks, saved foods, favourites, weight unit) must
// load without error in the older build, survive that build's own settings save, and come back out in its backup.
// The final storage is written to P13_ROLLBACK_OUT so the roll-forward check can load it in P1.3 again.
// Not part of the normal suite. CHROME MOBILE EMULATION, NOT SAFARI/WEBKIT. Synthetic data only.
const { test, expect } = require('@playwright/test');
const fs = require('fs');
const T = '2026-11-01T06:00:00.000Z';
const COACH = { schema: 1, enabled: true, profile: { heightCm: 178, heightUnit: 'cm', ageYears: 49, ageEnteredOn: '2026-11-01', ageConfirmedOn: '2026-11-01', estimateMethod: 'EQUATION', sexForEquation: 'MALE', activity: 'A2' },
  goal: { id: 'LOSE_1', setAt: '2026-11-01' },
  target: { kcal: 2200, proteinG: 190, fatG: 60, carbsG: null, origin: 'OWNER_ENTERED', method: 'OWNER', effectiveDate: '2026-11-02', confirmedAt: '2026-11-02T06:00:00.000Z', reason: 'synthetic', version: 'coach-1', goal: 'LOSE_1', inputs: null, warnings: [], replaced: { kcal: 2400, proteinG: 190, fatG: null, carbsG: null, origin: 'PROVISIONAL' } },
  history: [] };
COACH.history = [COACH.target];
const SET = { id: 'app-settings', date: '2026-11-11', createdAt: T, rhrBaselineBpm: 61, rhrBaselineSource: 'OWNER_SET', stepBaselineMode: 'AUTO', weightUnit: 'lb',
  myFoods: [{ id: 'mf-syn', name: 'Synthetic oats', basis: 'PER_SERVING', servingLabel: '1 bowl', kcal: 150, proteinG: 5, carbsG: 27, fatG: 3, createdAt: T }], favFoods: ['MY:mf-syn'], planBlocks: [],
  nutritionCoach: COACH };
const SEED = { version: 2, weight: [{ id: 'w-a', date: '2026-11-22', kg: 97.5, createdAt: T }], workouts: [], nutrition: [], ownerSettings: [SET] };
const stored = (page) => page.evaluate(() => JSON.parse(localStorage.getItem('hyrox.v1') || '{}'));

test('older build: P1.3 storage loads cleanly and keeps nutritionCoach, saved foods, favourites and the unit through its own settings save and its backup', async ({ page }) => {
  const errs = []; page.on('pageerror', (e) => errs.push(e.message));
  await page.clock.setFixedTime(new Date('2026-11-23T09:00:00.000Z'));
  await page.goto('./');
  await page.evaluate((s) => { localStorage.clear(); localStorage.setItem('hyrox.v1', JSON.stringify(s)); }, SEED);
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
  await expect(page.getByTestId('damaged-banner')).toHaveCount(0);
  await page.getByTestId('tab-settings').click();
  await expect(page.getByTestId('owner-settings-damaged')).toHaveCount(0);
  await page.getByTestId('set-rhr-baseline').fill('60'); await page.getByTestId('set-save').click();
  await expect.poll(async () => (await stored(page)).ownerSettings[0].rhrBaselineBpm).toBe(60);
  const s = await stored(page);
  expect(s.ownerSettings[0].nutritionCoach).toEqual(COACH);
  expect(s.ownerSettings[0].myFoods).toEqual(SET.myFoods);
  expect(s.ownerSettings[0].favFoods).toEqual(SET.favFoods);
  expect(s.ownerSettings[0].weightUnit).toBe('lb');
  const [dl] = await Promise.all([page.waitForEvent('download'), page.getByTestId('export-btn').click()]);
  const b = JSON.parse(fs.readFileSync(await dl.path(), 'utf8'));
  expect(b.ownerSettings[0].nutritionCoach).toEqual(COACH);
  if (process.env.P13_ROLLBACK_OUT) fs.writeFileSync(process.env.P13_ROLLBACK_OUT, JSON.stringify(s));
  expect(errs).toEqual([]);
});
