'use strict';
// Sprint B2 downgrade check, run AGAINST AN OLDER BUILD (copied into that build's tests/e2e): a meal draft written by the
// candidate (UI-only key hyrox.ui.meal-draft) is ignored harmlessly: the app opens without error, the draft is never counted
// or shown as a meal, the older build's own meal save and backup leave the key byte-identical and never include it.
// Writes every localStorage key to P2B_OUT for the roll-forward check. CHROME MOBILE EMULATION, NOT SAFARI/WEBKIT. Synthetic.
const { test, expect } = require('@playwright/test');
const fs = require('fs');
const TS = '2026-11-18T05:00:00.000Z', E = (v) => ({ value: v, state: 'ESTIMATED' });
const SEED = { version: 2, weight: [], workouts: [], nutrition: [], meals: [{ id: 'meal-seed-1', date: '2026-11-18', time: '08:00', label: '', source: 'MANUAL', description: 'seed breakfast', eatenFraction: 1,
  lifecycle: 'CONFIRMED', confirmedAt: TS, createdAt: TS, updatedAt: TS, components: [{ name: 'Oats', role: 'MAIN', portion: '1 bowl', preparation: '', eatenFraction: null, kcal: E(500), proteinG: E(20), carbsG: E(80), fatG: E(8) }] }] };
const DRAFT = JSON.stringify({ v: 1, kind: 'hyrox-meal-draft', savedAt: '2026-11-18T08:30:00.000Z', day: '2026-11-18', draftId: 'md-rollback-1', baseUpdatedAt: null, photoCount: 1, estimatePending: false,
  ctx: { cat: 'LUNCH', date: '2026-11-18', fixed: false, edit: false }, fromHistory: false,
  ms: { date: '2026-11-18', time: '11:30', label: '', source: 'MANUAL', description: 'ROLLBACK-DRAFT chicken rice', eatenFraction: 1, mealCategory: 'LUNCH', lifecycle: 'DRAFT', ai: null,
    components: [{ name: 'Chicken rice', role: 'MAIN', portion: '1.5 plates', preparation: '', eatenFraction: null, kcal: E(900), proteinG: E(50), carbsG: E(100), fatG: E(20) }] } });
test('older build: a P1.4-RC2 meal draft is ignored harmlessly, never counted, never in its backup, and left byte-identical', async ({ page }) => {
  const errs = []; page.on('pageerror', (e) => errs.push(e.message));
  await page.clock.setFixedTime(new Date('2026-11-18T09:00:00.000Z'));
  await page.goto('./');
  await page.evaluate((a) => { localStorage.clear(); localStorage.setItem('hyrox.v1', JSON.stringify(a[0])); localStorage.setItem('hyrox.ui.meal-draft', a[1]); }, [SEED, DRAFT]);
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
  const sub = page.getByTestId('today-subtotal');
  if (await sub.count()) { await expect(sub).toContainText('500'); await expect(sub).not.toContainText('1400'); }
  expect(await page.evaluate(() => document.body.innerText.includes('ROLLBACK-DRAFT'))).toBe(false);
  // the older build saves a meal of its own and exports a backup
  const before = await page.evaluate(() => localStorage.getItem('hyrox.v1'));
  await page.evaluate(() => { const st = window.HyroxData.createStore(); const r = st.addNutrition ? st.addNutrition({ date: '2026-11-18', calories: '300', proteinG: '10' }) : null; return r; });
  expect(await page.evaluate(() => localStorage.getItem('hyrox.v1'))).not.toBe(before);
  const [dl] = await Promise.all([page.waitForEvent('download'), page.getByTestId('tab-settings').click().then(() => page.getByTestId('export-btn').click())]);
  const b = fs.readFileSync(await dl.path(), 'utf8');
  expect(b.includes('ROLLBACK-DRAFT')).toBe(false);
  expect(await page.evaluate(() => localStorage.getItem('hyrox.ui.meal-draft'))).toBe(DRAFT);
  const all = await page.evaluate(() => { const o = {}; for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); o[k] = localStorage.getItem(k); } return o; });
  if (process.env.P2B_OUT) fs.writeFileSync(process.env.P2B_OUT, JSON.stringify(all));
  expect(JSON.parse(all['hyrox.v1']).meals.length).toBe(1);
  expect(errs).toEqual([]);
});
