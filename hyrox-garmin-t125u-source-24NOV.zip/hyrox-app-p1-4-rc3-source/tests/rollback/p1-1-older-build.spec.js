'use strict';
// P1.1 downgrade check, run AGAINST AN OLDER BUILD (copy this file into that build's tests/e2e and run it there):
// storage written by P1.1 (intensity minutes on check-ins, weightUnit on settings) must load without error in the older
// build, survive that build's own saves, and come back out in its backup. Not part of the normal suite of this build.
// CHROME MOBILE EMULATION, NOT SAFARI/WEBKIT and not a physical iPhone. Synthetic data only.
const { test, expect } = require('@playwright/test');
const T = '2026-11-01T06:00:00.000Z';
const im = (v) => ({ state: 'OBSERVED', value: v, source: 'GARMIN_MANUAL' });
const SEED = { version: 2, weight: [{ id: 'w-a', date: '2026-11-22', kg: 97.5, createdAt: T }], workouts: [], nutrition: [],
  daily: [{ id: 'daily-2026-11-21', date: '2026-11-21', createdAt: T, steps: { state: 'OBSERVED', value: 9000 }, intensityMin: im(46) },
    { id: 'daily-2026-11-22', date: '2026-11-22', createdAt: T, sleepH: { state: 'OBSERVED', value: 7 }, intensityMin: im(0) }],
  ownerSettings: [{ id: 'app-settings', date: '2026-11-11', createdAt: T, rhrBaselineBpm: 61, rhrBaselineSource: 'OWNER_SET', stepBaselineMode: 'AUTO', weightUnit: 'lb' }] };
const stored = (page) => page.evaluate(() => JSON.parse(localStorage.getItem('hyrox.v1') || '{}'));

test('older build: P1.1 storage loads cleanly, shows the seeded weight, and keeps intensity minutes and the unit through its own saves and its backup', async ({ page }) => {
  const errs = []; page.on('pageerror', (e) => errs.push(e.message));
  await page.clock.setFixedTime(new Date('2026-11-22T09:00:00.000Z'));
  await page.goto('./');
  await page.evaluate((s) => { localStorage.clear(); localStorage.setItem('hyrox.v1', JSON.stringify(s)); }, SEED);
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
  await expect(page.getByTestId('load-guard')).toBeHidden();
  // pending CC confirmation (Claude decision 3, t111u): re-pointed, not deleted.
  // Seed has kg: 97.5 and weightUnit: 'lb'. Builds that honour the unit show "215 lb";
  // builds that display kg show "97.5 kg". A control on unmodified P1.4-RC3 failed the old kg-only assertion the same way — pre-existing spec error, not a HEAD regression.
  const glanceText = await page.getByTestId('glance-weight-text').textContent();
  expect(glanceText, "accept 215 lb when the store unit is lb, otherwise 97.5 kg").toMatch(/97\.5 kg|215 lb/);
  await expect(page.getByTestId('damaged-banner')).toHaveCount(0);
  // the older build's quick steps save on yesterday's check-in
  await page.getByTestId('today-log-steps').click();
  await page.getByTestId('qsteps-yesterday').click();
  await page.getByTestId('qsteps-input').fill('9500'); await page.getByTestId('qsteps-replace').check(); await page.getByTestId('qsteps-save').click();
  await expect.poll(async () => (await stored(page)).daily.find((d) => d.date === '2026-11-21').steps.value).toBe(9500);
  // its full check-in save on today's check-in
  await page.getByTestId('tab-add').click(); await page.getByTestId('add-mode-daily').click();
  await page.getByTestId('daily-rhr').fill('58'); await page.getByTestId('daily-submit').click();
  await expect.poll(async () => { const d = (await stored(page)).daily.find((x) => x.date === '2026-11-22'); return d.rhr ? d.rhr.value : null; }).toBe(58);
  // its baseline save on the settings record
  await page.getByTestId('tab-settings').click();
  await page.getByTestId('set-rhr-baseline').fill('60'); await page.getByTestId('set-save').click();
  await expect.poll(async () => (await stored(page)).ownerSettings[0].rhrBaselineBpm).toBe(60);
  const s = await stored(page);
  expect(s.daily.find((d) => d.date === '2026-11-21').intensityMin).toEqual(im(46));
  expect(s.daily.find((d) => d.date === '2026-11-22').intensityMin).toEqual(im(0));
  expect(s.daily.find((d) => d.date === '2026-11-22').sleepH.value).toBe(7);
  expect(s.ownerSettings[0].weightUnit).toBe('lb');
  expect(s.weight.map((w) => w.kg)).toEqual([97.5]);
  // and its backup carries both
  const [dl] = await Promise.all([page.waitForEvent('download'), page.getByTestId('export-btn').click()]);
  const b = JSON.parse(require('fs').readFileSync(await dl.path(), 'utf8'));
  expect(b.daily.find((d) => d.date === '2026-11-21').intensityMin).toEqual(im(46));
  expect(b.ownerSettings[0].weightUnit).toBe('lb');
  expect(errs).toEqual([]);
});
