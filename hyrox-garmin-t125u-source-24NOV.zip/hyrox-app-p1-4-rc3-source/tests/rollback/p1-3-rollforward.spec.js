'use strict';
// P1.3 roll-forward: the storage an older build left behind (P13_ROLLBACK_IN) opens in P1.3 with the coach intact.
// Copied into tests/e2e of a P1.3 copy to run. CHROME MOBILE EMULATION, NOT SAFARI/WEBKIT. Synthetic data only.
const { test, expect } = require('@playwright/test');
const fs = require('fs');
test('P1.3 reads storage written back by an older build: coach target, profile and saved foods intact', async ({ page }) => {
  const errs = []; page.on('pageerror', (e) => errs.push(e.message));
  const seed = JSON.parse(fs.readFileSync(process.env.P13_ROLLBACK_IN, 'utf8'));
  await page.clock.setFixedTime(new Date('2026-11-23T09:00:00.000Z'));
  await page.goto('./');
  await page.evaluate((s) => { localStorage.clear(); localStorage.setItem('hyrox.v1', JSON.stringify(s)); }, seed);
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
  await page.getByTestId('tab-settings').click();
  await expect(page.getByTestId('coach-toggle')).toHaveText('Coach: On');
  await expect(page.getByTestId('coach-current-line')).toHaveText('In use today: 2,200 kcal · protein 190 g · fat 60 g · carbs —');
  await expect(page.getByTestId('coach-invalid')).toHaveCount(0);
  expect(errs).toEqual([]);
});
