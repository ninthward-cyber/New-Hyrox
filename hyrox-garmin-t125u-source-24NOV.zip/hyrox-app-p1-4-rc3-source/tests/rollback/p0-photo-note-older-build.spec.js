'use strict';
// P0 sprint downgrade check, run AGAINST AN OLDER BUILD (copied into a copy of that build's tests/e2e): a photo meal written by
// the P0 fix (item bases on components, acknowledgements on meal.ai) must load without error in the older build, keep both
// through that build's own Edit -> Confirm of the same meal and through its backup, and still count 766 kcal once.
// The final storage goes to P0_ROLLBACK_OUT for the roll-forward check. CHROME MOBILE EMULATION, NOT SAFARI/WEBKIT. Synthetic data.
const { test, expect } = require('@playwright/test');
const fs = require('fs');
const ts = '2026-11-18T04:30:00.000Z';
const M = (v) => ({ value: v, state: 'ESTIMATED' });
const comp = (name, basis, k, p, c, f, extra) => Object.assign({ name, role: 'MAIN', portion: '', preparation: '', eatenFraction: null, kcal: M(k), proteinG: M(p), carbsG: M(c), fatG: M(f), confidence: 'MEDIUM', uncertainty: 'synthetic', basis }, extra || {});
const MEAL = { id: 'meal-p0-1', date: '2026-11-18', time: '07:30', label: '', source: 'PHOTO_AI', description: '3 eggs, 2 pork patties, and strawberry yogurt, black coffee',
  eatenFraction: 1, lifecycle: 'CONFIRMED', confirmedAt: ts, createdAt: ts, updatedAt: ts,
  components: [comp('Eggs', 'NOTE', 216, 19, 1, 15), comp('Pork patties', 'NOTE', 400, 22, 1, 34), comp('Strawberry yogurt', 'BOTH', 150, 6, 25, 3)],
  ai: { mode: 'REAL', provider: 'openai', model: 'gpt-6-luna', analyzedAt: ts, warnings: [], userCorrected: false, acks: [{ kind: 'FOOD', key: 'black coffee', text: 'black coffee' }] } };
const SEED = { version: 2, weight: [], workouts: [], nutrition: [], meals: [MEAL] };
const stored = (page) => page.evaluate(() => JSON.parse(localStorage.getItem('hyrox.v1') || '{}'));

test('older build: a P0-fix photo meal loads cleanly, counts 766 kcal, and keeps item bases and acknowledgements through its own edit/confirm and backup', async ({ page }) => {
  const errs = []; page.on('pageerror', (e) => errs.push(e.message));
  await page.clock.setFixedTime(new Date('2026-11-18T09:00:00.000Z'));
  await page.goto('./');
  await page.evaluate((s) => { localStorage.clear(); localStorage.setItem('hyrox.v1', JSON.stringify(s)); }, SEED);
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
  await expect(page.getByTestId('damaged-banner')).toHaveCount(0);
  await expect(page.getByTestId('today-subtotal')).toContainText('766');
  await page.getByTestId('tab-history').click();
  await page.getByTestId('history-meal').first().getByRole('button', { name: /^Edit/ }).click();
  await page.getByTestId('meal-confirm').click();
  await expect.poll(async () => (await stored(page)).meals[0].updatedAt).not.toBe(ts);
  const s = await stored(page);
  expect(s.meals.length).toBe(1);
  expect(s.meals[0].components.map((c) => c.basis)).toEqual(['NOTE', 'NOTE', 'BOTH']);
  expect(s.meals[0].ai.acks).toEqual(MEAL.ai.acks);
  const [dl] = await Promise.all([page.waitForEvent('download'), page.getByTestId('tab-settings').click().then(() => page.getByTestId('export-btn').click())]);
  const b = JSON.parse(fs.readFileSync(await dl.path(), 'utf8'));
  expect(b.meals[0].components.map((c) => c.basis)).toEqual(['NOTE', 'NOTE', 'BOTH']);
  if (process.env.P0_ROLLBACK_OUT) fs.writeFileSync(process.env.P0_ROLLBACK_OUT, JSON.stringify(s));
  expect(errs).toEqual([]);
});
