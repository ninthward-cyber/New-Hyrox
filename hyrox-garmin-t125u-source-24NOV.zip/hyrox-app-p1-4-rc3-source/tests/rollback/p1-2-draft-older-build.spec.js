'use strict';
// Sprint B downgrade check, run AGAINST AN OLDER BUILD (copied into that build's tests/e2e): an unsaved-workout draft written by
// the Sprint B build (same key hyrox.ui.workout-draft, extra optional envelope fields day + draftId) is still offered and
// restored by the older build, and saving it there stores exactly one session and clears the draft.
// CHROME MOBILE EMULATION, NOT SAFARI/WEBKIT. Synthetic data.
const { test, expect } = require('@playwright/test');
const KEY = 'hyrox.ui.workout-draft';
const NOW = '2026-11-18T09:00:00.000Z';
const WS = { date: '2026-11-18', title: 'Sprint B draft', status: 'COMPLETED', modified: false, variant: 'ORIGINAL_60', planSlotId: null, planVersion: null, scheduledDate: null, durationMin: 25, rpe: null, notes: 'from the new build', blocks: [] };
test('older build: a Sprint B workout draft envelope is restored and saved once', async ({ page }) => {
  const errs = []; page.on('pageerror', (e) => errs.push(e.message));
  await page.clock.setFixedTime(new Date(NOW));
  await page.goto('./');
  await page.evaluate((a) => { localStorage.clear(); localStorage.setItem(a[0], JSON.stringify({ savedAt: a[1], ws: a[2], day: '2026-11-18', draftId: 'wd-test-1' })); }, [KEY, NOW, WS]);
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
  await page.getByTestId('today-workout-draft-continue').click();
  await expect(page.getByTestId('session-title')).toHaveValue('Sprint B draft');
  await page.getByTestId('session-save').click();
  await expect(page.getByTestId('ext-toast')).toContainText('Saved');
  const s = await page.evaluate(() => JSON.parse(localStorage.getItem('hyrox.v1')));
  expect(s.sessions.length).toBe(1);
  expect(s.sessions[0].notes).toBe('from the new build');
  expect(await page.evaluate((k) => localStorage.getItem(k), KEY)).toBeNull();
  expect(errs).toEqual([]);
});
