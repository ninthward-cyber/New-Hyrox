'use strict';
// Sprint B2 roll-forward: the storage an older build left behind (P2B_IN, every key) opens in the candidate: the meal draft is
// still offered with Resume/Discard, restored exactly on Resume, and confirmed once on top of what the older build saved.
// CHROME MOBILE EMULATION, NOT SAFARI/WEBKIT. Synthetic data.
const { test, expect } = require('@playwright/test');
const fs = require('fs');
test('candidate resumes a meal draft that survived an older build; Confirm saves it once', async ({ page }) => {
  const errs = []; page.on('pageerror', (e) => errs.push(e.message));
  const all = JSON.parse(fs.readFileSync(process.env.P2B_IN, 'utf8'));
  await page.clock.setFixedTime(new Date('2026-11-18T09:00:00.000Z'));
  await page.goto('./');
  await page.evaluate((o) => { localStorage.clear(); for (const k of Object.keys(o)) localStorage.setItem(k, o[k]); }, all);
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
  await expect(page.getByTestId('today-meal-draft')).toBeVisible();
  await expect(page.getByTestId('today-meal-draft-photos')).toContainText('1 photo');
  const n0 = (JSON.parse(all['hyrox.v1']).meals || []).length;
  await page.getByTestId('today-meal-draft-resume').click();
  await expect(page.getByTestId('meal-description')).toHaveValue('ROLLBACK-DRAFT chicken rice');
  await expect(page.getByTestId('meal-draft-photos-reattach')).toBeVisible();
  await page.getByTestId('meal-confirm').click();
  await expect.poll(async () => (JSON.parse(await page.evaluate(() => localStorage.getItem('hyrox.v1'))).meals || []).length).toBe(n0 + 1);
  expect(await page.evaluate(() => localStorage.getItem('hyrox.ui.meal-draft'))).toBeNull();
  expect(errs).toEqual([]);
});
