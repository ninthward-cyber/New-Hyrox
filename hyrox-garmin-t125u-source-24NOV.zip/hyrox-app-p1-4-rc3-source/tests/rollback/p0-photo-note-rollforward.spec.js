'use strict';
// P0 sprint roll-forward: the storage an older build left behind (P0_ROLLBACK_IN) opens in the P0 fix with item bases and the
// acknowledgement intact: the meal counts 766 kcal and reopening it shows nothing "not accounted for". CHROME EMULATION, NOT SAFARI.
const { test, expect } = require('@playwright/test');
const fs = require('fs');
test('P0 fix reads storage written back by an older build: 766 kcal, bases kept, acknowledged food still acknowledged', async ({ page }) => {
  const errs = []; page.on('pageerror', (e) => errs.push(e.message));
  const seed = JSON.parse(fs.readFileSync(process.env.P0_ROLLBACK_IN, 'utf8'));
  await page.clock.setFixedTime(new Date('2026-11-18T09:00:00.000Z'));
  await page.goto('./');
  await page.evaluate((s) => { localStorage.clear(); localStorage.setItem('hyrox.v1', JSON.stringify(s)); }, seed);
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
  await expect(page.getByTestId('today-subtotal')).toContainText('766');
  await page.getByTestId('tab-history').click();
  await page.getByTestId('history-meal').first().getByTestId('meal-edit').click();
  await expect(page.getByTestId('meal-review-box')).toBeVisible();
  await expect(page.getByTestId('meal-unaccounted')).toHaveCount(0);
  await expect(page.getByTestId('review-origin').nth(0)).toContainText('from your note');
  expect(errs).toEqual([]);
});
