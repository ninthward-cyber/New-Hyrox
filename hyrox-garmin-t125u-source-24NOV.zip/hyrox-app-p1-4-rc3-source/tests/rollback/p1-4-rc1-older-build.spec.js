'use strict';
// P1.4-RC1 integrated downgrade check, run AGAINST AN OLDER BUILD (copied into that build's tests/e2e). Input: P14_IN (storage the
// candidate's own data layer wrote: Sprint D seed + Sprint A photo+note meal + Sprint B draft envelope) and P14_CAND_BACKUP (a backup
// file the candidate exported from that storage). The older build must (1) open the storage with no error and keep every record,
// (2) export a backup with every record, (3) restore the candidate's backup through its own Restore preview + confirm.
// Writes P14_OUT_STORAGE and P14_OUT_BACKUP for the roll-forward check. CHROME MOBILE EMULATION, NOT SAFARI/WEBKIT. Synthetic data.
const { test, expect } = require('@playwright/test');
const fs = require('fs');
const IN = JSON.parse(fs.readFileSync(process.env.P14_IN, 'utf8'));
const ids = (v) => { const o = {}; for (const k of Object.keys(v).sort()) if (Array.isArray(v[k])) o[k] = v[k].map((r) => (r && (r.id || r.date)) || '?').sort(); return o; };
const stored = (page) => page.evaluate(() => JSON.parse(localStorage.getItem('hyrox.v1') || '{}'));
test('older build: P1.4-RC1 storage opens, keeps every record through its backup, and its Restore accepts the P1.4-RC1 backup', async ({ page }) => {
  const errs = []; page.on('pageerror', (e) => errs.push(e.message));
  await page.clock.setFixedTime(new Date('2026-11-18T09:00:00.000Z'));
  await page.goto('./');
  await page.evaluate((s) => { localStorage.clear(); for (const k of Object.keys(s)) localStorage.setItem(k, s[k]); }, IN);
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
  await expect(page.getByTestId('damaged-banner')).toHaveCount(0);
  const want = ids(JSON.parse(IN['hyrox.v1']));
  expect(ids(await stored(page))).toEqual(want);
  const [dl] = await Promise.all([page.waitForEvent('download'), page.getByTestId('tab-settings').click().then(() => page.getByTestId('export-btn').click())]);
  const backup = fs.readFileSync(await dl.path(), 'utf8');
  const b = JSON.parse(backup);
  for (const k of Object.keys(want)) expect(ids(b)[k] || [], 'backup keeps ' + k).toEqual(want[k]);
  expect(b.meals.find((m) => m.id === 'meal-p0-1').ai.acks).toEqual([{ kind: 'FOOD', key: 'black coffee', text: 'black coffee' }]);
  // restore the candidate's own backup in this older build
  await page.getByTestId('import-file').setInputFiles({ name: 'hyrox-backup.json', mimeType: 'application/json', buffer: fs.readFileSync(process.env.P14_CAND_BACKUP) });
  await expect(page.getByTestId('import-preview')).toBeVisible();
  await page.getByTestId('import-confirm').click();
  await expect.poll(async () => JSON.stringify(ids(await stored(page)))).toBe(JSON.stringify(want));
  fs.writeFileSync(process.env.P14_OUT_STORAGE, JSON.stringify(await stored(page)));
  fs.writeFileSync(process.env.P14_OUT_BACKUP, backup);
  expect(errs).toEqual([]);
});
