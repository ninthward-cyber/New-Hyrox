'use strict';
// P1.3 Delivery D: weekly status (green/amber/red/gray with text + icon), strength like-with-like, waist-to-height (informational).
// Synthetic fixtures only.
const test = require('node:test');
const assert = require('node:assert');
const path = require('path');
const HC = require(path.join(__dirname, '..', 'src', 'data', 'hyrox-coach.js'));
const TD = '2026-11-23';
const W = (date, kg) => ({ date, kg });
function hist({ kgPerWeek = -0.45, startKg = 100, weighDows = [0, 2, 4, 6], d5Dows = [0, 1, 2, 3, 4, 5, 6], weeks = 4 } = {}) {
  const ws = HC.reviewWeeks(TD, weeks), from = ws[0].start, days = [], weights = [];
  for (let d = from; d <= HC.lastCompletedSunday(TD); d = HC.addDays(d, 1)) { // re-pointed: Monday-Sunday weeks (independent review C2)
    const dw = new Date(d + 'T00:00:00Z').getUTCDay(), t = HC.daysBetween(from, d);
    if (weighDows.includes(dw)) weights.push(W(d, startKg + kgPerWeek * t / 7));
    days.push(d5Dows.includes(dw) ? { date: d, code: 'D5', kcal: 2300, estKcal: 0 } : { date: d, code: 'D2', kcal: null, estKcal: null });
  }
  return { sb: HC.stageB(days, weights, TD), days };
}
const st = (o, cons, goal = 'LOSE_1', unit = 'kg') => { const h = hist(o); return HC.status(h.sb, cons || HC.concerns(h.sb, h.days, {}), goal, unit); };

test('P1.3 D: every status has a level, an icon and a text label (never colour alone)', () => {
  for (const lv of ['GREEN', 'AMBER', 'RED', 'GRAY']) { assert.ok(HC.STATUS_ICON[lv]); assert.ok(HC.STATUS_LABEL[lv]); }
  assert.notStrictEqual(new Set(Object.values(HC.STATUS_ICON)).size, 1);
});

test('P1.3 D: green within half to 1.5x the goal rate; amber when both of the last 2 weeks are outside it (slower or faster)', () => {
  const g = st({ kgPerWeek: -0.45 });
  assert.deepStrictEqual([g.level, g.text], ['GREEN', 'On track: −0.4 kg a week over 2 weeks.']); // weekly means are kept to 0.1 kg
  assert.strictEqual(st({ kgPerWeek: -0.45 }, null, 'LOSE_1', 'lb').text, 'On track: −1.0 lb a week over 2 weeks.');
  const slow = st({ kgPerWeek: -0.1 });
  assert.strictEqual(slow.level, 'AMBER'); assert.match(slow.text, /^Slower than your goal for 2 weeks/);
  const fast = st({ kgPerWeek: -0.8 }); // 1.76x the 1 lb goal, under 1 % of weight
  assert.strictEqual(fast.level, 'AMBER'); assert.match(fast.text, /^Faster than your goal for 2 weeks/);
  // maintain: within about 0.25 % of body weight a week
  assert.strictEqual(st({ kgPerWeek: -0.2 }, null, 'MAINTAIN').level, 'GREEN');
  assert.strictEqual(st({ kgPerWeek: -0.4 }, null, 'MAINTAIN').level, 'AMBER');
  assert.strictEqual(st({ kgPerWeek: 0.45 }, null, 'GAIN_1').level, 'GREEN');
});

test('P1.3 D: red for recovery/pain/low intake/very rapid loss; red always says no reduction; amber for rapid loss says eat more', () => {
  const r = st({ kgPerWeek: -0.45 }, [{ code: 'RECOVERY', level: 'RED', text: 'Two or more readiness flags on 4 days last week.' }]);
  assert.strictEqual(r.level, 'RED'); assert.match(r.text, /No reduction is suggested/);
  const vf = st({ kgPerWeek: -1.7 });
  assert.strictEqual(vf.level, 'RED');
  const af = st({ kgPerWeek: -1.2 });
  assert.strictEqual(af.level, 'AMBER'); assert.match(af.text, /Faster is not better here/);
  assert.doesNotMatch(af.text + vf.text + r.text, /fail|bad|poor|cheat/i, 'no shaming words');
});

test('P1.3 D: gray when data is short — no goal, under 3 weigh-in days last week, or fewer than 3 weeks in a row (one week is not a trend)', () => {
  assert.strictEqual(st({}, null, null).level, 'GRAY');
  const thin = st({ weighDows: [1, 4] });
  assert.deepStrictEqual([thin.level, thin.text], ['GRAY', 'Not enough data: 2 weigh-in days last week, 3 needed.']);
  const h = hist({ kgPerWeek: -2 }); // a big early drop with only the last 2 weeks weighed
  h.sb.weeks[0].weightOk = false; h.sb.weeks[0].meanKg = null; h.sb.weeks[1].weightOk = false; h.sb.weeks[1].meanKg = null;
  const g = HC.status(h.sb, HC.concerns(h.sb, h.days, {}), 'LOSE_1', 'kg');
  assert.strictEqual(g.level, 'GRAY'); assert.match(g.text, /One week is not a trend/);
});

test('P1.3 D: amber when food coverage is low for 2 weeks even if weight is on track (uncertain picture, not a failure)', () => {
  const s = st({ kgPerWeek: -0.45, d5Dows: [0, 6] });
  assert.strictEqual(s.level, 'AMBER'); assert.match(s.text, /the picture is uncertain/);
});

test('P1.3 D: strength compares like with like only (same exercise, working sets, reps within ±2); otherwise "not comparable"', () => {
  const weeks = HC.reviewWeeks(TD, 3);
  const sets = [
    { date: '2026-11-03', exercise: 'Back squat', loadKg: 100, reps: 5 }, { date: '2026-11-10', exercise: 'Back squat', loadKg: 102.5, reps: 5 },
    { date: '2026-11-17', exercise: 'Back squat', loadKg: 100, reps: 6 }, { date: '2026-11-19', exercise: 'Back squat', loadKg: 90, reps: 10 },
    { date: '2026-11-10', exercise: 'Bench press', loadKg: 60, reps: 12 }, { date: '2026-11-17', exercise: 'Bench press', loadKg: 70, reps: 5 },
    { date: '2026-11-18', exercise: 'Row', loadKg: 50, reps: 8 }, { date: '2026-11-18', exercise: 'Row', loadKg: NaN, reps: 8 }];
  const r = HC.strengthCompare(sets, weeks);
  const by = Object.fromEntries(r.map((x) => [x.exercise, x]));
  assert.strictEqual(by['Back squat'].result, 'DOWN'); assert.strictEqual(by['Back squat'].previous.loadKg, 102.5);
  assert.strictEqual(by['Bench press'].result, 'NOT_COMPARABLE');
  assert.strictEqual(by['Row'].result, 'NOT_COMPARABLE');
  // falling two weeks in a row -> the strength concern (no reduction)
  const four = HC.reviewWeeks(TD, 4);
  const falling = [{ date: '2026-11-03', exercise: 'Deadlift', loadKg: 140, reps: 5 }, { date: '2026-11-10', exercise: 'Deadlift', loadKg: 135, reps: 5 }, { date: '2026-11-17', exercise: 'Deadlift', loadKg: 130, reps: 4 }];
  assert.deepStrictEqual(HC.strengthDownTwice(falling, four), ['Deadlift']);
  assert.deepStrictEqual(HC.strengthDownTwice(falling.slice(1), four), []);
  const c = HC.concerns({ weeks: [] }, [], { strengthDown: ['Deadlift'] });
  assert.deepStrictEqual(c.map((x) => [x.code, x.level]), [['STRENGTH', 'AMBER']]);
});

test('P1.3 D: waist-to-height is a plain ratio (informational); missing height or waist gives no number', () => {
  assert.strictEqual(HC.waistToHeight(89, 178), 0.5);
  assert.strictEqual(HC.waistToHeight(96.5, 170), 0.57); // the NICE NG246 box 1 worked example
  assert.strictEqual(HC.waistToHeight(null, 178), null);
  assert.strictEqual(HC.waistToHeight(90, null), null);
});
