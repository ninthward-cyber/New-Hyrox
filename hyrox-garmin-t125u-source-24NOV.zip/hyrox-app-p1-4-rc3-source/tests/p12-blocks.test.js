'use strict';
// Phase 12: training-block planner engine (src/data/hyrox-blocks.js). Block 1 stays the immutable built-in plan; Block 2
// lives in the optional settings field planBlocks (data v2). Covers the CC D1-D12 decisions, midnight boundaries (Asia/Qatar),
// lifecycle guards, block-scoped cascade, field-preserving writes, export/restore and restore on older data layers.
// Synthetic data only. Older source trees are read-only and SKIPPED (visibly) when absent.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const SRC = path.resolve(__dirname, '..', 'src');
const HD = require(path.join(SRC, 'data', 'hyrox-data.js'));
const HP = require(path.join(SRC, 'data', 'hyrox-plan.js'));
const HB = require(path.join(SRC, 'data', 'hyrox-blocks.js'));
const mem = () => { const m = {}; return { m, getItem: (k) => (k in m ? m[k] : null), setItem(k, v) { m[k] = String(v); }, removeItem(k) { delete m[k]; } }; };
const sha = (f) => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
let seed = 7; const rand = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
const TS = '2026-12-11T08:00:00.000Z';
const sess = (slotId, date, status, extra) => Object.assign({ id: 's-' + slotId + '-' + date + '-' + status, date, status, planSlotId: slotId, variant: 'ORIGINAL_60', modified: false, blocks: [], createdAt: TS }, extra || {});

function draft(start, today) { const r = HB.createDraft([], start || '2026-12-14', today || '2026-11-19', TS, rand); assert.equal(r.ok, true, r.text); return r; }
function active(start, today) {
  const d = draft(start, today || '2026-11-19');
  const t = today && today >= HB.DECISION_FROM ? today : '2026-12-11';
  const a = HB.activate(d.blocks, d.block.id, t, TS, { approved: true, previewHash: HB.contentHash(d.block.slots) });
  assert.equal(a.ok, true, a.text); return a;
}

// ---------- Block 1 immutability ----------
const P112_DATA = {
  'food-db.js': '312e75c5b5fb6703e323a5311e7d04b937e306805f177c7d3c42df8f809f4279',
  'hyrox-data.js': '35fe4ac633b40d69871b79ef652089acb46aed69653248a3da61811b44022870', /* RE-POINTED t112b (24 Nov 2026): t112b Dawit R4-D1/D2 + Meron R4-D1–D8 / O-1. No version bump, no new storage key. */
  'hyrox-foodcalc.js': 'c15605f0af39d82432e9ada6599dde01dba9c00511c2ae3b31a30366a0715f6c',
  // RC1 integration: hyrox-foodsearch.js is the reviewed P11.3 file (rc1/a-review, unchanged by the RC1 repairs); Claude P11.2 was 2165e950…
  // RC2 review (Claude): pin moved from RC1's 28e136b2… to the RC2 file (owner fiber/sodium marker, saved-foods restore note,
  // ranking). Every other pinned data file is unchanged. hyrox-blocks.js (Block 2 lock) is not changed by RC2 either.
  'hyrox-foodsearch.js': 'a4ea1228f108e44f33ff0f4d673b7b888d9d7d65b595cec5283eb979c48b7787',
  'hyrox-nutrition.js': 'f3da951f134fb805e126d34ef9e3eb3aa22514e195a423cec4876045e6055064',
  'hyrox-plan.js': '77a3694274dc207c851626f4bb03e71cbc651d10a5da6fe590e13f51a800ac05',
  'hyrox-wellness.js': 'b962208da03e4d259791104ef671f3b3902ef40a48bca8e7aa8386976c2c7b84',
};
test('P12 changes no existing data-layer file (Block 1 plan, data layer, readiness all byte-identical to Claude P11.2; food search = reviewed P11.3)', () => {
  for (const [f, h] of Object.entries(P112_DATA)) assert.equal(sha(path.join(SRC, 'data', f)), h, f);
});
test('Block 1 constants, 20 slot ids and dates unchanged; the planner never touches HyroxPlan', () => {
  assert.equal(HP.PLAN_VERSION, 'v2.1'); assert.equal(HP.BLOCK_START, '2026-11-16'); assert.equal(HP.BLOCK_END, '2026-12-13');
  assert.equal(HP.SLOTS.length, 20); assert.equal(HP.SLOTS[0].id, 'v2.1-W1-MON'); assert.equal(HP.SLOTS[19].date, '2026-12-11');
  const before = JSON.stringify(HP.SLOTS);
  const a = active(); HB.preview(a.block); HB.effectiveWeek(a.block, 1); HB.summary(a.block, []);
  assert.equal(JSON.stringify(HP.SLOTS), before);
  const src = fs.readFileSync(path.join(SRC, 'data', 'hyrox-blocks.js'), 'utf8');
  assert.equal(/HyroxWellness|readiness\s*\(|planEvents\s*[.=]|fetch\(|XMLHttpRequest|localStorage/.test(src), false, 'no readiness, legacy planEvents write, network or direct storage use');
});

// ---------- D1/D2: Hold content ----------
test('D1: Hold W1-W3 never exceed the Block 1 W2/W3 ceiling; W4 is the deload; options default to none', () => {
  const b = draft().block;
  assert.deepEqual(b.options, { running: null, race: null, lifting: null, bothConfirmed: false });
  assert.equal(b.state, 'DRAFT'); assert.equal(b.approval, null);
  const txt = b.slots.map((s) => s.prescription.join(' | '));
  for (const s of b.slots) {
    const j = s.prescription.join(' ');
    if (s.type === 'INTERVALS') { const m = /(\d+) rounds: (\d+) m/.exec(j); assert.ok(+m[1] <= 4 && +m[2] <= 400, s.id); }
    if (s.type === 'RACE') { assert.match(j, /2 rounds/); assert.match(j, /20 m bodyweight lunges \+ 15 light wall balls/); }
    if (s.type === 'STRENGTH_A' && !s.deload) assert.match(j, /3x5 @ RPE 7/);
    if (s.type === 'AEROBIC') assert.ok(/5x \(2 min jog \/ 1 min walk\)|3x \(4 min jog \/ 1 min walk\)/.test(j), s.id);
    if (s.deload) assert.match(j, /deload|3 rounds|BENCHMARK 3|5x \(2 min|10 min warm-up|Treadmill/);
    assert.equal(/Romanian|500 m|5 rounds|30 m bodyweight|20 light wall/.test(j), false, s.id + ' no option content by default');
  }
  assert.ok(txt.every((t) => !/increase load|add weight|\+\s*\d+(\.\d+)?\s*kg/i.test(t)), 'no automatic load increase');
  assert.match(txt[0], /Hold never raises weights automatically/);
});
test('15-minute cap: every continuous machine/treadmill bout in every slot, option and fallback is <= 15 min', () => {
  const all = [];
  const opt = { running: 'A1', race: 'R1L', lifting: 'S1' };
  for (const o of [{}, opt, { running: 'I1' }, { running: 'I2', race: 'R1W' }]) for (const s of HB.buildSlots('b-20261214-aaaa', '2026-12-14', o)) {
    all.push(...HB.machineMinutes(s.prescription));
    for (const v of ['SOURCE_45_MIN', 'SOURCE_25_MIN']) { const p = HB.variantPrescription(s, v); if (p) all.push(...HB.machineMinutes(p.prescription)); }
  }
  assert.ok(all.length > 50);
  assert.ok(all.every((m) => m <= 15), JSON.stringify(all.filter((m) => m > 15)));
});
test('dates, ids, Benchmark 3 on Fri 8 Jan, possible closures only flagged', () => {
  const b = draft().block;
  assert.equal(b.startDate, '2026-12-14'); assert.equal(b.endDate, '2027-01-10');
  assert.match(b.id, /^b-20261214-[a-z0-9]{4}$/);
  assert.equal(b.slots[0].id, b.id + '-W1-MON'); assert.equal(b.slots[19].date, '2027-01-08');
  assert.ok(b.slots.every((s) => s.id.length <= 40 && HB.isBlockSlotId(s.id)));
  assert.equal(b.slots[19].benchmark, 3); assert.match(b.slots[19].prescription[1], /BENCHMARK 3 — exact repeat/);
  assert.ok(b.slots[19].prescription[1].includes(HP.SLOTS[19].prescription[1].replace(/^2 rounds \(repeat W2 exactly — BENCHMARK 2\): /, '')));
  const pv = HB.preview(b);
  const flagged = pv.weeks.flatMap((w) => w.days.filter((d) => d.possibleClosure).map((d) => d.slot.date));
  assert.deepEqual(flagged, ['2026-12-18', '2026-12-25', '2027-01-01']);
  const a = active();
  assert.deepEqual(a.block.events, []);
  assert.equal(HB.slotStatus(a.blocks, a.block.id + '-W1-FRI', []).code, 'NOT_LOGGED', 'a possible closure is never pre-marked');
  assert.ok(pv.rules.some((r) => /ST0/.test(r) && /not assumed/.test(r)));
});

// ---------- D3/D4 start rules + activation guards ----------
test('start: Monday only, no early start, no past start, later Monday allowed', () => {
  assert.equal(HB.startCheck('2026-12-07', '2026-11-19').code, 'EARLY_START');
  assert.equal(HB.startCheck('2026-12-13', '2026-11-19').code, 'START_NOT_MONDAY');
  assert.equal(HB.startCheck('2026-12-15', '2026-11-19').code, 'START_NOT_MONDAY');
  assert.equal(HB.startCheck('2026-12-21', '2026-11-19').ok, true);
  assert.equal(HB.startCheck('2026-12-14', '2026-12-15').code, 'START_IN_PAST');
  assert.equal(HB.startCheck('', '2026-11-19').code, 'NO_DATE');
  assert.deepEqual(HB.mondaysFrom('2026-11-19', 3), ['2026-12-14', '2026-12-21', '2026-12-28']);
  assert.deepEqual(HB.mondaysFrom('2026-12-15', 1), ['2026-12-21']);
});
test('activation: not before 11 Dec, needs approval + matching preview, never twice, never overlapping', () => {
  const d = draft();
  const h = HB.contentHash(d.block.slots);
  assert.equal(HB.activationCheck(d.blocks, d.block.id, '2026-12-10', { approved: true, previewHash: h }).code, 'BEFORE_DECISION_DATE');
  assert.equal(HB.activationCheck(d.blocks, d.block.id, '2026-12-11', {}).code, 'CONTENT_NOT_APPROVED');
  assert.equal(HB.activationCheck(d.blocks, d.block.id, '2026-12-11', { approved: true, previewHash: 'deadbeef' }).code, 'STALE');
  assert.equal(HB.activationCheck(d.blocks, d.block.id, '2026-12-15', { approved: true, previewHash: h }).code, 'START_IN_PAST');
  const a = HB.activate(d.blocks, d.block.id, '2026-12-11', TS, { approved: true, previewHash: h });
  assert.equal(a.ok, true); assert.equal(a.block.state, 'ACTIVATED'); assert.match(a.block.approval.text, /Hold/);
  assert.deepEqual(HB.validateBlock(a.block), []);
  assert.equal(HB.activate(a.blocks, d.block.id, '2026-12-12', TS, { approved: true }).code, 'ALREADY_ACTIVE', 'duplicate activation refused');
  const d2 = HB.createDraft(a.blocks, '2026-12-21', '2026-12-12', TS, rand);
  assert.equal(HB.activationCheck(d2.blocks, d2.block.id, '2026-12-12', { approved: true }).code, 'OVERLAP');
  const d3 = HB.createDraft(a.blocks, '2027-01-11', '2026-12-12', TS, rand);
  const a3 = HB.activate(d3.blocks, d3.block.id, '2026-12-12', TS, { approved: true });
  assert.equal(a3.ok, true, 'a non-overlapping later block (owner-created) can be activated: two blocks');
  assert.equal(HB.activated(a3.blocks).length, 2);
  // input arrays are never mutated
  assert.equal(d.blocks[0].state, 'DRAFT');
});
test('D2 options: locked before 11 Dec, never pre-selected, both increases need an explicit confirm, options reset approval', () => {
  const d = draft();
  assert.equal(HB.setOptions(d.blocks, d.block.id, { running: 'I1' }, '2026-12-10').code, 'OPTIONS_LOCKED');
  assert.equal(HB.setOptions(d.blocks, d.block.id, {}, '2026-12-10').ok, true, 'Hold everywhere is always allowed');
  const o = HB.setOptions(d.blocks, d.block.id, { running: 'I1', lifting: 'S1' }, '2026-12-11');
  assert.equal(o.ok, true); assert.equal(o.block.options.bothConfirmed, false);
  assert.match(o.block.slots.find((s) => s.id.endsWith('W2-TUE')).prescription[1], /500 m/);
  assert.match(o.block.slots.find((s) => s.id.endsWith('W2-MON')).prescription[3], /Romanian deadlift/);
  assert.notEqual(o.block.templateHash, d.block.templateHash);
  assert.equal(HB.activationCheck(o.blocks, d.block.id, '2026-12-11', { approved: true }).code, 'BOTH_NOT_CONFIRMED');
  const o2 = HB.setOptions(o.blocks, d.block.id, { running: 'I1', lifting: 'S1', bothConfirmed: true }, '2026-12-11');
  assert.equal(HB.activationCheck(o2.blocks, d.block.id, '2026-12-11', { approved: true }).ok, true);
  assert.equal(HB.setOptions(o2.blocks, d.block.id, { running: 'X9' }, '2026-12-11').block.options.running, null, 'unknown option ignored');
  const a = HB.activate(o2.blocks, d.block.id, '2026-12-11', TS, { approved: true });
  assert.equal(HB.setOptions(a.blocks, d.block.id, {}, '2026-12-11').code, 'NOT_DRAFT');
});

// ---------- drafts have no effect; midnight boundaries ----------
test('a draft (or cancelled block) has no effect on any lookup', () => {
  const d = draft();
  const id = d.block.id + '-W1-MON';
  assert.equal(HB.slotById(id, d.blocks), null); assert.equal(HB.blockForDate('2026-12-14', d.blocks), null);
  assert.equal(HB.blockStatus('2026-12-14', d.blocks), null); assert.deepEqual(HB.plannedOn('2026-12-14', d.blocks), []);
  assert.equal(HB.slotStatus(d.blocks, id, []), null); assert.equal(HB.rescheduleCheck(d.blocks, id, '2026-12-15', [], '2026-12-14').code, 'UNKNOWN_SLOT');
  const a = active(); const c = HB.cancel(a.blocks, a.block.id, '2026-12-12', TS);
  assert.equal(c.ok, true); assert.equal(HB.blockForDate('2026-12-14', c.blocks), null);
  assert.equal(HB.cancel(a.blocks, a.block.id, '2026-12-14', TS).code, 'STARTED');
});
test('midnight boundaries (Asia/Qatar): 13/14 Dec and 10/11 Jan', () => {
  const a = active();
  const day = (iso) => HD.todayQatar(new Date(iso));
  assert.equal(day('2026-12-13T23:59:59+03:00'), '2026-12-13'); assert.equal(day('2026-12-14T00:00:00+03:00'), '2026-12-14');
  assert.equal(HB.blockStatus(day('2026-12-13T23:59:59+03:00'), a.blocks), null, 'Block 1 deload Sunday: Block 1 status applies');
  assert.equal(HP.blockStatus('2026-12-13').week, 4);
  const s = HB.blockStatus(day('2026-12-14T00:00:00+03:00'), a.blocks);
  assert.equal(s.active, true); assert.equal(s.week, 1);
  assert.equal(HB.blockStatus(day('2027-01-10T23:59:59+03:00'), a.blocks).week, 4);
  assert.equal(HB.blockStatus(day('2027-01-11T00:00:00+03:00'), a.blocks), null);
  assert.equal(HB.plannedOn('2026-12-14', a.blocks)[0].id, a.block.id + '-W1-MON');
  assert.deepEqual(HB.plannedOn('2026-12-13', a.blocks), []);
});
test('late start: gap days are not counted and not missed; block-own dates only', () => {
  const a = active('2026-12-21');
  const gap = HB.blockStatus('2026-12-16', a.blocks);
  assert.equal(gap.active, false); assert.match(gap.text, /not counted and not missed/);
  assert.equal(HB.blockStatus('2026-12-21', a.blocks).week, 1);
  assert.equal(HB.summary(a.block, []).denominator, 20); assert.equal(HB.summary(a.block, []).NOT_LOGGED, 20);
});

// ---------- statuses, cascade scoping, D6/D10/D11 ----------
test('cascade events are block-scoped: Block 1 planEvents never touch Block 2 and vice versa', () => {
  const a = active();
  const ev = HB.addEvent(a.blocks, a.block.id, 'MISSED_MONDAY', 1, '2026-12-14', TS, rand);
  assert.equal(ev.ok, true);
  const w = HB.effectiveWeek(ev.block, 1);
  assert.equal(w.days[0].show.length, 0); assert.equal(w.days[1].show[0].slot.day, 'MON'); assert.equal(w.days[3].omitted[0].reason, 'MISSED_MONDAY_CASCADE');
  assert.equal(HB.effectiveWeek(ev.block, 2).days[0].show[0].slot.day, 'MON', 'other weeks unchanged');
  assert.equal(HB.effectiveWeek(a.block, 1).days[0].show.length, 1, 'Block 1 planEvents ignored (they are never read)');
  const b1 = HP.effectiveWeek(1, []);
  assert.equal(b1.days[0].show[0].slot.id, 'v2.1-W1-MON', 'Block 2 events never reach Block 1');
  assert.equal(HB.addEvent(ev.blocks, a.block.id, 'MISSED_MONDAY', 1, '2026-12-14', TS, rand).code, 'ALREADY');
  assert.equal(HB.addEvent(a.blocks, a.block.id, 'MISSED_WEDNESDAY', 2, '2026-12-14', TS, rand).code, 'FUTURE');
  const both = HB.addEvent(ev.blocks, a.block.id, 'MISSED_WEDNESDAY', 1, '2026-12-16', TS, rand);
  assert.match(HB.effectiveWeek(both.block, 1).unresolved, /decide manually/, 'D11: both missed stays unresolved');
  assert.equal(HB.slotStatus(ev.blocks, a.block.id + '-W1-THU', []).code, 'SOURCE_OMITTED');
  const sessions = [sess(a.block.id + '-W1-THU', '2026-12-17', 'COMPLETED')];
  assert.ok(HB.cascadeConflicts(ev.block, 1, sessions).some((c) => c.code === 'ACTUAL_SESSION_ON_SOURCE_OMITTED_SLOT'));
  const rm = HB.removeEvent(ev.blocks, a.block.id, ev.block.events[0].id); assert.equal(rm.ok, true); assert.equal(rm.block.events.length, 0);
});
test('a Block 1 session never satisfies a Block 2 slot; actual work wins; weekend work flagged; D6 Saturday uncounted', () => {
  const a = active(); const id = a.block.id + '-W1-MON';
  assert.equal(HB.slotStatus(a.blocks, id, [sess('v2.1-W1-MON', '2026-11-16', 'COMPLETED')]).code, 'NOT_LOGGED');
  const done = sess(id, '2026-12-14', 'COMPLETED', { updatedAt: '2026-12-14T10:00:00Z' });
  const laterSkip = sess(id, '2026-12-14', 'SKIPPED', { updatedAt: '2026-12-14T12:00:00Z' });
  assert.equal(HB.slotStatus(a.blocks, id, [done, laterSkip]).code, 'COMPLETED');
  const wk = sess(id, '2026-12-19', 'COMPLETED');
  const st = HB.slotStatus(a.blocks, id, [wk]);
  assert.equal(st.code, 'NOT_LOGGED'); assert.equal(st.weekendWork.length, 1);
  const wo = HB.effectiveWeek(a.block, 1).weekendOptions;
  assert.equal(wo[0].day, 'SAT'); assert.equal(wo[0].counted, false); assert.equal(wo[0].gymMakeUp, false);
  assert.equal(HB.rescheduleCheck(a.blocks, a.block.id + '-W1-FRI', '2026-12-19', [], '2026-12-18').code, 'FRIDAY_NO_WEEKEND_MAKEUP');
  assert.equal(HB.summary(a.block, [wk]).denominator, 20);
  assert.equal(HB.summary(a.block, [wk]).numeratorStatus, 'OWNER_DECISION_PENDING', 'D11: 17/20 numerator unresolved');
  assert.equal(HB.summary(a.block, [wk]).qualifyingNumerator, null);
});
test('reschedule stays inside the block, no stacking, no weekend gym make-up', () => {
  const a = active(); const mon = a.block.id + '-W1-MON';
  assert.equal(HB.rescheduleCheck(a.blocks, mon, '2026-12-13', [], '2026-12-10').code, 'OUTSIDE_BLOCK');
  assert.equal(HB.rescheduleCheck(a.blocks, a.block.id + '-W4-FRI', '2027-01-11', [], '2027-01-08').code, 'OUTSIDE_BLOCK');
  assert.equal(HB.rescheduleCheck(a.blocks, mon, '2026-12-15', [], '2026-12-14').ok, false, 'Tuesday already has a session (no stacking)');
  const dates = HB.rescheduleDates(a.blocks, mon, [], '2026-12-14');
  assert.ok(dates.every((d) => d >= '2026-12-14' && d <= '2027-01-10'));
  const adv = HB.skipAdvice(a.blocks, mon, [], '2026-12-14');
  assert.equal(adv.options.ADJUST_WEEK.available, true); assert.equal(adv.recommended, 'ADJUST_WEEK');
  assert.equal(HB.skipAdvice(a.blocks, a.block.id + '-W1-FRI', [], '2026-12-18').recommended, 'SKIP_PERMANENT');
});
test('D10 revisions: future + unlogged only, append-only, denominator kept, planned rest separate, no upward deload change', () => {
  const a = active(); const tue = a.block.id + '-W1-TUE';
  assert.equal(HB.revise(a.blocks, a.block.id, tue, 'PLANNED_REST', '', [], '2026-12-15', TS, rand).code, 'NOT_FUTURE');
  assert.equal(HB.revise(a.blocks, a.block.id, tue, 'PLANNED_REST', '', [sess(tue, '2026-12-14', 'NOT_STARTED')], '2026-12-14', TS, rand).code, 'HAS_RECORD');
  const r = HB.revise(a.blocks, a.block.id, tue, 'PLANNED_REST', '', [], '2026-12-14', TS, rand);
  assert.equal(r.ok, true);
  assert.deepEqual(r.block.slots, a.block.slots, 'snapshot untouched');
  assert.equal(HB.slotStatus(r.blocks, tue, []).code, 'PLANNED_REST');
  const sum = HB.summary(r.block, []);
  assert.equal(sum.denominator, 20); assert.equal(sum.PLANNED_REST, 1); assert.equal(sum.SKIPPED, 0); assert.equal(sum.SOURCE_OMITTED, 0);
  assert.equal(HB.rescheduleCheck(r.blocks, a.block.id + '-W1-MON', '2026-12-15', [], '2026-12-14').ok, false, 'planned-rest day never receives a session');
  const w4 = a.block.id + '-W4-TUE';
  assert.equal(HB.revise(a.blocks, a.block.id, w4, 'OWNER_TEXT', 'Run 6x800 m', [], '2026-12-14', TS, rand).code, 'DELOAD_NO_UPWARD');
  for (const k of ['LOW_IMPACT', 'REDUCED_VOLUME', 'FALLBACK_45', 'FALLBACK_25', 'PLANNED_REST']) assert.equal(HB.revise(a.blocks, a.block.id, w4, k, '', [], '2026-12-14', TS, rand).ok, true, k);
  const o = HB.revise(a.blocks, a.block.id, a.block.id + '-W2-MON', 'OWNER_TEXT', 'Squat 3x5 @ RPE 6\nRow 3x10', [], '2026-12-14', TS, rand);
  const s = HB.slotById(a.block.id + '-W2-MON', o.blocks);
  assert.equal(s.revision.ownerWritten, true); assert.match(s.prescription[0], /^Owner-written/);
  assert.equal(HB.revise(a.blocks, a.block.id, a.block.id + '-W2-MON', 'OWNER_TEXT', 'x'.repeat(281), [], '2026-12-14', TS, rand).code, 'TEXT');
  for (const k of ['LOW_IMPACT', 'REDUCED_VOLUME', 'FALLBACK_45', 'FALLBACK_25']) for (const sl of a.block.slots) {
    const rv = HB.revise(a.blocks, a.block.id, sl.id, k, '', [], '2026-12-13', TS, rand);
    if (rv.ok) assert.ok(HB.machineMinutes(HB.slotById(sl.id, rv.blocks).prescription).every((m) => m <= 15), sl.id + ' ' + k);
  }
});
test('end early: later sessions become "not in plan", never missed; blocks after it are unaffected', () => {
  const a = active();
  const e = HB.endEarly(a.blocks, a.block.id, '2026-12-22');
  assert.equal(e.ok, true); assert.equal(e.block.endedEarlyOn, '2026-12-23');
  assert.equal(HB.slotStatus(e.blocks, a.block.id + '-W2-WED', []).code, 'NOT_IN_PLAN');
  assert.equal(HB.slotStatus(e.blocks, a.block.id + '-W2-TUE', []).code, 'NOT_LOGGED');
  assert.equal(HB.blockForDate('2026-12-23', e.blocks), null);
  assert.equal(HB.summary(e.block, []).denominator, 20);
  assert.equal(HB.endEarly(a.blocks, a.block.id, '2026-12-12').code, 'NOT_STARTED');
});
test('benchmark 3: comparable only when unmodified ORIGINAL_60; a modified one is recorded as modified', () => {
  const a = active(); const fri = a.block.id + '-W4-FRI';
  assert.equal(HB.benchmarks(a.block, [sess(fri, '2027-01-08', 'COMPLETED')])[0].comparable, true);
  const m = HB.benchmarks(a.block, [sess(fri, '2027-01-08', 'COMPLETED', { modified: true })])[0];
  assert.equal(m.comparable, false); assert.match(m.note, /modified/);
  assert.match(HB.variantPrescription(HB.slotById(fri, a.blocks), 'SOURCE_45_MIN').prescription.join(' '), /not benchmark-comparable/);
  assert.equal(HB.variantFamilyError(HB.slotById(fri, a.blocks), 'MAIN_LIFT_45') !== null, true);
  assert.equal(HB.variantFamilyError(HB.slotById(a.block.id + '-W1-MON', a.blocks), 'MAIN_LIFT_45'), null);
});

// ---------- integrity ----------
test('corrupt or duplicate blocks are reported and not used; malformed planBlocks is refused, never overwritten', () => {
  const a = active();
  const bad1 = JSON.parse(JSON.stringify(a.block)); bad1.slots[3].date = '2026-12-31';
  const bad2 = { id: 'nonsense' }; const dup = JSON.parse(JSON.stringify(a.block));
  const r = HB.readBlocks([a.block, bad1, bad2, dup, 'x']);
  assert.equal(r.blocks.length, 1); assert.equal(r.invalid.length, 4);
  assert.equal(HB.readBlocks({ not: 'a list' }).malformed, true);
  bad1.state = 'DRAFT';
  assert.equal(HB.activationCheck([bad1], bad1.id, '2026-12-11', { approved: true }).code, 'INVALID', 'a damaged draft cannot be activated');
});
test('writers: field-preserving fresh re-read; STALE across two tabs; damaged settings refused; corrupt entries kept', () => {
  const storage = mem(); const now = () => new Date('2026-12-11T09:00:00Z');
  const tabA = HD.createStore(storage, { now }), tabB = HD.createStore(storage, { now });
  const base = { id: HD.SETTINGS_ID, date: '2026-12-11', rhrBaselineBpm: 60, myFoods: [{ id: 'mf1', name: 'Oats' }], favFoods: ['mf1'], p113FutureField: { keep: true },
    planBlocks: [{ id: 'garbage-entry', state: 'WEIRD' }] };
  assert.equal(tabA.putRecord('ownerSettings', base).ok, true);
  const stampB = HB.settingsStamp(tabB);
  const d = HB.writeBlocks(tabA, HD, '2026-12-11', (raw) => HB.createDraft(raw, '2026-12-14', '2026-12-11', TS, rand));
  assert.equal(d.ok, true);
  const rec = tabA.settings().record;
  assert.deepEqual(rec.myFoods, base.myFoods); assert.deepEqual(rec.favFoods, ['mf1']); assert.deepEqual(rec.p113FutureField, { keep: true }); assert.equal(rec.rhrBaselineBpm, 60);
  assert.deepEqual(rec.planBlocks[0], { id: 'garbage-entry', state: 'WEIRD' }, 'corrupt entry kept as stored');
  // tab B opened before the write: its activation is refused as STALE
  const s2 = HB.writeBlocks(tabB, HD, '2026-12-11', (raw) => HB.activate(raw, d.block.id, '2026-12-11', TS, { approved: true }), { expectStamp: stampB });
  assert.equal(s2.code, 'STALE');
  const s3 = HB.writeBlocks(tabB, HD, '2026-12-11', (raw) => HB.activate(raw, d.block.id, '2026-12-11', TS, { approved: true }), { expectStamp: HB.settingsStamp(tabB) });
  assert.equal(s3.ok, true);
  const s4 = HB.writeBlocks(tabA, HD, '2026-12-11', (raw) => HB.activate(raw, d.block.id, '2026-12-11', TS, { approved: true }));
  assert.equal(s4.code, 'ALREADY_ACTIVE', 'second tab without stamp still cannot double-activate');
  // a P11.3-style foods writer that re-reads and clones keeps planBlocks
  const fresh = JSON.parse(JSON.stringify(tabA.settings().record)); fresh.myFoods.push({ id: 'mf2', name: 'Rice' });
  assert.equal(tabA.putRecord('ownerSettings', fresh).ok, true);
  assert.equal(HB.readBlocks(tabA.settings().record.planBlocks).blocks.length, 1);
  // malformed planBlocks: refused, nothing changed
  const st2 = HD.createStore(mem(), { now }); st2.putRecord('ownerSettings', { id: HD.SETTINGS_ID, date: '2026-12-11', planBlocks: 'oops' });
  const before = JSON.stringify(st2.settings().record);
  assert.equal(HB.writeBlocks(st2, HD, '2026-12-11', (raw) => HB.createDraft(raw, '2026-12-14', '2026-12-11', TS, rand)).code, 'PLAN_BLOCKS_MALFORMED');
  assert.equal(JSON.stringify(st2.settings().record), before);
  // damaged settings record: refused
  const st3mem = mem(); const st3 = HD.createStore(st3mem, { now }); st3.putRecord('ownerSettings', { id: HD.SETTINGS_ID, date: '2026-12-11', rhrBaselineBpm: 60 });
  const raw = JSON.parse(st3mem.getItem(HD.STORAGE_KEY)); raw.ownerSettings[0].rhrBaselineBpm = 'bad'; st3mem.setItem(HD.STORAGE_KEY, JSON.stringify(raw));
  const st3b = HD.createStore(st3mem, { now });
  if (st3b.damagedRecords().some((x) => x.collection === 'ownerSettings')) assert.equal(HB.writeBlocks(st3b, HD, '2026-12-11', (r) => HB.createDraft(r, '2026-12-14', '2026-12-11', TS, rand)).code, 'SETTINGS_DAMAGED');
});
test('repairCarry keeps every valid field (planBlocks, foods, unknown later fields) and drops only the damaged ones', () => {
  const a = active();
  const rawRec = { id: HD.SETTINGS_ID, date: '2026-12-11', createdAt: TS, rhrBaselineBpm: 'bad', myFoods: [{ id: 'm', name: 'Egg' }], planBlocks: a.blocks, p113FutureField: 3 };
  const r = HB.repairCarry(rawRec, ['rhrBaselineBpm'], [], HD, '2026-12-11');
  assert.deepEqual(Object.keys(r.carry).sort(), ['myFoods', 'p113FutureField', 'planBlocks']);
  assert.deepEqual(r.carry.planBlocks, a.blocks);
  const big = HB.repairCarry({ id: HD.SETTINGS_ID, img: 'x'.repeat(5000) }, [], [], HD, '2026-12-11');
  assert.deepEqual(big.dropped, ['img']);
});
test('a large, heavily revised block stays a valid settings record (size and nesting limits)', () => {
  let a = active(); const st = HD.createStore(mem(), { now: () => new Date('2026-12-11T09:00:00Z') });
  for (let i = 0; i < 18; i++) {
    const sl = a.block.slots[i + 2]; const k = sl.week === 4 ? 'REDUCED_VOLUME' : 'OWNER_TEXT';
    const r = HB.revise(a.blocks, a.block.id, sl.id, k, Array(8).fill('y'.repeat(280)).join('\n'), [], '2026-12-13', TS, rand); assert.equal(r.ok, true, r.text); a = r;
  }
  const r = st.putRecord('ownerSettings', { id: HD.SETTINGS_ID, date: '2026-12-11', planBlocks: a.blocks });
  assert.equal(r.ok, true, JSON.stringify(r.errors || ''));
  assert.deepEqual(HB.validateBlock(a.block), []);
});

// ---------- export / restore and downgrade ----------
function p12Export() {
  const st = HD.createStore(mem(), { now: () => new Date('2026-12-21T09:00:00Z') });
  let a = active();
  a = HB.addEvent(a.blocks, a.block.id, 'MISSED_MONDAY', 1, '2026-12-14', TS, rand);
  a = HB.revise(a.blocks, a.block.id, a.block.id + '-W3-THU', 'PLANNED_REST', '', [], '2026-12-21', TS, rand);
  assert.equal(st.putRecord('ownerSettings', { id: HD.SETTINGS_ID, date: '2026-12-11', rhrBaselineBpm: 60, myFoods: [{ id: 'mf1', name: 'Oats' }], favFoods: ['mf1'], planBlocks: a.blocks }).ok, true);
  const s1 = { date: '2026-12-15', title: 'Strength A', status: 'COMPLETED', modified: false, variant: 'ORIGINAL_60', blocks: [], planSlotId: a.block.id + '-W1-MON', planVersion: 'b2-hold-1', scheduledDate: '2026-12-14' };
  const s2 = { date: '2026-12-18', title: 'Race skills', status: 'SKIPPED', modified: false, variant: 'ORIGINAL_60', blocks: [], planSlotId: a.block.id + '-W1-FRI', planVersion: 'b2-hold-1', scheduledDate: '2026-12-18', skipDecision: 'SKIP_PERMANENT', skipConfirmed: true };
  assert.equal(st.putRecord('sessions', s1).ok, true); assert.equal(st.putRecord('sessions', s2).ok, true);
  return { text: st.exportJSON(), blocks: a.blocks, blockId: a.block.id };
}
function restoreOn(HDx, text) {
  const tgt = HDx.createStore(mem(), { now: () => new Date('2026-12-21T09:00:00Z') });
  const p = tgt.previewImport(text); assert.equal(p.ok, true, JSON.stringify(p.errors || p.message || ''));
  const r = tgt.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt });
  assert.equal(r.ok, true, JSON.stringify(r));
  return tgt;
}
test('export -> restore on this build keeps planBlocks, foods and Block 2 sessions exactly', () => {
  const e = p12Export();
  const tgt = restoreOn(HD, e.text);
  assert.deepEqual(tgt.settings().record.planBlocks, e.blocks);
  assert.deepEqual(tgt.settings().record.myFoods, [{ id: 'mf1', name: 'Oats' }]);
  const ss = tgt.records('sessions'); assert.equal(ss.length, 2);
  assert.equal(HB.slotStatus(HB.readBlocks(tgt.settings().record.planBlocks).blocks, e.blockId + '-W1-MON', ss).code, 'COMPLETED');
  assert.equal(ss.find((s) => s.status === 'SKIPPED').skipDecision, 'SKIP_PERMANENT');
});
test('restoreNote warns before a backup without Block 2 replaces a device that has it', () => {
  const e = p12Export();
  const dev = JSON.stringify(JSON.parse(e.text));
  const old = JSON.parse(e.text); delete old.ownerSettings[0].planBlocks;
  assert.match(HB.restoreNote(dev, JSON.stringify(old)), /removes Block 2 from this device/);
  assert.equal(HB.restoreNote(dev, e.text), null);
  assert.equal(HB.restoreNote(null, JSON.stringify(old)), null);
  assert.match(HB.restoreNote(JSON.stringify(old), e.text), /differ/);
});
const OLD = {
  'Claude P11.2 (6e2b2cae)': '/workspace/hyrox-p12/src-ref/hyrox-app-phase11-2-source-claude/src',
  'Claude P11 (bdab182, ffa58d1a)': '/workspace/hyrox-p12/old/claude-p11/hyrox-app-phase11-source-claude/src',
  'Claude P10b (34bdf3d)': '/workspace/hyrox-p12/old/claude-p10b/hyrox-app-phase10b-source-claude/src',
};
for (const [name, dir] of Object.entries(OLD)) {
  const has = fs.existsSync(path.join(dir, 'data', 'hyrox-data.js'));
  (has ? test : test.skip)(`rollback: a P12 backup restores on the ${name} data layer with planBlocks and Block 2 sessions intact; a fresh-read settings save there keeps them`, () => {
    const e = p12Export();
    const HDo = require(path.join(dir, 'data', 'hyrox-data.js'));
    const tgt = restoreOn(HDo, e.text);
    assert.deepEqual(tgt.settings().record.planBlocks, e.blocks);
    assert.equal(tgt.records('sessions').length, 2);
    assert.equal(tgt.records('sessions').find((s) => s.status === 'SKIPPED').skipDecision, 'SKIP_PERMANENT');
    assert.equal(typeof tgt.damagedRecords === 'function' ? tgt.damagedRecords().length : 0, 0);
    const rec = JSON.parse(JSON.stringify(tgt.settings().record)); rec.rhrBaselineBpm = 62;
    assert.equal(tgt.putRecord('ownerSettings', rec).ok, true);
    assert.deepEqual(tgt.settings().record.planBlocks, e.blocks, 'old-build settings save (clone of stored record) keeps planBlocks');
    // the exported text from the old build still carries Block 2 back
    const back = restoreOn(HD, tgt.exportJSON());
    assert.deepEqual(back.settings().record.planBlocks, e.blocks);
  });
}
