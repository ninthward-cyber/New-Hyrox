'use strict';
// Config for the isolated Emergent container: Playwright-bundled WebKit (desktop engine with iPhone 13
// emulation — NOT real iPhone Safari) and bundled Chromium. Usage:
//   NODE_PATH=<dir with @playwright/test> npx playwright test -c tests/playwright.emergent.config.js
const path = require('path');
const { defineConfig, devices } = require('@playwright/test');

const port = Number(process.env.HYROX_APP_PORT || 4173);
const mobile = { viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, timezoneId: 'Asia/Qatar', locale: 'en-US' };

module.exports = defineConfig({
  testDir: path.join(__dirname, 'e2e'),
  testMatch: '**/*.spec.js',
  workers: 1,
  timeout: 30000,
  expect: { timeout: 8000 },
  outputDir: path.join(__dirname, 'out/playwright-results'),
  reporter: [['list']],
  use: { baseURL: 'http://127.0.0.1:' + port + '/', acceptDownloads: true },
  projects: [
    { name: 'webkit-iphone13-emulation', use: { ...devices['iPhone 13'], ...mobile, browserName: 'webkit' } },
    { name: 'chromium-mobile', use: { ...mobile, browserName: 'chromium' } },
  ],
  webServer: {
    command: process.execPath + ' ' + JSON.stringify(path.join(__dirname, 'static-server.js')),
    url: 'http://127.0.0.1:' + port + '/',
    reuseExistingServer: false,
    timeout: 15000,
    env: { HYROX_APP_ROOT: path.resolve(__dirname, '..'), HYROX_APP_PORT: String(port) },
  },
});
