'use strict';
// Phase 9: server function tests. The real handler code runs against an in-memory Blobs-compatible store and a stub
// OpenAI endpoint (injected fetch). No network, no key, synthetic images only.
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');

let H, cfgMod, imgMod, storeMod, oaMod;
before(async () => {
  H = await import('./p9-helpers.mjs');
  cfgMod = await import('../netlify/lib/config.mjs');
  imgMod = await import('../netlify/lib/image.mjs');
  storeMod = await import('../netlify/lib/store.mjs');
  oaMod = await import('../netlify/lib/openai.mjs');
});

const run = async (ctx, req, context) => H.j(await ctx.handle(req, context || { ip: '203.0.113.9' }));
const codeOf = (r) => r.body.detail && r.body.detail.code;

describe('P9 auth: the function itself refuses unauthenticated, wrong and forged requests', () => {
  it('no Authorization header -> 401 AUTH, no provider call, no storage access', async () => {
    const c = H.setup();
    const r = await run(c, H.analyzeReq({ token: null }));
    assert.equal(r.status, 401); assert.equal(codeOf(r), 'AUTH');
    assert.equal(c.fetchStub.calls.length, 0); assert.equal(c.store.ops, 0);
  });
  it('wrong code -> 401, never a provider call; a near-miss and an empty bearer fail too', async () => {
    const c = H.setup();
    for (const t of [H.OWNER_CODE + 'x', H.OWNER_CODE.slice(0, -1), 'wrong', 'Bearer', '']) {
      const r = await run(c, H.analyzeReq({ token: t || null, headers: t === '' ? { Authorization: 'Bearer ' } : t === 'Bearer' ? { Authorization: 'Bearer' } : {} }));
      assert.equal(r.status, 401);
    }
    assert.equal(c.fetchStub.calls.length, 0);
  });
  it('fake headers do not authenticate: consent header, same-site Origin/Referer, forwarded IP, X-Hyrox-* tokens, query token', async () => {
    const c = H.setup();
    const r = await run(c, H.analyzeReq({ token: null, url: 'https://hyrox.test/api/food-photo/analyze?token=' + H.OWNER_CODE,
      headers: { Origin: 'https://hyrox.test', Referer: 'https://hyrox.test/', 'X-Forwarded-For': '127.0.0.1', 'X-Hyrox-Owner': H.OWNER_CODE, 'X-Hyrox-Token': H.OWNER_HASH, 'X-NF-Client-Connection-IP': '127.0.0.1', Cookie: 'owner=' + H.OWNER_CODE } }));
    assert.equal(r.status, 401); assert.equal(c.fetchStub.calls.length, 0);
    const r2 = await run(c, H.analyzeReq({ token: H.OWNER_HASH })); // the stored hash is not a usable credential
    assert.equal(r2.status, 401);
  });
  it('non-app Origin: refused even with a valid code (defence in depth); same Origin passes; no Origin (curl) passes', async () => {
    const c = H.setup();
    const bad = await run(c, H.analyzeReq({ headers: { Origin: 'https://evil.example' } }));
    assert.equal(bad.status, 403); assert.equal(codeOf(bad), 'NOT_AUTHORIZED');
    const noToken = await run(c, H.analyzeReq({ token: null, headers: { Origin: 'https://evil.example' } }));
    assert.ok([401, 403].includes(noToken.status));
    assert.equal(c.fetchStub.calls.length, 0);
    const ok = await run(c, H.analyzeReq({ headers: { Origin: 'https://hyrox.test' } }));
    assert.equal(ok.status, 200);
    c.clock.t += 60000;
    const ok2 = await run(c, H.analyzeReq());
    assert.equal(ok2.status, 200);
  });
  it('lockout: 5 wrong codes lock that client for 30 minutes, even for the right code; other clients and later times are unaffected', async () => {
    const c = H.setup();
    for (let i = 0; i < 5; i++) assert.equal((await run(c, H.analyzeReq({ token: 'nope' + i }), { ip: '198.51.100.7' })).status, 401);
    const locked = await run(c, H.analyzeReq(), { ip: '198.51.100.7' });
    assert.equal(locked.status, 429); assert.equal(codeOf(locked), 'LOCKED_OUT'); assert.ok(Number(locked.headers.get('retry-after')) > 0);
    assert.equal(c.fetchStub.calls.length, 0);
    const other = await run(c, H.analyzeReq(), { ip: '192.0.2.55' });
    assert.equal(other.status, 200);
    c.clock.t += 31 * 60 * 1000;
    assert.equal((await run(c, H.analyzeReq(), { ip: '198.51.100.7' })).status, 200);
  });
  it('lockout also protects /status; status never reveals usage to anonymous callers', async () => {
    const c = H.setup();
    const anon = await run(c, H.statusReq());
    assert.equal(anon.status, 200); assert.equal(anon.body.authorized, false); assert.equal(anon.body.usage, undefined); assert.equal(anon.body.model, undefined);
    assert.equal((await run(c, H.statusReq('bad'))).status, 401);
    const good = await run(c, H.statusReq(H.OWNER_CODE));
    assert.equal(good.status, 200); assert.equal(good.body.authorized, true); assert.equal(good.body.usage.day.cap, 20);
    assert.equal(JSON.stringify(good.body).includes(H.FAKE_KEY), false);
  });
});

describe('P9 fail closed: missing configuration => NOT_CONFIGURED on both endpoints, no provider call', () => {
  const cases = [
    ['no env at all', { HYROX_PHOTO_ENABLED: undefined, OPENAI_API_KEY: undefined, HYROX_OWNER_CODE_HASH: undefined }],
    ['enable flag missing', { HYROX_PHOTO_ENABLED: undefined }],
    ['enable flag "TRUE"', { HYROX_PHOTO_ENABLED: 'TRUE' }], ['enable flag "1"', { HYROX_PHOTO_ENABLED: '1' }], ['enable flag "false"', { HYROX_PHOTO_ENABLED: 'false' }],
    ['API key missing', { OPENAI_API_KEY: undefined }], ['API key too short', { OPENAI_API_KEY: 'sk-x' }],
    ['owner hash missing', { HYROX_OWNER_CODE_HASH: undefined }], ['owner hash malformed', { HYROX_OWNER_CODE_HASH: 'abc123' }],
    ['unknown model without price', { HYROX_PHOTO_MODEL: 'mystery-model-9' }],
    ['bad cap value', { HYROX_DAILY_CALL_CAP: 'lots' }], ['non-local base url', { HYROX_OPENAI_BASE_URL: 'https://evil.example' }],
  ];
  for (const [name, env] of cases) it(name, async () => {
    const c = H.setup({ env });
    const a = await run(c, H.analyzeReq());
    assert.equal(a.status, 503); assert.equal(codeOf(a), 'NOT_CONFIGURED');
    const s = await run(c, H.statusReq(H.OWNER_CODE));
    assert.equal(s.status, 503); assert.equal(codeOf(s), 'NOT_CONFIGURED'); assert.equal(s.body.configured, false);
    assert.equal(c.fetchStub.calls.length, 0);
    assert.equal(JSON.stringify([a.body, s.body]).includes('OPENAI'), false); // does not tell the caller which variable
  });
  it('an unlisted model works only with an explicit price pair', async () => {
    // Claude P10 review: an unlisted model is costed conservatively before every call, and at 1.5/M output its worst case
    // exceeds the default $0.004 reservation, so this test also raises HYROX_RESERVE_USD (the documented remedy).
    const c = H.setup({ env: { HYROX_PHOTO_MODEL: 'mystery-model-9', HYROX_PRICE_IN_PER_M: '0.3', HYROX_PRICE_OUT_PER_M: '1.5', HYROX_RESERVE_USD: '0.02' } });
    assert.equal((await run(c, H.analyzeReq())).status, 200);
    assert.equal(c.fetchStub.calls[0].body.model, 'mystery-model-9');
  });
  it('caps cannot be raised past the hard ceilings', () => {
    const r = cfgMod.readConfig({ ...H.BASE_ENV, HYROX_TOTAL_USD_CAP: '999', HYROX_MONTHLY_USD_CAP: '999', HYROX_DAILY_CALL_CAP: '9999', HYROX_MONTHLY_CALL_CAP: '99999' });
    assert.equal(r.ok, true);
    assert.equal(r.config.totalUsd, cfgMod.CEILINGS.totalUsd); assert.equal(r.config.monthlyUsd, cfgMod.CEILINGS.monthlyUsd);
    assert.equal(r.config.dailyCalls, cfgMod.CEILINGS.dailyCalls); assert.equal(r.config.monthlyCalls, cfgMod.CEILINGS.monthlyCalls);
  });
  it('defaults: $5 trial, $3 month, gpt-6-luna, auto detail', () => {
    const r = cfgMod.readConfig(H.BASE_ENV).config;
    assert.deepEqual([r.totalUsd, r.monthlyUsd, r.dailyCalls, r.monthlyCalls, r.model, r.detail, r.timeoutMs], [5, 3, 20, 300, 'gpt-6-luna', 'auto', 40000]);
    assert.ok(r.timeoutMs < 45000);
  });
});

describe('P9 request validation (nothing reaches the provider)', () => {
  it('consent: missing header, wrong value, consent:false', async () => {
    const c = H.setup();
    assert.equal(codeOf(await run(c, H.analyzeReq({ headers: { 'X-Hyrox-Consent': undefined } }))), 'NO_CONSENT');
    assert.equal(codeOf(await run(c, H.analyzeReq({ headers: { 'X-Hyrox-Consent': 'yes' } }))), 'NO_CONSENT');
    assert.equal(codeOf(await run(c, H.analyzeReq({ bodyObj: { consent: false } }))), 'NO_CONSENT');
    assert.equal(c.fetchStub.calls.length, 0);
  });
  it('oversize: declared length, streamed body, and base64 over the image cap -> 413', async () => {
    const c = H.setup();
    const big = JSON.stringify({ imageBase64: 'A'.repeat(3_000_000), mimeType: 'image/jpeg', consent: true, requestId: 'req-big1' });
    const r1 = await run(c, H.analyzeReq({ body: big }));
    assert.equal(r1.status, 413); assert.equal(codeOf(r1), 'TOO_LARGE');
    const r2 = await run(c, H.analyzeReq({ body: big, headers: { 'Content-Length': '99999999' } }));
    assert.equal(r2.status, 413);
    const r3 = await run(c, H.analyzeReq({ bodyObj: { imageBase64: 'A'.repeat(2_300_000), requestId: 'req-big2' } }));
    assert.equal(r3.status, 413);
    assert.equal(c.fetchStub.calls.length, 0);
  });
  it('malformed JSON, wrong content type, non-object, bad request id, long description -> 400', async () => {
    const c = H.setup();
    assert.equal(codeOf(await run(c, H.analyzeReq({ body: '{nope' }))), 'BAD_REQUEST');
    assert.equal(codeOf(await run(c, H.analyzeReq({ body: '[1,2]' }))), 'BAD_REQUEST');
    assert.equal(codeOf(await run(c, H.analyzeReq({ headers: { 'Content-Type': 'text/plain' } }))), 'BAD_REQUEST');
    assert.equal(codeOf(await run(c, H.analyzeReq({ bodyObj: { requestId: '../../x' } }))), 'BAD_REQUEST');
    assert.equal(codeOf(await run(c, H.analyzeReq({ bodyObj: { requestId: undefined } }))), 'BAD_REQUEST');
    assert.equal(codeOf(await run(c, H.analyzeReq({ bodyObj: { description: 'x'.repeat(501) } }))), 'BAD_REQUEST');
    assert.equal(c.fetchStub.calls.length, 0);
  });
  it('non-image payloads: text, PDF, PNG, WebP, HEIC, GIF, random bytes, truncated JPEG, tiny and huge dimensions, bad base64, wrong MIME', async () => {
    const c = H.setup();
    const send = async (b64, mime = 'image/jpeg') => run(c, H.analyzeReq({ bodyObj: { imageBase64: b64, mimeType: mime, requestId: 'req-' + Math.random().toString(36).slice(2) } }));
    const b = (x) => Buffer.from(x).toString('base64');
    const expect = async (b64, codes, mime) => { const r = await send(b64, mime); assert.equal(r.status, 400, 'status for ' + codes); assert.ok(codes.includes(codeOf(r)), codeOf(r)); };
    await expect(b('hello world, not an image at all'), ['UNSUPPORTED_TYPE']);
    await expect(b('%PDF-1.7\n1 0 obj\n'), ['UNSUPPORTED_TYPE']);
    await expect(H.jpegB64('synthetic-food-clean.png'), ['UNSUPPORTED_TYPE']);
    await expect(H.jpegB64('p9-sample.webp'), ['UNSUPPORTED_TYPE']);
    await expect(H.jpegB64('p9-fake.heic'), ['UNSUPPORTED_TYPE']);
    await expect(b('GIF89a' + '\u0000'.repeat(40)), ['UNSUPPORTED_TYPE']);
    await expect(H.jpegB64('not-an-image.jpg'), ['UNSUPPORTED_TYPE']);
    await expect(b(Buffer.from([0xFF, 0xD8, 0xFF, 0xE0, 0, 16, 0x4A, 0x46])), ['CORRUPT_IMAGE']);
    const whole = fs.readFileSync(H.FIX('p9-clean-square.jpg'));
    await expect(b(whole.subarray(0, whole.length - 40)), ['CORRUPT_IMAGE']); // truncated
    await expect(b(whole.subarray(0, 300)), ['CORRUPT_IMAGE']);
    await expect(H.jpegB64('p9-tiny.jpg'), ['CORRUPT_IMAGE']);
    await expect(H.jpegB64('p9-wide-dims.jpg'), ['CORRUPT_IMAGE']);
    await expect('@@@@not base64!!!', ['BAD_REQUEST']);
    await expect(H.jpegB64(), ['UNSUPPORTED_TYPE'], 'image/png'); // MIME not on the allowlist
    await expect(H.jpegB64(), ['UNSUPPORTED_TYPE'], 'text/html');
    assert.equal(c.fetchStub.calls.length, 0);
  });
  it('a JPEG with trailing junk after EOI is cleaned, and a progressive JPEG is accepted', async () => {
    const c = H.setup();
    const ok = await run(c, H.analyzeReq({ bodyObj: { imageBase64: H.jpegB64('p9-progressive.jpg') } }));
    assert.equal(ok.status, 200);
    const junk = Buffer.concat([fs.readFileSync(H.FIX('p9-clean-square.jpg')), Buffer.from('SECRET-TRAILER-TEXT')]).toString('base64');
    c.clock.t += 5000;
    const ok2 = await run(c, H.analyzeReq({ bodyObj: { imageBase64: junk } }));
    assert.equal(ok2.status, 200);
    const sent = Buffer.from(c.fetchStub.calls[1].body.input[0].content[1].image_url.split(',')[1], 'base64');
    assert.equal(sent.includes(Buffer.from('SECRET-TRAILER')), false);
  });
});

describe('P9 provider request contract + server-side metadata strip', () => {
  it('sends strict structured output, the configured model, low-cost detail, store:false, the key only in the header; EXIF/GPS never reach OpenAI', async () => {
    const c = H.setup();
    const exifB64 = fs.readFileSync(H.FIX('synthetic-food-exif.jpg')).toString('base64');
    const r = await run(c, H.analyzeReq({ bodyObj: { imageBase64: exifB64, description: 'half portion, no sauce' } }));
    assert.equal(r.status, 200);
    const call = c.fetchStub.calls[0];
    assert.equal(call.url, 'https://api.openai.com/v1/responses');
    assert.equal(call.init.headers.Authorization, 'Bearer ' + H.FAKE_KEY);
    assert.equal(call.body.model, 'gpt-6-luna'); assert.equal(call.body.store, false);
    assert.equal(call.body.text.format.type, 'json_schema'); assert.equal(call.body.text.format.strict, true);
    assert.equal(call.body.input[0].content[1].detail, 'auto');
    assert.ok(call.body.max_output_tokens <= 3000);
    assert.equal(JSON.stringify(call.body).includes(H.FAKE_KEY), false);
    assert.ok(call.body.input[0].content[0].text.includes('untrusted'));
    const img = Buffer.from(call.body.input[0].content[1].image_url.split(',')[1], 'base64');
    for (const s of ['Exif', 'SyntheticCam', 'synthetic fixture comment']) assert.equal(img.includes(Buffer.from(s)), false, s);
    assert.equal(img[0], 0xFF); assert.equal(img[img.length - 1], 0xD9);
    // every property is required (strict-mode rule) and unknowns may be null
    const it0 = call.body.text.format.schema.properties.items.items;
    assert.deepEqual([...it0.required].sort(), Object.keys(it0.properties).sort());
    assert.equal(it0.additionalProperties, false);
  });
  it('detail=low and reasoning=none are honoured from env', async () => {
    const c = H.setup({ env: { HYROX_PHOTO_IMAGE_DETAIL: 'low', HYROX_PHOTO_REASONING: 'none' } });
    await run(c, H.analyzeReq());
    assert.equal(c.fetchStub.calls[0].body.input[0].content[1].detail, 'low');
    assert.equal(c.fetchStub.calls[0].body.reasoning.effort, 'none');
  });
});

describe('P9 response mapping to schema v1', () => {
  it('maps to the exact client contract; not-visible oil is null/LOW/flagged; zero stays zero only where the model said zero', async () => {
    const c = H.setup();
    const r = await run(c, H.analyzeReq());
    assert.equal(r.status, 200);
    assert.deepEqual(Object.keys(r.body).sort(), ['items', 'model', 'provider', 'schemaVersion', 'warnings']);
    assert.equal(r.body.schemaVersion, 1); assert.equal(r.body.provider, 'openai'); assert.equal(r.body.model, 'gpt-6-luna');
    const [chk, rice, oil] = r.body.items;
    assert.equal(chk.carbsG, 0); assert.equal(chk.role, 'MAIN'); assert.equal(chk.eatenFraction, null);
    assert.deepEqual([oil.kcal, oil.proteinG, oil.carbsG, oil.fatG], [null, null, null, null]);
    assert.equal(oil.confidence, 'LOW'); assert.match(oil.uncertainty, /Not visible/);
    assert.ok(r.body.warnings.some((w) => /Hidden oil/.test(w)) && r.body.warnings.some((w) => /Real model estimate/.test(w)));
    for (const it of r.body.items) assert.deepEqual(Object.keys(it).sort(), ['carbsG', 'confidence', 'eatenFraction', 'fatG', 'kcal', 'name', 'portion', 'preparation', 'proteinG', 'role', 'uncertainty']);
    // the browser validator accepts it unchanged
    const AI = require('../src/ai/photo-ai.js');
    assert.equal(AI.validateResult(r.body).ok, true, JSON.stringify(AI.validateResult(r.body).errors));
  });
  it('null numbers stay null (never coerced to 0); empty item list is a valid answer', async () => {
    const txt = JSON.stringify({ items: [{ name: 'Mystery stew', role: 'MAIN', preparation: null, portion: null, notVisible: false, kcal: null, proteinG: null, carbsG: null, fatG: null, confidence: 'LOW', uncertainty: null }], warnings: [] });
    let c = H.setup({ script: () => H.openaiOk(txt) });
    let r = await run(c, H.analyzeReq());
    assert.deepEqual([r.body.items[0].kcal, r.body.items[0].proteinG, r.body.items[0].carbsG, r.body.items[0].fatG], [null, null, null, null]);
    c = H.setup({ script: () => H.openaiOk(JSON.stringify({ items: [], warnings: ['No food visible.'] })) });
    r = await run(c, H.analyzeReq());
    assert.equal(r.status, 200); assert.deepEqual(r.body.items, []);
  });
  it('markup in model text is neutralised; text is length-limited', async () => {
    const txt = JSON.stringify({ items: [{ name: '<img src=x onerror=alert(1)>Rice javascript:alert(2)' + 'z'.repeat(200), role: 'SIDE', preparation: null, portion: '<b>1 cup</b>', notVisible: false, kcal: 200, proteinG: 4, carbsG: 44, fatG: 1, confidence: 'HIGH', uncertainty: null }], warnings: ['<script>x</script>ok'] });
    const c = H.setup({ script: () => H.openaiOk(txt) });
    const r = await run(c, H.analyzeReq());
    assert.equal(r.status, 200);
    assert.ok(!/[<>]|javascript:/i.test(JSON.stringify(r.body)));
    assert.ok(r.body.items[0].name.length <= 80);
  });
  const bad = {
    'invalid JSON text': 'this is not json {', 'prose around json': 'Here you go: {"items":[],"warnings":[]}',
    'wrong shape': JSON.stringify({ foods: [] }), 'bad role': JSON.stringify({ items: [{ name: 'x', role: 'SNACKY', preparation: null, portion: null, notVisible: false, kcal: 1, proteinG: 0, carbsG: 0, fatG: 0, confidence: 'LOW', uncertainty: null }], warnings: [] }),
    'bad confidence': JSON.stringify({ items: [{ name: 'x', role: 'MAIN', preparation: null, portion: null, notVisible: false, kcal: 1, proteinG: 0, carbsG: 0, fatG: 0, confidence: 'SURE', uncertainty: null }], warnings: [] }),
    'negative kcal': JSON.stringify({ items: [{ name: 'x', role: 'MAIN', preparation: null, portion: null, notVisible: false, kcal: -5, proteinG: 0, carbsG: 0, fatG: 0, confidence: 'LOW', uncertainty: null }], warnings: [] }),
    'string number': JSON.stringify({ items: [{ name: 'x', role: 'MAIN', preparation: null, portion: null, notVisible: false, kcal: '200', proteinG: 0, carbsG: 0, fatG: 0, confidence: 'LOW', uncertainty: null }], warnings: [] }),
    'impossible magnitude': JSON.stringify({ items: [{ name: 'x', role: 'MAIN', preparation: null, portion: null, notVisible: false, kcal: 99999, proteinG: 0, carbsG: 0, fatG: 0, confidence: 'LOW', uncertainty: null }], warnings: [] }),
    'empty name': JSON.stringify({ items: [{ name: '  ', role: 'MAIN', preparation: null, portion: null, notVisible: false, kcal: 10, proteinG: 1, carbsG: 1, fatG: 0, confidence: 'LOW', uncertainty: null }], warnings: [] }),
    'too many items': JSON.stringify({ items: Array.from({ length: 21 }, () => ({ name: 'x', role: 'MAIN', preparation: null, portion: null, notVisible: false, kcal: 10, proteinG: 1, carbsG: 1, fatG: 0, confidence: 'LOW', uncertainty: null })), warnings: [] }),
    'inconsistent macros (salad: 50 kcal, 100/100/100 g)': JSON.stringify({ items: [{ name: 'Salad', role: 'MAIN', preparation: null, portion: null, notVisible: false, kcal: 50, proteinG: 100, carbsG: 100, fatG: 100, confidence: 'HIGH', uncertainty: null }], warnings: [] }),
    'inconsistent macros (900 kcal from 1 g)': JSON.stringify({ items: [{ name: 'Air', role: 'MAIN', preparation: null, portion: null, notVisible: false, kcal: 900, proteinG: 1, carbsG: 0, fatG: 0, confidence: 'HIGH', uncertainty: null }], warnings: [] }),
  };
  for (const [name, text] of Object.entries(bad)) it('rejects: ' + name + ' -> 502 INVALID_RESPONSE, nothing cached, spend still counted', async () => {
    const c = H.setup({ script: () => H.openaiOk(text) });
    const r = await run(c, H.analyzeReq({ bodyObj: { requestId: 'req-bad-1' } }));
    assert.equal(r.status, 502); assert.equal(codeOf(r), 'INVALID_RESPONSE');
    assert.equal([...c.store.m.keys()].filter((k) => k.startsWith('idem/')).length, 0);
    const led = c.store.m.get('ledger/v1').data;
    assert.ok(led.total.usd > 0 && Object.keys(led.inflight).length === 0);
  });
  it('refusal, incomplete status, missing output text, non-JSON provider body -> INVALID_RESPONSE', async () => {
    for (const body of [
      { status: 'completed', output: [{ type: 'message', content: [{ type: 'refusal', refusal: 'no' }] }], usage: { input_tokens: 10, output_tokens: 5 } },
      { status: 'incomplete', incomplete_details: { reason: 'max_output_tokens' }, output: [], usage: { input_tokens: 10, output_tokens: 3000 } },
      { status: 'completed', output: [{ type: 'reasoning' }], usage: { input_tokens: 10, output_tokens: 5 } },
    ]) {
      const c = H.setup({ script: () => ({ status: 200, body }) });
      const r = await run(c, H.analyzeReq());
      assert.equal(r.status, 502); assert.equal(codeOf(r), 'INVALID_RESPONSE');
    }
    const c2 = H.setup({ script: () => ({ status: 200, body: '<html>oops</html>' }) });
    assert.equal(codeOf(await run(c2, H.analyzeReq())), 'INVALID_RESPONSE');
  });
});

describe('P9 provider failures', () => {
  it('provider 500 -> 502 PROVIDER_ERROR, not billed, call not counted, retry with the same id works', async () => {
    let n = 0;
    const c = H.setup({ script: () => (++n === 1 ? { status: 500, body: { error: { message: 'boom SECRET-PROVIDER-TEXT' } } } : H.openaiOk()) });
    const r = await run(c, H.analyzeReq({ bodyObj: { requestId: 'req-retry-1' } }));
    assert.equal(r.status, 502); assert.equal(codeOf(r), 'PROVIDER_ERROR'); assert.equal(JSON.stringify(r.body).includes('SECRET-PROVIDER'), false);
    const led = c.store.m.get('ledger/v1').data;
    assert.equal(led.total.usd, 0); assert.equal(led.day.calls, 0);
    const r2 = await run(c, H.analyzeReq({ bodyObj: { requestId: 'req-retry-1' } }));
    assert.equal(r2.status, 200);
  });
  it('provider 429 rate limit -> 429 RATE_LIMIT; spend-limit/credit 429 -> 402 BUDGET_EXHAUSTED', async () => {
    let c = H.setup({ script: () => ({ status: 429, body: { error: { code: 'rate_limit_exceeded' } } }) });
    let r = await run(c, H.analyzeReq()); assert.equal(r.status, 429); assert.equal(codeOf(r), 'RATE_LIMIT');
    for (const code of ['project_spend_limit_exceeded', 'organization_spend_limit_exceeded', 'credit_balance_exhausted']) {
      c = H.setup({ script: () => ({ status: 429, body: { error: { code } } }) });
      r = await run(c, H.analyzeReq()); assert.equal(r.status, 402); assert.equal(codeOf(r), 'BUDGET_EXHAUSTED');
    }
  });
  it('provider 401 (bad server key) -> 502 PROVIDER_ERROR without leaking the key', async () => {
    const c = H.setup({ script: () => ({ status: 401, body: { error: { message: 'Incorrect API key provided: ' + H.FAKE_KEY } } }) });
    const r = await run(c, H.analyzeReq());
    assert.equal(r.status, 502); assert.equal(JSON.stringify(r.body).includes(H.FAKE_KEY), false);
    assert.equal(c.logs.join('\n').includes(H.FAKE_KEY), false);
  });
  it('network failure -> 502 PROVIDER_ERROR (not billed)', async () => {
    const c = H.setup();
    const bad = async () => { throw new TypeError('fetch failed'); };
    const h = (await import('../netlify/lib/handler.mjs')).createHandler({ env: c.env, fetch: bad, getStore: () => c.store, now: () => c.clock.t, log: () => {} });
    const r = await H.j(await h(H.analyzeReq(), { ip: '1.1.1.1' }));
    assert.equal(r.status, 502); assert.equal(c.store.m.get('ledger/v1').data.total.usd, 0);
  });
  it('provider timeout -> 504 TIMEOUT within the configured limit, and the reservation is charged (it may have been billed)', async () => {
    const c = H.setup({ env: { HYROX_PROVIDER_TIMEOUT_MS: '1000' }, script: () => 'hang' });
    const t0 = Date.now();
    const r = await run(c, H.analyzeReq());
    assert.equal(r.status, 504); assert.equal(codeOf(r), 'TIMEOUT');
    assert.ok(Date.now() - t0 < 3000);
    const led = c.store.m.get('ledger/v1').data;
    assert.equal(led.total.usd, 0.004); assert.equal(led.day.calls, 1); assert.deepEqual(led.inflight, {});
    assert.equal([...c.store.m.keys()].filter((k) => k.startsWith('idem/')).length, 0);
  });
  it('the timeout cannot be configured above the 45 s client timeout', () => {
    assert.equal(cfgMod.readConfig({ ...H.BASE_ENV, HYROX_PROVIDER_TIMEOUT_MS: '90000' }).config.timeoutMs, 42000);
  });
});

describe('P9 durable limits and budget', () => {
  it('cost is computed from reported tokens at the official per-token price', async () => {
    const c = H.setup();
    await run(c, H.analyzeReq());
    const led = c.store.m.get('ledger/v1').data;
    assert.equal(led.total.usd, Math.round((2700 * 0.10 + 900 * 0.50) / 1e6 * 1e6) / 1e6); // $0.00072
    assert.equal(led.month.usd, led.total.usd);
    assert.equal(oaMod.estimateCostUsd({ price: { in: 0.10, out: 0.50 } }, { input_tokens: 1000000, output_tokens: 1000000 }), 0.6);
  });
  it('daily call cap: the 3rd call on a day with cap 2 is refused with no provider call; next Qatar day resets', async () => {
    const c = H.setup({ env: { HYROX_DAILY_CALL_CAP: '2' } });
    assert.equal((await run(c, H.analyzeReq())).status, 200);
    assert.equal((await run(c, H.analyzeReq())).status, 200);
    const r = await run(c, H.analyzeReq());
    assert.equal(r.status, 429); assert.equal(codeOf(r), 'QUOTA_EXHAUSTED'); assert.equal(c.fetchStub.calls.length, 2);
    c.clock.t = Date.UTC(2026, 10, 16, 21, 30, 0); // 00:30 on 17 Nov in Qatar (UTC+3)
    assert.equal((await run(c, H.analyzeReq())).status, 200);
  });
  it('day rollover follows Asia/Qatar, not UTC', () => {
    assert.equal(cfgMod.dayKey(Date.UTC(2026, 10, 16, 20, 59, 59)), '2026-11-16');
    assert.equal(cfgMod.dayKey(Date.UTC(2026, 10, 16, 21, 0, 0)), '2026-11-17');
    assert.equal(cfgMod.monthKey(Date.UTC(2026, 10, 30, 21, 0, 0)), '2026-12');
  });
  it('monthly call cap and its rollover', async () => {
    const c = H.setup({ env: { HYROX_MONTHLY_CALL_CAP: '2', HYROX_DAILY_CALL_CAP: '50' } });
    await run(c, H.analyzeReq()); await run(c, H.analyzeReq());
    assert.equal(codeOf(await run(c, H.analyzeReq())), 'QUOTA_EXHAUSTED');
    c.clock.t = Date.UTC(2026, 11, 1, 6, 0, 0);
    assert.equal((await run(c, H.analyzeReq())).status, 200);
  });
  it('monthly USD cap: refuses when spend + reservation would pass it, before any provider call', async () => {
    const c = H.setup({ env: { HYROX_MONTHLY_USD_CAP: '0.01', HYROX_RESERVE_USD: '0.004' }, script: () => H.openaiOk(H.goodModelJson(), { input_tokens: 20000, output_tokens: 5000 }) }); // $0.0045 / call
    assert.equal((await run(c, H.analyzeReq())).status, 200);
    assert.equal((await run(c, H.analyzeReq())).status, 200);
    const r = await run(c, H.analyzeReq()); // 0.009 spent + 0.004 reserve > 0.01
    assert.equal(r.status, 402); assert.equal(codeOf(r), 'BUDGET_EXHAUSTED'); assert.equal(c.fetchStub.calls.length, 2);
    c.clock.t = Date.UTC(2026, 11, 2, 6, 0, 0); // next month: month resets
    assert.equal((await run(c, H.analyzeReq())).status, 200);
  });
  it('trial total cap ($5 default) is lifetime: it does not reset with the month', async () => {
    const c = H.setup({ env: { HYROX_TOTAL_USD_CAP: '0.01', HYROX_MONTHLY_USD_CAP: '3' }, script: () => H.openaiOk(H.goodModelJson(), { input_tokens: 20000, output_tokens: 5000 }) });
    await run(c, H.analyzeReq()); await run(c, H.analyzeReq());
    assert.equal(codeOf(await run(c, H.analyzeReq())), 'BUDGET_EXHAUSTED');
    c.clock.t = Date.UTC(2026, 11, 20, 6, 0, 0);
    assert.equal(codeOf(await run(c, H.analyzeReq())), 'BUDGET_EXHAUSTED');
  });
  it('rate limit: minimum gap and burst window', async () => {
    const c = H.setup({ env: { HYROX_MIN_GAP_SECONDS: '5', HYROX_BURST_CAP: '3', HYROX_DAILY_CALL_CAP: '50' } });
    assert.equal((await run(c, H.analyzeReq())).status, 200);
    c.clock.t += 2000;
    const gap = await run(c, H.analyzeReq()); assert.equal(gap.status, 429); assert.equal(codeOf(gap), 'RATE_LIMIT'); assert.ok(Number(gap.headers.get('retry-after')) >= 1);
    c.clock.t += 6000; assert.equal((await run(c, H.analyzeReq())).status, 200);
    c.clock.t += 6000; assert.equal((await run(c, H.analyzeReq())).status, 200);
    c.clock.t += 6000; assert.equal(codeOf(await run(c, H.analyzeReq())), 'RATE_LIMIT');
    c.clock.t += 11 * 60 * 1000; assert.equal((await run(c, H.analyzeReq())).status, 200);
    assert.equal(c.fetchStub.calls.length, 4);
  });
  it('concurrency: 12 parallel requests with a daily cap of 3 make exactly 3 provider calls (compare-and-set ledger)', async () => {
    const c = H.setup({ env: { HYROX_DAILY_CALL_CAP: '3', HYROX_BURST_CAP: '20' } });
    const rs = await Promise.all(Array.from({ length: 12 }, () => run(c, H.analyzeReq())));
    assert.equal(rs.filter((r) => r.status === 200).length, 3);
    assert.equal(c.fetchStub.calls.length, 3);
    assert.ok(rs.filter((r) => r.status !== 200).every((r) => ['QUOTA_EXHAUSTED', 'STORAGE_UNAVAILABLE', 'RATE_LIMIT'].includes(codeOf(r))));
  });
  it('a function that died mid-call: its stale reservation is charged, not forgotten', async () => {
    const c = H.setup();
    await run(c, H.analyzeReq());
    const led = c.store.m.get('ledger/v1');
    led.data.inflight['ghost'] = { at: c.clock.t, usd: 0.004 };
    const before = led.data.total.usd;
    c.clock.t += 200 * 1000;
    await run(c, H.analyzeReq());
    const after = c.store.m.get('ledger/v1').data;
    assert.ok(after.total.usd >= before + 0.004 && !after.inflight.ghost);
  });
  it('storage unavailable (Blobs down) -> 503 STORAGE_UNAVAILABLE, fail closed, no provider call', async () => {
    const c = H.setup();
    c.store.down = true;
    const r = await run(c, H.analyzeReq()); assert.equal(r.status, 503); assert.equal(codeOf(r), 'STORAGE_UNAVAILABLE');
    const s = await run(c, H.statusReq(H.OWNER_CODE)); assert.equal(s.status, 503);
    assert.equal(c.fetchStub.calls.length, 0);
  });
  it('Blobs failing only after the provider answered still returns the estimate; reservation stays to be charged', async () => {
    const c = H.setup();
    let n = 0;
    const orig = c.store.put;
    c.store.put = async (...a) => { if (++n > 4) throw new Error('late failure'); return orig.apply(c.store, a); };
    const r = await run(c, H.analyzeReq());
    assert.equal(r.status, 200);
  });
});

describe('P9 idempotency: retries cannot double-bill', () => {
  it('same request id + same photo: second call is a replay (no provider call, no extra charge, flagged header)', async () => {
    const c = H.setup();
    const req = { bodyObj: { requestId: 'req-idem-1' } };
    const a = await run(c, H.analyzeReq(req)); const spent = c.store.m.get('ledger/v1').data.total.usd;
    const b = await run(c, H.analyzeReq(req));
    assert.equal(a.status, 200); assert.equal(b.status, 200); assert.deepEqual(a.body, b.body);
    assert.equal(b.headers.get('x-hyrox-replay'), 'true');
    assert.equal(c.fetchStub.calls.length, 1); assert.equal(c.store.m.get('ledger/v1').data.total.usd, spent); assert.equal(c.store.m.get('ledger/v1').data.day.calls, 1);
  });
  it('same request id with a different photo is refused', async () => {
    const c = H.setup();
    await run(c, H.analyzeReq({ bodyObj: { requestId: 'req-idem-2' } }));
    const r = await run(c, H.analyzeReq({ bodyObj: { requestId: 'req-idem-2', imageBase64: H.jpegB64('p9-progressive.jpg') } }));
    assert.equal(r.status, 409); assert.equal(c.fetchStub.calls.length, 1);
  });
  it('simultaneous duplicate: one provider call, the other gets 409 IN_FLIGHT', async () => {
    let release; const gate = new Promise((res) => { release = res; });
    const c = H.setup({ script: async () => { await gate; return H.openaiOk(); } });
    const p1 = run(c, H.analyzeReq({ bodyObj: { requestId: 'req-idem-3' } }));
    await new Promise((r) => setTimeout(r, 30));
    const r2 = await run(c, H.analyzeReq({ bodyObj: { requestId: 'req-idem-3' } }));
    assert.equal(r2.status, 409); assert.equal(codeOf(r2), 'IN_FLIGHT');
    release(); const r1 = await p1;
    assert.equal(r1.status, 200); assert.equal(c.fetchStub.calls.length, 1);
  });
  it('cached estimates expire after 15 minutes and are purged; they hold no image data', async () => {
    const c = H.setup();
    await run(c, H.analyzeReq({ bodyObj: { requestId: 'req-idem-4' } }));
    const keys = () => [...c.store.m.keys()].filter((k) => k.startsWith('idem/'));
    assert.equal(keys().length, 1);
    const blob = JSON.stringify([...c.store.m.values()]);
    assert.equal(blob.includes(H.jpegB64().slice(100, 160)), false); assert.equal(blob.includes('imageBase64'), false);
    c.clock.t += 16 * 60 * 1000;
    await run(c, H.analyzeReq({ bodyObj: { requestId: 'req-idem-5' } }));
    assert.equal(c.store.m.has(keys().find((k) => true)) , true);
    assert.equal(keys().length, 1); // old one purged, new one present
    const again = await run(c, H.analyzeReq({ bodyObj: { requestId: 'req-idem-4' } }));
    assert.equal(again.headers.get('x-hyrox-replay'), null); // expired => a genuinely new analysis
  });
});

describe('P9 logging: no secrets, tokens, image bytes or meal text', () => {
  it('logs from success, validation, provider failure and auth failure contain none of them', async () => {
    const c = H.setup({ script: (call, n) => (n === 2 ? { status: 500, body: { error: { message: 'x ' + H.FAKE_KEY } } } : H.openaiOk()) });
    const origLog = console.log; const seen = []; console.log = (...a) => seen.push(a.join(' '));
    try {
      await run(c, H.analyzeReq({ bodyObj: { description: 'SECRET-MEAL-NOTE shawarma', requestId: 'req-log-1' } }));
      c.clock.t += 5000;
      await run(c, H.analyzeReq({ bodyObj: { description: 'SECRET-MEAL-NOTE 2', requestId: 'req-log-2' } }));
      await run(c, H.analyzeReq({ token: 'WRONG-TOKEN-VALUE' }));
      await run(c, H.analyzeReq({ body: '{broken' }));
      await run(c, H.statusReq(H.OWNER_CODE));
    } finally { console.log = origLog; }
    const all = c.logs.concat(seen).join('\n');
    assert.ok(c.logs.length >= 3);
    for (const s of [H.FAKE_KEY, H.OWNER_CODE, H.OWNER_HASH, 'WRONG-TOKEN-VALUE', 'SECRET-MEAL-NOTE', 'Grilled chicken', 'chicken', 'White rice', H.jpegB64().slice(200, 260), '/9j/']) assert.equal(all.includes(s), false, 'leaked: ' + s);
    for (const line of c.logs) assert.ok(JSON.parse(line).evt);
  });
});

describe('P9 image gate unit checks', () => {
  it('walks real JPEGs, strips APPn/COM, keeps decodable structure (Pillow-made baseline, progressive, EXIF-rotated)', () => {
    for (const f of ['p9-clean-square.jpg', 'p9-progressive.jpg', 'p9-portrait-exif6.jpg', 'synthetic-food-exif.jpg']) {
      const r = imgMod.checkImage({ imageBase64: H.jpegB64(f), mimeType: 'image/jpeg' }, 1_650_000);
      assert.equal(r.ok, true, f);
      assert.equal(r.bytes.includes(Buffer.from('SyntheticCam')), false);
      assert.equal(r.bytes.includes(Buffer.from('Exif')), false);
      assert.ok(r.width >= 8 && r.height >= 8);
    }
  });
  it('sniff recognises the formats we refuse', () => {
    assert.equal(imgMod.sniff(fs.readFileSync(H.FIX('synthetic-food-clean.png'))), 'png');
    assert.equal(imgMod.sniff(fs.readFileSync(H.FIX('p9-sample.webp'))), 'webp');
    assert.equal(imgMod.sniff(fs.readFileSync(H.FIX('p9-fake.heic'))), 'heif');
    assert.equal(imgMod.sniff(Buffer.from('xx')), 'unknown');
  });
  it('index/store basics: sha is stable; ledger snapshot caps reflect config', async () => {
    assert.equal(storeMod.sha('a'), storeMod.sha('a'));
    const snap = storeMod.snapshot({ total: { usd: 1, calls: 2 }, month: { usd: 0.5, calls: 1 }, day: { calls: 1 }, inflight: {} }, cfgMod.readConfig(H.BASE_ENV).config);
    assert.equal(snap.remainingUsd, 2.5);
  });
});
