'use strict';
// Phase 11.3 part 1: the larger free US food list (USDA FNDDS 2021-2023, CC0) as a separate static file next to the
// unchanged 8,167-food list; search, labels, provenance, servings. Synthetic data only; no network.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const zlib = require('node:zlib');
const crypto = require('node:crypto');
const { execFileSync } = require('node:child_process');
const S = require('../src/data/hyrox-foodsearch.js');
const C = require('../src/data/hyrox-foodcalc.js');
const HD = require('../src/data/hyrox-data.js');
const D = path.join(__dirname, '..', 'src', 'data');
const db = require('../src/data/food-db.json');
const us = require('../src/data/food-db-us.json');
const ix = S.buildIndex(db, C.ALIASES, us), ix0 = S.buildIndex(db, C.ALIASES);
const sha = (f) => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
const NOW = new Date('2026-11-19T09:00:00Z');
const mem = () => { const m = {}; return { getItem: (k) => (k in m ? m[k] : null), setItem(k, v) { m[k] = String(v); }, removeItem(k) { delete m[k]; } }; };

test('asset: FNDDS 2021-2023 (FDC 2024-10-31), CC0, source file pinned by sha256; counts; the original list is untouched', () => {
  const m = us.meta, s0 = m.sources[0];
  assert.equal(m.license, 'CC0 1.0 Universal (public domain)');
  assert.equal(s0.release, '2024-10-31'); assert.equal(s0.sha256, 'dfb06ae7ddc397ccd570b91c14b75438ab2ba39f64f22d321f61d4a52a77f3eb');
  assert.equal(s0.url, 'https://fdc.nal.usda.gov/fdc-datasets/FoodData_Central_survey_food_json_2024-10-31.zip');
  assert.equal(s0.foodsInSource, 5432); assert.equal(us.foods.length, 5431); assert.equal(m.foodCount, 5431);
  assert.deepEqual(s0.excluded.map((x) => x.description), ['Milk, human']); // USDA gives it no nutrient values; never filled in
  assert.equal(m.baseDb.sha256, sha(path.join(D, 'food-db.json'))); assert.equal(m.baseDb.foodCount, 8167); assert.equal(db.foods.length, 8167);
  assert.equal(sha(path.join(D, 'food-db.json')), 'a7071ae53480e97e3610c9f1180e73a2d04f4614d1c460a6a545f419ff8c65d3', 'food-db.json byte-identical to Phase 11.2');
  const js = fs.readFileSync(path.join(D, 'food-db-us.js'), 'utf8');
  assert.ok(/^\/\* GENERATED/.test(js) && js.indexOf(fs.readFileSync(path.join(D, 'food-db-us.json'), 'utf8').trim()) !== -1, '.js wraps the same JSON');
  assert.ok(/^[\x00-\x7f]*$/.test(js), 'ASCII only');
  const gz = zlib.gzipSync(fs.readFileSync(path.join(D, 'food-db-us.js')), { level: 9 }).length, gz0 = zlib.gzipSync(fs.readFileSync(path.join(D, 'food-db.js')), { level: 9 }).length;
  assert.ok(gz < 220000, 'food-db-us.js gzip ' + gz); assert.ok(gz + gz0 < 800000, 'all food assets under the 800 KB gzip budget: ' + (gz + gz0));
});
test('rows: real FDC ids (unique, never colliding with the original list), four macros, fiber/sodium null or >= 0, no Guideline-amount portions', () => {
  const ids = new Set(), base = new Set(db.foods.map((r) => r[1] + ':' + r[0]));
  us.foods.forEach((r) => {
    assert.equal(r[1], 'FN'); assert.ok(Number.isInteger(r[0]) && r[0] > 2700000 && r[0] < 2800000, 'FNDDS 2021-2023 fdcId ' + r[0]);
    assert.ok(!ids.has(r[0])); ids.add(r[0]); assert.ok(!base.has('FN:' + r[0]));
    [3, 4, 5, 6].forEach((j) => assert.equal(typeof r[j], 'number'));
    [8, 9].forEach((j) => assert.ok(r[j] === null || (typeof r[j] === 'number' && r[j] >= 0)));
    r[7].forEach((p) => { assert.ok(p[0] > 0 && p[2] > 0 && typeof p[1] === 'string'); assert.ok(!/^guideline amount/i.test(p[1])); });
  });
  const egg = us.foods.find((r) => r[2] === 'Egg, whole, boiled or poached');
  assert.deepEqual(egg.slice(0, 7), [2707154, 'FN', 'Egg, whole, boiled or poached', 143, 12.4, 0.96, 9.96]);
  assert.deepEqual(egg[7][0], [1, 'egg', 50]); assert.deepEqual(egg.slice(8), [0, 129]); // USDA 0 g fiber is a real 0
  const tuna = us.foods.find((r) => r[2] === 'Fish, tuna, canned');
  assert.ok(tuna[7].some((p) => p[1] === 'standard can' && p[2] === 115));
  assert.ok(tuna[7].some((p) => p[1] === 'serving (USDA default, quantity not specified)'));
});
test('fiber/sodium for the ORIGINAL foods come from the same USDA releases; coverage is partial and reported, never filled', () => {
  const cov = us.meta.sources[1].coverage, covF = us.meta.sources[2].coverage;
  assert.deepEqual(cov, { foodsInDb: 7793, withFiber: 7231, withSodium: 7709 });
  assert.deepEqual(covF, { foodsInDb: 374, withFiber: 201, withSodium: 355 });
  const egg = ix.foods[ix.byKey['SR:173424']]; // Egg, whole, cooked, hard-boiled
  assert.equal(egg.name, 'Egg, whole, cooked, hard-boiled'); assert.deepEqual(egg.fs, [0, 124]);
  const noFs = ix.foods.filter((f) => f.dataset !== 'FN' && !f.fs).length;
  assert.ok(noFs > 0, 'some original foods have no fiber/sodium at all (unknown)');
});
test('index: original 8,167 rows first and unchanged; FNDDS appended; without the file the index is the Phase 11.2 one', () => {
  assert.equal(ix.foods.length, 8167 + 5431); assert.equal(ix.baseCount, 8167); assert.equal(ix.usCount, 5431);
  assert.equal(ix0.foods.length, 8167); assert.equal(ix0.usCount, 0);
  for (let i = 0; i < 8167; i++) { assert.equal(ix.foods[i].key, ix0.foods[i].key); assert.deepEqual(ix.foods[i].per100, ix0.foods[i].per100); }
  assert.deepEqual(S.search(ix0, 'banana').results.map((r) => r.key), S.search(S.buildIndex(db, C.ALIASES, null), 'banana').results.map((r) => r.key));
  const t = Date.now(); S.buildIndex(db, C.ALIASES, us); assert.ok(Date.now() - t < 2000, 'build time');
});
const top = (q, n) => S.search(ix, q).results.slice(0, n || 3).map((r) => r.name);
test('common American foods (typed with counts/units: never sets the quantity, only finds the food)', () => {
  assert.deepEqual(top('4 boiled eggs', 2), ['Egg, whole, cooked, hard-boiled', 'Egg, whole, boiled or poached']);
  assert.ok(top('1 can tuna', 1)[0].startsWith('Fish, tuna, light, canned in water'));
  assert.ok(S.search(ix, '1 can tuna').results.some((r) => r.name === 'Fish, tuna, canned'));
  assert.ok(/^Chicken, broilers or fryers, breast/.test(top('chicken breast 200g', 1)[0]));
  assert.equal(top('pancakes', 1)[0], 'Pancakes, NFS');
  assert.equal(top('grilled cheese', 1)[0], 'Grilled cheese sandwich, NFS');
  assert.equal(top('hot dog', 1)[0], 'Hot dog, NFS');
  assert.equal(top('burrito', 1)[0], 'Burrito, NFS');
  assert.equal(top('peanut butter jelly sandwich', 1)[0], 'Peanut butter and jelly sandwich, NFS');
  assert.equal(top('banana', 1)[0], 'Bananas, raw');
  // before / after: more choices, the original top results still there
  for (const q of ['turkey sandwich', 'chicken nuggets', 'mac and cheese', 'pizza']) assert.ok(S.search(ix, q).count > S.search(ix0, q).count, q);
  const r = S.search(ix, '4 boiled eggs').results[0]; assert.equal(r.qty, undefined); assert.equal(r.quantity, undefined);
});
test('restaurant labels: chain items are USDA estimates (SR 2018 or FNDDS survey), generic restaurant-style items are labelled apart; ordinary foods carry none', () => {
  const bm = S.search(ix, 'big mac').results;
  const fn = bm.find((r) => r.name === 'Big Mac (McDonalds)'), sr = bm.find((r) => r.name === "McDONALD'S, BIG MAC");
  assert.equal(fn.restaurantKind, 'CHAIN'); assert.equal(fn.restaurantBadge, 'Chain item · USDA survey estimate (US)'); assert.equal(fn.sourceLabel, 'USDA FNDDS 2021-2023 (survey)');
  assert.equal(sr.restaurantKind, 'CHAIN'); assert.equal(sr.restaurantBadge, 'Restaurant · US 2018');
  const nug = S.search(ix, 'chicken nuggets').results.find((r) => r.name === 'Chicken nuggets, from fast food');
  assert.equal(nug.restaurantKind, 'GENERIC'); assert.equal(nug.restaurantBadge, 'Restaurant-style · generic USDA'); assert.equal(nug.restaurant, false);
  assert.equal(S.search(ix, 'banana').results[0].restaurantBadge, null);
  // no "official" anywhere in the data
  assert.ok(!/official/i.test(JSON.stringify(us.foods)));
});
test('duplicate policy: identical descriptions across datasets are kept apart and labelled (never merged)', () => {
  assert.equal(us.meta.duplicateDescriptions, 105);
  const r = S.search(ix, 'cream heavy').results.filter((x) => x.name.toLowerCase() === 'cream, heavy');
  assert.deepEqual(r.map((x) => x.sourceLabel).sort(), ['USDA FNDDS 2021-2023 (survey)', 'USDA Foundation Foods (2026)']);
});
test('FNDDS component: real fdcId + FN provenance + FNDDS dbVersion; serving x quantity scales macros, fiber and sodium', () => {
  const sv = S.servingsFor(ix, 'FN:2707154').find((s) => s.label === '1 egg');
  assert.ok(sv.isDefault);
  const c = S.usdaComponent(ix, 'FN:2707154', sv, 4).component;
  assert.equal(c.portion, '4 × 1 egg (200 g)');
  assert.deepEqual([c.kcal.value, c.proteinG.value, c.fiberG, c.sodiumMg], [286, 24.8, { value: 0, state: 'ESTIMATED' }, { value: 258, state: 'ESTIMATED' }]);
  assert.deepEqual(c.provenance, { source: 'USDA_FDC', dataset: 'FN', fdcId: 2707154, description: 'Egg, whole, boiled or poached', portion: '4 × 1 egg (200 g)', grams: 200, dbVersion: us.meta.dbVersion });
  assert.ok(us.meta.dbVersion.length <= 80);
  const st = HD.createStore(mem(), { now: () => NOW });
  const r = st.putRecord('meals', { date: '2026-11-19', time: '08:00', label: 'Breakfast', source: 'MANUAL', description: '', eatenFraction: 1, lifecycle: 'CONFIRMED', confirmedAt: NOW.toISOString(), ai: null, mealCategory: 'BREAKFAST', components: [c] });
  assert.equal(r.ok, true, JSON.stringify(r.errors));
  const tuna = S.usdaComponent(ix, 'FN:2706311', S.servingsFor(ix, 'FN:2706311').find((s) => s.label === '1 standard can'), 1).component;
  assert.deepEqual([tuna.kcal.value, tuna.proteinG.value, tuna.sodiumMg.value], [98, 21.9, 252]);
});
test('reproducible: rebuilding from the pinned USDA zips gives byte-identical files (skipped only when the raw zips are not on this machine)', (t) => {
  const fn = process.env.P113_FNDDS_DIR || '/workspace/p11-3-usda', src = process.env.P113_USDA_SRC || '/workspace/hyrox-p6/food-data-feasibility';
  if (!fs.existsSync(path.join(fn, 'FoodData_Central_survey_food_json_2024-10-31.zip')) || !fs.existsSync(path.join(src, 'FoodData_Central_sr_legacy_food_csv_2018-04.zip'))) { t.skip('raw USDA zips not present'); return; }
  const out = fs.mkdtempSync(path.join(require('node:os').tmpdir(), 'fdb-us-'));
  execFileSync('python3', [path.join(__dirname, '..', 'tools', 'food-db', 'build_food_db_us.py'), '--fndds', fn, '--src', src, '--out', out]);
  for (const f of ['food-db-us.json', 'food-db-us.js']) assert.equal(sha(path.join(out, f)), sha(path.join(D, f)), f);
});
test('the search module still has no storage or network calls', () => {
  const code = fs.readFileSync(path.join(D, 'hyrox-foodsearch.js'), 'utf8').replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, '');
  assert.ok(!/localStorage|fetch\(|XMLHttpRequest|sendBeacon|WebSocket|importScripts/.test(code));
});

test('a chain dish lists the portion that names it first (Big Mac -> "McDonald\'s Big Mac" 205 g, not the Mac Jr); counts recorded in meta', () => {
  const us = require('../src/data/food-db-us.json');
  const bm = us.foods.find((r) => r[0] === 2706916);
  assert.deepEqual(bm[7][0], [1, "McDonald's Big Mac", 205]);
  assert.equal(bm[7].length, 4);
  assert.equal(JSON.stringify(us.meta).includes('"chainDishNamedPortionFirst":7'), true);
});
