'use strict';
// Plan v2.1, nutrition day states, readiness/steps rules.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const HP = require(path.resolve(__dirname, '../src/data/hyrox-plan.js'));
const HN = require(path.resolve(__dirname, '../src/data/hyrox-nutrition.js'));
const HW = require(path.resolve(__dirname, '../src/data/hyrox-wellness.js'));

describe('training plan v2.1', () => {
  it('has exactly 20 Mon–Fri slots from 16 Nov to 11 Dec 2026 (Phase 8 anchor)', () => {
    assert.equal(HP.SLOTS.length, 20);
    assert.equal(HP.SLOTS[0].date, '2026-11-16'); assert.equal(HP.SLOTS[0].type, 'STRENGTH_A');
    assert.equal(HP.SLOTS[19].date, '2026-12-11'); assert.equal(HP.SLOTS[19].type, 'RACE');
    const days = HP.SLOTS.map((s) => new Date(s.date + 'T00:00:00Z').getUTCDay());
    assert.ok(days.every((d) => d >= 1 && d <= 5));
  });
  it('two strength and three HYROX days per week', () => {
    const w1 = HP.SLOTS.filter((s) => s.week === 1).map((s) => s.type);
    assert.deepEqual(w1, ['STRENGTH_A', 'INTERVALS', 'STRENGTH_B', 'AEROBIC', 'RACE']);
  });
  it('week-specific prescriptions are source-faithful', () => {
    assert.match(HP.slotById('v2.1-W1-MON').prescription.join(' '), /2x5 @ RPE 6–7/);
    assert.match(HP.slotById('v2.1-W3-TUE').prescription.join(' '), /4 rounds: 500 m/);
    assert.match(HP.slotById('v2.1-W1-THU').prescription.join(' '), /7x \(1 min jog/);
    assert.match(HP.slotById('v2.1-W4-FRI').prescription.join(' '), /repeat W2 exactly/);
    assert.equal(HP.slotById('v2.1-W2-FRI').benchmark, 1); assert.equal(HP.slotById('v2.1-W4-FRI').benchmark, 2);
  });
  it('templates never invent loads or times', () => {
    HP.SLOTS.forEach((s) => HP.templateBlocks(s.type, s.week).forEach((b) => {
      assert.equal(b.loadKg, undefined); assert.equal(b.durationSec, undefined);
    }));
  });
  it('block status: Day 0, weeks, and exact text after 13 Dec', () => {
    assert.equal(HP.blockStatus('2026-11-18').week, 1);
    assert.equal(HP.blockStatus('2026-12-13').week, 4);
    assert.equal(HP.blockStatus('2026-12-14').text, 'No current approved training block');
    assert.equal(HP.blockStatus('2026-11-15').week, 0);
  });
  it('silence never becomes SKIPPED', () => {
    assert.equal(HP.slotStatus('v2.1-W1-MON', [], []).code, 'NOT_LOGGED');
    assert.equal(HP.summary([], []).SKIPPED, 0);
    assert.equal(HP.summary([], []).NOT_LOGGED, 20);
  });
  it('missed Monday cascade: strength moves to Tue, intervals to Thu, aerobic source-omitted', () => {
    const ev = [{ kind: 'MISSED_MONDAY', week: 1 }];
    const e = HP.effectiveWeek(1, ev);
    assert.equal(e.days[0].show.length, 0);
    assert.equal(e.days[1].show[0].slot.id, 'v2.1-W1-MON');
    assert.equal(e.days[3].show[0].slot.id, 'v2.1-W1-TUE');
    assert.equal(e.days[3].omitted[0].reason, 'MISSED_MONDAY_CASCADE');
    assert.equal(HP.slotStatus('v2.1-W1-THU', [], ev).code, 'SOURCE_OMITTED');
    const sum = HP.summary([], ev);
    assert.equal(sum.SOURCE_OMITTED, 1); assert.equal(sum.SKIPPED, 0); assert.equal(sum.denominator, 20);
  });
  it('missed Wednesday cascade', () => {
    const e = HP.effectiveWeek(2, [{ kind: 'MISSED_WEDNESDAY', week: 2 }]);
    assert.equal(e.days[3].show[0].slot.id, 'v2.1-W2-WED');
    assert.equal(e.days[3].omitted[0].reason, 'MISSED_WEDNESDAY_CASCADE');
  });
  it('both missed stays unresolved; nothing invented', () => {
    const e = HP.effectiveWeek(1, [{ kind: 'MISSED_MONDAY', week: 1 }, { kind: 'MISSED_WEDNESDAY', week: 1 }]);
    assert.ok(e.unresolved);
    assert.ok(e.days.every((d) => d.omitted.length === 0 && d.show.length === 1 && d.show[0].movedFrom === null));
  });
  it('machine compliance literals; 900 within, 960 overrun, never clipped', () => {
    assert.equal(HP.machineCompliance({ kind: 'skierg', durationSec: 900 }), 'WITHIN_LIMIT');
    const b = { kind: 'row', durationSec: 960 };
    assert.equal(HP.machineCompliance(b), 'OVERRUN'); assert.equal(b.durationSec, 960);
    assert.equal(HP.machineCompliance({ kind: 'bike' }), 'UNVERIFIED');
    assert.equal(HP.machineCompliance({ kind: 'row', durationSec: 960, claimWithinLimit: true }), 'CONFLICT');
    assert.equal(HP.machineCompliance({ kind: 'lunges', durationSec: 2000 }), null);
    assert.equal(HP.machineCompliance({ kind: 'run', machine: true, durationSec: 901 }), 'OVERRUN');
  });
  it('benchmarks comparable only when completed, unmodified, original variant', () => {
    const s = [{ planSlotId: 'v2.1-W2-FRI', status: 'COMPLETED', modified: true, variant: 'ORIGINAL_60', durationMin: 40, createdAt: 'a' }];
    const b = HP.benchmarks(s);
    assert.equal(b[0].comparable, false); assert.equal(b[1].status, 'NOT_LOGGED');
  });
  it('fallback variants are counted separately', () => {
    const s = [{ planSlotId: 'v2.1-W1-MON', status: 'COMPLETED', modified: false, variant: 'SOURCE_25_MIN', createdAt: 'a' }];
    const sum = HP.summary(s, []);
    assert.equal(sum.COMPLETED, 1); assert.equal(sum.fallback, 1);
  });
});

const U = HN.unknown();
const K = (v) => ({ value: v, state: 'KNOWN' });
const E = (v) => ({ value: v, state: 'ESTIMATED' });
function m(id, lifecycle, comps, extra) {
  return Object.assign({ id, date: '2026-11-18', lifecycle, updatedAt: '2026-11-18T08:00:00Z', components: comps }, extra || {});
}

describe('nutrition semantics', () => {
  it('UNKNOWN is null, true zero is 0', () => {
    const t = HN.mealTotals(m('a', 'CONFIRMED', [{ name: 'water', kcal: K(0), proteinG: K(0), carbsG: K(0), fatG: K(0) }, { name: 'sauce', kcal: U, proteinG: U, carbsG: U, fatG: U }]));
    assert.equal(t.kcal.value, 0); assert.equal(t.kcal.state, 'PARTIAL');
    const t2 = HN.mealTotals(m('b', 'CONFIRMED', [{ name: 'x', kcal: U, proteinG: U, carbsG: U, fatG: U }]));
    assert.equal(t2.kcal.value, null); assert.equal(t2.kcal.state, 'UNKNOWN');
  });
  it('eaten fraction scales; estimated propagates', () => {
    const t = HN.mealTotals(m('a', 'CONFIRMED', [{ name: 'rice', eatenFraction: 0.5, kcal: E(400), proteinG: K(10), carbsG: K(80), fatG: K(2) }]));
    assert.equal(t.kcal.value, 200); assert.equal(t.kcal.state, 'ESTIMATED'); assert.equal(t.proteinG.state, 'KNOWN');
  });
  it('D1 with no meals; drafts and consumed-intent are not counted', () => {
    assert.equal(HN.dayState('2026-11-18', [], null).code, 'D1');
    const ds = HN.dayState('2026-11-18', [m('d', 'DRAFT', [{ name: 'x', kcal: K(500), proteinG: U, carbsG: U, fatG: U }]),
      m('i', 'CONSUMED_INTENT', [{ name: 'y', kcal: K(300), proteinG: U, carbsG: U, fatG: U }])], null);
    assert.equal(ds.code, 'D2'); assert.equal(ds.subtotal.kcal.value, null); assert.equal(ds.pendingCount, 1);
  });
  it('D5 needs valid COMPLETE attestation, no pending, all kcal known and > 0', () => {
    const meals = [m('a', 'CONFIRMED', [{ name: 'oats', kcal: K(350), proteinG: K(12), carbsG: U, fatG: U }])];
    const pre = HN.dayState('2026-11-18', meals, null);
    assert.equal(pre.code, 'D2');
    const att = { attestation: 'COMPLETE', basis: pre.basis };
    assert.equal(HN.dayState('2026-11-18', meals, att).code, 'D5');
  });
  it('D4 when complete but kcal unknown somewhere; water-only zero day is not D5', () => {
    const meals = [m('a', 'CONFIRMED', [{ name: 'curry', kcal: U, proteinG: U, carbsG: U, fatG: U }])];
    const b = HN.dayState('2026-11-18', meals, null).basis;
    assert.equal(HN.dayState('2026-11-18', meals, { attestation: 'COMPLETE', basis: b }).code, 'D4');
    const water = [m('w', 'CONFIRMED', [{ name: 'water', kcal: K(0), proteinG: K(0), carbsG: K(0), fatG: K(0) }])];
    const bw = HN.dayState('2026-11-18', water, null).basis;
    assert.equal(HN.dayState('2026-11-18', water, { attestation: 'COMPLETE', basis: bw }).code, 'D4');
  });
  it('D3 for declared incomplete', () => {
    const meals = [m('a', 'CONFIRMED', [{ name: 'oats', kcal: K(350), proteinG: U, carbsG: U, fatG: U }])];
    const b = HN.dayState('2026-11-18', meals, null).basis;
    assert.equal(HN.dayState('2026-11-18', meals, { attestation: 'INCOMPLETE', basis: b }).code, 'D3');
  });
  it('editing, deleting, redating or consumed-intent change invalidates a complete day', () => {
    const meals = [m('a', 'CONFIRMED', [{ name: 'oats', kcal: K(350), proteinG: U, carbsG: U, fatG: U }])];
    const att = { attestation: 'COMPLETE', basis: HN.dayState('2026-11-18', meals, null).basis };
    const edited = [m('a', 'CONFIRMED', [{ name: 'oats', kcal: K(400), proteinG: U, carbsG: U, fatG: U }], { updatedAt: '2026-11-18T09:00:00Z' })];
    const s1 = HN.dayState('2026-11-18', edited, att); assert.equal(s1.code, 'D2'); assert.equal(s1.staleAttestation, true);
    assert.equal(HN.dayState('2026-11-18', [], att).staleAttestation, true);
    const pending = meals.concat([m('b', 'CONSUMED_INTENT', [{ name: 'snack', kcal: U, proteinG: U, carbsG: U, fatG: U }])]);
    const s3 = HN.dayState('2026-11-18', pending, att); assert.notEqual(s3.code, 'D5');
    assert.equal(HN.canAttest(s3).ok, false);
  });
  it('legacy entries map to confirmed with carbs/fat UNKNOWN', () => {
    const lm = HN.legacyToMeal({ id: 'n1', date: '2026-11-17', createdAt: '2026-11-17T08:00:00Z', label: 'Oats', calories: 350, proteinG: 22.5 });
    assert.equal(lm.lifecycle, 'CONFIRMED'); assert.equal(lm.components[0].carbsG.value, null);
    assert.equal(HN.completeness(lm), 'CONFIRMED_INCOMPLETE');
  });
  it('partial-day subtotal is labelled, never full-day', () => {
    const meals = [m('a', 'CONFIRMED', [{ name: 'oats', kcal: K(350), proteinG: U, carbsG: U, fatG: U }])];
    const s = HN.dayState('2026-11-18', meals, null);
    assert.equal(s.fullDay, false); assert.match(s.caveat, /Not a full-day total/);
  });
});

describe('readiness and steps', () => {
  const O = (v) => ({ state: 'OBSERVED', value: v });
  it('missing data is reported, never assumed safe', () => {
    const r = HW.readiness('2026-11-18', []);
    assert.equal(r.flags.length, 0); assert.ok(r.missing.includes('sleep')); assert.match(r.guidance, /cannot be confirmed/);
  });
  it('one flag -> 20–30% guidance; two flags -> easy movement only', () => {
    assert.match(HW.readiness('2026-11-18', [{ date: '2026-11-18', sleepH: O(5.5) }]).guidance, /20–30%/);
    assert.match(HW.readiness('2026-11-18', [{ date: '2026-11-18', sleepH: O(5.5), soreness: O(7) }]).guidance, /easy movement only/);
  });
  it('RHR flag only with a valid baseline (>=4 readings in prior 7 days)', () => {
    const d = [{ date: '2026-11-18', rhr: O(62) }, { date: '2026-11-15', rhr: O(54) }, { date: '2026-11-16', rhr: O(55) }, { date: '2026-11-17', rhr: O(55) }];
    let r = HW.readiness('2026-11-18', d);
    assert.equal(r.baseline.valid, false); assert.equal(r.flags.length, 0);
    d.push({ date: '2026-11-14', rhr: O(56) });
    r = HW.readiness('2026-11-18', d);
    assert.equal(r.baseline.valid, true); assert.equal(r.flags.length, 1);
  });
  it('canonical steps are the declared daily total only (walk steps not added)', () => {
    assert.equal(HW.canonicalSteps('2026-11-18', [{ date: '2026-11-18', steps: O(8000) }]).value, 8000);
    assert.equal(HW.canonicalSteps('2026-11-18', [{ date: '2026-11-18', steps: { state: 'MISSING', value: null } }]).value, null);
  });
  it('series drops non-observations', () => {
    const s = HW.series([{ date: '2026-11-09', v: 2 }, { date: '2026-11-08', v: null }, { date: '2026-11-08', v: 1 }], (r) => r.v);
    assert.deepEqual(s.map((p) => p.value), [1, 2]);
  });
});
