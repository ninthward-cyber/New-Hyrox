'use strict';
// P1.3 Delivery B: Nutrition Coach profile, goals and confirmed targets (src/data/hyrox-coach.js) and their storage in the
// shared owner-settings record through the UNCHANGED data layer, including older data layers kept for rollback.
// Synthetic data only. No network.
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const ROOT = path.join(__dirname, '..');
const HC = require(path.join(ROOT, 'src', 'data', 'hyrox-coach.js'));
const HD = require(path.join(ROOT, 'src', 'data', 'hyrox-data.js'));
const HN = require(path.join(ROOT, 'src', 'data', 'hyrox-nutrition.js'));
const HB = require(path.join(ROOT, 'src', 'data', 'hyrox-blocks.js'));
const NOW = new Date('2026-11-23T09:00:00.000Z'); // Mon 23 Nov 2026, 12:00 Asia/Qatar
const TD = '2026-11-23';
function mem() { const m = {}; return { getItem: (k) => (Object.prototype.hasOwnProperty.call(m, k) ? m[k] : null), setItem: (k, v) => { m[k] = String(v); }, _m: m }; }
const SYN_PROFILE = { heightCm: 180, heightUnit: 'cm', ageYears: 40, ageEnteredOn: '2026-11-01', ageConfirmedOn: '2026-11-01', estimateMethod: 'EQUATION', sexForEquation: 'MALE', activity: 'A2' };
const coachWith = (extra) => Object.assign(HC.emptyCoach(), { enabled: true, profile: Object.assign({}, SYN_PROFILE) }, extra || {});
const OTHER = { id: 'app-settings', date: '2026-11-11', createdAt: '2026-11-01T06:00:00.000Z', rhrBaselineBpm: 61, rhrBaselineSource: 'OWNER_SET', stepBaselineMode: 'AUTO', weightUnit: 'lb',
  myFoods: [{ id: 'mf1', name: 'Synthetic oats', kcal: 150 }], favFoods: ['SR:1001'], planBlocks: [{ id: 'syn-block', state: 'DRAFT' }], futureField: { a: [1, 2] } };

test('P1.3 B: an empty coach validates; wrong types, NaN, unknown goals and bad dates are refused', () => {
  assert.deepStrictEqual(HC.validateCoach(HC.emptyCoach()), []);
  assert.deepStrictEqual(HC.validateCoach(coachWith({ goal: { id: 'LOSE_1', setAt: TD } })), []);
  for (const bad of [null, [], 'x', Object.assign(HC.emptyCoach(), { schema: 2 }), Object.assign(HC.emptyCoach(), { enabled: 'yes' }),
    coachWith({ profile: Object.assign({}, SYN_PROFILE, { heightCm: NaN }) }), coachWith({ profile: Object.assign({}, SYN_PROFILE, { heightCm: 99 }) }),
    coachWith({ profile: Object.assign({}, SYN_PROFILE, { ageYears: 17 }) }), coachWith({ profile: Object.assign({}, SYN_PROFILE, { ageYears: 40.5 }) }),
    coachWith({ profile: Object.assign({}, SYN_PROFILE, { sexForEquation: 'X' }) }), coachWith({ profile: Object.assign({}, SYN_PROFILE, { activity: 'A9' }) }),
    coachWith({ goal: { id: 'LOSE_3', setAt: TD } }), coachWith({ goal: { id: 'LOSE_1', setAt: '2026-02-30' } }),
    coachWith({ target: { kcal: 2000, proteinG: 300, fatG: 100, carbsG: 100, origin: 'OWNER_ENTERED', effectiveDate: TD, confirmedAt: NOW.toISOString() } })]) {
    assert.ok(HC.validateCoach(bad).length > 0, JSON.stringify(bad));
  }
});

test('P1.3 B: height in cm or ft/in is stored once, canonically in cm; out-of-range and non-numbers are refused; nothing is guessed', () => {
  assert.strictEqual(HC.ftInToCm(5, 10), 177.8);
  assert.strictEqual(HC.ftInToCm(6, 0), 182.9);
  assert.deepStrictEqual(HC.cmToFtIn(177.8), { ft: 5, inch: 10 });
  const a = HC.parseProfile({ heightUnit: 'ftin', heightFt: '5', heightIn: '10', ageYears: '', estimateMethod: 'NONE', activity: '' }, TD, null);
  const b = HC.parseProfile({ heightUnit: 'cm', heightCm: '177.8', ageYears: '', estimateMethod: 'NONE', activity: '' }, TD, null);
  assert.strictEqual(a.ok, true); assert.strictEqual(a.profile.heightCm, b.profile.heightCm);
  assert.strictEqual(a.profile.ageYears, null); assert.strictEqual(a.profile.sexForEquation, null); assert.strictEqual(a.profile.activity, null);
  for (const bad of [{ heightCm: '99' }, { heightCm: '251' }, { heightCm: 'abc' }, { heightCm: '1e3' }]) assert.strictEqual(HC.parseProfile(Object.assign({ heightUnit: 'cm', estimateMethod: 'NONE' }, bad), TD, null).ok, false, JSON.stringify(bad));
  assert.strictEqual(HC.parseProfile({ heightUnit: 'ftin', heightFt: '5.5', heightIn: '0', estimateMethod: 'NONE' }, TD, null).ok, false);
  assert.strictEqual(HC.parseProfile({ heightUnit: 'ftin', heightFt: '5', heightIn: '12', estimateMethod: 'NONE' }, TD, null).ok, false);
});

test('P1.3 B: sex is asked and kept ONLY for the equation-based estimate, never defaulted', () => {
  const eq = HC.parseProfile({ heightUnit: 'cm', heightCm: '180', ageYears: '40', estimateMethod: 'EQUATION', sexForEquation: 'FEMALE', activity: 'A1' }, TD, null);
  assert.strictEqual(eq.profile.sexForEquation, 'FEMALE');
  const none = HC.parseProfile({ heightUnit: 'cm', heightCm: '180', ageYears: '40', estimateMethod: 'NONE', sexForEquation: 'FEMALE', activity: 'A1' }, TD, null);
  assert.strictEqual(none.profile.sexForEquation, null, 'dropped when the equation is not used');
  const noSex = HC.parseProfile({ heightUnit: 'cm', heightCm: '180', ageYears: '40', estimateMethod: 'EQUATION', activity: 'A1' }, TD, null);
  assert.strictEqual(noSex.ok, true); assert.strictEqual(noSex.profile.sexForEquation, null, 'no default sex');
});

test('P1.3 B: age in whole years, no birth date; never advanced automatically; yearly confirmation is asked', () => {
  const p1 = HC.parseProfile({ heightUnit: 'cm', heightCm: '180', ageYears: '40', estimateMethod: 'NONE' }, '2026-01-10', null).profile;
  assert.deepStrictEqual([p1.ageYears, p1.ageEnteredOn, p1.ageConfirmedOn], [40, '2026-01-10', '2026-01-10']);
  assert.strictEqual(Object.keys(p1).some((k) => /birth|dob/i.test(k)), false);
  assert.strictEqual(HC.ageStatus(p1, '2027-01-09').needsConfirm, false);
  const due = HC.ageStatus(p1, '2027-01-10');
  assert.strictEqual(due.needsConfirm, true); assert.strictEqual(due.years, 40, 'never inferred to be 41');
  const same = HC.parseProfile({ heightUnit: 'cm', heightCm: '180', ageYears: '40', estimateMethod: 'NONE' }, '2027-01-11', p1).profile;
  assert.strictEqual(same.ageConfirmedOn, '2026-01-10', 'saving other fields does not count as a confirmation');
  const conf = HC.parseProfile({ heightUnit: 'cm', heightCm: '180', ageYears: '40', estimateMethod: 'NONE', confirmAge: true }, '2027-01-11', p1).profile;
  assert.deepStrictEqual([conf.ageEnteredOn, conf.ageConfirmedOn], ['2026-01-10', '2027-01-11']);
  const upd = HC.parseProfile({ heightUnit: 'cm', heightCm: '180', ageYears: '41', estimateMethod: 'NONE' }, '2027-01-11', p1).profile;
  assert.deepStrictEqual([upd.ageYears, upd.ageEnteredOn, upd.ageConfirmedOn], [41, '2027-01-11', '2027-01-11']);
  for (const bad of ['17', '101', '40.5', 'forty', '-3']) assert.strictEqual(HC.parseProfile({ heightUnit: 'cm', ageYears: bad, estimateMethod: 'NONE' }, TD, null).ok, false, bad);
});

test('P1.3 B: four goals exactly; 1 lb/week recommended; 2 lb/week visible but gated', () => {
  assert.deepStrictEqual(HC.GOALS.map((g) => [g.id, g.lbPerWeek]), [['LOSE_1', -1], ['LOSE_2', -2], ['MAINTAIN', 0], ['GAIN_1', 1]]);
  assert.match(HC.goalById('LOSE_1').note, /Recommended/);
  assert.match(HC.goalById('LOSE_2').note, /gated/);
});

test('P1.3 B: owner-entered targets — consistent ones are accepted with warnings; impossible macro sums and bad numbers are refused', () => {
  const ok = HC.checkOwnerTarget({ kcal: '2200', proteinG: '190', fatG: '60', carbsG: '' }, { restingKcal: 1800, sex: 'MALE', currentKcal: 2400 });
  assert.strictEqual(ok.ok, true); assert.deepStrictEqual(ok.warnings, []);
  assert.deepStrictEqual(ok.target, { kcal: 2200, proteinG: 190, fatG: 60, carbsG: null });
  const imp = HC.checkOwnerTarget({ kcal: '1500', proteinG: '250', fatG: '80', carbsG: '100' }, {});
  assert.strictEqual(imp.ok, false); assert.match(imp.errors[0], /add up to 2120 kcal, more than the 1500/);
  for (const bad of [{ kcal: '' , proteinG: '190' }, { kcal: '2200', proteinG: '' }, { kcal: '999', proteinG: '100' }, { kcal: '6001', proteinG: '100' }, { kcal: '2200.5', proteinG: '100' }, { kcal: 'NaN', proteinG: '100' }, { kcal: '2200', proteinG: '401' }])
    assert.strictEqual(HC.checkOwnerTarget(bad, {}).ok, false, JSON.stringify(bad));
  // Re-pointed for P1.3-RC3 (owner decision 1, 23 Nov 2026): a target below the provisional floor is REFUSED, not warned.
  const low = HC.checkOwnerTarget({ kcal: '1300', proteinG: '160', fatG: '25', carbsG: '' }, { restingKcal: 1750, sex: 'MALE', currentKcal: 2400 });
  assert.strictEqual(low.ok, false, 'a target below the provisional floor is refused');
  assert.match(low.errors.join(' '), /clinician/);
  // just above the floor the other warnings still apply
  const lowOk = HC.checkOwnerTarget({ kcal: '1760', proteinG: '160', fatG: '25', carbsG: '' }, { restingKcal: 1750, sex: 'MALE', currentKcal: 2400 });
  assert.strictEqual(lowOk.ok, true);
  assert.deepStrictEqual(lowOk.warnings.map((w) => w.code).sort(), ['FAT_LOW', 'LARGE_CHANGE', 'PROTEIN_BELOW_REFERENCE_FLOOR'].sort());
  const un = HC.checkOwnerTarget({ kcal: '2400', proteinG: '190', fatG: '60', carbsG: '200' }, {});
  assert.deepStrictEqual(un.warnings.map((w) => w.code), ['UNASSIGNED']);
});

test('P1.3 B: confirming keeps old and new values, origin, reason and inputs; history is capped at 12; effective date today..+14', () => {
  let c = coachWith({ goal: { id: 'LOSE_1', setAt: TD } });
  const prev = HC.targetFor(c, TD, HN.PROVISIONAL);
  assert.deepStrictEqual([prev.kcal, prev.proteinG, prev.origin], [2400, 190, 'PROVISIONAL']);
  let r = HC.confirmTarget(c, { kcal: 2200, proteinG: 190, fatG: 60, carbsG: null }, { today: TD, nowIso: NOW.toISOString(), effectiveDate: TD, origin: 'OWNER_ENTERED', reason: 'Entered by me', previous: prev });
  assert.strictEqual(r.ok, true);
  assert.deepStrictEqual(r.target.replaced, { kcal: 2400, proteinG: 190, fatG: null, carbsG: null, origin: 'PROVISIONAL' });
  assert.strictEqual(r.target.origin, 'OWNER_ENTERED'); assert.strictEqual(r.target.goal, 'LOSE_1'); assert.strictEqual(r.target.version, HC.VERSION);
  assert.deepStrictEqual(HC.validateCoach(r.coach), []);
  for (const bad of ['2026-11-22', '2026-12-08', 'soon']) assert.strictEqual(HC.confirmTarget(c, { kcal: 2200, proteinG: 190 }, { today: TD, nowIso: NOW.toISOString(), effectiveDate: bad, origin: 'OWNER_ENTERED' }).ok, false, bad);
  assert.strictEqual(HC.confirmTarget(c, { kcal: 2200, proteinG: 190 }, { today: TD, nowIso: NOW.toISOString(), effectiveDate: '2026-12-07', origin: 'OWNER_ENTERED' }).ok, true);
  c = r.coach;
  for (let i = 0; i < 14; i++) c = HC.confirmTarget(c, { kcal: 2000 + i * 10, proteinG: 190 }, { today: TD, nowIso: new Date(NOW.getTime() + (i + 1) * 1000).toISOString(), effectiveDate: TD, origin: 'OWNER_ENTERED' }).coach;
  assert.strictEqual(c.history.length, 12); assert.strictEqual(c.history[11].kcal, 2130);
  assert.deepStrictEqual(HC.validateCoach(c), []);
});

test('P1.3 B: the reference in force — provisional 2,400 / 190 / 170 when off or unconfirmed; earlier dates keep the target that applied then', () => {
  const prov = HC.targetFor(null, TD, HN.PROVISIONAL);
  assert.deepStrictEqual([prov.kcal, prov.proteinG, prov.proteinFloorG, prov.origin], [2400, 190, 170, 'PROVISIONAL']);
  let c = coachWith();
  c = HC.confirmTarget(c, { kcal: 2300, proteinG: 190 }, { today: '2026-11-10', nowIso: '2026-11-10T06:00:00.000Z', effectiveDate: '2026-11-10', origin: 'OWNER_ENTERED' }).coach;
  c = HC.confirmTarget(c, { kcal: 2200, proteinG: 185 }, { today: TD, nowIso: NOW.toISOString(), effectiveDate: '2026-11-25', origin: 'OWNER_ENTERED' }).coach;
  assert.strictEqual(HC.targetFor(c, '2026-11-09', HN.PROVISIONAL).origin, 'PROVISIONAL');
  assert.strictEqual(HC.targetFor(c, '2026-11-10', HN.PROVISIONAL).kcal, 2300);
  assert.strictEqual(HC.targetFor(c, '2026-11-24', HN.PROVISIONAL).kcal, 2300, 'a future-dated confirmation does not apply early');
  assert.strictEqual(HC.targetFor(c, '2026-11-25', HN.PROVISIONAL).kcal, 2200);
  const off = Object.assign({}, c, { enabled: false });
  assert.strictEqual(HC.targetFor(off, '2026-11-25', HN.PROVISIONAL).origin, 'PROVISIONAL', 'coach off: the provisional reference everywhere');
  assert.deepStrictEqual([HN.PROVISIONAL.kcal, HN.PROVISIONAL.proteinG, HN.PROVISIONAL.proteinFloorG], [2400, 190, 170], 'the provisional constants are unchanged');
});

test('P1.3 B: field-preserving write — only nutritionCoach changes; plan blocks, saved foods, favourites, baselines, unit and unknown fields are byte-identical', () => {
  const before = JSON.parse(JSON.stringify(OTHER));
  const rec = HC.withCoach(OTHER, coachWith(), 'app-settings', TD);
  assert.deepStrictEqual(OTHER, before, 'input not modified');
  const rest = Object.assign({}, rec); delete rest.nutritionCoach;
  assert.strictEqual(JSON.stringify(rest), JSON.stringify(before));
  const gone = HC.withCoach(rec, null, 'app-settings', TD);
  assert.strictEqual(JSON.stringify(gone), JSON.stringify(before));
});

test('P1.3 B: the unchanged data layer saves, reads back, exports and restores a settings record with nutritionCoach (data version 2, no damage)', () => {
  const s = mem(), st = HD.createStore(s, { now: () => NOW });
  const c = HC.confirmTarget(coachWith({ goal: { id: 'LOSE_1', setAt: TD } }), { kcal: 2200, proteinG: 190, fatG: 60, carbsG: 225 }, { today: TD, nowIso: NOW.toISOString(), effectiveDate: TD, origin: 'OWNER_ENTERED', reason: 'synthetic' }).coach;
  let r = st.putRecord('ownerSettings', HC.withCoach(OTHER, c, 'app-settings', TD)); assert.strictEqual(r.ok, true, JSON.stringify(r.errors));
  const back = HD.createStore(s, { now: () => NOW });
  assert.deepStrictEqual(back.damagedRecords(), []);
  assert.deepStrictEqual(HC.readCoach(back.settings().record), { present: true, valid: true, coach: c, problems: [] });
  const text = back.exportJSON(); assert.strictEqual(JSON.parse(text).version, 2);
  const s2 = mem(), st2 = HD.createStore(s2, { now: () => NOW });
  const p = st2.previewImport(text); assert.strictEqual(p.ok, true, JSON.stringify(p.errors || p.message));
  assert.strictEqual(st2.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt }).ok, true);
  const rec2 = HD.createStore(s2, { now: () => NOW }).settings().record;
  assert.deepStrictEqual(HC.readCoach(rec2).coach, c);
  assert.deepStrictEqual(rec2.planBlocks, OTHER.planBlocks); assert.deepStrictEqual(rec2.myFoods, OTHER.myFoods); assert.deepStrictEqual(rec2.favFoods, OTHER.favFoods);
  assert.strictEqual(rec2.weightUnit, 'lb'); assert.deepStrictEqual(rec2.futureField, OTHER.futureField);
});

test('P1.3 B: two-tab concurrency — a write prepared from a stale screen (settings stamp) is refused and changes nothing', () => {
  const s = mem(), st = HD.createStore(s, { now: () => NOW });
  assert.strictEqual(st.putRecord('ownerSettings', OTHER).ok, true);
  const stampA = HB.settingsStamp(st); // tab A draws its screen
  // tab B saves a favourite meanwhile
  const rb = HB.writeSettings(st, HD, TD, (rec) => { rec.favFoods = rec.favFoods.concat(['SR:2002']); return null; });
  assert.strictEqual(rb.ok, true);
  const before = s.getItem(HD.STORAGE_KEY);
  const ra = HB.writeSettings(st, HD, TD, (rec) => { rec.nutritionCoach = coachWith(); return null; }, { expectStamp: stampA });
  assert.strictEqual(ra.ok, false); assert.strictEqual(ra.code, 'STALE');
  assert.strictEqual(s.getItem(HD.STORAGE_KEY), before);
  // after a fresh read the same write keeps tab B's favourite
  const rc = HB.writeSettings(st, HD, TD, (rec) => { rec.nutritionCoach = coachWith(); return null; }, { expectStamp: HB.settingsStamp(st) });
  assert.strictEqual(rc.ok, true);
  assert.deepStrictEqual(HD.createStore(s, { now: () => NOW }).settings().record.favFoods, ['SR:1001', 'SR:2002']);
});

test('P1.3 B: a malformed stored coach object is reported INVALID (coach shows nothing) and the rest of the settings stay usable', () => {
  const rec = Object.assign({}, OTHER, { nutritionCoach: { schema: 1, enabled: true, profile: { heightCm: 'tall' } } });
  const rc = HC.readCoach(rec);
  assert.strictEqual(rc.valid, false); assert.strictEqual(rc.coach, null); assert.ok(rc.problems.length);
  const s = mem(), st = HD.createStore(s, { now: () => NOW });
  assert.strictEqual(st.putRecord('ownerSettings', rec).ok, true, 'the data layer does not judge the coach object');
  assert.strictEqual(HD.createStore(s, { now: () => NOW }).settings().rhrBaselineBpm, 61);
});

test('P1.3 B: restore preview says when a backup would replace or remove the coach profile and targets (read-only)', () => {
  const c = HC.confirmTarget(coachWith(), { kcal: 2200, proteinG: 190 }, { today: TD, nowIso: NOW.toISOString(), effectiveDate: TD, origin: 'OWNER_ENTERED' }).coach;
  const cur = JSON.stringify({ version: 2, ownerSettings: [HC.withCoach(OTHER, c, 'app-settings', TD)] });
  const old = JSON.stringify({ version: 2, ownerSettings: [OTHER] });
  assert.match(HC.restoreNote(cur, old), /removes this device's Nutrition Coach profile, goal and 1 confirmed target/);
  assert.strictEqual(HC.restoreNote(cur, cur), null);
  assert.strictEqual(HC.restoreNote(old, cur), null, 'nothing on the device to lose');
  const other = JSON.stringify({ version: 2, ownerSettings: [HC.withCoach(OTHER, coachWith(), 'app-settings', TD)] });
  assert.match(HC.restoreNote(cur, other), /differs/);
});

// ---------- rollback: older data layers keep the field ----------
const OLD = {
  'claude-p11.2': process.env.P113_P112_SRC || '/workspace/hyrox-p11-3-before/src',
  'claude-p11': process.env.P112_P11_SRC || '/workspace/hyrox-p11-2-before/src',
  'claude-p10b': process.env.P112_P10B_SRC || '/workspace/hyrox-p11-before/src',
  p9: process.env.P112_P9_SRC || '/workspace/hyrox-p9/src',
};
for (const [name, dir] of Object.entries(OLD)) {
  const present = fs.existsSync(path.join(dir, 'data', 'hyrox-data.js'));
  (present ? test : test.skip)(`P1.3 B rollback: the ${name} data layer restores a P1.3 backup without damage and keeps nutritionCoach through its own settings save`, () => {
    const s0 = mem(), st0 = HD.createStore(s0, { now: () => NOW });
    const c = HC.confirmTarget(coachWith({ goal: { id: 'LOSE_1', setAt: TD } }), { kcal: 2200, proteinG: 190 }, { today: TD, nowIso: NOW.toISOString(), effectiveDate: TD, origin: 'OWNER_ENTERED' }).coach;
    const base = Object.assign({}, OTHER); delete base.planBlocks; delete base.myFoods; delete base.favFoods; // fields older layers may not know are covered elsewhere
    assert.strictEqual(st0.putRecord('ownerSettings', HC.withCoach(base, c, 'app-settings', TD)).ok, true);
    const text = st0.exportJSON();
    const OLDHD = require(path.join(dir, 'data', 'hyrox-data.js'));
    const storage = mem(), st = OLDHD.createStore(storage, { now: () => NOW });
    const p = st.previewImport(text); assert.strictEqual(p.ok, true, JSON.stringify(p.errors || p.message));
    assert.strictEqual(st.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt }).ok, true);
    const st2 = OLDHD.createStore(storage, { now: () => NOW });
    assert.deepStrictEqual(typeof st2.damagedRecords === 'function' ? st2.damagedRecords() : [], []);
    const set = JSON.parse(JSON.stringify(st2.settings().record)); set.rhrBaselineBpm = 60;
    assert.strictEqual(st2.putRecord('ownerSettings', set).ok, true);
    const back = OLDHD.createStore(storage, { now: () => NOW }).settings();
    assert.strictEqual(back.rhrBaselineBpm, 60);
    assert.deepStrictEqual(back.record.nutritionCoach, c);
    // and roll forward again: this build reads it unchanged
    assert.deepStrictEqual(HC.readCoach(back.record).coach, c);
  });
}

test('P1.3 B scope: data, plan, block, nutrition, wellness, estimator, food, photo and server files are byte-identical to P1.1-RC2', () => {
  // Re-pointed by the P0 sprint photo + note fix (23 Nov 2026): see tests/p0-sprint-pins.js (3 photo/server files re-pinned on purpose).
  require('./p0-sprint-pins.js').checkRc2PinsWithSprint(ROOT);
  const src = fs.readFileSync(path.join(ROOT, 'src', 'data', 'hyrox-coach.js'), 'utf8').replace(/\/\*[\s\S]*?\*\/|\/\/.*$/gm, '');
  for (const banned of [/localStorage/, /fetch\s*\(/, /XMLHttpRequest/, /sendBeacon/, /WebSocket/, /import\s*\(/, /https?:\/\//]) assert.doesNotMatch(src, banned);
});
