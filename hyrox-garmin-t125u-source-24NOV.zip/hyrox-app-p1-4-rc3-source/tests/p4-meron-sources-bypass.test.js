'use strict';
// Phase 4 (Meron): bypass attempts against Dawit's 5e5d18f top-level `sources` refusal.
// NEW FILE. Synthetic data. previewImport and applyImport (apply called directly
// with confirm + expectCurrent, no preview) are both exercised. Live data must
// stay unchanged on a refusal. A genuine normal backup must still be accepted.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const { HD, KEY, PRE, mem, mk, O, ts, backup, restore } = require('./p3-helpers.js');

const D = '2026-11-10';
const badDaily = () => ({
  id: 'daily-' + D, createdAt: ts, updatedAt: ts, date: D,
  footPain: O(11), stairKneePain: O(1), sleepH: O(7),
  limp: { state: 'OBSERVED', value: false }, steps: O(8000), soreness: O(2), rhr: O(60),
});
function seed(lists) {
  const raw = JSON.stringify(Object.assign({
    version: 2,
    weight: [{ id: 'w1', createdAt: ts, date: D, kg: 80 }],
    workouts: [], nutrition: [],
  }, lists));
  const s = mem({ [KEY]: raw });
  return { s, st: mk(s), raw };
}
function rawObj() {
  const r = seed({ daily: [badDaily()] }).st.rawRecoveryExport();
  assert.equal(r.ok, true);
  return JSON.parse(r.text);
}
// Relabelled as a normal backup with empty lists (Meron HIGH repro), then mutated.
function editedRaw(mutate) {
  const o = Object.assign({}, rawObj(), { app: 'hyrox-app', version: 2, weight: [], workouts: [], nutrition: [] });
  delete o.kind;
  if (mutate) mutate(o);
  return o;
}
function liveDevice() {
  const s = mem();
  const st = mk(s);
  assert.equal(st.addWeight({ date: D, kg: 80 }).ok, true);
  assert.equal(st.putRecord('walks', { date: D, durationMin: 30, steps: 3000 }).ok, true);
  const p = st.previewImport(st.exportJSON());
  assert.equal(p.ok, true);
  return { s, st, current: p.preview.current, currentExt: p.preview.currentExt, before: snapAll(s), writes: s.writes };
}
const snapAll = (s) => JSON.stringify(Object.keys(s.m).sort().map((k) => [k, s.m[k]]));

function assertRefusedBoth(text, expectedCode) {
  const code = expectedCode || 'raw_recovery_file';
  const { s, st, current, currentExt, before, writes } = liveDevice();
  const p = st.previewImport(text);
  assert.equal(p.ok, false, 'previewImport must refuse');
  assert.equal(p.code, code);
  assert.equal(s.writes, writes, 'preview writes nothing');
  assert.equal(snapAll(s), before);
  // applyImport called directly on the text, never going through preview
  const a = st.applyImport(text, { confirm: 'REPLACE', expectCurrent: current, expectCurrentExt: currentExt });
  assert.equal(a.ok, false, 'applyImport (direct) must refuse');
  assert.equal(a.code, code);
  assert.equal(s.writes, writes, 'apply writes nothing');
  assert.equal(snapAll(s), before, 'every storage key is byte-identical');
  assert.equal(st.list('weight').length, 1);
  assert.equal(st.list('weight')[0].kg, 80);
  assert.equal(st.records('walks').length, 1);
  assert.equal(Object.prototype.hasOwnProperty.call(s.m, PRE), false);
}

function assertWipesOrReplaces(text) {
  // Used by DEFECT tests: the file must not be accepted, and must not replace live data.
  const { s, st, current, currentExt, before, writes } = liveDevice();
  const p = st.previewImport(text);
  assert.equal(p.ok, false, 'previewImport must refuse an edited emergency file');
  assert.equal(p.code, 'raw_recovery_file');
  const a = st.applyImport(text, { confirm: 'REPLACE', expectCurrent: current, expectCurrentExt: currentExt });
  assert.equal(a.ok, false, 'applyImport (direct) must refuse an edited emergency file');
  assert.equal(a.code, 'raw_recovery_file');
  assert.equal(s.writes, writes);
  assert.equal(snapAll(s), before);
  assert.equal(st.list('weight').length, 1);
  assert.equal(st.list('weight')[0].kg, 80);
}

describe('5e5d18f holds: a top-level sources field is refused on preview and on direct apply; nothing is written', () => {
  it('the Meron disguise (app relabelled, kind removed, empty lists, sources kept) is refused on both paths', () => {
    assertRefusedBoth(JSON.stringify(editedRaw()));
  });

  it('sources set to null, {}, [], or "" is still refused', () => {
    for (const v of [null, {}, [], '']) {
      assertRefusedBoth(JSON.stringify(editedRaw((o) => { o.sources = v; })));
    }
  });

  it('kind/app/version edits combined with empty lists are still refused while sources remains', () => {
    const raw = rawObj();
    const variants = [
      Object.assign({}, raw, { app: 'hyrox-app', kind: 'hyrox-app', version: 2, weight: [], workouts: [], nutrition: [] }),
      Object.assign({}, raw, { app: 'hyrox-app', kind: '', version: 2, weight: [], workouts: [], nutrition: [] }),
      Object.assign({}, raw, { app: 'hyrox-app', kind: 'backup', version: 2, weight: [], workouts: [], nutrition: [] }),
      editedRaw((o) => { o.version = 1; }),
      editedRaw((o) => { o.version = 99; }),
      editedRaw((o) => { o.version = '2'; }),
    ];
    for (const o of variants) assertRefusedBoth(JSON.stringify(o));
  });

  it('__proto__ or constructor mixed in does not bypass a present top-level sources field', () => {
    const withCtor = editedRaw((o) => { o.constructor = { name: 'x' }; });
    assertRefusedBoth(JSON.stringify(withCtor));
    const text = JSON.stringify(editedRaw()).replace(/^{/, '{"__proto__":{"meals":[{"id":"m1"}]},');
    assertRefusedBoth(text);
  });

  it('JSON text with a duplicate sources key is refused when the last value is still the sources field (null or [])', () => {
    const src = JSON.stringify(rawObj().sources);
    const prefix = '{"app":"hyrox-app","version":2,"exportedAt":"' + ts + '","weight":[],"workouts":[],"nutrition":[],';
    assertRefusedBoth(prefix + '"sources":' + src + ',"sources":null}');
    assertRefusedBoth(prefix + '"sources":' + src + ',"sources":[]}');
    // last "weight" is populated, but last "sources" is still present (null)
    assertRefusedBoth('{"app":"hyrox-app","version":2,"exportedAt":"' + ts + '","weight":[],"workouts":[],"nutrition":[],"sources":null,"weight":[{"id":"w1","createdAt":"' + ts + '","date":"' + D + '","kg":99}]}');
  });

  it('a unicode-escaped "sources" key (\\u0073ources) is still the sources field and is refused', () => {
    assertRefusedBoth('{"app":"hyrox-app","version":2,"exportedAt":"' + ts + '","weight":[],"workouts":[],"nutrition":[],"\\u0073ources":[]}');
  });

  it('whitespace around a disguise is still refused; a leading BOM is refused and writes nothing (not_json)', () => {
    assertRefusedBoth('\n\t  ' + JSON.stringify(editedRaw()) + '  \n');
    assertRefusedBoth('\uFEFF' + JSON.stringify(editedRaw()), 'not_json');
  });

  it('a genuine normal backup without a sources field is still accepted and restores; live data is replaced only then', () => {
    const { s, st } = liveDevice();
    const text = backup({
      weight: [{ id: 'n1', createdAt: ts, date: D, kg: 79 }],
      notes: 'hi', source: 'phone', kindOfBackup: 'manual', format: 1, sourcesCount: 2,
    });
    const p = st.previewImport(text);
    assert.equal(p.ok, true, 'must not false-refuse a genuine backup');
    assert.equal(Object.prototype.hasOwnProperty.call(JSON.parse(text), 'sources'), false);
    const a = restore(st, text);
    assert.equal(a.ok, true);
    assert.equal(st.list('weight').length, 1);
    assert.equal(st.list('weight')[0].kg, 79);
    assert.ok(s.writes > 0);
  });

  it('a genuine empty normal backup still previews ok (empty-replace is unchanged policy)', () => {
    const { st } = liveDevice();
    const p = st.previewImport(backup({}));
    assert.equal(p.ok, true);
    assert.deepEqual(p.preview.counts, { weight: 0, workouts: 0, nutrition: 0 });
  });
});

describe('DEFECT: an edited emergency raw file can still replace live data if the top-level sources key is renamed, nested, or removed', () => {
  // HIGH, data-loss footgun. 5e5d18f only inspects an own top-level property named exactly "sources".
  // If that key is renamed, moved, or deleted, previewImport/applyImport accept the file as a normal
  // backup and REPLACE live records (empty or planted lists). The emergency copies may still be in
  // the file (under a lookalike key, a nested wrapper, or leftover warning/format/normalExport fields).

  function renamed(key) {
    return JSON.stringify(editedRaw((o) => { const s = o.sources; delete o.sources; o[key] = s; }));
  }

  it('renaming sources to Sources, SOURCES, a spaced or look-alike key, or a zero-width/nbsp variant still wipes live data; this must be refused', () => {
    const keys = [
      'Sources', 'SOURCES', ' sources',
      'sources\u200b', 'sour\u200bces',
      '\u0441ources', // Cyrillic es
      '\u0455ources', // Cyrillic dze
      'sources\u00a0',
      '\ufeffsources',
    ];
    for (const k of keys) assertWipesOrReplaces(renamed(k));
  });

  it('moving sources under a wrapper, to depth 2, or inside a weight/workouts/nutrition entry still lets the file replace live data; this must be refused', () => {
    const copies = rawObj().sources;
    assertWipesOrReplaces(JSON.stringify(editedRaw((o) => { delete o.sources; o.wrapper = { sources: copies }; })));
    assertWipesOrReplaces(JSON.stringify(editedRaw((o) => { delete o.sources; o.meta = { deep: { sources: copies } }; })));
    assertWipesOrReplaces(JSON.stringify(editedRaw((o) => {
      delete o.sources;
      o.weight = [{ id: 'planted', createdAt: ts, date: D, kg: 70, sources: copies }];
    })));
  });

  it('deleting sources but leaving warning/format/normalExport/omitted (still an identifiable edited raw file) wipes live data; this must be refused', () => {
    assertWipesOrReplaces(JSON.stringify(editedRaw((o) => { delete o.sources; })));
  });

  it('stuffing sources under __proto__ after removing the top-level field wipes live data; this must be refused', () => {
    // Built at the text level so "__proto__" is a real JSON key, not the object prototype
    // (JSON.stringify drops a mutated prototype).
    const o = editedRaw((x) => { delete x.sources; });
    const text = JSON.stringify(o).replace(/^{/, '{"__proto__":{"sources":' + JSON.stringify(rawObj().sources) + '},');
    assertWipesOrReplaces(text);
  });

  it('deleting sources and planting a partial weight list replaces live data with that list; this must be refused', () => {
    assertWipesOrReplaces(JSON.stringify(editedRaw((o) => {
      delete o.sources;
      o.weight = [{ id: 'x1', createdAt: ts, date: D, kg: 70 }];
    })));
  });
});

describe('characterization (limit of identification, not a new policy): a file stripped of every recovery marker is a genuine empty backup', () => {
  // Once app/kind/sources/warning/format/normalExport/omitted are all gone, the text is
  // indistinguishable from a normal empty backup, which is still accepted (owner / existing
  // empty-replace behaviour). This is recorded, not filed as a DEFECT of the sources check.
  it('a fully stripped {app,version,exportedAt,empty lists} file previews as a normal empty backup', () => {
    const { st } = liveDevice();
    const text = JSON.stringify({ app: 'hyrox-app', version: 2, exportedAt: ts, weight: [], workouts: [], nutrition: [] });
    const p = st.previewImport(text);
    assert.equal(p.ok, true);
    assert.deepEqual(p.preview.counts, { weight: 0, workouts: 0, nutrition: 0 });
  });
});
