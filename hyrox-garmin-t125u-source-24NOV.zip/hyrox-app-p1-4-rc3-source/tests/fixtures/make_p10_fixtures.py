"""P10 synthetic photo fixtures (no real food, no people, no metadata): three distinct 'plate' views and one
1700 px image (over the 1600 px multi-photo cap). Run: python make_p10_fixtures.py"""
from PIL import Image, ImageDraw
def plate(name, size, seed):
    im = Image.new('RGB', size, (235, 230, 220)); d = ImageDraw.Draw(im)
    w, h = size
    d.ellipse([w*0.1, h*0.1, w*0.9, h*0.9], fill=(250, 250, 250), outline=(180, 180, 180), width=4)
    d.ellipse([w*0.25+seed*7, h*0.3, w*0.55+seed*7, h*0.6], fill=(200, 110 + seed*20, 40))   # "chicken"
    d.ellipse([w*0.45, h*0.45-seed*5, w*0.75, h*0.75-seed*5], fill=(210, 80, 30))            # "sauce"
    im.save(name, 'JPEG', quality=80)
plate('p10-view-a.jpg', (640, 480), 0)
plate('p10-view-b.jpg', (480, 640), 1)
plate('p10-view-c.jpg', (600, 600), 2)
plate('p10-over-1600.jpg', (1700, 1275), 3)
