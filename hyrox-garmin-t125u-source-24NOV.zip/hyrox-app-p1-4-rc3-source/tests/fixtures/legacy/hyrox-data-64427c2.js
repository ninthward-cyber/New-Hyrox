/*
 * hyrox-data.js - on-device data layer for the HYROX tracker.
 * Plain-JS UMD: classic <script> (window.HyroxData) or require() in Node.
 * No dependencies. Storage key: 'hyrox.v1'.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.HyroxData = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var KEY = 'hyrox.v1';
  // Damaged data found under KEY is copied here, byte-for-byte, before anything
  // new is written. It is never overwritten once set.
  var RECOVERY_KEY = 'hyrox.v1.corrupt-backup';
  var VERSION = 1;
  // Exact previous KEY text saved before an import replaces it:
  // JSON.stringify({kind:'hyrox-pre-import', savedAt, raw}). Latest import wins.
  var BACKUP_KEY = 'hyrox.v1.pre-import-backup';
  var BACKUP_KIND = 'hyrox-pre-import';
  var APP_ID = 'hyrox-app';
  var IMPORT_LIMITS = Object.freeze({ maxBytes: 2000000, maxPerList: 10000 });
  var MAX_IMPORT_ERRORS = 20;
  var TYPES = ['weight', 'workouts', 'nutrition'];

  var MSG = {
    unavailable: 'Not saved: storage is unavailable in this browser (private browsing or blocked site data).',
    unreadable: 'Not saved: your saved data could not be read, so nothing was changed. Reload and try again.',
    newer: 'Not saved: your saved data is from a newer version of this app, so nothing was changed.',
    corrupt: 'Not saved: your saved data is damaged and could not be backed up safely, so nothing was changed.',
    write: 'Could not save on this device (storage full or blocked).'
  };

  // ---------- helpers ----------

  function todayQatar(now) {
    var d = now instanceof Date ? now : (now != null ? new Date(now) : new Date());
    var parts = new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Qatar', year: 'numeric', month: '2-digit', day: '2-digit'
    }).formatToParts(d);
    var p = {};
    parts.forEach(function (x) { p[x.type] = x.value; });
    return p.year + '-' + p.month + '-' + p.day;
  }

  function emptyData() {
    return { version: VERSION, weight: [], workouts: [], nutrition: [] };
  }

  function memoryStorage() {
    var m = {};
    return {
      getItem: function (k) { return Object.prototype.hasOwnProperty.call(m, k) ? m[k] : null; },
      setItem: function (k, v) { m[k] = String(v); }
    };
  }

  function isBlank(v) {
    return v === undefined || v === null || (typeof v === 'string' && v.trim() === '');
  }

  function toNumber(v) {
    if (typeof v === 'number') return v;
    if (typeof v === 'string' && v.trim() !== '') return Number(v.trim());
    return NaN;
  }

  function maxOneDecimal(n) {
    return Math.abs(Math.round(n * 10) - n * 10) < 1e-9;
  }

  function newId() {
    return Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
  }

  // ---------- field validators (each returns {value} or {error}) ----------

  // Format + real calendar date + not after `ceiling` (a YYYY-MM-DD string).
  function vDateUpTo(v, ceiling) {
    if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(v)) return { error: 'Date must be YYYY-MM-DD.' };
    var y = +v.slice(0, 4), m = +v.slice(5, 7), d = +v.slice(8, 10);
    var dt = new Date(Date.UTC(y, m - 1, d));
    if (dt.getUTCFullYear() !== y || dt.getUTCMonth() !== m - 1 || dt.getUTCDate() !== d) {
      return { error: 'Date is not a real calendar date.' };
    }
    if (v > ceiling) return { error: 'Date cannot be in the future.' };
    return { value: v };
  }

  function vDate(v, now) {
    return vDateUpTo(v, todayQatar(now));
  }

  function vNumber(v, opts) {
    if (isBlank(v)) return { error: opts.label + ' is required.' };
    var n = toNumber(v);
    if (!isFinite(n)) return { error: opts.label + ' must be a number.' };
    if (opts.integer && !Number.isInteger(n)) return { error: opts.label + ' must be a whole number.' };
    if (opts.oneDecimal && !maxOneDecimal(n)) return { error: opts.label + ' can have at most 1 decimal place.' };
    if (n < opts.min || n > opts.max) return { error: opts.label + ' must be between ' + opts.min + ' and ' + opts.max + '.' };
    return { value: opts.oneDecimal ? Math.round(n * 10) / 10 : n };
  }

  function vText(v, opts) {
    if (isBlank(v)) {
      if (opts.required) return { error: opts.label + ' is required.' };
      return { value: '' };
    }
    if (typeof v !== 'string') return { error: opts.label + ' must be text.' };
    var s = v.trim();
    if (s.length > opts.max) return { error: opts.label + ' must be at most ' + opts.max + ' characters.' };
    return { value: s };
  }

  function vBool(v, label) {
    if (v === undefined || v === null || v === '') return { value: false };
    if (v === true || v === 'true') return { value: true };
    if (v === false || v === 'false') return { value: false };
    return { error: label + ' must be true or false.' };
  }

  function runRules(input, rules) {
    input = input && typeof input === 'object' ? input : {};
    var out = {}, errors = {}, bad = false;
    Object.keys(rules).forEach(function (field) {
      var r = rules[field](input[field]);
      if (r.error) { errors[field] = r.error; bad = true; } else { out[field] = r.value; }
    });
    return bad ? { errors: errors } : { value: out };
  }

  // ---------- store ----------

  function isValidEntry(e) {
    return !!e && typeof e === 'object' && typeof e.id === 'string' && typeof e.date === 'string';
  }

  // Classifies non-empty stored text. Pure: never touches storage.
  //   ok      -> data keeps every stored entry and unknown field
  //   corrupt -> not a valid hyrox object;  newer -> newer schema version
  function classifyRaw(raw) {
    var parsed;
    try { parsed = JSON.parse(raw); } catch (e) { return { state: 'corrupt', raw: raw }; }
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return { state: 'corrupt', raw: raw };
    if (typeof parsed.version === 'number' && parsed.version > VERSION) return { state: 'newer', raw: raw };
    for (var i = 0; i < TYPES.length; i++) {
      var v = parsed[TYPES[i]];
      if (v !== undefined && v !== null && !Array.isArray(v)) return { state: 'corrupt', raw: raw };
    }
    // Keep unknown top-level fields and every entry (even ones we cannot
    // display) so a later save never silently drops data.
    var data = {};
    Object.keys(parsed).forEach(function (k) { data[k] = parsed[k]; });
    if (data.version === undefined) data.version = VERSION;
    TYPES.forEach(function (t) { data[t] = Array.isArray(parsed[t]) ? parsed[t].slice() : []; });
    return { state: 'ok', data: data, raw: raw };
  }

  // ---------- import validation (pure: never touches storage) ----------
  // Import never coerces: numbers must be numbers, booleans must be booleans,
  // text is kept exactly as written. Entries are rebuilt from known fields only.

  var ISO_RE = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2}(\.\d{1,9})?)?(Z|[+-]\d{2}:\d{2})$/;

  function isIsoTimestamp(v) {
    return typeof v === 'string' && ISO_RE.test(v) && !isNaN(new Date(v).getTime());
  }

  function hasOwn(o, k) { return Object.prototype.hasOwnProperty.call(o, k); }

  function iNumber(opts) {
    return function (v) {
      if (v === undefined || v === null) return { error: opts.label + ' is required.' };
      if (typeof v !== 'number' || !isFinite(v)) return { error: opts.label + ' must be a number.' };
      if (opts.integer && !Number.isInteger(v)) return { error: opts.label + ' must be a whole number.' };
      if (opts.oneDecimal && !maxOneDecimal(v)) return { error: opts.label + ' can have at most 1 decimal place.' };
      if (v < opts.min || v > opts.max) return { error: opts.label + ' must be between ' + opts.min + ' and ' + opts.max + '.' };
      return { value: v };
    };
  }

  function iText(opts) {
    return function (v) {
      if (v === undefined || v === null) {
        return opts.required ? { error: opts.label + ' is required.' } : { value: '' };
      }
      if (typeof v !== 'string') return { error: opts.label + ' must be text.' };
      if (opts.required && v.trim() === '') return { error: opts.label + ' is required.' };
      if (v.length > opts.max) return { error: opts.label + ' must be at most ' + opts.max + ' characters.' };
      return { value: v };
    };
  }

  function iBool(label) {
    return function (v) {
      if (v === undefined || v === null) return { value: false };
      if (typeof v !== 'boolean') return { error: label + ' must be true or false.' };
      return { value: v };
    };
  }

  function iId(v) {
    if (typeof v !== 'string' || v.length < 1 || v.length > 64) return { error: 'Id must be text of 1 to 64 characters.' };
    return { value: v };
  }

  function iCreatedAt(v) {
    if (!isIsoTimestamp(v)) return { error: 'createdAt must be an ISO date-time.' };
    return { value: v };
  }

  // Field order here is the stored field order (matches add*).
  function importRules(ceiling) {
    var date = function (v) { return vDateUpTo(v, ceiling); };
    return {
      weight: [['id', iId], ['createdAt', iCreatedAt], ['date', date],
        ['kg', iNumber({ label: 'Weight', min: 20, max: 400, oneDecimal: true })]],
      workouts: [['id', iId], ['createdAt', iCreatedAt], ['date', date],
        ['activity', iText({ label: 'Activity', max: 60, required: true })],
        ['durationMin', iNumber({ label: 'Duration', min: 1, max: 600, integer: true })],
        ['partial', iBool('Partial')],
        ['notes', iText({ label: 'Notes', max: 500 })]],
      nutrition: [['id', iId], ['createdAt', iCreatedAt], ['date', date],
        ['label', iText({ label: 'Label', max: 60 })],
        ['calories', iNumber({ label: 'Calories', min: 0, max: 10000, integer: true })],
        ['proteinG', iNumber({ label: 'Protein', min: 0, max: 1000, oneDecimal: true })]]
    };
  }

  function importFail(code, message, errors) {
    return { ok: false, code: code, message: message, errors: errors || [] };
  }

  function countLists(data) {
    var c = {};
    TYPES.forEach(function (t) { c[t] = data[t].length; });
    return c;
  }

  function countValid(data) {
    var c = {};
    TYPES.forEach(function (t) { c[t] = data[t].filter(isValidEntry).length; });
    return c;
  }

  // Parses and fully validates an import file. Returns
  // {ok:true, data:{version,weight,workouts,nutrition}, exportedAt, warnings[]}
  // or {ok:false, code, message, errors[]}.
  function parseImport(text, now) {
    if (typeof text !== 'string' || text.length === 0) {
      return importFail('not_json', 'This file is empty or is not a backup file.');
    }
    if (text.length > IMPORT_LIMITS.maxBytes) {
      return importFail('too_large', 'This file is too large to be a HYROX backup (limit 2 MB).');
    }
    var parsed;
    try { parsed = JSON.parse(text); } catch (e) {
      return importFail('not_json', 'This file is not valid JSON. It may be damaged or incomplete.');
    }
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed) || parsed.app !== APP_ID) {
      return importFail('not_hyrox', 'This file is not a HYROX tracker backup.');
    }
    if (parsed.version !== VERSION) {
      return importFail('unsupported_version', 'This backup is from an unsupported app version, so it cannot be restored.');
    }
    for (var i = 0; i < TYPES.length; i++) {
      if (!Array.isArray(parsed[TYPES[i]])) {
        return importFail('not_hyrox', 'This file is not a HYROX tracker backup (the ' + TYPES[i] + ' list is missing or damaged).');
      }
    }
    for (i = 0; i < TYPES.length; i++) {
      if (parsed[TYPES[i]].length > IMPORT_LIMITS.maxPerList) {
        return importFail('too_many', 'This backup has more than ' + IMPORT_LIMITS.maxPerList + ' ' + TYPES[i] + ' entries, so it cannot be restored.');
      }
    }

    var nowDate = now instanceof Date ? now : new Date(now);
    var today = todayQatar(nowDate);
    var exportedAt = hasOwn(parsed, 'exportedAt') ? parsed.exportedAt : null;
    var ceiling = today;
    var warnings = [];
    if (exportedAt !== null && !isIsoTimestamp(exportedAt)) {
      warnings.push('This backup\'s export date is unreadable, so entries dated after today are not accepted.');
    }
    if (isIsoTimestamp(exportedAt)) {
      var exportedDay = todayQatar(new Date(exportedAt));
      if (exportedDay > ceiling) ceiling = exportedDay;
      if (new Date(exportedAt).getTime() > nowDate.getTime()) {
        warnings.push('This backup says it was exported in the future (' + exportedAt + '). Check this device\'s date and time before restoring.');
      }
    }

    var rules = importRules(ceiling);
    var errors = [], errorCount = 0, dupCount = 0, extraFields = 0;
    var out = { version: VERSION, weight: [], workouts: [], nutrition: [] };
    function addError(list, index, field, message) {
      errorCount++;
      if (errors.length < MAX_IMPORT_ERRORS) errors.push({ list: list, index: index, field: field, message: message });
    }
    TYPES.forEach(function (t) {
      var seen = Object.create(null);
      var known = Object.create(null);
      rules[t].forEach(function (r) { known[r[0]] = true; });
      parsed[t].forEach(function (e, idx) {
        if (!e || typeof e !== 'object' || Array.isArray(e)) {
          addError(t, idx, 'entry', 'Entry is not a valid record.');
          return;
        }
        var entry = {}, bad = false;
        rules[t].forEach(function (r) {
          var res = r[1](hasOwn(e, r[0]) ? e[r[0]] : undefined);
          if (res.error) { bad = true; addError(t, idx, r[0], res.error); } else { entry[r[0]] = res.value; }
        });
        Object.keys(e).forEach(function (k) { if (!known[k]) extraFields++; });
        if (!bad) {
          if (seen[entry.id]) { dupCount++; addError(t, idx, 'id', 'Duplicate id "' + entry.id + '" (also at index ' + (seen[entry.id] - 1) + ').'); }
          else seen[entry.id] = idx + 1;
        }
        out[t].push(entry);
      });
    });
    if (errorCount > 0) {
      var onlyDups = dupCount === errorCount;
      return importFail(onlyDups ? 'duplicate_ids' : 'invalid_records',
        (onlyDups ? 'This backup has repeated entry ids' : 'This backup has ' + errorCount + ' invalid ' + (errorCount === 1 ? 'value' : 'values')) +
        ', so nothing was restored.', errors);
    }
    var topKnown = { app: 1, exportedAt: 1, version: 1, weight: 1, workouts: 1, nutrition: 1 };
    var extraTop = Object.keys(parsed).filter(function (k) { return !hasOwn(topKnown, k); }).length;
    if (extraFields > 0) warnings.push(extraFields + ' unknown ' + (extraFields === 1 ? 'field' : 'fields') + ' in entries will be ignored.');
    if (extraTop > 0) warnings.push(extraTop + ' unknown top-level ' + (extraTop === 1 ? 'field' : 'fields') + ' will be ignored.');
    return { ok: true, data: out, exportedAt: typeof exportedAt === 'string' ? exportedAt : null, warnings: warnings };
  }

  function createStore(storage, options) {
    // persistent=false means we are running on throwaway in-memory storage:
    // reads work (always empty) but every write is refused with an error.
    var persistent = true;
    if (!storage) {
      try {
        storage = (typeof window !== 'undefined' && window.localStorage) ? window.localStorage : null;
      } catch (e) { storage = null; }
      if (!storage) { storage = memoryStorage(); persistent = false; }
    }
    var nowFn = options && typeof options.now === 'function' ? options.now : function () { return new Date(); };

    // Reads KEY and classifies it. Never writes.
    //   ok | empty        -> data is usable (data keeps every stored entry and field)
    //   unreadable        -> getItem threw; we do not know what is stored
    //   corrupt           -> stored text is not a valid hyrox object (raw kept)
    //   newer             -> stored by a newer schema version (raw kept)
    function readState() {
      if (!persistent) return { state: 'unavailable', data: emptyData() };
      var raw;
      try { raw = storage.getItem(KEY); } catch (e) { return { state: 'unreadable' }; }
      if (raw === undefined) raw = null;
      if (raw === null || raw === '') return { state: 'empty', data: emptyData(), raw: raw };
      return classifyRaw(raw);
    }

    // For display: only well-formed entries; damaged/unreadable storage reads as empty.
    function load() {
      var s = readState();
      var data = emptyData();
      if (s.data) TYPES.forEach(function (t) { data[t] = s.data[t].filter(isValidEntry); });
      return data;
    }

    // Copies damaged raw text to RECOVERY_KEY and verifies it. Never replaces
    // an existing, different recovery copy.
    function preserveCorrupt(raw) {
      var existing;
      try { existing = storage.getItem(RECOVERY_KEY); } catch (e) { return false; }
      if (existing !== null && existing !== undefined) return existing === raw;
      try {
        storage.setItem(RECOVERY_KEY, raw);
        return storage.getItem(RECOVERY_KEY) === raw;
      } catch (e) { return false; }
    }

    // Returns {data} that is safe to modify and save, or {error}.
    function loadForWrite() {
      var s = readState();
      if (s.state === 'unavailable') return { error: MSG.unavailable };
      if (s.state === 'unreadable') return { error: MSG.unreadable };
      if (s.state === 'newer') return { error: MSG.newer };
      if (s.state === 'corrupt') {
        if (!preserveCorrupt(s.raw)) return { error: MSG.corrupt };
        return { data: emptyData() };
      }
      return { data: s.data };
    }

    // Writes and reads back; success only if the stored text matches exactly.
    function save(data) {
      if (!persistent) return false;
      var json = JSON.stringify(data);
      try {
        storage.setItem(KEY, json);
        return storage.getItem(KEY) === json;
      } catch (e) { return false; }
    }

    // ---------- import / restore (REPLACE only) ----------

    var STORAGE_FAIL = {
      unavailable: ['storage_unavailable', MSG.unavailable.replace('Not saved', 'Not restored')],
      unreadable: ['storage_unreadable', MSG.unreadable.replace('Not saved', 'Not restored')],
      newer: ['storage_newer', MSG.newer.replace('Not saved', 'Not restored')]
    };

    function currentCounts(s) {
      return s.data ? countValid(s.data) : { weight: 0, workouts: 0, nutrition: 0 };
    }

    function applyFail(code, message, extra) {
      var r = importFail(code, message, extra && extra.errors);
      r.rolledBack = !!(extra && extra.rolledBack);
      r.backupKey = extra && extra.backupKey ? extra.backupKey : null;
      return r;
    }

    function readBackupSlot() {
      try {
        var v = storage.getItem(BACKUP_KEY);
        return { value: v === undefined ? null : v };
      } catch (e) { return { error: true }; }
    }

    // Saves the exact previous KEY text (or null) in the single pre-import slot
    // and verifies it. If verification fails, the previous slot value is put back.
    function saveImportBackup(raw) {
      var prev = readBackupSlot();
      if (prev.error) return false;
      var envelope = JSON.stringify({ kind: BACKUP_KIND, savedAt: nowFn().toISOString(), raw: raw });
      try {
        storage.setItem(BACKUP_KEY, envelope);
        var back = storage.getItem(BACKUP_KEY);
        if (back === envelope && JSON.parse(back).raw === raw) return true;
      } catch (e) { /* fall through to restore the earlier slot */ }
      try {
        if (prev.value === null) { if (typeof storage.removeItem === 'function') storage.removeItem(BACKUP_KEY); }
        else storage.setItem(BACKUP_KEY, prev.value);
      } catch (e) { /* best effort */ }
      return false;
    }

    // Puts the exact previous KEY text back (never the envelope), or removes
    // KEY if there was none. Returns true only if verified.
    function rollback(raw) {
      try {
        if (raw === null) {
          storage.removeItem(KEY);
          var gone = storage.getItem(KEY);
          return gone === null || gone === undefined;
        }
        storage.setItem(KEY, raw);
        return storage.getItem(KEY) === raw;
      } catch (e) { return false; }
    }

    function sameCounts(a, b) {
      if (!a || typeof a !== 'object') return false;
      return TYPES.every(function (t) { return a[t] === b[t]; });
    }

    function previewImport(text) {
      var p;
      try { p = parseImport(text, nowFn()); } catch (e) { return importFail('not_json', 'This file could not be read.'); }
      if (!p.ok) return p;
      var s = readState();
      if (STORAGE_FAIL[s.state]) return importFail(STORAGE_FAIL[s.state][0], STORAGE_FAIL[s.state][1]);
      var partialCount = p.data.workouts.filter(function (w) { return w.partial === true; }).length;
      return {
        ok: true,
        preview: {
          version: p.data.version,
          exportedAt: p.exportedAt,
          counts: countLists(p.data),
          partialCount: partialCount,
          current: currentCounts(s),
          currentState: s.state,
          warnings: p.warnings
        }
      };
    }

    function applyImportUnsafe(text, opts) {
      if (!opts || opts.confirm !== 'REPLACE') {
        return applyFail('not_confirmed', 'Not restored: the replace was not confirmed.');
      }
      var p = parseImport(text, nowFn());
      if (!p.ok) return applyFail(p.code, p.message, { errors: p.errors });
      var s = readState();
      if (STORAGE_FAIL[s.state]) return applyFail(STORAGE_FAIL[s.state][0], STORAGE_FAIL[s.state][1]);
      if (!sameCounts(opts.expectCurrent, currentCounts(s))) {
        return applyFail('stale_plan', 'Not restored: your data changed since the preview. Choose the file again.');
      }
      var raw = s.raw === undefined ? null : s.raw;
      if (s.state === 'corrupt') preserveCorrupt(raw); // best effort; the pre-import slot keeps it too

      if (!saveImportBackup(raw)) {
        return applyFail('backup_failed', 'Not restored: a safety copy of your current data could not be saved (storage full or blocked). Nothing was changed.');
      }

      var json = JSON.stringify(p.data);
      var code = null, after = null;
      try {
        storage.setItem(KEY, json);
      } catch (e) { code = 'write_failed'; }
      if (!code) {
        var back;
        try { back = storage.getItem(KEY); } catch (e) { back = null; }
        after = back === json ? readState() : null;
        if (!after || after.state !== 'ok' || !sameCounts(countLists(p.data), countLists(after.data))) code = 'verify_failed';
      }
      if (!code) return { ok: true, counts: countLists(after.data), backupKey: BACKUP_KEY };

      if (rollback(raw)) {
        return applyFail(code, code === 'write_failed'
          ? 'Not restored: the backup could not be saved on this device (storage full or blocked). Your previous data was put back.'
          : 'Not restored: the saved data did not check out. Your previous data was put back.',
        { rolledBack: true, backupKey: BACKUP_KEY });
      }
      return applyFail('rollback_failed', 'Not restored, and your previous data could not be put back automatically. It is kept in this browser under ' + BACKUP_KEY + '. Do not clear site data.',
        { rolledBack: false, backupKey: BACKUP_KEY });
    }

    function applyImport(text, opts) {
      try { return applyImportUnsafe(text, opts); } catch (e) {
        // Should be unreachable; never throw and never report success.
        return applyFail('write_failed', 'Not restored: an unexpected error occurred.');
      }
    }

    function importBackupInfo() {
      if (!persistent) return null;
      var slot = readBackupSlot();
      if (slot.error || slot.value === null) return null;
      var env;
      try { env = JSON.parse(slot.value); } catch (e) { env = null; }
      if (!env || typeof env !== 'object' || env.kind !== BACKUP_KIND) return { key: BACKUP_KEY, savedAt: null, counts: null };
      var counts = null;
      if (typeof env.raw === 'string' && env.raw !== '') {
        var c = classifyRaw(env.raw);
        if (c.state === 'ok') counts = countValid(c.data);
      }
      return { key: BACKUP_KEY, savedAt: typeof env.savedAt === 'string' ? env.savedAt : null, counts: counts };
    }

    function add(type, input, rules) {
      var res = runRules(input, rules);
      if (res.errors) return { ok: false, errors: res.errors };
      var entry = { id: newId(), createdAt: nowFn().toISOString() };
      Object.keys(res.value).forEach(function (k) { entry[k] = res.value[k]; });
      var w = loadForWrite();
      if (w.error) return { ok: false, errors: { storage: w.error } };
      w.data[type].push(entry);
      if (!save(w.data)) return { ok: false, errors: { storage: MSG.write } };
      return { ok: true, entry: entry };
    }

    function dateRule(v) { return vDate(v, nowFn()); }

    function sortNewest(arr) {
      return arr
        .map(function (e, i) { return { e: e, i: i }; })
        .sort(function (a, b) {
          if (a.e.date !== b.e.date) return a.e.date < b.e.date ? 1 : -1;
          var ca = String(a.e.createdAt || ''), cb = String(b.e.createdAt || '');
          if (ca !== cb) return ca < cb ? 1 : -1;
          return b.i - a.i;
        })
        .map(function (x) { return x.e; });
    }

    return {
      addWeight: function (input) {
        return add('weight', input, {
          date: dateRule,
          kg: function (v) { return vNumber(v, { label: 'Weight', min: 20, max: 400, oneDecimal: true }); }
        });
      },
      addWorkout: function (input) {
        return add('workouts', input, {
          date: dateRule,
          activity: function (v) { return vText(v, { label: 'Activity', max: 60, required: true }); },
          durationMin: function (v) { return vNumber(v, { label: 'Duration', min: 1, max: 600, integer: true }); },
          partial: function (v) { return vBool(v, 'Partial'); },
          notes: function (v) { return vText(v, { label: 'Notes', max: 500 }); }
        });
      },
      addNutrition: function (input) {
        return add('nutrition', input, {
          date: dateRule,
          label: function (v) { return vText(v, { label: 'Label', max: 60 }); },
          calories: function (v) { return vNumber(v, { label: 'Calories', min: 0, max: 10000, integer: true }); },
          proteinG: function (v) { return vNumber(v, { label: 'Protein', min: 0, max: 1000, oneDecimal: true }); }
        });
      },
      list: function (type) {
        if (TYPES.indexOf(type) === -1) return [];
        return sortNewest(load()[type]);
      },
      remove: function (type, id) {
        if (TYPES.indexOf(type) === -1) return false;
        var s = readState();
        if (s.state !== 'ok') return false; // never rewrite damaged/unknown storage
        var data = s.data;
        var before = data[type].length;
        data[type] = data[type].filter(function (e) { return !(isValidEntry(e) && e.id === id); });
        if (data[type].length === before) return false;
        return save(data);
      },
      // Storage health for the UI. ok=false means saving is blocked or data could not be read.
      status: function () {
        var s = readState();
        var recovery = null;
        if (persistent) {
          try { recovery = storage.getItem(RECOVERY_KEY); } catch (e) { recovery = null; }
        }
        return {
          persistent: persistent,
          state: s.state,
          ok: s.state === 'ok' || s.state === 'empty',
          recoveryKey: recovery !== null && recovery !== undefined ? RECOVERY_KEY : null,
          importBackup: importBackupInfo()
        };
      },
      dailyNutritionTotals: function () {
        var by = {};
        load().nutrition.forEach(function (e) {
          var t = by[e.date] || (by[e.date] = { date: e.date, calories: 0, proteinG: 0, count: 0 });
          t.calories += Number(e.calories) || 0;
          t.proteinG += Number(e.proteinG) || 0;
          t.count += 1;
        });
        return Object.keys(by).sort().reverse().map(function (d) {
          by[d].proteinG = Math.round(by[d].proteinG * 10) / 10;
          return by[d];
        });
      },
      // Read-only; never throws. Tells the UI how many entries an export leaves out.
      exportSummary: function () {
        var s;
        try { s = readState(); } catch (e) { s = { state: 'unreadable' }; }
        if (s.state !== 'ok' && s.state !== 'empty') return { included: null, omitted: null, state: s.state };
        var all = countLists(s.data), included = countValid(s.data), omitted = {};
        TYPES.forEach(function (t) { omitted[t] = all[t] - included[t]; });
        return { included: included, omitted: omitted };
      },
      previewImport: previewImport,
      applyImport: applyImport,
      exportJSON: function () {
        var s = readState();
        if (s.state === 'unavailable') throw new Error('storage is unavailable in this browser, so there is no saved data to export.');
        if (s.state === 'unreadable') throw new Error('saved data could not be read. Reload and try again.');
        if (s.state === 'corrupt' || s.state === 'newer') {
          throw new Error('saved data is damaged or from a newer app version and was not exported. It has been kept, not deleted.');
        }
        var data = load();
        return JSON.stringify({
          app: 'hyrox-app',
          exportedAt: nowFn().toISOString(),
          version: VERSION,
          weight: data.weight,
          workouts: data.workouts,
          nutrition: data.nutrition
        }, null, 2);
      }
    };
  }

  return {
    todayQatar: todayQatar, createStore: createStore, STORAGE_KEY: KEY, RECOVERY_KEY: RECOVERY_KEY, VERSION: VERSION,
    IMPORT_BACKUP_KEY: BACKUP_KEY, IMPORT_LIMITS: IMPORT_LIMITS
  };
});
