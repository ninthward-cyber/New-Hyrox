S0 / D4 Garmin fixtures — 24 Nov 2026 Asia/Qatar.
ALL FILES ARE SYNTHETIC. No real Garmin data, keys or tokens. Official field names where the schema is known.

Governing spec: Command Center D1–D4 disposition (24 Nov 2026) and Claude independent review v1.0.
This pack supersedes earlier research ZIPs for weight tests (those 2025 epochs are kept only as weight-range-sample-BAD-2025-epochs.json).

G-TZ-08 gold (unchanged from the 23 Nov corrected pack): local midnight = previous day 21:00 GMT.
G-TZ-09: calendarDate vs chronology mismatch; uuid is deliberately not hex — never validate uuid format.
G-TZ-03 text: Europe/London (UTC+0 in November) holds the fetch. Do not call inverted GMT 00:00 / local 03:00 'Qatar-shaped'.

Weight gold uses 2026 Qatar morning instants (2026-11-20 06:00 Qatar = 1795143600000).
Proxy expectations: 31 inclusive days; tokenCached removed.
D3 today-in-progress: inject todayQatar=2026-11-23; midnight boundary is 2026-11-23T21:00:00Z.

Run the independent checker under TZ=UTC and TZ=America/Los_Angeles:
  python3 -I qa/s0/build_and_check_fixtures.py --check qa/s0/fixtures
Per-file expected outcomes: qa/s0/FIXTURE-OUTCOMES.json and SHA256SUMS.txt.
