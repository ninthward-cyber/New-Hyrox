'use strict';
// P0 sprint (23 Nov 2026): SYNTHETIC model outputs for the photo + note bug. Photo shows ONLY strawberry yogurt; the note
// says "3 eggs, 2 pork patties, and strawberry yogurt". No real photo, no real model answer, no owner data.
// Each value is the JSON text an OpenAI Responses call would carry in output_text (strict schema shape).
const NOTE = '3 eggs, 2 pork patties, and strawberry yogurt';
const yogurt = (basis) => ({ name: 'Strawberry yogurt', role: 'MAIN', ...(basis ? { basis } : {}), preparation: 'flavoured, cup', portion: 'about one cup (150 g)', notVisible: false,
  kcal: 150, proteinG: 6, carbsG: 25, fatG: 3, confidence: 'MEDIUM', uncertainty: 'brand and fat level unknown' });
const eggs = (basis, over = {}) => ({ name: 'Eggs', role: 'MAIN', ...(basis ? { basis } : {}), preparation: null, portion: '3 eggs', notVisible: false,
  kcal: 216, proteinG: 19, carbsG: 1, fatG: 15, confidence: 'MEDIUM', uncertainty: 'size and cooking method not stated; assumed large, cooked without added fat', ...over });
const patties = (basis, over = {}) => ({ name: 'Pork patties', role: 'MAIN', ...(basis ? { basis } : {}), preparation: null, portion: '2 patties', notVisible: false,
  kcal: 400, proteinG: 22, carbsG: 1, fatG: 34, confidence: 'LOW', uncertainty: 'patty size not stated; assumed about 45 g cooked each', ...over });
const out = (items, warnings = []) => JSON.stringify({ items, warnings });
module.exports = {
  NOTE,
  // What the RC3 contract invites: only the visible food (the note is "context"). Saved as yogurt only on RC3.
  YOGURT_ONLY: out([yogurt(null)]),
  // The other RC3 path: the model lists the note foods but flags them notVisible (they are not in the photo);
  // RC3's normaliser then nulls their numbers, so only the yogurt counts.
  NOTVISIBLE_OLD: out([eggs(null, { notVisible: true }), patties(null, { notVisible: true }), yogurt(null)]),
  // The same answer under the new contract (basis given): note foods keep their labelled estimates.
  NOTVISIBLE_NOTE: out([eggs('NOTE', { notVisible: true }), patties('NOTE', { notVisible: true, confidence: 'HIGH' }), yogurt('BOTH')]),
  // The fixed contract's expected answer: three distinct foods, yogurt once.
  COMBINED: out([eggs('NOTE'), patties('NOTE'), yogurt('BOTH')], ['Patty size was not stated.']),
  // Model double-counts the yogurt (once as seen, once as named).
  DOUBLE_YOGURT: out([eggs('NOTE'), patties('NOTE'), yogurt('PHOTO'), { ...yogurt('NOTE'), portion: 'one cup (from note)' }]),
  // Model cannot estimate the patties at all: numbers stay null (unknown), never 0.
  PATTIES_UNKNOWN: out([eggs('NOTE'), patties('NOTE', { kcal: null, proteinG: null, carbsG: null, fatG: null, uncertainty: 'patty size and type unknown' }), yogurt('BOTH')]),
  // "2 strawberry yogurts" with one cup pictured: ONE item that follows the note's count.
  TWO_YOGURTS: out([{ ...yogurt('BOTH'), portion: '2 cups (note says 2; 1 pictured)', kcal: 300, proteinG: 12, carbsG: 50, fatG: 6 }]),
  // Pictured-only foods: nothing in the note names them.
  PICTURED_ONLY: out([yogurt('PHOTO'), { name: 'Black coffee', role: 'DRINK', basis: 'PHOTO', preparation: null, portion: 'one mug', notVisible: false, kcal: 5, proteinG: 0, carbsG: 1, fatG: 0, confidence: 'MEDIUM', uncertainty: null }]),
  // Note-only meal answer when the model obeys nothing in an injected instruction (it still lists the eggs).
  INJECTION_OK: out([eggs('NOTE'), yogurt('BOTH')]),
  // An invalid basis value: the whole answer is refused (never partly used).
  BAD_BASIS: out([{ ...yogurt('BOTH'), basis: 'GUESS' }]),
};
