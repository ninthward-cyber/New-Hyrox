"""Generates SYNTHETIC food-photo fixtures (drawn, not real photos). No people, places or personal data.
Run: python3 tests/fixtures/make_fixtures.py
"""
import random
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter

OUT = Path(__file__).parent
random.seed(7)


def plate():
    img = Image.new("RGB", (800, 600), (92, 64, 44))
    d = ImageDraw.Draw(img)
    for _ in range(4000):  # wood-like texture
        x, y = random.randint(0, 799), random.randint(0, 599)
        c = random.randint(70, 110)
        d.point((x, y), fill=(c, int(c * 0.7), int(c * 0.5)))
    d.ellipse((120, 60, 680, 560), fill=(238, 238, 232), outline=(200, 200, 195), width=6)
    d.ellipse((170, 110, 630, 510), fill=(246, 246, 242))
    for _ in range(900):  # rice grains
        x, y = random.randint(220, 400), random.randint(200, 430)
        d.ellipse((x, y, x + 9, y + 4), fill=(252, 250, 240), outline=(225, 222, 205))
    for i in range(3):  # grilled chicken pieces with grill marks
        x0, y0 = 410 + i * 25, 180 + i * 80
        d.rounded_rectangle((x0, y0, x0 + 170, y0 + 70), radius=25, fill=(205, 150, 90), outline=(160, 100, 50), width=3)
        for k in range(4):
            d.line((x0 + 20 + k * 38, y0 + 8, x0 + 5 + k * 38, y0 + 62), fill=(110, 65, 30), width=6)
    for _ in range(25):  # green herbs
        x, y = random.randint(230, 600), random.randint(150, 470)
        d.ellipse((x, y, x + 12, y + 7), fill=(60, 140, 60))
    return img.filter(ImageFilter.GaussianBlur(0.6))


def exif_with_gps():
    ex = Image.Exif()
    ex[0x010F] = "SyntheticCam"          # Make
    ex[0x0110] = "FixtureModel"          # Model
    ex[0x0132] = "2026:11:11 12:00:00"   # DateTime
    gps = {1: "N", 2: (25.0, 17.0, 0.0), 3: "E", 4: (51.0, 31.0, 0.0)}  # synthetic coordinates
    ex[0x8825] = gps
    return ex


if __name__ == "__main__":
    img = plate()
    img.save(OUT / "synthetic-food-exif.jpg", format="JPEG", quality=88, exif=exif_with_gps().tobytes(), comment=b"synthetic fixture comment")
    img.save(OUT / "synthetic-food-clean.png", format="PNG")
    (OUT / "not-an-image.jpg").write_bytes(b"this is not a jpeg")
    print("fixtures written")
