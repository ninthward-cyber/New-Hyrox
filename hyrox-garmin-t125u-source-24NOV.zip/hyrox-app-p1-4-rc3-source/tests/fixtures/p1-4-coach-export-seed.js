'use strict';
// Sprint D (P1.4) synthetic seed: built through the real data layer's putRecord so every record is valid as stored.
// SYNTHETIC ONLY. Markers (FT-...) are planted in every free-text field to prove they never leak unless Free-text is on.
const path = require('path');
const HD = require(path.resolve(__dirname, '../../src/data/hyrox-data.js'));
const HN = require(path.resolve(__dirname, '../../src/data/hyrox-nutrition.js'));

const mem = (init) => { const m = Object.assign({}, init || {}); return { m, getItem(k) { return Object.prototype.hasOwnProperty.call(m, k) ? m[k] : null; }, setItem(k, v) { m[k] = String(v); }, removeItem(k) { delete m[k]; } }; };
const NOW = new Date('2026-11-18T09:00:00.000Z'); // Wed 18 Nov 2026, 12:00 Qatar
const K = (v) => ({ value: v, state: 'KNOWN' }), E = (v) => ({ value: v, state: 'ESTIMATED' }), U = () => ({ value: null, state: 'UNKNOWN' });
const ts = (d, hh) => d + 'T' + (hh || '06') + ':00:00.000Z';
const MARKERS = ['FT-SESSION-NOTE', 'FT-MEAL-DESC', 'FT-MEAL-LABEL', 'FT-BODY-NOTE', 'FT-DAILY-NOTE', 'FT-WALK-NOTE', 'FT-BLOCK-NOTE', 'FT-PORTION', 'FT-DRAFT-NAME', 'FT-WORKOUT-NOTE'];
const SECRETS = { ownerCode: 'OWNER-CODE-SYNTH-7731', aiSettings: '{"provider":"live","privacyAckAt":"2026-11-10T00:00:00.000Z","secretMarker":"AI-SETTINGS-SYNTH"}', preImport: '{"note":"PRE-IMPORT-SYNTH data:image/jpeg;base64,AAAA"}' };

function seed(opts) {
  opts = opts || {};
  const s = mem();
  const st = HD.createStore(s, { now: () => NOW });
  const put = (t, r) => { const res = st.putRecord(t, r); if (!res.ok) throw new Error(t + ' ' + JSON.stringify(res.errors)); return res.entry; };
  const ok = (r) => { if (r && r.ok === false) throw new Error(JSON.stringify(r)); return r; };
  // classic lists
  ok(st.addWeight({ date: '2026-11-16', kg: '98.4' }));
  ok(st.addWeight({ date: '2026-11-18', kg: '98.0' }));
  ok(st.addWeight({ date: '2026-11-01', kg: '99.9' })); // out of range for a 14-day window ending 18 Nov
  ok(st.addWorkout({ date: '2026-11-17', activity: 'Bike', durationMin: '30', notes: 'FT-WORKOUT-NOTE' }));
  ok(st.addNutrition({ date: '2026-11-17', calories: '600', proteinG: '40', label: 'FT-MEAL-LABEL quick' }));
  // sessions
  put('sessions', { id: 's-c1', date: '2026-11-16', title: 'Strength A', status: 'COMPLETED', modified: false, variant: 'ORIGINAL_60', planSlotId: 'v2.1-W1-MON', planVersion: 'v2.1', scheduledDate: '2026-11-16',
    durationMin: 58, rpe: 7, notes: 'FT-SESSION-NOTE', blocks: [{ kind: 'strength_set', label: 'Back squat', exercise: 'Back squat', sets: 3, reps: 5, loadKg: 80, rpe: 7, notes: 'FT-BLOCK-NOTE' }] });
  put('sessions', { id: 's-p1', date: '2026-11-17', title: 'Intervals', status: 'PARTIAL', modified: true, variant: 'ORIGINAL_60', planSlotId: null, planVersion: null, scheduledDate: null, durationMin: 20, rpe: 6, notes: '', blocks: [] });
  // meals: confirmed with unknown oil (D2 day), confirmed complete (D5 day with attestation), draft, consumed intent, explicit 0
  const comp = (name, role, kc, p, c, f, extra) => Object.assign({ name, role, portion: 'FT-PORTION 1 cup', preparation: '', eatenFraction: null, kcal: kc, proteinG: p, carbsG: c, fatG: f }, extra || {});
  put('meals', { id: 'm-c1', date: '2026-11-16', time: '13:10', label: 'FT-MEAL-LABEL', description: 'FT-MEAL-DESC chicken rice', source: 'DESCRIPTION', lifecycle: 'CONFIRMED', confirmedAt: ts('2026-11-16', '10'), mealCategory: 'LUNCH',
    components: [comp('Chicken breast, grilled', 'MAIN', E(330), E(62), E(0), E(7.2)), comp('White rice, cooked', 'SIDE', E(205), E(4.3), E(44.5), E(0.4)), comp('Cooking oil', 'OIL', U(), U(), U(), U())] });
  put('meals', { id: 'm-c2', date: '2026-11-17', time: '08:00', label: '', description: '', source: 'MANUAL', lifecycle: 'CONFIRMED', confirmedAt: ts('2026-11-17'), mealCategory: 'BREAKFAST',
    components: [comp('Boiled egg', 'MAIN', K(310), K(25), K(1.6), K(21)), comp('Black coffee', 'DRINK', K(0), K(0), K(0), K(0))] });
  put('meals', { id: 'm-d1', date: '2026-11-17', time: '19:00', label: '', description: '', source: 'MANUAL', lifecycle: 'DRAFT', mealCategory: 'DINNER',
    components: [comp('FT-DRAFT-NAME pasta', 'MAIN', E(700), E(20), E(100), E(20))] });
  if (!opts.noAttest) {
    const meals = st.records('meals').concat(st.list('nutrition').map(HN.legacyToMeal));
    // 17 Nov declared complete: m-c2 is complete, but the classic quick entry (600 kcal) and a draft exist -> app decides the code.
    put('dayStates', { date: '2026-11-17', attestation: 'COMPLETE', basis: HN.dayState('2026-11-17', meals, null).basis });
  }
  // body / daily / walks / plan events
  put('body', { date: '2026-11-16', metric: 'waist_cm', state: 'OBSERVED', value: 101.5, notes: 'FT-BODY-NOTE' });
  put('daily', { date: '2026-11-16', steps: { state: 'OBSERVED', value: 7240 }, sleepH: { state: 'OBSERVED', value: 6.5 }, readiness: { state: 'OBSERVED', value: 6 },
    pain: { state: 'OBSERVED', value: 2 }, footPain: { state: 'OBSERVED', value: 1 }, rhr: { state: 'OBSERVED', value: 61 }, notes: 'FT-DAILY-NOTE' });
  put('daily', { date: '2026-11-17', steps: { state: 'MISSING', value: null } });
  put('walks', { date: '2026-11-17', durationMin: 40, steps: 4200, stepsSource: 'DEVICE', notes: 'FT-WALK-NOTE' });
  if (opts.secrets !== false) { s.setItem('hyrox.ai-owner-code', SECRETS.ownerCode); s.setItem('hyrox.ai-settings', SECRETS.aiSettings); s.setItem(HD.IMPORT_BACKUP_KEY, SECRETS.preImport); s.setItem('hyrox.ui.workout-draft', '{"savedAt":"2026-11-18T08:00:00.000Z","ws":{"title":"DRAFT-WORKOUT-SYNTH","blocks":[]}}'); }
  return { s, st, NOW };
}
module.exports = { seed, mem, MARKERS, SECRETS, NOW };
