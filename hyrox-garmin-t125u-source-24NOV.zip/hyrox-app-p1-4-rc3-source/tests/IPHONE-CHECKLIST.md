# iPhone Safari checklist (HYROX tracker)

Use a real iPhone (Safari). Work through each item and tick it only if it passes. Use made-up values only (for example weight 72.5 kg, a 45-minute "SkiErg intervals" session, and a "Test oats" meal at 350 kcal / 22.5 g protein).

## Add entries

- [ ] Log a weight (date + kg) and see it in the list.
- [ ] Log a full workout (activity, duration, notes) and see it in the list.
- [ ] Log a partial workout; a partial badge is visible on that entry.
- [ ] Log a meal with calories and protein and see it in the list.

## Persistence

- [ ] Refresh the page (or close and reopen the tab). All of the entries above are still there.

## Totals and export

- [ ] Daily nutrition totals match the meals logged for that day (calories, protein, and count).
- [ ] Export downloads a JSON file that contains the weight, workouts, and nutrition lists.

## Input focus (no zoom)

- [ ] Tapping any text or number input does not zoom the page. Inputs must use a font size of at least 16px.

## Notes

Record the iOS / Safari version, any failure (what you typed, what you expected, what you saw), and a screenshot if something looks wrong.
