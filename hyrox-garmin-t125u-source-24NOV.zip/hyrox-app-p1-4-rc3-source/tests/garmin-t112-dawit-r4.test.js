'use strict';
// t112b Dawit R4-D1 / R4-D2 fail-first tests. Synthetic only; no network.
// Includes Dawit's official probe case B-verify-mismatch-first-day-leftover-KEY.
const test = require('node:test');
const assert = require('node:assert/strict');
const { requireGarmin, loadData } = require('./garmin-helpers');

const G = requireGarmin();
const HD = loadData();
const QA = { timeZone: 'Asia/Qatar' };
const TODAY = '2026-11-24';
const NOW = () => new Date('2026-11-24T06:00:00.000Z');
const PAST = '2026-11-22';

function mem() {
  const m = new Map();
  return {
    getItem: (k) => (m.has(k) ? m.get(k) : null),
    setItem: (k, v) => m.set(k, String(v)),
    removeItem: (k) => m.delete(k),
    keys: () => [...m.keys()]
  };
}
function v2doc(over) {
  return Object.assign({
    version: 2, weight: [], workouts: [], nutrition: [],
    sessions: [], meals: [], body: [], daily: [], walks: [],
    dayStates: [], planEvents: [], ownerSettings: []
  }, over || {});
}
function store(doc) {
  const s = mem();
  if (doc !== null) s.setItem(HD.STORAGE_KEY, JSON.stringify(doc));
  return { storage: s, api: HD.createStore(s, { now: NOW }), raw: () => s.getItem(HD.STORAGE_KEY), data: () => JSON.parse(s.getItem(HD.STORAGE_KEY) || 'null') };
}
function chron(date) {
  const [y, m, d] = date.split('-').map(Number);
  const localStart = new Date(Date.UTC(y, m - 1, d, 0, 0, 0));
  const gmtStart = new Date(localStart.getTime() - 3 * 3600 * 1000);
  const pad = (n) => String(n).padStart(2, '0');
  const fmt = (dt, withTime) => dt.getUTCFullYear() + '-' + pad(dt.getUTCMonth() + 1) + '-' + pad(dt.getUTCDate()) + 'T' + withTime;
  return {
    startTimestampGmt: fmt(gmtStart, '21:00:00.0'),
    startTimestampLocal: fmt(localStart, '00:00:00.0'),
    endTimestampGmt: fmt(new Date(gmtStart.getTime() + 23 * 3600 * 1000 + 59 * 60 * 1000), '20:59:00.0'),
    endTimestampLocal: fmt(localStart, '23:59:00.0'),
    totalDurationInMillis: 86340000
  };
}
function dailyRow(date, over) {
  return Object.assign({
    calendarDate: date, source: 'garmin', uuid: 'syn-uuid-' + date, includesWellnessData: true,
    movement: { steps: { value: 8421, goal: 10000 } },
    intensityMinutes: { moderate: 20, vigorous: 8 },
    wellnessChronology: chron(date)
  }, over || {});
}
function dailyPayload(rows) { return { data: rows }; }
function ctx(over) {
  return Object.assign({ settings: QA, todayQatar: TODAY, nowIso: '2026-11-24T06:00:00.000Z' }, over);
}

function corruptSettingsDoc() {
  return v2doc({
    daily: [{
      id: 'daily-' + PAST, date: PAST, createdAt: PAST + 'T05:00:00.000Z',
      steps: { state: 'OBSERVED', value: 8421, source: 'GARMIN_PERSONAL_API' }
    }],
    ownerSettings: [{ id: 'app-settings', date: PAST, createdAt: PAST + 'T05:00:00.000Z', garminLedger: 'not-an-object' }]
  });
}

test('Dawit R4-D1 / B-verify-mismatch-first-day-leftover-KEY: first-day verify mismatch removes hyrox.v1', () => {
  // Dawit's probe (r4-dawit-probe.js): setItem stores, getItem returns a different string.
  // On 0d1aba8 this left a stray v2 document and claimed rolledBack: true.
  const s = mem();
  const real = new Map();
  s.setItem = function (k, v) { real.set(k, String(v)); };
  s.getItem = function (k) {
    if (!real.has(k)) return null;
    if (k === HD.STORAGE_KEY) return real.get(k) + ' '; // fail read-back verify
    return real.get(k);
  };
  s.removeItem = function (k) { real.delete(k); };
  s.keys = function () { return [...real.keys()]; };
  const api = HD.createStore(s, { now: NOW });
  const r = G.applyMerge(api, { applySteps: { [PAST]: true } }, ctx({ dailyPayload: dailyPayload([dailyRow(PAST)]) }));
  const leftover = real.get(HD.STORAGE_KEY);
  assert.equal(r.ok, false);
  assert.equal(r.wrote, false);
  assert.equal(r.code, 'save_failed');
  assert.equal(leftover, undefined, 'hyrox.v1 must be removed when the pre-write snapshot was null');
  assert.equal(real.has(HD.STORAGE_KEY), false);
  assert.equal(r.rolledBack, true, 'rolledBack is true only after KEY is actually absent again');
  assert.equal(s.getItem(HD.IMPORT_BACKUP_KEY), null);
  assert.equal(s.getItem(HD.RECOVERY_KEY), null);
  assert.deepEqual(s.keys(), []);
});

test('Dawit R4-D1: quota throw before a completed setItem still leaves an empty store empty', () => {
  const s = mem();
  const innerSet = s.setItem.bind(s);
  s.setItem = function (k, v) {
    if (k === HD.STORAGE_KEY) throw new Error('QuotaExceededError');
    return innerSet(k, v);
  };
  const api = HD.createStore(s, { now: NOW });
  const r = G.applyMerge(api, { applySteps: { [PAST]: true } }, ctx({ dailyPayload: dailyPayload([dailyRow(PAST)]) }));
  assert.equal(r.ok, false);
  assert.equal(r.wrote, false);
  assert.equal(r.code, 'save_failed');
  assert.equal(s.getItem(HD.STORAGE_KEY), null);
  assert.equal(s.getItem(HD.IMPORT_BACKUP_KEY), null);
  assert.equal(s.getItem(HD.RECOVERY_KEY), null);
  assert.deepEqual(s.keys(), []);
  assert.equal(r.rolledBack, true);
});

test('Dawit R4-D1: existing-store verify mismatch restores the snapshot and does not removeItem', () => {
  const t = store(v2doc({ weight: [{ id: 'w1', createdAt: '2026-11-01T00:00:00.000Z', date: '2026-11-01', kg: 80 }] }));
  const before = t.raw();
  let removed = false;
  const innerRemove = t.storage.removeItem.bind(t.storage);
  t.storage.removeItem = function (k) {
    if (k === HD.STORAGE_KEY) removed = true;
    return innerRemove(k);
  };
  const innerGet = t.storage.getItem.bind(t.storage);
  t.storage.getItem = function (k) {
    const v = innerGet(k);
    if (k === HD.STORAGE_KEY && v && String(v).indexOf('8421') !== -1) return v + ' ';
    return v;
  };
  const r = G.applyMerge(t.api, { applySteps: { [PAST]: true } }, ctx({ dailyPayload: dailyPayload([dailyRow(PAST)]) }));
  assert.equal(r.ok, false);
  assert.equal(r.wrote, false);
  assert.equal(r.code, 'save_failed');
  assert.equal(t.raw(), before, 'populated diary is restored, not deleted');
  assert.equal(JSON.parse(t.raw()).weight[0].kg, 80);
  assert.equal(removed, false, 'P6-DL-6: populated KEY is not removed');
  assert.equal(r.rolledBack, true);
  assert.equal(t.storage.getItem(HD.IMPORT_BACKUP_KEY), null);
});

test('Dawit R4-D2: LEDGER_CORRUPT delete wording names settings and says nothing was deleted', () => {
  const t = store(corruptSettingsDoc());
  const before = t.raw();
  assert.equal(t.api.removeRecord('daily', 'daily-' + PAST), false);
  assert.equal(t.raw(), before);
  const last = t.api.lastRemoveResult();
  assert.equal(last.reason, 'LEDGER_CORRUPT');
  assert.match(last.message, /Garmin import links in your settings could not be read/i);
  assert.match(last.message, /Nothing was deleted/);
  assert.doesNotMatch(last.message, /this check-in/i);
  assert.doesNotMatch(last.message, /Nothing was changed/);
});

test('Dawit R4-D2: LEDGER_CORRUPT apply wording names settings and says nothing was changed', () => {
  const t = store(corruptSettingsDoc());
  const before = t.raw();
  const r = G.applyMerge(t.api, { applySteps: { [PAST]: true } }, ctx({ dailyPayload: dailyPayload([dailyRow(PAST)]) }));
  assert.equal(r.ok, false);
  assert.equal(r.wrote, false);
  assert.equal(r.code, 'LEDGER_CORRUPT');
  assert.equal(t.raw(), before);
  assert.match(r.message, /Garmin import links in your settings could not be read/i);
  assert.match(r.message, /Nothing was changed/);
  assert.doesNotMatch(r.message, /Nothing was deleted/);
  assert.doesNotMatch(r.message, /this check-in/i);
  const owner = G.ownerMessageForApply(r);
  assert.match(owner, /Garmin import links in your settings could not be read/i);
  assert.match(owner, /Nothing was changed/);
  assert.doesNotMatch(owner, /Nothing was deleted/);
  assert.doesNotMatch(owner, /this check-in/i);
  assert.equal(G.LEDGER_CORRUPT_OWNER, r.message);
});
