# Real iPhone Safari checklist (Phase 2 P0)

This maps one-to-one to the 6 e2e specs in `tests/e2e/p0-flows.spec.js`. Desktop WebKit and the **Chromium substitute, not Safari** project do not count as iPhone Safari. The real-iPhone check is on the owner, after a separately approved preview. Use made-up data only (examples below). Tick only what you actually see. Record iOS / Safari version.

Made-up values: weight **72.5 kg**, a **45 min** "SkiErg intervals" session, a **partial** "Half sim" (20 min), and "Test oats" at **350 kcal / 22.5 g protein**.

## 1. `logs weight, full and partial workouts, and a meal; they persist after reload`

Steps:
1. In Safari (not the Home Screen icon), open the approved preview.
2. Log the four made-up entries above (leave dates as today unless the form requires otherwise).
3. Reload the page (or close and reopen the tab).

Expected: All four entries are still listed; the Half sim row shows a Partial badge; the daily nutrition total shows 350 kcal and 22.5 g protein.

## 2. `export downloads hyrox-backup-YYYY-MM-DD.json with the logged entries`

Steps:
1. With those four entries present, tap **Export JSON backup**.
2. Open the file in Files (Downloads).

Expected: The file is named `hyrox-backup-YYYY-MM-DD.json` (today in Qatar). It is valid JSON with `app: "hyrox-app"`, `version: 1`, weight 72.5, both workouts (Half sim marked partial), and Test oats 350 / 22.5.

## 3. `text, number, date and textarea inputs use font-size of at least 16px`

Steps:
1. Tap each text, number, date, and notes field in the weight, workout, and nutrition forms.

Expected: The page does not zoom on focus. (Inputs are specified at 16px or larger.)

## 4. `import preview, cancel leaves data, confirm REPLACE restores the backup, reload holds`

Steps:
1. Export the four-entry backup and keep the file in Files.
2. Delete the 72.5 kg entry (confirm the prompt) and add a made-up weight of **80 kg**.
3. Tap **Restore from backup…**, pick the exported file, and read the preview counts (1 weight, 2 workouts, 1 nutrition, 1 partial) and the REPLACE warning.
4. Tap **Cancel**.
5. Pick the same file again and tap **Replace my data**.
6. Reload the page.

Expected: After Cancel, 80 kg is still there and 72.5 is not. After Replace, the four original entries are back (Partial badge and totals included), 80 kg is gone, and a "previous data is kept" note may appear. There is no Undo button. After reload, the restored entries remain. (After a confirm the file is discarded; you must pick it again to retry.)

## 5. `truncated, wrong-version and missing-app files are refused without data loss`

Steps:
1. Start from the four restored made-up entries.
2. Try restoring a truncated / broken `.json` text file.
3. Try a file whose `version` is 2.
4. Try a file with no `"app": "hyrox-app"` field.

Expected: Each is refused (an error, not a success). **Replace my data** is not offered (or does not apply). The four entries are unchanged after every attempt.

## 6. `a good backup (including one without a .json name) is accepted; script text does not run`

Steps:
1. Replace current logs with a made-up 80 kg-only state (or add 80 kg after clearing via a known backup).
2. Restore a valid backup whose filename has **no** `.json` extension, if you can save one that way in Files. Confirm REPLACE.
3. Restore the same good backup again (re-pick the file).
4. Restore a valid backup in which a note or meal label is the literal text `<script>…</script>` or `<img src=x onerror=…>` (typed as data, not a real script file).

Expected: The no-`.json` file still opens a preview and restores the four entries; 80 kg is gone. The second restore does not duplicate rows (still 1 weight, 2 workouts, 1 meal). The script/HTML text appears as plain text in the list; no alert or zoom-to-image, and no extra script or image appears in the page.
