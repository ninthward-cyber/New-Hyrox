'use strict';
// Claude Phase 5 independent review: regression tests. Synthetic data only.
// 1. Size-limit repair: this build's own normal backup of ~8+ months of daily logging was refused by
//    this build's own restore (too_large at 2,000,000 characters). FAILS on Grok 9ba6e34.
// 2. O1 bypass attempts and F02 fault sweeps (single and pairwise) against the data layer. These
//    PASS on 9ba6e34: they are independent verification of Grok's fixes, kept as regression guards.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const HD = require(path.resolve(__dirname, '../src/data/hyrox-data.js'));
const KEY = 'hyrox.v1', SLOT = 'hyrox.v1.pre-import-backup', REC = 'hyrox.v1.corrupt-backup';
const NOW = new Date('2026-11-12T06:00:00Z'), ts = NOW.toISOString();

// Storage with a programmable fault on the n-th operation (0-based, counting getItem/setItem/removeItem).
function faulty(init, plan) {
  const m = Object.assign({}, init || {}); let n = 0;
  const s = {
    m, ops: [],
    getItem(k) { const i = n++; s.ops.push('get ' + k); if (plan && plan.at === i) { if (plan.kind === 'getThrow') throw new Error('read'); if (plan.kind === 'getNull') return null; } return Object.prototype.hasOwnProperty.call(m, k) ? m[k] : null; },
    setItem(k, v) { const i = n++; s.ops.push('set ' + k); if (plan && plan.at === i) {
        if (plan.kind === 'setThrow') throw new Error('Quota');
        if (plan.kind === 'setDrop') return;
        if (plan.kind === 'setTorn') { m[k] = String(v).slice(0, Math.floor(String(v).length / 2)); return; }
        if (plan.kind === 'setTornThrow') { m[k] = String(v).slice(0, 7); throw new Error('Quota'); }
      } m[k] = String(v); },
    removeItem(k) { const i = n++; s.ops.push('rm ' + k); if (plan && plan.at === i && plan.kind === 'setThrow') throw new Error('rm'); delete m[k]; },
  };
  return s;
}
const mk = (s) => HD.createStore(s, { now: () => NOW });
function backupText(lists) {
  return JSON.stringify(Object.assign({ app: 'hyrox-app', version: 2, exportedAt: ts, weight: [], workouts: [], nutrition: [] }, lists || {}), null, 2);
}
const W = (id, kg) => ({ id, createdAt: ts, date: '2026-11-10', kg });
const ORIGINAL = JSON.stringify({ version: 2, weight: [W('w-orig', 80)], workouts: [], nutrition: [], walks: [{ id: 'k1', createdAt: ts, date: '2026-11-10', durationMin: 30 }] });
const FILE_A = backupText({ weight: [W('w-a', 70)] });
const FILE_B = backupText({ weight: [W('w-b', 60)] });
const EMPTY = backupText({});
function apply(st, text, extra) {
  const p = st.previewImport(text);
  if (!p.ok) return p;
  return st.applyImport(text, Object.assign({ confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt }, extra || {}));
}
// Where can the original bytes still be found?
function originalSurvives(m) {
  if (m[KEY] === ORIGINAL) return 'KEY';
  if (m[REC] === ORIGINAL) return 'RECOVERY';
  try { const e = JSON.parse(m[SLOT]); if (e.raw === ORIGINAL) return 'SLOT:' + e.restoreState; } catch (e) { /* */ }
  return null;
}

describe('O1: confirmEmptyReplace bypass attempts at the data layer', () => {
  const populated = () => faulty({ [KEY]: ORIGINAL });
  for (const [label, v] of [['string "true"', 'true'], ['1', 1], ['object', {}], ['[true]', [true]], ['Boolean object', new Boolean(true)], ['"yes"', 'yes'], ['undefined', undefined], ['null', null]]) {
    it('refuses with confirmEmptyReplace = ' + label + ' and writes nothing', () => {
      const s = populated(); const before = JSON.stringify(s.m);
      const r = apply(mk(s), EMPTY, { confirmEmptyReplace: v });
      assert.equal(r.ok, false); assert.equal(r.code, 'empty_replace_not_confirmed');
      assert.equal(JSON.stringify(s.m), before);
    });
  }
  it('a getter that says true once is read only once (no double-read trick)', () => {
    const s = populated(); let reads = 0;
    const opts = { confirm: 'REPLACE' };
    const p = mk(s).previewImport(EMPTY);
    opts.expectCurrent = p.preview.current; opts.expectCurrentExt = p.preview.currentExt;
    Object.defineProperty(opts, 'confirmEmptyReplace', { get() { reads++; return reads === 1 ? false : true; } });
    const r = mk(s).applyImport(EMPTY, opts);
    assert.equal(r.code, 'empty_replace_not_confirmed'); assert.equal(reads, 1);
  });
  it('confirm given only to preview, or preview on an empty device then data added: apply re-checks live storage', () => {
    const s = faulty();
    const st = mk(s);
    const p = st.previewImport(EMPTY);
    assert.equal(p.preview.emptyReplacesPopulated, false);
    st.addWeight({ date: '2026-11-10', kg: 80 });
    const r = st.applyImport(EMPTY, { confirm: 'REPLACE', expectCurrent: { weight: 1, workouts: 0, nutrition: 0 } });
    assert.equal(r.code, 'empty_replace_not_confirmed');
    assert.equal(mk(s).list('weight').length, 1);
  });
  it('device populated ONLY by damaged records, ONLY by settings, or ONLY by a plan event counts as populated', () => {
    for (const lists of [{ daily: ['junk'] }, { ownerSettings: [{ id: 'app-settings', createdAt: ts, date: '2026-11-10', rhrBaselineBpm: 70 }] }, { planEvents: [{ id: 'e', createdAt: ts, date: '2026-11-09', kind: 'MISSED_MONDAY', week: 1 }] }]) {
      const s = faulty({ [KEY]: JSON.stringify(Object.assign({ version: 2, weight: [], workouts: [], nutrition: [] }, lists)) });
      const r = apply(mk(s), EMPTY);
      assert.equal(r.code, 'empty_replace_not_confirmed', JSON.stringify(lists));
    }
  });
  it('an "empty" file padded with unknown top-level fields / legacy keys is still empty', () => {
    const s = faulty({ [KEY]: ORIGINAL });
    const padded = JSON.stringify({ app: 'hyrox-app', version: 2, exportedAt: ts, weight: [], workouts: [], nutrition: [], settings: { unit: 'kg' }, notes: 'x', sessions: [], meals: [] });
    const r = apply(mk(s), padded);
    assert.equal(r.code, 'empty_replace_not_confirmed');
  });
  it('a Phase 2 file with lists missing entirely is treated the same as empty', () => {
    const s = faulty({ [KEY]: ORIGINAL });
    const r = apply(mk(s), JSON.stringify({ app: 'hyrox-app', version: 1, exportedAt: ts, weight: [] }));
    assert.ok(r.code === 'empty_replace_not_confirmed' || r.ok === false, JSON.stringify(r));
    assert.equal(s.m[KEY], ORIGINAL);
  });
  it('prototype pollution of opts is a caller-environment issue (documented, not a data-file vector)', () => {
    const s = faulty({ [KEY]: ORIGINAL });
    // A backup FILE cannot set Object.prototype: its __proto__ key stays an own field.
    const evil = '{"app":"hyrox-app","version":2,"exportedAt":"' + ts + '","weight":[],"workouts":[],"nutrition":[],"__proto__":{"confirmEmptyReplace":true}}';
    const r = apply(mk(s), evil);
    assert.equal(({}).confirmEmptyReplace, undefined);
    assert.notEqual(r.ok, true);
    assert.equal(s.m[KEY], ORIGINAL);
  });
  it('with the strict true it restores, keeps a pending->completed slot holding the original', () => {
    const s = faulty({ [KEY]: ORIGINAL });
    const r = apply(mk(s), EMPTY, { confirmEmptyReplace: true });
    assert.equal(r.ok, true);
    const env = JSON.parse(s.m[SLOT]);
    assert.equal(env.raw, ORIGINAL); assert.equal(env.restoreState, 'completed');
  });
});

describe('F02: fault sweep - restore A with one fault at every storage call, then restore B with no fault', () => {
  const KINDS = ['getThrow', 'getNull', 'setThrow', 'setDrop', 'setTorn', 'setTornThrow'];
  // count ops in a clean run of restore A
  const clean = faulty({ [KEY]: ORIGINAL }); apply(mk(clean), FILE_A);
  const N = clean.ops.length;
  it('a clean restore A uses ' + N + ' storage calls (sanity)', () => { assert.ok(N > 8); });
  for (const kind of KINDS) {
    it(kind + ': original never lost unless restore A verifiably completed; B never overwrites an unresolved only-copy', () => {
      const bad = [];
      for (let at = 0; at < N + 2; at++) {
        const s = faulty({ [KEY]: ORIGINAL }, { at, kind });
        let rA; try { rA = apply(mk(s), FILE_A); } catch (e) { rA = { threw: e.message }; }
        if (rA.threw) bad.push('A threw at ' + at);
        const afterA = originalSurvives(s.m);
        const aDone = rA.ok === true && s.m[KEY] && JSON.parse(s.m[KEY]).weight[0].id === 'w-a';
        if (!afterA && !aDone) bad.push(`${kind}@${at}: original lost after A (A=${rA.code || 'ok'})`);
        if (rA.ok === true && !aDone) bad.push(`${kind}@${at}: A reported ok but KEY is not file A`);
        // restore B, clean storage behaviour
        const s2 = faulty(s.m);
        let rB; try { rB = apply(mk(s2), FILE_B); } catch (e) { rB = { threw: e.message }; }
        const afterB = originalSurvives(s2.m);
        if (!aDone && afterA && !afterB) bad.push(`${kind}@${at}: original (in ${afterA}) lost by restore B (A=${rA.code}, B=${rB.code || 'ok'})`);
        if (rB.ok === true && JSON.parse(s2.m[KEY]).weight[0].id !== 'w-b') bad.push(`${kind}@${at}: B ok but KEY wrong`);
        // an unresolved only-copy must be visible to the user in status()
        if (!aDone && afterA && afterA.startsWith('SLOT') && rB.code === 'prior_copy_unresolved') {
          const st = mk(faulty(s.m)).status();
          if (!st.priorCopy || st.priorCopy.blocksNextRestore !== true) bad.push(`${kind}@${at}: blocked but status().priorCopy does not say so`);
          const rr = mk(faulty(s.m)).rawRecoveryExport();
          const srcs = rr.ok ? HD.parseRawRecovery(rr.text).sources : [];
          if (!srcs.some((x) => x.key === SLOT && JSON.parse(x.raw).raw === ORIGINAL)) bad.push(`${kind}@${at}: raw recovery copy lacks the slot`);
        }
      }
      assert.deepEqual(bad, []);
    });
  }
});

describe('F02: double faults - one fault in A and one in B (pairwise sweep)', () => {
  it('original survives every pair unless A completed', () => {
    const clean = faulty({ [KEY]: ORIGINAL }); apply(mk(clean), FILE_A); const N = clean.ops.length + 2;
    const bad = []; let combos = 0;
    for (const k1 of ['setThrow', 'setTorn', 'getNull', 'setDrop']) for (let a = 0; a < N; a++) for (const k2 of ['setThrow', 'setTorn', 'getNull', 'setDrop']) for (let b = 0; b < N + 4; b++) {
      combos++;
      const s = faulty({ [KEY]: ORIGINAL }, { at: a, kind: k1 });
      let rA; try { rA = apply(mk(s), FILE_A); } catch (e) { rA = {}; }
      const aDone = rA.ok === true;
      const s2 = faulty(s.m, { at: b, kind: k2 });
      try { apply(mk(s2), FILE_B); } catch (e) { /* */ }
      if (!aDone && !originalSurvives(s2.m)) bad.push(`${k1}@${a} then ${k2}@${b}`);
    }
    assert.deepEqual(bad.slice(0, 10), [], combos + ' combos');
  });
});

// ---------------------------------------------------------------- size limit
function yearOfLogging(days) {
  const K = (v) => ({ value: v, state: 'KNOWN' }), O = (v) => ({ state: 'OBSERVED', value: v });
  const d = (i) => new Date(Date.UTC(2026, 10, 11) - i * 864e5).toISOString().slice(0, 10);
  const data = { version: 2, weight: [], workouts: [], nutrition: [], meals: [], daily: [], sessions: [], walks: [] };
  for (let i = 0; i < days; i++) {
    const D = d(i);
    data.weight.push({ id: 'w' + i, createdAt: ts, date: D, kg: 80 });
    data.daily.push({ id: 'daily-' + D, createdAt: ts, date: D, steps: O(8000), sleepH: O(7), soreness: O(2), rhr: O(60), readiness: O(7) });
    for (let j = 0; j < 4; j++) data.meals.push({ id: 'm' + i + '-' + j, createdAt: ts, updatedAt: ts, date: D, time: '08:00', label: 'Meal ' + j, source: 'MANUAL',
      lifecycle: 'CONFIRMED', confirmedAt: ts, eatenFraction: 1, components: [0, 1, 2].map((c) => ({ name: 'Item ' + c, role: 'MAIN', eatenFraction: null, kcal: K(300), proteinG: K(20), carbsG: K(30), fatG: K(10) })) });
    if (i % 7 < 5) data.sessions.push({ id: 's' + i, createdAt: ts, updatedAt: ts, date: D, status: 'COMPLETED', modified: false, variant: 'NONE',
      blocks: [{ kind: 'strength_set', exercise: 'Squat', sets: 3, reps: 5, loadKg: 80 }, { kind: 'run', distanceM: 1000, durationSec: 300 }] });
    data.walks.push({ id: 'k' + i, createdAt: ts, updatedAt: ts, date: D, durationMin: 30, steps: 3000 });
  }
  return JSON.stringify(data);
}

describe('REPAIR: the app can restore its own normal backup after a year of daily logging', () => {
  it('a 365-day export (~3 million characters) is reported restorable and restores exactly onto a new device', () => {
    const s = faulty({ [KEY]: yearOfLogging(365) }); const st = mk(s);
    const c = st.exportChecked();
    assert.equal(c.ok, true);
    assert.ok(c.text.length > 2000000, 'over the old 2,000,000 limit: ' + c.text.length);
    assert.deepEqual(c.reasons, []);
    assert.equal(c.restorable, true, 'was false (too_large) on 9ba6e34');
    assert.equal(st.rawRecoveryExport().normalRestorable, true);
    const s2 = faulty(); const st2 = mk(s2);
    const r = apply(st2, c.text);
    assert.equal(r.ok, true, JSON.stringify(r).slice(0, 300));
    for (const t of ['meals', 'daily', 'sessions', 'walks']) assert.deepEqual(st2.records(t), st.records(t), t);
    assert.deepEqual(st2.list('weight'), st.list('weight'));
  });
  it('the limit still refuses an oversized file before parsing it', () => {
    const orig = JSON.parse; let parsed = 0;
    JSON.parse = function () { parsed++; return orig.apply(this, arguments); };
    let r;
    try { r = mk(faulty()).previewImport('{' + ' '.repeat(HD.IMPORT_LIMITS.maxBytes) + '}'); } finally { JSON.parse = orig; }
    assert.equal(r.code, 'too_large'); assert.equal(parsed, 0);
    assert.match(r.message, /10 million characters/);
  });
  it('a valid file just under the new limit (~9.9M characters) is accepted in reasonable time', () => {
    const K = (v) => ({ value: v, state: 'KNOWN' });
    const meals = Array.from({ length: 10000 }, (_, i) => ({ id: 'm' + i, createdAt: ts, updatedAt: ts, date: '2026-11-10', label: 'Meal', source: 'MANUAL',
      lifecycle: 'CONFIRMED', confirmedAt: ts, eatenFraction: 1, components: Array.from({ length: 3 }, (_, c) => ({ name: 'Ingredient ' + c, role: 'MAIN', portion: 'one plate',
        eatenFraction: null, kcal: K(300), proteinG: K(20), carbsG: K(30), fatG: K(10) })) }));
    // compact JSON: 10,000 meals x 3 items (the per-list maximum) is just under the 10M-character limit
    const text = JSON.stringify({ app: 'hyrox-app', version: 2, exportedAt: ts, weight: [], workouts: [], nutrition: [], meals });
    assert.ok(text.length < HD.IMPORT_LIMITS.maxBytes && text.length > HD.IMPORT_LIMITS.maxBytes * 0.8, String(text.length));
    const t0 = Date.now();
    const p = mk(faulty()).previewImport(text);
    const ms = Date.now() - t0;
    assert.equal(p.ok, true, JSON.stringify(p).slice(0, 300));
    assert.ok(ms < 8000, ms + ' ms');
    console.log('# perf: ' + text.length + ' chars previewed in ' + ms + ' ms');
  });
});

describe('F02 documented behaviour: ONE failed finish-marker write leaves the slot pending (fail closed)', () => {
  // Grok's handover says a false block needs the marker write AND its repair to fail; one failure suffices,
  // because the repair puts the PENDING envelope back. The restore itself succeeded. This is not a data loss;
  // the in-app way out is an owner HOLD item. The safety properties are what is asserted here.
  it('restore reports ok, the next restore is refused, the original is still in the slot and in the raw copy', () => {
    const clean = faulty({ [KEY]: ORIGINAL }); apply(mk(clean), FILE_A);
    const markerAt = clean.ops.lastIndexOf('set ' + SLOT);
    const s = faulty({ [KEY]: ORIGINAL }, { at: markerAt, kind: 'setThrow' });
    const rA = apply(mk(s), FILE_A);
    assert.equal(rA.ok, true);
    assert.equal(JSON.parse(s.m[SLOT]).restoreState, 'pending');
    const st = mk(faulty(s.m));
    assert.equal(st.status().priorCopy.blocksNextRestore, true);
    assert.equal(apply(st, FILE_B).code, 'prior_copy_unresolved');
    assert.equal(JSON.parse(s.m[SLOT]).raw, ORIGINAL);
    assert.ok(HD.parseRawRecovery(st.rawRecoveryExport().text).sources.some((x) => x.key === SLOT && JSON.parse(x.raw).raw === ORIGINAL));
  });
});
