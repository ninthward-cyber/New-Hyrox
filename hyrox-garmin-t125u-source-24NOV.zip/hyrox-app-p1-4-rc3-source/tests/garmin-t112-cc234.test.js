'use strict';
// t112 CC #2 / #3 / #4 fail-first tests. Synthetic only; no network.
const test = require('node:test');
const assert = require('node:assert/strict');
const { requireGarmin, loadData, mem } = require('./garmin-helpers');

const G = requireGarmin();
const HD = loadData();
const QA = { timeZone: 'Asia/Qatar' };
const TODAY = '2026-11-24';
const NOW = () => new Date('2026-11-24T06:00:00.000Z');
const PAST = '2026-11-22';

function v2doc(over) {
  return Object.assign({
    version: 2, weight: [], workouts: [], nutrition: [],
    sessions: [], meals: [], body: [], daily: [], walks: [],
    dayStates: [], planEvents: [], ownerSettings: []
  }, over || {});
}
function store(doc) {
  const s = mem();
  if (doc !== null) s.setItem(HD.STORAGE_KEY, JSON.stringify(doc));
  return { storage: s, api: HD.createStore(s, { now: NOW }), raw: () => s.getItem(HD.STORAGE_KEY), data: () => JSON.parse(s.getItem(HD.STORAGE_KEY) || 'null') };
}
function chron(date) {
  // Qatar (UTC+3): local midnight of `date` is the previous day 21:00 GMT.
  const [y, m, d] = date.split('-').map(Number);
  const localStart = new Date(Date.UTC(y, m - 1, d, 0, 0, 0));
  const gmtStart = new Date(localStart.getTime() - 3 * 3600 * 1000);
  const pad = (n) => String(n).padStart(2, '0');
  const fmt = (dt, withTime) => dt.getUTCFullYear() + '-' + pad(dt.getUTCMonth() + 1) + '-' + pad(dt.getUTCDate()) + 'T' + withTime;
  return {
    startTimestampGmt: fmt(gmtStart, '21:00:00.0'),
    startTimestampLocal: fmt(localStart, '00:00:00.0'),
    endTimestampGmt: fmt(new Date(gmtStart.getTime() + 23 * 3600 * 1000 + 59 * 60 * 1000), '20:59:00.0'),
    endTimestampLocal: fmt(localStart, '23:59:00.0'),
    totalDurationInMillis: 86340000
  };
}
function dailyRow(date, over) {
  return Object.assign({
    calendarDate: date,
    source: 'garmin',
    uuid: 'syn-uuid-' + date,
    includesWellnessData: true,
    movement: { steps: { value: 8421, goal: 10000 } },
    intensityMinutes: { moderate: 20, vigorous: 8 },
    wellnessChronology: chron(date)
  }, over || {});
}
function dailyPayload(rows) { return { data: rows }; }
function settingsOf(data) {
  return ((data && data.ownerSettings) || []).filter((e) => e && e.id === 'app-settings')[0] || null;
}

test('CC #2 fail-first: a weight payload is never written and never offered', () => {
  const t = store(v2doc({
    daily: [{ id: 'daily-2026-11-22', date: PAST, createdAt: '2026-11-22T05:00:00.000Z', steps: { state: 'OBSERVED', value: 1000 } }],
    weight: [{ id: 'w-manual', createdAt: '2026-11-22T05:00:00.000Z', date: PAST, kg: 80.0 }]
  }));
  const weightPayload = {
    dailyWeightSummaries: [{ allWeightMetrics: [{ weight: 97.4, timestampGMT: Date.parse('2026-11-22T06:00:00.000Z'), calendarDate: PAST }] }]
  };
  const prev = G.preview({ settings: QA, weightPayload, storeData: t.data(), api: t.api, todayQatar: TODAY });
  assert.equal(prev.ok, true);
  assert.ok((prev.warnings || []).includes('GARMIN_WEIGHT_EXCLUDED'));
  assert.equal((prev.items || []).filter((i) => i.collection === 'weight').length, 0, 'no weight rows offered');
  const before = t.raw();
  const r = G.applyMerge(t.api, { applyWeight: { [Date.parse('2026-11-22T06:00:00.000Z')]: true }, replaceWeight: { [Date.parse('2026-11-22T06:00:00.000Z')]: true } }, {
    settings: QA, weightPayload, todayQatar: TODAY
  });
  assert.equal(r.ok, false);
  assert.equal(r.wrote, false);
  assert.equal(r.code, 'NO_ROWS');
  assert.match(G.ownerMessageForApply(r), /Weight is logged in HYROX only/i);
  assert.equal(t.raw(), before);
  assert.equal(t.data().weight.length, 1);
  assert.equal(t.data().weight[0].id, 'w-manual');
  assert.equal(t.data().weight[0].kg, 80);
});

test('CC #2: injected mappedRows.weight is ignored at preview and apply; manual weight stays', () => {
  const t = store(v2doc({
    daily: [{ id: 'daily-2026-11-22', date: PAST, createdAt: '2026-11-22T05:00:00.000Z' }],
    weight: [{ id: 'w-manual', createdAt: '2026-11-22T05:00:00.000Z', date: PAST, kg: 81.5 }]
  }));
  const mappedRows = { weight: [{ date: PAST, kg: 50, timestampGMT: 1 }], daily: [], sleep: [], activities: [] };
  const prev = G.preview({ settings: QA, mappedRows, storeData: t.data(), api: t.api, todayQatar: TODAY });
  assert.equal((prev.items || []).filter((i) => i.collection === 'weight').length, 0);
  const r = G.applyMerge(t.api, { applyWeight: { 1: true } }, { settings: QA, mappedRows, todayQatar: TODAY });
  assert.equal(r.code, 'NO_ROWS');
  assert.equal(t.data().weight[0].kg, 81.5);
});

test('CC #3 condition 1: ticked complete past date creates a real OBSERVED daily-YYYY-MM-DD only if absent', () => {
  const t = store(v2doc());
  const payload = dailyPayload([dailyRow(PAST)]);
  const prev = G.preview({ settings: QA, dailyPayload: payload, storeData: t.data(), api: t.api, todayQatar: TODAY });
  const news = prev.items.filter((i) => i.status === 'New' && (i.collection === 'steps' || i.collection === 'intensity'));
  assert.ok(news.length >= 1, JSON.stringify(prev.items));
  assert.equal(prev.items.filter((i) => i.reason === 'NO_DAILY_FOR_DATE').length, 0);
  const r = G.applyMerge(t.api, { applySteps: { [PAST]: true }, applyIntensity: { [PAST]: true } }, {
    settings: QA, dailyPayload: payload, todayQatar: TODAY, nowIso: '2026-11-24T06:00:00.000Z'
  });
  assert.equal(r.ok, true, JSON.stringify(r));
  assert.equal(r.wrote, true);
  const data = t.data();
  assert.equal(data.version, 2);
  const d = data.daily.filter((x) => x.id === 'daily-2026-11-22')[0];
  assert.ok(d, 'created standard daily id');
  assert.equal(d.date, PAST);
  assert.equal(d.steps.state, 'OBSERVED');
  assert.equal(d.steps.value, 8421);
  assert.equal(d.steps.source, 'GARMIN_PERSONAL_API');
  assert.equal(d.intensityMin.state, 'OBSERVED');
  assert.equal(d.intensityMin.source, 'GARMIN_PERSONAL_API');
  assert.equal(d.intensityMin.value, 36);
  assert.ok(d.readiness == null && d.soreness == null && d.rhr == null && d.sleepH == null, 'must not invent a filled check-in');
  const set = settingsOf(data);
  assert.ok(set && set.garminLedger, 'owner-settings created in the same save');
  assert.equal(set.id, 'app-settings');
  assert.equal((data.ownerSettings || []).length, 1);
});

test('CC #3 condition 1: today, future, sleep-only and weight never create a day', () => {
  const t = store(v2doc());
  const payload = dailyPayload([
    dailyRow(TODAY),
    dailyRow('2026-11-25'),
    Object.assign(dailyRow('2026-11-21'), { includesWellnessData: false, movement: {}, intensityMinutes: {} })
  ]);
  const r = G.applyMerge(t.api, {
    applySteps: { [TODAY]: true, '2026-11-25': true, '2026-11-21': true },
    applyIntensity: { [TODAY]: true, '2026-11-25': true, '2026-11-21': true },
    applySleep: { '2026-11-21': true }
  }, {
    settings: QA,
    dailyPayload: payload,
    sleepPayload: { calendarDate: '2026-11-21', sleepTimeSeconds: 25200 },
    todayQatar: TODAY,
    nowIso: '2026-11-24T06:00:00.000Z'
  });
  const data = t.data();
  assert.ok(!r.wrote, JSON.stringify(r));
  assert.equal((data && data.daily || []).length, 0);
});

test('CC #3 condition 2: deleting a Garmin day records a durable tombstone; preview is Deleted by you and cannot recreate', () => {
  const t = store(v2doc());
  const payload = dailyPayload([dailyRow(PAST)]);
  const created = G.applyMerge(t.api, { applySteps: { [PAST]: true } }, {
    settings: QA, dailyPayload: payload, todayQatar: TODAY, nowIso: '2026-11-24T06:00:00.000Z'
  });
  assert.equal(created.wrote, true, JSON.stringify(created));
  const id = 'daily-' + PAST;
  const ok = t.api.removeRecord('daily', id);
  assert.equal(ok, true, JSON.stringify(t.api.lastRemoveResult && t.api.lastRemoveResult()));
  const data = t.data();
  assert.equal(data.daily.length, 0);
  const led = settingsOf(data).garminLedger;
  const tombs = (led.tombstones || []).concat(
    Object.keys(led.byDate || {}).flatMap((dt) => (led.byDate[dt].tombstones || []))
  );
  assert.ok(tombs.some((x) => x.collection === 'daily' && (x.localId === id || x.date === PAST)), JSON.stringify(led));
  const prev = G.preview({ settings: QA, dailyPayload: payload, storeData: data, api: t.api, todayQatar: TODAY });
  const gone = prev.items.filter((i) => i.status === 'Deleted by you' && i.date === PAST);
  assert.ok(gone.length >= 1, JSON.stringify(prev.items));
  assert.ok(gone.every((i) => i.writable === false || i.ticked === false));
  const again = G.applyMerge(t.api, { applySteps: { [PAST]: true }, applyIntensity: { [PAST]: true } }, {
    settings: QA, dailyPayload: payload, todayQatar: TODAY, nowIso: '2026-11-24T06:00:00.000Z'
  });
  assert.ok(!again.wrote, JSON.stringify(again));
  assert.equal(t.data().daily.length, 0);
});

test('CC #3 condition 3: the last Garmin day is deletable with no ledger-carrier lockout', () => {
  const t = store(v2doc());
  G.applyMerge(t.api, { applySteps: { [PAST]: true } }, {
    settings: QA, dailyPayload: dailyPayload([dailyRow(PAST)]), todayQatar: TODAY, nowIso: '2026-11-24T06:00:00.000Z'
  });
  assert.equal(t.data().daily.length, 1);
  const ok = t.api.removeRecord('daily', 'daily-' + PAST);
  assert.equal(ok, true, JSON.stringify(t.api.lastRemoveResult && t.api.lastRemoveResult()));
  assert.equal(t.data().daily.length, 0);
  assert.ok(settingsOf(t.data()).garminLedger);
});

test('CC #3 / #4 condition 4: first-day atomic create on a fresh empty store; refuse schema-1, corrupt, newer, pending restore', () => {
  // empty store
  const empty = store(null);
  assert.equal(empty.raw(), null);
  const slotBefore = empty.storage.getItem(HD.IMPORT_BACKUP_KEY);
  const r = G.applyMerge(empty.api, { applySteps: { [PAST]: true } }, {
    settings: QA, dailyPayload: dailyPayload([dailyRow(PAST)]), todayQatar: TODAY, nowIso: '2026-11-24T06:00:00.000Z'
  });
  assert.equal(r.ok, true, JSON.stringify(r));
  assert.equal(r.wrote, true);
  const data = empty.data();
  assert.equal(data.version, 2);
  assert.ok(data.daily.some((d) => d.id === 'daily-2026-11-22'));
  assert.ok(settingsOf(data) && settingsOf(data).garminLedger);
  assert.equal(empty.storage.getItem(HD.IMPORT_BACKUP_KEY), slotBefore, 'backup slot unchanged');
  // zero-write replay
  const mid = empty.raw();
  const r2 = G.applyMerge(empty.api, { applySteps: { [PAST]: true } }, {
    settings: QA, dailyPayload: dailyPayload([dailyRow(PAST)]), todayQatar: TODAY, nowIso: '2026-11-24T06:00:00.000Z'
  });
  assert.equal(r2.wrote, false, JSON.stringify(r2));
  assert.equal(empty.raw(), mid, 'replay is zero-write');

  // existing schema-1 is refused (not auto-upgraded)
  const s1 = store({ version: 1, weight: [{ id: 'w-old', createdAt: '2026-11-01T00:00:00.000Z', date: '2026-11-01', kg: 80 }], workouts: [], nutrition: [] });
  const before1 = s1.raw();
  const r1 = G.applyMerge(s1.api, { applySteps: { [PAST]: true } }, {
    settings: QA, dailyPayload: dailyPayload([dailyRow(PAST)]), todayQatar: TODAY, nowIso: '2026-11-24T06:00:00.000Z'
  });
  assert.equal(r1.wrote, false);
  assert.equal(r1.code, 'schema_1');
  assert.match(G.ownerMessageForApply(r1), /earlier or unreadable data format/i);
  assert.equal(s1.raw(), before1);
  assert.equal(JSON.parse(before1).version, 1);

  // corrupt
  const c = mem();
  c.setItem(HD.STORAGE_KEY, '{not-json');
  const capi = HD.createStore(c, { now: NOW });
  const rc = G.applyMerge(capi, { applySteps: { [PAST]: true } }, {
    settings: QA, dailyPayload: dailyPayload([dailyRow(PAST)]), todayQatar: TODAY
  });
  assert.equal(rc.wrote, false);
  assert.equal(rc.code, 'corrupt');
  assert.equal(c.getItem(HD.STORAGE_KEY), '{not-json');

  // newer
  const newer = store({ version: 99, weight: [], workouts: [], nutrition: [], sessions: [], meals: [], body: [], daily: [], walks: [], dayStates: [], planEvents: [], ownerSettings: [] });
  const beforeN = newer.raw();
  const rn = G.applyMerge(newer.api, { applySteps: { [PAST]: true } }, {
    settings: QA, dailyPayload: dailyPayload([dailyRow(PAST)]), todayQatar: TODAY
  });
  assert.equal(rn.wrote, false);
  assert.equal(rn.code, 'newer');
  assert.equal(newer.raw(), beforeN);

  // pending restore
  const pend = store(v2doc());
  pend.storage.setItem(HD.IMPORT_BACKUP_KEY, JSON.stringify({
    kind: 'hyrox-pre-import', restoreState: 'pending', savedAt: '2026-11-24T05:00:00.000Z', raw: pend.raw() || '{"version":2}'
  }));
  const beforeP = pend.raw();
  const slotP = pend.storage.getItem(HD.IMPORT_BACKUP_KEY);
  const rp = G.applyMerge(pend.api, { applySteps: { [PAST]: true } }, {
    settings: QA, dailyPayload: dailyPayload([dailyRow(PAST)]), todayQatar: TODAY
  });
  assert.equal(rp.wrote, false);
  assert.equal(rp.code, 'restore_pending');
  assert.equal(pend.raw(), beforeP);
  assert.equal(pend.storage.getItem(HD.IMPORT_BACKUP_KEY), slotP);
});

test('CC #3 condition 5 / V15: unchanged check-in save keeps Garmin steps provenance; manual steps are not overwritten without Replace', () => {
  const t = store(v2doc({
    daily: [{
      id: 'daily-2026-11-22', date: PAST, createdAt: '2026-11-22T05:00:00.000Z',
      steps: { state: 'OBSERVED', value: 5000, source: 'MANUAL_TYPING' }
    }]
  }));
  // V15 fail-first: existing observed (non-API / manual) steps must not be overwritten without replaceSteps.
  const r = G.applyMerge(t.api, { applySteps: { [PAST]: true } }, {
    settings: QA, dailyPayload: dailyPayload([dailyRow(PAST)]), todayQatar: TODAY, nowIso: '2026-11-24T06:00:00.000Z'
  });
  assert.ok(!r.wrote || t.data().daily[0].steps.value === 5000, 'manual steps must not be overwritten without Replace: ' + JSON.stringify(r));
  assert.equal(t.data().daily[0].steps.value, 5000);
  assert.notEqual(t.data().daily[0].steps.source, 'GARMIN_PERSONAL_API');

  // With Replace, Garmin may overwrite.
  const r2 = G.applyMerge(t.api, { applySteps: { [PAST]: true }, replaceSteps: { [PAST]: true } }, {
    settings: QA, dailyPayload: dailyPayload([dailyRow(PAST)]), todayQatar: TODAY, nowIso: '2026-11-24T06:00:00.000Z'
  });
  assert.equal(r2.wrote, true, JSON.stringify(r2));
  assert.equal(t.data().daily[0].steps.value, 8421);
  assert.equal(t.data().daily[0].steps.source, 'GARMIN_PERSONAL_API');

  // Morning/check-in helpers: unchanged value keeps API source.
  const HM = require('../src/data/hyrox-morning.js');
  const ir = HM.intensityUpdate(t.data().daily[0], PAST, t.data().daily[0].intensityMin ? t.data().daily[0].intensityMin.value : 36, TODAY);
  // set intensity first
  t.data(); // no-op
  const rec = t.data().daily[0];
  rec.intensityMin = { state: 'OBSERVED', value: 36, source: 'GARMIN_PERSONAL_API', moderate: 20, vigorous: 8 };
  const ir2 = HM.intensityUpdate(rec, PAST, 36, TODAY);
  assert.equal(ir2.changed, false);
  assert.equal(ir2.rec.intensityMin.source, 'GARMIN_PERSONAL_API');
  const ir3 = HM.intensityUpdate(rec, PAST, 40, TODAY);
  assert.equal(ir3.changed, true);
  assert.equal(ir3.rec.intensityMin.source, 'GARMIN_MANUAL');
});

test('CC #3 condition 6: export names Garmin-derived observations and does not call API source owner-typed', () => {
  const CX = require('../src/data/hyrox-coach-export.js');
  const rec = {
    id: 'daily-2026-11-22', date: PAST, createdAt: '2026-11-22T05:00:00.000Z',
    steps: { state: 'OBSERVED', value: 8421, source: 'GARMIN_PERSONAL_API' },
    intensityMin: { state: 'OBSERVED', value: 36, source: 'GARMIN_PERSONAL_API', moderate: 20, vigorous: 8 }
  };
  const snap = CX.buildExport
    ? null
    : null;
  // Use the public export builder if present.
  const keys = Object.keys(CX);
  assert.ok(keys.length, 'coach export loaded');
  // intensityNote string (if a helper is exported we still assert the source file wording via a built snapshot if possible).
  const src = require('fs').readFileSync(require('path').resolve(__dirname, '../src/data/hyrox-coach-export.js'), 'utf8');
  assert.match(src, /Garmin-derived observation imported from the Personal API/);
  assert.doesNotMatch(src, /typed by the owner as Garmin shows it \(Garmin already counts vigorous minutes double\)\. null/);
  void rec; void snap;
});

test('CC #4: settings ledger is the canonical copy; a last-day delete does not drop identity or tombstones', () => {
  const t = store(v2doc());
  G.applyMerge(t.api, { applySteps: { [PAST]: true } }, {
    settings: QA, dailyPayload: dailyPayload([dailyRow(PAST)]), todayQatar: TODAY, nowIso: '2026-11-24T06:00:00.000Z'
  });
  assert.ok(settingsOf(t.data()).garminLedger);
  assert.ok(!(t.data().daily[0].garminLedger), 'daily is not the canonical ledger after apply');
  t.api.removeRecord('daily', 'daily-' + PAST);
  const led = settingsOf(t.data()).garminLedger;
  assert.ok(led);
  assert.ok(led.identity && led.identity.provider === 'garmin-personal-api');
});
