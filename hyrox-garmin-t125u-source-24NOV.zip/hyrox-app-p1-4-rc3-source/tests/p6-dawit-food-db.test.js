'use strict';
// P6 food DB (Dawit): shape + sanity of src/data/food-db.json / food-db.js built by tools/food-db/build_food_db.py.
// Synthetic-free: this validates the bundled USDA FoodData Central (CC0) data. No network.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');
const cp = require('node:child_process');
const os = require('node:os');

const ROOT = path.resolve(__dirname, '..');
const JSON_PATH = path.join(ROOT, 'src/data/food-db.json'), JS_PATH = path.join(ROOT, 'src/data/food-db.js');
const SRC_DIR = '/workspace/hyrox-p6/food-data-feasibility';
const DB = JSON.parse(fs.readFileSync(JSON_PATH, 'utf8'));

describe('P6 food-db.json: meta', () => {
  it('has the contract meta', () => {
    const m = DB.meta;
    assert.equal(m.schema, 1);
    assert.equal(m.dbVersion, 'usda-srlegacy-2018-04+foundation-2026-10-29');
    assert.match(m.license, /^CC0 1\.0 Universal/);
    assert.match(m.citation, /FoodData Central/);
    assert.match(m.citation, /fdc\.nal\.usda\.gov/);
    assert.equal(typeof m.notes, 'string'); assert.match(m.notes, /per 100 g/); assert.match(m.notes, /Atwater/); assert.match(m.notes, /by difference/);
    assert.deepEqual(m.sources.map((s) => [s.dataset, s.release]), [['SR Legacy', '2018-04'], ['Foundation', '2026-10-29']]);
    for (const s of m.sources) {
      assert.match(s.sha256, /^[0-9a-f]{64}$/); assert.match(s.file, /\.zip$/);
      assert.equal(s.foodCount + s.excludedCount, s.foodsInSource);
    }
  });
  it('foodCount equals foods.length and the per-source counts; excluded count recorded', () => {
    assert.equal(DB.meta.foodCount, DB.foods.length);
    assert.equal(DB.meta.foodCount, DB.meta.sources.reduce((a, s) => a + s.foodCount, 0));
    assert.equal(DB.meta.excludedCount, DB.meta.sources.reduce((a, s) => a + s.excludedCount, 0));
    assert.equal(DB.foods.filter((f) => f[1] === 'SR').length, DB.meta.sources[0].foodCount);
    assert.equal(DB.foods.filter((f) => f[1] === 'FF').length, DB.meta.sources[1].foodCount);
  });
  it('is large enough to be the real data, not a stub', () => {
    assert.ok(DB.meta.foodCount > 8000, String(DB.meta.foodCount));
    assert.ok(DB.foods.filter((f) => f[1] === 'SR').length > 7500);
    assert.ok(DB.foods.filter((f) => f[1] === 'FF').length > 300);
  });
  it('no timestamps in meta (deterministic build)', () => {
    assert.equal(/\d{4}-\d{2}-\d{2}T\d{2}:/.test(JSON.stringify(DB.meta)), false);
  });
});

describe('P6 food-db.json: rows', () => {
  it('every row has the contract shape', () => {
    for (const f of DB.foods) {
      assert.equal(f.length, 8);
      assert.ok(Number.isInteger(f[0]) && f[0] > 0);
      assert.ok(f[1] === 'SR' || f[1] === 'FF');
      assert.ok(typeof f[2] === 'string' && f[2].length > 0 && f[2] === f[2].trim() && f[2].length <= 200, String(f[0]));
      for (let i = 3; i <= 6; i++) assert.ok(typeof f[i] === 'number' && Number.isFinite(f[i]), f[0] + ' col ' + i);
      assert.ok(Array.isArray(f[7]));
      for (const p of f[7]) {
        assert.equal(p.length, 3);
        assert.ok(typeof p[0] === 'number' && p[0] > 0 && p[0] <= 1000, f[0]);
        assert.ok(typeof p[1] === 'string' && p[1].length > 0 && p[1] === p[1].trim(), f[0]);
        assert.ok(typeof p[2] === 'number' && p[2] > 0 && p[2] <= 100000, f[0]);
      }
    }
  });
  it('fdcIds are unique per dataset, and sorted (dataset order SR then FF, then fdcId)', () => {
    for (const ds of ['SR', 'FF']) {
      const ids = DB.foods.filter((f) => f[1] === ds).map((f) => f[0]);
      assert.equal(new Set(ids).size, ids.length, ds);
      assert.deepEqual(ids, ids.slice().sort((a, b) => a - b), ds + ' sorted');
    }
    const order = DB.foods.map((f) => f[1]);
    assert.equal(order.indexOf('FF'), order.filter((d) => d === 'SR').length, 'all SR rows first');
  });
  it('value ranges per 100 g are physically sane', () => {
    for (const f of DB.foods) {
      const [kcal, p, c, fat] = f.slice(3, 7);
      assert.ok(kcal >= 0 && kcal <= 910, f[0] + ' kcal ' + kcal);
      assert.ok(p >= 0 && p <= 100, f[0] + ' protein');
      assert.ok(fat >= 0 && fat <= 100, f[0] + ' fat');
      assert.ok(c >= -1 && c <= 100, f[0] + ' carbs ' + c);
      assert.ok(p + Math.max(c, 0) + fat <= 100.5, f[0] + ' macros sum to more than 100 g');
    }
  });
  it('the only negative value is carbohydrate-by-difference from a few Foundation rows (kept as USDA published it)', () => {
    const neg = DB.foods.filter((f) => f.slice(3, 7).some((v) => v < 0));
    assert.ok(neg.length <= 20, String(neg.length));
    for (const f of neg) { assert.equal(f[1], 'FF'); assert.ok(f[3] >= 0 && f[4] >= 0 && f[6] >= 0); assert.ok(f[5] < 0 && f[5] >= -1); }
  });
  it('energy is consistent with 4P+4C+9F for the large majority (Atwater sanity, not a rule)', () => {
    const big = DB.foods.filter((f) => f[3] >= 50);
    const ok = big.filter((f) => Math.abs(f[3] - (4 * f[4] + 4 * f[5] + 9 * f[6])) <= 0.25 * f[3]);
    assert.ok(ok.length / big.length > 0.97, ok.length + '/' + big.length);
  });
  it('most foods have household portions', () => {
    assert.ok(DB.foods.filter((f) => f[7].length).length / DB.foods.length > 0.9);
  });
  it('known foods have the expected USDA rows (spot checks, SR Legacy 171287 and 170000-range ids)', () => {
    const egg = DB.foods.find((f) => f[1] === 'SR' && f[0] === 171287);
    assert.equal(egg[2], 'Egg, whole, raw, fresh');
    assert.deepEqual(egg.slice(3, 7), [143, 12.56, 0.72, 9.51]);
    assert.deepEqual(egg[7][0], [1, 'large', 50]);
  });
  it('contains no ASCII-hostile bytes: the files are pure ASCII (escapes), so file:// charset cannot corrupt them', () => {
    for (const p of [JSON_PATH, JS_PATH]) assert.equal(/[^\x00-\x7f]/.test(fs.readFileSync(p, 'latin1')), false, p);
  });
});

describe('P6 food-db.js (file:// build) is equivalent to food-db.json', () => {
  it('evaluates as a classic script and sets window.HyroxFoodDb deeply equal to the JSON', () => {
    const win = {};
    const ctx = vm.createContext({ window: win });
    vm.runInContext(fs.readFileSync(JS_PATH, 'utf8'), ctx);
    assert.deepEqual(JSON.parse(JSON.stringify(win.HyroxFoodDb)), DB);
  });
  it('without a window object it falls back to the global object (no throw)', () => {
    const ctx = vm.createContext({});
    vm.runInContext(fs.readFileSync(JS_PATH, 'utf8'), ctx);
    assert.equal(vm.runInContext('globalThis.HyroxFoodDb.meta.foodCount', ctx), DB.meta.foodCount);
  });
  it('the JS file embeds the exact JSON text', () => {
    const j = fs.readFileSync(JSON_PATH, 'utf8').trim();
    assert.ok(fs.readFileSync(JS_PATH, 'utf8').includes(j));
  });
});

describe('P6 build script: reproducible from the USDA zips', () => {
  const have = fs.existsSync(path.join(SRC_DIR, DB.meta.sources[0].file)) && fs.existsSync(path.join(SRC_DIR, DB.meta.sources[1].file));
  const py = cp.spawnSync('python3', ['--version']);
  it('input zips match the sha256 recorded in meta', { skip: !have && 'USDA zips not on this machine' }, () => {
    for (const s of DB.meta.sources) {
      const h = crypto.createHash('sha256').update(fs.readFileSync(path.join(SRC_DIR, s.file))).digest('hex');
      assert.equal(h, s.sha256, s.file);
    }
  });
  it('re-running the build twice produces byte-identical files equal to the committed ones', { skip: (!have || py.status !== 0) && 'zips or python3 not available' }, () => {
    const dirs = [0, 1].map(() => fs.mkdtempSync(path.join(os.tmpdir(), 'fooddb-')));
    for (const d of dirs) {
      const r = cp.spawnSync('python3', [path.join(ROOT, 'tools/food-db/build_food_db.py'), '--src', SRC_DIR, '--out', d], { encoding: 'utf8' });
      assert.equal(r.status, 0, r.stderr);
    }
    for (const f of ['food-db.json', 'food-db.js']) {
      const a = fs.readFileSync(path.join(dirs[0], f)), b = fs.readFileSync(path.join(dirs[1], f));
      assert.ok(a.equals(b), f + ' differs between runs');
      assert.ok(a.equals(fs.readFileSync(path.join(ROOT, 'src/data', f))), f + ' differs from the committed file');
    }
  });
  it('the build script is stdlib-only (no third-party imports) and makes no network calls', () => {
    const src = fs.readFileSync(path.join(ROOT, 'tools/food-db/build_food_db.py'), 'utf8');
    const std = new Set(['argparse', 'csv', 'hashlib', 'io', 'json', 'os', 'sys', 'zipfile']);
    const imports = [...src.matchAll(/^(?:import|from)\s+([A-Za-z0-9_]+)/gm)].map((m) => m[1]);
    assert.ok(imports.length > 0);
    for (const i of imports) assert.ok(std.has(i), i);
    assert.equal(/urllib|http|socket|requests/.test(src.replace(/https:\/\/fdc\.nal\.usda\.gov[^'"\s]*/g, '')), false);
  });
});
