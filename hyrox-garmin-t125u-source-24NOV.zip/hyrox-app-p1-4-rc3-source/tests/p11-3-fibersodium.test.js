'use strict';
// Phase 11.3 part 2: optional fiber (g) / sodium (mg). Unknown is never 0; eaten fraction applied once; partial coverage is
// "known subtotal — incomplete"; complete only when every confirmed consumed item has it AND the day is complete.
// Data version stays 2 and meal.source stays MANUAL; older data layers keep the fields. Synthetic data only.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const X = require('../src/data/hyrox-fibersodium.js');
const HN = require('../src/data/hyrox-nutrition.js');
const HD = require('../src/data/hyrox-data.js');
const S = require('../src/data/hyrox-foodsearch.js');
const C = require('../src/data/hyrox-foodcalc.js');
const ix = S.buildIndex(require('../src/data/food-db.json'), C.ALIASES, require('../src/data/food-db-us.json'));
const NOW = new Date('2026-11-19T09:00:00Z');
const mem = () => { const m = {}; return { getItem: (k) => (k in m ? m[k] : null), setItem(k, v) { m[k] = String(v); }, removeItem(k) { delete m[k]; } }; };
const K = (v) => ({ value: v, state: 'KNOWN' }), E = (v) => ({ value: v, state: 'ESTIMATED' }), U = () => ({ value: null, state: 'UNKNOWN' });
function item(name, kcal, extra) { return Object.assign({ name, role: 'MAIN', portion: '', preparation: '', eatenFraction: null, kcal: K(kcal), proteinG: K(1), carbsG: K(1), fatG: K(1) }, extra || {}); }
function meal(comps, o) { return Object.assign({ id: 'm' + Math.random().toString(36).slice(2), date: '2026-11-19', time: '12:00', label: 'Lunch', source: 'MANUAL', description: '', eatenFraction: 1, lifecycle: 'CONFIRMED', confirmedAt: NOW.toISOString(), ai: null, mealCategory: 'LUNCH', components: comps }, o || {}); }
const D5 = { code: 'D5' }, D4 = { code: 'D4' }, D2 = { code: 'D2' };

test('mixed null / zero / known / invalid: only real numbers count; 0 is a known 0; nothing unknown becomes 0', () => {
  const m = meal([item('a', 100, { fiberG: K(0) }), item('b', 100), item('c', 100, { fiberG: U() }), item('d', 100, { fiberG: { value: null, state: 'ESTIMATED' } }),
    item('e', 100, { fiberG: K(-2) }), item('f', 100, { fiberG: 'lots' }), item('g', 100, { fiberG: E(3.25) })]);
  const t = X.mealTotal(m, 'fiberG');
  assert.deepEqual([t.state, t.value, t.known, t.items, t.estimated], ['PARTIAL', 3.3, 2, 7, 1]);
  const z = X.dayTotal([meal([item('a', 0, { sodiumMg: K(0) })])], '2026-11-19', 'sodiumMg', D5);
  assert.deepEqual([z.state, z.value], ['COMPLETE', 0]);
  const none = X.dayTotal([meal([item('a', 100), item('b', 100, { sodiumMg: U() })])], '2026-11-19', 'sodiumMg', D5);
  assert.deepEqual([none.state, none.value, none.known, none.items], ['UNKNOWN', null, 0, 2]);
  assert.equal(X.text(none), 'Sodium: unknown (0 of 2 items known)');
});
test('day states: NONE / UNKNOWN / PARTIAL ("known subtotal — incomplete") / SO_FAR / COMPLETE (D4 or D5 only); drafts never count', () => {
  const all = [meal([item('a', 300, { fiberG: K(4) }), item('b', 200, { fiberG: K(2.5) })]), meal([item('x', 500, { fiberG: K(9) })], { lifecycle: 'DRAFT', confirmedAt: null })];
  assert.equal(X.dayTotal([], '2026-11-19', 'fiberG', D5).state, 'NONE');
  const so = X.dayTotal(all, '2026-11-19', 'fiberG', D2);
  assert.deepEqual([so.state, so.value, so.known, so.items], ['SO_FAR', 6.5, 2, 2]);
  assert.equal(X.text(so), 'Fiber: 6.5 g so far (2 of 2 items known)');
  assert.equal(X.dayTotal(all, '2026-11-19', 'fiberG', D4).state, 'COMPLETE');
  assert.equal(X.text(X.dayTotal(all, '2026-11-19', 'fiberG', D5)), 'Fiber: 6.5 g — complete day total (2 of 2 items known)');
  all.push(meal([item('c', 100)]));
  const part = X.dayTotal(all, '2026-11-19', 'fiberG', D5);
  assert.deepEqual([part.state, part.value], ['PARTIAL', 6.5]);
  assert.equal(X.text(part), 'Fiber: 6.5 g known subtotal — incomplete (2 of 3 items known)');
  assert.equal(X.dayTotal(all, '2026-11-18', 'fiberG', D5).state, 'NONE'); // other dates never mix in
});
test('eaten fraction is applied exactly once (item, else meal, else 1); unstated photo fraction = unknown; 0 eaten = not consumed', () => {
  const m = meal([item('a', 100, { sodiumMg: K(1000) }), item('b', 100, { sodiumMg: K(400), eatenFraction: 0.25 }), item('c', 100, { sodiumMg: K(999), eatenFraction: 0 })], { eatenFraction: 0.5 });
  const t = X.mealTotal(m, 'sodiumMg');
  assert.deepEqual([t.value, t.known, t.items], [600, 2, 2]);
  assert.equal(HN.mealTotals(m).kcal.value, 75, 'kcal uses the same fraction rule'); // 50 + 25
  const ph = meal([item('a', 100, { fiberG: K(5) })], { source: 'PHOTO_AI', eatenFraction: null, lifecycle: 'DRAFT', confirmedAt: null });
  assert.deepEqual([X.mealTotal(ph, 'fiberG').state, X.mealTotal(ph, 'fiberG').known], ['UNKNOWN', 0]);
  // same rule as hyrox-nutrition.js: for each item, kcal 100 x fraction == what HN computes
  for (const mm of [m, ph]) for (const c of mm.components) { const f = X.eatenFractionOf(mm, c), k = HN.mealTotals({ source: mm.source, eatenFraction: mm.eatenFraction, components: [Object.assign({}, c, { kcal: K(100) })] }).kcal.value; assert.equal(k, f === null ? null : Math.round(100 * f * 10) / 10); }
});
test('kcal, macros, day states and averages are unchanged by fiber/sodium fields', () => {
  const plain = [meal([item('a', 300), item('b', 200)])];
  const withX = JSON.parse(JSON.stringify(plain)); withX[0].components[0].fiberG = K(4); withX[0].components[1].sodiumMg = E(800);
  const a = HN.dayState('2026-11-19', plain, null), b = HN.dayState('2026-11-19', withX, null);
  assert.deepEqual([b.code, b.subtotal, b.dayKcal], [a.code, a.subtotal, a.dayKcal]);
  assert.deepEqual(HN.mealTotals(withX[0]), HN.mealTotals(plain[0]));
  assert.equal(HN.MACROS.indexOf('fiberG'), -1); assert.equal(HN.MACROS.indexOf('sodiumMg'), -1);
});
test('older backups / meals without the fields read as unknown (never 0) and are not changed', () => {
  const old = meal([item('rice', 400), item('chicken', 300)]);
  const before = JSON.stringify(old);
  const t = X.dayTotal([old], '2026-11-19', 'fiberG', D5);
  assert.deepEqual([t.state, t.value, t.items], ['UNKNOWN', null, 2]);
  assert.equal(JSON.stringify(old), before);
});
test('real per-serving scaling: USDA serving x quantity, and edited quantity for a saved food; sodium whole mg, fiber 0.1 g', () => {
  const sv = S.servingsFor(ix, 'SR:173944'), cup = sv.find((s) => s.isDefault);
  const one = S.usdaComponent(ix, 'SR:173944', cup, 1).component, two = S.usdaComponent(ix, 'SR:173944', cup, 2).component;
  assert.ok(one.fiberG && one.sodiumMg, 'banana has both');
  assert.equal(two.sodiumMg.value, Math.round(ix.foods[ix.byKey['SR:173944']].fs[1] * cup.grams * 2 / 100));
  assert.equal(two.fiberG.value, Math.round(ix.foods[ix.byKey['SR:173944']].fs[0] * cup.grams * 2 / 10) / 10);
  const mf = S.myFoodFromComponent(one, { id: 'mf-b' }).food;
  assert.deepEqual([mf.fiberG, mf.sodiumMg], [one.fiberG, one.sodiumMg]);
  const x3 = S.myFoodComponent(mf, 3).component;
  assert.deepEqual([x3.fiberG.value, x3.sodiumMg.value, x3.fiberG.state], [Math.round(one.fiberG.value * 30) / 10, Math.round(one.sodiumMg.value * 3), 'ESTIMATED']);
  // a food USDA gives no fiber for: no fiberG written (unknown), sodium still there
  const noFib = ix.foods.find((f) => f.dataset === 'SR' && f.fs && f.fs[0] === null && f.fs[1] !== null);
  const c = S.usdaComponent(ix, noFib.key, S.servingsFor(ix, noFib.key)[0], 1).component;
  assert.equal(c.fiberG, undefined); assert.equal(typeof c.sodiumMg.value, 'number');
});
test('saved foods: a manually entered, confirmed chain value (KNOWN) is kept as KNOWN with its fiber/sodium; unknown is not stored; invalid is dropped', () => {
  const chain = item('Chain burger (official US app value)', 590, { portion: '1 burger', sodiumMg: K(1050), fiberG: U() });
  const f = S.myFoodFromComponent(chain, { id: 'mf-c' }).food;
  assert.equal(f.basis, 'your values'); assert.deepEqual(f.sodiumMg, K(1050)); assert.equal('fiberG' in f, false); assert.equal(f.provenance, undefined);
  const v = S.validMyFoods([Object.assign({}, f, { fiberG: K(-1) }), Object.assign({}, f, { id: 'mf-d', sodiumMg: { value: 'x' } })]);
  assert.equal('fiberG' in v[0], false); assert.deepEqual(v[0].sodiumMg, K(1050)); assert.equal('sodiumMg' in v[1], false);
  assert.deepEqual(S.myFoodComponent(f, 1).component.sodiumMg, K(1050));
});
test('duplicates: the same food added twice counts twice (each a separate item the owner chose); a copied meal is a separate meal', () => {
  const c = S.usdaComponent(ix, 'FN:2707154', S.servingsFor(ix, 'FN:2707154').find((s) => s.isDefault), 1).component;
  const m = meal([c, JSON.parse(JSON.stringify(c))]);
  const t = X.mealTotal(m, 'sodiumMg'); assert.deepEqual([t.value, t.items], [c.sodiumMg.value * 2, 2]);
  const copy = Object.assign(JSON.parse(JSON.stringify(m)), { id: 'copy' });
  assert.equal(X.dayTotal([m, copy], '2026-11-19', 'sodiumMg', D2).value, c.sodiumMg.value * 4);
});
test('Describe-path components get USDA fiber/sodium from their own source note (grams), never overwriting an owner value', () => {
  const est = C.estimate('2 large eggs', require('../src/data/food-db.json')); assert.equal(est.ok, true);
  const comps = C.toComponents({ ok: true, dbVersion: est.dbVersion, items: est.items, totals: {} }).components;
  const e = S.withFiberSodium(ix, comps[0]);
  assert.ok(e.sodiumMg && e.sodiumMg.state === 'ESTIMATED');
  const f = ix.foods[ix.byKey[comps[0].provenance.dataset + ':' + comps[0].provenance.fdcId]];
  assert.equal(e.sodiumMg.value, Math.round(f.fs[1] * comps[0].provenance.grams / 100));
  const mine = S.withFiberSodium(ix, Object.assign({}, comps[0], { sodiumMg: K(5) }));
  assert.deepEqual(mine.sodiumMg, K(5));
  assert.equal(comps[0].sodiumMg, undefined, 'input not mutated');
  const noProv = item('home stew', 400); assert.equal(S.withFiberSodium(ix, noProv), noProv);
});
// ---------- storage: data version 2, MANUAL, export/restore, rollback to older data layers ----------
function store(H) { return H.createStore(mem(), { now: () => NOW }); }
function p113Backup() {
  const st = store(HD);
  const c = S.usdaComponent(ix, 'FN:2707154', S.servingsFor(ix, 'FN:2707154').find((s) => s.isDefault), 2).component;
  const r = st.putRecord('meals', meal([c, item('chain fries (official US value)', 320, { sodiumMg: K(260), fiberG: K(0) }), item('sauce', 60)], { id: undefined }));
  assert.equal(r.ok, true, JSON.stringify(r.errors));
  const mf = S.myFoodFromComponent(c, { id: 'mf-1', savedAt: NOW.toISOString() }).food;
  assert.equal(st.putRecord('ownerSettings', { id: HD.SETTINGS_ID, date: '2026-11-19', myFoods: [mf], favFoods: ['FN:2707154'] }).ok, true);
  return st.exportJSON();
}
const roundTrip = (H, text) => {
  const storage = mem(), st = H.createStore(storage, { now: () => NOW });
  const p = st.previewImport(text); assert.equal(p.ok, true, JSON.stringify(p.errors || p.message));
  const r = st.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt }); assert.equal(r.ok, true, JSON.stringify(r));
  return H.createStore(storage, { now: () => NOW });
};
test('this build: version 2, source MANUAL, fiber/sodium + FNDDS provenance + My foods round-trip exactly', () => {
  const text = p113Backup(), j = JSON.parse(text);
  assert.equal(j.version, 2); assert.equal(j.meals[0].source, 'MANUAL');
  const back = JSON.parse(roundTrip(HD, text).exportJSON());
  assert.deepEqual(back.meals[0].components, j.meals[0].components);
  assert.deepEqual(back.ownerSettings[0].myFoods, j.ownerSettings[0].myFoods);
  assert.deepEqual(j.meals[0].components[1].sodiumMg, K(260));
});
const OLD = { 'claude-p11.2': process.env.P113_P112_SRC || '/workspace/hyrox-p11-3-before/src', 'claude-p11': process.env.P112_P11_SRC || '/workspace/hyrox-p11-2-before/src', 'claude-p10b': process.env.P112_P10B_SRC || '/workspace/hyrox-p11-before/src' };
for (const [name, dir] of Object.entries(OLD)) {
  const present = fs.existsSync(path.join(dir, 'data', 'hyrox-data.js'));
  (present ? test : test.skip)(`rollback: the ${name} data layer restores a Phase 11.3 backup and exports fiber/sodium, FNDDS provenance and My foods unchanged`, () => {
    const text = p113Backup(), src = JSON.parse(text);
    const OH = require(path.join(dir, 'data', 'hyrox-data.js'));
    const out = JSON.parse(roundTrip(OH, text).exportJSON());
    assert.deepEqual(out.meals[0].components, src.meals[0].components);
    assert.deepEqual(out.ownerSettings[0].myFoods, src.ownerSettings[0].myFoods);
    assert.deepEqual(out.ownerSettings[0].favFoods, src.ownerSettings[0].favFoods);
    // and back again to this build
    const again = JSON.parse(roundTrip(HD, JSON.stringify(out)).exportJSON());
    assert.deepEqual(again.meals[0].components, src.meals[0].components);
  });
}
test('a P11.2 / P11 / P10b-era backup (no fiber/sodium) restores here unchanged, nothing added', () => {
  const st = store(HD);
  assert.equal(st.putRecord('meals', meal([item('rice', 400)], { id: undefined })).ok, true);
  const text = st.exportJSON();
  const back = JSON.parse(roundTrip(HD, text).exportJSON());
  assert.deepEqual(back.meals, JSON.parse(text).meals);
  assert.equal(JSON.stringify(back).indexOf('fiberG'), -1);
});
test('no data-layer or nutrition-module change: hyrox-data.js / hyrox-nutrition.js are byte-identical to Claude P11.2', (t) => {
  const base = OLD['claude-p11.2'];
  if (!fs.existsSync(path.join(base, 'data', 'hyrox-data.js'))) { t.skip('Claude P11.2 tree not present'); return; }
  // RE-POINTED S1 (Garmin import, 24 Nov 2026): hyrox-data.js gained applyAtomic; nutrition and food files stay byte-identical to Claude P11.2.
  for (const f of ['hyrox-nutrition.js', 'hyrox-foodcalc.js', 'food-db.js', 'food-db.json']) assert.equal(fs.readFileSync(path.join(__dirname, '..', 'src', 'data', f), 'utf8'), fs.readFileSync(path.join(base, 'data', f), 'utf8'), f);
});
