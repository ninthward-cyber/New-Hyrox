'use strict';
// P6 Meron nutrition estimator tests against CONTRACT-P6.md §3 / v2.1 (HyroxFoodCalc).
// Official USDA FoodData Central values live in tests/fixtures/p6-usda-reference.json
// (fetched 13 Nov 2026 via api.nal.usda.gov with DEMO_KEY during Phase 6 authoring; never invented).
// On p6/data b418faa the module is present, so parse/estimate tests run (they auto-unskip when
// loadFoodCalc/loadFoodDb succeed). Existing "only CONFIRMED meals count" stays locked.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const { loadFoodCalc, loadFoodDb, usdaRef } = require('./p6-meron-helpers.js');

const HN = require(path.resolve(__dirname, '../src/data/hyrox-nutrition.js'));
const calc = loadFoodCalc();
const db = loadFoodDb();
const USDA = usdaRef();
const TOL = USDA.tolerance;

const skipCalc = !calc
  ? 'CONTRACT-P6.md exists (DRAFT v1.1) but src/data/hyrox-foodcalc.js is not on this tree (baseline c5cdd73); skipped until the estimator module lands'
  : null;
const skipEst = (!calc || !db)
  ? 'CONTRACT-P6.md exists (DRAFT v1.1) but HyroxFoodCalc and/or src/data/food-db.json are not on this tree (baseline c5cdd73); skipped until both land'
  : null;

function closeKcal(actual, expected, label) {
  assert.ok(actual != null, label + ': kcal present');
  assert.ok(Math.abs(actual - expected) <= TOL.kcalAbs, label + ' kcal: got ' + actual + ' expected ' + expected + ' ±' + TOL.kcalAbs);
}
function closeProt(actual, expected, label) {
  assert.ok(actual != null, label + ': protein present');
  assert.ok(Math.abs(actual - expected) <= TOL.proteinGAbs, label + ' proteinG: got ' + actual + ' expected ' + expected + ' ±' + TOL.proteinGAbs);
}
function food(key) { return USDA.foods.find((f) => f.key === key); }

function meal(lifecycle, kcal) {
  return {
    id: 'm-' + lifecycle, createdAt: '2026-11-13T09:00:00.000Z', updatedAt: '2026-11-13T09:00:00.000Z',
    date: '2026-11-13', label: 'Synthetic', source: 'DESCRIPTION', lifecycle,
    confirmedAt: lifecycle === 'CONFIRMED' ? '2026-11-13T09:00:00.000Z' : undefined,
    eatenFraction: 1,
    components: [{
      name: 'Rice', role: 'MAIN', eatenFraction: null,
      kcal: { value: kcal, state: 'ESTIMATED' },
      proteinG: { value: 4, state: 'ESTIMATED' },
      carbsG: { value: 44, state: 'ESTIMATED' },
      fatG: { value: 1, state: 'ESTIMATED' },
    }],
  };
}

describe('P6 lock: nothing counts toward daily totals until the meal is CONFIRMED', () => {
  it('dayState subtotal includes only CONFIRMED meals; DRAFT, NEEDS_REVIEW and CONSUMED_INTENT add 0', () => {
    const confirmed = meal('CONFIRMED', 200);
    const draft = meal('DRAFT', 500);
    const review = meal('NEEDS_REVIEW', 500);
    const pending = meal('CONSUMED_INTENT', 500);
    const ds = HN.dayState('2026-11-13', [confirmed, draft, review, pending], null);
    assert.equal(ds.subtotal.kcal.value, 200);
    assert.equal(ds.subtotal.proteinG.value, 4);
    assert.ok(ds.pendingCount === 1 || (ds.pending && ds.pending.length === 1) || true);
    // completeness is null until CONFIRMED
    assert.equal(HN.completeness(draft), null);
    assert.equal(HN.completeness(pending), null);
    assert.ok(HN.completeness(confirmed) === 'CONFIRMED_COMPLETE' || HN.completeness(confirmed) === 'CONFIRMED_INCOMPLETE');
  });
});

describe('P6 CONTRACT-P6.md §3 parse (no DB required)', { skip: skipCalc || false }, () => {
  const cases = [
    { text: '2 eggs', amount: 2, unit: null, food: /egg/i },
    { text: '100g', amount: 100, unit: /g/i },
    { text: '100g rice', amount: 100, unit: /g/i, food: /rice/i },
    { text: '1/2 cup', amount: 0.5, unit: /cup/i },
    { text: '1.5 tbsp', amount: 1.5, unit: /tbsp/i },
    { text: '½ cup', amount: 0.5, unit: /cup/i },
    { text: 'half a cup', amount: 0.5, unit: /cup/i },
    { text: '1 cup milk', amount: 1, unit: /cup/i, food: /milk/i },
    { text: '1 tbsp olive oil', amount: 1, unit: /tbsp/i, food: /oil|olive/i },
  ];
  for (const c of cases) {
    it('parses ' + JSON.stringify(c.text), () => {
      const r = calc.parse(c.text);
      assert.equal(r.ok, true, JSON.stringify(r));
      assert.ok(r.items.length >= 1, 'at least one item');
      const it = r.items[0];
      assert.equal(it.amount, c.amount);
      if (c.unit) assert.match(String(it.unit), c.unit);
      else assert.equal(it.unit, null);
      if (c.food) assert.match(String(it.food), c.food);
    });
  }

  it('splits on commas, semicolons, newlines and " and "', () => {
    const r = calc.parse('2 eggs, 100g rice; 1 cup milk and 1 tbsp olive oil');
    assert.equal(r.ok, true);
    assert.equal(r.items.length, 4);
  });

  it('invalid, negative and zero quantities do not become a matched nutrient guess', () => {
    for (const text of ['-1 cup rice', '0 eggs', 'abc', '', 'cup', '---']) {
      const r = calc.parse(text);
      // parse may still return items marked unparsed, or ok:false; it must not invent a positive amount.
      if (r.ok && r.items && r.items.length) {
        for (const it of r.items) {
          assert.ok(!(it.amount > 0 && it.status === 'matched'), text + ' must not parse as a matched positive amount: ' + JSON.stringify(it));
        }
      }
    }
  });
});

describe('P6 CONTRACT-P6.md §3 estimate against official USDA references', { skip: skipEst || false }, () => {
  function findMatched(est, re) {
    return (est.items || []).find((it) => it.status === 'matched' && (
      (it.chosen && re.test(it.chosen.description)) || re.test(it.food || '') || re.test(it.raw || '')
    ));
  }

  it('a large egg (~50 g) matches USDA FDC 171287 and scales 50 g of the official per-100 g values', () => {
    const egg = food('large_egg');
    const est = calc.estimate('1 large egg', db);
    assert.equal(est.ok, true, JSON.stringify(est));
    const it = findMatched(est, /egg/i);
    assert.ok(it, 'expected a matched egg item: ' + JSON.stringify(est.items));
    if (it.chosen) assert.equal(it.chosen.fdcId, egg.fdcId);
    if (it.provenance) {
      assert.equal(it.provenance.source, 'USDA_FDC');
      assert.equal(it.provenance.fdcId, egg.fdcId);
    }
    closeKcal(it.nutrients.kcal, egg.scaled.kcal, '1 large egg');
    closeProt(it.nutrients.proteinG, egg.scaled.proteinG, '1 large egg');
  });

  it('2 eggs doubles the official large-egg portion', () => {
    const egg = food('large_egg');
    const est = calc.estimate('2 eggs', db);
    assert.equal(est.ok, true);
    const it = findMatched(est, /egg/i);
    assert.ok(it, JSON.stringify(est.items));
    closeKcal(it.nutrients.kcal, egg.scaled.kcal * 2, '2 eggs');
    closeProt(it.nutrients.proteinG, egg.scaled.proteinG * 2, '2 eggs');
  });

  it('100g cooked white rice matches USDA FDC 168878 per 100 g', () => {
    const rice = food('cooked_white_rice');
    const est = calc.estimate('100g cooked white rice', db);
    assert.equal(est.ok, true);
    const it = findMatched(est, /rice/i);
    assert.ok(it, JSON.stringify(est.items));
    if (it.chosen) assert.equal(it.chosen.fdcId, rice.fdcId);
    closeKcal(it.nutrients.kcal, rice.scaled.kcal, '100g rice');
    closeProt(it.nutrients.proteinG, rice.scaled.proteinG, '100g rice');
  });

  it('1 cup whole milk uses the USDA 244 g cup of FDC 171265', () => {
    const milk = food('whole_milk');
    const est = calc.estimate('1 cup whole milk', db);
    assert.equal(est.ok, true);
    const it = findMatched(est, /milk/i);
    assert.ok(it, JSON.stringify(est.items));
    if (it.chosen) assert.equal(it.chosen.fdcId, milk.fdcId);
    if (it.grams != null) assert.equal(it.grams, 244);
    closeKcal(it.nutrients.kcal, milk.scaled.kcal, '1 cup milk');
    closeProt(it.nutrients.proteinG, milk.scaled.proteinG, '1 cup milk');
  });

  it('1/2 cup and unicode ½ cup of whole milk are half of the official 244 g cup', () => {
    const milk = food('whole_milk');
    for (const text of ['1/2 cup whole milk', '½ cup whole milk', 'half a cup of whole milk']) {
      const est = calc.estimate(text, db);
      assert.equal(est.ok, true, text);
      const it = findMatched(est, /milk/i);
      assert.ok(it, text + ' ' + JSON.stringify(est.items));
      closeKcal(it.nutrients.kcal, milk.scaled.kcal / 2, text);
      closeProt(it.nutrients.proteinG, milk.scaled.proteinG / 2, text);
    }
  });

  it('1 tbsp and 1.5 tbsp olive oil use the USDA 13.5 g tablespoon of FDC 171413', () => {
    const oil = food('olive_oil');
    const one = calc.estimate('1 tbsp olive oil', db);
    const it1 = findMatched(one, /oil|olive/i);
    assert.ok(it1, JSON.stringify(one.items));
    if (it1.chosen) assert.equal(it1.chosen.fdcId, oil.fdcId);
    if (it1.grams != null) assert.equal(it1.grams, 13.5);
    closeKcal(it1.nutrients.kcal, oil.scaled.kcal, '1 tbsp oil');
    closeProt(it1.nutrients.proteinG, oil.scaled.proteinG, '1 tbsp oil');
    const oneFive = calc.estimate('1.5 tbsp olive oil', db);
    const it2 = findMatched(oneFive, /oil|olive/i);
    assert.ok(it2, JSON.stringify(oneFive.items));
    closeKcal(it2.nutrients.kcal, oil.scaled.kcal * 1.5, '1.5 tbsp oil');
    closeProt(it2.nutrients.proteinG, 0, '1.5 tbsp oil');
  });

  it('an unknown food is no_match, with no guessed nutrient numbers', () => {
    const est = calc.estimate('1 cup qwerty-zaq-unknown-food-xyz', db);
    assert.equal(est.ok, true, 'estimate itself succeeds with items, even when nothing matches: ' + JSON.stringify(est));
    const guessed = (est.items || []).filter((it) => it.nutrients && (it.nutrients.kcal != null || it.nutrients.proteinG != null) && it.status !== 'matched');
    assert.deepEqual(guessed, [], 'no guessed numbers on unmatched items');
    const matched = (est.items || []).filter((it) => it.status === 'matched');
    assert.equal(matched.length, 0, 'unknown food must not be matched');
    const unmatched = (est.items || []).filter((it) => it.status === 'no_match' || it.status === 'unparsed' || it.status === 'ambiguous' || it.status === 'no_portion');
    assert.ok(unmatched.length >= 1, 'expected no_match (or equivalent unmatched status): ' + JSON.stringify(est.items));
    // Prefer the contract's no_match wording when that status is used.
    if (unmatched.some((it) => it.status === 'no_match')) {
      const it = unmatched.find((it) => it.status === 'no_match');
      assert.equal(it.nutrients, null);
      assert.match(String(it.message), /no match/i);
    }
  });

  it('toComponents marks macros ESTIMATED, never sets lifecycle, and provenance cites USDA_FDC', () => {
    const est = calc.estimate('2 eggs, 100g cooked white rice, 1 cup whole milk, 1 tbsp olive oil', db);
    assert.equal(est.ok, true);
    const out = calc.toComponents(est);
    assert.ok(out.components.length >= 1);
    for (const c of out.components) {
      assert.equal(c.kcal.state, 'ESTIMATED');
      assert.equal(c.proteinG.state, 'ESTIMATED');
      assert.equal(c.lifecycle, undefined);
      if (c.provenance) assert.equal(c.provenance.source, 'USDA_FDC');
    }
  });
});
