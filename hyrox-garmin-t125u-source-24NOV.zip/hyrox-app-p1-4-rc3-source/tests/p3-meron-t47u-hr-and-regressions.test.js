'use strict';
// Meron (QA): OWNER-DECISIONS-t47u.txt "OTHER HOLDS" — HR baselines — and
// regression guards (P0-A/P0-B, downgrade, rollback, raw recovery).
// Synthetic data only. New file; no src/ or existing-test edits.

const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const HW = require(path.resolve(__dirname, '../src/data/hyrox-wellness.js'));
const HP = require(path.resolve(__dirname, '../src/data/hyrox-plan.js'));
const HD = require(path.resolve(__dirname, '../src/data/hyrox-data.js'));
const { KEY, RECOVERY, PRE, mem, mk, O, ts, backup, restore } = require('./p8-helpers.js');

function addDays(iso, n) {
  const d = new Date(Date.UTC(+iso.slice(0, 4), +iso.slice(5, 7) - 1, +iso.slice(8, 10) + n));
  return d.toISOString().slice(0, 10);
}
const D = '2026-11-18';

describe('OTHER HOLDS (already on this build): configured 76 stays separate from the observed 7-day mean; one reading is one flag', () => {
  // "The personal resting-HR weekly-baseline calculation is unspecified by v2.1: preserve
  // owner-configured 76 bpm separately from an observed 7-day mean, label both, avoid treating
  // two comparisons of one HR measurement as two independent readiness flags, and do not
  // silently promote the observed mean to an approved source rule."
  it('configured 76 is a setting, separate from the observed 7-day mean, and the mean does not replace it', () => {
    const dailies = [];
    for (let i = 1; i <= 5; i++) dailies.push({ date: addDays(D, -i), rhr: O(70) });
    dailies.push({ date: D, rhr: O(80), sleepH: O(7), soreness: O(2) });
    const settings = { rhrBaselineBpm: 76, rhrBaselineSource: 'OWNER_DEFAULT' };
    const ra = HW.rhrAssessment(80, D, dailies, settings);
    assert.equal(ra.configured.value, 76);
    assert.equal(ra.configured.source, 'OWNER_DEFAULT');
    assert.equal(ra.observed.valid, true);
    assert.equal(ra.observed.value, 70);
    assert.notEqual(ra.configured.value, ra.observed.value);
    assert.equal(HD.DEFAULT_SETTINGS.rhrBaselineBpm, 76);
  });

  it('two comparisons of one reading are not two independent readiness flags', () => {
    // Reading 90 is ≥7 above both configured 76 and an observed mean of 76.
    const dailies = [];
    for (let i = 1; i <= 5; i++) dailies.push({ date: addDays(D, -i), rhr: O(76) });
    dailies.push({ date: D, rhr: O(90), sleepH: O(7), soreness: O(2) });
    const settings = { rhrBaselineBpm: 76, rhrBaselineSource: 'OWNER_DEFAULT' };
    const ra = HW.rhrAssessment(90, D, dailies, settings);
    const r = HW.readiness(D, dailies, settings);
    assert.ok(ra.flag, 'the combined comparison may be mentioned once');
    const rhrFlags = r.flags.filter((f) => /resting HR|baseline|7-day mean/i.test(f));
    assert.equal(rhrFlags.length, 1, 'must not count as two flags: ' + JSON.stringify(r.flags));
    assert.equal(r.flags.length, 1);
    assert.match(r.guidance, /one flag/i);
    assert.doesNotMatch(r.guidance, /two or more flags/i);
  });
});

describe('Regression guards (already on this build): P0-A, P0-B, downgrade, rollback, raw recovery', () => {
  it('P0-A: a malformed Phase 3 collection is flagged and the first save keeps a byte-exact recovery copy; export refuses', () => {
    const raw = '{"version":1,"weight":[],"workouts":[],"nutrition":[],"sessions":{"historic":"keep-me"}}';
    const s = mem({ [KEY]: raw });
    const st = mk(s);
    assert.equal(st.status().state, 'corrupt');
    assert.throws(() => st.exportJSON(), /damaged|newer/i);
    st.addWeight({ date: '2026-11-17', kg: 80 });
    assert.equal(s.m[RECOVERY], raw, 'byte-exact corrupt-backup');
    assert.notEqual(s.m[KEY], raw, 'live store is no longer the damaged collection');
  });

  it('P0-B: a completed Thursday session stays COMPLETED (not SKIPPED) when a Monday cascade omits Thursday', () => {
    const thu = {
      id: 's-thu', planSlotId: 'v2.1-W1-THU', date: '2026-11-19', status: 'COMPLETED',
      modified: false, variant: 'ORIGINAL_60', blocks: [], createdAt: '2026-11-19T10:00:00.000Z', updatedAt: '2026-11-19T10:00:00.000Z',
    };
    const ev = [{ id: 'e1', kind: 'MISSED_MONDAY', week: 1, date: '2026-11-16', createdAt: '2026-11-19T18:00:00.000Z' }];
    const st = HP.slotStatus('v2.1-W1-THU', [thu], ev);
    assert.equal(st.code, 'COMPLETED');
    assert.notEqual(st.code, 'SKIPPED');
    assert.equal(st.session.id, 's-thu');
    assert.equal(st.omission, 'MISSED_MONDAY_CASCADE');
  });

  it('downgrade guard: Phase 3 data is version 2; a v3 payload is refused and bytes are untouched', () => {
    const s = mem();
    const st = mk(s);
    assert.equal(st.putRecord('walks', { date: D, durationMin: 30 }).ok, true);
    assert.equal(JSON.parse(s.m[KEY]).version, 2);
    assert.equal(JSON.parse(st.exportJSON()).version, 2);
    const raw = '{"version":3,"weight":[],"workouts":[],"nutrition":[],"future":[1]}';
    const s3 = mem({ [KEY]: raw });
    const st3 = mk(s3);
    assert.equal(st3.status().state, 'newer');
    assert.equal(st3.addWeight({ date: D, kg: 80 }).ok, false);
    assert.equal(s3.m[KEY], raw);
    assert.equal(mk(mem()).previewImport(backup({}, 3)).code, 'unsupported_version');
  });

  it('rollback: a failed import write leaves the previous store bytes and keeps the pre-import copy', () => {
    let armed = false;
    const prior = '{"version":2,"weight":[],"workouts":[],"nutrition":[]}';
    const s = mem({ [KEY]: prior }, (k) => { if (k === KEY && armed) { armed = false; return true; } return false; });
    const st = mk(s);
    const text = backup({ weight: [{ id: 'n', createdAt: ts, date: '2026-11-17', kg: 70 }] });
    const p = st.previewImport(text);
    assert.equal(p.ok, true);
    armed = true;
    const r = st.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt });
    assert.equal(r.ok, false);
    assert.equal(s.m[KEY], prior);
    assert.equal(JSON.parse(s.m[PRE]).raw, prior);
  });

  it('rawRecoveryExport is byte-exact; a raw file is refused by normal import and nothing is written', () => {
    const raw = '{"version":2,"weight":[],"workouts":[],"nutrition":[],"sessions":[{"id":"bad","createdAt":"' + ts + '","date":"' + D + '","status":"BOGUS"}]}';
    const src = mk(mem({ [KEY]: raw }));
    const rec = src.rawRecoveryExport();
    assert.equal(rec.ok, true);
    const parsed = HD.parseRawRecovery(rec.text);
    assert.equal(parsed.ok, true);
    assert.equal(parsed.sources[0].raw, raw);
    const s = mem();
    const st = mk(s);
    st.addWeight({ date: '2026-11-17', kg: 80 });
    const before = JSON.stringify(s.m), writes = s.writes;
    assert.equal(st.previewImport(rec.text).code, 'raw_recovery_file');
    const a = st.applyImport(rec.text, { confirm: 'REPLACE', expectCurrent: { weight: 1, workouts: 0, nutrition: 0 } });
    assert.equal(a.ok, false);
    assert.equal(a.code, 'raw_recovery_file');
    assert.equal(JSON.stringify(s.m), before);
    assert.equal(s.writes, writes);
  });
});
