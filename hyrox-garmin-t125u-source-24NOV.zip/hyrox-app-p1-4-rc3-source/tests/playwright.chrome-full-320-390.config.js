'use strict';
// Full Chrome e2e at 320 and 390. Chrome mobile emulation, NOT WebKit and NOT iPhone Safari.
// Feature flag FEATURE_GARMIN_IMPORT remains default-off in app source; specs that need the preview use mocks/forceRender.
const path = require('path');
const { defineConfig } = require('@playwright/test');

const port = Number(process.env.HYROX_APP_PORT || 4188);
const chrome = process.env.HYROX_CHROME || '/usr/bin/google-chrome';
const outRoot = process.env.HYROX_E2E_OUT || '/workspace/hyrox-garmin-build/qa/full-e2e';

function mobile(width, height) {
  return {
    viewport: { width, height },
    screen: { width, height },
    deviceScaleFactor: 3,
    isMobile: true,
    hasTouch: true,
    timezoneId: 'Asia/Qatar',
    locale: 'en-US',
    browserName: 'chromium',
    launchOptions: { executablePath: chrome, args: ['--no-sandbox', '--disable-dev-shm-usage'] }
  };
}

module.exports = defineConfig({
  testDir: path.join(__dirname, 'e2e'),
  testMatch: '**/*.spec.js',
  fullyParallel: false,
  workers: Number(process.env.HYROX_E2E_WORKERS || 3),
  timeout: 30000,
  expect: { timeout: 8000 },
  retries: 0,
  outputDir: path.join(outRoot, 'playwright-results'),
  reporter: [
    ['list'],
    ['json', { outputFile: path.join(outRoot, 'playwright-report.json') }]
  ],
  use: { baseURL: 'http://127.0.0.1:' + port + '/', acceptDownloads: true, trace: 'off', screenshot: 'off', video: 'off' },
  projects: [
    { name: 'chrome-emulation-320-not-safari', metadata: { w: 320 }, use: mobile(320, 568) },
    { name: 'chrome-emulation-390-not-safari', metadata: { w: 390 }, use: mobile(390, 844) }
  ],
  webServer: {
    command: process.execPath + ' ' + JSON.stringify(path.join(__dirname, 'static-server.js')),
    url: 'http://127.0.0.1:' + port + '/',
    reuseExistingServer: false,
    timeout: 20000,
    env: { HYROX_APP_ROOT: path.resolve(__dirname, '..'), HYROX_APP_PORT: String(port) }
  }
});
