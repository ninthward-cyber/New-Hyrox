'use strict';
// P5 restore-safety (Dawit, owner t69u). Synthetic data only. See /workspace/hyrox-p5/CONTRACT.md.
//   P4-O1  empty backup replacing a populated device needs a second explicit confirmation
//   P4-F02 a restore must never overwrite the only pre-import copy of unresolved data (fail closed)
//   P4-F01 an export this build's own restore would refuse must never be presented as restorable
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const { HD, NOW, KEY, RECOVERY, PRE, ts } = require('./p3-helpers.js');

function mapStorage(init) {
  const m = new Map(Object.entries(init || {}));
  return { m, getItem(k) { return m.has(k) ? m.get(k) : null; }, setItem(k, v) { m.set(k, String(v)); }, removeItem(k) { m.delete(k); } };
}
const mk = (s, now) => HD.createStore(s, { now: () => now || NOW });
const snap = (s) => JSON.stringify([...s.m.entries()].sort());
const file = (extra) => JSON.stringify(Object.assign({ app: 'hyrox-app', version: 2, exportedAt: ts, weight: [], workouts: [], nutrition: [] }, extra));
const W = (id, kg) => ({ id, createdAt: ts, date: '2026-11-10', kg: kg === undefined ? 80 : kg });
const ORIG = JSON.stringify({ version: 2, weight: [W('w0', 81.5)], workouts: [], nutrition: [], daily: [] });
const EMPTY_FILE = file({});
const FULL_FILE = file({ weight: [W('w1')] });
function restore(st, text, extra) {
  const p = st.previewImport(text);
  if (!p.ok) return p;
  return st.applyImport(text, Object.assign({ confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt }, extra || {}));
}
// KEY write #1 lands but the read-back lies once, and the rollback write throws -> rollback_failed.
function rollbackFailStorage(orig) {
  const m = new Map([[KEY, orig]]);
  let keyWrites = 0, lieNext = false;
  return { m,
    getItem(k) { if (k === KEY && lieNext) { lieNext = false; return 'garbled'; } return m.has(k) ? m.get(k) : null; },
    setItem(k, v) { if (k === KEY) { keyWrites++; if (keyWrites === 1) { m.set(k, v); lieNext = true; return; } if (keyWrites === 2) throw new Error('Quota'); } m.set(k, String(v)); },
    removeItem(k) { m.delete(k); } };
}
const slot = (s) => JSON.parse(s.m.get(PRE));

describe('P4-O1: empty backup over a populated device needs a second confirmation', () => {
  it('preview flags it and gives per-collection current vs incoming counts', () => {
    const s = mapStorage({ [KEY]: ORIG });
    const p = mk(s).previewImport(EMPTY_FILE);
    assert.equal(p.ok, true);
    assert.equal(p.preview.emptyReplacesPopulated, true);
    assert.equal(p.preview.replaceSummary.incoming.total, 0);
    assert.equal(p.preview.replaceSummary.current.weight, 1);
    assert.equal(p.preview.replaceSummary.current.total, 1);
    for (const c of ['weight', 'workouts', 'nutrition', 'sessions', 'meals', 'body', 'daily', 'walks', 'dayStates', 'planEvents', 'ownerSettings']) {
      assert.equal(typeof p.preview.replaceSummary.incoming[c], 'number', c);
      assert.equal(typeof p.preview.replaceSummary.current[c], 'number', c);
    }
    assert.equal(p.preview.replaceSummary.currentState, 'ok');
  });
  it('apply without the second confirmation is refused and writes NOTHING (byte-exact)', () => {
    const s = mapStorage({ [KEY]: ORIG });
    const before = snap(s);
    const r = restore(mk(s), EMPTY_FILE);
    assert.equal(r.ok, false);
    assert.equal(r.code, 'empty_replace_not_confirmed');
    assert.equal(r.rolledBack, false);
    assert.equal(r.backupKey, null);
    assert.equal(snap(s), before);
    assert.equal(s.m.has(PRE), false);
  });
  it('only a strict boolean true counts as the second confirmation', () => {
    for (const bad of ['true', 1, 'yes', {}, [], null, undefined, false]) {
      const s = mapStorage({ [KEY]: ORIG });
      const before = snap(s);
      const r = restore(mk(s), EMPTY_FILE, { confirmEmptyReplace: bad });
      assert.equal(r.code, 'empty_replace_not_confirmed', String(bad));
      assert.equal(snap(s), before);
    }
  });
  it('with both confirmations the empty backup restores and the previous text is kept byte-exact', () => {
    const s = mapStorage({ [KEY]: ORIG });
    const r = restore(mk(s), EMPTY_FILE, { confirmEmptyReplace: true });
    assert.equal(r.ok, true);
    assert.equal(slot(s).raw, ORIG);
    assert.equal(mk(s).status().state, 'ok');
    assert.equal(JSON.parse(s.m.get(KEY)).weight.length, 0);
  });
  it('a normal (non-empty) restore is unchanged: no flag, no second confirmation', () => {
    const s = mapStorage({ [KEY]: ORIG });
    const p = mk(s).previewImport(FULL_FILE);
    assert.equal(p.preview.emptyReplacesPopulated, false);
    assert.equal(restore(mk(s), FULL_FILE).ok, true);
  });
  it('an empty backup onto an empty device is unchanged (no second confirmation)', () => {
    for (const init of [{}, { [KEY]: '' }, { [KEY]: JSON.stringify({ version: 1, weight: [], workouts: [], nutrition: [] }) }]) {
      const s = mapStorage(init);
      assert.equal(mk(s).previewImport(EMPTY_FILE).preview.emptyReplacesPopulated, false);
      assert.equal(restore(mk(s), EMPTY_FILE).ok, true);
    }
  });
  it('unneeded confirmEmptyReplace is ignored', () => {
    const s = mapStorage({ [KEY]: ORIG });
    assert.equal(restore(mk(s), FULL_FILE, { confirmEmptyReplace: true }).ok, true);
  });
  it('populated means any STORED record: damaged classic entry or a Phase 3 record', () => {
    const damaged = JSON.stringify({ version: 1, weight: [{ id: 'x', date: '2026-11-10', createdAt: ts, kg: '80' }], workouts: [], nutrition: [] });
    const onlyWalk = JSON.stringify({ version: 2, weight: [], workouts: [], nutrition: [], walks: [{ id: 'k1', createdAt: ts, date: '2026-11-10', durationMin: 30 }] });
    for (const [name, raw, state] of [['damaged', damaged, 'ok'], ['walk only', onlyWalk, 'ok']]) {
      const s = mapStorage({ [KEY]: raw });
      const p = mk(s).previewImport(EMPTY_FILE);
      assert.equal(p.preview.emptyReplacesPopulated, true, name);
      assert.equal(p.preview.replaceSummary.currentState, state, name);
      const before = snap(s);
      assert.equal(restore(mk(s), EMPTY_FILE).code, 'empty_replace_not_confirmed', name);
      assert.equal(snap(s), before, name);
    }
  });
  it('unreadable (corrupt) stored text is not counted as populated: its bytes stay in the recovery key and the slot (documented limit)', () => {
    const corrupt = '{"version":2,"weight":[tr';
    const s = mapStorage({ [KEY]: corrupt });
    const p = mk(s).previewImport(EMPTY_FILE);
    assert.equal(p.preview.emptyReplacesPopulated, false);
    assert.equal(p.preview.replaceSummary.currentState, 'corrupt');
    assert.equal(restore(mk(s), EMPTY_FILE).ok, true);
    assert.equal(s.m.get(RECOVERY), corrupt);
    assert.equal(slot(s).raw, corrupt);
  });
  it('an incoming backup is "empty" only if EVERY collection is empty (settings-only or Phase 3 only is not)', () => {
    const s = mapStorage({ [KEY]: ORIG });
    const st = mk(s);
    const settingsOnly = file({ ownerSettings: [{ id: 'app-settings', date: '2026-11-10', createdAt: ts, updatedAt: ts, rhrBaselineBpm: 70 }] });
    const walkOnly = file({ walks: [{ id: 'k1', createdAt: ts, date: '2026-11-10', durationMin: 30 }] });
    for (const f of [settingsOnly, walkOnly]) {
      const p = st.previewImport(f);
      assert.equal(p.ok, true);
      assert.equal(p.preview.emptyReplacesPopulated, false);
    }
    const emptyLists = file({ sessions: [], meals: [], body: [], daily: [], walks: [], dayStates: [], planEvents: [], ownerSettings: [] });
    assert.equal(st.previewImport(emptyLists).preview.emptyReplacesPopulated, true);
  });
  it('stale_plan is still checked when the second confirmation is given', () => {
    const s = mapStorage({ [KEY]: ORIG });
    const st = mk(s);
    const p = st.previewImport(EMPTY_FILE);
    st.addWeight({ date: '2026-11-10', kg: 79 });
    const before = snap(s);
    const r = st.applyImport(EMPTY_FILE, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt, confirmEmptyReplace: true });
    assert.equal(r.code, 'stale_plan');
    assert.equal(snap(s), before);
  });
  it('the evaluation is made at apply time from live storage (a preview from an empty device cannot be reused)', () => {
    const s = mapStorage({});
    const st = mk(s);
    const p = st.previewImport(EMPTY_FILE);
    assert.equal(p.preview.emptyReplacesPopulated, false);
    s.m.set(KEY, ORIG); // another tab populated the device
    const r = st.applyImport(EMPTY_FILE, { confirm: 'REPLACE', expectCurrent: p.preview.current });
    assert.ok(r.code === 'stale_plan' || r.code === 'empty_replace_not_confirmed');
    assert.equal(s.m.get(KEY), ORIG);
  });
});

describe('P4-F02: never overwrite the only pre-import copy of unresolved data', () => {
  it('REPRO: rollback_failed then a second restore is refused; nothing is written; the original stays byte-exact in the slot', () => {
    const s = rollbackFailStorage(ORIG);
    const st = mk(s);
    const r1 = restore(st, FULL_FILE);
    assert.equal(r1.code, 'rollback_failed');
    assert.equal(slot(s).raw, ORIG);
    assert.equal(st.status().priorCopy.restoreState, 'pending');
    assert.equal(st.status().priorCopy.blocksNextRestore, true);
    assert.equal(st.previewImport(file({ weight: [W('w2')] })).preview.priorCopy.blocksRestore, true);
    const before = snap(s);
    const r2 = restore(st, file({ weight: [W('w2')] }));
    assert.equal(r2.ok, false);
    assert.equal(r2.code, 'prior_copy_unresolved');
    assert.equal(r2.rolledBack, false);
    assert.equal(r2.backupKey, PRE);
    assert.equal(snap(s), before, 'a refused restore must write nothing');
    assert.equal(slot(s).raw, ORIG);
  });
  it('the refusal also applies to an empty-backup restore with both confirmations', () => {
    const s = rollbackFailStorage(ORIG);
    const st = mk(s);
    restore(st, FULL_FILE);
    const before = snap(s);
    const r = restore(st, EMPTY_FILE, { confirmEmptyReplace: true });
    assert.equal(r.code, 'prior_copy_unresolved');
    assert.equal(snap(s), before);
  });
  it('the first ordinary restore still works and the slot is marked completed', () => {
    const s = mapStorage({ [KEY]: ORIG });
    const st = mk(s);
    assert.equal(st.previewImport(FULL_FILE).preview.priorCopy, null);
    const r = restore(st, FULL_FILE);
    assert.equal(r.ok, true);
    assert.equal(slot(s).raw, ORIG);
    assert.equal(slot(s).restoreState, 'completed');
    assert.equal(st.status().priorCopy.restoreState, 'completed');
    assert.equal(st.status().priorCopy.blocksNextRestore, false);
  });
  it('a completed restore does not block the next one (unchanged: latest wins; see findings, HOLD)', () => {
    const s = mapStorage({ [KEY]: ORIG });
    const st = mk(s);
    assert.equal(restore(st, FULL_FILE).ok, true);
    const r2 = restore(st, file({ weight: [W('w2')] }));
    assert.equal(r2.ok, true);
    assert.equal(JSON.parse(slot(s).raw).weight[0].id, 'w1');
  });
  it('a failed restore that was rolled back (verified) leaves the slot resolved, even after later edits', () => {
    const m = new Map([[KEY, ORIG]]);
    let keyWrites = 0;
    const s = { m, getItem(k) { return m.has(k) ? m.get(k) : null; },
      setItem(k, v) { if (k === KEY && ++keyWrites === 1) throw new Error('Quota'); m.set(k, String(v)); }, removeItem(k) { m.delete(k); } };
    const st = mk(s);
    const r = restore(st, FULL_FILE);
    assert.equal(r.code, 'write_failed');
    assert.equal(r.rolledBack, true);
    assert.equal(s.m.get(KEY), ORIG);
    assert.equal(slot(s).restoreState, 'rolled_back');
    assert.equal(st.addWeight({ date: '2026-11-10', kg: 70 }).ok, true);
    assert.equal(st.status().priorCopy.blocksNextRestore, false);
    assert.equal(restore(st, FULL_FILE).ok, true);
  });
  it('nothing is lost when the original is back in place (KEY byte-identical to the slot text)', () => {
    const s = rollbackFailStorage(ORIG);
    const st = mk(s);
    restore(st, FULL_FILE);
    s.m.set(KEY, ORIG); // the owner put the original back by hand
    assert.equal(st.status().priorCopy.blocksNextRestore, false);
    assert.equal(restore(st, file({ weight: [W('w2')] })).ok, true);
  });
  it('a restore that never changed KEY (write and rollback both failed) does not block: KEY still holds the original', () => {
    const m = new Map([[KEY, ORIG]]);
    const s = { m, getItem(k) { return m.has(k) ? m.get(k) : null; }, setItem(k, v) { if (k === KEY) throw new Error('Quota'); m.set(k, String(v)); }, removeItem(k) { m.delete(k); } };
    const st = mk(s);
    assert.equal(restore(st, FULL_FILE).code, 'rollback_failed');
    assert.equal(s.m.get(KEY), ORIG);
    assert.equal(slot(s).restoreState, 'pending');
    s.setItem = (k, v) => { m.set(k, String(v)); };
    assert.equal(restore(st, FULL_FILE).ok, true);
  });
  it('a slot from an older build (no restoreState) and a slot of an empty device are not protected', () => {
    const old = JSON.stringify({ kind: 'hyrox-pre-import', savedAt: '2026-11-01T00:00:00.000Z', raw: 'OLD' });
    const s1 = mapStorage({ [KEY]: ORIG, [PRE]: old });
    assert.equal(mk(s1).status().priorCopy.restoreState, 'unknown');
    assert.equal(mk(s1).status().priorCopy.blocksNextRestore, false);
    assert.equal(restore(mk(s1), FULL_FILE).ok, true);
    const nothing = JSON.stringify({ kind: 'hyrox-pre-import', savedAt: ts, raw: null, restoreState: 'pending' });
    const s2 = mapStorage({ [KEY]: ORIG, [PRE]: nothing });
    assert.equal(restore(mk(s2), FULL_FILE).ok, true);
  });
  it('a pending slot whose text differs from KEY blocks, even if both are plausible data', () => {
    const pending = JSON.stringify({ kind: 'hyrox-pre-import', savedAt: ts, raw: ORIG, restoreState: 'pending' });
    const s = mapStorage({ [KEY]: file({ weight: [W('w9')] }), [PRE]: pending });
    const before = snap(s);
    assert.equal(restore(mk(s), FULL_FILE).code, 'prior_copy_unresolved');
    assert.equal(snap(s), before);
  });
  it('finalize write faults never lose the copy: a dropped write leaves the slot pending (fail closed), a torn write is repaired', () => {
    for (const mode of ['throw', 'silent', 'partial']) {
      const m = new Map([[KEY, ORIG]]);
      let preWrites = 0;
      const s = { m, getItem(k) { return m.has(k) ? m.get(k) : null; },
        setItem(k, v) {
          if (k === PRE && ++preWrites === 2) { // the finalize write
            if (mode === 'throw') throw new Error('Quota');
            if (mode === 'silent') return;
            if (mode === 'partial') { m.set(k, String(v).slice(0, 10)); return; }
          }
          m.set(k, String(v));
        }, removeItem(k) { m.delete(k); } };
      const st = mk(s);
      const r = restore(st, FULL_FILE);
      assert.equal(r.ok, true, mode);
      assert.equal(JSON.parse(s.m.get(KEY)).weight[0].id, 'w1', mode);
      assert.equal(slot(s).raw, ORIG, mode + ': slot must still parse and hold the original');
      if (mode !== 'throw') { /* silent/partial: state is pending or repaired-pending */ }
      assert.ok(['pending', 'completed'].includes(slot(s).restoreState), mode);
    }
  });
  it('no extra backup slots are ever created', () => {
    const s = rollbackFailStorage(ORIG);
    const st = mk(s);
    restore(st, FULL_FILE);
    restore(st, file({ weight: [W('w2')] }));
    assert.deepEqual([...s.m.keys()].sort(), [KEY, PRE].sort());
    const s2 = mapStorage({ [KEY]: ORIG });
    restore(mk(s2), FULL_FILE); restore(mk(s2), file({ weight: [W('w2')] }));
    assert.deepEqual([...s2.m.keys()].sort(), [KEY, PRE].sort());
  });
  it('the raw recovery export still carries the exact slot text after a refusal', () => {
    const s = rollbackFailStorage(ORIG);
    const st = mk(s);
    restore(st, FULL_FILE);
    restore(st, file({ weight: [W('w2')] }));
    const raw = st.rawRecoveryExport();
    assert.equal(raw.ok, true);
    const o = JSON.parse(raw.text);
    const src = o.sources.find((x) => x.key === PRE);
    assert.equal(src.raw, s.m.get(PRE));
    assert.equal(JSON.parse(src.raw).raw, ORIG);
  });
});

describe('P4-F02 sweep: one storage fault at every step of restore 1, then restore 2 with healthy storage', () => {
  function faulty(init, failAt, mode) {
    const m = new Map(Object.entries(init));
    let n = 0;
    const hit = () => ++n === failAt;
    return { m,
      getItem(k) { hit(); return m.has(k) ? m.get(k) : null; },
      setItem(k, v) {
        if (hit()) {
          if (mode === 'throw') throw new Error('Quota');
          if (mode === 'silent') return;
          if (mode === 'partial') { m.set(k, String(v).slice(0, 10)); return; }
        }
        m.set(k, String(v));
      },
      removeItem(k) { m.delete(k); } };
  }
  for (const mode of ['throw', 'silent', 'partial']) {
    it(mode + ': the original text always survives restore 2 unless restore 1 verifiably finished', () => {
      let refused2 = 0;
      for (let f = 1; f <= 40; f++) {
        const s = faulty({ [KEY]: ORIG }, f, mode);
        const r1 = mk(s).applyImport(FULL_FILE, { confirm: 'REPLACE', expectCurrent: { weight: 1, workouts: 0, nutrition: 0 }, expectCurrentExt: { daily: 0 } });
        const slotNow = s.m.get(PRE);
        const s2 = mapStorage(Object.fromEntries(s.m));
        const st2 = mk(s2);
        const p2 = st2.previewImport(file({ weight: [W('w2')] }));
        if (!p2.ok) continue; // storage no longer readable as HYROX data: the restore is refused anyway
        const r2 = st2.applyImport(file({ weight: [W('w2')] }), { confirm: 'REPLACE', expectCurrent: p2.preview.current, expectCurrentExt: p2.preview.currentExt });
        if (r2.ok) {
          // allowed only if nothing was at risk: r1 verified OK (slot completed/legacy), or KEY still held the original
          const keptElsewhere = r1.ok === true || s.m.get(KEY) === ORIG || slotNow === undefined || (slotNow && JSON.parse(slotNow).raw !== ORIG);
          assert.ok(keptElsewhere, mode + ' f=' + f + ': restore 2 succeeded while the original lived only in the slot: ' + JSON.stringify(r1));
        } else {
          refused2++;
          assert.equal(r2.code, 'prior_copy_unresolved', mode + ' f=' + f);
          assert.equal(s2.m.get(PRE), slotNow, 'refused restore wrote the slot, f=' + f);
        }
        // in every case the original is still somewhere readable, unless restore 1 finished and restore 2 replaced the slot
        if (!r1.ok && !r2.ok) assert.ok(s2.m.get(KEY) === ORIG || (s2.m.get(PRE) && JSON.parse(s2.m.get(PRE)).raw === ORIG), mode + ' f=' + f);
      }
      assert.ok(refused2 >= 1, 'the fail-closed refusal path must be exercised');
    });
  }
});

describe('P4-F01: an export this build would refuse is never presented as verified restorable', () => {
  const clean = () => { const s = mapStorage({}); const st = mk(s); st.addWeight({ date: '2026-11-10', kg: 80 }); st.addWorkout({ date: '2026-11-10', activity: 'Run', durationMin: 30 }); return { s, st }; };
  it('clean data: restorable true, no reasons, text identical to exportJSON()', () => {
    const { st } = clean();
    const c = st.exportChecked();
    assert.equal(c.ok, true);
    assert.equal(c.restorable, true);
    assert.deepEqual(c.reasons, []);
    assert.equal(c.text, st.exportJSON());
    assert.equal(st.exportSummary().restorable, undefined, 'exportSummary shape is unchanged');
    assert.equal(st.rawRecoveryExport().normalRestorable, true);
  });
  it('empty store: restorable true', () => {
    const st = mk(mapStorage({}));
    const c = st.exportChecked();
    assert.equal(c.ok, true);
    assert.equal(c.restorable, true);
  });
  it('REPRO A: a stored classic entry this build refuses on restore (text number, bad date, no createdAt)', () => {
    for (const bad of [{ id: 'w1', date: '2026-11-10', createdAt: ts, kg: '80' }, { id: 'w1', date: '2026-13-45', createdAt: ts, kg: 80 }, { id: 'w1', date: '2026-11-10', kg: 80 }]) {
      const s = mapStorage({ [KEY]: JSON.stringify({ version: 1, weight: [bad], workouts: [], nutrition: [] }) });
      const st = mk(s);
      const before = snap(s);
      assert.equal(restore(mk(mapStorage({})), st.exportJSON()).code, 'invalid_records', 'baseline fact: own restore refuses it');
      const c = st.exportChecked();
      assert.equal(c.ok, true);
      assert.equal(c.restorable, false);
      assert.equal(c.reasons[0].code === 'invalid_records' || typeof c.reasons[0].code === 'string', true);
      assert.equal(c.reasons[0].collection, 'weight');
      assert.equal(c.reasons[0].id, 'w1');
      assert.equal(typeof c.reasons[0].message, 'string');
      assert.deepEqual(Object.keys(st.exportSummary()).sort(), ['included', 'omitted'], 'exportSummary shape is unchanged');
      const raw = st.rawRecoveryExport();
      assert.equal(raw.normalRestorable, false);
      assert.equal(raw.normalRestorableReasons[0].collection, 'weight');
      assert.ok(/would be refused/i.test(raw.warning), raw.warning);
      assert.equal(JSON.parse(raw.text).sources.find((x) => x.key === KEY).raw, s.m.get(KEY), 'original bytes kept');
      assert.equal(snap(s), before, 'export calls write nothing');
      // nothing omitted or rewritten to force the flag
      assert.equal(JSON.parse(c.text).weight.length, 1);
      assert.deepEqual(JSON.parse(c.text).weight[0], bad);
    }
  });
  it('REPRO B: a stored Phase 3 record dated after today (device clock was ahead)', () => {
    const s = mapStorage({ [KEY]: JSON.stringify({ version: 2, weight: [], workouts: [], nutrition: [], walks: [{ id: 'k1', createdAt: ts, date: '2026-11-12', durationMin: 30 }] }) });
    const st = mk(s);
    const c = st.exportChecked();
    assert.equal(c.restorable, false);
    assert.equal(c.reasons[0].collection, 'walks');
    assert.equal(JSON.parse(c.text).walks.length, 1);
  });
  it('REPRO C: duplicate ids in one list', () => {
    const s = mapStorage({ [KEY]: JSON.stringify({ version: 1, weight: [W('d1'), W('d1', 79)], workouts: [], nutrition: [] }) });
    const c = mk(s).exportChecked();
    assert.equal(c.restorable, false);
    assert.equal(c.reasons[0].code, 'DUPLICATE_ID');
    assert.equal(JSON.parse(c.text).weight.length, 2);
  });
  it('an export over the restore size limit is not restorable (too_large)', () => {
    const big = Object.assign(W('w1'), { note: 'x'.repeat(HD.IMPORT_LIMITS.maxBytes + 100000) }); // Claude P5: was a fixed 2,100,000
    const s = mapStorage({ [KEY]: JSON.stringify({ version: 1, weight: [big], workouts: [], nutrition: [] }) });
    const c = mk(s).exportChecked();
    assert.equal(c.ok, true);
    assert.equal(c.restorable, false);
    assert.equal(c.reasons[0].code, 'too_large');
  });
  it('reasons are capped and report the total', () => {
    const many = []; for (let i = 0; i < 30; i++) many.push({ id: 'b' + i, date: '2026-11-10', createdAt: ts, kg: 'x' });
    const c = mk(mapStorage({ [KEY]: JSON.stringify({ version: 1, weight: many, workouts: [], nutrition: [] }) })).exportChecked();
    assert.equal(c.restorable, false);
    assert.equal(c.reasons.length, 20);
    assert.equal(c.reasonsTotal, 30);
    assert.equal(c.reasonsTruncated, true);
  });
  it('unavailable states do not throw: ok:false with a code', () => {
    assert.equal(mk(mapStorage({ [KEY]: '{"version":2,"weight":[tr' })).exportChecked().ok, false);
    assert.equal(mk(mapStorage({ [KEY]: JSON.stringify({ version: 9, weight: [], workouts: [], nutrition: [] }) })).exportChecked().ok, false);
    const bad = { getItem() { throw new Error('x'); }, setItem() {}, removeItem() {} };
    const r = mk(bad).exportChecked();
    assert.equal(r.ok, false);
    assert.equal(r.code, 'storage_unreadable');
    const c = HD.createStore(null, { now: () => NOW }).exportChecked();
    assert.equal(c.ok, false);
    assert.equal(c.code, 'storage_unavailable');
  });
  it('a restorable export really restores (the flag is not a guess)', () => {
    const { st } = clean();
    const c = st.exportChecked();
    assert.equal(restore(mk(mapStorage({})), c.text).ok, true);
  });
  it('exportJSON() is unchanged (still a string)', () => {
    const { st } = clean();
    assert.equal(typeof st.exportJSON(), 'string');
  });
});
