'use strict';
// Claude Phase 10 independent review: regression tests. Synthetic data only; stub provider; no network.
// On Grok's Phase 10 these FAIL:
//  - a single photo had no 1600 px cap and no cost check (owner approved the cap, 17 Nov 2026);
//  - the image cost bound assumed patch billing for every model, so gpt-4o-mini (tile-billed at 2833 base / 5667 per
//    512-px tile, OpenAI "Images and vision") passed 3 photos whose real cost is about 3x the $0.004 reservation;
//  - request text was counted in characters, which undercounts multi-byte notes;
//  - removing an eaten amount from the note also removed the food ("ate half the rice" was sent as "").
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const fs = require('node:fs');

const load = () => Promise.all([import('./p9-helpers.mjs'), import('../netlify/lib/config.mjs'), import('../netlify/lib/openai.mjs')]);
const fx = (n) => fs.readFileSync(path.join(__dirname, 'fixtures', n)).toString('base64');
const ledger = (c) => (c.store.m.get('ledger/v1') || {}).data || null;
const multi = (H, imgs, over = {}) => H.analyzeReq({ body: JSON.stringify({ images: imgs, description: '', consent: true, requestId: 'req-' + Math.random().toString(36).slice(2, 10), ...over }) });
const img = (b64, label = 'SAME_PLATE') => ({ imageBase64: b64, mimeType: 'image/jpeg', label });

test('a single photo over 1600 px is refused before any storage write or provider call (owner cap)', async () => {
  const [H] = await load();
  const c = H.setup();
  const r = await c.handle(H.analyzeReq({ bodyObj: { imageBase64: fx('p10-over-1600.jpg') } }));
  assert.equal(r.status, 413);
  assert.match((await r.json()).detail.message, /1600 pixels/);
  assert.equal(c.fetchStub.calls.length, 0); assert.equal(ledger(c), null);
  // a normal single photo is unchanged
  assert.equal((await c.handle(H.analyzeReq())).status, 200);
});

test('default model: the largest request the server accepts provably fits the $0.004 reservation (single and 3 photos)', async () => {
  const [H, C, O] = await load();
  const cfg = C.readConfig({ ...H.BASE_ENV }).config;
  assert.equal(cfg.model, 'gpt-6-luna');
  const worstNote = '\u{1F35B}'.repeat(250); // 500 UTF-16 units (the limit), 1000 UTF-8 bytes
  const one = [{ width: 1600, height: 1600 }];
  const three = [one[0], one[0], one[0]];
  const t1 = O.requestTextChars(cfg, 'x', worstNote), t3 = O.requestTextChars(cfg, [{ b64: '', label: 'BEFORE' }, { b64: '', label: 'AFTER' }, { b64: '', label: 'EXTRA_DISH' }], worstNote);
  const w1 = C.worstCaseUsd(cfg, one, t1), w3 = C.worstCaseUsd(cfg, three, t3);
  assert.ok(w1 <= cfg.reserveUsd, 'single worst ' + w1); assert.ok(w3 <= cfg.reserveUsd, 'three worst ' + w3);
  // the bounds used: >= every published patch multiplier, 3000 output tokens (enforced by max_output_tokens), text in bytes
  assert.ok(C.TOKEN_BOUND.patchMultiplier >= 2.46);
  assert.equal(cfg.maxOutputTokens, 3000);
});

test('text is counted in UTF-8 bytes, so a multi-byte note cannot be undercounted', async () => {
  const [H, C, O] = await load();
  const cfg = C.readConfig({ ...H.BASE_ENV }).config;
  const ascii = O.requestTextChars(cfg, 'x', ''), emoji = O.requestTextChars(cfg, 'x', '\u{1F35B}'.repeat(250));
  assert.ok(emoji - ascii >= 1000, 'each emoji is 4 bytes: ' + (emoji - ascii));
});

test('gpt-4o-mini (tile-billed) cannot pass 3 photos or a large single photo under the default reservation', async () => {
  const [H] = await load();
  const c = H.setup({ env: { HYROX_PHOTO_MODEL: 'gpt-4o-mini' } });
  const A = fx('p10-view-a.jpg'), B = fx('p10-view-b.jpg'), Cc = fx('p10-view-c.jpg');
  const r3 = await c.handle(multi(H, [img(A), img(B, 'AFTER'), img(Cc, 'EXTRA_DISH')]));
  assert.equal(r3.status, 413); assert.equal(c.fetchStub.calls.length, 0); assert.equal(ledger(c), null);
});

test('every model in the price table: the largest accepted request is either refused or fits the reservation', async () => {
  const [H, C, O] = await load();
  for (const model of Object.keys(C.PRICE_TABLE)) {
    const cfg = C.readConfig({ ...H.BASE_ENV, HYROX_PHOTO_MODEL: model }).config;
    for (const n of [1, 2, 3]) {
      const ims = Array.from({ length: n }, () => ({ width: 1600, height: 1600 }));
      const photos = n === 1 ? 'x' : ims.map(() => ({ b64: '', label: 'SAME_PLATE' }));
      const w = C.worstCaseUsd(cfg, ims, O.requestTextChars(cfg, photos, 'n'.repeat(500)));
      // the handler sends only when w <= reserve; for tile-billed gpt-4o-mini the bound must reflect tiles
      if (model === 'gpt-4o-mini') assert.ok(w > cfg.reserveUsd, model + ' x' + n + ' must be refused (tile billing), bound ' + w);
      assert.ok(Number.isFinite(w) && w > 0, model);
    }
  }
});

test('eaten amounts are removed from the note but the food words are kept (owner decision 17 Nov 2026)', () => {
  const AI = require('../src/ai/photo-ai.js');
  assert.equal(AI.analysisNote('ate half the rice'), 'rice');
  assert.equal(AI.analysisNote('three quarters of the rice eaten'), 'rice');
  assert.equal(AI.analysisNote('ate none of the sauce'), 'sauce');
  assert.equal(AI.analysisNote('Ate HALF the Basmati Rice'), 'Basmati Rice', 'kept as typed');
  assert.equal(AI.analysisNote('butter chicken, all chicken eaten, 60% sauce'), 'butter chicken, chicken, sauce');
  assert.equal(AI.analysisNote('ate half'), '', 'no food word: nothing is sent');
  assert.equal(AI.analysisNote('2% milk'), '2% milk', 'food descriptions are untouched');
  // only the amount changed -> identical note (no stale estimate, no new paid call)
  assert.equal(AI.analysisNote('butter chicken, all chicken eaten, 40% sauce'), AI.analysisNote('butter chicken, all chicken eaten, 60% sauce'));
  // the eaten amount itself is still applied locally
  const f = AI.noteFractions('ate half the rice', [{ name: 'White rice', role: 'SIDE' }]);
  assert.equal(f.suggestions.length, 1); assert.equal(f.suggestions[0].fraction, 0.5);
});
