'use strict';
// P6 (Dawit): estimate -> toComponents -> meal. The meal built from the helper output must be accepted by putRecord as DRAFT and
// CONFIRMED, survive normal export -> previewImport/applyImport with provenance intact, and count toward day totals ONLY when CONFIRMED.
// Synthetic data only. The meals validator is NOT changed by this work.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const HD = require(path.resolve(__dirname, '../src/data/hyrox-data.js'));
const HN = require(path.resolve(__dirname, '../src/data/hyrox-nutrition.js'));
const FC = require(path.resolve(__dirname, '../src/data/hyrox-foodcalc.js'));
const DB = require(path.resolve(__dirname, '../src/data/food-db.json'));

const NOW = new Date('2026-11-13T09:00:00Z'), ts = NOW.toISOString(), DAY = '2026-11-12';
const mem = (init) => { const m = new Map(Object.entries(init || {})); return { m, getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => { m.set(k, String(v)); }, removeItem: (k) => { m.delete(k); } }; };
const mk = (s) => HD.createStore(s, { now: () => NOW });
const r1 = (n) => Math.round(n * 10) / 10;
const TEXT = '2 eggs, 150 g rice, 1 cup milk, 1 tbsp olive oil, half an avocado, 100 g qwertyuiop';

const built = () => FC.toComponents(FC.estimate(TEXT, DB));
const meal = (extra) => Object.assign({ id: 'meal-p6-1', date: DAY, time: '12:30', label: 'Synthetic lunch', description: TEXT, source: 'DESCRIPTION', lifecycle: 'DRAFT', components: built().components }, extra || {});
const confirmed = (extra) => Object.assign(meal({ lifecycle: 'CONFIRMED', confirmedAt: ts }), extra || {});

describe('P6 toComponents: shape', () => {
  it('matched items become components; everything else is listed separately with raw, status, message', () => {
    const r = FC.estimate(TEXT, DB), c = FC.toComponents(r);
    assert.equal(c.components.length, 5);
    assert.deepEqual(c.unmatched.map((u) => [u.raw, u.status]), [['100 g qwertyuiop', 'no_match']]);
    assert.ok(c.unmatched[0].message.length > 3);
    assert.deepEqual(Object.keys(c).sort(), ['components', 'unmatched']);
  });
  it('each component: role OTHER, eatenFraction null, preparation "", four ESTIMATED macros equal to the item, provenance', () => {
    const r = FC.estimate(TEXT, DB), c = FC.toComponents(r).components;
    c.forEach((x, i) => {
      const it = r.items[i];
      assert.equal(x.role, 'OTHER'); assert.equal(x.eatenFraction, null); assert.equal(x.preparation, '');
      assert.deepEqual(x.kcal, { value: it.nutrients.kcal, state: 'ESTIMATED' }); assert.deepEqual(x.proteinG, { value: it.nutrients.proteinG, state: 'ESTIMATED' });
      assert.deepEqual(x.carbsG, { value: it.nutrients.carbsG, state: 'ESTIMATED' }); assert.deepEqual(x.fatG, { value: it.nutrients.fatG, state: 'ESTIMATED' });
      assert.deepEqual(x.provenance, it.provenance);
      assert.ok(x.name.length > 0 && x.name.length <= 80); assert.ok(x.portion.length > 0 && x.portion.length <= 80);
      assert.equal(Object.prototype.hasOwnProperty.call(x, 'lifecycle'), false, 'the helper never sets a lifecycle');
    });
    assert.equal(c[0].name, 'Eggs'); assert.equal(c[0].portion, '2 large (100 g)'); assert.equal(c[1].portion, '150 g');
  });
  it('provenance is small (about 100-300 bytes per component) so a year of meals stays tiny', () => {
    for (const x of built().components) assert.ok(JSON.stringify(x.provenance).length < 400);
  });
  it('failed / empty / garbage estimate results give no components and no throw', () => {
    const empty = { components: [], unmatched: [] };
    for (const v of [FC.estimate('2 eggs', {}), FC.estimate('2 eggs'), null, undefined, 3, 'x', {}, { ok: true }, { ok: true, items: 'x' }]) assert.deepEqual(FC.toComponents(v), empty);
    assert.deepEqual(FC.toComponents(FC.estimate('', DB)), empty);
    const onlyBad = FC.toComponents(FC.estimate('100 g qwertyuiop, 100 g cheese', DB)); assert.equal(onlyBad.components.length, 0); assert.equal(onlyBad.unmatched.length, 2);
  });
  it('very long names/portions are cut to the meals limits (80)', () => {
    const r = FC.estimate('1 ' + 'x'.repeat(300), DB); const t = { ok: true, items: [Object.assign({}, FC.estimate('2 eggs', DB).items[0], { food: 'y'.repeat(300) })] };
    const c = FC.toComponents(t).components[0]; assert.equal(c.name.length, 80); assert.ok(r.ok);
  });
  it('the estimate result is not mutated', () => {
    const r = FC.estimate(TEXT, DB), before = JSON.stringify(r); FC.toComponents(r); assert.equal(JSON.stringify(r), before);
  });
});

describe('P6 meal from components: putRecord validation (validator unchanged)', () => {
  it('accepted as DRAFT', () => {
    const st = mk(mem()); const r = st.putRecord('meals', meal()); assert.equal(r.ok, true, JSON.stringify(r.errors));
    assert.equal(st.records('meals').length, 1); assert.equal(st.damagedRecords().length, 0);
  });
  it('accepted as NEEDS_REVIEW and CONSUMED_INTENT too', () => {
    for (const lc of ['NEEDS_REVIEW', 'CONSUMED_INTENT']) { const st = mk(mem()); assert.equal(st.putRecord('meals', meal({ lifecycle: lc })).ok, true, lc); }
  });
  it('accepted as CONFIRMED (confirmedAt set by the caller, i.e. the owner pressing confirm)', () => {
    const st = mk(mem()); const r = st.putRecord('meals', confirmed()); assert.equal(r.ok, true, JSON.stringify(r.errors));
    assert.equal(st.records('meals')[0].lifecycle, 'CONFIRMED'); assert.equal(st.damagedRecords().length, 0);
  });
  it('provenance and every component field are stored exactly as built', () => {
    const st = mk(mem()); const m = confirmed(); st.putRecord('meals', m);
    const stored = st.records('meals')[0];
    assert.deepEqual(stored.components, m.components); assert.equal(stored.components[0].provenance.fdcId, 171287);
  });
  it('a meal whose only components come from the helper but is edited by the owner (portion/grams changed) is still valid', () => {
    const edited = FC.toComponents({ ok: true, items: [FC.estimateItem('2 eggs', DB, { grams: 120 }), FC.estimateItem('1 cup cheese', DB, { fdcId: 173424 })] });
    assert.equal(edited.components.length, 2);
    assert.equal(mk(mem()).putRecord('meals', meal({ components: edited.components })).ok, true);
    assert.equal(edited.components[0].portion, '120 g'); assert.equal(edited.components[0].provenance.portion.endsWith('[user_grams]'), true);
  });
  it('the largest allowed item (just under the validator caps) is accepted; items beyond are refused by the estimator, not stored as DAMAGED', () => {
    const big = FC.toComponents({ ok: true, items: [FC.estimateItem('1000 g olive oil', DB)] });
    assert.equal(big.components.length, 1); assert.equal(mk(mem()).putRecord('meals', meal({ components: big.components })).ok, true);
    assert.equal(FC.toComponents({ ok: true, items: [FC.estimateItem('5000 g olive oil', DB)] }).components.length, 0);
  });
  it('50 components (the maximum a meal holds) from one estimate are accepted', () => {
    const t = Array.from({ length: 60 }, (_, i) => (i + 1) + ' g rice').join(', ');
    const c = FC.toComponents(FC.estimate(t, DB)); assert.equal(c.components.length, 50);
    assert.equal(mk(mem()).putRecord('meals', meal({ components: c.components })).ok, true);
  });
  // P7 (owner decision P6-1): this was a characterisation of the open choice "validator NOT changed" (any provenance shape accepted).
  // The owner decided to validate it, so the same input is now refused. Only the expectation changed (true -> false).
  it('P7: the meals validator now refuses an arbitrary provenance shape (was: accepted, owner decision P6-1)', () => {
    const c = built().components; c[0].provenance = { anything: 'goes', n: [1, 2, 3] };
    assert.equal(mk(mem()).putRecord('meals', meal({ components: c })).ok, false);
  });
});

describe('P6 meal from components: export -> import round trip with the existing confirmations', () => {
  const cycle = (target, text) => {
    const p = target.previewImport(text); assert.equal(p.ok, true, JSON.stringify(p));
    return target.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt });
  };
  it('normal export contains the meal with provenance; restore into an EMPTY device brings it back unchanged', () => {
    const src = mk(mem()); src.putRecord('meals', meal()); src.putRecord('meals', confirmed({ id: 'meal-p6-2', label: 'Confirmed one' }));
    const x = src.exportChecked(); assert.equal(x.restorable, true, JSON.stringify(x));
    const file = JSON.parse(x.text); assert.equal(file.meals.length, 2); assert.deepEqual(file.meals[0].components[0].provenance, built().components[0].provenance);
    const dst = mk(mem()); const r = cycle(dst, x.text); assert.equal(r.ok, true, JSON.stringify(r));
    const got = dst.records('meals'); assert.equal(got.length, 2);
    for (const g of got) { assert.deepEqual(g.components, built().components); assert.equal(g.components[0].provenance.dbVersion, DB.meta.dbVersion); }
    assert.equal(got.find((g) => g.id === 'meal-p6-1').lifecycle, 'DRAFT'); assert.equal(got.find((g) => g.id === 'meal-p6-2').lifecycle, 'CONFIRMED');
    assert.equal(dst.damagedRecords().length, 0);
  });
  it('restore onto a POPULATED device needs the REPLACE confirm + expected-current guard and keeps provenance', () => {
    const src = mk(mem()); src.putRecord('meals', confirmed());
    const text = src.exportJSON();
    const dst = mk(mem()); dst.addWeight({ date: '2026-11-10', kg: 80 });
    const p = dst.previewImport(text); assert.equal(p.ok, true);
    const noConfirm = dst.applyImport(text, { expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt }); assert.equal(noConfirm.ok, false, 'still refused without confirm');
    assert.equal(dst.records('meals').length, 0);
    const r = cycle(dst, text); assert.equal(r.ok, true, JSON.stringify(r));
    assert.deepEqual(dst.records('meals')[0].components[2].provenance, built().components[2].provenance);
  });
  it('raw recovery export carries the provenance text too', () => {
    const src = mk(mem()); src.putRecord('meals', meal());
    assert.ok(JSON.stringify(src.rawRecoveryExport()).includes('USDA_FDC'));
  });
});

describe('P6 nutrition totals: an estimate counts ONLY once the meal is CONFIRMED (existing HyroxNutrition rules)', () => {
  const sum = (k) => r1(built().components.reduce((a, c) => a + c[k].value, 0));
  it('DRAFT / NEEDS_REVIEW / CONSUMED_INTENT: nothing in the confirmed day subtotal', () => {
    for (const lc of ['DRAFT', 'NEEDS_REVIEW', 'CONSUMED_INTENT']) {
      const st = mk(mem()); st.putRecord('meals', meal({ lifecycle: lc }));
      const d = HN.dayState(DAY, st.records('meals'), null);
      assert.equal(d.confirmedCount, 0, lc); assert.equal(d.subtotal.kcal.value, null, lc); assert.equal(d.subtotal.proteinG.value, null, lc);
      assert.equal(d.dayKcal, null);
    }
  });
  it('CONFIRMED: the day subtotal equals the sum of the ESTIMATED components (eaten fraction 1 for a typed meal)', () => {
    const st = mk(mem()); st.putRecord('meals', confirmed());
    const m = st.records('meals')[0], t = HN.mealTotals(m);
    for (const [k, key] of [['kcal', 'kcal'], ['proteinG', 'proteinG'], ['carbsG', 'carbsG'], ['fatG', 'fatG']]) { assert.equal(t[key].value, sum(k), k); assert.equal(t[key].state, 'ESTIMATED'); assert.equal(t[key].unknownCount, 0); }
    const d = HN.dayState(DAY, st.records('meals'), null);
    assert.equal(d.confirmedCount, 1); assert.equal(d.subtotal.kcal.value, sum('kcal')); assert.equal(d.subtotal.proteinG.value, sum('proteinG'));
    assert.equal(HN.completeness(m), 'CONFIRMED_COMPLETE');
  });
  it('confirming the draft later (same id) is what makes it count; before that it did not', () => {
    const st = mk(mem()); st.putRecord('meals', meal());
    assert.equal(HN.dayState(DAY, st.records('meals'), null).subtotal.kcal.value, null);
    assert.equal(st.putRecord('meals', confirmed()).ok, true);
    assert.equal(st.records('meals').length, 1);
    assert.equal(HN.dayState(DAY, st.records('meals'), null).subtotal.kcal.value, sum('kcal'));
  });
  it('an item that was not matched contributes nothing (unknown is not 0): no component, so no fake zero', () => {
    const c = FC.toComponents(FC.estimate('2 eggs, 100 g qwertyuiop', DB));
    assert.equal(c.components.length, 1); assert.equal(c.unmatched.length, 1);
    const st = mk(mem()); st.putRecord('meals', confirmed({ components: c.components }));
    assert.equal(HN.mealTotals(st.records('meals')[0]).kcal.value, c.components[0].kcal.value);
  });
  it('an estimated kcal is never marked KNOWN and a confirmed-fast / D5 day logic is untouched (no new rules)', () => {
    for (const c of built().components) for (const k of ['kcal', 'proteinG', 'carbsG', 'fatG']) assert.equal(c[k].state, 'ESTIMATED');
    const st = mk(mem()); st.putRecord('meals', confirmed());
    const d = HN.dayState(DAY, st.records('meals'), null);
    assert.equal(d.code, 'D2'); assert.equal(d.fullDay, false, 'without the owner attesting a complete day the day stays in progress');
  });
});
