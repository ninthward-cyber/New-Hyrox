'use strict';
// Meron (QA): adversarial probes of Dawit's Round 2 API (build a92f482 = Liya 3aa277b + F9 517d90c + t54u a8b80b3).
// Synthetic data only. Does not edit the F6/F7/F8 tests in p3-meron-adversarial.test.js.

const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const HW = require(path.resolve(__dirname, '../src/data/hyrox-wellness.js'));
const HP = require(path.resolve(__dirname, '../src/data/hyrox-plan.js'));
const HN = require(path.resolve(__dirname, '../src/data/hyrox-nutrition.js'));
const { HD, KEY, mem, mk, O, K, U, ts, backup, restore } = require('./p8-helpers.js');

const sess = (o) => Object.assign({
  id: 'x' + Math.random().toString(36).slice(2), createdAt: ts, status: 'COMPLETED',
  modified: false, variant: 'NONE', blocks: [], planSlotId: null,
}, o);

describe("open item (c): demanding-definition edges (current behaviour; 'demanding' is RPE>=7, or intervals/race when no RPE, plus Dawit's planned-slot / intensity rules)", () => {
  // Contract: easy only if no v2.1 planSlotId AND (intensity === 'EASY' OR (rpe <= 4 AND every block is walk/mobility/warmup/cooldown/rest)). Otherwise demanding. All planned gym sessions are demanding.
  it('RPE 4 is easy; RPE 5 is demanding; missing RPE with no intensity is demanding', () => {
    assert.equal(HP.isDemandingSession(sess({ rpe: 4 })), false);
    assert.equal(HP.isDemandingSession(sess({ rpe: 4, blocks: [{ kind: 'walk' }, { kind: 'mobility' }] })), false);
    assert.equal(HP.isDemandingSession(sess({ rpe: 5 })), true);
    assert.equal(HP.isDemandingSession(sess({ rpe: 5, blocks: [{ kind: 'walk' }] })), true);
    assert.equal(HP.isDemandingSession(sess({})), true, 'missing RPE, no intensity → demanding (unknown = conservative)');
  });

  it('a mixed walk plus a strength block at RPE 4 is demanding', () => {
    assert.equal(HP.isDemandingSession(sess({ rpe: 4, blocks: [{ kind: 'walk' }, { kind: 'strength_set' }] })), true);
  });

  it('intensity EASY with RPE 8 is easy only when the session is unplanned; a planned gym slot stays demanding', () => {
    assert.equal(HP.isDemandingSession(sess({ intensity: 'EASY', rpe: 8 })), false);
    assert.equal(HP.isDemandingSession(sess({ intensity: 'EASY', rpe: 8, planSlotId: 'v2.1-W1-MON' })), true);
    assert.equal(HP.isDemandingSession(sess({ planSlotId: 'v2.1-W1-THU', rpe: 2, intensity: 'EASY' })), true);
  });
});

describe('FINDING (current behaviour): F7 refuses a synthetic older backup that has a fractional daily total — possible data-loss on restore', () => {
  // Documents CURRENT behaviour only. A v1-shaped backup with steps.value 10.5 is rejected
  // as invalid_records and nothing is written. If a real pre-F7 backup contains a fractional
  // OBSERVED daily total, Restore will refuse the whole file. Severity: MEDIUM (the on-device
  // store is unchanged, but the backup cannot be restored on this build without editing).
  it('previewImport/applyImport of a v1 backup with daily steps 10.5 is refused and writes nothing', () => {
    const text = backup({
      daily: [{ id: 'legacy-frac', createdAt: '2026-11-08T08:00:00.000Z', date: '2026-11-08', steps: O(10.5) }],
    }, 1);
    const s = mem();
    const st = mk(s);
    st.addWeight({ date: '2026-11-17', kg: 80 });
    const before = s.m[KEY], writes = s.writes;
    const p = st.previewImport(text);
    assert.equal(p.ok, false);
    assert.equal(p.code, 'invalid_records');
    assert.ok((p.errors || []).some((e) => e.list === 'daily' && e.field === 'steps'));
    const a = st.applyImport(text, { confirm: 'REPLACE', expectCurrent: { weight: 1, workouts: 0, nutrition: 0 } });
    assert.equal(a.ok, false);
    assert.equal(s.m[KEY], before);
    assert.equal(s.writes, writes);
  });

  // t54u landed in Dawit a8b80b3 / build a92f482. Field names taken from that implementation
  // (collection, id, date, field, value, rule, howToCorrect) — not invented.
  it('the refusal details array identifies the exact field, date and value, and live data is unchanged', () => {
    const text = backup({
      daily: [{ id: 'legacy-frac', createdAt: '2026-11-08T08:00:00.000Z', date: '2026-11-08', steps: O(10.5) }],
    }, 1);
    const s = mem();
    const st = mk(s);
    st.addWeight({ date: '2026-11-17', kg: 80 });
    const before = s.m[KEY], writes = s.writes;
    const p = st.previewImport(text);
    assert.equal(p.ok, false);
    assert.equal(p.code, 'invalid_records');
    assert.ok(Array.isArray(p.details) && p.details.length >= 1);
    const d = p.details.find((x) => x.collection === 'daily' && x.date === '2026-11-08' && x.id === 'legacy-frac');
    assert.ok(d, 'expected a details entry for daily legacy-frac / 2026-11-08: ' + JSON.stringify(p.details));
    assert.equal(d.field, 'steps.value');
    assert.equal(d.value, 10.5);
    assert.equal(d.rule, 'must be a whole number 0..200000');
    assert.match(d.howToCorrect, /steps\.value/);
    assert.match(d.howToCorrect, /whole number/);
    const a = st.applyImport(text, { confirm: 'REPLACE', expectCurrent: { weight: 1, workouts: 0, nutrition: 0 } });
    assert.equal(a.ok, false);
    assert.ok(Array.isArray(a.details));
    assert.equal(s.m[KEY], before);
    assert.equal(s.writes, writes);
  });
});

// ---- Round 2 independent review (Claude, 2026-11-18) ----
// The two tests below REPLACE Meron's two "characterization (current behaviour)" tests. Those tests
// passed while asserting behaviour the audit brief told us not to preserve (a fractional walk count
// reported as the day's steps; a whole daily record hidden because of one bad pain value). They now
// assert the repaired behaviour. Full coverage is in tests/r2-claude-integrity.test.js.
describe('repaired (was a characterization): fractional WALK steps of 10.5 are refused on entry and never counted', () => {
  it('putRecord refuses 10.5; an older backup holding 10.5 still restores exactly, and daySteps never reports or rounds it', () => {
    const st = mk(mem());
    const put = st.putRecord('walks', { id: 'w-frac', date: '2026-11-18', durationMin: 30, steps: 10.5 });
    assert.equal(put.ok, false);
    assert.equal(st.records('walks').length, 0);

    // Restore behaviour for older backups is an open owner decision, so it is not newly refused.
    const text = backup({ walks: [{ id: 'w-frac', createdAt: ts, updatedAt: ts, date: '2026-11-18', durationMin: 30, steps: 10.5 }] });
    const s2 = mem(); const st2 = mk(s2);
    const preview = st2.previewImport(text);
    assert.equal(preview.ok, true);
    assert.ok(preview.preview.warnings.some((w) => /not a whole number/.test(w)));
    assert.equal(restore(st2, text).ok, true);
    assert.equal(JSON.parse(s2.m[KEY]).walks[0].steps, 10.5, 'stored exactly as the backup held it');
    assert.equal(st2.records('walks')[0].steps, null, 'shown as not usable, not as 10.5 and not rounded');
    const ds2 = HW.daySteps('2026-11-18', { walks: st2.records('walks'), dailies: st2.records('daily'), sessions: st2.records('sessions') });
    assert.equal(ds2.walkSteps, null);
    assert.equal(ds2.total, null);
    assert.ok(ds2.flags.includes('INVALID_STEP_COUNT_IGNORED'));

    // Contrast: the daily-total F7 rule is unchanged.
    assert.equal(mk(mem()).putRecord('daily', { date: '2026-11-18', steps: O(10.5) }).ok, false);
  });
});

describe('repaired (was a characterization): a stored daily with out-of-range pain keeps its valid values', () => {
  function inject() {
    const rec = {
      id: 'd-bad', createdAt: ts, updatedAt: ts, date: '2026-11-17',
      footPain: O(11), stairKneePain: O(1), sleepH: O(7),
      limp: { state: 'OBSERVED', value: false }, steps: O(8000),
    };
    const s = mem();
    const st = mk(s);
    st.addWeight({ date: '2026-11-17', kg: 80 });
    const raw = JSON.parse(s.m[KEY]);
    raw.version = 2;
    raw.daily = [rec];
    s.m[KEY] = JSON.stringify(raw);
    return { rec, s, st: mk(s) };
  }

  it('records() keeps the daily; the gate uses the valid sleep and limp, names footPain as invalid, and the export keeps the record', () => {
    const { rec, s, st } = inject();
    const before = s.m[KEY];
    assert.equal(st.status().state, 'ok');
    assert.equal(st.records('daily').length, 1);
    const fromStore = HW.tenKGate('2026-11-17', st.records('daily'));
    assert.equal(fromStore.status, 'UNKNOWN');
    assert.deepEqual(fromStore.missing, ['footPain']);
    assert.deepEqual(fromStore.invalid, ['footPain']);
    assert.equal(fromStore.checks.find((c) => c.key === 'sleepH').value, 7);
    assert.equal(fromStore.checks.find((c) => c.key === 'limp').value, false);
    assert.equal(fromStore.checks.find((c) => c.key === 'stairKneePain').value, 1);

    // The store now gives the same answer as evaluating the raw record directly.
    const fromRaw = HW.tenKGate('2026-11-17', [rec]);
    assert.equal(fromRaw.status, fromStore.status);
    assert.deepEqual(fromRaw.invalid, fromStore.invalid);

    const sum = st.exportSummary();
    assert.equal(sum.omittedExt, undefined);
    assert.deepEqual(sum.salvagedExt, { daily: 1 });
    const exp = JSON.parse(st.exportJSON());
    assert.equal(exp.daily.length, 1);
    assert.equal(exp.daily[0].sleepH.value, 7);
    assert.equal(exp.daily[0].footPain.state, 'INVALID');
    assert.equal(s.m[KEY], before, 'the stored text, pain 11 included, is untouched');
    assert.equal(mk(mem()).putRecord('daily', { date: '2026-11-17', footPain: O(11), sleepH: O(7) }).ok, false);
  });
});

describe('adversarial: gate inputs, variantDraft, weekend dates, DF/no-zero, repeat import', () => {
  it('putRecord rejects out-of-range, string and NaN gate fields; a missing gate input stays UNKNOWN, never 0', () => {
    const st = mk(mem());
    assert.equal(st.putRecord('daily', { date: '2026-11-18', footPain: O(11) }).ok, false);
    assert.equal(st.putRecord('daily', { date: '2026-11-18', footPain: O(-1) }).ok, false);
    assert.equal(st.putRecord('daily', { date: '2026-11-18', footPain: { state: 'OBSERVED', value: '2' } }).ok, false);
    assert.equal(st.putRecord('daily', { date: '2026-11-18', footPain: { state: 'OBSERVED', value: NaN } }).ok, false);
    assert.equal(st.putRecord('daily', { date: '2026-11-18', limp: { state: 'OBSERVED', value: 1 } }).ok, false);
    const g = HW.step10kGate({ footPain: 1, limp: false, stairKneePain: 1 }); // sleep missing
    assert.equal(g.status, 'UNKNOWN');
    assert.equal(g.pass, false);
    assert.equal(g.checks.filter((c) => c.key === 'sleepH')[0].value, null);
    const str = HW.step10kGate({ heelArchAchillesPain: '2', limp: false, stairKneePain: 1, sleepH: 7 });
    assert.equal(str.status, 'UNKNOWN');
    assert.equal(str.pass, false);
    const nan = HW.step10kGate({ footPain: NaN, limp: false, stairKneePain: 1, sleepH: 7 });
    assert.equal(nan.status, 'UNKNOWN');
    assert.equal(nan.pass, false);
  });

  it('variantDraft has no fabricated loads or reps; a draft does not become COMPLETED; summary planned is 20 and qualifyingNumerator is null', () => {
    const d = HP.variantDraft('v2.1-W1-WED', 'SOURCE_25_MIN');
    assert.equal(d.status, 'NOT_STARTED');
    assert.equal(d.durationMin, null);
    d.blocks.forEach((b) => {
      assert.equal(b.loadKg, undefined);
      assert.equal(b.reps, undefined);
      assert.equal(b.distanceM, undefined);
    });
    const st = mk(mem());
    assert.equal(st.putRecord('sessions', d).ok, true);
    const sum = HP.summary(st.records('sessions'), []);
    assert.equal(sum.COMPLETED, 0);
    assert.equal(sum.planned, 20);
    assert.equal(sum.qualifyingNumerator, null);
    assert.equal(sum.numeratorStatus, 'OWNER_DECISION_PENDING');
  });

  it('a variantDraft that an attacker then fills with fabricated loadKg/reps is still not a completed session, and putRecord does not invent completion', () => {
    const d = HP.variantDraft('v2.1-W1-MON', 'SOURCE_25_MIN', '2026-11-16');
    d.blocks[1].loadKg = 100;
    d.blocks[1].reps = 5;
    d.durationMin = 25;
    const st = mk(mem());
    const r = st.putRecord('sessions', d);
    // Either refused or stored still as NOT_STARTED — never auto-completed.
    if (r.ok) {
      assert.equal(r.entry.status, 'NOT_STARTED');
      assert.equal(HP.summary(st.records('sessions'), []).COMPLETED, 0);
    }
  });

  it('weekend dates are never offered as make-up, including under a Mon cascade; optional mobility stays non-make-up', () => {
    const ev = [{ kind: 'MISSED_MONDAY', week: 1 }];
    const dates = HP.rescheduleDates('v2.1-W1-TUE', [], ev, '2026-11-18');
    assert.ok(dates.every((d) => !['2026-11-21', '2026-11-22'].includes(d)));
    assert.equal(HP.effectiveWeek(2, []).weekendMakeUp, false);
    assert.ok(HP.effectiveWeek(2, []).weekendOptions.every((o) => o.gymMakeUp === false && o.counted === false));
  });

  it('DF still maps to canonicalCode D4; unanswered empty day is D1 with dayKcal null, never an invented 0', () => {
    const empty = HN.dayState('2026-11-18', [], null);
    assert.equal(empty.code, 'D1');
    assert.equal(empty.canonicalCode, 'D1');
    assert.equal(empty.dayKcal, null);
    const att = { date: '2026-11-18', attestation: 'COMPLETE', basis: empty.basis, fast: 'CONFIRMED_FULL_DAY_FAST' };
    const df = HN.dayState('2026-11-18', [], att);
    assert.equal(df.code, 'DF');
    assert.equal(df.canonicalCode, 'D4');
    assert.equal(df.dayKcal, 0);
  });

  it('repeated import of a valid file with runSteps and a reference-goal daily does not duplicate records', () => {
    const src = mk(mem());
    src.putRecord('sessions', {
      date: '2026-11-18', status: 'COMPLETED', modified: false, variant: 'NONE', blocks: [],
      id: 'a', runSteps: 1000, runStepsSource: 'DEVICE',
    });
    src.putRecord('daily', { id: 'd', date: '2026-11-18', steps: O(8000) });
    const text = src.exportJSON();
    const st = mk(mem());
    assert.equal(restore(st, text).ok, true);
    assert.equal(restore(st, text).ok, true);
    assert.equal(st.records('sessions').length, 1);
    assert.equal(st.records('daily').length, 1);
    assert.equal(st.records('sessions')[0].runSteps, 1000);
  });
});

describe('DEFECT (regression guard): step10kGate must not treat a negative pain value as PASS', () => {
  // F9 fix landed in Dawit 517d90c / build 704e449: a negative pain reading is UNKNOWN, never PASS.
  // putRecord still rejects footPain -1 (must be 0–10). Kept as a regression guard.
  it('footPain or stairKneePain of -1 is UNKNOWN, never PASS', () => {
    const a = HW.step10kGate({ footPain: -1, limp: false, stairKneePain: 1, sleepH: 7 });
    const b = HW.step10kGate({ footPain: 1, limp: false, stairKneePain: -1, sleepH: 7 });
    assert.equal(a.status, 'UNKNOWN', 'footPain -1: ' + JSON.stringify(a));
    assert.equal(a.pass, false);
    assert.equal(b.status, 'UNKNOWN', 'stairKneePain -1: ' + JSON.stringify(b));
    assert.equal(b.pass, false);
  });
});

describe('DEFECT (regression guard): pain outside 0-10 must be UNKNOWN, never PASS (owner t54u)', () => {
  // Owner t54u: pain values outside 0–10 (negative AND >10) must be UNKNOWN, never PASS.
  // The pain-11 expectation was changed from FAIL to UNKNOWN only because of that owner decision.
  // Fix landed in Dawit a8b80b3 / build a92f482. A limp still gives FAIL.
  it('footPain or stairKneePain of 11 is UNKNOWN, never PASS', () => {
    const a = HW.step10kGate({ footPain: 11, limp: false, stairKneePain: 1, sleepH: 7 });
    const b = HW.step10kGate({ footPain: 1, limp: false, stairKneePain: 11, sleepH: 7 });
    assert.equal(a.status, 'UNKNOWN', 'footPain 11 was ' + a.status + ': ' + JSON.stringify(a));
    assert.equal(a.pass, false);
    assert.equal(b.status, 'UNKNOWN', 'stairKneePain 11 was ' + b.status);
    assert.equal(b.pass, false);
  });

  it('a limp still gives FAIL, even when a pain value is out of range', () => {
    const neg = HW.step10kGate({ footPain: -1, limp: true, stairKneePain: 1, sleepH: 7 });
    const hi = HW.step10kGate({ footPain: 11, limp: true, stairKneePain: 1, sleepH: 7 });
    assert.equal(neg.status, 'FAIL');
    assert.ok(neg.failed.includes('limp'));
    assert.equal(neg.pass, false);
    assert.equal(hi.status, 'FAIL');
    assert.ok(hi.failed.includes('limp'));
    assert.equal(hi.pass, false);
  });
});
