'use strict';
// P6 Meron red-team of HyroxFoodCalc on p6/data b418faa (CONTRACT-P6.md v2.1).
// Real holes that yield confident wrong numbers, a silent choice, a write to
// hyrox.v1, or totals from an unconfirmed meal become failing DEFECT tests.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const { loadFoodCalc, loadFoodDb, mem, mk, plant, KEY, HD } = require('./p6-meron-helpers.js');

const HN = require(path.resolve(__dirname, '../src/data/hyrox-nutrition.js'));
const FC = loadFoodCalc();
const DB = FC.loadDb(loadFoodDb()).db;
assert.ok(FC && DB, 'foodcalc and food-db must be present on this tree');

function est(text) { return FC.estimate(text, DB); }
function one(text) { return est(text).items[0]; }
function noNutrients(it, label) {
  // Unparsed / no_portion items may name a chosen food so the editor can ask for a quantity or unit.
  // A confident wrong number is nutrients set on a non-matched item, or a silent choice on ambiguous/no_match.
  assert.equal(it.nutrients, null, label + ' must not guess nutrients: ' + JSON.stringify(it.nutrients));
  if (it.status === 'ambiguous' || it.status === 'no_match') {
    assert.equal(it.chosen, null, label + ' must not silently choose a food: ' + JSON.stringify(it.chosen));
  }
}
function unmatchedStatus(it) {
  return it.status === 'no_match' || it.status === 'unparsed' || it.status === 'ambiguous' || it.status === 'no_portion';
}

describe('P6 red-team: units', () => {
  it('g, kg, oz, lb convert as mass; cup / tbsp / tsp / ml use USDA rows; piece/egg uses the alias default', () => {
    const g = one('100 g rice');
    assert.equal(g.status, 'matched'); assert.equal(g.chosen.fdcId, 168878); assert.equal(g.grams, 100);
    assert.equal(g.nutrients.kcal, 130); assert.equal(g.nutrients.proteinG, 2.7);

    const kg = one('2 kg rice');
    assert.equal(kg.status, 'matched'); assert.equal(kg.grams, 2000);

    const oz = one('1 oz whole milk');
    assert.equal(oz.status, 'matched'); assert.equal(oz.chosen.fdcId, 171265);
    assert.equal(oz.grams, 28.35);

    const cup = one('1 cup whole milk');
    assert.equal(cup.status, 'matched'); assert.equal(cup.grams, 244); assert.equal(cup.nutrients.kcal, 149);

    const tbsp = one('1 tbsp olive oil');
    assert.equal(tbsp.status, 'matched'); assert.equal(tbsp.chosen.fdcId, 171413);
    assert.equal(tbsp.grams, 13.5); assert.equal(tbsp.nutrients.kcal, 119);

    const tsp = one('1 tsp olive oil');
    assert.equal(tsp.status, 'matched'); assert.equal(tsp.grams, 4.5);

    const ml = one('5 ml olive oil');
    assert.equal(ml.status, 'matched'); assert.ok(ml.grams > 0); assert.equal(ml.nutrients.kcal >= 0, true);

    const egg = one('2 eggs');
    assert.equal(egg.status, 'matched'); assert.equal(egg.chosen.fdcId, 171287);
    assert.equal(egg.unit, null); assert.equal(egg.grams, 100); assert.equal(egg.nutrients.kcal, 143);

    const piece = one('1 piece banana');
    assert.equal(piece.status, 'matched'); assert.equal(piece.chosen.fdcId, 173944); assert.equal(piece.grams, 118);
  });

  it('a missing unit on a non-count food is no_portion, not a guessed gram weight or cup', () => {
    const it = one('2 rice');
    assert.equal(it.status, 'no_portion');
    noNutrients(it, '2 rice');
    assert.equal(it.grams, null);
  });
});

describe('P6 red-team: fractions and bad quantities', () => {
  it('1/2, unicode ½, 1 1/2, 0.5 and half all scale the official 244 g cup of whole milk', () => {
    const texts = ['1/2 cup whole milk', '½ cup whole milk', '1 1/2 cups whole milk', '0.5 cup whole milk', 'half a cup of whole milk', 'half cup whole milk'];
    const half = [74, 3.8]; // rounded 122 g of 61 kcal / 3.15 protein
    const oneHalf = [223, 11.5]; // 366 g
    for (const t of texts) {
      const it = one(t);
      assert.equal(it.status, 'matched', t);
      assert.equal(it.chosen.fdcId, 171265, t);
      if (/1 1\/2/.test(t)) {
        assert.equal(it.amount, 1.5, t);
        assert.equal(it.nutrients.kcal, oneHalf[0], t);
        assert.equal(it.nutrients.proteinG, oneHalf[1], t);
      } else {
        assert.equal(it.amount, 0.5, t);
        assert.equal(it.nutrients.kcal, half[0], t);
        assert.equal(it.nutrients.proteinG, half[1], t);
      }
    }
    assert.equal(one('1 and a half cups milk').status, 'matched');
    assert.equal(one('1 and a half cups milk').amount, 1.5);
  });

  it('0, 1/0, -1, NaN and huge quantities never become a matched nutrient guess', () => {
    const cases = {
      '0 eggs': { status: 'unparsed' },
      '0 g rice': { status: 'unparsed' },
      '1/0 cup rice': null, // may be unparsed / no_match / ambiguous; must not be matched
      '-1 cup rice': null,
      'NaN g rice': null,
      '1000000 eggs': { status: 'unparsed' },
      '10000 kg rice': { status: 'unparsed' },
      'Infinity g rice': null,
    };
    for (const [text, exp] of Object.entries(cases)) {
      const r = est(text);
      assert.equal(r.ok, true, text);
      assert.ok(r.items.length >= 1, text);
      for (const it of r.items) {
        assert.notEqual(it.status, 'matched', 'DEFECT if ' + text + ' is matched: ' + JSON.stringify(it));
        assert.equal(it.nutrients, null, 'DEFECT if ' + text + ' has nutrients: ' + JSON.stringify(it.nutrients));
        if (exp && exp.status) assert.equal(it.status, exp.status, text);
      }
      assert.deepEqual(r.totals, { kcal: 0, proteinG: 0, carbsG: 0, fatG: 0, matchedCount: 0, unmatchedCount: r.items.length });
    }
  });
});

describe('P6 red-team: no_match, ambiguous, missing quantity', () => {
  it('no_match (unknown food) has no guessed numbers, no chosen food, no candidates', () => {
    const it = one('1 cup qwerty-zaq-unknown-food-xyz');
    assert.equal(it.status, 'no_match');
    noNutrients(it, 'unknown');
    assert.deepEqual(it.candidates, []);
    assert.equal(it.grams, null);
    assert.match(String(it.message), /no match/i);
    assert.deepEqual(est('1 cup qwerty-zaq-unknown-food-xyz').totals.matchedCount, 0);
  });

  it('ambiguous: candidates (max 5, scored, deterministic) are surfaced; nothing is chosen; picking one makes it matched', () => {
    const it = one('100 g cheese');
    assert.equal(it.status, 'ambiguous');
    noNutrients(it, '100 g cheese');
    assert.equal(it.grams, null);
    assert.ok(it.candidates.length >= 2 && it.candidates.length <= 5);
    const scores = it.candidates.map((c) => c.score);
    assert.deepEqual(scores, scores.slice().sort((a, b) => b - a));
    assert.deepEqual(it.candidates, one('100 g cheese').candidates);
    assert.match(String(it.message), /pick one/i);
    const pick = FC.estimateItem('100 g cheese', DB, { fdcId: it.candidates[0].fdcId, dataset: it.candidates[0].dataset });
    assert.equal(pick.status, 'matched');
    assert.equal(pick.chosen.fdcId, it.candidates[0].fdcId);
    assert.ok(pick.nutrients && Number.isFinite(pick.nutrients.kcal));
  });

  it('generic words (chicken, oil) stay ambiguous even with a quantity — never a silent default', () => {
    for (const t of ['100g chicken', '1 cup chicken', 'chicken', 'oil']) {
      const it = one(t);
      assert.equal(it.status, 'ambiguous', t);
      noNutrients(it, t);
    }
  });

  it('a missing quantity is unparsed, not assumed to be 1, and has no nutrients', () => {
    const it = one('banana');
    assert.equal(it.status, 'unparsed');
    assert.equal(it.nutrients, null);
    assert.equal(it.grams, null);
    assert.equal(it.chosen.fdcId, 173944);
    assert.match(String(it.message), /quantity/i);
    assert.equal(est('banana').totals.matchedCount, 0);
  });
});

describe('P6 red-team: negative carbs are clamped to 0 in the estimator (DB keeps the USDA value)', () => {
  it('Foundation rows with carbohydrate-by-difference < 0 yield carbsG 0 and say so', () => {
    const f = DB.foods.find((x) => x[5] < 0);
    assert.ok(f, 'expected at least one negative-carb row in the bundled DB');
    assert.ok(f[5] < 0, 'DB must keep the official negative value, not clamp it');
    const it = FC.estimateItem('150 g x', DB, { fdcId: f[0], dataset: f[1] });
    assert.equal(it.status, 'matched');
    assert.equal(it.nutrients.carbsG, 0);
    assert.ok(it.nutrients.kcal >= 0 && Number.isFinite(it.nutrients.kcal));
    assert.ok(it.nutrients.proteinG >= 0 && it.nutrients.fatG >= 0);
    assert.match(it.message, /negative/);
  });
});

describe('P6 red-team: only CONFIRMED meals count; un-confirming removes them', () => {
  const TS = '2026-11-13T09:00:00.000Z';
  function meal(id, lifecycle, kcal) {
    return {
      id, createdAt: TS, updatedAt: TS, date: '2026-11-13',
      label: 'Synthetic red-team meal', source: 'DESCRIPTION', lifecycle,
      confirmedAt: lifecycle === 'CONFIRMED' ? TS : undefined,
      eatenFraction: 1,
      components: [{
        name: 'Rice', role: 'MAIN', eatenFraction: null,
        kcal: { value: kcal, state: 'ESTIMATED' },
        proteinG: { value: 4, state: 'ESTIMATED' },
        carbsG: { value: 44, state: 'ESTIMATED' },
        fatG: { value: 1, state: 'ESTIMATED' },
      }],
    };
  }

  it('DRAFT, NEEDS_REVIEW, CONSUMED_INTENT and an edited unconfirmed meal add 0; only CONFIRMED is in the subtotal', () => {
    const confirmed = meal('m-c', 'CONFIRMED', 200);
    const draft = meal('m-d', 'DRAFT', 500);
    const review = meal('m-r', 'NEEDS_REVIEW', 500);
    const pending = meal('m-p', 'CONSUMED_INTENT', 500);
    const edited = Object.assign(meal('m-e', 'DRAFT', 900), { updatedAt: '2026-11-13T10:00:00.000Z' });
    const ds = HN.dayState('2026-11-13', [confirmed, draft, review, pending, edited], null);
    assert.equal(ds.subtotal.kcal.value, 200);
    assert.equal(ds.subtotal.proteinG.value, 4);
  });

  it('un-confirming a stored meal (CONFIRMED -> DRAFT) removes its nutrients from the day subtotal', () => {
    const s = mem();
    const st = mk(s);
    // Phase 3 meals are read with records(), not list() (list() is the core weight/workout/nutrition API).
    const confirmed = Object.assign(meal('m-live', 'CONFIRMED', 200), { time: '12:30' });
    const put = st.putRecord('meals', confirmed);
    assert.equal(put.ok, true, JSON.stringify(put.errors || put));
    const before = HN.dayState('2026-11-13', st.records('meals'), null);
    assert.equal(before.subtotal.kcal.value, 200);
    const unconfirm = Object.assign({}, confirmed, { lifecycle: 'DRAFT', confirmedAt: undefined, updatedAt: '2026-11-13T10:00:00.000Z' });
    const up = st.putRecord('meals', unconfirm);
    assert.equal(up.ok, true, JSON.stringify(up.errors || up));
    const after = HN.dayState('2026-11-13', st.records('meals'), null);
    // An unlogged day reports unknown calories (null), not 0. The confirmed subtotal must no longer include 200.
    assert.equal(after.confirmedCount, 0);
    assert.notEqual(after.subtotal.kcal.value, 200);
    assert.ok(after.subtotal.kcal.value === 0 || after.subtotal.kcal.value === null, 'expected 0 or unknown null, got ' + after.subtotal.kcal.value);
    assert.ok(after.subtotal.proteinG.value === 0 || after.subtotal.proteinG.value === null);
    assert.equal(st.records('meals')[0].lifecycle, 'DRAFT');
  });
});

describe('P6 red-team: estimator and status write nothing to hyrox.v1 (byte-exact, write spy)', () => {
  it('status() and parse/estimate/toComponents do not call setItem/removeItem/clear on a store or on global localStorage', () => {
    const s = mem();
    const raw = plant(s, JSON.stringify({
      version: 2, weight: [{ id: 'w-live', createdAt: '2026-11-13T09:00:00.000Z', date: '2026-11-12', kg: 80.2 }],
      workouts: [], nutrition: [], sessions: [], meals: [], body: [], daily: [], walks: [], dayStates: [], planEvents: [], ownerSettings: [],
    }));
    const st = mk(s);
    s.calls.length = 0;
    const before = s.snapshot();
    const beforeKey = s.getItem(KEY);

    const lsCalls = [];
    const lsMem = {};
    const spy = {
      getItem(k) { lsCalls.push(['get', k]); return Object.prototype.hasOwnProperty.call(lsMem, k) ? lsMem[k] : null; },
      setItem(k, v) { lsCalls.push(['set', k, String(v)]); lsMem[k] = String(v); },
      removeItem(k) { lsCalls.push(['remove', k]); delete lsMem[k]; },
      clear() { lsCalls.push(['clear']); Object.keys(lsMem).forEach((k) => { delete lsMem[k]; }); },
      key() { return null; },
      get length() { return Object.keys(lsMem).length; },
    };
    const prev = Object.getOwnPropertyDescriptor(globalThis, 'localStorage');
    Object.defineProperty(globalThis, 'localStorage', { value: spy, configurable: true, writable: true });
    try {
      const status = st.status();
      assert.equal(status.keyPresent, true);
      assert.equal(typeof status.counts.total, 'number');
      const parsed = FC.parse('2 eggs, 100g rice, bread and butter', DB);
      assert.equal(parsed.ok, true);
      const estimated = FC.estimate('2 eggs, 100g rice, 1 cup whole milk', DB);
      assert.equal(estimated.ok, true);
      FC.toComponents(estimated);
      FC.estimateItem('100 g cheese', DB, { fdcId: 173424 });
    } finally {
      if (prev) Object.defineProperty(globalThis, 'localStorage', prev);
      else delete globalThis.localStorage;
    }

    const writes = lsCalls.filter((c) => c[0] === 'set' || c[0] === 'remove' || c[0] === 'clear');
    assert.deepEqual(writes, [], 'global localStorage write spy: ' + JSON.stringify(writes));
    assert.deepEqual(s.keyWrites(), [], 'store keyWrites: ' + JSON.stringify(s.keyWrites()));
    assert.equal(s.getItem(KEY), raw);
    assert.equal(s.getItem(KEY), beforeKey);
    assert.equal(s.snapshot(), before);
  });
});

describe('P6 red-team: " and " splitting (CONTRACT-P6.md v2.1 — bugs are defects)', () => {
  function noConfidentGuess(r, label) {
    assert.equal(r.ok, true, label);
    for (const it of r.items || []) {
      if (it.status !== 'matched') {
        assert.equal(it.nutrients, null, label + ' unmatched item leaked nutrients: ' + JSON.stringify(it));
        if (it.status === 'ambiguous' || it.status === 'no_match') {
          assert.equal(it.chosen, null, label + ' silently chose a food with status ' + it.status + ': ' + JSON.stringify(it.chosen));
        }
      } else {
        for (const v of Object.values(it.nutrients)) {
          assert.ok(Number.isFinite(v) && v >= 0, label + ' bad number ' + v);
        }
      }
    }
  }

  it('v2.2: bread and butter splits into bread + butter (any case, also &); pickle in the same segment stays one ambiguous pickle item', () => {
    // CONTRACT-P6.md v2.2: this phrase is split even though the DB has "bread ... and ... butter" in pickle rows.
    // Exception: the same comma-segment contains pickle/pickles -> stays whole (ambiguous pickle candidates, no silent numbers).
    for (const text of ['bread and butter', 'BREAD AND BUTTER', 'Bread And Butter', 'bread & butter']) {
      const r = est(text);
      noConfidentGuess(r, text);
      assert.equal(r.items.length, 2, text);
      assert.equal(r.items[0].food, 'bread', text);
      assert.equal(r.items[1].food, 'butter', text);
      assert.equal(r.items[0].status, 'unparsed', text);
      assert.equal(r.items[1].status, 'unparsed', text);
      assert.equal(r.items[0].nutrients, null, text);
      assert.equal(r.items[1].nutrients, null, text);
      assert.match(String(r.items[0].message), /quantity/i, text);
      assert.equal(FC.parse(text, DB).items.length, 2, 'parse ' + text);
    }

    const quantified = est('2 slices bread and 1 tbsp butter');
    noConfidentGuess(quantified, '2 slices bread and 1 tbsp butter');
    assert.equal(quantified.items.length, 2);
    assert.equal(quantified.items[0].status, 'matched');
    assert.equal(quantified.items[0].chosen.fdcId, 174924);
    assert.equal(quantified.items[0].grams, 58);
    assert.equal(quantified.items[0].nutrients.kcal, 154);
    assert.equal(quantified.items[1].status, 'matched');
    assert.equal(quantified.items[1].chosen.fdcId, 173410);
    assert.equal(quantified.items[1].grams, 14.2);
    assert.equal(quantified.items[1].nutrients.kcal, 102);
    assert.equal(quantified.totals.kcal, 256);
    assert.equal(quantified.totals.matchedCount, 2);

    const half = est('2 slices bread and butter');
    assert.equal(half.items.length, 2);
    assert.equal(half.items[0].status, 'matched');
    assert.equal(half.items[0].nutrients.kcal, 154);
    assert.equal(half.items[1].status, 'unparsed');
    assert.equal(half.items[1].food, 'butter');
    assert.equal(half.items[1].nutrients, null);

    for (const text of ['bread and butter pickles', 'bread & butter pickle', 'BREAD AND BUTTER PICKLES', 'bread and butter pickle']) {
      const r = est(text);
      noConfidentGuess(r, text);
      assert.equal(r.items.length, 1, text);
      assert.equal(r.items[0].status, 'ambiguous', text);
      assert.match(r.items[0].food, /bread and butter pickle/, text);
      assert.equal(r.items[0].nutrients, null, text);
      assert.equal(r.items[0].chosen, null, text);
      assert.ok(r.items[0].candidates.length >= 1);
      for (const c of r.items[0].candidates) {
        assert.match(c.description, /pickle/i, text + ' candidate was not a pickle row: ' + c.description);
      }
      assert.equal(FC.parse(text, DB).items[0].joined, true, text);
    }
  });

  it('eggs and bacon stays ONE ambiguous item (fast-food / babyfood candidates); numbers stay unset. "2 eggs and 3 bacon" splits to sane matched quantities', () => {
    const r = est('eggs and bacon');
    noConfidentGuess(r, 'eggs and bacon');
    assert.equal(r.items.length, 1);
    const it = r.items[0];
    assert.equal(it.status, 'ambiguous');
    assert.equal(it.food, 'eggs and bacon');
    assert.equal(it.nutrients, null);
    assert.equal(it.chosen, null);
    assert.deepEqual(r.totals.kcal, 0);
    assert.ok(it.candidates.length >= 2);
    // candidates may be biscuits / babyfood — that is only a defect if one is silently chosen.
    assert.equal(it.chosen, null);

    const quantified = est('2 eggs and 3 bacon');
    assert.equal(quantified.items.length, 2);
    assert.equal(quantified.items[0].status, 'matched');
    assert.equal(quantified.items[0].chosen.fdcId, 171287);
    assert.equal(quantified.items[0].nutrients.kcal, 143);
    assert.equal(quantified.items[1].status, 'matched');
    assert.equal(quantified.items[1].food, 'bacon');
    assert.ok(quantified.items[1].nutrients.kcal > 0 && quantified.items[1].nutrients.kcal < 800);
    assert.equal(quantified.totals.kcal, quantified.items[0].nutrients.kcal + quantified.items[1].nutrients.kcal);
  });

  it('known dishes stay whole and ambiguous (no silent numbers); dishes USDA does not list split', () => {
    const whole = {
      'rice and beans': /rice and beans/,
      '1 cup rice and beans': /rice and beans/,
      'mac and cheese': /macaroni and cheese/,
      '1 cup mac and cheese': /macaroni and cheese/,
      'chicken and rice': /chicken and rice/,
    };
    for (const [text, food] of Object.entries(whole)) {
      const r = est(text);
      noConfidentGuess(r, text);
      assert.equal(r.items.length, 1, text);
      assert.equal(r.items[0].status, 'ambiguous', text);
      assert.match(r.items[0].food, food, text);
      assert.equal(r.items[0].nutrients, null, text);
      assert.equal(r.items[0].chosen, null, text);
    }
    const split = {
      'salt and pepper': ['salt', 'pepper'],
      'fish and chips': ['fish', 'chips'],
      'peanut butter and jelly': ['peanut butter', 'jelly'],
    };
    for (const [text, foods] of Object.entries(split)) {
      const r = est(text);
      noConfidentGuess(r, text);
      assert.equal(r.items.length, 2, text + ' ' + JSON.stringify(r.items.map((i) => i.food)));
      assert.deepEqual(r.items.map((i) => i.food), foods);
      for (const it of r.items) assert.ok(unmatchedStatus(it), text + ' ' + it.status);
    }
  });

  it('mac spelling variants normalise; AND casing and extra spaces still join or split as the lower-cased phrase would', () => {
    for (const t of ['mac and cheese', 'mac & cheese', 'mac n cheese', "mac 'n' cheese"]) {
      const p = FC.parse(t, DB);
      assert.equal(p.items.length, 1, t);
      assert.equal(p.items[0].food, 'macaroni and cheese', t);
      assert.equal(est(t).items[0].status, 'ambiguous', t);
      assert.equal(est(t).items[0].nutrients, null, t);
    }
    // v2.2: BREAD AND BUTTER splits (covered above). Other cased/spaced dishes still join as in v2.1.
    for (const t of ['Eggs AND Bacon', 'rice  and  beans']) {
      const r = est(t);
      noConfidentGuess(r, t);
      assert.equal(r.items.length, 1, t);
      assert.equal(r.items[0].status, 'ambiguous', t);
    }
  });

  it('a leading "and" is dropped; a trailing "and" does not invent numbers; "2 eggs and 1 banana" stays two matched items; "1 and a half" is protected', () => {
    const lead = est('and eggs');
    noConfidentGuess(lead, 'and eggs');
    assert.equal(lead.items.length, 1);
    assert.equal(lead.items[0].food, 'eggs');
    assert.equal(lead.items[0].nutrients, null);

    const trail = est('eggs and');
    noConfidentGuess(trail, 'eggs and');
    for (const it of trail.items) assert.notEqual(it.status, 'matched');

    const two = est('2 eggs and 1 banana');
    assert.equal(two.items.length, 2);
    assert.equal(two.items[0].chosen.fdcId, 171287);
    assert.equal(two.items[1].chosen.fdcId, 173944);
    assert.equal(two.totals.matchedCount, 2);

    const half = est('1 and a half cups milk');
    assert.equal(half.items.length, 1);
    assert.equal(half.items[0].status, 'matched');
    assert.equal(half.items[0].amount, 1.5);
  });

  it('parse(text[, db]): with a DB, known dishes stay whole; without a DB only alias names do; bad db values never throw and agree with parse(text)', () => {
    const withDb = FC.parse('mac and cheese', DB);
    assert.equal(withDb.items.length, 1);
    assert.equal(withDb.items[0].food, 'macaroni and cheese');
    assert.equal(withDb.items[0].joined, true);

    const noDb = FC.parse('mac and cheese');
    assert.equal(noDb.items.length, 2);
    assert.deepEqual(noDb.items.map((i) => i.food), ['macaroni', 'cheese']);

    for (const bad of [null, undefined, {}, [], { foods: [] }, { meta: {}, foods: 'no' }, 'x']) {
      let r;
      assert.doesNotThrow(() => { r = FC.parse('mac and cheese', bad); });
      assert.equal(r.ok, true, JSON.stringify(bad));
      assert.deepEqual(r.items.map((i) => i.food), ['macaroni', 'cheese'], JSON.stringify(bad));
    }

    const a = FC.parse('2 eggs and 1 banana', DB);
    const b = FC.parse('2 eggs and 1 banana');
    assert.equal(a.items.length, 2);
    assert.deepEqual(a.items.map((i) => ({ amount: i.amount, food: i.food })), b.items.map((i) => ({ amount: i.amount, food: i.food })));
  });
});

describe('P6 red-team: fl oz and quart input units (CONTRACT-P6.md v2.2)', () => {
  it('fl oz spellings parse as unit "fl oz"; milk uses its USDA fl oz row (30.5 g), not weight oz', () => {
    for (const text of ['1 fl oz whole milk', '1 fl. oz whole milk', '1 fl.oz whole milk', '1 floz whole milk', '1 fluid ounce whole milk', '1 fluid ounces whole milk', '1 fluid oz whole milk']) {
      const p = FC.parse(text, DB);
      assert.equal(p.items.length, 1, text);
      assert.equal(p.items[0].unit, 'fl oz', text);
      assert.equal(p.items[0].amount, 1, text);
      const it = one(text);
      assert.equal(it.status, 'matched', text);
      assert.equal(it.unit, 'fl oz', text);
      assert.equal(it.chosen.fdcId, 171265, text);
      assert.equal(it.grams, 30.5, text);
      assert.equal(it.nutrients.kcal, 19, text);
    }
    const two = one('2 fl oz whole milk');
    assert.equal(two.grams, 61);
    assert.equal(two.nutrients.kcal, 37);
    // Milk has a bare USDA fl oz row, so a typed fl oz uses that row directly (no ml conversion message).
    assert.equal(one('1 fl oz whole milk').message.includes('converted'), false);
  });

  it('quart / qt spellings parse as unit "quart"; 1 quart milk is 976 g via the USDA cup row, not a silent count-row pick', () => {
    for (const text of ['1 quart whole milk', '1 quarts whole milk', '1 qt whole milk', '1 qts whole milk']) {
      const p = FC.parse(text, DB);
      assert.equal(p.items[0].unit, 'quart', text);
      const it = one(text);
      assert.equal(it.status, 'matched', text);
      assert.equal(it.unit, 'quart', text);
      assert.equal(it.chosen.fdcId, 171265, text);
      assert.equal(it.grams, 976, text);
      assert.equal(it.nutrients.kcal, 595, text);
      assert.match(it.message, /Quarts converted with the USDA "cup" row/i, text);
    }
    const two = one('2 quarts whole milk');
    assert.equal(two.grams, 1952);
  });

  it('plain oz stays weight (28.3495 g); fl oz with no USDA volume row is no_portion (no density guess)', () => {
    const oz = one('8 oz chicken breast');
    assert.equal(oz.status, 'matched');
    assert.equal(oz.unit, 'oz');
    assert.equal(oz.grams, 226.8);
    const floz = one('8 fl oz chicken breast');
    assert.equal(floz.status, 'no_portion');
    assert.equal(floz.unit, 'fl oz');
    assert.equal(floz.nutrients, null);
    assert.equal(floz.grams, null);
    assert.match(String(floz.message), /no density is guessed/i);
  });
});
