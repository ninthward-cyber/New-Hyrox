'use strict';
// P6 (Dawit): " and " is a separator UNLESS the whole phrase is one known food (alias name, or a DB description with the phrase's
// words in order with "and" between them). Commas, semicolons, newlines (and & / +) always split. Expected results are derived from the
// DB itself with independent regex checks, never hard-coded guesses about what USDA contains.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const FC = require(path.resolve(__dirname, '../src/data/hyrox-foodcalc.js'));
const DB = require(path.resolve(__dirname, '../src/data/food-db.json'));

const tiny = (foods) => ({ meta: { schema: 1, dbVersion: 'test-db' }, foods });
const r2 = (n) => Math.round(n * 100) / 100;
const descs = (re) => DB.foods.filter((f) => re.test(f[2]));
const split = (t, db) => FC.estimate(t, db === undefined ? DB : db).items;
const byKey = {}; DB.foods.forEach((f) => { byKey[f[1] + ':' + f[0]] = f; });

describe('P6 "and": mac and cheese', () => {
  const rows = descs(/\bmacaroni and cheese\b/i);
  it('the DB really has macaroni-and-cheese foods (premise of the tests below)', () => { assert.ok(rows.length >= 3); });
  it('"1 cup mac and cheese" stays ONE item, normalised to "macaroni and cheese", quantity and unit kept', () => {
    const r = FC.estimate('1 cup mac and cheese', DB); assert.equal(r.items.length, 1);
    const i = r.items[0];
    assert.equal(i.raw, '1 cup macaroni and cheese'); assert.equal(i.amount, 1); assert.equal(i.unit, 'cup'); assert.equal(i.food, 'macaroni and cheese');
    assert.equal(FC.parse('1 cup mac and cheese', DB).items[0].joined, true);
  });
  it('it then gets the normal status rules: candidates are real macaroni-and-cheese rows; nothing is chosen unless exactly one covers every word', () => {
    const i = split('1 cup mac and cheese')[0];
    const full = DB.foods.filter((f) => /\bmacaroni\b/i.test(f[2]) && /\bcheese\b/i.test(f[2]));
    assert.ok(['matched', 'ambiguous'].includes(i.status));
    assert.equal(i.status, full.length === 1 ? 'matched' : 'ambiguous');
    for (const c of i.candidates) { assert.match(c.description, /macaroni/i); assert.match(c.description, /cheese/i); assert.ok(byKey[c.dataset + ':' + c.fdcId]); }
    if (i.status === 'ambiguous') { assert.equal(i.chosen, null); assert.equal(i.nutrients, null); assert.equal(i.grams, null); }
    assert.match(i.message, /one food/);
  });
  it('the owner can pick a candidate and the cup measure of that row is used (or no_portion if USDA has none)', () => {
    const i = split('1 cup mac and cheese')[0], c = i.candidates[0], f = byKey[c.dataset + ':' + c.fdcId];
    const p = FC.estimateItem('1 cup mac and cheese', DB, { fdcId: c.fdcId, dataset: c.dataset });
    const cups = f[7].filter((x) => /^cup\b/i.test(x[1]));
    if (cups.length >= 1 && (cups.length === 1 || cups.some((x) => x[1] === 'cup'))) { const row = cups.find((x) => x[1] === 'cup') || cups[0]; assert.equal(p.status, 'matched'); assert.equal(p.grams, r2(row[2] / row[0])); }
    else assert.equal(p.status, 'no_portion');
  });
  it('spelling variants of the same dish all normalise to the same single item', () => {
    for (const t of ['mac and cheese', 'Mac & Cheese', 'mac n cheese', "mac 'n' cheese", 'MAC AND CHEESE', 'macaroni and cheese']) {
      const r = FC.estimate('2 cups ' + t, DB); assert.equal(r.items.length, 1, t); assert.equal(r.items[0].food, 'macaroni and cheese', t); assert.equal(r.items[0].amount, 2);
    }
  });
  it('only the exact phrase is normalised: "big mac" and a lone "mac" are untouched', () => {
    assert.equal(FC.parse('1 big mac', DB).items[0].food, 'big mac'); assert.equal(FC.parse('1 mac', DB).items[0].food, 'mac');
  });
  it('without any database parse(text) has no dish list: it splits (alias names are the only exception)', () => {
    assert.equal(FC.parse('1 cup mac and cheese').items.length, 2);
  });
  it('estimateItem never splits: "mac and cheese" is one item there too', () => {
    const i = FC.estimateItem('1 cup mac and cheese', DB); assert.equal(i.food, 'macaroni and cheese'); assert.ok(i.candidates.length > 0);
  });
});

describe('P6 "and": bread and butter, rice and beans (asserted against what the DB really contains)', () => {
  it('"bread and butter" (owner decision, supersedes the earlier DB-phrase result): the DB only has it as PICKLES, so it splits into bread + butter', () => {
    assert.ok(descs(/\bbread\b.*\band\b.*\bbutter\b/i).length > 0, 'premise: the DB phrase rule alone would have kept it whole (see p6-dawit-foodcalc-units-bnb.test.js for the exclusion)');
    assert.deepEqual(split('bread and butter').map((i) => i.food), ['bread', 'butter']);
  });
  it('"bread and butter" with a comma, or with its own quantities, always gives two items (bread alias, butter alias)', () => {
    const r = FC.estimate('1 slice bread, 1 tbsp butter', DB); assert.deepEqual(r.items.map((i) => i.status), ['matched', 'matched']);
    const q = FC.estimate('2 slices bread and 1 tbsp butter', DB); assert.deepEqual(q.items.map((i) => [i.food, i.status]), [['bread', 'matched'], ['butter', 'matched']]);
  });
  it('"rice and beans": whole phrase iff some description has rice ... and ... bean(s) in order', () => {
    const has = descs(/\brice\b.*\band\b.*\bbeans?\b/i);
    const items = split('rice and beans');
    if (has.length) {
      assert.equal(items.length, 1); assert.equal(items[0].food, 'rice and beans');
      for (const c of items[0].candidates) { assert.match(c.description, /rice/i); assert.match(c.description, /bean/i); }
      assert.notEqual(items[0].status, 'matched'); assert.equal(items[0].nutrients, null);
    } else assert.equal(items.length, 2);
  });
  it('loose word match: "rice and beans" joins the USDA "(rice and black beans)" row but reversed order "beans and rice" is checked on its own', () => {
    const rev = descs(/\bbeans?\b.*\band\b.*\brice\b/i);
    assert.equal(split('beans and rice').length, rev.length ? 1 : 2);
  });
  it('a dish that USDA does not list stays split: "salt and pepper" -> salt, pepper', () => {
    assert.equal(descs(/\bsalt\b.*\band\b.*\bpepper\b/i).length, 0, 'premise');
    assert.deepEqual(split('salt and pepper').map((i) => i.food), ['salt', 'pepper']);
  });
});

describe('P6 "and": separate items stay separate', () => {
  it('"2 eggs and 1 banana" is two matched items (with and without a DB)', () => {
    const items = split('2 eggs and 1 banana'); assert.deepEqual(items.map((i) => [i.food, i.status, i.amount]), [['eggs', 'matched', 2], ['banana', 'matched', 1]]);
    const egg = byKey['SR:171287'], big = egg[7].find((p) => p[1] === 'large');
    assert.equal(items[0].grams, r2(2 * big[2]));
    assert.equal(FC.parse('2 eggs and 1 banana').items.length, 2);
  });
  it('a later part with its own quantity ("a banana", "three dates", "half an avocado") always splits', () => {
    for (const t of ['2 eggs and a banana', '2 eggs and three dates', '2 eggs and half an avocado', '1 fish and 2 chips']) assert.equal(FC.parse(t, DB).items.length, 2, t);
    const t2 = tiny([[1, 'SR', 'Fish and chips, test', 200, 10, 20, 8, [[1, 'serving', 300]]]]);
    assert.equal(FC.parse('1 fish and 2 chips', t2).items.length, 2, 'quantity on the right beats a matching dish name');
    assert.equal(FC.parse('1 fish and chips', t2).items.length, 1);
  });
  it('commas, semicolons and newlines always split, even around a known dish name', () => {
    assert.equal(FC.parse('mac and cheese, mac and cheese', DB).items.length, 2);
    assert.equal(FC.parse('mac and cheese; 2 eggs\nbread and butter', DB).items.length, 4, 'dish, eggs, then bread + butter');
    assert.equal(FC.parse('mac and cheese; 2 eggs\nrice and beans', DB).items.length, 3);
    assert.equal(FC.parse('macaroni, and cheese', DB).items.length, 2);
    assert.equal(FC.parse('2 eggs & 3 dates', DB).items.length, 2, '& still splits');
    assert.equal(FC.parse('2 eggs + 3 dates', DB).items.length, 2, '+ still splits');
  });
  it('a dish and another item: "1 cup macaroni and cheese and 2 eggs" -> dish, eggs', () => {
    const items = split('1 cup macaroni and cheese and 2 eggs'); assert.deepEqual(items.map((i) => i.food), ['macaroni and cheese', 'eggs']);
    assert.equal(items[1].status, 'matched');
  });
  it('a known dish does not swallow a following unrelated food: "mac and cheese and apple" = dish + apple', () => {
    const items = FC.parse('1 cup mac and cheese and an apple', DB).items; assert.equal(items.length, 2);
  });
});

describe('P6 "and": generic rules on a small controlled DB (order, looseness, aliases)', () => {
  const T = tiny([
    [1, 'SR', 'Fish and chips, test', 200, 10, 20, 8, [[1, 'serving', 300]]],
    [2, 'SR', 'Rice and black beans, test', 130, 5, 25, 1, [[1, 'cup', 200]]],
    [3, 'SR', 'Plain thing, test', 100, 1, 1, 1, [[1, 'cup', 100]]]
  ]);
  it('words in order with "and" between: joined; reversed order is not', () => {
    assert.equal(FC.parse('1 fish and chips', T).items.length, 1);
    assert.equal(FC.parse('1 chips and fish', T).items.length, 2);
  });
  it('loose: words may have other words between them ("rice and beans" ~ "rice and black beans"), plural-insensitive', () => {
    assert.equal(FC.parse('1 cup rice and beans', T).items.length, 1);
    assert.equal(FC.parse('1 cup rices and bean', T).items.length, 1);
    assert.equal(FC.parse('1 cup rice and corn', T).items.length, 2);
  });
  it('the whole phrase is checked before splitting but gets the normal status rules (ambiguous with no nutrients here)', () => {
    const i = FC.estimate('1 cup rice and beans', T).items[0];
    // Claude P6 review: a text match whose USDA description has extra words ("..., test") is offered first, not chosen.
    assert.equal(i.status, 'ambiguous', 'single food covers all words in this small DB, but its description says more'); assert.equal(i.candidates[0].fdcId, 2); assert.equal(i.nutrients, null); assert.equal(i.chosen, null);
    const n = FC.estimate('1 fish and chips and 1 cup rice and beans', T).items; assert.deepEqual(n.map((i) => i.candidates[0] && i.candidates[0].fdcId), [1, 2]);
  });
  it('an alias phrase containing "and" stays whole, with or without a DB (and splits again without the alias)', () => {
    const mk = () => tiny([[5, 'SR', 'Sandwich pbj, test', 300, 10, 40, 12, [[1, 'sandwich', 150]]]]); // a DB object is indexed once, so use a new one after the alias changes
    assert.equal(FC.parse('2 peanut butter and jelly', mk()).items.length, 2, 'premise: not an alias yet');
    FC.ALIASES.push([['peanut butter and jelly', 'pb and j'], 'SR', 5, 'sandwich', 'test alias']);
    try {
      const db = mk(); const r = FC.estimate('2 peanut butter and jelly', db); assert.equal(r.items.length, 1);
      assert.equal(r.items[0].status, 'matched'); assert.equal(r.items[0].chosen.fdcId, 5); assert.equal(r.items[0].grams, 300); assert.equal(r.items[0].portion.basis, 'alias_default');
      assert.equal(FC.estimate('1 pb and j, 1 peanut butter and jelly', db).items.length, 2);
      assert.equal(FC.parse('2 peanut butter and jelly').items.length, 1, 'alias names keep a phrase whole even with no DB');
      assert.equal(FC.parse('2 peanut butter and jelly and 1 egg').items.length, 2);
    } finally { FC.ALIASES.pop(); }
    assert.equal(FC.parse('2 peanut butter and jelly', mk()).items.length, 2, 'back to splitting once the alias is gone');
  });
  it('the real alias table has no "and" name today, and every alias name still resolves through the normal path', () => {
    const withAnd = FC.ALIASES.flatMap((a) => a[0]).filter((n) => /\band\b/.test(n));
    for (const n of withAnd) assert.equal(FC.parse('1 ' + n, DB).items.length, 1, n);
  });
});

describe('P6 "and": determinism and limits', () => {
  const INPUTS = ['1 cup mac and cheese', 'bread and butter', 'rice and beans', '2 eggs and 1 banana', 'salt and pepper', 'chicken and rice, 2 eggs and a banana', 'eggs and bacon', 'mac & cheese and 3 dates'];
  it('same input -> deeply equal output, repeatedly and in any order', () => {
    const first = INPUTS.map((t) => FC.estimate(t, DB));
    for (let k = 0; k < 3; k++) INPUTS.slice().reverse().forEach((t) => { assert.deepEqual(FC.estimate(t, DB), first[INPUTS.indexOf(t)], t); assert.deepEqual(FC.parse(t, DB), FC.parse(t, DB)); });
  });
  it('a freshly loaded copy of the module gives identical results (no hidden state)', () => {
    const fresh = (() => { const id = require.resolve('../src/data/hyrox-foodcalc.js'); const saved = require.cache[id]; delete require.cache[id]; const m = require(id); require.cache[id] = saved; return m; })();
    for (const t of INPUTS) assert.deepEqual(fresh.estimate(t, DB), FC.estimate(t, DB), t);
  });
  it('pathological "and" input is fast and capped (50 items)', () => {
    const t0 = Date.now(); const r = FC.estimate('a and '.repeat(300) + 'b', DB);
    assert.ok(Date.now() - t0 < 3000); assert.ok(r.items.length <= FC.MAX_ITEMS); assert.equal(r.truncated, true);
    assert.equal(FC.estimate(' and and and ', DB).items.length, 0);
    assert.equal(FC.estimate('and', DB).items.length, 0);
    assert.doesNotThrow(() => FC.estimate('rice and '.repeat(40) + 'beans', DB));
  });
  it('totals and counts stay consistent when a dish is joined', () => {
    const r = FC.estimate('2 eggs, 1 cup mac and cheese, 1 banana', DB);
    assert.equal(r.items.length, 3); assert.equal(r.totals.matchedCount + r.totals.unmatchedCount, 3);
    assert.equal(r.totals.matchedCount, r.items.filter((i) => i.status === 'matched').length);
  });
  it('toComponents lists a joined-but-ambiguous dish as unmatched, never as a component', () => {
    const c = FC.toComponents(FC.estimate('2 eggs, 1 cup mac and cheese', DB));
    assert.equal(c.components.length, 1); assert.equal(c.unmatched.length, 1); assert.equal(c.unmatched[0].raw, '1 cup macaroni and cheese'); assert.equal(c.unmatched[0].status, 'ambiguous');
  });
});
