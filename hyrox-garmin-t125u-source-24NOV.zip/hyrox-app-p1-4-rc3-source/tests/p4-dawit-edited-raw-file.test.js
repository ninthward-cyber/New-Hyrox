'use strict';
// P4 (Dawit): regression for Meron's HIGH DEFECT on p4/qa 327c8e6 — an EDITED emergency raw
// recovery file (app -> 'hyrox-app', 'kind' removed, empty lists added) must still be refused
// as a normal backup and must never replace live data. Synthetic data only.
// The first describe block is copied from tests/p4-meron-adversarial.test.js @ 327c8e6 with the
// same assertions; the rest are Dawit's extras.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const { HD, KEY, PRE, mem, mk, O, ts, backup, restore } = require('./p3-helpers.js');

const D = '2026-11-10';
const badDaily = (extra) => Object.assign({
  id: 'daily-' + D, createdAt: ts, updatedAt: ts, date: D,
  footPain: O(11), stairKneePain: O(1), sleepH: O(7),
  limp: { state: 'OBSERVED', value: false }, steps: O(8000), soreness: O(2), rhr: O(60),
}, extra);
function seed(lists) {
  const raw = JSON.stringify(Object.assign({
    version: 2,
    weight: [{ id: 'w1', createdAt: ts, date: D, kg: 80 }],
    workouts: [], nutrition: [],
  }, lists));
  const s = mem({ [KEY]: raw });
  return { s, st: mk(s), raw };
}

// ---- Copied verbatim from p4/qa 327c8e6 (Meron), same assertions ----
describe('DEFECT: a relabelled emergency raw recovery file can be imported as an empty normal backup and wipe live data', () => {
  it('previewImport/applyImport of a relabelled raw file wipes the live store; this must be refused', () => {
    const { st } = seed({ daily: [badDaily()] });
    const recov = st.rawRecoveryExport();
    const pRaw = JSON.parse(recov.text);
    const disguised = Object.assign({}, pRaw, { app: 'hyrox-app', version: 2, weight: [], workouts: [], nutrition: [] });
    delete disguised.kind;
    const live = mem();
    const st2 = mk(live);
    st2.addWeight({ date: D, kg: 80 });
    const before = live.m[KEY];
    const prev = st2.previewImport(JSON.stringify(disguised));
    assert.equal(prev.ok, false, 'relabelled raw recovery must not preview as a normal backup');
    assert.equal(prev.code, 'raw_recovery_file');
    assert.equal(live.m[KEY], before);
    const applied = st2.applyImport(JSON.stringify(disguised), { confirm: 'REPLACE', expectCurrent: { weight: 1, workouts: 0, nutrition: 0 } });
    assert.equal(applied.ok, false);
    assert.equal(applied.code, 'raw_recovery_file');
    assert.equal(live.m[KEY], before);
    assert.equal(st2.list('weight').length, 1);
  });
});

// ---- Dawit extras ----
function rawFile() {
  const { st } = seed({ daily: [badDaily()] });
  const r = st.rawRecoveryExport();
  assert.equal(r.ok, true);
  return JSON.parse(r.text);
}
function disguise(mutate) {
  const o = Object.assign({}, rawFile(), { app: 'hyrox-app', version: 2, weight: [], workouts: [], nutrition: [] });
  delete o.kind;
  if (mutate) mutate(o);
  return JSON.stringify(o);
}
// A populated live device (core + extension lists) to prove nothing is touched.
function liveDevice() {
  const s = mem();
  const st = mk(s);
  assert.ok(st.addWeight({ date: D, kg: 80 }));
  assert.equal(st.putRecord('walks', { date: D, durationMin: 30, steps: 3000 }).ok, true);
  const p = st.previewImport(st.exportJSON());
  assert.equal(p.ok, true);
  return { s, st, current: p.preview.current, currentExt: p.preview.currentExt };
}
const snapAll = (s) => JSON.stringify(Object.keys(s.m).sort().map((k) => [k, s.m[k]]));

function assertRefused(r, isApply) {
  assert.equal(r.ok, false);
  assert.equal(r.code, 'raw_recovery_file');
  assert.equal(typeof r.message, 'string');
  assert.match(r.message, /emergency raw recovery/i);
  assert.match(r.message, /not a normal backup/);
  assert.match(r.message, /nothing was changed/i);
  assert.ok(Array.isArray(r.errors));
  assert.deepEqual(r.errors, []);
  if (isApply) { assert.equal(r.rolledBack, false); assert.equal(r.backupKey, null); }
}

describe('edited emergency raw files are refused on both paths, with zero writes', () => {
  const variants = {
    'app relabelled, kind removed, empty lists (Meron repro)': disguise(),
    'kind removed only, app still raw': (() => { const o = rawFile(); delete o.kind; return JSON.stringify(o); })(),
    'app relabelled, kind kept': (() => { const o = Object.assign(rawFile(), { app: 'hyrox-app', version: 2, weight: [], workouts: [], nutrition: [] }); return JSON.stringify(o); })(),
    'app relabelled, kind changed to something else': disguise((o) => { o.kind = 'backup'; }),
    'relabelled AND format/warning/state stripped, only sources left': disguise((o) => { delete o.format; delete o.warning; delete o.state; delete o.normalExport; delete o.omitted; delete o.omittedTotal; }),
    'relabelled with sources emptied': disguise((o) => { o.sources = []; }),
    'relabelled with sources set to null': disguise((o) => { o.sources = null; }),
    'relabelled with legacy version 1': disguise((o) => { o.version = 1; }),
    'relabelled with lists that DO carry data': disguise((o) => { o.weight = [{ id: 'x1', createdAt: ts, date: D, kg: 70 }]; }),
    'relabelled and whitespace-padded': '\n  ' + disguise() + '\n',
    'a normal-looking backup with a top-level sources field': backup({ sources: [] }),
  };
  for (const [name, text] of Object.entries(variants)) {
    it(name, () => {
      const { s, st, current, currentExt } = liveDevice();
      const before = snapAll(s), writes = s.writes, list = JSON.stringify(st.list('weight'));
      const p = st.previewImport(text);
      assertRefused(p, false);
      assert.equal(s.writes, writes, 'preview writes nothing');
      assert.equal(snapAll(s), before);
      for (const opts of [
        { confirm: 'REPLACE', expectCurrent: current, expectCurrentExt: currentExt },
        { confirm: 'REPLACE', expectCurrent: current, expectCurrentExt: currentExt, approveCorrection: true, approveDamaged: true },
      ]) {
        const a = st.applyImport(text, opts);
        assertRefused(a, true);
        assert.equal(s.writes, writes, 'apply writes nothing');
        assert.equal(snapAll(s), before, 'every storage key is byte-identical');
        assert.equal(Object.prototype.hasOwnProperty.call(s.m, PRE), false, 'no pre-import safety slot was created or overwritten');
      }
      assert.equal(JSON.stringify(st.list('weight')), list);
      assert.equal(st.records('walks').length, 1);
    });
  }

  it('an existing pre-import safety copy is not overwritten by a refused edited raw file', () => {
    const { s, st, current, currentExt } = liveDevice();
    s.m[PRE] = JSON.stringify({ kind: 'hyrox-pre-import', savedAt: ts, raw: 'older exact bytes' });
    const before = snapAll(s), writes = s.writes;
    assertRefused(st.applyImport(disguise(), { confirm: 'REPLACE', expectCurrent: current, expectCurrentExt: currentExt }), true);
    assert.equal(snapAll(s), before);
    assert.equal(s.writes, writes);
  });

  it('the untouched raw file keeps its original refusal (unchanged message)', () => {
    const { st } = liveDevice();
    const r = st.previewImport(JSON.stringify(rawFile()));
    assert.equal(r.code, 'raw_recovery_file');
    assert.equal(r.message, 'This is an emergency raw recovery copy, not a normal backup, so it cannot be restored here. Keep it safe; nothing was changed.');
  });

  it('the edited-file message says it looks like an emergency copy even if edited', () => {
    const { st } = liveDevice();
    const r = st.previewImport(disguise());
    assert.match(r.message, /even if it was edited/);
    assert.match(r.message, /"sources"/);
  });

  it('parseRawRecovery still does not accept the edited file as a raw file (no raw-copy restore is built)', () => {
    assert.equal(HD.parseRawRecovery(disguise()).ok, false);
    assert.equal(typeof mk(mem()).restoreRawRecovery, 'undefined');
  });
});

describe('negative: genuine normal backups are not affected', () => {
  it('a genuine backup with unrelated unknown top-level fields is still accepted (warning only) and restores', () => {
    const { s, st } = liveDevice();
    const text = backup({ weight: [{ id: 'n1', createdAt: ts, date: D, kg: 79 }], notes: 'hi', source: 'phone', kindOfBackup: 'manual', format: 1, sourcesCount: 2 });
    const p = st.previewImport(text);
    assert.equal(p.ok, true);
    assert.ok(p.preview.warnings.some((w) => /unknown top-level fields will be ignored/.test(w)));
    const a = restore(st, text);
    assert.equal(a.ok, true);
    assert.equal(st.list('weight').length, 1);
    assert.equal(st.list('weight')[0].kg, 79);
    assert.ok(s.writes > 0);
  });

  it('a normal export still round-trips into a fresh store exactly', () => {
    const { st } = liveDevice();
    const text = st.exportJSON();
    assert.equal(Object.prototype.hasOwnProperty.call(JSON.parse(text), 'sources'), false);
    const s2 = mem(); const st2 = mk(s2);
    const a = restore(st2, text);
    assert.equal(a.ok, true);
    assert.deepEqual(st2.list('weight'), st.list('weight'));
    assert.deepEqual(st2.records('walks'), st.records('walks'));
    assert.equal(st2.exportJSON().replace(/"exportedAt":"[^"]*"/, ''), text.replace(/"exportedAt":"[^"]*"/, ''));
  });

  it('a genuine EMPTY normal backup still previews ok (empty-replace behaviour unchanged; owner decision)', () => {
    const { st } = liveDevice();
    const p = st.previewImport(backup({}));
    assert.equal(p.ok, true);
    assert.deepEqual(p.preview.counts, { weight: 0, workouts: 0, nutrition: 0 });
  });
});
