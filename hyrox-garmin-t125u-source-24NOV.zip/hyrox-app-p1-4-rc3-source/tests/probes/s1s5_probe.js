// Claude QA, 24 Nov 2026: independent probes of Grok's S1-S5 (garmin-import.js + applyAtomic) on the reconstructed candidate
// (source 98693c54e734). Synthetic data, in-memory storage, no network. Each line: PASS/FAIL against the contract.
'use strict';
const path = require('path'), fs = require('fs');
const [, , CAND, FIX, OLD] = process.argv;           // candidate root, corrected fixtures dir, P1.3-RC3 root
const G = require(path.join(CAND, 'src/integrations/garmin-import.js'));
const D = require(path.join(CAND, 'src/data/hyrox-data.js'));
const DOLD = require(path.join(OLD, 'src/data/hyrox-data.js'));
const HMOLD = require(path.join(OLD, 'src/data/hyrox-morning.js'));
const HM = require(path.join(CAND, 'src/data/hyrox-morning.js'));
const fx = (n) => JSON.parse(fs.readFileSync(path.join(FIX, n), 'utf8'));
let fails = 0; const out = (ok, id, msg) => { if (!ok) fails++; console.log((ok ? 'PASS ' : 'FAIL ') + id + ': ' + msg); };
function mem() { const m = new Map(); return { getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => m.set(k, String(v)), removeItem: (k) => m.delete(k), _m: m }; }
const NOW = new Date('2026-11-24T06:00:00Z');        // 09:00 Qatar, Tuesday 24 Nov
function store(data, now) { const s = mem(); s.setItem(D.STORAGE_KEY, JSON.stringify(Object.assign({ version: 2, weight: [], workouts: [], nutrition: [], sessions: [], meals: [], body: [], daily: [], walks: [], dayStates: [], planEvents: [], ownerSettings: [] }, data))); return { s, api: D.createStore(s, { now: () => now || NOW }) }; }
const raw = (st) => st.s.getItem(D.STORAGE_KEY), doc = (st) => JSON.parse(raw(st));
const QA = { timeZone: 'Asia/Qatar' };
const carrier = { id: 'daily-2026-11-10', createdAt: '2026-11-10T05:00:00.000Z', date: '2026-11-10', soreness: { state: 'OBSERVED', value: 2 } };
// A today row (24 Nov) and a future row (25 Nov) built from the corrected 16 Nov row, chronology moved consistently.
function shift(row, date) { const r = JSON.parse(JSON.stringify(row)); const prev = new Date(Date.parse(date + 'T00:00:00Z') - 86400000).toISOString().slice(0, 10);
  r.calendarDate = date; r.uuid = 'qa-' + date; r.wellnessChronology = { startTimestampGmt: prev + 'T21:00:00.0', startTimestampLocal: date + 'T00:00:00.0', endTimestampGmt: date + 'T20:59:00.0', endTimestampLocal: date + 'T23:59:00.0' }; return r; }
const base16 = fx('dailysummaries-v2-normal-7d.json').data.find((r) => r.calendarDate === '2026-11-16');
const todayRow = shift(base16, '2026-11-24'), futureRow = shift(base16, '2026-11-25');

// C1 D3: today's steps/intensity, apply called directly WITHOUT ctx.todayQatar (the module trusts the caller's clock)
{ const st = store({ daily: [carrier] });
  const r = G.applyMerge(st.api, { applySteps: { '2026-11-24': true }, applyIntensity: { '2026-11-24': true } }, { settings: QA, dailyPayload: { data: [todayRow] } });
  const d = doc(st).daily.find((x) => x.date === '2026-11-24');
  out(!(d && (d.steps || d.intensityMin)), 'D3-direct', `today 24 Nov, no todayQatar passed: wrote=${r.wrote}, stored steps=${d && d.steps && d.steps.value}, intensity=${d && d.intensityMin && d.intensityMin.value}`); }
// C2 D3: caller passes a stale "today" (yesterday)
{ const st = store({ daily: [carrier] });
  const r = G.applyMerge(st.api, { applySteps: { '2026-11-24': true } }, { settings: QA, todayQatar: '2026-11-23', dailyPayload: { data: [todayRow] } });
  out(!(doc(st).daily.find((x) => x.date === '2026-11-24')), 'D3-stale-today', `caller says today=23 Nov: wrote=${r.wrote}`); }
// C3 future day written when the caller omits todayQatar
{ const st = store({ daily: [carrier] });
  const r = G.applyMerge(st.api, { applySteps: { '2026-11-25': true } }, { settings: QA, dailyPayload: { data: [futureRow] } });
  out(!(doc(st).daily.find((x) => x.date === '2026-11-25')), 'FUTURE-direct', `25 Nov (tomorrow) steps: wrote=${r.wrote}`); }
// C4 control: with the correct todayQatar the module refuses (Grok's G-TZ-10)
{ const st = store({ daily: [carrier] });
  const r = G.applyMerge(st.api, { applySteps: { '2026-11-24': true } }, { settings: QA, todayQatar: '2026-11-24', dailyPayload: { data: [todayRow] } });
  out(!(doc(st).daily.find((x) => x.date === '2026-11-24')), 'D3-control', `with todayQatar=24 Nov: wrote=${r.wrote}, reason=${r.reason || r.code || ''}`); }

// B1 empty daily[]: everything refused, including a confirmed past steps write that would itself create a real check-in
{ const st = store({ daily: [] }); const before = raw(st);
  const r = G.applyMerge(st.api, { applySteps: { '2026-11-16': true } }, { settings: QA, todayQatar: '2026-11-24', dailyPayload: { data: [base16] } });
  out(true, 'D1-empty-daily (limitation)', `no check-ins yet: ok=${r.ok} wrote=${r.wrote} reason=${r.reason || r.code}; storage unchanged=${raw(st) === before}`); }

// Weight / activity / sleep fixtures (own synthetic; Grok's regenerated S0 fixtures were not delivered)
const W = (ts, kg) => ({ calendarDate: new Date(ts + 3 * 3600e3).toISOString().slice(0, 10), weight: kg, timestampGMT: ts });
const t20 = Date.parse('2026-11-20T03:00:00Z'), t21 = Date.parse('2026-11-21T03:10:00Z');
const weightDoc = (kgs) => ({ dailyWeightSummaries: [{ summaryDate: '2026-11-20', allWeightMetrics: [W(t20, kgs[0])] }, { summaryDate: '2026-11-21', allWeightMetrics: [W(t21, kgs[1])] }] });
const actDoc = { activities: [{ activityId: 90000000001, activityName: 'Easy run', activityType: { typeKey: 'running' }, startTimeGMT: '2026-11-20 03:05:00', startTimeLocal: '2026-11-20 06:05:00', duration: 1860, distance: 5000, averageHR: 141, maxHR: 162 }] };
const confW = { applyWeight: { [t20]: true, [t21]: true } }, confA = { applyActivity: { '90000000001': true } };

// B2 idempotent apply + restore-slot bytes + no stub dailies
{ const slot = JSON.stringify({ kind: 'hyrox-pre-import-backup', restoreState: 'done', note: 'owner prior copy' });
  const st = store({ daily: [carrier] }); st.s.setItem(D.IMPORT_BACKUP_KEY, slot);
  const r1 = G.applyMerge(st.api, Object.assign({}, confW, confA), { settings: QA, todayQatar: '2026-11-24', weightPayload: weightDoc([97.43, 97.25]), activityPayload: actDoc, nowIso: '2026-11-24T06:00:00.000Z' });
  const a1 = raw(st);
  const r2 = G.applyMerge(st.api, Object.assign({}, confW, confA), { settings: QA, todayQatar: '2026-11-24', weightPayload: weightDoc([97.43, 97.25]), activityPayload: actDoc, nowIso: '2026-11-24T06:05:00.000Z' });
  const d = doc(st);
  out(r1.wrote && !r2.wrote && raw(st) === a1, 'IDEMPOTENT', `1st wrote=${r1.wrote}; 2nd wrote=${r2.wrote} reason=${r2.reason}; bytes identical=${raw(st) === a1}`);
  out(st.s.getItem(D.IMPORT_BACKUP_KEY) === slot, 'RESTORE-SLOT', 'prior-copy slot byte-identical after two applies');
  out(d.daily.length === 1, 'NO-STUB', `daily rows ${d.daily.length} (carrier only)`);
  out((d.weight || []).length === 0, 'ROUNDING', `t112 CC #2: Garmin weight is not imported; kg stored ${(d.weight||[]).map((w)=>w.kg).join() || '(none)'}`);
  const chk = st.api.exportChecked(); out(chk.ok && (!chk.warnings || !chk.warnings.length), 'HEALTHY', `exportChecked ok=${chk.ok} warnings=${JSON.stringify(chk.warnings || [])}`);
  // Rollback: P1.4-candidate backup restored on the live P1.3-RC3 data layer, then rolled forward
  const text = st.api.exportJSON(); const s3 = mem(); const old = DOLD.createStore(s3, { now: () => NOW });
  const pv = old.previewImport(text); const rr = old.applyImport(text, { confirm: 'REPLACE', expectCurrent: pv.preview.current, expectCurrentExt: pv.preview.currentExt });
  const back = JSON.parse(s3.getItem(DOLD.STORAGE_KEY));
  const set = (back.ownerSettings || []).find((s) => s && s.id === 'app-settings') || {};
  const keys = JSON.stringify(set.garminLedger || {}) + JSON.stringify((back.daily || []).map((d) => d.garminLedger || d.garminLedgerBag || {}));
  out(rr.ok && /"activityId":"90000000001"/.test(keys) && (back.weight || []).length === 0 && back.workouts.length === 1, 'ROLLBACK-P13', `t112: restore on P1.3-RC3 ok=${rr.ok}; activity ledger keys kept=${/"activityId":"90000000001"/.test(keys)}; weights ${ (back.weight||[]).length}, workouts ${back.workouts.length}`);
  const t2 = old.exportJSON(); const s4 = mem(); const fwd = D.createStore(s4, { now: () => NOW });
  const pv2 = fwd.previewImport(t2); fwd.applyImport(t2, { confirm: 'REPLACE', expectCurrent: pv2.preview.current, expectCurrentExt: pv2.preview.currentExt });
  const st4 = { s: s4, api: fwd };
  const r3 = G.applyMerge(fwd, Object.assign({}, confW, confA), { settings: QA, todayQatar: '2026-11-24', weightPayload: weightDoc([97.43, 97.25]), activityPayload: actDoc });
  out(!r3.wrote && (doc(st4).weight || []).length === 0 && doc(st4).workouts.length === 1, 'ROLLFORWARD-IDEMPOTENT', `t112 re-fetch after P1.3 round trip: wrote=${r3.wrote}, weights ${(doc(st4).weight||[]).length}, workouts ${doc(st4).workouts.length}`);
}
// B3 t112: user deletes a Garmin-created day, then re-fetches; preview is Deleted by you and nothing is recreated.
{ const st = store({ daily: [] });
  const created = G.applyMerge(st.api, { applySteps: { '2026-11-16': true } }, { settings: QA, todayQatar: '2026-11-24', dailyPayload: { data: [base16] }, nowIso: '2026-11-24T06:00:00.000Z' });
  const id = 'daily-2026-11-16';
  const rm = { ok: st.api.removeRecord('daily', id) !== false };
  const led = ((doc(st).ownerSettings || []).find((s) => s && s.id === 'app-settings') || {}).garminLedger;
  const ledgerHasTomb = JSON.stringify(led || {}).includes('daily-2026-11-16') || JSON.stringify(led || {}).includes('2026-11-16');
  const pv = G.preview({ settings: QA, todayQatar: '2026-11-24', storeData: doc(st), dailyPayload: { data: [base16] } });
  const p16 = (pv.items || []).find((i) => i.date === '2026-11-16');
  const before = (doc(st).daily || []).length;
  const r = G.applyMerge(st.api, { applySteps: { '2026-11-16': true } }, { settings: QA, todayQatar: '2026-11-24', dailyPayload: { data: [base16] } });
  out(created.wrote && ledgerHasTomb, 'DELETE-TOMBSTONE', `ordinary delete (${rm && rm.ok}) wrote a settings tombstone: ${ledgerHasTomb}`);
  out(p16 && p16.status === 'Deleted by you' && !r.wrote && (doc(st).daily || []).length === before, 'DELETE-PREVIEW-HONEST', `deleted day shown as "${p16 && p16.status}"; ticking it then writes=${r.wrote}, dailies ${before} -> ${(doc(st).daily||[]).length}`); }
// B4 t112: a Garmin-linked day is deleted; the settings ledger remains; weight is never re-imported.
{ const st = store({ daily: [carrier, { id: 'daily-2026-11-12', createdAt: '2026-11-12T05:00:00.000Z', date: '2026-11-12', soreness: { state: 'OBSERVED', value: 1 } }] });
  G.applyMerge(st.api, confA, { settings: QA, todayQatar: '2026-11-24', activityPayload: actDoc, nowIso: '2026-11-24T06:00:00.000Z' });
  const d0 = doc(st);
  const carrierId = (d0.daily.find((x) => x.garminLedgerBag || x.garminLedger) || d0.daily[0]).id;
  const rm = { ok: st.api.removeRecord('daily', carrierId) };
  const r = G.applyMerge(st.api, Object.assign({}, confW, confA), { settings: QA, todayQatar: '2026-11-24', weightPayload: weightDoc([97.4, 97.3]), activityPayload: actDoc });
  const wids = (doc(st).weight || []).map((w) => w.id);
  const wos = (doc(st).workouts || []).map((w) => w.id);
  const set = (doc(st).ownerSettings || []).find((s) => s && s.id === 'app-settings');
  out(rm.ok && set && set.garminLedger && wids.length === 0 && wos.length === 1 && !r.wrote, 'CARRIER-DELETED', `daily ${carrierId} deleted (ok=${rm && rm.ok}); settings ledger kept=${!!(set && set.garminLedger)}; re-fetch wrote=${r.wrote}; workouts ${JSON.stringify(wos)}; weights ${JSON.stringify(wids)}`); }
// B5 sleep: manual sleep kept unless replaced; replay idempotent
{ const st = store({ daily: [carrier, { id: 'daily-2026-11-21', createdAt: '2026-11-21T05:00:00.000Z', date: '2026-11-21', sleepH: { state: 'OBSERVED', value: 6.5 } }] });
  const sl = Object.assign({}, fx('daily-sleep-sample.json'), { sleepWindowConfirmed: true });
  const r1 = G.applyMerge(st.api, { applySleep: true }, { settings: QA, todayQatar: '2026-11-24', sleepPayload: sl });
  const v = doc(st).daily.find((x) => x.date === '2026-11-21').sleepH; const a1 = raw(st);
  out(v.value === 6.5, 'SLEEP-MANUAL-WINS', `manual 6.5 h on 21 Nov; after a plain sleep tick it is ${v.value} h (source ${v.source || 'manual'}), wrote=${r1.wrote}`);
  const r2 = G.applyMerge(st.api, { applySleep: true }, { settings: QA, todayQatar: '2026-11-24', sleepPayload: sl });
  out(!r2.wrote, 'SLEEP-IDEMPOTENT', `second identical sleep apply wrote=${r2.wrote}; bytes identical=${raw(st) === a1}`); }
// B6 sleep wake date when Garmin gives LOCAL epoch milliseconds (a wake at 21:30 Qatar)
{ const sl = { sleepWindowConfirmed: true, sleepTimeSeconds: 3 * 3600, sleepEndTimestampLocal: Date.UTC(2026, 10, 21, 21, 30), sleepEndTimestampGMT: Date.UTC(2026, 10, 21, 18, 30) };
  const m = G.mapSleep(sl); out(m.wakeDate === '2026-11-21', 'SLEEP-LOCAL-MS', `wake 21:30 Qatar on 21 Nov given as local epoch ms -> wake date ${m.wakeDate}`); }
// B7 weight Replace confirmation
{ const st = store({ daily: [carrier] });
  G.applyMerge(st.api, confW, { settings: QA, todayQatar: '2026-11-24', weightPayload: weightDoc([97.4, 97.3]) });
  const r = G.applyMerge(st.api, Object.assign({}, confW, { replaceWeight: { [t20]: true } }), { settings: QA, todayQatar: '2026-11-24', weightPayload: weightDoc([96.9, 97.3]) });
  const row = (doc(st).weight || []).find((w) => w.date === '2026-11-20');
  out(!row && (r.wrote === false), 'WEIGHT-REPLACE', `t112 CC #2: Garmin weight is not imported even with Replace ticked; stored ${row && row.kg}, wrote=${r.wrote}, code=${r.code}`); }
// B8 seconds-instead-of-ms timestamp (schema type not verified) must not create a 1970 weigh-in
{ const pv = G.preview({ settings: QA, todayQatar: '2026-11-24', storeData: { daily: [carrier], weight: [] }, weightPayload: { dailyWeightSummaries: [{ allWeightMetrics: [{ weight: 97.4, timestampGMT: 1795143600 }] }] } });
  const it = pv.items.find((i) => i.collection === 'weight');
  out(!(it && it.status === 'New'), 'WEIGHT-SECONDS', `timestampGMT in seconds -> preview "${it && it.status}" dated ${it && it.date}`); }
// B9 data-layer guard: applyAtomic writes whatever the mutator returns (no record validation)
{ const st = store({ daily: [carrier] });
  const r = st.api.applyAtomic((d) => { d.weight.push({ id: 'x', createdAt: 'nope', date: '2026-13-45', kg: 'heavy' }); d.daily = []; return { write: true, data: d }; });
  const chk = st.api.exportChecked();
  out(!r.wrote, 'ATOMIC-VALIDATES', `invalid weight + all check-ins dropped: wrote=${r.wrote}; afterwards exportChecked ok=${chk.ok} restorable=${chk.restorable}`); }
// G-VER-04 on the real P1.3-RC3 reader (the embedded contract silently skips it outside Grok's workspace)
{ const rec = { intensityMin: { state: 'OBSERVED', value: 46, source: 'GARMIN_PERSONAL_API', moderate: 30, vigorous: 8 } };
  const o = HMOLD.intensityRead(rec), n = HM.intensityRead(rec);
  out(o.state === 'INVALID' && o.value === null && n.state === 'OBSERVED' && n.value === 46, 'G-VER-04', `P1.3-RC3 reads ${JSON.stringify(o)}; candidate reads ${JSON.stringify(n)}`); }
console.log(`SUMMARY: ${fails} failing probe(s)`);
