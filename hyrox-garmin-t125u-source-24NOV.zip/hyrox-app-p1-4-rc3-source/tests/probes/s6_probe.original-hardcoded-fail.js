// Claude QA, 24 Nov 2026: independent probe of Grok's S6 shared lockout helper (netlify/lib/auth-lockout-shared.js), using MY
// fake store with ~5 ms async latency and real etags (Grok's createFakeStore answers without delay). No network, no Blobs.
'use strict';
const L = require(process.argv[2]);
const crypto = require('crypto');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function slowStore(o = {}) { const m = new Map(); let n = 0, puts = 0;
  return { _m: m, async get(k) { await sleep(o.lat || 5); if (o.down) throw new Error('down'); const v = m.get(k); return v ? { data: JSON.parse(v.j), etag: v.e } : null; },
    async put(k, d, op = {}) { await sleep(o.lat || 5); if (o.down) throw new Error('down'); puts++; if (o.staleEvery && puts % o.staleEvery === 0) return false;
      const c = m.get(k); if (op.onlyIfNew && c) return false; if (op.onlyIfMatch && (!c || c.e !== op.onlyIfMatch)) return false; m.set(k, { j: JSON.stringify(d), e: 'e' + (++n) }); return true; } }; }
const HASH = crypto.createHash('sha256').update('owner-synthetic-code-0123456789').digest('hex');
let fails = 0; const out = (ok, id, msg) => { if (!ok) fails++; console.log((ok ? 'PASS ' : 'FAIL ') + id + ': ' + msg); };
(async () => {
  const T0 = Date.UTC(2026, 10, 24, 5, 0, 0);
  const run = async (store, n, ipOf, now, code) => { let compared = 0;
    const r = await Promise.all(Array.from({ length: n }, (_, i) => L.checkCode({ store, now, ip: ipOf(i), ownerHash: HASH, code: code || ('wrong-' + i), compareFn: undefined })));
    r.forEach((x) => { if (x.compared) compared++; }); return { compared, codes: r.map((x) => x.status) }; };
  let s = slowStore(); let r = await run(s, 50, () => '203.0.113.7', T0);
  out(r.compared <= 5, 'SAME-IP-50', `50 parallel wrong codes, one IP: ${r.compared} compared (limit 5); statuses ${[...new Set(r.codes)].join('/')}`);
  s = slowStore(); r = await run(s, 50, (i) => '198.51.100.' + (i + 1), T0);
  out(r.compared <= 20, 'DISTRIBUTED-50', `50 IPs at once: ${r.compared} compared (global limit 20)`);
  const g = await s.get('lock/global'); out(g && g.data.until > T0, 'GLOBAL-LOCKED', `global lock until ${g && new Date(g.data.until).toISOString()}`);
  const own = await L.checkCode({ store: s, now: T0 + 60e3, ip: '192.0.2.10', ownerHash: HASH, code: 'owner-synthetic-code-0123456789' });
  out(true, 'OWNER-DOS (accepted risk D2)', `owner, correct code, new IP, 1 min later: status ${own.status} body ${own.bodyText}`);
  // Sequential escalation and whether it ever decays
  s = slowStore(); let t = T0; const locks = [];
  for (let k = 0; k < 6; k++) { for (let i = 0; i < 20; i++) await L.checkCode({ store: s, now: t, ip: '10.0.' + k + '.' + i, ownerHash: HASH, code: 'x' });
    const d = (await s.get('lock/global')).data; locks.push(Math.round((d.until - t) / 3600e3) + 'h'); t = d.until + 30 * 24 * 3600e3; }
  out(false, 'NO-DECAY', `global lock lengths for 6 attacks, each 30 days after the previous lock ended: ${locks.join(', ')} (lock length never comes back down)`);
  // Contention: 200 parallel from one IP
  s = slowStore(); r = await run(s, 200, () => '203.0.113.8', T0);
  out(r.compared <= 5, 'SAME-IP-200', `200 parallel, one IP: ${r.compared} compared`);
  // Store down / stale etags
  r = await run(slowStore({ down: true }), 5, () => '203.0.113.9', T0);
  out(r.compared === 0 && r.codes.every((c) => c === 429), 'STORE-DOWN', `store down: ${r.compared} compared, statuses ${[...new Set(r.codes)].join('/')}`);
  s = slowStore({ staleEvery: 2 }); r = await run(s, 30, () => '203.0.113.10', T0);
  out(r.compared <= 5, 'STALE-ETAGS', `every 2nd write refused as stale, 30 parallel: ${r.compared} compared`);
  // Failure recording lost under contention: after a burst, is every compared wrong code counted?
  s = slowStore({ staleEvery: 3 }); r = await run(s, 5, (i) => '203.0.113.' + (20 + i), T0);
  const gd = await s.get('lock/global'); const counted = gd ? gd.data.fails.length + (gd.data.until ? 20 : 0) : 0;
  out(counted >= r.compared, 'FAILURES-COUNTED', `${r.compared} compared, ${gd ? gd.data.fails.length : 0} recorded on the global tier`);
  console.log('SUMMARY: ' + fails + ' failing probe(s) (OWNER-DOS is the risk the owner accepted, not a failure)');
})();
