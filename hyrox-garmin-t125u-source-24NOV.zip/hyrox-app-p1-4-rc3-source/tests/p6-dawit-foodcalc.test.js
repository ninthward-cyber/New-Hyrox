'use strict';
// P6 food calculator (Dawit): parser, alias matcher, estimator, DB-failure handling. Synthetic text only, offline.
// Arithmetic is recomputed from the DB rows (never hard-coded magic numbers).
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const FC = require(path.resolve(__dirname, '../src/data/hyrox-foodcalc.js'));
const DB = require(path.resolve(__dirname, '../src/data/food-db.json'));

const byKey = {}; DB.foods.forEach((f) => { byKey[f[1] + ':' + f[0]] = f; });
const row = (ds, id) => { const f = byKey[ds + ':' + id]; assert.ok(f, ds + id + ' not in DB'); return f; };
const portion = (f, label) => { const p = f[7].find((x) => x[1] === label); assert.ok(p, f[2] + ' has no portion ' + label); return p; };
const r1 = (n) => Math.round(n * 10) / 10, r2 = (n) => Math.round(n * 100) / 100;
const nutOf = (f, grams) => ({ kcal: Math.round(f[3] * grams / 100), proteinG: r1(f[4] * grams / 100), carbsG: r1(Math.max(f[5], 0) * grams / 100), fatG: r1(f[6] * grams / 100) });
const est = (t) => FC.estimate(t, DB);
const one = (t) => { const r = est(t); assert.equal(r.ok, true); assert.equal(r.items.length, 1, t); return r.items[0]; };
const tiny = (foods) => ({ meta: { schema: 1, dbVersion: 'test-db' }, foods });

describe('P6 foodcalc: the headline example', () => {
  const T = '2 eggs, 150 g rice, 1 cup milk, 1 tbsp olive oil, half an avocado';
  it('five matched items, each recomputed from the DB rows', () => {
    const r = est(T);
    assert.equal(r.ok, true); assert.equal(r.dbVersion, DB.meta.dbVersion); assert.equal(r.items.length, 5);
    assert.deepEqual(r.items.map((i) => i.status), ['matched', 'matched', 'matched', 'matched', 'matched']);
    const exp = [
      [row('SR', 171287), 2 * portion(row('SR', 171287), 'large')[2]],
      [row('SR', 168878), 150],
      [row('SR', 171265), 1 * portion(row('SR', 171265), 'cup')[2]],
      [row('SR', 171413), 1 * portion(row('SR', 171413), 'tablespoon')[2]],
      [row('SR', 171705), 0.5 * portion(row('SR', 171705), 'avocado, NS as to Florida or California')[2]]
    ];
    exp.forEach(([f, g], i) => {
      const it = r.items[i];
      assert.equal(it.chosen.fdcId, f[0], it.raw); assert.equal(it.chosen.dataset, f[1]);
      assert.equal(it.grams, r2(g), it.raw);
      assert.deepEqual(it.nutrients, nutOf(f, r2(g)), it.raw);
    });
    assert.deepEqual(r.items.map((i) => i.portion.basis), ['alias_default', 'mass', 'usda_portion', 'usda_portion', 'alias_default']);
  });
  it('totals = rounded sum of the (rounded) item values; counts', () => {
    const r = est(T), s = (k) => r.items.reduce((a, i) => a + i.nutrients[k], 0);
    assert.deepEqual(r.totals, { kcal: Math.round(s('kcal')), proteinG: r1(s('proteinG')), carbsG: r1(s('carbsG')), fatG: r1(s('fatG')), matchedCount: 5, unmatchedCount: 0 });
  });
  it('provenance carries dataset, fdcId, description, portion, grams, dbVersion', () => {
    for (const i of est(T).items) {
      assert.deepEqual(Object.keys(i.provenance).sort(), ['dataset', 'dbVersion', 'description', 'fdcId', 'grams', 'portion', 'source']);
      assert.equal(i.provenance.source, 'USDA_FDC'); assert.equal(i.provenance.fdcId, i.chosen.fdcId); assert.equal(i.provenance.dbVersion, DB.meta.dbVersion);
      assert.equal(i.provenance.grams, i.grams); assert.equal(i.provenance.description, byKey[i.chosen.dataset + ':' + i.chosen.fdcId][2]);
      assert.equal(typeof i.provenance.portion, 'string');
    }
  });
  it('rounding: kcal integers, macros one decimal, grams at most two decimals', () => {
    for (const i of est(T).items) {
      assert.ok(Number.isInteger(i.nutrients.kcal));
      for (const k of ['proteinG', 'carbsG', 'fatG']) assert.equal(i.nutrients[k], r1(i.nutrients[k]));
      assert.equal(i.grams, r2(i.grams));
    }
  });
  it('deterministic: same input gives deeply equal output', () => { assert.deepEqual(est(T), est(T)); });
  it('every item exposes the household measures of its food (index, amount, unit, label, grams)', () => {
    const i = est(T).items[0];
    assert.deepEqual(i.portions, byKey['SR:171287'][7].map((p, ix) => ({ index: ix, amount: p[0], unit: p[1], label: p[1], grams: p[2] })));
  });
});

describe('P6 foodcalc: parse', () => {
  const P = (t) => FC.parse(t).items.map((i) => [i.amount, i.unit, i.food]);
  it('numbers, decimals, units attached or spaced, abbreviations and plurals', () => {
    assert.deepEqual(P('150g rice'), [[150, 'g', 'rice']]);
    assert.deepEqual(P('150 g rice'), [[150, 'g', 'rice']]);
    assert.deepEqual(P('2.5 kg flour'), [[2.5, 'kg', 'flour']]);
    assert.deepEqual(P('500 mg salt'), [[500, 'mg', 'salt']]);
    assert.deepEqual(P('250 ml milk'), [[250, 'ml', 'milk']]);
    assert.deepEqual(P('1.5 l water'), [[1.5, 'l', 'water']]);
    assert.deepEqual(P('2 litres water'), [[2, 'l', 'water']]);
    assert.deepEqual(P('8 oz steak'), [[8, 'oz', 'steak']]);
    assert.deepEqual(P('1 lb rice'), [[1, 'lb', 'rice']]);
    assert.deepEqual(P('2 lbs rice'), [[2, 'lb', 'rice']]);
    assert.deepEqual(P('2 cups rice'), [[2, 'cup', 'rice']]);
    assert.deepEqual(P('2 Tbsp. olive oil'), [[2, 'tbsp', 'olive oil']]);
    assert.deepEqual(P('2 tablespoons honey'), [[2, 'tbsp', 'honey']]);
    assert.deepEqual(P('1 tsp salt'), [[1, 'tsp', 'salt']]);
    assert.deepEqual(P('3 teaspoons sugar'), [[3, 'tsp', 'sugar']]);
    assert.deepEqual(P('2 slices of bread'), [[2, 'slice', 'bread']]);
    assert.deepEqual(P('3 pcs chicken'), [[3, 'piece', 'chicken']]);
    assert.deepEqual(P('1 piece naan'), [[1, 'piece', 'naan']]);
    assert.deepEqual(P('2 eggs'), [[2, null, 'eggs']]);
    assert.deepEqual(P('1 large egg'), [[1, null, 'large egg']]);
  });
  it('fractions: 1/2, 1 1/2, unicode, "half a/an", "a/an", number words, "and a half"', () => {
    assert.deepEqual(P('1/2 cup milk'), [[0.5, 'cup', 'milk']]);
    assert.deepEqual(P('1 1/2 cups milk'), [[1.5, 'cup', 'milk']]);
    assert.deepEqual(P('\u00bd cup milk'), [[0.5, 'cup', 'milk']]);
    assert.deepEqual(P('1\u00bd cups milk'), [[1.5, 'cup', 'milk']]);
    assert.deepEqual(P('1 \u00bd cups milk'), [[1.5, 'cup', 'milk']]);
    assert.deepEqual(P('\u00be cup oats'), [[0.75, 'cup', 'oats']]);
    assert.deepEqual(P('\u2153 cup oats')[0].slice(0, 2), [1 / 3, 'cup']);
    assert.deepEqual(P('half an avocado'), [[0.5, null, 'avocado']]);
    assert.deepEqual(P('half a banana'), [[0.5, null, 'banana']]);
    assert.deepEqual(P('Half a cup of milk'), [[0.5, 'cup', 'milk']]);
    assert.deepEqual(P('half avocado'), [[0.5, null, 'avocado']]);
    assert.deepEqual(P('a banana'), [[1, null, 'banana']]);
    assert.deepEqual(P('an apple'), [[1, null, 'apple']]);
    assert.deepEqual(P('a cup of rice'), [[1, 'cup', 'rice']]);
    assert.deepEqual(P('three eggs'), [[3, null, 'eggs']]);
    assert.deepEqual(P('Twelve dates'), [[12, null, 'dates']]);
    assert.deepEqual(P('one and a half cups rice'), [[1.5, 'cup', 'rice']]);
    assert.deepEqual(P('1 and a half cups rice'), [[1.5, 'cup', 'rice']]);
    assert.deepEqual(P('a quarter cup oats'), [[0.25, 'cup', 'oats']]);
    assert.deepEqual(P('about 2 eggs'), [[2, null, 'eggs']]);
    assert.deepEqual(P('1,000 g rice'), [[1000, 'g', 'rice']]);
    assert.deepEqual(P('.5 cup milk'), [[0.5, 'cup', 'milk']]);
  });
  it('splits on commas, semicolons, newlines and " and "; drops empty pieces and a leading "and"', () => {
    assert.equal(FC.parse('2 eggs, 150 g rice; 1 cup milk\n1 tbsp olive oil and half an avocado').items.length, 5);
    assert.equal(FC.parse('2 eggs,, ,;; 3 dates').items.length, 2);
    assert.deepEqual(P('and 2 eggs'), [[2, null, 'eggs']]);
    assert.deepEqual(P('2 eggs and 3 dates'), [[2, null, 'eggs'], [3, null, 'dates']]);
    assert.deepEqual(P('2 eggs & 3 dates'), [[2, null, 'eggs'], [3, null, 'dates']]);
    // without a database (parse(text) alone) " and " splits unless the phrase is an alias name; with one, see p6-dawit-foodcalc-and.test.js
    assert.equal(FC.parse('mac and cheese').items.length, 2);
    assert.equal(FC.parse('brand new').items.length, 1, '"and" inside a word never splits');
  });
  it('weird whitespace (nbsp, thin space, tabs, CRLF, zero-width)', () => {
    assert.deepEqual(P('2\u00a0eggs ,\t150\u2009g   rice\r\n1\u200b cup\u3000milk'), [[2, null, 'eggs'], [150, 'g', 'rice'], [1, 'cup', 'milk']]);
    assert.deepEqual(P('   \n\t  \u00a0 '), []);
  });
  it('empty, null, undefined, numbers, objects: no items, never throws', () => {
    for (const v of ['', ' ', null, undefined, 42, {}, [], true]) { const r = FC.parse(v); assert.equal(r.ok, true); assert.deepEqual(r.items, []); }
  });
  it('very long input is capped (chars and items) and reported', () => {
    const long = FC.parse('1 egg, '.repeat(5000));
    assert.equal(long.truncated, true); assert.ok(long.items.length <= FC.MAX_ITEMS);
    const many = FC.parse(Array.from({ length: 80 }, (_, i) => (i + 1) + ' g rice').join(', '));
    assert.equal(many.items.length, FC.MAX_ITEMS); assert.equal(many.truncated, true);
    assert.equal(FC.parse('2 eggs').truncated, false);
    const t0 = Date.now(); est('x '.repeat(100000)); assert.ok(Date.now() - t0 < 2000, 'huge input stays fast');
  });
  it('no quantity, range, zero and huge amounts are flagged, not guessed', () => {
    assert.equal(FC.parse('banana').items[0].amount, null);
    assert.equal(FC.parse('2-3 eggs').items[0].amount, null); assert.equal(FC.parse('2-3 eggs').items[0].problem, 'range');
    assert.equal(FC.parse('2 to 3 eggs').items[0].problem, 'range');
    assert.equal(FC.parse('0 g rice').items[0].problem, 'zero');
    assert.equal(FC.parse('99999999 g rice').items[0].problem, 'toolarge');
  });
  it('raw keeps the (whitespace-collapsed) typed text', () => { assert.equal(FC.parse('  2   eggs ').items[0].raw, '2 eggs'); });
  it('parse needs no database', () => { assert.equal(FC.parse('2 eggs').ok, true); });
});

describe('P6 foodcalc: alias table (documented, verified against the built DB)', () => {
  it('has 80-150 foods, every fdcId exists in the DB, names are unique', () => {
    assert.ok(FC.ALIASES.length >= 80 && FC.ALIASES.length <= 150, String(FC.ALIASES.length));
    const seen = {};
    for (const [names, ds, id, label, note] of FC.ALIASES) {
      assert.ok(byKey[ds + ':' + id], names[0] + ' -> ' + ds + id + ' missing from DB');
      assert.ok(Array.isArray(names) && names.length >= 1 && typeof note === 'string');
      for (const n of names) { assert.equal(n, n.toLowerCase()); assert.equal(seen[n], undefined, 'duplicate alias ' + n); seen[n] = 1; }
      if (label !== null) assert.ok(byKey[ds + ':' + id][7].some((p) => p[1] === label), names[0] + ' default portion "' + label + '" is not a USDA row of that food');
    }
  });
  it('the common foods the owner types are all covered', () => {
    const all = new Set(FC.ALIASES.flatMap((a) => a[0]));
    for (const n of ['egg', 'rice', 'milk', 'olive oil', 'avocado', 'bread', 'banana', 'apple', 'chicken breast', 'oats', 'yogurt', 'hummus', 'dates', 'tahini', 'butter', 'honey', 'tuna', 'salmon', 'lentils', 'chickpeas', 'potato', 'orange', 'coffee', 'water']) assert.ok(all.has(n), n);
  });
  it('every alias name resolves to its own food (typed as "100 g <name>")', () => {
    for (const [names, ds, id] of FC.ALIASES) for (const n of names) {
      const i = FC.estimate('100 g ' + n, DB).items[0];
      assert.equal(i.status, 'matched', n); assert.equal(i.chosen.fdcId, id, n); assert.equal(i.chosen.dataset, ds, n);
      assert.deepEqual(i.nutrients, nutOf(byKey[ds + ':' + id], 100), n);
    }
  });
  it('every alias with a default count portion: "2 <name>" = 2 x (row grams / row amount)', () => {
    let n = 0;
    for (const [names, ds, id, label] of FC.ALIASES) {
      if (label === null) continue; n++;
      const p = byKey[ds + ':' + id][7].find((x) => x[1] === label), i = FC.estimate('2 ' + names[0], DB).items[0];
      assert.equal(i.status, 'matched', names[0]); assert.equal(i.grams, r2(2 * p[2] / p[0]), names[0]);
      assert.equal(i.portion.basis, 'alias_default'); assert.equal(i.portion.label, label);
    }
    assert.ok(n >= 40, 'at least 40 aliases carry a documented count portion: ' + n);
  });
  it('aliases without a count portion refuse a bare count instead of inventing one ("2 rice")', () => {
    const i = one('2 rice'); assert.equal(i.status, 'no_portion'); assert.equal(i.nutrients, null); assert.equal(i.grams, null);
  });
  it('plural/singular, case, hyphen and size words resolve to the alias', () => {
    assert.equal(one('2 Tomatoes').chosen.fdcId, 170457); assert.equal(one('2 peaches').chosen.fdcId, 169928);
    assert.equal(one('1 MEDIUM banana').chosen.fdcId, 173944);
    assert.equal(one('2 hard-boiled eggs').chosen.fdcId, 173424);
    assert.equal(one('2 semi-skimmed milk'.replace('2 ', '1 cup ')).chosen.fdcId, 171267);
  });
  it('size words pick the matching USDA row when it exists ("1 large banana"), else fall back and say so', () => {
    const f = row('SR', 173944), large = f[7].find((p) => /^large\b/.test(p[1]));
    if (large) assert.equal(one('1 large banana').grams, r2(large[2] / large[0]));
    const j = one('1 large dates'); assert.equal(j.status, 'matched'); assert.match(j.message, /no "large" measure/);
  });
  it('the assumption behind an alias is said in item.message (rice is assumed cooked)', () => {
    assert.match(one('150 g rice').message, /cooked/); assert.match(one('150 g uncooked rice').message, /Dry/);
    assert.notEqual(one('150 g uncooked rice').chosen.fdcId, one('150 g rice').chosen.fdcId);
  });
  it('generic words that hide a real choice are NOT aliased (chicken, cheese, turkey, chocolate, corn, soda)', () => {
    for (const w of ['chicken', 'cheese', 'turkey', 'chocolate', 'corn', 'soda', 'fish', 'oil', 'beef', 'bean']) assert.notEqual(one('100 g ' + w).status, 'matched', w);
  });
});

describe('P6 foodcalc: units and portions', () => {
  const rice = row('SR', 168878), milk = row('SR', 171265);
  it('mass units convert directly (g, kg, mg, oz, lb) with basis "mass"', () => {
    for (const [t, g] of [['150 g rice', 150], ['0.5 kg rice', 500], ['250 mg rice', 0.25], ['4 oz rice', r2(4 * 28.3495)], ['1 lb rice', r2(453.592)], ['1.5 lb rice', r2(1.5 * 453.592)]]) {
      const i = one(t); assert.equal(i.status, 'matched', t); assert.equal(i.grams, g, t); assert.equal(i.portion.basis, 'mass'); assert.deepEqual(i.nutrients, nutOf(rice, g), t);
    }
  });
  it('cup / tbsp / tsp use the food USDA row; fractions scale it', () => {
    const cup = portion(milk, 'cup');
    assert.equal(one('1/2 cup milk').grams, r2(0.5 * cup[2] / cup[0])); assert.equal(one('1 1/2 cups milk').grams, r2(1.5 * cup[2] / cup[0]));
    const oil = row('SR', 171413);
    assert.equal(one('2 tbsp olive oil').grams, r2(2 * portion(oil, 'tablespoon')[2])); assert.equal(one('1 tsp olive oil').grams, r2(portion(oil, 'tsp')[2]));
    assert.equal(one('1 cup olive oil').grams, r2(portion(oil, 'cup')[2]));
  });
  it('slice uses the slice row; piece falls back to the alias default', () => {
    const bread = row('SR', 174924); assert.equal(one('3 slices bread').grams, r2(3 * portion(bread, 'slice')[2]));
    assert.equal(one('1 slice of bread').portion.label, 'slice');
    assert.equal(one('2 pieces egg').grams, r2(2 * portion(row('SR', 171287), 'large')[2]));
  });
  it('ml uses a bare USDA volume row (cup, tbsp, tsp, fl oz): grams = ml x (row grams per ml); litres too', () => {
    const cup = portion(milk, 'cup'), ML = 236.5882365;
    assert.equal(one('250 ml milk').grams, r2(250 * cup[2] / cup[0] / ML)); assert.equal(one('0.5 l milk').grams, r2(500 * cup[2] / cup[0] / ML));
    assert.match(one('250 ml milk').message, /Millilitres converted/);
    const w = row('SR', 173647), fl = portion(w, 'fl oz');
    assert.equal(one('100 ml water').grams, r2(100 * fl[2] / fl[0] / 29.5735295625));
  });
  it('ml with NO volume row is no_portion (no density guessing), never a number', () => {
    const t = tiny([[1, 'SR', 'Flour, test', 360, 10, 76, 1, []], [2, 'SR', 'Cheese, test slab', 300, 20, 2, 20, [[1, 'slab', 100]]]]);
    for (const q of ['100 ml flour test', '1 cup flour test', '1 tbsp flour test', '2 flour test']) { const i = FC.estimate(q, t).items[0]; assert.equal(i.status, 'no_portion', q); assert.equal(i.nutrients, null); assert.equal(i.grams, null); assert.ok(i.message.length > 10); }
    assert.equal(FC.estimate('100 ml cheese test slab', t).items[0].status, 'no_portion');
    assert.equal(FC.estimate('3 cheese test slab', t).items[0].grams, 300, 'one single-count row is used');
    assert.equal(FC.estimate('100 g flour test', t).items[0].status, 'matched', 'mass always works');
  });
  it('several "cup" variants (chopped / sliced ...) and no bare row: no_portion asking the user to pick', () => {
    const t = tiny([[1, 'SR', 'Veg, test', 20, 1, 3, 0, [[1, 'cup, chopped', 90], [1, 'cup, sliced', 70], [1, 'medium', 120], [1, 'large', 180]]]]);
    const c = FC.estimate('1 cup veg test', t).items[0]; assert.equal(c.status, 'no_portion'); assert.match(c.message, /several/);
    const m = FC.estimate('2 medium veg test', t).items[0]; assert.equal(m.status, 'matched'); assert.equal(m.grams, 240);
    assert.equal(FC.estimate('2 veg test', t).items[0].status, 'no_portion', 'two count rows: no silent pick');
    const p = FC.estimateItem('1 veg test', t, { portionIndex: 1 }); assert.equal(p.status, 'matched'); assert.equal(p.grams, 70);
  });
  it('a unique non-bare cup row is used; a bare cup row wins over variants', () => {
    const t = tiny([[1, 'SR', 'One cup, test', 100, 0, 25, 0, [[1, 'cup, cooked', 150]]], [2, 'SR', 'Bare cup, test', 100, 0, 25, 0, [[1, 'cup, chopped', 90], [2, 'cup', 300]]]]);
    assert.equal(FC.estimate('2 cups one cup test', t).items[0].grams, 300);
    assert.equal(FC.estimate('1 cup bare cup test', t).items[0].grams, 150, 'per-unit grams = row grams / row amount');
  });
  it('estimateItem edits: grams override, portion index, qty change, unit change, pick a candidate', () => {
    const g = FC.estimateItem('2 eggs', DB, { grams: 120.456 }); assert.equal(g.status, 'matched'); assert.equal(g.grams, 120.46); assert.equal(g.portion.basis, 'user_grams'); assert.deepEqual(g.nutrients, nutOf(row('SR', 171287), 120.46));
    const pi = FC.estimateItem('2 eggs', DB, { portionIndex: 3 }); const cupRow = row('SR', 171287)[7][3]; assert.equal(pi.grams, r2(2 * cupRow[2] / cupRow[0])); assert.equal(pi.portion.basis, 'usda_portion');
    assert.equal(FC.estimateItem('2 eggs', DB, { amount: 3 }).grams, 150);
    assert.equal(FC.estimateItem('2 eggs', DB, { unit: 'g', amount: 90 }).grams, 90);
    const pick = FC.estimateItem('1 cheddar', DB, { fdcId: 173424 }); assert.equal(pick.chosen.fdcId, 173424); assert.equal(pick.status, 'matched');
    const ff = FC.estimateItem('100 g x', DB, { fdcId: 323604, dataset: 'FF' }); assert.equal(ff.chosen.dataset, 'FF');
    assert.equal(FC.estimateItem('2 eggs', DB, { fdcId: 999999999 }).status, 'no_match');
    assert.equal(FC.estimateItem('banana', DB, { amount: 2 }).status, 'matched');
    assert.equal(FC.estimateItem('banana', DB, {}).status, 'unparsed');
  });
});

describe('P6 foodcalc: matching rules (alias, unique strong text match, ambiguous, no_match)', () => {
  it('gibberish is no_match: no nutrients, no candidates, counted as unmatched', () => {
    const r = est('asdkjh qwpoei, 2 xyzzyx');
    for (const i of r.items) { assert.equal(i.status, 'no_match'); assert.equal(i.nutrients, null); assert.equal(i.chosen, null); assert.deepEqual(i.candidates, []); assert.equal(i.provenance, null); assert.match(i.message, /No match/); }
    assert.deepEqual(r.totals, { kcal: 0, proteinG: 0, carbsG: 0, fatG: 0, matchedCount: 0, unmatchedCount: 2 });
  });
  it('a partial overlap that is not strong enough stays no_match ("dragon fruit pie shawarma")', () => {
    assert.equal(one('100 g chicken shawarma').status, 'no_match');
    assert.equal(one('100 g qwerty fruit shawarma').status, 'no_match');
  });
  it('ambiguous: candidates (max 5, scored, deterministic), nothing chosen, no nutrients; picking one makes it matched', () => {
    const i = one('100 g cheese');
    assert.equal(i.status, 'ambiguous'); assert.equal(i.chosen, null); assert.equal(i.nutrients, null); assert.equal(i.grams, null); assert.equal(i.provenance, null);
    assert.ok(i.candidates.length >= 2 && i.candidates.length <= 5);
    for (const c of i.candidates) { assert.ok(byKey[c.dataset + ':' + c.fdcId]); assert.equal(c.description, byKey[c.dataset + ':' + c.fdcId][2]); assert.ok(c.score > 0 && c.score <= 1); }
    assert.deepEqual(i.candidates, one('100 g cheese').candidates);
    const sorted = i.candidates.map((c) => c.score); assert.deepEqual(sorted, sorted.slice().sort((a, b) => b - a));
    const pick = FC.estimateItem('100 g cheese', DB, { fdcId: i.candidates[0].fdcId, dataset: i.candidates[0].dataset });
    assert.equal(pick.status, 'matched'); assert.deepEqual(pick.nutrients, nutOf(byKey[i.candidates[0].dataset + ':' + i.candidates[0].fdcId], 100));
    assert.equal(pick.provenance.fdcId, i.candidates[0].fdcId);
  });
  it('an unambiguous strong text match (exactly one food covers every word) is matched', () => {
    // Claude P6 review: chosen by itself only when the USDA description has no words beyond the typed ones.
    // "Egg, duck, whole, fresh, raw" says more than "duck egg": offered first, owner picks; picking gives the same numbers.
    const i = one('100 g duck egg'); assert.equal(i.status, 'ambiguous'); assert.equal(i.chosen, null); assert.equal(i.nutrients, null); assert.equal(i.candidates[0].fdcId, 172189);
    const pk = FC.estimateItem('100 g duck egg', DB, { fdcId: 172189, dataset: 'SR' }); assert.equal(pk.status, 'matched'); assert.deepEqual(pk.nutrients, nutOf(row('SR', 172189), 100));
    assert.equal(one('1 cup cooked millet').chosen.description, 'Millet, cooked');
  });
  it('two equally good foods are never silently chosen ("kiwifruit green raw" exists in SR and Foundation)', () => {
    assert.equal(one('100 g kiwifruit green raw').status, 'ambiguous');
  });
  it('alias candidates start with the alias food, then text candidates; <= 5', () => {
    const i = one('2 eggs'); assert.equal(i.candidates[0].fdcId, 171287); assert.ok(i.candidates.length <= 5);
    assert.equal(new Set(i.candidates.map((c) => c.dataset + c.fdcId)).size, i.candidates.length);
  });
  it('no quantity: food is identified but nothing is computed ("banana" -> unparsed, asks for a quantity)', () => {
    const i = one('banana'); assert.equal(i.status, 'unparsed'); assert.equal(i.nutrients, null); assert.equal(i.chosen.fdcId, 173944); assert.match(i.message, /quantity/);
  });
  it('range, zero and empty-food items are unparsed with a message and no numbers', () => {
    for (const t of ['2-3 eggs', '0 g rice', '150 g']) { const i = one(t); assert.equal(i.status, 'unparsed', t); assert.equal(i.nutrients, null); assert.ok(i.message.length > 5); }
  });
  it('prototype-ish words are plain text: no throw, no match', () => {
    for (const t of ['__proto__', '1 constructor', '100 g hasOwnProperty', 'toString', '2 valueOf, 1 __defineGetter__']) { const r = est(t); assert.equal(r.ok, true); for (const i of r.items) assert.notEqual(i.status, 'matched', t); }
  });
  it('one bad item never blocks the others; unmatched count is exact', () => {
    const r = est('2 eggs, 100 g qwertyuiop, 1 cup milk, 100 g cheese');
    assert.deepEqual(r.items.map((i) => i.status), ['matched', 'no_match', 'matched', 'ambiguous']);
    assert.equal(r.totals.matchedCount, 2); assert.equal(r.totals.unmatchedCount, 2);
    assert.equal(r.totals.kcal, r.items[0].nutrients.kcal + r.items[2].nutrients.kcal);
  });
  it('empty input: ok, no items, zero totals', () => {
    for (const t of ['', '   ', '\n\n', null, undefined]) { const r = FC.estimate(t, DB); assert.equal(r.ok, true); assert.deepEqual(r.items, []); assert.deepEqual(r.totals, { kcal: 0, proteinG: 0, carbsG: 0, fatG: 0, matchedCount: 0, unmatchedCount: 0 }); }
  });
  it('estimateItem on empty/garbage input returns an unparsed/no_match item, never throws', () => {
    for (const t of ['', null, 42, '   ']) { const i = FC.estimateItem(t, DB); assert.equal(i.ok, undefined); assert.ok(['unparsed', 'no_match'].includes(i.status), String(t)); assert.equal(i.nutrients, null); }
  });
  it('sanity: a food typed with its quantity never yields negative or non-finite numbers across the whole alias list', () => {
    for (const [names] of FC.ALIASES) for (const u of ['100 g ', '1 cup ', '1 tbsp ', '2 ', '1 slice ', '100 ml ']) {
      const i = FC.estimate(u + names[0], DB).items[0];
      if (i.status === 'matched') for (const v of Object.values(i.nutrients)) assert.ok(Number.isFinite(v) && v >= 0, u + names[0]);
      else assert.equal(i.nutrients, null);
    }
  });
});

describe('P6 foodcalc: guards that keep components valid', () => {
  it('a quantity beyond what one meal component can hold is refused (no 40,000 kcal item)', () => {
    const i = one('100000 g olive oil'); assert.equal(i.status, 'unparsed'); assert.equal(i.nutrients, null); assert.match(i.message, /too large/);
    const j = one('99999999999999999999 g rice'); assert.equal(j.status, 'unparsed');
    assert.equal(one('1000 g olive oil').status, 'matched', '8840 kcal is inside the 10000 kcal component limit');
    assert.equal(one('1200 g olive oil').status, 'unparsed', '10608 kcal exceeds the component limit');
  });
  it('every matched item stays inside the meals validator macro ranges', () => {
    for (const t of ['1100 g olive oil', '9999 g rice', '3000 g chicken breast', '500 g honey']) { const i = one(t); if (i.status === 'matched') { assert.ok(i.nutrients.kcal <= FC.MACRO_LIMIT.kcal); assert.ok(i.nutrients.proteinG <= FC.MACRO_LIMIT.proteinG); assert.ok(i.nutrients.carbsG <= FC.MACRO_LIMIT.carbsG); assert.ok(i.nutrients.fatG <= FC.MACRO_LIMIT.fatG); } }
  });
  it('USDA rows with a slightly negative carbohydrate-by-difference are counted as 0 g (and say so)', () => {
    const f = DB.foods.find((x) => x[5] < 0); assert.ok(f);
    const i = FC.estimateItem('150 g x', DB, { fdcId: f[0], dataset: f[1] });
    assert.equal(i.status, 'matched'); assert.equal(i.nutrients.carbsG, 0); assert.match(i.message, /negative/);
    assert.equal(i.nutrients.kcal, Math.round(f[3] * 150 / 100));
  });
});

describe('P6 foodcalc: database loading and failure (never throws)', () => {
  const FAIL = (r, code) => { assert.equal(r.ok, false); assert.equal(r.code, code); assert.equal(typeof r.message, 'string'); assert.ok(r.message.length > 5); assert.deepEqual(r.items, []); };
  const saved = () => ({ g: globalThis.HyroxFoodDb });
  it('no db argument and no global db: db_not_loaded for estimate and estimateItem; toComponents -> empty', () => {
    const s = saved(); delete globalThis.HyroxFoodDb;
    try {
      for (const r of [FC.estimate('2 eggs'), FC.estimate('2 eggs', undefined), FC.estimate('2 eggs', null), FC.estimateItem('2 eggs'), FC.estimateItem('2 eggs', null, {})]) FAIL(r, 'db_not_loaded');
      assert.deepEqual(FC.toComponents(FC.estimate('2 eggs')), { components: [], unmatched: [] });
      assert.equal(FC.parse('2 eggs').ok, true);
    } finally { if (s.g !== undefined) globalThis.HyroxFoodDb = s.g; }
  });
  it('a missing db falls back to window/global HyroxFoodDb; an explicit db wins', () => {
    const s = saved(); globalThis.HyroxFoodDb = DB;
    try {
      const a = FC.estimate('2 eggs'); assert.equal(a.ok, true); assert.equal(a.items[0].status, 'matched'); assert.deepEqual(a, FC.estimate('2 eggs', DB));
      assert.equal(FC.estimateItem('2 eggs').status, 'matched');
      const other = tiny([[7, 'SR', 'Egg thing, test', 100, 10, 1, 5, [[1, 'large', 40]]]]);
      assert.equal(FC.estimate('2 egg thing test', other).dbVersion, 'test-db'); assert.equal(FC.estimate('2 egg thing test', other).items[0].chosen.fdcId, 7);
      FAIL(FC.estimate('2 eggs', { nope: 1 }), 'db_invalid');
    } finally { if (s.g === undefined) delete globalThis.HyroxFoodDb; else globalThis.HyroxFoodDb = s.g; }
  });
  it('loaded in a browser-like vm exactly as the page does it: food-db.js then hyrox-foodcalc.js, no db argument', () => {
    const win = {}; const ctx = vm.createContext({ window: win, self: win });
    vm.runInContext(fs.readFileSync(path.resolve(__dirname, '../src/data/food-db.js'), 'utf8'), ctx);
    vm.runInContext(fs.readFileSync(path.resolve(__dirname, '../src/data/hyrox-foodcalc.js'), 'utf8'), ctx);
    assert.equal(typeof win.HyroxFoodCalc.estimate, 'function'); assert.equal(typeof win.HyroxFoodDb.meta, 'object');
    const r = win.HyroxFoodCalc.estimate('2 eggs, 150 g rice');
    assert.equal(r.ok, true); assert.equal(r.items[0].status, 'matched'); assert.equal(r.dbVersion, DB.meta.dbVersion);
    // the script loaded alone (food-db.js missing or failed): db_not_loaded
    const w2 = {}; const c2 = vm.createContext({ window: w2, self: w2 });
    vm.runInContext(fs.readFileSync(path.resolve(__dirname, '../src/data/hyrox-foodcalc.js'), 'utf8'), c2);
    const f = w2.HyroxFoodCalc.estimate('2 eggs'); assert.equal(f.ok, false); assert.equal(f.code, 'db_not_loaded'); assert.equal(w2.HyroxFoodCalc.parse('2 eggs').ok, true);
  });
  it('invalid databases give db_invalid (estimate, estimateItem), never a throw', () => {
    const good = [1, 'SR', 'Egg thing, test', 100, 10, 1, 5, [[1, 'large', 40]]];
    const bads = [{}, [], 'x', 5, true, { meta: {}, foods: [] }, { meta: { schema: 1, dbVersion: 'v' }, foods: [] }, { meta: { schema: 2, dbVersion: 'v' }, foods: [good] },
      { meta: { schema: 1 }, foods: [good] }, { meta: { schema: 1, dbVersion: 'v' }, foods: 'nope' }, tiny([[1, 'SR', 'x']]), tiny([[1, 'XX', 'x', 1, 1, 1, 1, []]]),
      tiny([[1.5, 'SR', 'x', 1, 1, 1, 1, []]]), tiny([[1, 'SR', '', 1, 1, 1, 1, []]]), tiny([[1, 'SR', 'x', null, 1, 1, 1, []]]), tiny([[1, 'SR', 'x', 1, 1, 1, NaN, []]]),
      tiny([[1, 'SR', 'x', 1, 1, 1, 1, 'p']]), tiny([[1, 'SR', 'x', 1, 1, 1, 1, [[0, 'cup', 10]]]]), tiny([[1, 'SR', 'x', 1, 1, 1, 1, [[1, 'cup', -4]]]]),
      tiny([[1, 'SR', 'x', 1, 1, 1, 1, [[1, 5, 4]]]]), tiny([good, good]), '{not json', '{"meta":{"schema":1,"dbVersion":"v"},"foods":[[1]]}'];
    for (const b of bads) { FAIL(FC.estimate('2 eggs', b), 'db_invalid'); FAIL(FC.estimateItem('2 eggs', b), 'db_invalid'); assert.deepEqual(FC.toComponents(FC.estimate('2 eggs', b)), { components: [], unmatched: [] }); }
  });
  it('loadDb: accepts an object, JSON text or its own result; rejects the rest with db_invalid', () => {
    const a = FC.loadDb(DB); assert.equal(a.ok, true); assert.equal(a.db, DB);
    const b = FC.loadDb(JSON.stringify(DB)); assert.equal(b.ok, true); assert.equal(b.db.meta.foodCount, DB.meta.foodCount);
    assert.equal(FC.loadDb(a).ok, true);
    for (const bad of [null, undefined, 3, '', '{', '[]', { meta: {} }]) { const r = FC.loadDb(bad); assert.equal(r.ok, false); assert.equal(r.code, 'db_invalid'); assert.ok(r.message); }
    assert.equal(FC.estimate('2 eggs', a).ok, true, 'the loadDb result can be passed straight to estimate');
  });
  it('a hostile getter on the db cannot make estimate throw', () => {
    const evil = { get meta() { throw new Error('boom'); }, foods: [] };
    assert.doesNotThrow(() => FC.estimate('2 eggs', evil)); assert.equal(FC.estimate('2 eggs', evil).ok, false);
    assert.doesNotThrow(() => FC.estimateItem('2 eggs', evil));
  });
  it('the module is pure: no storage / network / timers referenced', () => {
    const src = fs.readFileSync(path.resolve(__dirname, '../src/data/hyrox-foodcalc.js'), 'utf8').replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, '');
    for (const w of ['localStorage', 'sessionStorage', 'fetch(', 'XMLHttpRequest', 'setTimeout', 'Date.now', 'Math.random', 'require(']) assert.equal(src.includes(w), false, w);
  });
});
