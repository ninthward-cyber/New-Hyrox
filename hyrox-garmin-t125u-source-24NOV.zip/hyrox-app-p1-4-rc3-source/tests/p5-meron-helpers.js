'use strict';
// Shared helpers for Meron Phase 5 restore-safety RED tests.
// Follows /workspace/hyrox-p5/CONTRACT.md (published 11 Nov 2026). Synthetic data only.
const path = require('node:path');
const HD = require(path.resolve(__dirname, '../src/data/hyrox-data.js'));

const NOW = new Date('2026-11-11T09:00:00Z');
const TS = NOW.toISOString();
const KEY = HD.STORAGE_KEY;
const PRE = HD.IMPORT_BACKUP_KEY;
const RECOVERY = HD.RECOVERY_KEY;
const ALL = Object.freeze([
  'weight', 'workouts', 'nutrition',
  'sessions', 'meals', 'body', 'daily', 'walks', 'dayStates', 'planEvents', 'ownerSettings'
]);
const CLASSIC = Object.freeze(['weight', 'workouts', 'nutrition']);

function mem(init) {
  const m = Object.assign({}, init || {});
  const calls = [];
  const setCount = {};
  return {
    m, calls,
    writes() { return calls.filter((c) => c[0] !== 'get'); },
    snapshot() { return JSON.stringify(Object.keys(m).sort().map((k) => [k, m[k]])); },
    getItem(k) {
      calls.push(['get', k]);
      return Object.prototype.hasOwnProperty.call(m, k) ? m[k] : null;
    },
    setItem(k, v) {
      calls.push(['set', k, String(v)]);
      setCount[k] = (setCount[k] || 0) + 1;
      m[k] = String(v);
    },
    removeItem(k) {
      calls.push(['remove', k]);
      delete m[k];
    },
  };
}

// Per-key fault injection, same shapes as tests/hyrox-data.test.js.
// faults.set(key, value, n) -> 'throw' | 'truncate' | 'ignore' | 'swap' | undefined (n is 1-based)
// faults.get(key, n) -> true to throw; faults.remove(key) -> true to throw
function faultStorage(seed, faults) {
  faults = faults || {};
  const m = Object.assign({}, seed || {});
  const calls = [];
  const setCount = {};
  const getCount = {};
  return {
    m, calls,
    writes() { return calls.filter((c) => c[0] !== 'get'); },
    snapshot() { return JSON.stringify(Object.keys(m).sort().map((k) => [k, m[k]])); },
    getItem(k) {
      calls.push(['get', k]);
      getCount[k] = (getCount[k] || 0) + 1;
      if (faults.get && faults.get(k, getCount[k])) throw new Error('SecurityError');
      return Object.prototype.hasOwnProperty.call(m, k) ? m[k] : null;
    },
    setItem(k, v) {
      const s = String(v);
      calls.push(['set', k, s]);
      setCount[k] = (setCount[k] || 0) + 1;
      const f = faults.set && faults.set(k, s, setCount[k]);
      if (f === 'throw') throw new Error('QuotaExceededError');
      if (f === 'ignore') return;
      if (f === 'truncate') { m[k] = s.slice(0, 7); return; }
      if (f === 'swap') { m[k] = '{"version":1,"weight":[],"workouts":[],"nutrition":[]}'; return; }
      m[k] = s;
    },
    removeItem(k) {
      calls.push(['remove', k]);
      if (faults.remove && faults.remove(k)) throw new Error('SecurityError');
      delete m[k];
    },
  };
}

const mk = (s) => HD.createStore(s, { now: () => NOW });

function backup(extra, version) {
  return JSON.stringify(Object.assign({
    app: 'hyrox-app',
    version: version === undefined ? 2 : version,
    exportedAt: TS,
    weight: [], workouts: [], nutrition: [],
  }, extra || {}));
}

function emptyBackup(extra) {
  return backup(extra);
}

function validWeight(id, kg, date) {
  return { id: id || 'w-live', createdAt: TS, date: date || '2026-11-10', kg: kg == null ? 80 : kg };
}

function storedPopulated(extra) {
  return JSON.stringify(Object.assign({
    version: 2,
    weight: [validWeight()],
    workouts: [],
    nutrition: [],
  }, extra || {}));
}

function plant(s, data) {
  s.setItem(KEY, typeof data === 'string' ? data : JSON.stringify(data));
}

function livePopulated(extra) {
  const s = mem();
  plant(s, storedPopulated(extra));
  const st = mk(s);
  return { s, st, before: s.snapshot(), raw: s.getItem(KEY) };
}

function applyReplace(st, text, extraOpts) {
  const p = st.previewImport(text);
  if (!p.ok) return p;
  const opts = Object.assign({
    confirm: 'REPLACE',
    expectCurrent: p.preview.current,
    expectCurrentExt: p.preview.currentExt,
  }, extraOpts || {});
  return st.applyImport(text, opts);
}

function slotRaw(s) {
  const v = s.getItem(PRE);
  if (v == null) return null;
  try { return JSON.parse(v); } catch (e) { return { _unparseable: true, rawSlot: v }; }
}

function zeroAll() {
  const o = {};
  ALL.forEach((k) => { o[k] = 0; });
  o.total = 0;
  return o;
}

module.exports = {
  HD, NOW, TS, KEY, PRE, RECOVERY, ALL, CLASSIC,
  mem, faultStorage, mk, backup, emptyBackup, validWeight, storedPopulated,
  plant, livePopulated, applyReplace, slotRaw, zeroAll,
};
