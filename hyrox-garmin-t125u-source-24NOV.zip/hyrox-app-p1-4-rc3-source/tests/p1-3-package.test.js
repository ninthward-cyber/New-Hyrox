'use strict';
// P1.3-RC1 packaging (fail-first): release label, deploy README, deploy/change notes, corrected wording and references.
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const read = (f) => fs.readFileSync(path.join(root, f), 'utf8');

test('P1.3 package: release label P1.3-RC1, dated, source copy unstamped; the comment names 18 app files', () => {
  const html = read('index.html');
  assert.match(html, /<meta name="hyrox-release" content="(P1\.3-RC[123]|P1\.4-RC[123])">/); // RE-POINTED by P1.4-RC2 (Sprint B2, 23 Nov 2026); // RE-POINTED by the integrated candidate P1.4-RC1 (23 Nov 2026); // re-pointed: P1.3-RC2 (independent review) // RE-POINTED by P1.4-RC3 (Claude independent QA, 23 Nov 2026)
  assert.match(html, /<meta name="hyrox-build-date" content="2026-11-23">/);
  assert.match(html, /<meta name="hyrox-build-id" content="dev">/);
  assert.match(html, /over the 20 app files/); // RE-POINTED R8 (24 Nov 2026): +src/integrations/garmin-import.js -> 20
  assert.doesNotMatch(html, /over the 16 app files/);
});

test('P1.3 package: the build script defaults to the P1.3-RC1 folder and still asserts 18 files', () => {
  const s = read('tools/build-deploy-package.mjs');
  assert.match(s, /hyrox-p1-(3-rc[123]|4-rc[123])-deploy/); /* RE-POINTED by the integrated candidate P1.4-RC1 (23 Nov 2026) */ // re-pointed: P1.3-RC2 assert.match(s, /APP_FILES\.length !== 18/); // RE-POINTED by P1.4-RC2 // RE-POINTED by P1.4-RC3 (Claude independent QA, 23 Nov 2026)
  assert.doesNotMatch(s, /the 17 static app files/);
});

test('P1.3 package: README-DEPLOY names this package, its notes, the coach file and the true style.css statement', () => {
  const r = read('deploy/README-DEPLOY.txt');
  for (const re of [/P1\.3-RC1/, /DEPLOY-P1\.3-RC3\.md/, /SHA256SUMS-p1-3-rc3\.txt/, /CHANGES-P1\.3-RC1\.md/, /CHANGES-P1\.3-RC2\.md/, /protein floor 170 g/, /Monday-Sunday/, // re-pointed: P1.3-RC2 /hyrox-coach\.js/, /the 18 static app files/,
    /NOT deploy approval/, /Nutrition Coach/, /off until you turn it on/i, /data version 2/i, /No new storage key/]) assert.match(r, re);
  assert.doesNotMatch(r, /style\.css is byte-identical to P0-RC3/);
  assert.doesNotMatch(r, /^HYROX Command P1\.1-RC2 deploy package/m);
});

test('P1.3 notes: DEPLOY assumes no live build, rolls back to P1.1-RC2 first, keeps Block 2 locked; CHANGES corrects the P1.1-RC2 wording', () => {
  const d = read('DEPLOY-P1.3-RC1.md'), c = read('CHANGES-P1.3-RC1.md');
  assert.match(d, /not deploy approval/i); assert.match(d, /56f7a2c12c998d0c48ce9632764cf77454bd89e56ffab6f5f3411d60ccb2e143/); // P1.1-RC2 deploy ZIP
  assert.match(d, /3079cb300d1f/); assert.match(d, /331044/); // P1.1-RC2 source id and app-ext.js size, to recognise it if live
  assert.doesNotMatch(d, /If P1\.1-RC1 is live/); assert.match(d, /unknown|not confirmed/i);
  assert.match(d, /11 Dec/); assert.match(d, /Chrome emulation, not Safari/i);
  assert.match(c, /redrawn at the tap/); assert.match(c, /stays as you saw it until your next action/); // quotes the corrected sentence
  assert.match(c, /Mifflin/); assert.match(c, /provisional/i); assert.match(c, /Not deployed, not pushed/i);
});
