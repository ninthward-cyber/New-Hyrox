'use strict';
// Phase 4 overnight QA (Meron): adversarial tests of Claude R2 behaviour on b21cf93.
// NEW FILE only. Synthetic data. Current behaviour is asserted truthfully; real defects
// are left as clearly named failing DEFECT tests.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const HW = require(path.resolve(__dirname, '../src/data/hyrox-wellness.js'));
const { HD, KEY, mem, mk, O, ts, backup } = require('./p8-helpers.js');

const D = '2026-11-17';
const badDaily = (extra) => Object.assign({
  id: 'daily-' + D, createdAt: ts, updatedAt: ts, date: D,
  footPain: O(11), stairKneePain: O(1), sleepH: O(7),
  limp: { state: 'OBSERVED', value: false }, steps: O(8000), soreness: O(2), rhr: O(60),
}, extra);
function seed(lists) {
  const raw = JSON.stringify(Object.assign({
    version: 2,
    weight: [{ id: 'w1', createdAt: ts, date: D, kg: 80 }],
    workouts: [], nutrition: [],
  }, lists));
  const s = mem({ [KEY]: raw });
  return { s, st: mk(s), raw };
}
const noWrites = (s, raw) => {
  assert.equal(s.m[KEY], raw, 'stored text is byte-identical');
  assert.equal(s.writes, 0, 'nothing was written');
};

describe('damaged-record approval: nothing is written without a strict true flag', () => {
  function correctedView(st) {
    const view = JSON.parse(JSON.stringify(st.records('daily')[0]));
    view.footPain = O(2);
    return view;
  }

  it('putRecord refuses every non-true approval stand-in and writes nothing', () => {
    const standins = [
      undefined, {}, { approveCorrection: false }, { approveCorrection: 'true' },
      { approveCorrection: 1 }, { approveCorrection: 'yes' }, { approveCorrection: { ok: true } },
      { approveDamaged: true }, { approveCorrection: 'TRUE' },
    ];
    for (const opts of standins) {
      const { s, st, raw } = seed({ daily: [badDaily()] });
      const r = st.putRecord('daily', correctedView(st), opts);
      assert.equal(r.ok, false, JSON.stringify(opts));
      assert.equal(r.code, 'STORED_RECORD_DAMAGED', JSON.stringify(opts));
      noWrites(s, raw);
    }
  });

  it('a true flag placed on the record body, not in opts, is not approval and writes nothing', () => {
    const { s, st, raw } = seed({ daily: [badDaily()] });
    const view = correctedView(st);
    view.approveCorrection = true;
    view.approveDamaged = true;
    const r = st.putRecord('daily', view);
    assert.equal(r.ok, false);
    assert.equal(r.code, 'STORED_RECORD_DAMAGED');
    noWrites(s, raw);
  });

  it('approveCorrection: true is the only accepted write path, and a replay without the flag still fails', () => {
    const { s, st, raw } = seed({ daily: [badDaily()] });
    const view = correctedView(st);
    assert.equal(st.putRecord('daily', view).ok, false);
    noWrites(s, raw);
    const ok = st.putRecord('daily', view, { approveCorrection: true });
    assert.equal(ok.ok, true);
    assert.deepEqual(st.records('daily')[0].footPain, O(2));
    assert.deepEqual(st.records('daily')[0].sleepH, O(7));
    assert.deepEqual(st.records('daily')[0].steps, O(8000));
    // A second damaged record still needs its own approval (replay does not latch).
    const raw2 = s.m[KEY];
    const writes = s.writes;
    const other = Object.assign(badDaily({ id: 'daily-2026-11-16', date: '2026-11-16' }));
    const stuffed = JSON.parse(raw2);
    stuffed.daily.push(other);
    const raw3 = JSON.stringify(stuffed);
    s.m[KEY] = raw3;
    const st3 = mk(s);
    const view3 = JSON.parse(JSON.stringify(st3.records('daily').find((d) => d.date === '2026-11-16')));
    view3.footPain = O(1);
    const again = st3.putRecord('daily', view3); // no flag
    assert.equal(again.ok, false);
    assert.equal(again.code, 'STORED_RECORD_DAMAGED');
    assert.equal(s.m[KEY], raw3);
    assert.equal(s.writes, writes);
  });

  it('removeRecord accepts only approveDamaged === true; the put-record flag does not delete', () => {
    const { s, st, raw } = seed({ daily: [badDaily()] });
    assert.equal(st.removeRecord('daily', 'daily-' + D), false);
    assert.equal(st.removeRecord('daily', 'daily-' + D, { approveCorrection: true }), false);
    assert.equal(st.removeRecord('daily', 'daily-' + D, { approveDamaged: 'true' }), false);
    noWrites(s, raw);
    assert.equal(st.removeRecord('daily', 'daily-' + D, { approveDamaged: true }), true);
    assert.equal(st.records('daily').length, 0);
  });

  it('approval does not bypass entry rules: a new or still-invalid pain 11 is refused and nothing is written', () => {
    const fresh = mk(mem());
    const neu = fresh.putRecord('daily', { date: D, footPain: O(11), sleepH: O(7) }, { approveCorrection: true });
    assert.equal(neu.ok, false);
    const { s, st, raw } = seed({ daily: [badDaily()] });
    const view = JSON.parse(JSON.stringify(st.records('daily')[0]));
    view.footPain = O(11);
    const r = st.putRecord('daily', view, { approveCorrection: true });
    assert.equal(r.ok, false);
    assert.ok(r.errors && r.errors.footPain);
    noWrites(s, raw);
  });
});

describe('normal vs emergency backup separation', () => {
  it('the normal export is a hyrox-app backup, not a raw recovery file, and does not embed emergency sources', () => {
    const { s, st, raw } = seed({ daily: [badDaily()] });
    const text = st.exportJSON();
    const exp = JSON.parse(text);
    assert.equal(exp.app, 'hyrox-app');
    assert.equal(exp.kind, undefined);
    assert.equal(exp.format, undefined);
    assert.equal(Array.isArray(exp.sources), false);
    assert.notEqual(exp.app, HD.RAW_RECOVERY_KIND);
    assert.equal(HD.parseRawRecovery(text).ok, false);
    noWrites(s, raw);
  });

  it('the emergency copy is identifiable, byte-exact, and refused by previewImport and applyImport (nothing written)', () => {
    const { s, st, raw } = seed({ daily: [badDaily()] });
    const recov = st.rawRecoveryExport();
    assert.equal(recov.ok, true);
    assert.match(recov.filename, /^hyrox-RAW-RECOVERY-/);
    assert.match(recov.warning, /NOT a normal backup and cannot be restored/);
    const parsed = JSON.parse(recov.text);
    assert.equal(parsed.app, HD.RAW_RECOVERY_KIND);
    assert.equal(parsed.kind, HD.RAW_RECOVERY_KIND);
    assert.equal(parsed.format, 1);
    assert.ok(Array.isArray(parsed.sources) && parsed.sources.length >= 1);
    assert.equal(parsed.sources[0].raw, raw);
    const ident = HD.parseRawRecovery(recov.text);
    assert.equal(ident.ok, true);
    assert.equal(ident.sources[0].raw, raw);

    const p = st.previewImport(recov.text);
    assert.equal(p.ok, false);
    assert.equal(p.code, 'raw_recovery_file');
    noWrites(s, raw);

    const a = st.applyImport(recov.text, { confirm: 'REPLACE', expectCurrent: { weight: 1, workouts: 0, nutrition: 0 }, approveCorrection: true, approveDamaged: true });
    assert.equal(a.ok, false);
    assert.equal(a.code, 'raw_recovery_file');
    noWrites(s, raw);

    const pPad = mk(mem()).previewImport('\n  ' + recov.text + '\n');
    assert.equal(pPad.ok, false);
    assert.equal(pPad.code, 'raw_recovery_file');
  });

  it('the inner stored payload of a raw copy is not itself a normal backup', () => {
    const { st } = seed({ daily: [badDaily()] });
    const ident = HD.parseRawRecovery(st.rawRecoveryExport().text);
    const inner = mk(mem()).previewImport(ident.sources[0].raw);
    assert.equal(inner.ok, false);
    assert.equal(inner.code, 'not_hyrox');
  });
});

describe('DEFECT: a relabelled emergency raw recovery file can be imported as an empty normal backup and wipe live data', () => {
  // Current behaviour, named as a defect. The unmodified raw file is correctly refused, but if
  // app/kind are changed to look like a normal backup and empty weight/workouts/nutrition lists
  // are added, previewImport accepts it ("unknown top-level fields will be ignored") and
  // applyImport replaces live data with empty lists. The emergency copies in `sources` are
  // not restored. A user editing the emergency file to try to restore it can lose what was on the device.
  it('previewImport/applyImport of a relabelled raw file wipes the live store; this must be refused', () => {
    const { st } = seed({ daily: [badDaily()] });
    const recov = st.rawRecoveryExport();
    const pRaw = JSON.parse(recov.text);
    const disguised = Object.assign({}, pRaw, { app: 'hyrox-app', version: 2, weight: [], workouts: [], nutrition: [] });
    delete disguised.kind;
    const live = mem();
    const st2 = mk(live);
    st2.addWeight({ date: D, kg: 80 });
    const before = live.m[KEY];
    const prev = st2.previewImport(JSON.stringify(disguised));
    // Expected (safe) behaviour: still identifiable as a raw recovery file, refused, nothing written.
    assert.equal(prev.ok, false, 'relabelled raw recovery must not preview as a normal backup');
    assert.equal(prev.code, 'raw_recovery_file');
    assert.equal(live.m[KEY], before);
    const applied = st2.applyImport(JSON.stringify(disguised), { confirm: 'REPLACE', expectCurrent: { weight: 1, workouts: 0, nutrition: 0 } });
    assert.equal(applied.ok, false);
    assert.equal(applied.code, 'raw_recovery_file');
    assert.equal(live.m[KEY], before);
    assert.equal(st2.list('weight').length, 1);
  });
});

describe('PAIN_INVALID: corrupted general pain holds the reference goal and is never treated as pain-free', () => {
  const set = { rhrBaselineBpm: 76, rhrBaselineSource: 'OWNER_DEFAULT' };

  it('an invalid stored general pain is PAIN_INVALID / DO_NOT_FORCE; a missing pain is not (held policy)', () => {
    const invalid = seed({ daily: [badDaily({ footPain: O(1), pain: O(14) })] }).st.records('daily');
    const r = HW.readiness(D, invalid, set);
    assert.deepEqual(r.invalid, ['pain']);
    assert.match(r.guidance, /cannot be confirmed/);
    assert.match(r.painUnknown, /unknown \(not 0\)/);
    assert.match(r.painUnknown, /Do not treat today as pain-free/);
    const ref = HW.stepReferenceGoal(D, { dailies: invalid, walks: [], sessions: [], settings: set });
    assert.equal(ref.status, 'DO_NOT_FORCE');
    assert.ok(ref.doNotForce.includes('PAIN_INVALID'));
    assert.equal(ref.optional10k.offered, false);
    assert.equal(ref.gate.status, 'PASS', 'the four 10k-gate inputs are valid here');

    const missing = seed({ daily: [badDaily({ footPain: O(1) })] }).st.records('daily');
    const refM = HW.stepReferenceGoal(D, { dailies: missing, walks: [], sessions: [], settings: set });
    assert.equal(refM.status, 'ACTIVE', 'a missing (not invalid) general pain does not hold the goal — owner item still open');
    assert.equal(refM.doNotForce.includes('PAIN_INVALID'), false);
  });
});

describe('sleep range: only 0–24 h is accepted; 0 is a real failure, 99 h is invalid', () => {
  const ok = { footPain: 0, limp: false, stairKneePain: 0, sleepH: 7 };

  it('boundary and rejected values', () => {
    assert.equal(HW.step10kGate(Object.assign({}, ok, { sleepH: 0 })).status, 'FAIL');
    assert.equal(HW.step10kGate(Object.assign({}, ok, { sleepH: 6 })).status, 'PASS');
    assert.equal(HW.step10kGate(Object.assign({}, ok, { sleepH: 24 })).status, 'PASS');
    for (const v of [24.0000001, 24.5, 25, 99, -0.1, -1, NaN, Infinity, '7', true]) {
      const g = HW.step10kGate(Object.assign({}, ok, { sleepH: v }));
      assert.equal(g.status, 'UNKNOWN', String(v));
      assert.deepEqual(g.invalid, ['sleepH'], String(v));
    }
    const stored = seed({ daily: [badDaily({ footPain: O(1), sleepH: O(99) })] }).st.records('daily');
    const g = HW.tenKGate(D, stored);
    assert.equal(g.status, 'UNKNOWN');
    assert.ok(g.invalid.includes('sleepH'));
    assert.equal(stored[0].sleepH.state, 'INVALID');
    assert.equal(g.checks.find((c) => c.key === 'footPain').result, 'PASS');
  });
});

describe('fractional walk steps: new fractions refused; legacy kept exactly and not counted; F7 daily totals unchanged', () => {
  const walk = (o) => Object.assign({ id: 'w-frac', createdAt: ts, updatedAt: ts, date: D, durationMin: 30, steps: 10.5 }, o);

  it('putRecord refuses 10.5 and 10.0000001 and writes nothing; 10 and 0 are accepted', () => {
    const s = mem(); const st = mk(s);
    assert.equal(st.putRecord('walks', { date: D, durationMin: 30, steps: 10.5 }).ok, false);
    assert.equal(st.putRecord('walks', { date: D, durationMin: 30, steps: 10.0000001 }).ok, false);
    assert.deepEqual(Object.keys(s.m), []);
    assert.equal(st.putRecord('walks', { date: D, durationMin: 30, steps: 10 }).ok, true);
    assert.equal(st.putRecord('walks', { date: D, durationMin: 30, steps: 0 }).ok, true);
  });

  it('a stored legacy 10.5 is not counted or rounded, and a same-day whole count is not padded up', () => {
    const { s, st, raw } = seed({ walks: [walk(), walk({ id: 'w-ok', steps: 3000 })] });
    const ds = HW.daySteps(D, { walks: st.records('walks'), dailies: [], sessions: [] });
    assert.equal(ds.total, 3000);
    assert.equal(ds.ignoredInvalid, 1);
    noWrites(s, raw);
  });

  it('a daily-total 10.5 is still refused on entry and on restore (F7 / t54u)', () => {
    assert.equal(mk(mem()).putRecord('daily', { date: D, steps: O(10.5) }).ok, false);
    const p = mk(mem()).previewImport(backup({ daily: [{ id: 'd', createdAt: ts, date: D, steps: O(10.5) }] }));
    assert.equal(p.ok, false);
    assert.equal(p.code, 'invalid_records');
  });
});
