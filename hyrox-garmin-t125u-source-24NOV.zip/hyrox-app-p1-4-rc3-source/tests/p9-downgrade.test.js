'use strict';
// Phase 9 downgrade/rollback check: a backup exported by Phase 9 that contains a LIVE photo meal (ai.mode REAL, provider openai,
// source PHOTO_AI) must restore on the Phase 8 and Phase 7 data layers with every field intact. Phase 9 changed NO file under src/data/,
// so this is also asserted byte-for-byte. The older source trees are read-only; the checks are SKIPPED (visibly) if they are absent.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const OLD = {
  p8: process.env.P9_P8_SRC || '/workspace/hyrox-p8/src',
  p7: process.env.P9_P7_SRC || '/workspace/hyrox-p7/repo/src',
};
const HERE = path.resolve(__dirname, '..', 'src');
const FIXTURE = fs.readFileSync(path.join(__dirname, 'fixtures', 'p9-live-export.json'), 'utf8');
const NOW = new Date('2026-11-18T09:00:00Z');
const sha = (f) => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
const mem = () => { const m = {}; return { m, getItem: (k) => (k in m ? m[k] : null), setItem(k, v) { m[k] = String(v); }, removeItem(k) { delete m[k]; } }; };

for (const [name, dir] of Object.entries(OLD)) {
  const present = fs.existsSync(path.join(dir, 'data', 'hyrox-data.js'));
  const t = present ? test : test.skip;

  t(`${name}: the Phase 9 export (live photo meal) previews and restores on the ${name} data layer, fields intact`, () => {
    const HD = require(path.join(dir, 'data', 'hyrox-data.js'));
    const storage = mem();
    const st = HD.createStore(storage, { now: () => NOW });
    const p = st.previewImport(FIXTURE);
    assert.equal(p.ok, true, JSON.stringify(p.errors || p.message || ''));
    const r = st.applyImport(FIXTURE, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt });
    assert.equal(r.ok, true, JSON.stringify(r));
    const st2 = HD.createStore(storage, { now: () => NOW }); // a fresh store on the same storage, like a page reload
    const meals = st2.records('meals');
    assert.equal(meals.length, 1);
    const src = JSON.parse(FIXTURE).meals[0], got = meals[0];
    assert.equal(got.source, 'PHOTO_AI');
    assert.equal(got.ai.mode, 'REAL');
    assert.equal(got.ai.provider, 'openai');
    assert.equal(got.ai.model, 'gpt-6-luna');
    assert.equal(got.components.length, src.components.length);
    assert.deepEqual(got.components.map((c) => c.kcal), src.components.map((c) => c.kcal));
    assert.equal(got.components[2].kcal.state, 'UNKNOWN'); // the unseen oil stays unknown, never 0
    assert.equal(JSON.stringify(got).includes('imageBase64'), false);
    // and it exports again on the old build
    assert.equal(JSON.parse(st2.exportJSON()).meals.length, 1);
  });

  t(`${name}: the Phase 9 data layer (src/data/*) is byte-identical to ${name}'s where Phase 9 did not touch it`, () => {
    const GARMIN_R_PINS = require('./fixtures/garmin-r-data-pins.json'); // RE-POINTED R1-R8 (24 Nov 2026): changed data files are hash-pinned, not exempted.
    const files = fs.readdirSync(path.join(HERE, 'data')).filter((f) => /\.(js|json)$/.test(f));
    const diff = files.filter((f) => {
      if (GARMIN_R_PINS[f]) { assert.equal(sha(path.join(HERE, 'data', f)), GARMIN_R_PINS[f], f + ' (R1-R8 pin)'); return false; }
      return fs.existsSync(path.join(dir, 'data', f)) && sha(path.join(HERE, 'data', f)) !== sha(path.join(dir, 'data', f));
    });
    if (name === 'p8') assert.deepEqual(diff, [], 'Phase 9 must not change the data layer relative to Phase 8');
    else assert.ok(Array.isArray(diff)); // P7 -> P8 legitimately differs; the restore test above is the contract
  });
}

test('the fixture is synthetic and carries no photo, no owner code and no key', () => {
  assert.equal(/data:image|\/9j\/|imageBase64|hx1-|hx-TEST|sk-/.test(FIXTURE), false);
  assert.equal(JSON.parse(FIXTURE).meals[0].ai.mode, 'REAL');
});
