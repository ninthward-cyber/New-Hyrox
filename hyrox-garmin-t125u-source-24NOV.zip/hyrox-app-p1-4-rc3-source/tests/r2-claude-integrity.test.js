'use strict';
// Round 2 independent review (Claude): regression tests for the repairs made on top of Grok ed7ad84.
// Synthetic data only. Each "REPAIR" block failed on the unmodified ed7ad84 source (see the QA logs).
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const HW = require(path.resolve(__dirname, '../src/data/hyrox-wellness.js'));
const HN = require(path.resolve(__dirname, '../src/data/hyrox-nutrition.js'));
const { HD, KEY, RECOVERY, PRE, mem, mk, O, MISSING, ts, backup, restore } = require('./p8-helpers.js');

const D = '2026-11-17';
const E = (v) => ({ value: v, state: 'ESTIMATED' });
// Puts raw Phase 3 lists straight into storage (as an older build or outside edit would have left them).
function seed(lists, fail) {
  const raw = JSON.stringify(Object.assign({ version: 2, weight: [{ id: 'w1', createdAt: ts, date: D, kg: 80 }], workouts: [], nutrition: [] }, lists));
  const s = mem({ [KEY]: raw }, fail);
  return { s, st: mk(s), raw };
}
const badDaily = (extra) => Object.assign({ id: 'daily-' + D, createdAt: ts, updatedAt: ts, date: D,
  footPain: O(11), stairKneePain: O(1), sleepH: O(7), limp: { state: 'OBSERVED', value: false }, steps: O(8000), soreness: O(2), rhr: O(60) }, extra);
const noWrites = (s, raw) => { assert.equal(s.m[KEY], raw, 'stored text is byte-identical'); assert.equal(s.writes, 0, 'nothing was written'); };

describe('REPAIR P0-1: one out-of-range value no longer hides the whole daily record', () => {
  it('the record is shown with its valid values; only the bad field is marked INVALID; reading writes nothing', () => {
    const { s, st, raw } = seed({ daily: [badDaily()] });
    assert.equal(st.status().state, 'ok');
    const list = st.records('daily');
    assert.equal(list.length, 1);
    const r = list[0];
    assert.deepEqual(r.footPain, { state: 'INVALID', value: null });
    assert.deepEqual(r.sleepH, O(7)); assert.deepEqual(r.stairKneePain, O(1)); assert.deepEqual(r.steps, O(8000));
    assert.deepEqual(r.limp, { state: 'OBSERVED', value: false });
    assert.equal(r._storedDamaged.kind, 'SALVAGED');
    assert.equal(Object.keys(r).includes('_storedDamaged'), false, 'the marker is hidden so it can never be saved by accident');
    assert.equal(JSON.parse(JSON.stringify(r))._storedDamaged, undefined);
    assert.deepEqual(r.invalidOriginal, [{ field: 'footPain', stored: '{"state":"OBSERVED","value":11}', rule: 'must be a number from 0 to 10' }]);
    noWrites(s, raw);
  });

  it('the invalid field is identified exactly: collection, id, date, field, stored value and rule', () => {
    const { s, st, raw } = seed({ daily: [badDaily()] });
    const d = st.damagedRecords();
    assert.equal(d.length, 1);
    assert.deepEqual({ c: d[0].collection, i: d[0].index, id: d[0].id, date: d[0].date, kind: d[0].kind, usable: d[0].usable },
      { c: 'daily', i: 0, id: 'daily-' + D, date: D, kind: 'SALVAGED', usable: true });
    assert.deepEqual(d[0].problems, [{ field: 'footPain', path: 'footPain.value', value: 11, valueType: 'number', rule: 'must be a number from 0 to 10',
      message: 'footPain must be a number from 0 to 10.', legacy: false }]);
    noWrites(s, raw);
  });

  it('invalid pain is UNKNOWN in the 10k gate, named as invalid, and the valid sleep / limp / stair values are used', () => {
    const { st } = seed({ daily: [badDaily()] });
    const g = HW.tenKGate(D, st.records('daily'));
    assert.equal(g.status, 'UNKNOWN'); assert.equal(g.pass, false);
    assert.deepEqual(g.invalid, ['footPain']); assert.deepEqual(g.missing, ['footPain']);
    assert.equal(g.checks.find((c) => c.key === 'sleepH').value, 7);
    assert.equal(g.checks.find((c) => c.key === 'limp').value, false);
    assert.equal(g.checks.find((c) => c.key === 'stairKneePain').value, 1);
    assert.equal(HW.daySteps(D, { dailies: st.records('daily') }).total, 8000, 'the valid daily step total is still used');
  });

  it('every kind of bad pain value is UNKNOWN and never a pass: above 10, negative, text, wrong shape', () => {
    [O(11), O(-1), O('3'), O(null), { state: 'OBSERVED' }, 'two', 7, { state: 'BOGUS', value: 1 }, { state: 'MISSING', value: 4 }].forEach((bad) => {
      ['footPain', 'stairKneePain'].forEach((k) => {
        const rec = badDaily({ footPain: O(1), stairKneePain: O(1) }); rec[k] = bad;
        const { s, st, raw } = seed({ daily: [rec] });
        const list = st.records('daily');
        assert.equal(list.length, 1, k + ' ' + JSON.stringify(bad));
        const g = HW.tenKGate(D, list);
        assert.equal(g.status, 'UNKNOWN', k + ' ' + JSON.stringify(bad));
        assert.notEqual(g.checks.find((c) => c.key === k).result, 'PASS');
        assert.ok(g.invalid.includes(k));
        assert.equal(g.checks.find((c) => c.key === 'sleepH').result, 'PASS');
        noWrites(s, raw);
      });
    });
  });

  it('a real failure on another input still wins over the invalid value (FAIL, not UNKNOWN)', () => {
    const { st } = seed({ daily: [badDaily({ limp: { state: 'OBSERVED', value: true } })] });
    const g = HW.tenKGate(D, st.records('daily'));
    assert.equal(g.status, 'FAIL'); assert.deepEqual(g.failed, ['limp']); assert.deepEqual(g.invalid, ['footPain']);
  });

  it('invalid general pain never reads as "no flags": readiness cannot be confirmed, goals are not pushed, targets are not raised', () => {
    const rec = badDaily({ footPain: O(1), pain: O(14) });
    const { st } = seed({ daily: [rec] });
    const dailies = st.records('daily');
    const set = { rhrBaselineBpm: 76, rhrBaselineSource: 'OWNER_DEFAULT' };
    const r = HW.readiness(D, dailies, set);
    assert.deepEqual(r.flags, []); assert.deepEqual(r.missing, []); assert.deepEqual(r.invalid, ['pain']);
    assert.match(r.guidance, /cannot be confirmed/); assert.doesNotMatch(r.guidance, /^No source readiness flags/);
    assert.match(r.painUnknown, /unknown \(not 0\)/);
    assert.equal(r.painNote, null);
    const gate = HW.tenKGate(D, dailies);
    assert.equal(gate.status, 'PASS', 'the four gate inputs themselves are valid here');
    const ref = HW.stepReferenceGoal(D, { dailies, walks: [], sessions: [], settings: set });
    assert.equal(ref.status, 'DO_NOT_FORCE'); assert.ok(ref.doNotForce.includes('PAIN_INVALID'));
    assert.equal(ref.optional10k.offered, false, 'no optional 10k is offered while pain is unknown');
    const hist = ['2026-11-12', '2026-11-13', '2026-11-14', '2026-11-15', '2026-11-16'].map((x) => ({ id: 'd' + x, date: x, steps: O(8000) }));
    const t = HW.stepTarget(D, { dailies: dailies.concat(hist), walks: [], settings: {}, plannedToday: 0, recentSessions: [] });
    assert.equal(t.target, 8000, 'the light-day raise (8,800) is not applied');
    assert.match(t.reason, /pain value is invalid/); assert.ok(t.recoveryUnknown.includes('pain'));
    // contrast: the same day with a valid pain of 0 does get the normal behaviour (zero is not missing)
    const ok = [Object.assign({}, rec, { pain: O(0) })].concat(hist);
    assert.equal(HW.readiness(D, ok, set).guidance, 'No source readiness flags in the recorded data.');
    assert.equal(HW.stepTarget(D, { dailies: ok, walks: [], settings: {}, plannedToday: 0, recentSessions: [] }).target, 8800);
  });

  it('invalid sleep / soreness / resting HR are missing-and-invalid, never fine', () => {
    const { st } = seed({ daily: [badDaily({ footPain: O(1), sleepH: O(30), soreness: O(-2), rhr: O(900) })] });
    const r = HW.readiness(D, st.records('daily'), { rhrBaselineBpm: 76 });
    assert.deepEqual(r.missing, ['sleep', 'soreness', 'resting HR']);
    assert.deepEqual(r.invalid.sort(), ['rhr', 'sleepH', 'soreness']);
    assert.match(r.guidance, /cannot be confirmed/);
  });

  it('the normal backup keeps the record: bad field marked INVALID, original noted, everything else intact, and it restores', () => {
    const { s, st, raw } = seed({ daily: [badDaily()] });
    assert.deepEqual(st.exportSummary().salvagedExt, { daily: 1 });
    assert.equal(st.exportSummary().omittedExt, undefined);
    const text = st.exportJSON();
    const exp = JSON.parse(text).daily;
    assert.equal(exp.length, 1);
    assert.deepEqual(exp[0].footPain, { state: 'INVALID', value: null });
    assert.deepEqual(exp[0].sleepH, O(7)); assert.deepEqual(exp[0].steps, O(8000));
    assert.equal(exp[0].invalidOriginal[0].stored, '{"state":"OBSERVED","value":11}');
    noWrites(s, raw);
    const s2 = mem(); const st2 = mk(s2);
    assert.equal(restore(st2, text).ok, true);
    const back = st2.records('daily')[0];
    assert.equal(back._storedDamaged, undefined, 'the restored copy is a valid record');
    assert.deepEqual(st2.damagedRecords(), []);
    assert.deepEqual(back.sleepH, O(7));
    assert.equal(HW.tenKGate(D, st2.records('daily')).status, 'UNKNOWN');
    assert.deepEqual(HW.tenKGate(D, st2.records('daily')).invalid, ['footPain']);
    assert.equal(back.invalidOriginal[0].stored, '{"state":"OBSERVED","value":11}', 'the original value is still on record after restore');
  });

  it('the emergency raw copy keeps the exact stored bytes and says the normal backup altered a value', () => {
    const { s, st, raw } = seed({ daily: [badDaily()] });
    const r = st.rawRecoveryExport();
    assert.equal(r.ok, true); assert.equal(r.alteredTotal, 1); assert.deepEqual(r.altered, { daily: 1 });
    assert.match(r.warning, /marks 1 invalid stored value as invalid/); assert.match(r.warning, /NOT a normal backup and cannot be restored/);
    const parsed = HD.parseRawRecovery(r.text);
    assert.equal(parsed.ok, true); assert.equal(parsed.sources[0].raw, raw);
    assert.equal(st.previewImport(r.text).code, 'raw_recovery_file');
    noWrites(s, raw);
  });

  it('a save can no longer silently replace the stored record: it needs the owner\'s approval', () => {
    const { s, st, raw } = seed({ daily: [badDaily()] });
    // what the check-in and the step-override button used to send for that date
    const res = st.putRecord('daily', { id: 'daily-' + D, date: D, sleepH: O(8) });
    assert.equal(res.ok, false); assert.equal(res.code, 'STORED_RECORD_DAMAGED'); assert.match(res.errors.damaged, /approve the correction/);
    noWrites(s, raw);
    assert.equal(st.removeRecord('daily', 'daily-' + D), false);
    noWrites(s, raw);
    const view = JSON.parse(JSON.stringify(st.records('daily')[0]));
    view.footPain = O(2); // the owner's corrected value
    const ok = st.putRecord('daily', view, { approveCorrection: true });
    assert.equal(ok.ok, true);
    assert.deepEqual(st.damagedRecords(), []);
    const now = st.records('daily')[0];
    assert.deepEqual(now.footPain, O(2)); assert.deepEqual(now.sleepH, O(7));
    assert.equal(now.invalidOriginal[0].stored, '{"state":"OBSERVED","value":11}');
    assert.equal(HW.tenKGate(D, st.records('daily')).status, 'PASS');
  });

  it('deleting it also needs approval', () => {
    const { st } = seed({ daily: [badDaily()] });
    assert.equal(st.removeRecord('daily', 'daily-' + D, { approveDamaged: true }), true);
    assert.equal(st.records('daily').length, 0);
  });

  it('a failed restore over such data rolls back to the exact bytes, bad value included', () => {
    const good = mk(mem()); good.putRecord('walks', { date: D, durationMin: 30 });
    const text = good.exportJSON();
    let armed = false;
    const { s, st, raw } = seed({ daily: [badDaily()] }, (k, v) => armed && k === KEY && v !== raw);
    const p = st.previewImport(text);
    assert.equal(p.ok, true);
    armed = true;
    const r = st.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt });
    assert.equal(r.ok, false); assert.equal(r.rolledBack, true);
    assert.equal(s.m[KEY], raw);
    assert.equal(JSON.parse(s.m[PRE]).raw, raw);
    assert.equal(st.records('daily')[0].sleepH.value, 7);
  });

  it('a successful restore over such data keeps the exact previous bytes in the pre-import slot', () => {
    const good = mk(mem()); good.putRecord('walks', { date: D, durationMin: 30 });
    const { s, st, raw } = seed({ daily: [badDaily()] });
    assert.equal(restore(st, good.exportJSON()).ok, true);
    assert.equal(JSON.parse(s.m[PRE]).raw, raw);
  });

  it('entry and restore rules are unchanged: a backup that itself holds pain 11 is still refused with details (owner t54u)', () => {
    const st = mk(mem());
    assert.equal(st.putRecord('daily', { date: D, footPain: O(11), sleepH: O(7) }).ok, false);
    const p = st.previewImport(backup({ daily: [badDaily()] }));
    assert.equal(p.ok, false); assert.equal(p.code, 'invalid_records');
    assert.equal(p.details[0].field, 'footPain.value'); assert.equal(p.details[0].value, 11);
  });

  it('other independent daily fields are handled the same way (limp, steps, override)', () => {
    const { st } = seed({ daily: [badDaily({ footPain: O(1), limp: { state: 'OBSERVED', value: 'no' }, steps: O(10.5), stepTargetOverride: -5 })] });
    const r = st.records('daily')[0];
    assert.deepEqual(r.limp, { state: 'INVALID', value: null }); assert.deepEqual(r.steps, { state: 'INVALID', value: null });
    assert.equal(r.stepTargetOverride, null);
    assert.equal(HW.daySteps(D, { dailies: [r] }).total, null, 'a fractional stored daily total is unknown, not 10.5 and not rounded');
    assert.deepEqual(HW.tenKGate(D, [r]).invalid, ['limp']);
    assert.deepEqual(st.damagedRecords()[0].problems.map((p) => p.field).sort(), ['limp', 'stepTargetOverride', 'steps']);
  });

  it('a record that is broken beyond its independent fields stays hidden, is listed, and is left out of the backup', () => {
    const { s, st, raw } = seed({ daily: [badDaily({ footPain: O(1), notes: 'x'.repeat(600) }), 'junk', { id: 'no-date', createdAt: ts, sleepH: O(7) }] });
    assert.equal(st.records('daily').length, 0);
    const d = st.damagedRecords();
    assert.deepEqual(d.map((x) => x.kind), ['DAMAGED', 'DAMAGED', 'DAMAGED']);
    assert.deepEqual(d.map((x) => x.usable), [false, false, false]);
    assert.equal(d[0].problems[0].field, 'notes');
    assert.deepEqual(st.exportSummary().omittedExt, { daily: 3 });
    assert.equal(JSON.parse(st.exportJSON()).daily.length, 0);
    assert.equal(st.putRecord('daily', { id: 'no-date', date: D, sleepH: O(8) }).code, 'STORED_RECORD_DAMAGED');
    noWrites(s, raw);
  });

  it('damaged classic entries are listed too', () => {
    const raw = JSON.stringify({ version: 1, weight: [{ id: 'w1', createdAt: ts, date: D, kg: 80 }, 'junk', { kg: 81 }], workouts: [], nutrition: [] });
    const st = mk(mem({ [KEY]: raw }));
    assert.deepEqual(st.damagedRecords().map((x) => [x.collection, x.index, x.kind]), [['weight', 1, 'DAMAGED'], ['weight', 2, 'DAMAGED']]);
    assert.deepEqual(mk(mem()).damagedRecords(), []);
  });
});

describe('P0-2 (owner policy ON HOLD - behaviour deliberately unchanged): old CONFIRMED photo meal with no eaten amount', () => {
  const meal = { id: 'm-old', createdAt: ts, updatedAt: ts, date: D, label: 'Plate', source: 'PHOTO_AI', lifecycle: 'CONFIRMED', confirmedAt: ts,
    ai: { mode: 'MOCK', provider: 'mock-fixture', model: 'm' }, components: [{ name: 'Rice', role: 'SIDE', kcal: E(240), proteinG: E(5), carbsG: E(53), fatG: E(1) }] };

  it('is still not counted, not shown and not exported - but is now listed with the exact reason, and is in the raw copy', () => {
    const { s, st, raw } = seed({ meals: [meal] });
    assert.equal(st.records('meals').length, 0, 'policy unchanged: never counted as 100% eaten');
    assert.equal(HN.dayState(D, st.records('meals'), null).subtotal.kcal.value, null);
    assert.deepEqual(st.exportSummary().omittedExt, { meals: 1 });
    assert.equal(JSON.parse(st.exportJSON()).meals.length, 0);
    const d = st.damagedRecords();
    assert.equal(d.length, 1); assert.equal(d[0].kind, 'DAMAGED'); assert.equal(d[0].id, 'm-old');
    assert.equal(d[0].problems[0].field, 'eatenFraction');
    const rr = st.rawRecoveryExport();
    assert.equal(rr.omittedTotal, 1); assert.equal(HD.parseRawRecovery(rr.text).sources[0].raw, raw);
    noWrites(s, raw);
  });
  it('the stored meal can no longer be overwritten or deleted without approval', () => {
    const { s, st, raw } = seed({ meals: [meal] });
    const fixed = Object.assign({}, meal, { eatenFraction: 0.5 });
    assert.equal(st.putRecord('meals', fixed).code, 'STORED_RECORD_DAMAGED');
    assert.equal(st.removeRecord('meals', 'm-old'), false);
    noWrites(s, raw);
    assert.equal(st.putRecord('meals', fixed, { approveCorrection: true }).ok, true);
    assert.equal(HN.mealTotals(st.records('meals')[0]).kcal.value, 120, 'counted only at the amount the owner then states');
  });
  it('a backup holding it is still refused whole, with the record identified (current policy)', () => {
    const p = mk(mem()).previewImport(backup({ meals: [meal] }));
    assert.equal(p.ok, false); assert.equal(p.code, 'invalid_records'); assert.equal(p.details[0].id, 'm-old'); assert.equal(p.details[0].field, 'eatenFraction');
  });
  it('meals written by the Emergent build (numeric amount on every item) are unaffected', () => {
    const ok = Object.assign({}, meal, { components: [Object.assign({ eatenFraction: 1 }, meal.components[0])] });
    const { st } = seed({ meals: [ok] });
    assert.equal(st.records('meals').length, 1); assert.deepEqual(st.damagedRecords(), []);
  });
});

describe('REPAIR P1-4: walk step counts are whole numbers; legacy fractions are kept, flagged and never counted', () => {
  const walk = (o) => Object.assign({ id: 'w-frac', createdAt: ts, updatedAt: ts, date: D, durationMin: 30, steps: 10.5 }, o);

  it('a new fractional walk count is refused and nothing is written', () => {
    const s = mem(); const st = mk(s);
    const r = st.putRecord('walks', { date: D, durationMin: 30, steps: 10.5 });
    assert.equal(r.ok, false); assert.match(r.errors.steps, /whole number/);
    assert.deepEqual(Object.keys(s.m), []);
    assert.equal(st.putRecord('walks', { date: D, durationMin: 30, steps: 10 }).ok, true);
    assert.equal(st.putRecord('walks', { date: D, durationMin: 30, steps: 0 }).ok, true, 'a recorded 0 is a real 0');
    assert.equal(st.putRecord('walks', { date: D, durationMin: 30, steps: null }).ok, true, 'blank stays not recorded');
  });

  it('a stored legacy 10.5 is shown, flagged, kept byte-exact, and is neither counted nor rounded', () => {
    const { s, st, raw } = seed({ walks: [walk()] });
    const w = st.records('walks');
    assert.equal(w.length, 1); assert.equal(w[0].steps, null); assert.equal(w[0].durationMin, 30);
    assert.equal(w[0]._storedDamaged.kind, 'LEGACY');
    assert.equal(w[0].invalidOriginal, undefined, 'a legacy record is not annotated; it is exported as stored');
    const ds = HW.daySteps(D, { walks: w, dailies: [], sessions: [] });
    assert.equal(ds.total, null); assert.equal(ds.walkSteps, null); assert.equal(ds.ignoredInvalid, 1);
    assert.deepEqual(ds.flags, ['INVALID_STEP_COUNT_IGNORED', 'NO_STEP_DATA']);
    const d = st.damagedRecords();
    assert.deepEqual([d[0].collection, d[0].kind, d[0].usable, d[0].problems[0].value, d[0].problems[0].legacy], ['walks', 'LEGACY', true, 10.5, true]);
    noWrites(s, raw);
  });

  it('valid walks on the same day still count; the fraction is left out, not rounded in', () => {
    const { st } = seed({ walks: [walk(), walk({ id: 'w-ok', steps: 3000 })] });
    const ds = HW.daySteps(D, { walks: st.records('walks'), dailies: [], sessions: [] });
    assert.equal(ds.total, 3000); assert.equal(ds.source, 'partial_lower_bound'); assert.equal(ds.ignoredInvalid, 1);
    assert.ok(ds.flags.includes('INVALID_STEP_COUNT_IGNORED'));
  });

  it('the pure step functions ignore any non-whole or out-of-range count, whatever the caller passes', () => {
    [10.5, -3, 300000, NaN, Infinity].forEach((v) => {
      const ds = HW.daySteps(D, { walks: [{ id: 'a', date: D, steps: v }], dailies: [], sessions: [{ id: 's', date: D, status: 'COMPLETED', runSteps: v }] });
      assert.equal(ds.total, null, String(v)); assert.equal(ds.ignoredInvalid, 2, String(v));
    });
    assert.equal(HW.daySteps(D, { walks: [{ id: 'a', date: D, steps: null }], dailies: [], sessions: [] }).ignoredInvalid, 0, 'not recorded is not invalid');
    assert.equal(HW.daySteps(D, { walks: [{ id: 'a', date: D, steps: 0 }], dailies: [], sessions: [] }).total, 0);
  });

  it('the normal backup writes the legacy walk exactly as stored, and reports it', () => {
    const { st } = seed({ walks: [walk()] });
    assert.deepEqual(st.exportSummary().legacyExt, { walks: 1 });
    assert.equal(st.exportSummary().omittedExt, undefined); assert.equal(st.exportSummary().salvagedExt, undefined);
    assert.deepEqual(JSON.parse(st.exportJSON()).walks[0], walk());
  });

  it('restore of an older backup with a fractional walk count is NOT newly refused (owner decision pending): restored exactly, with a warning', () => {
    const s = mem(); const st = mk(s);
    const text = backup({ walks: [walk()] });
    const p = st.previewImport(text);
    assert.equal(p.ok, true);
    assert.ok(p.preview.warnings.some((w) => /1 walk step count is not a whole number/.test(w) && /restored exactly as written and not counted/.test(w)));
    assert.equal(restore(st, text).ok, true);
    assert.equal(JSON.parse(s.m[KEY]).walks[0].steps, 10.5, 'the stored value is exactly what the backup held');
    assert.equal(st.records('walks')[0].steps, null);
    assert.equal(HW.daySteps(D, { walks: st.records('walks'), dailies: [], sessions: [] }).total, null);
  });

  it('the owner corrects it explicitly; nothing is rounded for them', () => {
    const { s, st, raw } = seed({ walks: [walk()] });
    const view = JSON.parse(JSON.stringify(st.records('walks')[0]));
    view.steps = 11;
    assert.equal(st.putRecord('walks', view).code, 'STORED_RECORD_DAMAGED');
    noWrites(s, raw);
    assert.equal(st.putRecord('walks', view, { approveCorrection: true }).ok, true);
    assert.equal(st.records('walks')[0].steps, 11); assert.deepEqual(st.damagedRecords(), []);
  });

  it('daily totals and session running steps keep their existing whole-number rules', () => {
    const st = mk(mem());
    assert.equal(st.putRecord('daily', { date: D, steps: O(10.5) }).ok, false);
    assert.equal(st.putRecord('sessions', { date: D, status: 'COMPLETED', modified: false, variant: 'NONE', blocks: [], runSteps: 10.5, runStepsSource: 'DEVICE' }).ok, false);
    assert.equal(mk(mem()).previewImport(backup({ daily: [{ id: 'd', createdAt: ts, date: D, steps: O(10.5) }] })).ok, false, 'F7 / t54u unchanged');
  });
});

describe('REPAIR P1-5: 10k readiness gate - malformed input is never a pass; zero is not missing', () => {
  const ok = { footPain: 0, limp: false, stairKneePain: 0, sleepH: 7 };
  it('all four recorded and within limits passes; pain 0 is a real 0', () => {
    assert.equal(HW.step10kGate(ok).status, 'PASS');
    assert.equal(HW.step10kGate(Object.assign({}, ok, { footPain: 2, stairKneePain: 2, sleepH: 6 })).status, 'PASS');
  });
  it('a missing input is UNKNOWN, never treated as 0 / fine', () => {
    ['footPain', 'limp', 'stairKneePain', 'sleepH'].forEach((k) => {
      [null, undefined].forEach((v) => {
        const g = HW.step10kGate(Object.assign({}, ok, { [k]: v }));
        assert.equal(g.status, 'UNKNOWN', k); assert.deepEqual(g.missing, [k]); assert.deepEqual(g.invalid, []);
      });
    });
    assert.equal(HW.step10kGate({}).status, 'UNKNOWN');
  });
  it('sleep outside 0-24 hours is invalid/UNKNOWN - it used to PASS (e.g. 99 h)', () => {
    [99, 24.5, -1, NaN, Infinity, '8', true].forEach((v) => {
      const g = HW.step10kGate(Object.assign({}, ok, { sleepH: v }));
      assert.equal(g.status, 'UNKNOWN', String(v)); assert.deepEqual(g.invalid, ['sleepH']);
    });
    assert.equal(HW.step10kGate(Object.assign({}, ok, { sleepH: 24 })).status, 'PASS');
    assert.equal(HW.step10kGate(Object.assign({}, ok, { sleepH: 0 })).status, 'FAIL', 'a recorded 0 h is a real failure, not missing');
  });
  it('pain outside 0-10, or not a number, is invalid/UNKNOWN; limp must be true/false', () => {
    [-1, -0.5, 10.01, 11, NaN, Infinity, '1', true, {}].forEach((v) => {
      ['footPain', 'stairKneePain'].forEach((k) => {
        const g = HW.step10kGate(Object.assign({}, ok, { [k]: v }));
        assert.equal(g.status, 'UNKNOWN', k + ' ' + String(v)); assert.deepEqual(g.invalid, [k]);
      });
    });
    ['no', 0, 1, {}].forEach((v) => {
      const g = HW.step10kGate(Object.assign({}, ok, { limp: v }));
      assert.equal(g.status, 'UNKNOWN'); assert.deepEqual(g.invalid, ['limp']);
    });
  });
  it('an unknown gate never raises a target or offers 10k in Week 4', () => {
    const W4 = '2026-12-08';
    const dailies = [{ id: 'd', date: W4, sleepH: O(8), soreness: O(1), rhr: O(60) }];
    const ref = HW.stepReferenceGoal(W4, { dailies, walks: [], sessions: [], settings: { rhrBaselineBpm: 76 } });
    assert.equal(ref.gate.status, 'UNKNOWN'); assert.equal(ref.status, 'DO_NOT_FORCE'); assert.ok(ref.doNotForce.includes('READINESS_GATE_UNKNOWN'));
    assert.equal(ref.goal, 10000, 'no lower number is invented (open owner decision)');
  });
  it('one resting-HR reading above both baselines is still ONE flag, with both comparisons labelled', () => {
    const hist = ['2026-11-13', '2026-11-14', '2026-11-15', '2026-11-16'].map((x) => ({ id: x, date: x, rhr: O(60) }));
    const r = HW.readiness(D, hist.concat([{ id: 't', date: D, rhr: O(90), sleepH: O(8), soreness: O(1) }]), { rhrBaselineBpm: 76 });
    assert.equal(r.flags.length, 1); assert.equal(r.rhr.flagCount, 1);
    assert.deepEqual(r.rhrFlagBasis, ['OWNER_CONFIGURED', 'OBSERVED_7DAY_MEAN']);
    assert.equal(r.rhr.comparisons.length, 2);
    assert.match(r.guidance, /one flag/);
  });
});

describe('P0-3: emergency raw recovery copy under failure', () => {
  it('a read failure on any key fails the whole copy - never a partial file that looks complete - and writes nothing', () => {
    const raw = JSON.stringify({ version: 2, weight: [], workouts: [], nutrition: [], daily: [badDaily()] });
    const s = mem({ [KEY]: raw, [RECOVERY]: '{"older":"damage"}' });
    const real = s.getItem.bind(s);
    s.getItem = (k) => { if (k === RECOVERY) throw new Error('SecurityError'); return real(k); };
    const r = mk(s).rawRecoveryExport();
    assert.equal(r.ok, false); assert.equal(r.code, 'storage_unreadable'); assert.equal(r.text, undefined);
    assert.equal(s.writes, 0); assert.equal(s.m[KEY], raw);
  });
  it('damaged storage: the normal backup is refused, the raw copy is byte-exact, and it cannot be restored as a backup', () => {
    const raw = '{"version":2,"weight":[],"workouts":[],"nutrition":[],"daily":{"oops":1}}';
    const s = mem({ [KEY]: raw }); const st = mk(s);
    assert.throws(() => st.exportJSON(), /damaged/);
    const r = st.rawRecoveryExport();
    assert.equal(r.ok, true); assert.equal(r.normalExport, 'refused'); assert.equal(r.alteredTotal, null);
    assert.match(r.filename, /^hyrox-RAW-RECOVERY-/); assert.match(r.warning, /NOT a normal backup and cannot be restored/);
    assert.equal(HD.parseRawRecovery(r.text).sources[0].raw, raw);
    const a = st.applyImport(r.text, { confirm: 'REPLACE', expectCurrent: { weight: 0, workouts: 0, nutrition: 0 } });
    assert.equal(a.ok, false); assert.equal(a.code, 'raw_recovery_file');
    assert.equal(s.writes, 0); assert.equal(s.m[KEY], raw);
  });
  it('an edited or truncated raw copy is detected; the checksum is an integrity check only', () => {
    const { st } = seed({ daily: [badDaily()] });
    const text = st.rawRecoveryExport().text;
    assert.equal(HD.parseRawRecovery(text.replace('"value\\":11', '"value\\":10')).code, 'damaged');
    assert.equal(HD.parseRawRecovery(text.slice(0, text.length - 40)).ok, false);
  });
});
