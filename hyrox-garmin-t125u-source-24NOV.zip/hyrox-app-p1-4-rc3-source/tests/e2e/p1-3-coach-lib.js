'use strict';
// Shared SYNTHETIC fixtures for the P1.3 coach specs (Deliveries C and D). No real owner data. Day bases are computed with the
// app's own hyrox-nutrition.js so seeded declarations are current (not stale).
const path = require('path');
const HN = require(path.join(__dirname, '..', '..', 'src', 'data', 'hyrox-nutrition.js'));
const HC = require(path.join(__dirname, '..', '..', 'src', 'data', 'hyrox-coach.js'));
const { expect } = require('@playwright/test');

const K = (v) => ({ value: v, state: 'KNOWN' });
const E = (v) => ({ value: v, state: 'ESTIMATED' });
function meal(id, date, kcal, opts) {
  const o = opts || {};
  return { id, createdAt: date + 'T08:00:00.000Z', date, time: '12:00', label: '', source: 'MANUAL', description: '', eatenFraction: 1,
    lifecycle: 'CONFIRMED', confirmedAt: date + 'T08:05:00.000Z', ai: null, mealCategory: 'LUNCH',
    components: [{ name: 'Synthetic item ' + id, role: 'MAIN', kcal: o.est ? E(kcal) : K(kcal), proteinG: K(o.protein == null ? 150 : o.protein), carbsG: K(200), fatG: K(60) }] };
}
const T0 = '2026-10-01T05:00:00.000Z';
// history({ today, weeks, weighDows, d5Dows, kcal, startKg, kgPerWeek, estDows, extraWeights })
function history(o) {
  const opt = Object.assign({ today: '2026-11-23', weeks: 4, weighDows: [0, 2, 4, 6], d5Dows: [0, 1, 2, 3, 4, 5, 6], kcal: 2300, startKg: 100, kgPerWeek: -0.35, estDows: [], fastDates: [], includeCurrentWeek: false }, o || {});
  const ws = HC.reviewWeeks(opt.today, opt.weeks), from = ws[0].start, to = opt.includeCurrentWeek ? HC.addDays(opt.today, -1) : HC.lastCompletedSunday(opt.today); // re-pointed: Monday-Sunday weeks (independent review C2)
  const meals = [], dayStates = [], weight = [];
  for (let d = from; d <= to; d = HC.addDays(d, 1)) {
    const dw = new Date(d + 'T00:00:00Z').getUTCDay(), t = HC.daysBetween(from, d);
    if (opt.weighDows.includes(dw)) weight.push({ id: 'w-' + d, date: d, kg: Math.round((opt.startKg + opt.kgPerWeek * t / 7) * 10) / 10 /* stored weights have one decimal */, createdAt: d + 'T05:00:00.000Z' });
    if (opt.fastDates.includes(d)) {
      dayStates.push({ id: 'ds-' + d, date: d, createdAt: T0, attestation: 'COMPLETE', fast: 'CONFIRMED_FULL_DAY_FAST', basis: HN.dayBasis([]), attestedAt: d + 'T20:00:00.000Z' });
    } else if (opt.d5Dows.includes(dw)) {
      const m = meal('m-' + d, d, opt.kcal, { est: opt.estDows.includes(dw) });
      meals.push(m);
      dayStates.push({ id: 'ds-' + d, date: d, createdAt: T0, attestation: 'COMPLETE', fast: null, basis: HN.dayBasis([m]), attestedAt: d + 'T20:00:00.000Z' });
    }
  }
  return { meals, dayStates, weight: weight.concat(opt.extraWeights || []) };
}
const PROFILE = { heightCm: 178, heightUnit: 'cm', ageYears: 49, ageEnteredOn: '2026-11-01', ageConfirmedOn: '2026-11-01', estimateMethod: 'EQUATION', sexForEquation: 'MALE', activity: 'A2' };
function settingsWith(coach, extra) {
  return Object.assign({ id: 'app-settings', date: '2026-11-01', createdAt: T0, rhrBaselineBpm: 61, rhrBaselineSource: 'OWNER_SET', stepBaselineMode: 'AUTO', weightUnit: 'kg',
    myFoods: [{ id: 'mf-syn', name: 'Synthetic oats', basis: 'PER_SERVING', servingLabel: '1 bowl', kcal: 150, proteinG: 5, carbsG: 27, fatG: 3, createdAt: T0 }], favFoods: [], planBlocks: [] },
  coach ? { nutritionCoach: coach } : {}, extra || {});
}
function coachObj(more) { return Object.assign({ schema: 1, enabled: true, profile: Object.assign({}, PROFILE), goal: { id: 'LOSE_1', setAt: '2026-11-01' }, target: null, history: [] }, more || {}); }
function seedOf(more) { return Object.assign({ version: 2, weight: [], workouts: [], nutrition: [], meals: [] }, more || {}); }
async function open(page, seed, at) {
  page._errs = []; page.on('pageerror', (e) => page._errs.push(e.message));
  page._net = []; page.on('request', (r) => { if (!/^http:\/\/127\.0\.0\.1:\d+\//.test(r.url())) page._net.push(r.url()); });
  page.on('dialog', (d) => d.accept());
  await page.clock.setFixedTime(new Date(at || '2026-11-23T09:00:00.000Z'));
  await page.goto('./');
  await page.evaluate((s) => { localStorage.clear(); if (s) localStorage.setItem('hyrox.v1', JSON.stringify(s)); }, seed || null);
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
}
const stored = (page) => page.evaluate(() => JSON.parse(localStorage.getItem('hyrox.v1') || '{}'));
const setRec = async (page) => ((await stored(page)).ownerSettings || []).find((r) => r.id === 'app-settings');
// 3 of the 5 plan v2.1 sessions of 16-20 Nov completed, so the "fewer than half of planned sessions" concern does not apply
function planDone() {
  return [['MON', '16'], ['TUE', '17'], ['WED', '18']].map((x) => ({ id: 'p-' + x[0], createdAt: '2026-11-' + x[1] + 'T06:00:00.000Z', date: '2026-11-' + x[1], title: 'Synthetic session',
    status: 'COMPLETED', modified: false, variant: 'ORIGINAL_60', durationMin: 50, rpe: 7, notes: '', blocks: [], planSlotId: 'v2.1-W1-' + x[0], planVersion: 'v2.1', scheduledDate: '2026-11-' + x[1] }));
}
module.exports = { planDone, HN, HC, meal, history, PROFILE, settingsWith, coachObj, seedOf, open, stored, setRec, K, E };
