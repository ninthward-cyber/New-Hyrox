'use strict';
// P1.3 Delivery A (CC execution order 23 Nov 2026, section 3): the existing day closeout controls on Today/Home, directly
// beneath the compact Nutrition section, for the DISPLAYED Asia/Qatar date. Synthetic data only, no network, no paid call.
// CHROME MOBILE EMULATION, NOT SAFARI/WEBKIT and not a physical iPhone.
const { test, expect } = require('@playwright/test');

const NOW = '2026-11-19T09:00:00.000Z'; // 12:00 Asia/Qatar, Thu 19 Nov 2026
const TODAY = '2026-11-19', YDAY = '2026-11-18';
const K = (v) => ({ value: v, state: 'KNOWN' });
const U = () => ({ value: null, state: 'UNKNOWN' });
const meal = (id, date, extra, comp) => Object.assign({ id, createdAt: date + 'T08:00:00.000Z', date, time: '11:00', label: '', source: 'MANUAL', description: '', eatenFraction: 1,
  lifecycle: 'CONFIRMED', confirmedAt: date + 'T08:05:00.000Z', ai: null, mealCategory: 'LUNCH',
  components: [Object.assign({ name: id + ' item', role: 'MAIN', kcal: K(600), proteinG: K(40), carbsG: K(60), fatG: K(20) }, comp || {})] }, extra || {});
const seedOf = (meals, more) => Object.assign({ version: 2, weight: [], workouts: [], nutrition: [], meals }, more || {});
async function open(page, seed, at = NOW) {
  page._errs = []; page.on('pageerror', (e) => page._errs.push(e.message));
  page._net = []; page.on('request', (r) => { if (!/^http:\/\/127\.0\.0\.1:\d+\//.test(r.url())) page._net.push(r.url()); });
  await page.clock.setFixedTime(new Date(at));
  await page.goto('./');
  await page.evaluate((s) => { localStorage.clear(); if (s) localStorage.setItem('hyrox.v1', JSON.stringify(s)); }, seed || null);
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
}
const stored = (page) => page.evaluate(() => JSON.parse(localStorage.getItem('hyrox.v1') || '{}'));

for (const W of [390, 320]) {
  test.describe(`P1.3 Delivery A — Home closeout ${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`${W}: FAIL-FIRST — Home shows ONE set of closeout controls for the displayed Qatar date, directly beneath Nutrition; no Meals card returns`, async ({ page }) => {
      await open(page, seedOf([meal('m1', TODAY)]));
      const home = page.getByTestId('panel-today');
      const nr = page.getByTestId('glance-nutrition');
      const co = nr.getByTestId('today-closeout');
      await expect(co).toBeVisible();
      await expect(co).toHaveAttribute('data-date', TODAY);
      await expect(co.getByTestId('today-closeout-date')).toHaveText('Day closeout · Thu 19 Nov (today)');
      await expect(home.getByTestId('today-attest-complete')).toHaveCount(1);
      await expect(home.getByTestId('today-attest-incomplete')).toHaveCount(1);
      await expect(home.getByTestId('attest-complete')).toHaveCount(0);
      await expect(home.getByTestId('attest-clear')).toHaveCount(0);
      // order inside the Nutrition section: status, macros, Log meal / Photo meal, then the closeout
      const order = await nr.evaluate((el) => Array.from(el.querySelectorAll('[data-testid]')).map((x) => x.getAttribute('data-testid')));
      expect(order.indexOf('glance-nutrition-text')).toBeLessThan(order.indexOf('today-add-meal'));
      expect(order.indexOf('today-photo-meal')).toBeLessThan(order.indexOf('today-closeout'));
      await expect(co.getByTestId('today-closeout-state')).toContainText('Not declared yet');
      await expect(home.getByTestId('meal-diary')).toHaveCount(0);
      await expect(home.getByTestId('today-diary')).toHaveCount(0);
      await expect(home.getByTestId('meal-label')).toHaveCount(0);
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
      expect(page._errs).toEqual([]); expect(page._net).toEqual([]);
    });

    test(`${W}: FAIL-FIRST — "All food & drink entered" on Home declares the displayed date complete through the existing rules; totals unchanged; a second press writes nothing`, async ({ page }) => {
      await open(page, seedOf([meal('m1', TODAY), meal('y1', YDAY)]));
      const before = await page.getByTestId('glance-nutrition-text').textContent();
      expect(before).toBe('Nutrition 600 kcal confirmed so far — not full day.');
      await page.getByTestId('today-attest-complete').click();
      await expect(page.getByTestId('glance-nutrition-text')).toHaveText('Nutrition 600 kcal confirmed — complete day.');
      await expect(page.getByTestId('today-closeout-state')).toContainText('Declared: all food & drink entered — D5 Complete and quantified');
      await expect(page.getByTestId('today-attest-complete')).toHaveAttribute('aria-pressed', 'true');
      let s = await stored(page);
      expect(s.dayStates.length).toBe(1);
      expect(s.dayStates[0].date).toBe(TODAY);
      expect(s.dayStates[0].attestation).toBe('COMPLETE');
      const at = s.dayStates[0].attestedAt;
      // macro grid identical to the confirmed subtotal (no change in underlying totals)
      await expect(page.getByTestId('glance-macros')).toContainText('40 g');
      await page.getByTestId('today-attest-complete').click();
      await expect(page.getByTestId('today-closeout-msg')).toHaveText('Already declared for Thu 19 Nov. Nothing changed.');
      s = await stored(page);
      expect(s.dayStates.length).toBe(1); expect(s.dayStates[0].attestedAt).toBe(at);
      // yesterday was not touched; History shows the same declaration for today and a separate, undeclared yesterday
      await page.getByTestId('tab-history').click();
      const days = page.getByTestId('history-day');
      await expect(days.filter({ hasText: 'Thu 19 Nov' }).getByTestId('history-day-state')).toContainText('D5');
      await expect(days.filter({ hasText: 'Wed 18 Nov' }).getByTestId('history-day-state')).toContainText('D2');
      expect(page._errs).toEqual([]);
    });

    test(`${W}: FAIL-FIRST — an "I ate this" (consumed-intent) meal blocks "complete" with the reason; "Day is incomplete" still works; pending unknown never counted`, async ({ page }) => {
      await open(page, seedOf([meal('m1', TODAY), meal('p1', TODAY, { lifecycle: 'CONSUMED_INTENT', confirmedAt: null })]));
      await expect(page.getByTestId('today-attest-complete')).toBeDisabled();
      await expect(page.getByTestId('today-attest-blocked')).toHaveText('Confirm or discard meals marked "I ate this" first.');
      await page.getByTestId('today-attest-incomplete').click();
      await expect(page.getByTestId('today-closeout-state')).toContainText('Declared: day is incomplete');
      const s = await stored(page);
      expect(s.dayStates.length).toBe(1); expect(s.dayStates[0].attestation).toBe('INCOMPLETE'); expect(s.dayStates[0].fast).toBeNull();
      await expect(page.getByTestId('glance-nutrition-text')).toHaveText('Nutrition 600 kcal confirmed so far — not full day.');
      expect(page._errs).toEqual([]);
    });

    test(`${W}: FAIL-FIRST — an unknown-calorie item makes the declared day D4 (complete, not quantified): never a full-day total or an average`, async ({ page }) => {
      await open(page, seedOf([meal('m1', TODAY), meal('u1', TODAY, {}, { kcal: U() })]));
      await page.getByTestId('today-attest-complete').click();
      await expect(page.getByTestId('today-closeout-state')).toContainText('D4 Complete, not fully quantified');
      await expect(page.getByTestId('glance-nutrition-text')).toHaveText('Nutrition 600+ kcal confirmed so far — not full day.');
      expect(page._errs).toEqual([]);
    });

    test(`${W}: FAIL-FIRST — water-only day: "complete" is refused (fasting question), "Day is incomplete" records "food not logged"; a confirmed fast shows as such`, async ({ page }) => {
      await open(page, seedOf([], { weight: [{ id: 'w0', date: '2026-11-10', kg: 90, createdAt: '2026-11-10T05:00:00.000Z' }] }));
      await page.getByTestId('today-attest-complete').click();
      await expect(page.getByTestId('today-closeout-msg')).toContainText('fasting question');
      expect((await stored(page)).dayStates).toBeUndefined();
      await page.getByTestId('today-attest-incomplete').click();
      await expect(page.getByTestId('today-closeout-state')).toHaveText('Declared: food not logged (calories unknown).');
      expect((await stored(page)).dayStates[0].fast).toBe('NOT_LOGGED');
      expect(page._errs).toEqual([]);
    });

    test(`${W}: FAIL-FIRST — a confirmed fast (true zero) is shown, not reclassified`, async ({ page }) => {
      const ds = { id: 'ds1', date: TODAY, createdAt: TODAY + 'T05:00:00.000Z', attestation: 'COMPLETE', fast: 'CONFIRMED_FULL_DAY_FAST', basis: '0:' + (5381 >>> 0).toString(36), attestedAt: TODAY + 'T05:00:00.000Z' };
      await open(page, seedOf([], { dayStates: [ds] }));
      await expect(page.getByTestId('glance-nutrition-text')).toHaveText('Nutrition: confirmed fast day');
      await expect(page.getByTestId('today-closeout-state')).toHaveText('Declared: intentional full-day fast (0 kcal).');
      await page.getByTestId('today-attest-complete').click();
      await expect(page.getByTestId('today-closeout-msg')).toContainText('fasting question');
      expect((await stored(page)).dayStates).toEqual([ds]);
      expect(page._errs).toEqual([]);
    });

    test(`${W}: FAIL-FIRST — stale date: a Home drawn before Qatar midnight never declares the new day (or the old one) from a stale screen`, async ({ page }) => {
      await open(page, seedOf([meal('m1', YDAY), meal('m2', TODAY)]), '2026-11-18T20:59:30.000Z'); // 23:59:30 Qatar, Wed 18 Nov
      await expect(page.getByTestId('today-closeout')).toHaveAttribute('data-date', YDAY);
      await page.clock.setFixedTime(new Date('2026-11-18T21:00:30.000Z')); // 00:00:30 Thu 19 Nov, screen not redrawn yet
      await page.getByTestId('today-attest-complete').click();
      await expect(page.getByTestId('ext-toast')).toContainText('The date changed at midnight (Asia/Qatar). Home now shows Thu 19 Nov. Nothing was saved.');
      expect((await stored(page)).dayStates).toBeUndefined();
      await expect(page.getByTestId('today-closeout')).toHaveAttribute('data-date', TODAY);
      await expect(page.getByTestId('today-closeout-date')).toHaveText('Day closeout · Thu 19 Nov (today)');
      expect(page._errs).toEqual([]);
    });

    test(`${W}: FAIL-FIRST — resume after midnight (visibility) redraws Home for the new date; the declaration goes to the date shown`, async ({ page }) => {
      await open(page, seedOf([meal('m1', YDAY), meal('m2', TODAY)]), '2026-11-18T20:59:30.000Z');
      await page.clock.setFixedTime(new Date('2026-11-18T21:05:00.000Z'));
      await page.evaluate(() => document.dispatchEvent(new Event('visibilitychange')));
      await expect(page.getByTestId('today-closeout')).toHaveAttribute('data-date', TODAY);
      await page.getByTestId('today-attest-complete').click();
      const s = await stored(page);
      expect(s.dayStates.map((d) => d.date)).toEqual([TODAY]);
      expect(page._errs).toEqual([]);
    });

    test(`${W}: FAIL-FIRST — meals changed in another tab after Home was drawn: the press is refused with a reason and writes nothing`, async ({ page }) => {
      await open(page, seedOf([meal('m1', TODAY)]));
      await page.evaluate((m) => { const s = JSON.parse(localStorage.getItem('hyrox.v1')); s.meals.push(m); localStorage.setItem('hyrox.v1', JSON.stringify(s)); }, meal('other-tab', TODAY));
      await page.getByTestId('today-attest-complete').click();
      await expect(page.getByTestId('today-closeout-msg')).toContainText('changed since this screen was drawn');
      expect((await stored(page)).dayStates).toBeUndefined();
      expect(page._errs).toEqual([]);
    });

    test(`${W}: FAIL-FIRST — a failed save keeps everything as it was and says so`, async ({ page }) => {
      await open(page, seedOf([meal('m1', TODAY)]));
      const before = await page.evaluate(() => localStorage.getItem('hyrox.v1'));
      await page.evaluate(() => { const orig = Storage.prototype.setItem; window.__origSet = orig; Storage.prototype.setItem = function (k, v) { if (k === 'hyrox.v1') { const e = new Error('quota'); e.name = 'QuotaExceededError'; throw e; } return orig.call(this, k, v); }; });
      await page.getByTestId('today-attest-complete').click();
      await expect(page.getByTestId('today-closeout-msg')).toContainText('Not saved');
      await page.evaluate(() => { Storage.prototype.setItem = window.__origSet; });
      expect(await page.evaluate(() => localStorage.getItem('hyrox.v1'))).toBe(before);
      await expect(page.getByTestId('today-closeout-state')).toContainText('Not declared yet');
      expect(page._errs).toEqual([]);
    });

    test(`${W}: FAIL-FIRST — a relevant edit (new meal, delete, backdated copy into today) invalidates the declaration; an unrelated save (steps, weight) does not`, async ({ page }) => {
      await open(page, seedOf([meal('m1', TODAY), meal('y1', YDAY)]));
      await page.getByTestId('today-attest-complete').click();
      await expect(page.getByTestId('today-closeout-state')).toContainText('Declared: all food & drink entered');
      // unrelated: steps for today
      await page.getByTestId('today-log-steps').click();
      await page.getByTestId('qsteps-input').fill('8000');
      await page.getByTestId('qsteps-save').click();
      await expect(page.getByTestId('glance-steps-text')).toContainText('8,000');
      await expect(page.getByTestId('today-closeout-state')).toContainText('Declared: all food & drink entered');
      // a backdated change to YESTERDAY does not touch today's declaration
      await page.getByTestId('tab-history').click();
      const yd = page.getByTestId('history-day').filter({ hasText: 'Wed 18 Nov' });
      await yd.getByTestId('attest-incomplete').click();
      await page.getByTestId('tab-today').click();
      await expect(page.getByTestId('today-closeout-state')).toContainText('Declared: all food & drink entered');
      // relevant: a new consumed-intent draft for today (stored by another path) makes it out of date
      await page.evaluate((m) => { const s = JSON.parse(localStorage.getItem('hyrox.v1')); s.meals.push(m); localStorage.setItem('hyrox.v1', JSON.stringify(s)); window.dispatchEvent(new Event('hyrox:changed')); }, meal('late', TODAY, { lifecycle: 'CONSUMED_INTENT', confirmedAt: null }));
      await expect(page.getByTestId('today-closeout-state')).toHaveText('Your declaration is out of date because a meal changed. Declare again.');
      await expect(page.getByTestId('glance-nutrition-text')).toHaveText('Nutrition 600 kcal confirmed so far — not full day.');
      await expect(page.getByTestId('today-attest-complete')).toBeDisabled();
      expect(page._errs).toEqual([]);
    });

    test(`${W}: FAIL-FIRST — History keeps date-specific closeout (and Clear) for earlier days; Add > Meal diary is unchanged`, async ({ page }) => {
      await open(page, seedOf([meal('y1', YDAY)]));
      await page.getByTestId('tab-history').click();
      const yd = page.getByTestId('history-day').filter({ hasText: 'Wed 18 Nov' });
      await yd.getByTestId('attest-complete').click();
      await expect(yd.getByTestId('history-day-state')).toContainText('D5');
      await expect(yd.getByTestId('attest-clear')).toBeVisible();
      await page.getByTestId('tab-today').click();
      await expect(page.getByTestId('today-closeout')).toHaveAttribute('data-date', TODAY);
      await page.getByTestId('today-add-meal').click();
      await expect(page.getByTestId('meal-diary')).toBeVisible();
      await expect(page.getByTestId('meal-diary').getByTestId('today-attest-complete')).toHaveCount(0);
      expect(page._errs).toEqual([]);
    });

    test(`${W}: FAIL-FIRST — accessibility: labelled group, date in each button's accessible name, 44 px targets, larger text without overflow`, async ({ page }) => {
      await open(page, seedOf([meal('m1', TODAY)]));
      const co = page.getByTestId('today-closeout');
      await expect(co).toHaveAttribute('role', 'group');
      await expect(co).toHaveAttribute('aria-label', 'Day closeout for Thu 19 Nov (today)');
      await expect(page.getByTestId('today-attest-complete')).toHaveAttribute('aria-label', 'All food & drink entered for Thu 19 Nov (today)');
      for (const id of ['today-attest-complete', 'today-attest-incomplete']) {
        const b = await page.getByTestId(id).boundingBox(); expect(b.height).toBeGreaterThanOrEqual(44);
      }
      await page.evaluate(() => { document.documentElement.style.fontSize = '150%'; document.body.style.fontSize = '150%'; });
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
      expect(page._errs).toEqual([]);
    });
  });
}
