'use strict';
// Phase 9: the LIVE photo flow in the browser at 320 and 390 px. The page's /api/food-photo/* calls are answered by the REAL
// server code (netlify/lib/handler.mjs) running in this test process against an in-memory store and a stub OpenAI endpoint.
// No network, no key, synthetic images only. CHROME EMULATION, NOT SAFARI/WEBKIT.
const fs = require('fs');
const path = require('path');
const { test, expect } = require('@playwright/test');
// P0 (22 Nov 2026): "Meal name" is no longer a routine field; the optional custom name sits in a closed fold.
async function nameField(page) { const f = page.getByTestId('meal-label'); if (!(await f.isVisible())) await page.getByTestId('meal-name-toggle').click(); return f; }


const FIX = path.join(__dirname, '..', 'fixtures');
const SHOTS = process.env.P9_SHOTS || '';
let H;
// Playwright's loader cannot import() the server's ES modules, so bundle the harness (and the real handler) to CJS with esbuild first.
test.beforeAll(() => {
  const out = path.join(__dirname, '..', 'out', 'p9-helpers.bundle.cjs');
  // Claude P9 review: find esbuild on any machine (installed package first), not only at the author's path.
  const esbuild = process.env.P9_ESBUILD || (() => { try { return require.resolve('esbuild/bin/esbuild'); } catch (e) { return '/workspace/p9-tools/node_modules/.bin/esbuild'; } })();
  require('child_process').execFileSync(esbuild, [path.join(__dirname, '..', 'p9-helpers.mjs'), '--bundle', '--platform=node', '--format=cjs', '--log-level=error', '--define:import.meta.url=' + JSON.stringify(require('url').pathToFileURL(path.join(__dirname, '..', 'p9-helpers.mjs')).href), '--outfile=' + out]);
  H = require(out);
});

async function installApi(page, opts = {}) {
  const ctx = H.setup({ script: opts.script || (() => H.openaiOk()), env: opts.env || {}, clock: { t: Date.UTC(2026, 10, 16, 6, 0, 0) } });
  const seen = [];
  await page.route('**/api/food-photo/**', async (route) => {
    const r = route.request();
    seen.push({ url: r.url(), method: r.method(), headers: r.headers(), body: r.postData() });
    if (opts.offline) return route.abort('internetdisconnected');
    if (opts.unreachable) return route.abort('connectionrefused');
    const req = new Request(r.url(), { method: r.method(), headers: r.headers(), body: r.method() === 'GET' ? undefined : r.postData() });
    const res = await ctx.handle(req, { ip: '203.0.113.5' });
    await route.fulfill({ status: res.status, headers: Object.fromEntries(res.headers), body: await res.text() });
  });
  return { ctx, seen };
}
async function open(page) {
  await page.clock.setFixedTime(new Date('2026-11-16T06:00:00.000Z'));
  await page.goto('./');
  await page.evaluate(() => localStorage.clear());
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
}
async function chooseLive(page) {
  await page.getByTestId('tab-settings').click();
  await page.getByTestId('ai-provider-live').check();
}
async function saveCode(page, code) {
  await page.getByTestId('ai-owner-code').fill(code);
  await page.getByTestId('ai-owner-code-save').click();
}
async function toPhoto(page, file = 'synthetic-food-exif.jpg') {
  await page.getByTestId('tab-add').click();
  await page.getByTestId('add-mode-meal').click();
  await page.getByTestId('meal-path-photo_ai').click();
  await page.getByTestId('photo-library-input').setInputFiles(path.join(FIX, file));
  await expect(page.getByTestId('photo-preview')).toBeVisible();
}
const meals = (page) => page.evaluate(() => (JSON.parse(localStorage.getItem('hyrox.v1') || '{}').meals) || []);
const noHorizontalScroll = async (page) => expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
const shot = async (page, name) => { if (SHOTS) { fs.mkdirSync(SHOTS, { recursive: true }); await page.screenshot({ path: path.join(SHOTS, name + '.png'), fullPage: true }); } };

for (const W of [390, 320]) {
  test.describe(`P9 live photo ${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`${W}: configured -> enter code -> analyze -> review -> edit -> confirm -> History -> export -> restore`, async ({ page }) => {
      const { ctx, seen } = await installApi(page);
      await open(page);
      await chooseLive(page);
      await shot(page, `p9-settings-live-nocode-${W}`);
      await saveCode(page, H.OWNER_CODE);
      await page.getByTestId('ai-live-check').click();
      await expect(page.getByTestId('ai-live-status')).toContainText('Ready');
      await expect(page.getByTestId('ai-live-status')).toContainText('photos today');
      await expect(page.getByTestId('ai-settings-footnote')).not.toContainText('BLOCKED');
      await toPhoto(page);
      // no engineering paragraph about synthetic-only; live wording only once the server says ready
      await expect(page.getByTestId('photo-live-state')).toHaveCount(0);
      await page.getByTestId('photo-privacy-ack').click();
      await expect(page.getByTestId('photo-box')).not.toContainText('synthetic');
      await expect(page.getByTestId('photo-box')).not.toContainText('not approved');
      const send = page.getByTestId('photo-send');
      await expect(send).toHaveText('Analyze photo');
      await expect(send).toBeDisabled();
      expect(seen.filter((s) => /analyze/.test(s.url)).length).toBe(0); // nothing sent before consent + click
      await page.getByTestId('photo-send-consent').check();
      await shot(page, `p9-photo-ready-${W}`);
      await send.click();
      await expect(page.getByTestId('meal-ai-badge')).toContainText('REAL MODEL ESTIMATE');
      await expect(page.getByTestId('meal-ai-badge')).toContainText('openai / gpt-6-luna');
      await expect(page.getByTestId('component-row')).toHaveCount(3);
      await expect(page.getByTestId('photo-review-note')).toContainText('Review & save');
      // the request really carried bearer + consent, a cleaned JPEG, and nothing identifying
      const a = seen.find((s) => /analyze/.test(s.url));
      expect(a.headers['authorization']).toBe('Bearer ' + H.OWNER_CODE);
      expect(a.headers['x-hyrox-consent']).toBe('send-once');
      const body = JSON.parse(a.body);
      expect(body.consent).toBe(true); expect(body.imageBase64.startsWith('/9j/')).toBe(true);
      const jpg = Buffer.from(body.imageBase64, 'base64');
      for (const s of ['Exif', 'SyntheticCam', 'synthetic fixture comment']) expect(jpg.includes(Buffer.from(s))).toBe(false);
      expect(ctx.fetchStub.calls.length).toBe(1);
      // hidden oil is unknown (null), not 0, and flagged
      await expect(page.getByTestId('component-kcal').nth(2)).toHaveValue('');
      await expect(page.getByTestId('photo-warnings')).toContainText('Hidden oil');
      // totals stay unknown until the eaten amount is stated; edits move the totals; nothing saved yet
      await expect(page.getByTestId('meal-total-kcal')).toContainText('unknown');
      expect((await meals(page)).length).toBe(0);
      await page.getByTestId('meal-eaten-100').click();
      await expect(page.getByTestId('meal-total-kcal')).toContainText('460');
      await page.getByTestId('component-kcal').nth(1).fill('300');
      await expect(page.getByTestId('meal-total-kcal')).toContainText('520');
      await page.getByTestId('component-fatG').nth(2).fill('10'); // owner fills the oil they know about
      await (await nameField(page)).fill('Live test plate');
      await noHorizontalScroll(page);
      await shot(page, `p9-review-${W}`);
      await page.getByTestId('meal-confirm').click();
      await expect(page.getByTestId('ext-toast')).toContainText('Saved on this device');
      const saved = (await meals(page))[0];
      expect(saved.ai.mode).toBe('REAL'); expect(saved.ai.provider).toBe('openai'); expect(saved.ai.userCorrected).toBe(true);
      expect(saved.lifecycle).toBe('CONFIRMED'); expect(saved.source).toBe('PHOTO_AI');
      // no photo, no code in app data
      const hy = await page.evaluate(() => localStorage.getItem('hyrox.v1'));
      expect(/data:image|\/9j\/|base64/i.test(hy)).toBe(false); expect(hy.includes(H.OWNER_CODE)).toBe(false);
      // export contains neither the photo nor the owner code; the file restores
      await page.getByTestId('tab-settings').click();
      const [dl] = await Promise.all([page.waitForEvent('download'), page.getByTestId('export-btn').click()]);
      const exported = fs.readFileSync(await dl.path(), 'utf8');
      expect(exported.includes(H.OWNER_CODE)).toBe(false); expect(/data:image|\/9j\/|"imageBase64"/i.test(exported)).toBe(false);
      expect(JSON.parse(exported).meals[0].ai.provider).toBe('openai');
      if (process.env.P9_EXPORT_OUT && W === 390) fs.writeFileSync(process.env.P9_EXPORT_OUT, exported); // used once to refresh tests/fixtures/p9-live-export.json
      await page.evaluate(() => localStorage.removeItem('hyrox.v1'));
      await page.reload();
      await page.getByTestId('tab-settings').click();
      const bk = test.info().outputPath('p9-backup.json'); fs.writeFileSync(bk, exported);
      await page.getByTestId('import-file').setInputFiles(bk);
      await expect(page.getByTestId('import-confirm')).toBeEnabled();
      await page.getByTestId('import-confirm').click();
      await expect.poll(async () => (await meals(page)).length, { timeout: 8000 }).toBe(1);
      expect((await meals(page))[0].label).toBe('Live test plate');
      // the code survives the restore (separate device-only key) and is still absent from the data
      expect(await page.evaluate(() => localStorage.getItem('hyrox.ai-owner-code'))).toBe(H.OWNER_CODE);
      await page.getByTestId('tab-history').click();
      await expect(page.getByTestId('history-meal').filter({ hasText: 'Live test plate' }).getByTestId('meal-ai-badge')).toContainText('REAL MODEL ESTIMATE');
    });

    test(`${W}: server not configured -> clear message, no send controls, nothing sent, manual entry still works`, async ({ page }) => {
      const { ctx, seen } = await installApi(page, { env: { OPENAI_API_KEY: undefined } });
      await open(page);
      await chooseLive(page); await saveCode(page, H.OWNER_CODE);
      await page.getByTestId('ai-live-check').click();
      await expect(page.getByTestId('ai-live-status')).toContainText('not set up');
      await toPhoto(page);
      await expect(page.getByTestId('photo-live-state')).toHaveAttribute('data-state', 'not_configured');
      await expect(page.getByTestId('photo-live-state')).toContainText('not set up yet');
      await expect(page.getByTestId('photo-send')).toHaveCount(0);
      await expect(page.getByTestId('photo-privacy-ack')).toHaveCount(0);
      await noHorizontalScroll(page);
      await shot(page, `p9-not-configured-${W}`);
      expect(seen.filter((s) => /analyze/.test(s.url)).length).toBe(0); expect(ctx.fetchStub.calls.length).toBe(0);
      // the manual path is still fully available
      await page.getByTestId('meal-path-manual').click();
      // Claude P10b review (owner decision): leaving Photo with a chosen, unanalysed photo asks first (was a silent drop)
      await expect(page.getByTestId('choice-body')).toContainText('photos');
      await page.getByTestId('choice-yes').click();
      await (await nameField(page)).fill('Oats');
      await page.getByTestId('component-name').fill('Oats');
      await page.getByTestId('component-kcal').fill('350');
      await page.getByTestId('meal-consumed-intent').click();
      await page.getByTestId('tab-history').click();
      await expect(page.getByTestId('history-meal').filter({ hasText: 'Oats' })).toHaveCount(1);
    });

    test(`${W}: no code / wrong code -> asks for the code; wrong code is refused by the server and never reaches OpenAI`, async ({ page }) => {
      const { ctx } = await installApi(page);
      await open(page);
      await chooseLive(page);
      await toPhoto(page);
      await expect(page.getByTestId('photo-live-state')).toHaveAttribute('data-state', 'needs_code');
      await expect(page.getByTestId('photo-live-state')).toContainText('owner access code');
      await expect(page.getByTestId('photo-send')).toHaveCount(0);
      await page.getByTestId('tab-settings').click();
      await saveCode(page, 'hx1-this-is-a-wrong-code-but-long-enough');
      await toPhoto(page);
      await expect(page.getByTestId('photo-live-state')).toHaveAttribute('data-state', 'bad_code');
      await expect(page.getByTestId('photo-live-state')).toContainText('missing or wrong');
      await shot(page, `p9-wrong-code-${W}`);
      expect(ctx.fetchStub.calls.length).toBe(0);
    });

    test(`${W}: offline -> compact offline message, nothing sent`, async ({ page, context }) => {
      const { seen } = await installApi(page);
      await open(page);
      await chooseLive(page); await saveCode(page, H.OWNER_CODE);
      await context.setOffline(true);
      await toPhoto(page);
      await expect(page.getByTestId('photo-live-state')).toHaveAttribute('data-state', 'offline');
      await expect(page.getByTestId('photo-live-state')).toContainText('offline');
      await expect(page.getByTestId('photo-send')).toHaveCount(0);
      expect(seen.length).toBe(0);
      await context.setOffline(false);
      await page.getByTestId('photo-live-retry').click();
      await expect(page.getByTestId('photo-privacy-ack')).toBeVisible();
    });

    for (const [name, script, expectText] of [
      ['provider error', () => ({ status: 500, body: { error: { message: 'x' } } }), 'had a problem'],
      ['timeout (server answers 504)', () => 'hang', 'took too long'],
      ['invalid provider JSON', () => H.openaiOk('not json at all'), 'failed safety checks'],
      ['budget exhausted', null, 'budget'],
    ]) test(`${W}: ${name} -> compact message, nothing saved, retry possible`, async ({ page }) => {
      const env = { HYROX_PROVIDER_TIMEOUT_MS: '1000' };
      if (name === 'budget exhausted') env.HYROX_MONTHLY_USD_CAP = '0.01', env.HYROX_RESERVE_USD = '0.02';
      const { ctx } = await installApi(page, { script: script || (() => H.openaiOk()), env });
      await open(page);
      await chooseLive(page); await saveCode(page, H.OWNER_CODE);
      await toPhoto(page);
      await page.getByTestId('photo-privacy-ack').click();
      await page.getByTestId('photo-send-consent').check();
      await page.getByTestId('photo-send').click();
      await expect(page.getByTestId('photo-status')).toContainText(expectText, { timeout: 15000 });
      await expect(page.getByTestId('photo-status')).toContainText('manually');
      expect((await meals(page)).length).toBe(0);
      await expect(page.getByTestId('component-row')).toHaveCount(0); // nothing was filled in from a failed analysis
      await expect(page.getByTestId('photo-send')).toBeVisible(); // retry possible
      await noHorizontalScroll(page);
      await shot(page, `p9-error-${name.replace(/[^a-z]+/gi, '-')}-${W}`);
      if (name === 'budget exhausted') expect(ctx.fetchStub.calls.length).toBe(0);
    });

    test(`${W}: the server never being reachable (blocked network) shows a network message and sends nothing`, async ({ page }) => {
      await installApi(page, { unreachable: true });
      await open(page);
      await chooseLive(page); await saveCode(page, H.OWNER_CODE);
      await toPhoto(page);
      await expect(page.getByTestId('photo-live-state')).toContainText('Could not reach');
      await expect(page.getByTestId('photo-send')).toHaveCount(0);
    });
  });
}

test.describe('P9 photo input handling (390px)', () => {
  test.use({ viewport: { width: 390, height: 844 } });
  test('portrait photo (EXIF orientation 6) is rotated upright by the existing sanitize step; metadata stripped; HEIC without a MIME type is recognised', async ({ page }) => {
    await installApi(page);
    await open(page);
    await chooseLive(page);
    await toPhoto(page, 'p9-portrait-exif6.jpg');
    const dims = await page.getByTestId('photo-preview').evaluate((i) => ({ w: i.naturalWidth, h: i.naturalHeight }));
    expect(dims.h).toBeGreaterThan(dims.w); // stored 480x360 landscape, displayed portrait
    await expect(page.getByTestId('photo-sanitized')).toContainText('Metadata removed');
    await expect(page.getByTestId('photo-sanitized')).toContainText('360×480');
    // a HEIC file the OS hands over with an empty type is accepted by type inference (decode support is the browser's)
    const r = await page.evaluate(() => window.HyroxPhotoAI.validateFile({ name: 'IMG_0001.HEIC', type: '', size: 2000 }));
    expect(r.ok).toBe(true);
    const bad = await page.evaluate(() => window.HyroxPhotoAI.validateFile({ name: 'notes.pdf', type: '', size: 2000 }));
    expect(bad.code).toBe('UNSUPPORTED_TYPE');
  });
});
