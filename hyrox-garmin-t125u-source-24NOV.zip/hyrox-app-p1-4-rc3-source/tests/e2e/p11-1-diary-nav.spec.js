'use strict';
// Phase 11.1 P0: the general Add > Meal form. A CONFIRMED save returns to the Today diary of the meal's own Asia/Qatar date,
// opens that category row (or Uncategorized), marks the saved meal, and moves keyboard/VoiceOver focus to the row.
// History's own Edit / Copy and non-confirmed saves keep returning to History. Synthetic data; photo analysis uses the real
// server handler with a STUBBED OpenAI (no network, no paid call). CHROME MOBILE EMULATION, NOT SAFARI/WEBKIT.
const fs = require('fs');
const path = require('path');
const { test, expect } = require('@playwright/test');
// P0 (22 Nov 2026): the meal diary moved from Today to Add > Meal ("Log meal" on Today opens it). This brings it on screen
// the way the owner does; it does nothing when the diary or a dedicated logger is already showing.
async function diary(page) {
  if (await page.getByTestId('meal-diary').isVisible()) return;
  if (await page.getByTestId('logger-head').isVisible()) return;
  if (!(await page.getByTestId('panel-today').isVisible())) await page.getByTestId('tab-today').click();
  await page.getByTestId('today-add-meal').click();
  await page.getByTestId('meal-diary').waitFor();
}

// P0 (22 Nov 2026): "Meal name" is no longer a routine field; the optional custom name sits in a closed fold.
async function nameField(page) { const f = page.getByTestId('meal-label'); if (!(await f.isVisible())) await page.getByTestId('meal-name-toggle').click(); return f; }


const FIX = path.join(__dirname, '..', 'fixtures');
const F = (n) => path.join(FIX, n);
let H;
test.beforeAll(() => {
  const out = path.join(__dirname, '..', 'out', 'p9-helpers.bundle.cjs');
  const esbuild = process.env.P9_ESBUILD || (() => { try { return require.resolve('esbuild/bin/esbuild'); } catch (e) { return '/workspace/p9-tools/node_modules/.bin/esbuild'; } })();
  require('child_process').execFileSync(esbuild, [path.join(__dirname, '..', 'p9-helpers.mjs'), '--bundle', '--platform=node', '--format=cjs', '--log-level=error', '--define:import.meta.url=' + JSON.stringify(require('url').pathToFileURL(path.join(__dirname, '..', 'p9-helpers.mjs')).href), '--outfile=' + out]);
  H = require(out);
});
async function installApi(page, opts = {}) {
  const ctx = H.setup({ script: opts.script || (() => H.openaiOk()), env: opts.env || {}, clock: { t: Date.UTC(2026, 10, 19, 6, 0, 0) } });
  const seen = [];
  await page.route('**/api/food-photo/**', async (route) => {
    const r = route.request();
    seen.push({ url: r.url(), method: r.method(), body: r.postData() });
    if (opts.delayMs && r.method() === 'POST') await new Promise((res) => setTimeout(res, opts.delayMs));
    const req = new Request(r.url(), { method: r.method(), headers: r.headers(), body: r.method() === 'GET' ? undefined : r.postData() });
    const res = await ctx.handle(req, { ip: '203.0.113.5' });
    try { await route.fulfill({ status: res.status, headers: Object.fromEntries(res.headers), body: await res.text() }); } catch (e) { /* page moved on */ }
  });
  return { ctx, seen };
}
const NOW = '2026-11-19T09:00:00.000Z'; // 12:00 Asia/Qatar, Thu 19 Nov 2026
async function open(page, at = NOW) {
  page._errs = []; page.on('pageerror', (e) => page._errs.push(e.message));
  await page.clock.setFixedTime(new Date(at));
  await page.goto('./');
  await page.evaluate(() => localStorage.clear());
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
}
const noErrors = (page) => expect(page._errs).toEqual([]);
const stored = (page) => page.evaluate(() => JSON.parse(localStorage.getItem('hyrox.v1') || '{}'));
const meals = async (page) => (await stored(page)).meals || [];
const posts = (seen) => seen.filter((s) => s.method === 'POST' && /analyze/.test(s.url)).map((s) => JSON.parse(s.body));
const noPhotoBytes = async (page) => { const raw = (await page.evaluate(() => localStorage.getItem('hyrox.v1'))) || ''; expect(/data:image|imageBase64|\/9j\//.test(raw)).toBe(false); };
const noHScroll = async (page) => expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
async function items(page, label, list) {
  await (await nameField(page)).fill(label);
  for (let i = 0; i < list.length; i++) {
    if (i) await page.getByTestId('meal-add-component').click();
    await page.getByTestId('component-name').nth(i).fill(list[i][0]);
    await page.getByTestId('component-kcal').nth(i).fill(String(list[i][1]));
  }
}
async function logManual(page, cat, label, kcal) {
  await diary(page); await page.getByTestId('diary-log-' + cat).click();
  await expect(page.getByTestId('logger-title')).toHaveText('Log ' + cat);
  await page.getByTestId('meal-path-manual').click();
  await items(page, label, [[label + ' item', kcal]]);
  await page.getByTestId('meal-confirm').click();
  await expect(page.getByTestId('meal-diary')).toBeVisible();
}
async function expectFresh(page, cat) {
  await expect(page.getByTestId('meal-form')).toContainText('Add a meal');
  if (cat) { await expect(page.getByTestId('logger-title')).toHaveText('Log ' + cat); await expect(page.getByTestId('meal-cat-' + cat)).toHaveAttribute('aria-pressed', 'true'); }
  await expect(page.getByTestId('meal-label')).toHaveValue('');
  await expect(page.getByTestId('meal-description')).toHaveValue('');
  await expect(page.getByTestId('photo-preview')).toHaveCount(0);
  await expect(page.getByTestId('photo-send-consent')).toHaveCount(0);
  await expect(page.getByTestId('meal-review-box')).toHaveCount(0);
  await expect(page.getByTestId('meal-error')).toHaveText('');
  const names = await page.getByTestId('component-name').evaluateAll((els) => els.map((e) => e.value));
  expect(names.every((v) => v === '')).toBe(true);
}
const row = (page, cat) => page.getByTestId('diary-row-' + cat);
async function chooseLive(page) {
  await page.getByTestId('tab-settings').click();
  await page.getByTestId('ai-provider-live').check();
  await page.getByTestId('ai-owner-code').fill(H.OWNER_CODE);
  await page.getByTestId('ai-owner-code-save').click();
  await page.getByTestId('tab-today').click();
}


async function addMeal(page) {
  await page.getByTestId('tab-add').click();
  await page.getByTestId('add-mode-meal').click();
  await expect(page.getByTestId('add-modes')).toBeVisible();
  await expect(page.getByTestId('logger-head')).toHaveCount(0);
}
const focused = (page) => page.evaluate(() => document.activeElement && document.activeElement.getAttribute('data-testid'));
// the diary shows the saved record exactly once, marked, in an expanded row that holds focus
async function expectRevealed(page, key, name, dateText) {
  await expect(page.getByTestId('meal-diary')).toBeVisible();
  await expect(page.getByTestId('diary-date')).toContainText(dateText);
  await expect(page.getByTestId('diary-toggle-' + key)).toHaveAttribute('aria-expanded', 'true');
  const hits = page.getByTestId('meal-diary').getByTestId('diary-entry').filter({ hasText: name });
  await expect(hits).toHaveCount(1);
  await expect(hits).toHaveAttribute('data-just-saved', 'true');
  await expect(page.locator('[data-just-saved="true"]')).toHaveCount(1);
  await expect(page.getByTestId('diary-row-' + key).getByTestId('diary-entry').filter({ hasText: name })).toHaveCount(1);
  await expect.poll(() => focused(page)).toBe('diary-toggle-' + key);
  const box = await hits.boundingBox(); const vh = page.viewportSize().height;
  expect(box.y + box.height).toBeGreaterThan(0); expect(box.y).toBeLessThan(vh);
}

for (const W of [390, 320]) {
  test.describe(`P11.1 Add > Meal returns to the diary ${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`${W}: Manual, today, with a category — lands on today's Lunch row, saved once, focused; the next Add is a clean draft with the normal Add choices`, async ({ page }) => {
      await open(page);
      await logManual(page, 'lunch', 'Earlier lunch', 200);
      await addMeal(page);
      await page.getByTestId('meal-path-manual').click();
      await page.getByTestId('meal-cat-lunch').click();
      await items(page, 'Direct lunch', [['rice', 400]]);
      await page.getByTestId('meal-confirm').click();
      await expectRevealed(page, 'lunch', 'Direct lunch', 'Thu 19 Nov · today');
      await expect(page.getByTestId('diary-sub-lunch')).toHaveText('2 entries · 600 kcal');
      await expect(page.getByTestId('diary-total')).toContainText('600 kcal confirmed so far — not a full day');
      await expect(page.getByTestId('tab-add')).toHaveAttribute('aria-selected', 'true'); // P0: the diary is on Add > Meal
      const m = await meals(page);
      expect(m.map((x) => [x.label, x.mealCategory, x.lifecycle])).toEqual([['Earlier lunch', 'LUNCH', 'CONFIRMED'], ['Direct lunch', 'LUNCH', 'CONFIRMED']]);
      await addMeal(page);
      await expectFresh(page);
      for (const c of ['breakfast', 'lunch', 'dinner', 'snacks']) await expect(page.getByTestId('meal-cat-' + c)).toHaveAttribute('aria-pressed', 'false');
      await noHScroll(page);
      noErrors(page);
    });

    test(`${W}: a deliberately backdated meal without a category lands on that past day's Uncategorized row; Today stays today`, async ({ page }) => {
      await open(page);
      await addMeal(page);
      await page.getByTestId('meal-path-manual').click();
      await page.getByTestId('meal-date').fill('2026-11-17');
      await items(page, 'Backdated bowl', [['lentils', 350]]);
      await page.getByTestId('meal-confirm').click();
      await expectRevealed(page, 'uncat', 'Backdated bowl', 'Tue 17 Nov');
      await expect(page.getByTestId('diary-not-today')).toBeVisible();
      await expect(page.getByTestId('today-card')).toContainText('Thu 19 Nov');
      await expect(page.getByTestId('diary-uncat-note')).toBeVisible();
      await diary(page); await page.getByTestId('diary-today').click();
      await expect(page.getByTestId('diary-date')).toContainText('Thu 19 Nov · today');
      await expect(page.getByTestId('diary-total')).toContainText('unknown, not 0');
      expect((await meals(page)).map((x) => [x.date, x.mealCategory])).toEqual([['2026-11-17', undefined]]);
      noErrors(page);
    });

    test(`${W}: Description path (local food estimate) — the auto-saved draft and the confirm are one record, shown once under Breakfast`, async ({ page }) => {
      await open(page);
      await addMeal(page);
      await page.getByTestId('meal-path-description').click();
      await page.getByTestId('meal-cat-breakfast').click();
      await page.getByTestId('meal-description').fill('1 cup milk');
      await page.getByTestId('estimate-run').click();
      await expect(page.getByTestId('estimate-items')).toBeVisible();
      await page.getByTestId('estimate-apply').click();
      await page.getByTestId('meal-confirm').click();
      await expect(page.getByTestId('meal-diary')).toBeVisible();
      await expect(page.getByTestId('diary-toggle-breakfast')).toHaveAttribute('aria-expanded', 'true');
      await expect(page.getByTestId('diary-row-breakfast').getByTestId('diary-entry')).toHaveCount(1);
      await expect(page.locator('[data-just-saved="true"]')).toHaveCount(1);
      await expect.poll(() => focused(page)).toBe('diary-toggle-breakfast');
      const m = await meals(page);
      expect(m).toHaveLength(1);
      expect([m[0].mealCategory, m[0].lifecycle, m[0].source]).toEqual(['BREAKFAST', 'CONFIRMED', 'DESCRIPTION']);
      noErrors(page);
    });

    test(`${W}: Photo path (stubbed provider) — one consented request, lands under Dinner once; the next Add carries no photo, estimate, consent or request id`, async ({ page }) => {
      const { seen } = await installApi(page);
      await open(page);
      await chooseLive(page);
      await addMeal(page);
      await page.getByTestId('meal-path-photo_ai').click();
      await page.getByTestId('meal-cat-dinner').click();
      await page.getByTestId('meal-description').fill('rice and dal');
      await page.getByTestId('photo-library-input').setInputFiles([F('p10-view-a.jpg'), F('p10-view-b.jpg')]);
      await page.getByTestId('photo-privacy-ack').click();
      await page.getByTestId('photo-send-consent').check();
      await page.getByTestId('photo-send').click();
      await expect(page.getByTestId('component-row')).toHaveCount(3);
      // Re-pointed by the P0 sprint photo + note fix (23 Nov 2026): the stubbed model returns chicken/rice/oil, so "dal" from the
      // note is now flagged "not accounted for" and must be acknowledged before Confirm (this test is about the meal lifecycle).
      await expect(page.getByTestId('unaccounted-item')).toHaveCount(1);
      await page.getByTestId('unaccounted-ack').click();
      await page.getByTestId('meal-eaten-100').click();
      await page.getByTestId('meal-confirm').click();
      await expect(page.getByTestId('meal-diary')).toBeVisible();
      await expect(page.getByTestId('diary-row-dinner').getByTestId('diary-entry')).toHaveCount(1);
      await expect(page.locator('[data-just-saved="true"]')).toHaveCount(1);
      await expect.poll(() => focused(page)).toBe('diary-toggle-dinner');
      expect(posts(seen)).toHaveLength(1);
      await addMeal(page);
      await expect(page.getByTestId('meal-path-photo_ai')).toHaveClass(/active/);
      await expectFresh(page);
      await expect(page.getByTestId('photo-preview')).toHaveCount(0);
      expect(posts(seen)).toHaveLength(1);
      expect((await meals(page)).map((x) => [x.mealCategory, x.source, x.lifecycle])).toEqual([['DINNER', 'PHOTO_AI', 'CONFIRMED']]);
      await noPhotoBytes(page);
      noErrors(page);
    });

    test(`${W}: unchanged paths — History Edit / Copy and a Save draft still return to History; a diary Edit returns to the diary; edits keep the one record`, async ({ page }) => {
      await open(page);
      await logManual(page, 'snacks', 'Dates', 120);
      await page.getByTestId('tab-history').click();
      await page.getByTestId('history-meal').filter({ hasText: 'Dates' }).getByTestId('meal-edit').click();
      await page.getByTestId('component-kcal').first().fill('130');
      await page.getByTestId('meal-confirm').click();
      await expect(page.getByTestId('panel-history')).toBeVisible();
      await page.getByTestId('history-meal').filter({ hasText: 'Dates' }).getByTestId('meal-copy').click();
      await (await nameField(page)).fill('Dates again');
      await page.getByTestId('meal-confirm').click();
      await expect(page.getByTestId('panel-history')).toBeVisible();
      await addMeal(page);
      await page.getByTestId('meal-path-manual').click();
      await items(page, 'Draft only', [['soup', 90]]);
      await page.getByTestId('meal-save-draft').click();
      await expect(page.getByTestId('panel-history')).toBeVisible();
      await page.getByTestId('tab-today').click();
      await diary(page);
      if ((await page.getByTestId('diary-toggle-snacks').getAttribute('aria-expanded')) !== 'true') await page.getByTestId('diary-toggle-snacks').click();
      await page.getByTestId('diary-row-snacks').getByTestId('diary-entry').filter({ hasText: 'Dates again' }).getByTestId('diary-entry-edit').click();
      await expect(page.getByTestId('logger-title')).toHaveText('Edit snacks');
      await page.getByTestId('component-kcal').first().fill('140');
      await page.getByTestId('meal-confirm').click();
      await expectRevealed(page, 'snacks', 'Dates again', 'Thu 19 Nov · today');
      const m = await meals(page);
      expect(m.map((x) => [x.label, x.mealCategory || null, x.lifecycle, x.components[0].kcal.value])).toEqual([
        ['Dates', 'SNACKS', 'CONFIRMED', 130], ['Dates again', 'SNACKS', 'CONFIRMED', 140], ['Draft only', null, 'DRAFT', 90]]);
      noErrors(page);
    });

    test(`${W}: a failed save stays on Add > Meal with every input and goes nowhere; the retry saves once and then reveals it`, async ({ page }) => {
      await open(page);
      await addMeal(page);
      await page.getByTestId('meal-path-manual').click();
      await page.getByTestId('meal-cat-snacks').click();
      await items(page, 'Synthetic nuts', [['nuts', 180]]);
      await page.evaluate(() => { const orig = Storage.prototype.setItem; window.__origSet = orig; Storage.prototype.setItem = function (k, v) { if (k === 'hyrox.v1') { const e = new Error('quota'); e.name = 'QuotaExceededError'; throw e; } return orig.call(this, k, v); }; });
      await page.getByTestId('meal-confirm').click();
      await expect(page.getByTestId('meal-error')).toContainText('Not saved');
      await expect(page.getByTestId('panel-add')).toBeVisible();
      await expect(page.getByTestId('meal-label')).toHaveValue('Synthetic nuts');
      await expect(page.getByTestId('meal-cat-snacks')).toHaveAttribute('aria-pressed', 'true');
      expect(await meals(page)).toEqual([]);
      await page.evaluate(() => { Storage.prototype.setItem = window.__origSet; });
      await page.getByTestId('meal-confirm').click();
      await expectRevealed(page, 'snacks', 'Synthetic nuts', 'Thu 19 Nov · today');
      expect(await meals(page)).toHaveLength(1);
      noErrors(page);
    });

    test(`${W}: a late analysis answer for a discarded Add draft never reaches the next meal or the diary; still one request`, async ({ page }) => {
      const { seen } = await installApi(page, { delayMs: 2500 });
      await open(page);
      await chooseLive(page);
      await addMeal(page);
      await page.getByTestId('meal-path-photo_ai').click();
      await page.getByTestId('meal-description').fill('lentil soup');
      await page.getByTestId('photo-library-input').setInputFiles([F('p10-view-a.jpg')]);
      await page.getByTestId('photo-privacy-ack').click();
      await page.getByTestId('photo-send-consent').check();
      await page.getByTestId('photo-send').click();
      await page.getByTestId('meal-discard').click();
      await page.getByTestId('choice-yes').click();
      await page.getByTestId('meal-path-manual').click();
      await items(page, 'Plain toast', [['toast', 150]]);
      await page.waitForTimeout(3200);
      await expect(page.getByTestId('meal-review-box')).toHaveCount(0);
      await expect(page.getByTestId('component-row')).toHaveCount(1);
      await page.getByTestId('meal-confirm').click();
      await expectRevealed(page, 'uncat', 'Plain toast', 'Thu 19 Nov · today');
      await expect(page.getByTestId('diary-sub-uncat')).toHaveText('1 entry · 150 kcal');
      expect(posts(seen)).toHaveLength(1);
      expect((await meals(page)).map((x) => [x.label, x.source, x.components.length])).toEqual([['Plain toast', 'MANUAL', 1]]);
      noErrors(page);
    });

    test(`${W}: Asia/Qatar midnight — a typed Add draft keeps its date with the notice and, once confirmed, is revealed on that (now past) day`, async ({ page }) => {
      await open(page, '2026-11-18T20:58:00.000Z'); // 23:58 Wed 18 Nov
      await addMeal(page);
      await page.getByTestId('meal-path-manual').click();
      await items(page, 'Midnight snack', [['yoghurt', 110]]);
      await page.clock.setFixedTime(new Date('2026-11-18T21:00:30.000Z')); // 00:00:30 Thu 19 Nov
      await page.evaluate(() => document.dispatchEvent(new Event('visibilitychange')));
      await expect(page.getByTestId('meal-draft-date')).toBeVisible();
      await expect(page.getByTestId('meal-date')).toHaveValue('2026-11-18');
      await page.getByTestId('meal-cat-snacks').click();
      await page.getByTestId('meal-confirm').click();
      await expectRevealed(page, 'snacks', 'Midnight snack', 'Wed 18 Nov');
      await expect(page.getByTestId('today-card')).toContainText('Thu 19 Nov');
      await diary(page); await page.getByTestId('diary-next').click();
      await expect(page.getByTestId('diary-date')).toContainText('Thu 19 Nov · today');
      await expect(page.getByTestId('diary-sub-snacks')).toHaveText('Not logged');
      expect((await meals(page)).map((x) => [x.date, x.mealCategory])).toEqual([['2026-11-18', 'SNACKS']]);
      noErrors(page);
    });

    test(`${W}: after an older backup (no categories) is restored, a confirmed Add on that day joins Uncategorized once; old records are untouched`, async ({ page }) => {
      await open(page, '2026-11-10T09:00:00.000Z');
      await page.getByTestId('tab-settings').click();
      await page.getByTestId('import-file').setInputFiles(F('p3-phase3-export.json'));
      await page.getByTestId('import-confirm').click();
      await expect(page.getByTestId('import-result')).toBeVisible();
      await page.reload();
      const before = (await meals(page)).map((m) => JSON.stringify(m));
      await addMeal(page);
      await page.getByTestId('meal-path-manual').click();
      await items(page, 'New tea', [['tea', 40]]);
      await page.getByTestId('meal-confirm').click();
      await expectRevealed(page, 'uncat', 'New tea', 'Tue 10 Nov · today');
      await expect(page.getByTestId('diary-sub-uncat')).toContainText('3 entries');
      const after = await meals(page);
      expect(after).toHaveLength(before.length + 1);
      for (const s of before) expect(after.map((m) => JSON.stringify(m))).toContain(s);
      noErrors(page);
    });
  });
}
