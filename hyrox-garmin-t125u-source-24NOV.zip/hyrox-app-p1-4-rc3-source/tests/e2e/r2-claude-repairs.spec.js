'use strict';
// Round 2 independent review (Claude): user journeys for the repairs made on top of Grok ed7ad84.
// Synthetic data only. Installed Chrome with 390x844 phone emulation - NOT WebKit, NOT iPhone Safari.
const fs = require('fs');
const { test, expect } = require('@playwright/test');
const { openWhy, openFullPlan } = require('./p8-open');

const T = '2026-11-17T06:00:00.000Z';
const NOW = '2026-11-19T06:00:00.000Z'; // Thu 19 Nov 2026, 09:00 Qatar
const D = '2026-11-19';
test.describe.configure({ mode: 'serial' });

async function boot(page, data) {
  await page.clock.setFixedTime(new Date(NOW));
  await page.goto('./');
  await page.evaluate((d) => { localStorage.clear(); if (d) localStorage.setItem('hyrox.v1', typeof d === 'string' ? d : JSON.stringify(d)); }, data || null);
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
  // Phase 8: Today's detail sits under two closed folds; open them so the checks below still read the same elements.
  await openWhy(page); await openFullPlan(page);
}
const rawText = (page) => page.evaluate(() => localStorage.getItem('hyrox.v1'));
const stored = async (page) => JSON.parse(await rawText(page));
const O = (v) => ({ state: 'OBSERVED', value: v });
const base = (extra) => Object.assign({ version: 2, weight: [{ id: 'w1', createdAt: T, date: '2026-11-17', kg: 80 }], workouts: [], nutrition: [] }, extra);
const badDaily = () => ({ id: 'daily-' + D, createdAt: T, updatedAt: T, date: D, footPain: O(11), stairKneePain: O(1), sleepH: O(7),
  limp: { state: 'OBSERVED', value: false }, steps: O(8000), soreness: O(2), rhr: O(60) });
const noOverflow = async (page) => expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);

test('P0-1: an out-of-range stored pain value is named, the rest of the check-in stays in use, and nothing is overwritten without approval', async ({ page }) => {
  await boot(page, base({ daily: [badDaily()] }));
  const before = await rawText(page);

  // Today: valid values used, invalid one named, never a pass
  await openWhy(page);
  await expect(page.getByTestId('today-steps')).toContainText('8,000');
  await expect(page.getByTestId('today-step-gate')).toHaveAttribute('data-gate-status', 'UNKNOWN');
  await expect(page.getByTestId('today-step-gate')).toContainText('7 h');
  await expect(page.getByTestId('today-step-gate-invalid')).toContainText('first-step foot pain');
  await expect(page.getByTestId('today-invalid-values')).toContainText('first-step foot pain: stored 11 (must be a number from 0 to 10)');
  await expect(page.getByTestId('today-invalid-values')).toContainText('Nothing was changed or deleted');
  await noOverflow(page);

  // The step-override button used to silently replace the stored record. Now it is refused.
  await page.getByTestId('step-override').fill('9000');
  await page.getByTestId('step-override-save').click();
  await expect(page.getByTestId('ext-toast')).toContainText('approve the correction');
  expect(await rawText(page)).toBe(before);

  // Settings: listed with exact field, value and rule; raw copy offered
  await page.getByTestId('tab-settings').click();
  const item = page.getByTestId('attention-item');
  await expect(item).toHaveCount(1);
  await expect(item).toHaveAttribute('data-kind', 'SALVAGED');
  await expect(item).toContainText('Check-in · Thu 19 Nov');
  await expect(page.getByTestId('attention-problems')).toHaveText('first-step foot pain: stored 11 (must be a number from 0 to 10)');
  await expect(page.getByTestId('raw-recovery')).toBeVisible();
  await expect(page.getByTestId('raw-recovery-pre')).toContainText('NOT a normal backup and cannot be restored');
  await noOverflow(page);

  // Normal backup keeps the record, marks the value invalid, notes the original
  const [dl] = await Promise.all([page.waitForEvent('download'), page.getByTestId('export-btn').click()]);
  const exp = JSON.parse(fs.readFileSync(await dl.path(), 'utf8'));
  expect(exp.daily.length).toBe(1);
  expect(exp.daily[0].footPain).toEqual({ state: 'INVALID', value: null });
  expect(exp.daily[0].sleepH.value).toBe(7);
  expect(exp.daily[0].invalidOriginal[0].stored).toBe('{"state":"OBSERVED","value":11}');
  await expect(page.getByTestId('export-omitted')).toContainText('1 record was written with an invalid value marked as invalid');

  // Emergency raw copy is byte-exact and labelled
  const [rdl] = await Promise.all([page.waitForEvent('download'), page.getByTestId('raw-recovery-btn').click()]);
  expect(rdl.suggestedFilename()).toMatch(/^hyrox-RAW-RECOVERY-/);
  const rawFile = JSON.parse(fs.readFileSync(await rdl.path(), 'utf8'));
  expect(rawFile.sources[0].raw).toBe(before);
  await expect(page.getByTestId('raw-recovery-warning')).toContainText('cannot be restored with Restore');
  expect(await rawText(page)).toBe(before);

  // Check-in: shows what is wrong; saving needs the tick
  await page.getByTestId('tab-today').click();
  await page.getByTestId('today-invalid-fix').click();
  await expect(page.getByTestId('daily-damaged')).toContainText('first-step foot pain: stored 11');
  await expect(page.getByTestId('daily-footPain')).toHaveValue('');
  await expect(page.getByTestId('daily-footPain-state')).toHaveValue('INVALID');
  await expect(page.getByTestId('daily-sleepH')).toHaveValue('7');
  await page.getByTestId('daily-submit').click();
  await expect(page.getByTestId('daily-error')).toContainText('Nothing was changed');
  expect(await rawText(page)).toBe(before);
  await page.getByTestId('daily-footPain').fill('2');
  await page.getByTestId('daily-approve-correction').check();
  await page.getByTestId('daily-submit').click();
  await expect(page.getByTestId('ext-toast')).toContainText('Saved');
  await expect(page.getByTestId('daily-damaged')).toHaveCount(0);
  const rec = (await stored(page)).daily[0];
  expect(rec.footPain).toEqual(O(2));
  expect(rec.sleepH).toEqual(O(7));
  expect(rec.steps).toEqual(O(8000));
  expect(rec.invalidOriginal[0].stored).toBe('{"state":"OBSERVED","value":11}');

  await page.getByTestId('tab-today').click();
  await expect(page.getByTestId('today-step-gate')).toHaveAttribute('data-gate-status', 'PASS');
  await expect(page.getByTestId('today-invalid-values')).toHaveCount(0);
  await page.getByTestId('tab-settings').click();
  await expect(page.getByTestId('attention-card')).toHaveCount(0);
});

test('P0-1: an invalid general pain value never reads as fine, and the History row and delete warn about it', async ({ page }) => {
  const rec = badDaily(); rec.footPain = O(1); rec.pain = O(14);
  await boot(page, base({ daily: [rec] }));
  const before = await rawText(page);
  await expect(page.getByTestId('readiness-guidance')).toContainText('cannot be confirmed');
  await expect(page.getByTestId('today-pain-unknown')).toContainText('unknown (not 0)');
  await page.getByTestId('tab-history').click();
  await expect(page.getByTestId('history-daily-invalid')).toContainText('pain: stored 14');
  await expect(page.getByTestId('history-daily')).toContainText('sleepH: 7');
  await noOverflow(page);
  // delete asks with a warning; dismissing keeps everything
  let msg = '';
  page.once('dialog', (d) => { msg = d.message(); d.dismiss(); });
  await page.getByTestId('history-daily-delete').click();
  expect(msg).toContain('value that is not valid');
  expect(await rawText(page)).toBe(before);
});

test('P1-4: a legacy fractional walk count is shown, not counted, not rounded, and corrected only by the owner', async ({ page }) => {
  await boot(page, base({ walks: [{ id: 'w-frac', createdAt: T, updatedAt: T, date: D, durationMin: 30, steps: 10.5 }] }));
  const before = await rawText(page);
  await expect(page.getByTestId('today-steps')).toContainText('not recorded (unknown, not 0)');
  await expect(page.getByTestId('steps-invalid-ignored')).toContainText('not counted and not rounded');
  await page.getByTestId('tab-history').click();
  await expect(page.getByTestId('history-walk')).toContainText('Walk 30 min');
  await expect(page.getByTestId('history-walk-invalid')).toContainText('steps: stored 10.5');
  await noOverflow(page);
  await page.getByTestId('walk-fix-steps').fill('10.5');
  await page.getByTestId('walk-fix-save').click();
  await expect(page.getByTestId('walk-fix-error')).toContainText('whole number');
  expect(await rawText(page)).toBe(before);
  await page.getByTestId('walk-fix-steps').fill('11');
  page.once('dialog', (d) => d.accept());
  await page.getByTestId('walk-fix-save').click();
  await expect(page.getByTestId('ext-toast')).toContainText('Saved');
  expect((await stored(page)).walks[0].steps).toBe(11);
  await expect(page.getByTestId('history-walk-invalid')).toHaveCount(0);
  await page.getByTestId('tab-today').click();
  await expect(page.getByTestId('today-steps')).toContainText('at least 11');
  // a new fractional count is refused in the form
  await page.getByTestId('tab-add').click();
  await page.getByTestId('add-mode-walk').click();
  await page.getByTestId('walk-duration').fill('20');
  await page.getByTestId('walk-steps').fill('99.5');
  await page.getByTestId('walk-submit').click();
  await expect(page.getByTestId('walk-error')).toContainText('whole number');
  expect((await stored(page)).walks.length).toBe(1);
});

test('P1-4: restoring an older backup with a fractional walk count warns before anything changes and stores it exactly', async ({ page }) => {
  await boot(page, base({}));
  await page.getByTestId('tab-settings').click();
  const file = JSON.stringify({ app: 'hyrox-app', version: 2, exportedAt: T, weight: [], workouts: [], nutrition: [],
    walks: [{ id: 'w-frac', createdAt: T, updatedAt: T, date: '2026-11-17', durationMin: 30, steps: 10.5 }] });
  await page.getByTestId('import-file').setInputFiles({ name: 'old.json', mimeType: 'application/json', buffer: Buffer.from(file, 'utf8') });
  await expect(page.getByTestId('import-preview')).toBeVisible();
  await expect(page.getByTestId('import-preview-warnings')).toContainText('1 walk step count is not a whole number');
  await expect(page.getByTestId('import-preview-warnings')).toContainText('not counted in any step total until you correct it');
  expect((await stored(page)).walks).toBeUndefined();
});

test('P0-2 (policy on hold): an old confirmed photo meal with no eaten amount is not counted, is listed with the reason, and stays saved', async ({ page }) => {
  const E = (v) => ({ value: v, state: 'ESTIMATED' });
  const meal = { id: 'm-old', createdAt: T, updatedAt: T, date: D, label: 'Plate', source: 'PHOTO_AI', lifecycle: 'CONFIRMED', confirmedAt: T,
    ai: { mode: 'MOCK', provider: 'mock-fixture', model: 'm' }, components: [{ name: 'Rice', role: 'SIDE', kcal: E(240), proteinG: E(5), carbsG: E(53), fatG: E(1) }] };
  await boot(page, base({ meals: [meal] }));
  const before = await rawText(page);
  await expect(page.getByTestId('today-subtotal')).toContainText('Calories unknown'); // Phase 8 label (was 'kcal unknown')
  await page.getByTestId('tab-settings').click();
  await expect(page.getByTestId('attention-item')).toHaveAttribute('data-kind', 'DAMAGED');
  await expect(page.getByTestId('attention-item')).toContainText('Meal · Thu 19 Nov');
  await expect(page.getByTestId('attention-problems')).toContainText('amount eaten');
  await expect(page.getByTestId('attention-item')).toContainText('included in the emergency raw copy');
  const [dl] = await Promise.all([page.waitForEvent('download'), page.getByTestId('export-btn').click()]);
  expect(JSON.parse(fs.readFileSync(await dl.path(), 'utf8')).meals).toEqual([]);
  await expect(page.getByTestId('export-omitted')).toContainText('1 damaged entry was not included');
  expect(await rawText(page)).toBe(before);
});

test('an invalid saved settings record falls back to defaults, says so, and is replaced only with approval', async ({ page }) => {
  await boot(page, base({ ownerSettings: [{ id: 'app-settings', createdAt: T, updatedAt: T, date: '2026-11-17', rhrBaselineBpm: 70, stepLightDayPct: 99 }] }));
  const before = await rawText(page);
  await expect(page.getByTestId('rhr-baseline')).toContainText('configured: 76 bpm (owner default');
  await page.getByTestId('tab-settings').click();
  await expect(page.getByTestId('owner-settings-damaged')).toContainText('stepLightDayPct: stored 99');
  await page.getByTestId('set-rhr-baseline').fill('72');
  await page.getByTestId('set-save').click();
  await expect(page.getByTestId('owner-settings-error')).toContainText('Nothing was changed');
  expect(await rawText(page)).toBe(before);
  await page.getByTestId('set-approve-correction').check();
  await page.getByTestId('set-save').click();
  await expect(page.getByTestId('ext-toast')).toContainText('Saved');
  await expect(page.getByTestId('owner-settings-damaged')).toHaveCount(0);
  expect((await stored(page)).ownerSettings[0].rhrBaselineBpm).toBe(72);
});

test('Today at a glance shows unknown as unknown (never 0), and heart-rate differences are rounded', async ({ page }) => {
  await boot(page, base({}));
  await expect(page.getByTestId('glance-steps')).toContainText('not recorded (unknown)');
  await expect(page.getByTestId('glance-nutrition')).toContainText('nothing confirmed (unknown)');
  await expect(page.getByTestId('glance-readiness')).toContainText('Readiness not checked — log sleep, soreness, resting HR'); // Phase 8 wording (was 'Unconfirmed')
  await expect(page.getByTestId('today-card')).toContainText('Not logged'); // Phase 8: the session tile became the workout card
  // Phase 8: the dashboard also carries the yesterday-fast question ('...stay unknown (not 0)', 'record 0 kcal'), so the
  // no-0 check is applied to the three value tiles and to the glance with that question's text removed.
  for (const id of ['glance-steps', 'glance-readiness', 'glance-nutrition-text']) await expect(page.getByTestId(id)).not.toContainText(/\b0\b/);
  expect((await page.getByTestId('today-glance').innerText()).replace(await page.getByTestId('today-fast-question').innerText(), '')).not.toMatch(/\b0\b/);
  const hist = ['2026-11-15', '2026-11-16', '2026-11-17', '2026-11-18'].map((d, i) => ({ id: 'daily-' + d, createdAt: T, date: d, rhr: O([61, 62, 61, 61][i]) }));
  await boot(page, base({ daily: hist.concat([{ id: 'daily-' + D, createdAt: T, date: D, rhr: O(61), sleepH: O(8), soreness: O(1), steps: O(7200) }]) }));
  await openWhy(page);
  await expect(page.getByTestId('rhr-compare-observed')).toContainText('61.3 bpm');
  await expect(page.getByTestId('rhr-compare-observed')).toContainText(': -0.3 bpm');
  await expect(page.getByTestId('glance-steps')).toContainText('7,200');
  await expect(page.getByTestId('glance-readiness')).toContainText('No flags');
  await noOverflow(page);
  // the navigation bar sits at the bottom on a phone and never covers the last control of a page
  const bar = await page.getByTestId('tabbar').boundingBox();
  // RE-POINTED by Claude QA (24 Nov 2026): "y > 700" assumed an 844 px tall phone and cannot hold at 320 x 568. The intent,
  // "the bar sits at the bottom of the screen", is now measured against the window: lower half, bottom edge on screen.
  const vh = await page.evaluate(() => window.innerHeight);
  expect(bar.y).toBeGreaterThan(vh / 2);
  expect(bar.y + bar.height).toBeLessThanOrEqual(vh + 1);
  await page.getByTestId('tab-settings').click();
  await page.evaluate(() => window.scrollTo(0, document.documentElement.scrollHeight));
  const last = await page.locator('#panel-settings .btn:visible').last().boundingBox();
  expect(last.y + last.height).toBeLessThanOrEqual((await page.getByTestId('tabbar').boundingBox()).y);
});
