'use strict';
// Liya t59u shared helpers: synthetic seeding + in-page layout metrics. Synthetic data only.
const fs = require('fs');
const path = require('path');
const R = process.env.P4_RESULTS || path.join(__dirname, '..', 'out', 'p4-results'); // Claude P5: was /workspace/hyrox-p4/results (not writable on other machines)
const SHOTS = path.join(R, 'liya-shots');
const NOW = '2026-11-12T06:00:00.000Z'; // 09:00 Qatar, Week 1 Thu
const LONG = 'Sled-push-and-pull-intervals-with-a-deliberately-long-unbroken-synthetic-title-' + 'X'.repeat(40);
const LONGID = 'synthetic-id-' + 'q'.repeat(51); // 64 chars, no spaces

function log(file, obj) { fs.mkdirSync(R, { recursive: true }); fs.appendFileSync(path.join(R, file), JSON.stringify(obj) + '\n'); }

async function insets(page, ins) {
  const s = await page.context().newCDPSession(page);
  await s.send('Emulation.setSafeAreaInsetsOverride', { insets: ins });
  return s;
}

async function boot(page, testInfo, opts) {
  opts = opts || {};
  await page.clock.setFixedTime(new Date(opts.now || NOW));
  await insets(page, (testInfo.project.metadata || {}).insets || { top: 0, bottom: 0, left: 0, right: 0 });
  await page.goto('./');
  await page.evaluate(() => localStorage.clear());
  if (opts.seed !== false) {
    const res = await page.evaluate(seedInPage, { LONG, LONGID, T: NOW, attention: opts.attention !== false });
    if (!res.ok) throw new Error('seed failed: ' + JSON.stringify(res));
  }
  await page.reload();
  await page.waitForSelector('[data-testid="tabbar"]');
}

// Runs in the page: valid records through the real data API, then (optionally) raw-inject one stored
// check-in with an invalid independent field (pain 11) + a legacy fractional walk, to show "Records needing attention".
function seedInPage(a) {
  const O = (v) => ({ state: 'OBSERVED', value: v });
  const st = window.HyroxData.createStore();
  const out = [];
  const put = (k, v) => { const r = st.putRecord(k, v); out.push([k, r.ok, r.ok ? '' : JSON.stringify(r.errors)]); };
  ['2026-11-08', '2026-11-09', '2026-11-10', '2026-11-11'].forEach((d, i) => { out.push(['weight', st.addWeight({ date: d, kg: 80.4 - i * 0.3 }).ok]); });
  out.push(['workouts', st.addWorkout({ date: '2026-11-10', activity: a.LONG.slice(0, 60), durationMin: 40, partial: true, notes: a.LONG + ' ' + a.LONG }).ok]);
  out.push(['nutrition', st.addNutrition({ date: '2026-11-11', label: a.LONG.slice(0, 60), calories: 520, proteinG: 31.5 }).ok]);
  ['2026-11-08', '2026-11-09', '2026-11-10', '2026-11-11'].forEach((d, i) => put('daily', { date: d, steps: O(7000 + i * 600), sleepH: O(6.5 + i * 0.2), soreness: O(3), pain: O(1), readiness: O(7), rhr: O(62 + i), notes: 'Synthetic ' + a.LONG }));
  put('walks', { date: '2026-11-11', durationMin: 35, steps: 4200, notes: a.LONG });
  put('sessions', { date: '2026-11-10', title: a.LONG.slice(0, 80), status: 'COMPLETED', modified: false, variant: 'ORIGINAL_60', durationMin: 55, rpe: 7, notes: a.LONG, planSlotId: 'v2.1-W1-TUE', planVersion: 'v2.1', scheduledDate: '2026-11-10',
    blocks: [{ kind: 'run', label: 'Run 1 km', distanceM: 1000, durationSec: 300, sets: null, reps: null, loadKg: null, notes: '' }, { kind: 'strength_set', label: 'Back squat', sets: 3, reps: 5, loadKg: 60, distanceM: null, durationSec: null, notes: a.LONG }] });
  put('meals', { date: '2026-11-11', lifecycle: 'CONFIRMED', confirmedAt: a.T, source: 'MANUAL', label: a.LONG.slice(0, 80), eatenFraction: 1,
    components: [{ name: 'Synthetic oats ' + a.LONG.slice(0, 40), role: 'MAIN', kcal: { value: 350, state: 'KNOWN' }, proteinG: { value: 12, state: 'KNOWN' }, carbsG: { value: 60, state: 'ESTIMATED' }, fatG: { value: null, state: 'UNKNOWN' } }] });
  put('body', { date: '2026-11-11', metric: 'waist_cm', state: 'OBSERVED', value: 88 });
  if (a.attention) {
    const raw = JSON.parse(localStorage.getItem('hyrox.v1'));
    raw.daily.push({ id: a.LONGID, createdAt: a.T, date: '2026-11-07', steps: O(6000), pain: O(11), sleepH: O(7) });
    raw.walks.push({ id: a.LONGID + '-w', createdAt: a.T, date: '2026-11-07', durationMin: 20, steps: 10.5 });
    localStorage.setItem('hyrox.v1', JSON.stringify(raw));
  }
  return { ok: out.every((x) => x[1]), out };
}

// In-page metrics for the currently visible screen.
function metricsInPage(opt) {
  const vw = window.innerWidth, vh = window.innerHeight;
  const nav = document.querySelector('[data-testid="tabbar"]');
  const navR = nav ? nav.getBoundingClientRect() : null;
  const navFixed = nav && getComputedStyle(nav).position === 'fixed';
  function visible(el) {
    if (!el.getClientRects().length) return false;
    const cs = getComputedStyle(el);
    if (cs.visibility === 'hidden' || cs.display === 'none' || +cs.opacity === 0) return false;
    if (el.closest('[hidden]')) return false;
    const r = el.getBoundingClientRect();
    if (r.width <= 1 && r.height <= 1) return false; // visually-hidden
    if (cs.clip === 'rect(0px, 0px, 0px, 0px)' || cs.clipPath === 'inset(50%)') return false;
    return true;
  }
  function name(el) {
    const t = el.getAttribute('data-testid') || el.id || '';
    const txt = (el.innerText || el.value || el.getAttribute('aria-label') || '').trim().replace(/\s+/g, ' ').slice(0, 40);
    return el.tagName.toLowerCase() + (el.type ? '[' + el.type + ']' : '') + (t ? '#' + t : '') + (txt ? ' "' + txt + '"' : '');
  }
  const scope = document.body;
  const all = Array.from(scope.querySelectorAll('*')).filter(visible);
  const sx = window.scrollX;
  const wide = all.filter((el) => { const r = el.getBoundingClientRect(); return r.right + sx > vw + 1 || r.left + sx < -1; })
    .filter((el) => !Array.from(el.children).some((c) => visible(c) && (c.getBoundingClientRect().right > vw + 1)))
    .slice(0, 15).map((el) => { const r = el.getBoundingClientRect(); return name(el) + ' L' + Math.round(r.left) + ' R' + Math.round(r.right); });
  const fields = all.filter((el) => el.matches('input:not([type=hidden]):not([type=checkbox]):not([type=radio]):not([type=file]):not([type=range]), select, textarea'));
  const smallFont = fields.filter((el) => parseFloat(getComputedStyle(el).fontSize) < 16).map((el) => name(el) + ' ' + getComputedStyle(el).fontSize);
  const targets = all.filter((el) => el.matches('button, a[href], select, input:not([type=hidden]), textarea, summary, label.btn, [role=tab]'))
    .filter((el) => !(el.matches('input[type=file]') && el.getBoundingClientRect().width <= 1));
  const small = [];
  targets.forEach((el) => {
    let box = el;
    if (el.matches('input[type=checkbox], input[type=radio]')) box = el.closest('label') || el;
    const r = box.getBoundingClientRect();
    const isText = el.matches('input:not([type=checkbox]):not([type=radio]):not([type=button]):not([type=submit]), select, textarea');
    const inline = el.matches('a[href]') && getComputedStyle(el).display === 'inline';
    if (r.height < 44 - 0.5 || (!isText && r.width < 44 - 0.5)) small.push(name(el) + ' ' + Math.round(r.width) + 'x' + Math.round(r.height) + (inline ? ' (inline link)' : ''));
  });
  return { vw, vh, scrollW: document.documentElement.scrollWidth, clientW: document.documentElement.clientWidth, bodyScrollW: document.body.scrollWidth,
    pageH: document.documentElement.scrollHeight, navTop: navR ? Math.round(navR.top) : null, navBottomGap: navR ? Math.round(vh - navR.bottom) : null, navH: navR ? Math.round(navR.height) : null, navFixed,
    wide, smallFont: Array.from(new Set(smallFont)), smallTargets: Array.from(new Set(small)).slice(0, 40), smallTargetCount: new Set(small).size };
}

// Every visible control in the visible panel: scroll it to the centre and check it is not under the fixed nav;
// then at maximum scroll check the last control clears the nav.
function coverInPage() {
  const nav = document.querySelector('[data-testid="tabbar"]');
  if (!nav || getComputedStyle(nav).position !== 'fixed') return { navFixed: false };
  const panel = Array.from(document.querySelectorAll('.panel')).find((p) => !p.hidden) || document.body;
  const ctr = Array.from(panel.querySelectorAll('button, a[href], select, input:not([type=hidden]), textarea, summary, label.btn'))
    .filter((el) => el.getClientRects().length && !el.closest('[hidden]') && el.getBoundingClientRect().width > 1);
  const covered = [];
  ctr.forEach((el) => {
    el.scrollIntoView({ block: 'center' });
    const r = el.getBoundingClientRect(), n = nav.getBoundingClientRect();
    if (r.bottom > n.top + 0.5 && r.top < n.bottom) covered.push((el.getAttribute('data-testid') || el.tagName) + ' at centre-scroll');
  });
  window.scrollTo(0, document.documentElement.scrollHeight);
  const last = ctr[ctr.length - 1];
  const lr = last ? last.getBoundingClientRect() : null, nr = nav.getBoundingClientRect();
  const lastPage = Array.from(panel.querySelectorAll('*')).filter((el) => el.getClientRects().length && !el.closest('[hidden]')).reduce((m, el) => Math.max(m, el.getBoundingClientRect().bottom), 0);
  return { navFixed: true, controls: ctr.length, covered, lastControl: last ? (last.getAttribute('data-testid') || last.tagName) : null,
    lastControlBottom: lr ? Math.round(lr.bottom) : null, navTop: Math.round(nr.top), gapLastControlToNav: lr ? Math.round(nr.top - lr.bottom) : null,
    gapLastContentToNav: Math.round(nr.top - lastPage) };
}

async function shot(page, name, full) {
  const p = path.join(SHOTS, name + '.png');
  await page.screenshot({ path: p, fullPage: full !== false });
  return p;
}

module.exports = { R, SHOTS, NOW, LONG, LONGID, log, insets, boot, metricsInPage, coverInPage, shot, seedInPage };
