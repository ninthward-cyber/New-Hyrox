'use strict';
// P0 (owner decision 22 Nov 2026): one meal surface on Today; the diary lives on Add > Meal; no routine "Meal name";
// explicit Uncategorized; Settings build label; quiet backup reminder. Synthetic data only, no network, no paid call.
// CHROME MOBILE EMULATION, NOT SAFARI/WEBKIT and not a physical iPhone.
const { test, expect } = require('@playwright/test');

const NOW = '2026-11-19T09:00:00.000Z'; // 12:00 Asia/Qatar, Thu 19 Nov 2026
const U = () => ({ value: null, state: 'UNKNOWN' });
const meal = (id, date, extra) => Object.assign({ id, createdAt: date + 'T08:00:00.000Z', date, time: '11:00', label: '', source: 'MANUAL', description: '', eatenFraction: 1,
  lifecycle: 'CONFIRMED', confirmedAt: date + 'T08:05:00.000Z', ai: null,
  components: [{ name: id + ' item', role: 'MAIN', kcal: { value: 300, state: 'KNOWN' }, proteinG: U(), carbsG: U(), fatG: U() }] }, extra || {});
async function open(page, seed, at = NOW, extraKeys) {
  page._errs = []; page.on('pageerror', (e) => page._errs.push(e.message));
  await page.clock.setFixedTime(new Date(at));
  await page.goto('./');
  await page.evaluate(([s, x]) => { localStorage.clear(); if (s) localStorage.setItem('hyrox.v1', JSON.stringify(s)); Object.keys(x || {}).forEach((k) => localStorage.setItem(k, x[k])); }, [seed || null, extraKeys || null]);
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
}
const seedOf = (meals) => ({ version: 2, weight: [], workouts: [], nutrition: [], meals });
const stored = (page) => page.evaluate(() => JSON.parse(localStorage.getItem('hyrox.v1') || '{}'));
const raw = (page) => page.evaluate(() => localStorage.getItem('hyrox.v1'));
async function fillItem(page, name, kcal) {
  await page.getByTestId('component-name').first().fill(name);
  await page.getByTestId('component-kcal').first().fill(String(kcal));
}

for (const W of [390, 320]) {
  test.describe(`P0 Home + diary + meal name ${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`${W}: Today has exactly one meal surface — truthful Nutrition status, Log meal, Photo meal — and no diary card`, async ({ page }) => {
      await open(page);
      const today = page.getByTestId('panel-today');
      await expect(page.getByTestId('glance-nutrition-text')).toHaveText('Nutrition: nothing confirmed (unknown)');
      await expect(today.getByTestId('today-add-meal')).toHaveText('Log meal');
      await expect(today.getByTestId('today-photo-meal')).toHaveText('Photo meal');
      await expect(today.getByTestId('meal-diary')).toHaveCount(0);
      await expect(today.getByTestId('today-diary')).toHaveCount(0);
      await expect(today.locator('[data-testid^="diary-row-"]')).toHaveCount(0);
      await expect(today.getByText('Breakfast', { exact: true })).toHaveCount(0);
      // the rest of Home is still there
      for (const id of ['today-log-steps', 'glance-exercise', 'glance-weight', 'today-why-toggle']) await expect(page.getByTestId(id)).toBeVisible();
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
      expect(page._errs).toEqual([]);
    });

    test(`${W}: Log meal opens the diary on Add > Meal (date, four categories, Uncategorized when used); a category opens its logger; Back returns to the diary`, async ({ page }) => {
      await open(page, seedOf([meal('old1', '2026-11-19')]));
      await page.getByTestId('today-add-meal').click();
      await expect(page.getByTestId('panel-add')).toBeVisible();
      await expect(page.getByTestId('panel-today')).toBeHidden();
      const diary = page.getByTestId('meal-diary');
      await expect(diary).toBeVisible();
      await expect(page.getByTestId('diary-heading')).toBeFocused();
      await expect(page.getByTestId('diary-date')).toContainText('today');
      for (const c of ['breakfast', 'lunch', 'dinner', 'snacks']) await expect(page.getByTestId('diary-log-' + c)).toBeVisible();
      await expect(page.getByTestId('diary-row-uncat')).toContainText('1 entry');
      await page.getByTestId('diary-log-lunch').click();
      await expect(page.getByTestId('logger-title')).toHaveText('Log lunch');
      await expect(page.getByTestId('meal-diary')).toHaveCount(0);
      await page.getByTestId('logger-back').click();
      await expect(page.getByTestId('meal-diary')).toBeVisible();
      await expect(page.getByTestId('panel-add')).toBeVisible();
      expect(page._errs).toEqual([]);
    });

    test(`${W}: no routine Meal name on any path; a manual lunch saves with no name, returns to the dated diary, and is listed exactly once`, async ({ page }) => {
      await open(page);
      await page.getByTestId('today-add-meal').click();
      await page.getByTestId('diary-log-lunch').click();
      for (const p of ['manual', 'description', 'photo_ai']) {
        await page.getByTestId('meal-path-' + p).click();
        await expect(page.getByTestId('meal-form').getByText('Meal name', { exact: true })).toHaveCount(0);
        await expect(page.getByTestId('meal-label')).toBeHidden();
        await expect(page.getByTestId('meal-name-fold')).not.toHaveAttribute('open', '');
      }
      await page.getByTestId('meal-path-manual').click();
      await fillItem(page, 'Rice bowl', 520);
      await page.getByTestId('meal-confirm').click();
      await expect(page.getByTestId('panel-add')).toBeVisible();
      await expect(page.getByTestId('meal-diary')).toBeVisible();
      await expect(page.getByTestId('diary-row-lunch').getByTestId('diary-entry')).toHaveCount(1);
      await expect(page.getByTestId('meal-diary').getByTestId('diary-entry')).toHaveCount(1);
      await expect(page.getByTestId('diary-row-lunch').getByTestId('diary-entry')).toContainText('Rice bowl');
      const d = await stored(page);
      expect(d.meals.length).toBe(1);
      expect(d.meals[0].mealCategory).toBe('LUNCH');
      expect(d.meals[0].label).toBe(''); // nothing derived from the category is written
      expect(d.version).toBe(2);
      // the form under the diary is a fresh, empty entry
      await expect(page.getByTestId('component-name').first()).toHaveValue('');
      // Today shows the confirmed subtotal once
      await page.getByTestId('tab-today').click();
      await expect(page.getByTestId('glance-nutrition-text')).toContainText('520');
      // History titles the unnamed meal by its diary meal
      await page.getByTestId('tab-history').click();
      await expect(page.getByTestId('panel-history')).toContainText('Lunch');
      expect(page._errs).toEqual([]);
    });

    test(`${W}: Photo meal is a direct path with the four categories plus an explicit Uncategorized, which stores no category`, async ({ page }) => {
      await open(page);
      await page.getByTestId('today-photo-meal').click();
      await expect(page.getByTestId('logger-title')).toHaveText('Log a meal');
      await expect(page.getByTestId('meal-path-photo_ai')).toHaveClass(/active/);
      for (const c of ['breakfast', 'lunch', 'dinner', 'snacks', 'none']) await expect(page.getByTestId('meal-cat-' + c)).toBeVisible();
      await page.getByTestId('meal-cat-dinner').click();
      await expect(page.getByTestId('meal-cat-dinner')).toHaveAttribute('aria-pressed', 'true');
      await page.getByTestId('meal-cat-none').click();
      await expect(page.getByTestId('meal-cat-none')).toHaveAttribute('aria-pressed', 'true');
      await expect(page.getByTestId('meal-cat-dinner')).toHaveAttribute('aria-pressed', 'false');
      await page.getByTestId('meal-path-manual').click();
      // the path switch keeps "no category"
      await fillItem(page, 'Dates', 60);
      await page.getByTestId('meal-confirm').click();
      const d = await stored(page);
      expect(d.meals.length).toBe(1);
      expect(Object.prototype.hasOwnProperty.call(d.meals[0], 'mealCategory')).toBe(false);
      await expect(page.getByTestId('diary-row-uncat').getByTestId('diary-entry')).toHaveCount(1);
      // the diary's own Photo meal shortcut opens the photo logger for the diary's date
      await page.getByTestId('diary-prev').click();
      await page.getByTestId('diary-photo').click();
      await expect(page.getByTestId('meal-path-photo_ai')).toHaveClass(/active/);
      await expect(page.getByTestId('logger-date')).toContainText('18 Nov');
      await expect(page.getByTestId('logger-not-today')).toBeVisible();
      expect(page._errs).toEqual([]);
    });

    test(`${W}: a backdated meal returns to that day's diary; existing custom names, uncategorised and unrecognised meals are shown and kept byte for byte`, async ({ page }) => {
      const seed = seedOf([
        meal('named', '2026-11-18', { label: 'Team lunch', mealCategory: 'LUNCH' }),
        meal('plain', '2026-11-18'),
        meal('odd', '2026-11-18', { mealCategory: 'BRUNCH', label: 'Late one' }),
      ]);
      await open(page, seed);
      const before = await raw(page);
      await page.getByTestId('today-add-meal').click();
      await page.getByTestId('diary-prev').click();
      await expect(page.getByTestId('diary-date')).toContainText('18 Nov');
      await page.getByTestId('diary-view-all').click();
      await expect(page.getByTestId('diary-row-lunch')).toContainText('Team lunch');
      await expect(page.getByTestId('diary-row-uncat').getByTestId('diary-entry')).toHaveCount(2);
      // History: custom names as they are; no category invented for the others
      await page.getByTestId('tab-history').click();
      const hist = page.getByTestId('panel-history');
      await expect(hist).toContainText('Team lunch');
      await expect(hist).toContainText('Late one');
      expect(await raw(page)).toBe(before); // viewing changed nothing
      // edit the named meal: its name is shown in the opened fold and survives an unrelated edit
      await page.getByTestId('tab-add').click();
      await page.getByTestId('diary-row-lunch').getByTestId('diary-entry-edit').click();
      await expect(page.getByTestId('meal-name-fold')).toHaveAttribute('open', '');
      await expect(page.getByTestId('meal-label')).toHaveValue('Team lunch');
      await page.getByTestId('component-kcal').first().fill('410');
      await page.getByTestId('meal-confirm').click();
      let d = await stored(page);
      expect(d.meals.find((m) => m.id === 'named').label).toBe('Team lunch');
      expect(d.meals.find((m) => m.id === 'odd').mealCategory).toBe('BRUNCH');
      expect(Object.prototype.hasOwnProperty.call(d.meals.find((m) => m.id === 'plain'), 'mealCategory')).toBe(false);
      // backdated new dinner on the 18th
      await expect(page.getByTestId('diary-date')).toContainText('18 Nov');
      await page.getByTestId('diary-log-dinner').click();
      await expect(page.getByTestId('logger-date')).toContainText('18 Nov');
      await page.getByTestId('meal-path-manual').click();
      await fillItem(page, 'Soup', 210);
      await page.getByTestId('meal-confirm').click();
      await expect(page.getByTestId('diary-date')).toContainText('18 Nov');
      await expect(page.getByTestId('diary-row-dinner').getByTestId('diary-entry')).toHaveCount(1);
      d = await stored(page);
      expect(d.meals.filter((m) => m.date === '2026-11-18').length).toBe(4);
      expect(d.meals.filter((m) => m.mealCategory === 'DINNER').length).toBe(1);
      // Today (the 19th) still has nothing confirmed
      await page.getByTestId('tab-today').click();
      await expect(page.getByTestId('glance-nutrition-text')).toHaveText('Nutrition: nothing confirmed (unknown)');
      expect(page._errs).toEqual([]);
    });

    test(`${W}: an optional custom name can still be typed and is stored exactly; leaving it closed stores none`, async ({ page }) => {
      await open(page);
      await page.getByTestId('today-add-meal').click();
      await page.getByTestId('diary-log-snacks').click();
      await page.getByTestId('meal-path-manual').click();
      await page.getByTestId('meal-name-toggle').click();
      await page.getByTestId('meal-label').fill('Post-run snack');
      await fillItem(page, 'Banana', 105);
      await page.getByTestId('meal-confirm').click();
      const d = await stored(page);
      expect(d.meals[0].label).toBe('Post-run snack');
      await expect(page.getByTestId('diary-row-snacks')).toContainText('Post-run snack');
      // the next entry starts with the fold closed and empty
      await page.getByTestId('diary-log-snacks').click();
      await expect(page.getByTestId('meal-name-fold')).not.toHaveAttribute('open', '');
      expect(page._errs).toEqual([]);
    });

    test(`${W}: Settings shows an honest build label; the source tree says "Development copy" and never names a release as live`, async ({ page }) => {
      await open(page);
      await page.getByTestId('tab-settings').click();
      const label = page.getByTestId('build-label');
      await expect(label).toBeVisible();
      await expect(label).toContainText('Development copy');
      await expect(label).toContainText(await page.evaluate(() => document.querySelector('meta[name="hyrox-release"]').content)); // the release this tree names (P0-RC3 when written; later increments rename it)
      expect(await page.evaluate(() => document.querySelector('meta[name="hyrox-release"]').content)).toMatch(/^(P0-RC3|P1\.[1-4]-RC\d+)$/);
      await expect(page.getByTestId('build-note')).toContainText('does not check whether a newer build exists');
      await expect(page.getByTestId('build-card')).not.toContainText(/latest|up to date|live/i);
    });

    test(`${W}: backup reminder — unknown until an export; after Export it records a started download, never a saved backup; the export file is unchanged`, async ({ page }) => {
      await open(page, seedOf([meal('m1', '2026-11-19')]));
      await page.getByTestId('tab-settings').click();
      const note = page.getByTestId('backup-last');
      await expect(note).toContainText('no record (unknown)');
      await expect(note).toHaveAttribute('data-state', 'unknown');
      const before = await raw(page);
      const [dl] = await Promise.all([page.waitForEvent('download'), page.getByTestId('export-btn').click()]);
      expect(dl.suggestedFilename()).toBe('hyrox-backup-2026-11-19.json');
      const text = require('fs').readFileSync(await dl.path(), 'utf8');
      const parsed = JSON.parse(text);
      expect(parsed.app).toBe('hyrox-app');
      expect(Object.keys(parsed).sort()).toEqual(['app', 'exportedAt', 'meals', 'nutrition', 'version', 'weight', 'workouts']);
      expect(text).not.toContain('backup-note');
      await expect(note).toHaveAttribute('data-state', 'recorded');
      await expect(note).toContainText('19 Nov 2026');
      await expect(note).toContainText('today');
      await expect(note).toContainText('hyrox-backup-2026-11-19.json');
      await expect(note).toContainText('cannot check that the file was kept');
      await expect(note).not.toContainText(/saved to|backed up|uploaded|verified/i);
      expect(await raw(page)).toBe(before); // records untouched
      const keys = await page.evaluate(() => Object.keys(localStorage).sort());
      expect(keys).toEqual(['hyrox.backup-note', 'hyrox.v1']);
    });

    test(`${W}: the quiet Today line appears only when records exist and no download was started in the last 7 days; a damaged note reads as unknown`, async ({ page }) => {
      // fresh device, no records: nothing
      await open(page);
      await expect(page.getByTestId('today-backup-note')).toHaveCount(0);
      // records only from today: nothing yet
      await open(page, seedOf([meal('m1', '2026-11-19')]));
      await expect(page.getByTestId('today-backup-note')).toHaveCount(0);
      // records 8 days old, no note: shown, worded as "no record", not "no backup"
      await open(page, seedOf([meal('m1', '2026-11-11')]));
      await expect(page.getByTestId('today-backup-note')).toContainText('No backup download is recorded on this device.');
      // a note from 3 days ago: quiet
      await open(page, seedOf([meal('m1', '2026-11-11')]), NOW, { 'hyrox.backup-note': JSON.stringify({ v: 1, at: '2026-11-16T09:00:00.000Z', file: 'hyrox-backup-2026-11-16.json', restorable: true }) });
      await expect(page.getByTestId('today-backup-note')).toHaveCount(0);
      // a note from 9 days ago: shown with the age
      await open(page, seedOf([meal('m1', '2026-11-01')]), NOW, { 'hyrox.backup-note': JSON.stringify({ v: 1, at: '2026-11-10T09:00:00.000Z', file: 'x.json', restorable: true }) });
      await expect(page.getByTestId('today-backup-note')).toContainText('started here 9 days ago');
      await page.getByTestId('today-backup-open').click();
      await expect(page.getByTestId('panel-settings')).toBeVisible();
      // damaged or future-dated notes are never trusted
      for (const bad of ['{not json', JSON.stringify({ v: 1, at: '2027-01-01T00:00:00.000Z' }), JSON.stringify({ at: 5 })]) {
        await open(page, seedOf([meal('m1', '2026-11-01')]), NOW, { 'hyrox.backup-note': bad });
        await expect(page.getByTestId('today-backup-note')).toContainText('No backup download is recorded');
        await page.getByTestId('tab-settings').click();
        await expect(page.getByTestId('backup-last')).toHaveAttribute('data-state', 'unknown');
      }
      expect(page._errs).toEqual([]);
    });
  });
}
