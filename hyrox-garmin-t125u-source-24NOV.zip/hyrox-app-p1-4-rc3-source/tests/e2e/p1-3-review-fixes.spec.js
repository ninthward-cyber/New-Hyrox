'use strict';
// P1.3 independent-review fixes (Claude, Workstream E, 23 Nov 2026) on Grok's P1.3-RC1 (e272258), browser level:
// C2 Monday-Sunday review weeks, C3 unlogged sessions are not skips, C4 below-floor own target, C6 coach load error.
// Uses Grok's shared synthetic fixtures (p1-3-coach-lib.js). Synthetic data only, no network.
// CHROME MOBILE EMULATION, NOT SAFARI/WEBKIT and not a physical iPhone.
const { test, expect } = require('@playwright/test');
const L = require('./p1-3-coach-lib');

const sess = (id, date, slot, extra) => Object.assign({ id, createdAt: date + 'T06:00:00.000Z', date, title: 'Synthetic session', status: 'COMPLETED', modified: false, variant: 'ORIGINAL_60',
  durationMin: 50, rpe: 7, notes: '', blocks: [], planSlotId: 'v2.1-W1-' + slot, planVersion: 'v2.1', scheduledDate: date }, extra || {});
const DONE3 = () => [sess('p-MON', '2026-11-16', 'MON'), sess('p-TUE', '2026-11-17', 'TUE'), sess('p-WED', '2026-11-18', 'WED')];
function seed(o) {
  o = o || {};
  const h = L.history(o.hist || { kgPerWeek: -0.45 });
  return L.seedOf(Object.assign({ weight: h.weight, meals: h.meals.concat([L.meal('m-today', '2026-11-23', 600)]), dayStates: h.dayStates,
    sessions: o.sessions === undefined ? DONE3() : o.sessions, ownerSettings: [L.settingsWith(o.coach || L.coachObj())] }, o.more || {}));
}
const lowTarget = () => L.coachObj({ target: { kcal: 1000, proteinG: 190, fatG: null, carbsG: null, origin: 'OWNER_ENTERED', method: 'OWNER', effectiveDate: '2026-10-20', confirmedAt: '2026-10-20T05:00:00.000Z', reason: 'Synthetic', version: 'coach-1', goal: 'LOSE_1', inputs: null, warnings: ['BELOW_FLOOR'], replaced: null },
  history: [{ kcal: 1000, proteinG: 190, fatG: null, carbsG: null, origin: 'OWNER_ENTERED', method: 'OWNER', effectiveDate: '2026-10-20', confirmedAt: '2026-10-20T05:00:00.000Z', reason: 'Synthetic', version: 'coach-1', goal: 'LOSE_1', inputs: null, warnings: ['BELOW_FLOOR'], replaced: null }] });

for (const W of [390, 320]) {
  test.describe(`P1.3 review fixes ${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`${W}: FAIL-FIRST C2 — on Monday 23 Nov the review covers Mon 16 – Sun 22 Nov (Monday–Sunday, the plan's weeks); Home names Sunday as the week end`, async ({ page }) => {
      await L.open(page, seed());
      await expect(page.getByTestId('coach-status')).toContainText('(week to Sun 22 Nov)');
      await page.getByTestId('tab-trends').click();
      const c = page.getByTestId('trends-coach-review');
      await expect(c.getByTestId('review-week')).toHaveText('Completed week Mon 16 Nov – Sun 22 Nov (Monday–Sunday, Asia/Qatar, the same weeks as the training plan). Today is review day. The current week is not judged until it is complete.');
      await expect(c.getByTestId('review-weight-week').last()).toContainText('Mon 16 Nov – Sun 22 Nov');
      await expect(c).not.toContainText('Sunday–Saturday');
      // on Sunday 22 Nov the week of 16-22 is still open, so the review stays on 9-15 Nov and says when the next one is
      await L.open(page, seed(), '2026-11-22T09:00:00.000Z');
      await page.getByTestId('tab-trends').click();
      await expect(page.getByTestId('review-week')).toContainText('Completed week Mon 9 Nov – Sun 15 Nov');
      await expect(page.getByTestId('review-week')).toContainText('Next review Mon 23 Nov.');
      expect(page._errs).toEqual([]); expect(page._net).toEqual([]);
    });

    test(`${W}: FAIL-FIRST C3 — planned sessions that were simply not logged: no amber, never "completed"/"skipped"; shown as unknown and only hold a reduction`, async ({ page }) => {
      await L.open(page, seed({ sessions: [] }));
      const line = page.getByTestId('coach-status');
      await expect(line).toHaveAttribute('data-level', 'GREEN');
      await expect(line).not.toContainText('Fewer than half');
      await page.getByTestId('tab-trends').click();
      const c = page.getByTestId('trends-coach-review');
      await expect(c.getByTestId('review-planned')).toContainText('completed 0 · partial 0 · skipped (logged as skipped) 0 · not logged (unknown) 5');
      const con = c.locator('[data-testid="review-concern"][data-code="SESSION_LOG"]');
      await expect(con).toHaveAttribute('data-level', 'HOLD');
      await expect(con).toContainText('5 of 5 eligible planned sessions last week are not logged (unknown, not counted as missed)'); // wording re-pointed in RC3 (decision 3)
      await expect(c.locator('[data-testid="review-concern"][data-code="SESSIONS"]')).toHaveCount(0);
      await expect(c.getByTestId('review-gaps')).toContainText('5 planned sessions not logged');
      expect(page._errs).toEqual([]);
    });

    test(`${W}: FAIL-FIRST C3 — confirmed skips are named as skips and measured against logged sessions (3 of the 4 logged)`, async ({ page }) => {
      const sk = (id, date, slot) => sess(id, date, slot, { status: 'SKIPPED', skipConfirmed: true, durationMin: null, rpe: null });
      await L.open(page, seed({ sessions: [sess('p-MON', '2026-11-16', 'MON'), sk('p-TUE', '2026-11-17', 'TUE'), sk('p-WED', '2026-11-18', 'WED'), sk('p-THU', '2026-11-19', 'THU')] }));
      const line = page.getByTestId('coach-status');
      await expect(line).toHaveAttribute('data-level', 'AMBER');
      await expect(line).toContainText('3 of the 4 logged planned sessions were skipped last week.');
      expect(page._errs).toEqual([]);
    });

    test(`${W}: FAIL-FIRST C4 — a confirmed 1,000 kcal own target is never "On track": amber, named, with a clinician note`, async ({ page }) => {
      await L.open(page, seed({ coach: lowTarget() }));
      const line = page.getByTestId('coach-status');
      await expect(line).toHaveAttribute('data-level', 'AMBER');
      await expect(line).not.toContainText('On track');
      await expect(line).toContainText('Your confirmed target of 1,000 kcal is below the provisional floor of');
      await expect(line).toContainText('Discuss a target this low with a clinician.');
      expect(page._errs).toEqual([]);
    });

    // Re-pointed for P1.3-RC3 (owner decision 1): RC2 accepted a below-floor target after a separate tick; RC3 refuses it.
    test(`${W}: FAIL-FIRST C4 — a below-floor own target is refused before any confirm screen; nothing is saved; a normal target still works`, async ({ page }) => {
      await L.open(page, seed({ coach: L.coachObj() }));
      await page.getByTestId('tab-settings').click();
      await page.getByTestId('coach-own').locator('summary').click();
      const before = JSON.stringify(await L.setRec(page));
      await page.getByTestId('coach-own-kcal').fill('1000'); await page.getByTestId('coach-own-protein').fill('190');
      await page.getByTestId('coach-own-review').click();
      await expect(page.getByTestId('coach-own-error')).toContainText('1,000 kcal is below the provisional floor of');
      await expect(page.getByTestId('coach-own-error')).toContainText('not a medical rule');
      await expect(page.getByTestId('coach-confirm')).toHaveCount(0);
      expect(JSON.stringify(await L.setRec(page))).toBe(before);
      await page.getByTestId('coach-own-kcal').fill('2200'); await page.getByTestId('coach-own-protein').fill('190');
      await page.getByTestId('coach-own-review').click();
      await expect(page.getByTestId('coach-confirm')).toBeVisible();
      await page.getByTestId('coach-confirm-ok').click();
      await expect(page.getByTestId('coach-confirm')).toHaveCount(0);
      expect((await L.setRec(page)).nutritionCoach.target.kcal).toBe(2200);
      expect(page._errs).toEqual([]);
    });

    test(`${W}: FAIL-FIRST C6 — if hyrox-coach.js fails to load: load guard names it, Home and Settings say UNAVAILABLE (not "off"), stored coach untouched`, async ({ page }) => {
      const s = seed({ coach: lowTarget() });
      await L.open(page, s);
      await page.route('**/src/data/hyrox-coach.js', (r) => r.abort());
      await page.reload();
      await expect(page.getByTestId('load-guard')).toBeVisible();
      await expect(page.getByTestId('load-guard-missing')).toContainText('src/data/hyrox-coach.js');
      await expect(page.getByTestId('today-coach-unavailable')).toContainText('Nutrition Coach did not load');
      await expect(page.getByTestId('coach-status')).toHaveCount(0);
      await page.getByTestId('tab-settings').click();
      const u = page.getByTestId('coach-unavailable');
      await expect(u).toHaveAttribute('data-state', 'LOAD_ERROR');
      await expect(u).toContainText('UNAVAILABLE — load error');
      await expect(page.getByTestId('coach-toggle')).toHaveCount(0);
      expect((await L.setRec(page)).nutritionCoach).toEqual(s.ownerSettings[0].nutritionCoach);
      await page.unroute('**/src/data/hyrox-coach.js');
      await page.reload();
      await expect(page.getByTestId('load-guard')).toBeHidden();
      await expect(page.getByTestId('today-coach-unavailable')).toHaveCount(0);
      await expect(page.getByTestId('coach-status')).toHaveAttribute('data-level', 'AMBER');
    });

    test(`${W}: FAIL-FIRST C7 — with larger text (page zoom 1.35) every Home macro label is shown whole`, async ({ page }) => {
      await L.open(page, seed());
      await page.evaluate(() => { document.documentElement.style.zoom = '1.35'; });
      const clipped = await page.getByTestId('glance-macros').locator('dt').evaluateAll((els) => els.filter((e) => e.scrollWidth > e.clientWidth + 1).map((e) => e.textContent));
      expect(clipped).toEqual([]);
      await page.evaluate(() => { document.documentElement.style.zoom = ''; });
      // (RC3: the RC2 acknowledgement tick was removed with the refusal; its 44 px check went with it)
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
    });

    test(`${W}: GUARD (passes before and after) C6 — no coach stored and the module missing: no warning noise, Home works`, async ({ page }) => {
      await L.open(page, L.seedOf({ meals: [L.meal('m-today', '2026-11-23', 600)] }));
      await page.route('**/src/data/hyrox-coach.js', (r) => r.abort());
      await page.reload();
      await expect(page.getByTestId('today-coach-unavailable')).toHaveCount(0);
      await expect(page.getByTestId('glance-nutrition-text')).toContainText('600 kcal');
    });
  });
}
