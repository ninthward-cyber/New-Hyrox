'use strict';
// P1.1: Add > Morning (one optional morning log), Garmin intensity minutes (weekly Mon-Sun sum with coverage), kg/lb preference.
// Synthetic data only, no network, no paid call. CHROME MOBILE EMULATION, NOT SAFARI/WEBKIT and not a physical iPhone.
const { test, expect } = require('@playwright/test');

const NOW = '2026-11-22T09:00:00.000Z'; // 12:00 Asia/Qatar, Sun 22 Nov 2026 (week Mon 16 - Sun 22)
const T = '2026-11-01T06:00:00.000Z';
const im = (v) => ({ state: 'OBSERVED', value: v, source: 'GARMIN_MANUAL' });
const obs = (v) => ({ state: 'OBSERVED', value: v });
const day = (date, extra) => Object.assign({ id: 'daily-' + date, date, createdAt: T }, extra || {});
const seedOf = (o) => Object.assign({ version: 2, weight: [], workouts: [], nutrition: [] }, o || {});
async function open(page, seed, at = NOW) {
  page._errs = []; page.on('pageerror', (e) => page._errs.push(e.message));
  await page.clock.setFixedTime(new Date(at));
  await page.goto('./');
  await page.evaluate((s) => { localStorage.clear(); if (s) localStorage.setItem('hyrox.v1', JSON.stringify(s)); }, seed || null);
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
}
const stored = (page) => page.evaluate(() => JSON.parse(localStorage.getItem('hyrox.v1') || '{}'));
const raw = (page) => page.evaluate(() => localStorage.getItem('hyrox.v1'));
const keys = (page) => page.evaluate(() => Object.keys(localStorage).sort());
async function morning(page) { await page.getByTestId('tab-add').click(); await page.getByTestId('add-mode-morning').click(); await expect(page.getByTestId('morning-form')).toBeVisible(); }
async function setLb(page) { await page.getByTestId('tab-settings').click(); await page.getByTestId('unit-lb').click(); await expect(page.getByTestId('unit-lb')).toHaveAttribute('aria-pressed', 'true'); }
const daily = (s, d) => (s.daily || []).find((x) => x.date === d);

for (const W of [390, 320]) {
  test.describe(`P1.1 morning log ${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`${W}: one save writes weight and waist for today, sleep and resting HR dated today, steps and Garmin minutes dated yesterday; 46 stays 46`, async ({ page }) => {
      await open(page);
      await morning(page);
      await expect(page.getByTestId('mlog-morning-heading')).toContainText('Morning of Sun 22 Nov (today)');
      await expect(page.getByTestId('mlog-prev-heading')).toContainText('The day before — Sat 21 Nov');
      await expect(page.getByTestId('mlog-intensity-hint')).toContainText('30 moderate + 8 vigorous shows as 46');
      await page.getByTestId('mlog-weight').fill('97.6');
      await page.getByTestId('mlog-waist').fill('101.5');
      await page.getByTestId('mlog-sleep').fill('6.5');
      await page.getByTestId('mlog-rhr').fill('58');
      await page.getByTestId('mlog-steps').fill('8,500');
      await page.getByTestId('mlog-intensity').fill('46');
      await page.getByTestId('mlog-save').click();
      await expect(page.getByTestId('mlog-result')).toContainText('Saved on this device: weight 97.6 kg; waist 101.5 cm; sleep 6.5 h, resting HR 58 bpm (Sun 22 Nov); steps 8,500, intensity minutes 46 (Sat 21 Nov).');
      const s = await stored(page);
      expect(s.version).toBe(2);
      expect(s.weight.map((w) => [w.date, w.kg])).toEqual([['2026-11-22', 97.6]]);
      expect(s.body.map((b) => [b.date, b.metric, b.state, b.value, b.source])).toEqual([['2026-11-22', 'waist_cm', 'OBSERVED', 101.5, 'manual']]);
      expect(s.daily.length).toBe(2);
      const t = daily(s, '2026-11-22'), y = daily(s, '2026-11-21');
      expect([t.id, t.sleepH, t.rhr, t.steps, t.intensityMin]).toEqual(['daily-2026-11-22', obs(6.5), obs(58), undefined, undefined]);
      expect([y.id, y.steps, y.intensityMin, y.sleepH, y.rhr]).toEqual(['daily-2026-11-21', obs(8500), im(46), undefined, undefined]);
      // the form now shows what is saved; the other screens read the same records
      await expect(page.getByTestId('mlog-intensity')).toHaveValue('46');
      await expect(page.getByTestId('mlog-weight')).toHaveValue('97.6');
      await page.getByTestId('tab-today').click();
      await expect(page.getByTestId('glance-weight-text')).toHaveText('97.6 kg · today');
      await page.getByTestId('tab-trends').click();
      const wk = page.locator('[data-testid="intensity-week"][data-week="2026-11-16"]');
      await expect(wk).toHaveAttribute('data-total', '46');
      await expect(wk).toContainText('46 intensity min from 1 day recorded · 6 of 7 not recorded');
      await expect(wk).toContainText('reference 150: 104 below on the recorded days (the days not recorded are unknown)');
      expect(await keys(page)).toEqual(['hyrox.v1']);
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
      expect(page._errs).toEqual([]);
    });

    test(`${W}: every field blank saves nothing; one field alone writes only that; an explicit 0 is a recorded zero`, async ({ page }) => {
      const seed = seedOf({ daily: [day('2026-11-21', { steps: obs(7000), soreness: obs(3), limp: { state: 'OBSERVED', value: false }, stepTargetOverride: 9000, later: { keep: [1, 2] } })] });
      await open(page, seed);
      const before = await raw(page);
      await morning(page);
      await expect(page.getByTestId('mlog-steps')).toHaveValue('7000');
      await page.getByTestId('mlog-steps').fill('');
      await page.getByTestId('mlog-save').click();
      await expect(page.getByTestId('mlog-error')).toHaveText('Nothing to save: every field is blank. Nothing was changed.');
      expect(await raw(page)).toBe(before);
      await page.getByTestId('mlog-intensity').fill('0');
      await page.getByTestId('mlog-save').click();
      await expect(page.getByTestId('mlog-result')).toContainText('Saved on this device: intensity minutes 0 (Sat 21 Nov).');
      const s = await stored(page), y = daily(s, '2026-11-21'), was = seed.daily[0];
      expect(y.intensityMin).toEqual(im(0));
      const rest = Object.assign({}, y); delete rest.intensityMin; delete rest.updatedAt; delete rest.revisions; // updatedAt/revisions are the data layer's own edit stamp on every upsert
      expect(rest).toEqual(was); // the cleared steps box did not delete the 7,000; nothing else moved
      expect(s.daily.length).toBe(1); expect(s.weight).toEqual([]); expect(s.body || []).toEqual([]);
      await page.getByTestId('tab-trends').click();
      const wk = page.locator('[data-testid="intensity-week"][data-week="2026-11-16"]');
      await expect(wk).toHaveAttribute('data-total', '0'); await expect(wk).toHaveAttribute('data-recorded', '1');
      expect(page._errs).toEqual([]);
    });

    test(`${W}: editing upserts one record per date; saving what is shown again changes nothing; other dates and types are untouched`, async ({ page }) => {
      const seed = seedOf({
        weight: [{ id: 'w-a', date: '2026-11-22', kg: 98.2, createdAt: T }, { id: 'w-b', date: '2026-11-20', kg: 98.9, createdAt: T }],
        workouts: [{ id: 'wo1', date: '2026-11-21', type: 'run', durationMin: 40, createdAt: T }],
        body: [{ id: 'b-a', date: '2026-11-22', metric: 'waist_cm', state: 'OBSERVED', value: 102, source: 'manual', createdAt: T, notes: 'tape' }],
        daily: [day('2026-11-22', { sleepH: obs(7), rhr: obs(60), readiness: obs(8) }), day('2026-11-21', { steps: obs(9000), intensityMin: im(30) }), day('2026-11-20', { steps: obs(5000), intensityMin: im(12) })],
      });
      await open(page, seed);
      await morning(page);
      for (const [id, v] of [['mlog-weight', '98.2'], ['mlog-waist', '102'], ['mlog-sleep', '7'], ['mlog-rhr', '60'], ['mlog-steps', '9000'], ['mlog-intensity', '30']]) await expect(page.getByTestId(id)).toHaveValue(v);
      const before = await raw(page);
      await page.getByTestId('mlog-save').click();
      await expect(page.getByTestId('mlog-error')).toContainText('Nothing to save: weight, waist, sleep, resting HR, steps, intensity minutes already saved with those values.');
      expect(await raw(page)).toBe(before);
      await page.getByTestId('mlog-weight').fill('97.9');
      await page.getByTestId('mlog-waist').fill('101');
      await page.getByTestId('mlog-rhr').fill('57');
      await page.getByTestId('mlog-intensity').fill('46');
      await page.getByTestId('mlog-save').click();
      await expect(page.getByTestId('mlog-result')).toContainText('Unchanged: sleep, steps.');
      const s = await stored(page);
      expect(s.weight.map((w) => [w.date, w.kg]).sort()).toEqual([['2026-11-20', 98.9], ['2026-11-22', 97.9]]);
      expect(s.weight.find((w) => w.date === '2026-11-20')).toEqual(seed.weight[1]);
      expect(s.body.length).toBe(1);
      expect([s.body[0].id, s.body[0].value, s.body[0].notes]).toEqual(['b-a', 101, 'tape']);
      expect(s.daily.length).toBe(3);
      const t = daily(s, '2026-11-22'), y = daily(s, '2026-11-21');
      expect([t.sleepH, t.rhr, t.readiness]).toEqual([obs(7), obs(57), obs(8)]);
      expect([y.steps, y.intensityMin]).toEqual([obs(9000), im(46)]);
      expect(daily(s, '2026-11-20')).toEqual(seed.daily[2]);
      expect(s.workouts).toEqual(seed.workouts);
      expect(page._errs).toEqual([]);
    });

    test(`${W}: nothing is written when any field is not valid; the message names each problem`, async ({ page }) => {
      const seed = seedOf({ daily: [day('2026-11-21', { steps: obs(9000) })] });
      await open(page, seed);
      const before = await raw(page);
      await morning(page);
      await page.getByTestId('mlog-weight').fill('97.6');   // valid, but must not be saved on its own
      await page.getByTestId('mlog-sleep').fill('25');
      await page.getByTestId('mlog-rhr').fill('58.5');
      await page.getByTestId('mlog-intensity').fill('12.5');
      await page.getByTestId('mlog-save').click();
      const err = page.getByTestId('mlog-error');
      await expect(err).toContainText('Sleep must be a number of hours from 0 to 24.');
      await expect(err).toContainText('Resting HR must be a whole number from 25 to 220 bpm.');
      await expect(err).toContainText('Intensity minutes must be a whole number from 0 to 2880.');
      await expect(err).toContainText('Nothing was changed.');
      expect(await raw(page)).toBe(before);
      for (const [id, v] of [['mlog-sleep', ''], ['mlog-rhr', ''], ['mlog-intensity', '2881']]) await page.getByTestId(id).fill(v);
      await page.getByTestId('mlog-save').click();
      await expect(err).toContainText('Intensity minutes must be a whole number from 0 to 2880.');
      expect(await raw(page)).toBe(before);
      for (const bad of ['-5', '4e1', 'abc']) { await page.getByTestId('mlog-intensity').fill(bad); await page.getByTestId('mlog-save').click(); await expect(err).toContainText('Not saved'); expect(await raw(page)).toBe(before); }
      expect(page._errs).toEqual([]);
    });

    test(`${W}: date switches — yesterday morning and a chosen date write to the right days; a future date is refused`, async ({ page }) => {
      await open(page);
      await morning(page);
      await page.getByTestId('mlog-yesterday').click();
      await expect(page.getByTestId('mlog-morning-heading')).toContainText('Morning of Sat 21 Nov —');
      await expect(page.getByTestId('mlog-prev-heading')).toContainText('Fri 20 Nov');
      await page.getByTestId('mlog-rhr').fill('59'); await page.getByTestId('mlog-intensity').fill('20');
      await page.getByTestId('mlog-save').click();
      await expect(page.getByTestId('mlog-result')).toContainText('Saved on this device');
      await page.getByTestId('mlog-choose').click();
      await page.getByTestId('mlog-date').fill('2026-11-16'); // a Monday: the day before is Sunday of the previous week
      await expect(page.getByTestId('mlog-prev-heading')).toContainText('Sun 15 Nov');
      await page.getByTestId('mlog-weight').fill('99'); await page.getByTestId('mlog-intensity').fill('31');
      await page.getByTestId('mlog-save').click();
      await expect(page.getByTestId('mlog-result')).toContainText('Saved on this device');
      let s = await stored(page);
      expect(s.daily.map((d) => [d.date, d.rhr ? d.rhr.value : null, d.intensityMin ? d.intensityMin.value : null]).sort()).toEqual([['2026-11-15', null, 31], ['2026-11-20', null, 20], ['2026-11-21', 59, null]]);
      expect(s.weight.map((w) => [w.date, w.kg])).toEqual([['2026-11-16', 99]]);
      const before = await raw(page);
      await page.getByTestId('mlog-date').fill('2026-11-23');
      await expect(page.getByTestId('mlog-date-error')).toContainText('in the future');
      await expect(page.getByTestId('mlog-save')).toHaveCount(0);
      expect(await raw(page)).toBe(before);
      // weekly view: Sunday 15th counts in the week of Mon 9, Friday 20th in the week of Mon 16
      await page.getByTestId('tab-trends').click();
      await expect(page.locator('[data-testid="intensity-week"][data-week="2026-11-09"]')).toHaveAttribute('data-total', '31');
      await expect(page.locator('[data-testid="intensity-week"][data-week="2026-11-16"]')).toHaveAttribute('data-total', '20');
      expect(page._errs).toEqual([]);
    });

    test(`${W}: Asia/Qatar midnight — a form opened before midnight does not save under the wrong day; after re-check it uses the new day`, async ({ page }) => {
      await open(page, null, '2026-11-22T20:59:30.000Z'); // 23:59:30 Sun 22 Nov in Qatar
      await morning(page);
      await expect(page.getByTestId('mlog-morning-heading')).toContainText('Sun 22 Nov');
      await page.getByTestId('mlog-intensity').fill('46');
      await page.clock.setFixedTime(new Date('2026-11-22T21:00:30.000Z')); // 00:00:30 Mon 23 Nov in Qatar
      await page.getByTestId('mlog-save').click();
      await expect(page.getByTestId('mlog-result')).toContainText('The date changed at midnight (Asia/Qatar). Check the day and save again. Nothing was saved.');
      expect((await stored(page)).daily || []).toEqual([]);
      await expect(page.getByTestId('mlog-morning-heading')).toContainText('Morning of Mon 23 Nov (today)');
      await expect(page.getByTestId('mlog-prev-heading')).toContainText('Sun 22 Nov');
      await page.getByTestId('mlog-intensity').fill('46');
      await page.getByTestId('mlog-save').click();
      await expect(page.getByTestId('mlog-result')).toContainText('intensity minutes 46 (Sun 22 Nov)');
      const s = await stored(page);
      expect(s.daily.map((d) => [d.date, d.intensityMin.value])).toEqual([['2026-11-22', 46]]);
      // week rollover: Sunday's 46 belongs to the week of Mon 16; the new week (Mon 23) has nothing yet and says so
      await page.getByTestId('tab-trends').click();
      await expect(page.locator('[data-testid="intensity-week"][data-week="2026-11-16"]')).toHaveAttribute('data-total', '46');
      const cur = page.locator('[data-testid="intensity-week"][data-week="2026-11-23"]');
      await expect(cur).toHaveAttribute('data-total', '');
      await expect(cur).toContainText('no intensity minutes recorded (unknown, not 0) · 1 of 1 not recorded (week in progress, 1 day so far)');
      expect(page._errs).toEqual([]);
    });

    test(`${W}: weekly sum — recorded days only with coverage, mixed old and new check-ins, malformed values unknown, workouts never added`, async ({ page }) => {
      const seed = seedOf({
        workouts: [{ id: 'wo1', date: '2026-11-17', type: 'run', durationMin: 60, createdAt: T }],
        sessions: [],
        walks: [],
        daily: [day('2026-11-16', { intensityMin: im(46), steps: obs(9000) }), day('2026-11-17', { steps: obs(12000), soreness: obs(2) }), // an older-style check-in: no intensity field
          day('2026-11-18', { intensityMin: im(0) }), day('2026-11-19', { intensityMin: { state: 'OBSERVED', value: 'lots', source: 'GARMIN_MANUAL' } }),
          day('2026-11-20', { intensityMin: im(92) }), day('2026-11-21', { intensityMin: { state: 'OBSERVED', value: 40 } }),
          day('2026-11-10', { intensityMin: im(150) }), day('2026-11-12', { intensityMin: im(25) })],
      });
      await open(page, seed);
      const before = await raw(page);
      await page.getByTestId('tab-trends').click();
      const rows = page.getByTestId('intensity-week');
      await expect(rows).toHaveCount(4);
      const cur = page.locator('[data-testid="intensity-week"][data-week="2026-11-16"]');
      await expect(cur).toHaveText('Week of Mon 16 Nov: 138 intensity min from 3 days recorded · 2 of 7 not recorded · 2 days with a saved value that is not valid (not counted) · reference 150: 12 below on the recorded days (the days not recorded are unknown)');
      const prev = page.locator('[data-testid="intensity-week"][data-week="2026-11-09"]');
      await expect(prev).toHaveText('Week of Mon 9 Nov: 175 intensity min from 2 days recorded · 5 of 7 not recorded · reference 150: reached on the recorded days');
      await expect(page.locator('[data-testid="intensity-week"][data-week="2026-11-02"]')).toContainText('no intensity minutes recorded (unknown, not 0) · 7 of 7 not recorded');
      await expect(page.getByTestId('intensity-note')).toContainText('never estimated or scaled up');
      await expect(page.getByTestId('intensity-note')).toContainText('kept apart from your workout records, steps and calories');
      expect(await raw(page)).toBe(before); // looking at Trends writes nothing
      // the malformed days are offered for correction in the morning log, as unknown - never as a number
      await morning(page);
      await page.getByTestId('mlog-choose').click(); await page.getByTestId('mlog-date').fill('2026-11-20');
      await expect(page.getByTestId('mlog-intensity')).toHaveValue('');
      await expect(page.getByTestId('morning-form')).toContainText('The saved value is not valid (treated as unknown)');
      await page.getByTestId('mlog-intensity').fill('15'); await page.getByTestId('mlog-save').click();
      await expect(page.getByTestId('mlog-result')).toContainText('Saved on this device');
      expect(daily(await stored(page), '2026-11-19').intensityMin).toEqual(im(15));
      expect(page._errs).toEqual([]);
    });

    test(`${W}: the individual routes still work and keep the new value — Log steps, Check-in and Quick log weight`, async ({ page }) => {
      const seed = seedOf({ daily: [day('2026-11-21', { intensityMin: im(46) }), day('2026-11-22', { intensityMin: im(10) })] });
      await open(page, seed);
      // Today > Log steps (yesterday)
      await page.getByTestId('today-log-steps').click();
      await page.getByTestId('qsteps-yesterday').click();
      await page.getByTestId('qsteps-input').fill('8123'); await page.getByTestId('qsteps-save').click();
      await expect.poll(async () => { const d = daily(await stored(page), '2026-11-21'); return d && d.steps ? d.steps.value : null; }).toBe(8123);
      // Add > Check-in (today): saving the full check-in keeps the intensity minutes of that day
      await page.getByTestId('tab-add').click(); await page.getByTestId('add-mode-daily').click();
      await expect(page.getByTestId('daily-form')).toBeVisible();
      await page.getByTestId('daily-sleepH').fill('7.5');
      await page.getByTestId('daily-submit').click();
      await expect.poll(async () => { const d = daily(await stored(page), '2026-11-22'); return d && d.sleepH ? d.sleepH.value : null; }).toBe(7.5);
      // Add > Quick log weight
      await page.getByTestId('add-mode-classic').click();
      await page.getByTestId('weight-kg').fill('98.4'); await page.getByTestId('weight-submit').click();
      await expect(page.getByTestId('weight-item')).toContainText('98.4 kg');
      const s = await stored(page);
      expect(daily(s, '2026-11-21').intensityMin).toEqual(im(46));
      expect(daily(s, '2026-11-22').intensityMin).toEqual(im(10));
      expect(s.weight.map((w) => w.kg)).toEqual([98.4]);
      // and the morning log shows all of it
      await page.getByTestId('add-mode-morning').click();
      for (const [id, v] of [['mlog-weight', '98.4'], ['mlog-sleep', '7.5'], ['mlog-steps', '8123'], ['mlog-intensity', '46']]) await expect(page.getByTestId(id)).toHaveValue(v);
      expect(page._errs).toEqual([]);
    });

    test(`${W}: pounds — typed and shown in lb, stored in kg; switching back shows the same kg; re-saving what is shown never drifts`, async ({ page }) => {
      const seed = seedOf({ weight: [{ id: 'w-a', date: '2026-11-20', kg: 98.4, createdAt: T }, { id: 'w-b', date: '2026-11-15', kg: 99.2, createdAt: T }],
        ownerSettings: [{ id: 'app-settings', date: '2026-11-11', createdAt: T, rhrBaselineBpm: 61, rhrBaselineSource: 'OWNER_SET', stepBaselineMode: 'MANUAL', stepBaselineManual: 9000, favFoods: ['us:1'], later: { keep: true } }] });
      await open(page, seed);
      await page.getByTestId('tab-today').click();
      await expect(page.getByTestId('glance-weight-text')).toHaveText('98.4 kg · last measured Fri 20 Nov');
      await setLb(page);
      let s = await stored(page);
      const set = s.ownerSettings[0], was = seed.ownerSettings[0];
      expect(set.weightUnit).toBe('lb');
      for (const k of Object.keys(was)) expect(set[k]).toEqual(was[k]); // baselines, favourites and later fields kept
      expect(s.weight).toEqual(seed.weight); // no stored weight was touched
      await page.getByTestId('tab-today').click();
      await expect(page.getByTestId('glance-weight-text')).toHaveText('216.9 lb · last measured Fri 20 Nov');
      await page.getByTestId('tab-trends').click();
      await expect(page.getByTestId('chart-weight-heading')).toHaveText('Weight (lb)');
      await expect(page.getByTestId('trends-sum-weight')).toContainText('216.9 lb on Fri 20 Nov · -1.8 lb since');
      await morning(page);
      expect(await page.getByTestId('mlog-weight').evaluate((n) => document.querySelector('label[for="' + n.id + '"]').textContent)).toBe('Weight (lb)');
      await page.getByTestId('mlog-weight').fill('215');
      await page.getByTestId('mlog-save').click();
      await expect(page.getByTestId('mlog-result')).toContainText('Saved on this device: weight 215 lb.');
      await expect(page.getByTestId('mlog-weight')).toHaveValue('215');
      s = await stored(page);
      expect(s.weight.find((w) => w.date === '2026-11-22').kg).toBe(97.5);
      // re-save what is shown, three times: nothing is written
      const fixed = await raw(page);
      for (let i = 0; i < 3; i++) { await page.getByTestId('mlog-save').click(); await expect(page.getByTestId('mlog-error')).toContainText('Nothing to save: weight already saved'); }
      expect(await raw(page)).toBe(fixed);
      // Quick log in lb
      await page.getByTestId('add-mode-classic').click();
      await expect(page.getByTestId('weight-kg-label')).toHaveText('Weight (lb)');
      await expect(page.getByTestId('weight-item').first()).toContainText('215 lb');
      await page.getByTestId('weight-date').fill('2026-11-19'); await page.getByTestId('weight-kg').fill('216.2'); await page.getByTestId('weight-submit').click();
      await expect.poll(async () => ((await stored(page)).weight.find((w) => w.date === '2026-11-19') || {}).kg).toBe(98.1);
      await page.getByTestId('weight-kg').fill('30'); await page.getByTestId('weight-submit').click(); // 13.6 kg: below the stored range
      await expect(page.getByTestId('weight-error-kg')).toContainText('between 44.1 and 881.8 lb');
      expect((await stored(page)).weight.length).toBe(4);
      // back to kg: the same stored values, and the preference field is gone again
      await page.getByTestId('tab-settings').click(); await page.getByTestId('unit-kg').click();
      await expect(page.getByTestId('unit-kg')).toHaveAttribute('aria-pressed', 'true');
      s = await stored(page);
      expect('weightUnit' in s.ownerSettings[0]).toBe(false);
      expect(s.weight.map((w) => [w.date, w.kg]).sort()).toEqual([['2026-11-15', 99.2], ['2026-11-19', 98.1], ['2026-11-20', 98.4], ['2026-11-22', 97.5]]);
      await page.getByTestId('tab-today').click();
      await expect(page.getByTestId('glance-weight-text')).toHaveText('97.5 kg · today');
      await page.getByTestId('tab-add').click(); await page.getByTestId('add-mode-classic').click();
      await expect(page.getByTestId('weight-kg-label')).toHaveText('Weight (kg)');
      expect(await keys(page)).toEqual(['hyrox.v1']);
      expect(page._errs).toEqual([]);
    });

    test(`${W}: several weights already saved for the date, or a damaged check-in — the morning log changes nothing there and says where to go`, async ({ page }) => {
      const seed = seedOf({ weight: [{ id: 'w-a', date: '2026-11-22', kg: 98.2, createdAt: T }, { id: 'w-b', date: '2026-11-22', kg: 98.0, createdAt: '2026-11-01T07:00:00.000Z' }],
        daily: [day('2026-11-21', { steps: obs(9000), soreness: { state: 'OBSERVED', value: 99 } })] });
      await open(page, seed);
      const before = await raw(page);
      await morning(page);
      await expect(page.getByTestId('mlog-weight')).toBeDisabled();
      await expect(page.getByTestId('morning-form')).toContainText('2 weights are saved for this date. Manage them in Quick log');
      await expect(page.getByTestId('mlog-damaged-prev')).toBeVisible();
      await expect(page.getByTestId('mlog-steps')).toBeDisabled(); await expect(page.getByTestId('mlog-intensity')).toBeDisabled();
      await page.getByTestId('mlog-save').click();
      await expect(page.getByTestId('mlog-error')).toContainText('Nothing to save');
      expect(await raw(page)).toBe(before);
      // the healthy part still saves, and the damaged record is byte-for-byte what it was
      await page.getByTestId('mlog-sleep').fill('7'); await page.getByTestId('mlog-save').click();
      await expect(page.getByTestId('mlog-result')).toContainText('Saved on this device: sleep 7 h (Sun 22 Nov).');
      const s = await stored(page);
      expect(daily(s, '2026-11-21')).toEqual(seed.daily[0]); expect(s.weight).toEqual(seed.weight);
      await page.getByTestId('mlog-damaged-prev-open').click();
      await expect(page.getByTestId('daily-form')).toBeVisible();
      expect(page._errs).toEqual([]);
    });

    test(`${W}: cross-tab — changes made in another tab after the form was drawn are kept (check-in values, settings fields)`, async ({ page, context }) => {
      const seed = seedOf({ daily: [day('2026-11-21', { steps: obs(9000) })], ownerSettings: [{ id: 'app-settings', date: '2026-11-11', createdAt: T, rhrBaselineBpm: 61, stepBaselineMode: 'AUTO' }] });
      await open(page, seed);
      await morning(page);
      await page.getByTestId('mlog-intensity').fill('46');
      await page.getByTestId('tab-settings').click(); // the Units card is drawn now, before the other tab's change
      // another tab of the same app: yesterday's soreness is recorded and a favourite food is added
      const other = await context.newPage();
      await other.clock.setFixedTime(new Date(NOW));
      await other.goto('./');
      await other.evaluate(() => { const d = JSON.parse(localStorage.getItem('hyrox.v1'));
        d.daily[0].soreness = { state: 'OBSERVED', value: 4 }; d.daily[0].steps = { state: 'OBSERVED', value: 9100 };
        d.ownerSettings[0].favFoods = ['us:123']; d.ownerSettings[0].rhrBaselineBpm = 59;
        localStorage.setItem('hyrox.v1', JSON.stringify(d)); });
      await other.close();
      await page.getByTestId('unit-lb').click();
      await expect(page.getByTestId('unit-lb')).toHaveAttribute('aria-pressed', 'true');
      let s = await stored(page);
      expect([s.ownerSettings[0].weightUnit, s.ownerSettings[0].favFoods, s.ownerSettings[0].rhrBaselineBpm]).toEqual(['lb', ['us:123'], 59]);
      // back on the morning log the typed 46 was redrawn away with the fresh data; type it again and save
      await page.getByTestId('tab-add').click();
      await expect(page.getByTestId('mlog-steps')).toHaveValue('9100');
      await page.getByTestId('mlog-intensity').fill('46'); await page.getByTestId('mlog-save').click();
      await expect(page.getByTestId('mlog-result')).toContainText('Saved on this device: intensity minutes 46');
      s = await stored(page);
      const y = daily(s, '2026-11-21');
      expect([y.steps, y.soreness, y.intensityMin]).toEqual([obs(9100), obs(4), im(46)]);
      expect(page._errs).toEqual([]);
    });

    test(`${W}: cross-tab — a stale form never overwrites: the other tab's newer steps win when the steps box was left as drawn... and are replaced only when typed`, async ({ page, context }) => {
      const seed = seedOf({ daily: [day('2026-11-21', { steps: obs(9000), intensityMin: im(30) })] });
      await open(page, seed);
      await morning(page);
      await expect(page.getByTestId('mlog-steps')).toHaveValue('9000');
      const other = await context.newPage();
      await other.goto('./');
      await other.evaluate(() => { const d = JSON.parse(localStorage.getItem('hyrox.v1')); d.daily[0].readiness = { state: 'OBSERVED', value: 7 }; localStorage.setItem('hyrox.v1', JSON.stringify(d)); });
      await other.close();
      await page.getByTestId('mlog-intensity').fill('46'); // steps box still shows the drawn 9000 = what is stored: unchanged
      await page.getByTestId('mlog-save').click();
      await expect(page.getByTestId('mlog-result')).toContainText('Unchanged: steps.');
      const y = daily(await stored(page), '2026-11-21');
      expect([y.steps, y.readiness, y.intensityMin]).toEqual([obs(9000), obs(7), im(46)]);
      expect(page._errs).toEqual([]);
    });

    test(`${W}: damaged settings — the unit cannot be switched (nothing is replaced), weights show in kg, the morning log still saves`, async ({ page }) => {
      const seed = seedOf({ weight: [{ id: 'w-a', date: '2026-11-20', kg: 98.4, createdAt: T }],
        ownerSettings: [{ id: 'app-settings', date: '2026-11-11', createdAt: T, rhrBaselineBpm: 999, stepBaselineMode: 'AUTO', weightUnit: 'lb', favFoods: ['us:1'] }] });
      await open(page, seed);
      const before = await raw(page);
      await page.getByTestId('tab-today').click();
      await expect(page.getByTestId('glance-weight-text')).toContainText('98.4 kg');
      await page.getByTestId('tab-settings').click();
      await expect(page.getByTestId('owner-settings-damaged')).toBeVisible();
      await expect(page.getByTestId('unit-kg')).toHaveAttribute('aria-pressed', 'true');
      await page.getByTestId('unit-lb').click();
      await expect(page.getByTestId('units-error')).toContainText('Not saved: your saved settings have a value that is not valid');
      expect(await raw(page)).toBe(before);
      await morning(page);
      await page.getByTestId('mlog-weight').fill('98'); await page.getByTestId('mlog-save').click();
      await expect(page.getByTestId('mlog-result')).toContainText('Saved on this device: weight 98 kg.');
      const s = await stored(page);
      expect(s.ownerSettings).toEqual(seed.ownerSettings); // the damaged record is exactly as it was
      expect(page._errs).toEqual([]);
    });

    test(`${W}: storage failure — a full or blocked device reports "not saved", keeps the typed values and leaves storage as it was`, async ({ page }) => {
      const seed = seedOf({ daily: [day('2026-11-21', { steps: obs(9000) })] });
      await open(page, seed);
      const before = await raw(page);
      await morning(page);
      await page.getByTestId('mlog-intensity').fill('46'); await page.getByTestId('mlog-sleep').fill('7');
      await page.evaluate(() => { Storage.prototype.setItem = function () { throw new DOMException('quota', 'QuotaExceededError'); }; });
      await page.getByTestId('mlog-save').click();
      await expect(page.getByTestId('mlog-result')).toContainText('NOT saved');
      await expect(page.getByTestId('mlog-result')).not.toContainText('Saved on this device');
      expect(await raw(page)).toBe(before);
      expect(page._errs).toEqual([]);
    });

    test(`${W}: backup and restore carry intensity minutes and the unit; an RC2-style backup without them restores as before`, async ({ page }) => {
      const seed = seedOf({ weight: [{ id: 'w-a', date: '2026-11-20', kg: 98.4, createdAt: T }], daily: [day('2026-11-21', { steps: obs(9000), intensityMin: im(46) })],
        ownerSettings: [{ id: 'app-settings', date: '2026-11-11', createdAt: T, rhrBaselineBpm: 61, stepBaselineMode: 'AUTO', weightUnit: 'lb' }] });
      await open(page, seed);
      await page.getByTestId('tab-settings').click();
      const [dl] = await Promise.all([page.waitForEvent('download'), page.getByTestId('export-btn').click()]);
      const fs = require('fs'); const text = fs.readFileSync(await dl.path(), 'utf8'); const b = JSON.parse(text);
      expect(dl.suggestedFilename()).toBe('hyrox-backup-2026-11-22.json');
      expect(b.version).toBe(2);
      expect(b.daily[0].intensityMin).toEqual(im(46)); expect(b.ownerSettings[0].weightUnit).toBe('lb'); expect(b.weight[0].kg).toBe(98.4);
      // wipe to an RC2-style state, then restore the backup
      await page.evaluate(() => localStorage.setItem('hyrox.v1', JSON.stringify({ version: 2, weight: [], workouts: [], nutrition: [] })));
      await page.reload();
      await page.getByTestId('tab-today').click();
      await expect(page.getByTestId('glance-weight-text')).toHaveText('No weight recorded');
      await page.getByTestId('tab-settings').click();
      await page.getByTestId('import-file').setInputFiles({ name: 'hyrox-backup-2026-11-22.json', mimeType: 'application/json', buffer: Buffer.from(text) });
      await expect(page.getByTestId('import-preview')).toBeVisible();
      await page.getByTestId('import-confirm').click();
      await expect.poll(async () => ((await stored(page)).daily || []).length).toBe(1);
      const s = await stored(page);
      expect(s.daily[0].intensityMin).toEqual(im(46)); expect(s.ownerSettings[0].weightUnit).toBe('lb');
      await page.getByTestId('tab-today').click();
      await expect(page.getByTestId('glance-weight-text')).toContainText('216.9 lb');
      await page.getByTestId('tab-trends').click();
      await expect(page.locator('[data-testid="intensity-week"][data-week="2026-11-16"]')).toHaveAttribute('data-total', '46');
      expect(page._errs).toEqual([]);
    });

    test(`${W}: Today is unchanged — no new card, no morning-log control; the Add bar gains one "Morning" choice and fits the screen`, async ({ page }) => {
      await open(page);
      const today = page.getByTestId('panel-today');
      await expect(today.locator('[data-testid^="mlog-"], [data-testid="morning-form"], [data-testid="trends-intensity"]')).toHaveCount(0);
      await expect(today.getByText(/intensity/i)).toHaveCount(0);
      await page.getByTestId('tab-add').click();
      await expect(page.locator('[data-testid="add-modes"] .seg')).toHaveText(['Meal', 'Workout', 'Weight & waist', 'Check-in', 'Morning', 'Walk', 'Quick log']);
      await page.getByTestId('add-mode-morning').click();
      await expect(page.getByTestId('add-mode-morning')).toHaveAttribute('aria-pressed', 'true');
      await expect(page.getByTestId('weight-card')).toBeHidden(); // the classic cards belong to their own modes
      for (const id of ['mlog-weight', 'mlog-waist', 'mlog-sleep', 'mlog-rhr', 'mlog-steps', 'mlog-intensity']) {
        const el = page.getByTestId(id); await expect(el).toBeVisible();
        const lab = await el.evaluate((n) => { const l = document.querySelector('label[for="' + n.id + '"]'); return l ? l.textContent : ''; });
        expect(lab.length).toBeGreaterThan(3);
      }
      const box = await page.getByTestId('mlog-save').boundingBox(); expect(box.height).toBeGreaterThanOrEqual(40);
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
      expect(page._errs).toEqual([]);
    });
  });
}
