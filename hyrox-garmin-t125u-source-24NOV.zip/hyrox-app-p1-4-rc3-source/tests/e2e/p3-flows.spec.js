'use strict';
// Phase 3 end-to-end flows (synthetic data only; the photo provider is the MOCK TEST provider — no network).
const fs = require('fs');
const path = require('path');
const { test, expect } = require('@playwright/test');
// P0 (22 Nov 2026): the meal diary moved from Today to Add > Meal ("Log meal" on Today opens it). This brings it on screen
// the way the owner does; it does nothing when the diary or a dedicated logger is already showing.
async function diary(page) {
  if (await page.getByTestId('meal-diary').isVisible()) return;
  if (await page.getByTestId('logger-head').isVisible()) return;
  if (!(await page.getByTestId('panel-today').isVisible())) await page.getByTestId('tab-today').click();
  await page.getByTestId('today-add-meal').click();
  await page.getByTestId('meal-diary').waitFor();
}

// P0 (22 Nov 2026): "Meal name" is no longer a routine field; the optional custom name sits in a closed fold.
async function nameField(page) { const f = page.getByTestId('meal-label'); if (!(await f.isVisible())) await page.getByTestId('meal-name-toggle').click(); return f; }

const { openFullPlan, openWhy } = require('./p8-open');

const FIX = path.join(__dirname, '..', 'fixtures');
test.describe.configure({ mode: 'serial' });

test.beforeEach(async ({ page }) => {
  await page.goto('./');
  await page.evaluate(() => localStorage.clear());
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
});

async function setProvider(page, id) {
  await page.getByTestId('tab-settings').click();
  await page.getByTestId('ai-provider-' + id).check();
}

test('tabs switch panels and Today shows the plan honestly', async ({ page }) => {
  await expect(page.getByTestId('panel-today')).toBeVisible();
  await expect(page.getByTestId('block-status')).toBeVisible();
  for (const t of ['add', 'history', 'trends', 'settings', 'today']) {
    await page.getByTestId('tab-' + t).click();
    await expect(page.getByTestId('panel-' + t)).toBeVisible();
  }
  await expect(page.getByTestId('plan-calendar')).toBeHidden(); // Phase 8: the calendar is under "Full plan", closed by default
  await openFullPlan(page);
  await expect(page.getByTestId('plan-calendar')).toBeVisible();
  await expect(page.getByTestId('plan-summary')).toContainText('20 planned weekday sessions');
  await expect(page.getByTestId('plan-summary')).toContainText('numerator rule is an OPEN owner decision');
});

test('photo path with no provider says "not configured" and sends nothing', async ({ page }) => {
  const requests = [];
  page.on('request', (r) => { const u = r.url(); if (/^https?:/.test(u) && !u.startsWith('http://127.0.0.1')) requests.push(u); });
  await page.getByTestId('tab-add').click();
  await page.getByTestId('add-mode-meal').click();
  await page.getByTestId('meal-path-photo_ai').click();
  await page.getByTestId('photo-library-input').setInputFiles(path.join(FIX, 'synthetic-food-exif.jpg'));
  await expect(page.getByTestId('photo-preview')).toBeVisible();
  await expect(page.getByTestId('photo-sanitized')).toContainText('Metadata removed');
  await expect(page.getByTestId('photo-not-configured')).toBeVisible();
  await expect(page.getByTestId('photo-send')).toHaveCount(0);
  expect(requests).toEqual([]);
});

test('MOCK photo analysis -> review -> confirm; photo never stored or exported', async ({ page }) => {
  await setProvider(page, 'mock');
  await page.getByTestId('tab-add').click();
  await page.getByTestId('add-mode-meal').click();
  await page.getByTestId('meal-path-photo_ai').click();
  await page.getByTestId('photo-library-input').setInputFiles(path.join(FIX, 'synthetic-food-exif.jpg'));
  await expect(page.getByTestId('photo-preview')).toBeVisible();
  await page.getByTestId('photo-privacy-ack').click(); // re-renders into the per-photo consent step
  const send = page.getByTestId('photo-send');
  await expect(send).toBeDisabled();
  await page.getByTestId('photo-send-consent').check();
  await expect(send).toBeEnabled();
  await send.click();
  await expect(page.getByTestId('meal-ai-badge')).toContainText('MOCK TEST');
  await expect(page.getByTestId('component-row')).toHaveCount(3);
  // Owner rule 2: a photographed meal is never assumed eaten whole - totals stay unknown until stated.
  await expect(page.getByTestId('meal-total-kcal')).toContainText('unknown');
  await expect(page.getByTestId('meal-eaten-state')).toContainText('Not stated yet');
  await page.getByTestId('meal-eaten-100').click();
  await expect(page.getByTestId('meal-total-kcal')).toContainText('460');
  await expect(page.getByTestId('meal-total-kcal')).toContainText('unknown part');
  // user correction
  await page.getByTestId('component-kcal').nth(1).fill('300');
  await expect(page.getByTestId('meal-total-kcal')).toContainText('520');
  await (await nameField(page)).fill('Synthetic plate');
  await page.getByTestId('meal-confirm').click();
  await expect(page.getByTestId('ext-toast')).toContainText('Saved on this device');
  await expect(page.getByTestId('meal-diary')).toBeVisible(); // P11.1: a confirmed Add > Meal save now returns to the Today diary
  await page.getByTestId('tab-history').click();
  await expect(page.getByTestId('panel-history')).toBeVisible();
  const meal = page.getByTestId('history-meal').filter({ hasText: 'Synthetic plate' });
  await expect(meal.getByTestId('meal-lifecycle')).toHaveText(/Confirmed/);
  await expect(meal.getByTestId('meal-ai-badge')).toContainText('MOCK TEST');
  const dump = await page.evaluate(() => Object.keys(localStorage).map((k) => k + '=' + localStorage.getItem(k)).join('\n'));
  expect(/data:image|\/9j\/|base64/i.test(dump)).toBe(false);
  const raw = JSON.parse(await page.evaluate(() => localStorage.getItem('hyrox.v1')));
  expect(raw.meals[0].ai.mode).toBe('MOCK');
  expect(raw.meals[0].ai.userCorrected).toBe(true);
  expect(raw.meals[0].components[2].kcal).toEqual({ value: null, state: 'UNKNOWN' });
  await page.getByTestId('tab-settings').click();
  const [dl] = await Promise.all([page.waitForEvent('download'), page.getByTestId('export-btn').click()]);
  const text = fs.readFileSync(await dl.path(), 'utf8');
  expect(/data:image|\/9j\//.test(text)).toBe(false);
  expect(JSON.parse(text).meals.length).toBe(1);
});

test('consumed-intent is not counted; day declaration D5 then invalidated by an edit', async ({ page }) => {
  await page.getByTestId('tab-add').click();
  await page.getByTestId('add-mode-meal').click();
  await page.getByTestId('meal-path-manual').click();
  await (await nameField(page)).fill('Oats');
  await page.getByTestId('component-name').fill('Oats');
  await page.getByTestId('component-kcal').fill('350');
  await page.getByTestId('component-proteinG').fill('12');
  await page.getByTestId('meal-consumed-intent').click();
  await page.getByTestId('tab-today').click();
  await expect(page.getByTestId('today-pending')).toBeVisible();
  await openWhy(page);
  await expect(page.getByTestId('today-subtotal')).toContainText('Calories unknown'); // Phase 8 label (was 'kcal unknown')
  await page.getByTestId('tab-history').click();
  await expect(page.getByTestId('attest-complete')).toBeDisabled();
  await page.getByTestId('meal-review').click();
  await page.getByTestId('meal-confirm').click();
  await page.getByTestId('attest-complete').click();
  await expect(page.getByTestId('history-day-state').first()).toContainText('D5');
  await page.getByTestId('meal-edit').click();
  await page.getByTestId('component-kcal').fill('400');
  await page.getByTestId('meal-confirm').click();
  await expect(page.getByTestId('history-day-state').first()).toContainText('D2');
  await expect(page.getByTestId('history-day-stale')).toBeVisible();
});

test('detailed workout from plan slot keeps 960 s overrun, partial + modified independent', async ({ page }) => {
  await page.getByTestId('tab-add').click();
  await page.getByTestId('add-mode-workout').click();
  await page.getByTestId('session-slot').selectOption('v2.1-W1-TUE');
  await expect(page.getByTestId('block-row').first()).toBeVisible();
  await page.getByTestId('session-status').selectOption('PARTIAL');
  await page.getByTestId('session-modified').check();
  const ski = page.getByTestId('block-row').nth(2); // template order: warm-up, R1 run, R1 SkiErg
  await ski.getByTestId('block-durationSec').fill('960');
  await expect(ski.getByTestId('block-compliance')).toHaveText('OVERRUN');
  await page.getByTestId('session-save').click();
  await expect(page.getByTestId('ext-toast')).toContainText('Saved');
  const row = page.getByTestId('history-session').first();
  await expect(row).toContainText('Partial');
  await expect(row).toContainText('Modified');
  await expect(row).toContainText('1 overrun');
  const raw = JSON.parse(await page.evaluate(() => localStorage.getItem('hyrox.v1')));
  expect(raw.sessions[0].blocks.find((b) => b.label === 'Round 1 SkiErg').durationSec).toBe(960);
});

test('SKIPPED needs explicit confirmation', async ({ page }) => {
  await page.getByTestId('tab-add').click();
  await page.getByTestId('add-mode-workout').click();
  await page.getByTestId('session-title').fill('Test skip');
  await page.getByTestId('session-status').selectOption('SKIPPED');
  await page.getByTestId('session-save').click();
  await expect(page.getByTestId('session-error')).toContainText('confirmation');
  await page.getByTestId('session-skip-confirm').check();
  await page.getByTestId('session-save').click();
  await expect(page.getByTestId('history-session').first()).toContainText('Skipped (confirmed)');
});

test('check-in, waist and walk save; readiness flags; steps not double counted', async ({ page }) => {
  await page.getByTestId('tab-add').click();
  await page.getByTestId('add-mode-daily').click();
  await page.getByTestId('daily-steps').fill('7000');
  await page.getByTestId('daily-sleepH').fill('5.5');
  await page.getByTestId('daily-soreness').fill('7');
  await page.getByTestId('daily-submit').click();
  await page.getByTestId('add-mode-walk').click();
  await page.getByTestId('walk-duration').fill('30');
  await page.getByTestId('walk-steps').fill('3000');
  await page.getByTestId('walk-submit').click();
  await page.getByTestId('add-mode-body').click();
  await page.getByTestId('waist-cm').fill('90.5');
  await page.getByTestId('waist-submit').click();
  await page.getByTestId('tab-today').click();
  await expect(page.getByTestId('readiness-guidance')).toContainText('easy movement only');
  await expect(page.getByTestId('today-steps')).toContainText('7,000');
  await page.getByTestId('tab-history').click();
  await expect(page.getByTestId('history-waist')).toContainText('90.5');
  await expect(page.getByTestId('history-walk')).toContainText('info only');
});

test('restore preview shows detailed record counts and Cancel writes nothing', async ({ page }) => {
  await page.getByTestId('tab-add').click();
  await page.getByTestId('add-mode-walk').click();
  await page.getByTestId('walk-duration').fill('25');
  await page.getByTestId('walk-submit').click();
  await page.getByTestId('tab-settings').click();
  const [dl] = await Promise.all([page.waitForEvent('download'), page.getByTestId('export-btn').click()]);
  const p = test.info().outputPath('p3.json');
  await dl.saveAs(p);
  const before = await page.evaluate(() => JSON.stringify(localStorage));
  await page.getByTestId('import-file').setInputFiles(p);
  await expect(page.getByTestId('import-ext-counts')).toContainText('walks 1');
  await page.getByTestId('import-cancel').click();
  expect(await page.evaluate(() => JSON.stringify(localStorage))).toBe(before);
});

test('a failed second photo clears the old preview and Send (no stale UI)', async ({ page }) => {
  await setProvider(page, 'mock');
  await page.getByTestId('tab-add').click();
  await page.getByTestId('add-mode-meal').click();
  await page.getByTestId('meal-path-photo_ai').click();
  await page.getByTestId('photo-library-input').setInputFiles(path.join(FIX, 'synthetic-food-clean.png'));
  await expect(page.getByTestId('photo-preview')).toBeVisible();
  await page.getByTestId('photo-library-input').setInputFiles({ name: 'bad.jpg', mimeType: 'image/jpeg', buffer: Buffer.from('not an image') });
  await expect(page.getByTestId('photo-status')).toContainText('could not be read');
  await expect(page.getByTestId('photo-preview')).toHaveCount(0);
  await expect(page.getByTestId('photo-send')).toHaveCount(0);
});
