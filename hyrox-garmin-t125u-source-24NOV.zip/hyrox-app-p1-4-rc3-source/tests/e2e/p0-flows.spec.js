'use strict';

const fs = require('fs');
const path = require('path');
if (fs.existsSync('/workspace/hyrox-p2/tools/node_modules/@playwright/test')) {
  module.paths.unshift('/workspace/hyrox-p2/tools/node_modules');
}
const { test, expect } = require('@playwright/test');
const {
  SYNTH,
  logFourSynthetic,
  expectFourSyntheticVisible,
  addWeight,
  fixture,
  pickBackup,
  expectPreviewCounts,
  expectImportError,
  gotoClassic,
  gotoSettings,
} = require('./helpers');

test.describe.configure({ mode: 'serial' });

test.beforeEach(async ({ page }, testInfo) => {
  if (testInfo.project.name === 'chromium-substitute') {
    testInfo.annotations.push({ type: 'note', description: 'Chromium substitute, not Safari' });
  }
  await page.goto('./');
  await expect(page.getByTestId('app-error')).toBeHidden();
  await gotoClassic(page);
  await expect(page.getByTestId('weight-form')).toBeVisible();
  await gotoSettings(page);
  await expect(page.getByTestId('import-section')).toBeVisible();
  await expect(page.getByTestId('import-btn')).toBeVisible();
});

test('logs weight, full and partial workouts, and a meal; they persist after reload', async ({ page }) => {
  await logFourSynthetic(page);
  await expectFourSyntheticVisible(page);
  const total = page.getByTestId('nutrition-total');
  await expect(total).toBeVisible();
  // Hook used when the build sets data-date (Liya). Optional if absent on older markup.
  const dated = page.locator('[data-testid="nutrition-total"][data-date]');
  if (await dated.count()) {
    await expect(dated.first()).toBeVisible();
  }
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
  await expectFourSyntheticVisible(page);
});

test('export downloads hyrox-backup-YYYY-MM-DD.json with the logged entries', async ({ page }) => {
  await logFourSynthetic(page);
  await gotoSettings(page);
  const [download] = await Promise.all([
    page.waitForEvent('download'),
    page.getByTestId('export-btn').click(),
  ]);
  const name = download.suggestedFilename();
  expect(name).toMatch(/^hyrox-backup-\d{4}-\d{2}-\d{2}\.json$/);
  const tmp = await download.path();
  expect(tmp).toBeTruthy();
  const raw = fs.readFileSync(tmp, 'utf8');
  const data = JSON.parse(raw);
  expect(data.app).toBe('hyrox-app');
  expect(data.version).toBe(1);
  expect(data.weight.some((e) => e.kg === 72.5)).toBe(true);
  expect(data.workouts.some((e) => e.activity === SYNTH.activityFull && e.partial === false)).toBe(true);
  expect(data.workouts.some((e) => e.activity === SYNTH.activityPartial && e.partial === true)).toBe(true);
  expect(data.nutrition.some((e) => e.label === SYNTH.meal && e.calories === 350 && e.proteinG === 22.5)).toBe(true);
});

test('text, number, date and textarea inputs use font-size of at least 16px', async ({ page }) => {
  const sizes = await page.locator('input[type="text"], input[type="number"], input[type="date"], textarea').evaluateAll((els) =>
    els.map((el) => ({
      testid: el.getAttribute('data-testid') || el.id,
      fontSize: getComputedStyle(el).fontSize,
      px: parseFloat(getComputedStyle(el).fontSize),
    }))
  );
  expect(sizes.length).toBeGreaterThan(0);
  for (const s of sizes) {
    expect(s.px, s.testid + ' font-size ' + s.fontSize).toBeGreaterThanOrEqual(16);
  }
});

test('import preview, cancel leaves data, confirm REPLACE restores the backup, reload holds', async ({ page }) => {
  await logFourSynthetic(page);
  await gotoSettings(page);
  const [download] = await Promise.all([
    page.waitForEvent('download'),
    page.getByTestId('export-btn').click(),
  ]);
  const backupPath = path.join(test.info().outputPath(), 'roundtrip.json');
  await download.saveAs(backupPath);

  page.once('dialog', (d) => d.accept());
  await gotoClassic(page);
  await page.getByTestId('weight-item').getByTestId('weight-delete').first().click();
  await addWeight(page, '80');
  await expect(page.getByTestId('weight-item').filter({ hasText: '80' })).toBeVisible();
  await expect(page.getByTestId('weight-item').filter({ hasText: '72.5' })).toHaveCount(0);

  await pickBackup(page, backupPath);
  await expectPreviewCounts(page, { weight: 1, workouts: 2, nutrition: 1, partial: 1 });
  await expect(page.getByTestId('import-preview-source')).toBeVisible();
  await expect(page.getByTestId('import-current')).toBeVisible();
  await expect(page.getByTestId('import-warning')).toContainText(/replace/i);

  await page.getByTestId('import-cancel').click();
  await expect(page.getByTestId('import-preview')).toBeHidden();
  await expect(page.getByTestId('import-status')).toContainText(/cancelled/i);
  await gotoClassic(page);
  await expect(page.getByTestId('weight-item').filter({ hasText: '80' })).toBeVisible();
  await expect(page.getByTestId('weight-item').filter({ hasText: '72.5' })).toHaveCount(0);

  // After cancel (and after any confirm) the file text is discarded — must re-pick.
  await pickBackup(page, backupPath);
  await expectPreviewCounts(page, { weight: 1, workouts: 2, nutrition: 1, partial: 1 });
  await page.getByTestId('import-confirm').click();
  await expect(page.getByTestId('import-result')).toContainText(/restored/i);
  await expect(page.getByTestId('import-preview')).toBeHidden();
  await expectFourSyntheticVisible(page);
  await expect(page.getByTestId('weight-item').filter({ hasText: '80' })).toHaveCount(0);
  await gotoSettings(page);
  const note = page.getByTestId('import-backup-note');
  await expect(note).toBeVisible();
  await expect(note).toContainText(/kept/i);
  await expect(note).not.toContainText(/previous data restored/i);
  await expect(page.locator('[data-testid="import-undo"]')).toHaveCount(0);

  await page.reload();
  await expectFourSyntheticVisible(page);
  await expect(page.getByTestId('weight-item').filter({ hasText: '80' })).toHaveCount(0);
});

test('truncated, wrong-version and missing-app files are refused without data loss', async ({ page }) => {
  await logFourSynthetic(page);

  async function refuse(file, label) {
    await pickBackup(page, file);
    await expectImportError(page);
    const message = (await page.getByTestId('import-error-message').innerText()).toLowerCase();
    expect(message, label + ' message: ' + message).toMatch(/not accepted|not restored|could not|failed|invalid|unsupported|version|json|hyrox|read/);
    await expectFourSyntheticVisible(page);
  }

  await refuse(fixture('bad-truncated.json'), 'truncated');
  await refuse(fixture('wrong-version.json'), 'wrong version');
  await refuse(fixture('missing-app.json'), 'missing app');
});

test('a good backup (including one without a .json name) is accepted; script text does not run', async ({ page }) => {
  await addWeight(page, '80');
  await expect(page.getByTestId('weight-item').filter({ hasText: '80' })).toBeVisible();

  await pickBackup(page, fixture('good-backup'));
  await expectPreviewCounts(page, { weight: 1, workouts: 2, nutrition: 1, partial: 1 });
  await page.getByTestId('import-confirm').click();
  await expect(page.getByTestId('import-result')).toContainText(/restored/i);
  await expectFourSyntheticVisible(page);
  await expect(page.getByTestId('weight-item').filter({ hasText: '80' })).toHaveCount(0);

  // After confirm the file text is discarded; re-pick the same backup to retry.
  await pickBackup(page, fixture('good-backup.json'));
  await expectPreviewCounts(page, { weight: 1, workouts: 2, nutrition: 1, partial: 1 });
  await expect(page.getByTestId('import-replaced-backup')).toBeVisible();
  await page.getByTestId('import-confirm').click();
  await expect(page.getByTestId('import-result')).toContainText(/restored/i);
  await expect(page.getByTestId('weight-item')).toHaveCount(1);
  await expect(page.getByTestId('workout-item')).toHaveCount(2);
  await expect(page.getByTestId('nutrition-item')).toHaveCount(1);

  // Valid file with HTML/script in notes/labels: accepted as data, rendered inertly (textContent).
  const dialogs = [];
  page.on('dialog', (d) => { dialogs.push(d.message()); d.dismiss(); });
  await page.evaluate(() => { window.__xss = 0; });
  await pickBackup(page, fixture('script-notes.json'));
  await expectPreviewCounts(page, { weight: 1, workouts: 2, nutrition: 1, partial: 1 });
  await page.getByTestId('import-confirm').click();
  await expect(page.getByTestId('import-result')).toContainText(/restored/i);
  const xss = await page.evaluate(() => window.__xss);
  expect(xss, 'payload must not execute').not.toBe(1);
  expect(dialogs, 'no dialog may fire').toEqual([]);
  await gotoClassic(page);
  await expect(page.getByTestId('workout-item').filter({ hasText: '<script>' })).toBeVisible();
  await expect(page.getByTestId('nutrition-item').filter({ hasText: '<img' })).toBeVisible();
  await expect(page.locator('script').filter({ hasText: 'window.__xss' })).toHaveCount(0);
  await expect(page.locator('img[src="x"]')).toHaveCount(0);
});
