'use strict';
// Phase 11.3: data with fiber/sodium opened, edited and re-exported by OLDER app versions on the SAME origin (same
// localStorage), then reopened in 11.3. /new/ = this tree, /c112/ = Claude P11.2, /p11/ = Claude P11, /p10b/ = P10b.
// Own 127.0.0.1 static server (port HYROX_OLDUI_PORT, default 4492). CHROME MOBILE EMULATION, NOT SAFARI/WEBKIT.
const { test, expect } = require('@playwright/test');
// P0 (22 Nov 2026): "Meal name" is no longer a routine field; the optional custom name sits in a closed fold.
async function nameField(page) { const f = page.getByTestId('meal-label'); if (!(await f.isVisible())) await page.getByTestId('meal-name-toggle').click(); return f; }

const fs = require('fs'), os = require('os'), path = require('path'), { spawn } = require('child_process');
const PORT = Number(process.env.HYROX_OLDUI_PORT || 4492), BASE = 'http://127.0.0.1:' + PORT;
const TREES = { new: process.env.HYROX_APP_ROOT || path.join(__dirname, '..', '..'),
  c112: process.env.P113_P112_ROOT || '/workspace/hyrox-p11-3-before',
  p11: process.env.P113_P11_ROOT || '/workspace/hyrox-p11-2-before',
  p10b: process.env.P113_P10B_ROOT || '/workspace/hyrox-p11-before' };
const NOW = '2026-11-19T09:00:00.000Z', T = '2026-11-19T08:00:00.000Z';
const K = (v) => ({ value: v, state: 'KNOWN' }), E = (v) => ({ value: v, state: 'ESTIMATED' });
const EGG = { name: 'Egg, whole, boiled or poached', role: 'OTHER', portion: '4 × 1 egg (200 g)', preparation: '', eatenFraction: null,
  kcal: E(286), proteinG: E(24.8), carbsG: E(1.9), fatG: E(19.9),
  provenance: { source: 'USDA_FDC', dataset: 'FN', fdcId: 2707154, description: 'Egg, whole, boiled or poached', portion: '4 × 1 egg (200 g)', grams: 200, dbVersion: 'usda-fndds-2021-2023-fdc-2024-10-31+fs-srlegacy-2018-04-foundation-2026-10-29' },
  fiberG: E(0), sodiumMg: E(258) }; // exactly what 11.3 Add foods stores for 4 eggs
const TOAST = { name: 'Toast', role: 'MAIN', portion: '', preparation: '', eatenFraction: null, kcal: K(160), proteinG: K(5), carbsG: K(30), fatG: K(2), fiberG: K(2.5) };
const MEAL = { id: 'm-egg', createdAt: T, updatedAt: T, date: '2026-11-19', time: '08:00', label: 'Eggs & toast', source: 'MANUAL', description: '', eatenFraction: 1, lifecycle: 'CONFIRMED', confirmedAt: T, ai: null, mealCategory: 'BREAKFAST', components: [EGG, TOAST] };
const SEED = { version: 2, weight: [], workouts: [], nutrition: [], meals: [MEAL],
  ownerSettings: [{ id: 'app-settings', date: '2026-11-18', createdAt: T, myFoods: [{ id: 'mf-1', name: 'Fries (US app value)', portion: '1 medium', kcal: K(320), proteinG: K(4), carbsG: K(43), fatG: K(15), sodiumMg: K(260), basis: 'your values', savedAt: T, fromMealId: null }], favFoods: ['my:mf-1'], planBlocks: [{ id: 'pb-future', note: 'unknown future settings field (Phase 12)' }] }] };
let server, root;

test.beforeAll(async () => {
  root = fs.mkdtempSync(path.join(os.tmpdir(), 'p113-mixed-'));
  for (const [k, v] of Object.entries(TREES)) { if (!fs.existsSync(path.join(v, 'index.html'))) throw new Error('missing tree ' + v); fs.symlinkSync(v, path.join(root, k)); }
  server = spawn(process.execPath, [path.join(__dirname, '..', 'static-server.js')], { env: Object.assign({}, process.env, { HYROX_APP_ROOT: root, HYROX_APP_PORT: String(PORT) }), stdio: 'ignore' });
  for (let i = 0; i < 50; i++) { try { const r = await fetch(BASE + '/new/index.html'); if (r.ok) return; } catch (e) { /* wait */ } await new Promise((r) => setTimeout(r, 100)); }
  throw new Error('mixed server did not start');
});
test.afterAll(() => { if (server) server.kill(); if (root) fs.rmSync(root, { recursive: true, force: true }); });

async function go(page, tree, seed) {
  await page.clock.setFixedTime(new Date(NOW));
  await page.goto(BASE + '/' + tree + '/index.html');
  if (seed) { await page.evaluate((d) => { localStorage.clear(); localStorage.setItem('hyrox.v1', JSON.stringify(d)); }, seed); await page.reload(); }
  await expect(page.getByTestId('app-error')).toBeHidden();
}
const stored = async (page) => JSON.parse((await page.evaluate(() => localStorage.getItem('hyrox.v1'))) || '{}');
async function exportFile(page) {
  await page.getByTestId('tab-settings').click();
  const [dl] = await Promise.all([page.waitForEvent('download'), page.getByTestId('export-btn').click()]);
  return fs.readFileSync(await dl.path(), 'utf8');
}

for (const W of [390, 320]) {
  test.describe(`P11.3 older-UI round trip ${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`${W}: Claude P11.2 UI: a label-only edit and an export keep fiber/sodium; 11.3 then shows the same totals`, async ({ page }) => {
      const errs = []; page.on('pageerror', (e) => errs.push(e.message));
      await go(page, 'new', SEED);
      await expect(page.getByTestId('diary-fiber')).toHaveText('Fiber: 2.5 g so far (2 of 2 items known, estimates included)');
      await expect(page.getByTestId('diary-sodium')).toHaveText('Sodium: 258 mg known subtotal — incomplete (1 of 2 items known, estimates included)');
      await go(page, 'c112');
      await page.getByTestId('tab-history').click(); await page.getByTestId('meal-edit').click();
      await (await nameField(page)).fill('Eggs & toast (edited in P11.2)'); await page.getByTestId('meal-confirm').click();
      const m = (await stored(page)).meals[0];
      expect([m.label, m.components[0].fiberG, m.components[0].sodiumMg, m.components[1].fiberG, m.components[0].provenance.fdcId]).toEqual(['Eggs & toast (edited in P11.2)', E(0), E(258), K(2.5), 2707154]);
      expect((await stored(page)).ownerSettings[0].myFoods[0].sodiumMg).toEqual(K(260));
      const exp = JSON.parse(await exportFile(page));
      expect(exp.meals[0].components[0].sodiumMg).toEqual(E(258)); expect(exp.version).toBe(2);
      await go(page, 'new');
      await expect(page.getByTestId('diary-sodium')).toHaveText('Sodium: 258 mg known subtotal — incomplete (1 of 2 items known, estimates included)');
      expect(errs).toEqual([]);
    });

    test(`${W}: KNOWN RISK (documented): in the Claude P11.2 UI, changing the egg's kcal drops its USDA note but keeps the old fiber/sodium; 11.3 shows them as before (no crash, still labelled estimate)`, async ({ page }) => {
      await go(page, 'c112', SEED);
      await page.getByTestId('tab-history').click(); await page.getByTestId('meal-edit').click();
      await page.getByTestId('component-kcal').first().fill('300'); await page.getByTestId('meal-confirm').click();
      const c = (await stored(page)).meals[0].components[0];
      expect([c.kcal.value, 'provenance' in c, c.sodiumMg]).toEqual([300, false, E(258)]); // older code cannot know about the new fields
      await go(page, 'new');
      await expect(page.getByTestId('diary-sodium')).toContainText('258 mg');
      await expect(page.getByTestId('diary-sodium')).toContainText('estimates included');
    });

    for (const tree of ['p11', 'p10b']) {
      test(`${W}: rollback to ${tree === 'p11' ? 'Claude P11 (b8275adb…)' : 'P10b (da206f89…)'} opens 11.3 data, edits a label, exports — fiber/sodium and saved foods survive, back in 11.3 unchanged`, async ({ page }) => {
        const errs = []; page.on('pageerror', (e) => errs.push(e.message));
        await go(page, tree, SEED);
        await page.getByTestId('tab-history').click(); await page.getByTestId('meal-edit').click();
        await (await nameField(page)).fill('Edited in ' + tree); await page.getByTestId('meal-confirm').click();
        const exp = JSON.parse(await exportFile(page));
        expect([exp.meals[0].label, exp.meals[0].source, exp.meals[0].components[0].sodiumMg, exp.meals[0].components[1].fiberG]).toEqual(['Edited in ' + tree, 'MANUAL', E(258), K(2.5)]);
        expect((await stored(page)).ownerSettings[0].myFoods[0].sodiumMg).toEqual(K(260));
        expect((await stored(page)).ownerSettings[0].planBlocks).toEqual(SEED.ownerSettings[0].planBlocks);
        await go(page, 'new');
        await expect(page.getByTestId('diary-fiber')).toHaveText('Fiber: 2.5 g so far (2 of 2 items known, estimates included)');
        expect(errs).toEqual([]);
      });
    }
  });
}
