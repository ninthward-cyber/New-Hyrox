'use strict';
// Phase 10b (owner P0, 18 Nov 2026): after a successful save the Add Meal form returns to an EMPTY draft; nothing of a
// saved meal (items, note, amounts, estimate, photos, consent, request id, messages) leaks into the next one; saved
// meals are never deleted; an unsaved draft is kept across tabs and never discarded without asking; a failed save
// keeps everything; Asia/Qatar midnight shows the new day. Synthetic data. CHROME EMULATION, NOT SAFARI/WEBKIT.
const fs = require('fs');
const path = require('path');
const { test, expect } = require('@playwright/test');
// P0 (22 Nov 2026): the meal diary moved from Today to Add > Meal ("Log meal" on Today opens it). This brings it on screen
// the way the owner does; it does nothing when the diary or a dedicated logger is already showing.
async function diary(page) {
  if (await page.getByTestId('meal-diary').isVisible()) return;
  if (await page.getByTestId('logger-head').isVisible()) return;
  if (!(await page.getByTestId('panel-today').isVisible())) await page.getByTestId('tab-today').click();
  await page.getByTestId('today-add-meal').click();
  await page.getByTestId('meal-diary').waitFor();
}

// P0 (22 Nov 2026): "Meal name" is no longer a routine field; the optional custom name sits in a closed fold.
async function nameField(page) { const f = page.getByTestId('meal-label'); if (!(await f.isVisible())) await page.getByTestId('meal-name-toggle').click(); return f; }


const FIX = path.join(__dirname, '..', 'fixtures');
const F = (n) => path.join(FIX, n);
let H;
test.beforeAll(() => {
  const out = path.join(__dirname, '..', 'out', 'p9-helpers.bundle.cjs');
  const esbuild = process.env.P9_ESBUILD || (() => { try { return require.resolve('esbuild/bin/esbuild'); } catch (e) { return '/workspace/p9-tools/node_modules/.bin/esbuild'; } })();
  require('child_process').execFileSync(esbuild, [path.join(__dirname, '..', 'p9-helpers.mjs'), '--bundle', '--platform=node', '--format=cjs', '--log-level=error', '--define:import.meta.url=' + JSON.stringify(require('url').pathToFileURL(path.join(__dirname, '..', 'p9-helpers.mjs')).href), '--outfile=' + out]);
  H = require(out);
});
async function installApi(page, opts = {}) {
  const ctx = H.setup({ script: opts.script || (() => H.openaiOk()), env: opts.env || {}, clock: { t: Date.UTC(2026, 10, 18, 6, 0, 0) } });
  const seen = [];
  await page.route('**/api/food-photo/**', async (route) => {
    const r = route.request();
    seen.push({ url: r.url(), method: r.method(), body: r.postData() });
    if (opts.delayMs && r.method() === 'POST') await new Promise((res) => setTimeout(res, opts.delayMs));
    const req = new Request(r.url(), { method: r.method(), headers: r.headers(), body: r.method() === 'GET' ? undefined : r.postData() });
    const res = await ctx.handle(req, { ip: '203.0.113.5' });
    try { await route.fulfill({ status: res.status, headers: Object.fromEntries(res.headers), body: await res.text() }); } catch (e) { /* page moved on */ }
  });
  return { ctx, seen };
}
const NOW = '2026-11-18T09:00:00.000Z'; // 12:00 Asia/Qatar
async function open(page, at = NOW) {
  page._errs = []; page.on('pageerror', (e) => page._errs.push(e.message));
  await page.clock.setFixedTime(new Date(at));
  await page.goto('./');
  await page.evaluate(() => localStorage.clear());
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
}
const noErrors = (page) => expect(page._errs).toEqual([]);
const meals = (page) => page.evaluate(() => (JSON.parse(localStorage.getItem('hyrox.v1') || '{}').meals) || []);
const posts = (seen) => seen.filter((s) => s.method === 'POST' && /analyze/.test(s.url)).map((s) => JSON.parse(s.body));
async function toAddMeal(page) { await page.getByTestId('tab-add').click(); await page.getByTestId('add-mode-meal').click(); }
async function manualMeal(page, label, kcal, note) {
  await page.getByTestId('meal-path-manual').click();
  await (await nameField(page)).fill(label);
  if (note) await page.getByTestId('meal-description').fill(note);
  await page.getByTestId('component-name').first().fill(label + ' item');
  await page.getByTestId('component-kcal').first().fill(String(kcal));
}
async function expectEmptyForm(page) {
  await expect(page.getByTestId('meal-form')).toContainText('Add a meal');
  await expect(page.getByTestId('meal-label')).toHaveValue('');
  await expect(page.getByTestId('meal-description')).toHaveValue('');
  await expect(page.getByTestId('photo-preview')).toHaveCount(0);
  await expect(page.getByTestId('photo-send-consent')).toHaveCount(0);
  await expect(page.getByTestId('meal-review-box')).toHaveCount(0);
  await expect(page.getByTestId('photo-estimate-stale')).toHaveCount(0);
  await expect(page.getByTestId('photo-error-details')).toHaveCount(0);
  await expect(page.getByTestId('meal-error')).toHaveText('');
  const names = await page.getByTestId('component-name').evaluateAll((els) => els.map((e) => e.value));
  expect(names.every((v) => v === '')).toBe(true);
  const kcals = await page.getByTestId('component-kcal').evaluateAll((els) => els.map((e) => e.value));
  expect(kcals.every((v) => v === '')).toBe(true);
}

for (const W of [390, 320]) {
  test.describe(`P10b meal reset ${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`${W}: two meals in succession — Add -> save -> Add shows an EMPTY draft; the second meal is saved as its own record`, async ({ page }) => {
      await open(page);
      await toAddMeal(page);
      await manualMeal(page, 'Synthetic oats', 300, 'oats with milk');
      await page.getByTestId('meal-confirm').click();
      await expect(page.getByTestId('meal-diary')).toBeVisible(); // P11.1: a confirmed Add > Meal save now returns to the Today diary
      await page.getByTestId('tab-history').click();
      await expect(page.getByTestId('panel-history')).toBeVisible();
      await page.getByTestId('tab-add').click();
      await expectEmptyForm(page);
      await manualMeal(page, 'Synthetic rice', 450, 'rice bowl');
      await page.getByTestId('meal-confirm').click();
      await page.getByTestId('tab-add').click();
      await expectEmptyForm(page);
      // and once more from Today's "Log meal"
      await page.getByTestId('tab-today').click();
      await page.getByTestId('today-add-meal').click();
      await expectEmptyForm(page);
      const m = await meals(page);
      expect(m.map((x) => [x.label, x.description, x.components[0].kcal.value, x.lifecycle])).toEqual([['Synthetic oats', 'oats with milk', 300, 'CONFIRMED'], ['Synthetic rice', 'rice bowl', 450, 'CONFIRMED']]);
      expect(new Set(m.map((x) => x.id)).size).toBe(2);
      await page.getByTestId('tab-today').click();
      await expect(page.getByTestId('today-subtotal')).toContainText('750');
      noErrors(page);
    });

    test(`${W}: draft and "I ate this" saves also reset; saved meals are never deleted`, async ({ page }) => {
      await open(page);
      await toAddMeal(page);
      await manualMeal(page, 'Draft A', 100);
      await page.getByTestId('meal-save-draft').click();
      await page.getByTestId('tab-add').click();
      await expectEmptyForm(page);
      await manualMeal(page, 'Intent B', 200);
      await page.getByTestId('meal-consumed-intent').click();
      await page.getByTestId('tab-add').click();
      await expectEmptyForm(page);
      expect((await meals(page)).map((x) => [x.label, x.lifecycle])).toEqual([['Draft A', 'DRAFT'], ['Intent B', 'CONSUMED_INTENT']]);
      noErrors(page);
    });

    test(`${W}: edit an old meal -> save -> new meal: the edit is loaded on purpose, saved to the same record, and nothing leaks into the next meal`, async ({ page }) => {
      await open(page);
      await toAddMeal(page);
      await manualMeal(page, 'Old lunch', 500, 'old note');
      await page.getByTestId('meal-confirm').click();
      await expect(page.getByTestId('meal-diary')).toBeVisible(); // P11.1: a confirmed Add > Meal save now returns to the Today diary
      await page.getByTestId('tab-history').click();
      await page.getByTestId('history-meal').filter({ hasText: 'Old lunch' }).getByTestId('meal-edit').click();
      await expect(page.getByTestId('meal-form')).toContainText('Edit meal');
      await expect(page.getByTestId('meal-label')).toHaveValue('Old lunch');
      await page.getByTestId('component-kcal').first().fill('550');
      await page.getByTestId('meal-confirm').click();
      await page.getByTestId('tab-add').click();
      await expectEmptyForm(page);
      await manualMeal(page, 'New dinner', 600);
      await page.getByTestId('meal-confirm').click();
      const m = await meals(page);
      expect(m.map((x) => [x.label, x.components[0].kcal.value])).toEqual([['Old lunch', 550], ['New dinner', 600]]);
      noErrors(page);
    });

    test(`${W}: an unsaved draft survives tab navigation; leaving it for a new meal asks first (cancel keeps it, OK clears it)`, async ({ page }) => {
      await open(page);
      await toAddMeal(page);
      await manualMeal(page, 'Half typed', 250, 'keep me');
      for (const t of ['tab-today', 'tab-history', 'tab-trends', 'tab-settings', 'tab-add']) await page.getByTestId(t).click();
      await expect(page.getByTestId('meal-label')).toHaveValue('Half typed');
      await expect(page.getByTestId('meal-description')).toHaveValue('keep me');
      await expect(page.getByTestId('component-kcal').first()).toHaveValue('250');
      await page.getByTestId('tab-today').click();
      let asked = 0; // Claude P10b review: the prompt is an in-app dialog (window.confirm can stop working in iOS Safari)
      // P0 (22 Nov 2026): "Log meal" opens the diary with the unfinished entry still under it - nothing is asked or dropped yet.
      await page.getByTestId('today-add-meal').click();
      await expect(page.getByTestId('choice-dialog')).toBeHidden();
      await expect(page.getByTestId('meal-label')).toHaveValue('Half typed');
      // starting a NEW meal from the diary is what would replace it, so that is where the question comes
      await page.getByTestId('diary-log-lunch').click();
      await expect(page.getByTestId('choice-title')).toContainText('Discard the meal you have not saved yet'); asked++;
      await page.getByTestId('choice-keep').click();
      expect(asked).toBe(1);
      await expect(page.getByTestId('meal-label')).toHaveValue('Half typed');
      await page.getByTestId('tab-today').click();
      await page.getByTestId('today-add-meal').click();
      await page.getByTestId('diary-log-lunch').click();
      await expect(page.getByTestId('choice-dialog')).toBeVisible(); asked++;
      await page.getByTestId('choice-yes').click();
      expect(asked).toBe(2);
      await expectEmptyForm(page);
      expect(await meals(page)).toEqual([]);
      // switching the input path with typed content also asks
      await manualMeal(page, 'Typed', 100);
      await page.getByTestId('meal-path-description').click();
      await expect(page.getByTestId('choice-dialog')).toBeVisible(); asked++;
      await page.getByTestId('choice-keep').click();
      expect(asked).toBe(3);
      await expect(page.getByTestId('meal-label')).toHaveValue('Typed');
      noErrors(page);
    });

    test(`${W}: a failed save keeps every input and the photos; the next try saves once`, async ({ page }) => {
      await open(page);
      await page.getByTestId('tab-settings').click();
      await page.getByTestId('ai-provider-mock').check();
      await toAddMeal(page);
      await page.getByTestId('meal-path-photo_ai').click();
      await page.getByTestId('meal-description').fill('chicken and rice');
      await page.getByTestId('photo-library-input').setInputFiles([F('p10-view-a.jpg'), F('p10-view-b.jpg')]);
      await expect(page.getByTestId('photo-preview')).toHaveCount(2);
      await page.getByTestId('photo-privacy-ack').click();
      await page.getByTestId('photo-send-consent').check();
      await page.getByTestId('photo-send').click();
      await expect(page.getByTestId('component-row')).toHaveCount(3);
      await page.getByTestId('meal-eaten-100').click();
      await page.evaluate(() => { const orig = Storage.prototype.setItem; window.__origSet = orig; Storage.prototype.setItem = function (k, v) { if (k === 'hyrox.v1') { const e = new Error('quota'); e.name = 'QuotaExceededError'; throw e; } return orig.call(this, k, v); }; });
      await page.getByTestId('meal-confirm').click();
      await expect(page.getByTestId('meal-error')).toContainText('Not saved');
      await expect(page.getByTestId('meal-description')).toHaveValue('chicken and rice');
      await expect(page.getByTestId('photo-preview')).toHaveCount(2);
      await expect(page.getByTestId('component-row')).toHaveCount(3);
      expect(await meals(page)).toEqual([]);
      await page.evaluate(() => { Storage.prototype.setItem = window.__origSet; });
      await page.getByTestId('meal-confirm').click();
      await page.getByTestId('tab-add').click();
      await expectEmptyForm(page);
      expect(await meals(page)).toHaveLength(1);
      noErrors(page);
    });

    for (const n of [1, 2, 3]) {
      test(`${W}: ${n}-photo analysis (real server code, stubbed OpenAI) -> confirm -> new meal starts empty with a NEW request id`, async ({ page }) => {
        const { ctx, seen } = await installApi(page);
        await open(page);
        await page.getByTestId('tab-settings').click();
        await page.getByTestId('ai-provider-live').check();
        await page.getByTestId('ai-owner-code').fill(H.OWNER_CODE);
        await page.getByTestId('ai-owner-code-save').click();
        const files = [F('p10-view-a.jpg'), F('p10-view-b.jpg'), F('p10-view-c.jpg')].slice(0, n);
        for (const round of [1, 2]) {
          await toAddMeal(page);
          if (round === 2) await expectEmptyForm(page);
          await page.getByTestId('meal-path-photo_ai').click();
          await page.getByTestId('meal-description').fill('rice and dal');
          await page.getByTestId('photo-library-input').setInputFiles(files);
          await expect(page.getByTestId('photo-preview')).toHaveCount(n);
          if (round === 1) await page.getByTestId('photo-privacy-ack').click();
          await expect(page.getByTestId('photo-send-consent')).not.toBeChecked(); // consent is per request, never carried over
          await page.getByTestId('photo-send-consent').check();
          await page.getByTestId('photo-send').click();
          await expect(page.getByTestId('component-row')).toHaveCount(3);
          // Re-pointed by the P0 sprint photo + note fix (23 Nov 2026): the stubbed model returns chicken/rice/oil, so "dal" from the
          // note is now flagged "not accounted for" and must be acknowledged before Confirm (this test is about the meal lifecycle).
          await expect(page.getByTestId('unaccounted-item')).toHaveCount(1);
          await page.getByTestId('unaccounted-ack').click();
          await page.getByTestId('meal-eaten-100').click();
          await page.getByTestId('meal-confirm').click();
          await expect(page.getByTestId('meal-diary')).toBeVisible(); // P11.1: a confirmed Add > Meal save now returns to the Today diary
          await page.getByTestId('tab-history').click();
          await expect(page.getByTestId('panel-history')).toBeVisible();
        }
        await page.getByTestId('tab-add').click();
        await expectEmptyForm(page);
        const p = posts(seen);
        expect(p).toHaveLength(2); // one request per analysis, no retries
        expect(p[0].requestId).not.toBe(p[1].requestId); // same photos + note in a NEW meal = a new, separately consented call
        expect(ctx.fetchStub.calls).toHaveLength(2);
        const m = await meals(page);
        expect(m).toHaveLength(2);
        expect(m.every((x) => x.components.length === 3)).toBe(true);
        const raw = await page.evaluate(() => localStorage.getItem('hyrox.v1'));
        expect(/data:image|imageBase64|\/9j\//.test(raw)).toBe(false);
        noErrors(page);
      });
    }

    test(`${W}: an estimate that arrives after its draft was replaced is NOT put into the new meal`, async ({ page }) => {
      const { seen } = await installApi(page, { delayMs: 1500 });
      await open(page);
      await page.getByTestId('tab-settings').click();
      await page.getByTestId('ai-provider-live').check();
      await page.getByTestId('ai-owner-code').fill(H.OWNER_CODE);
      await page.getByTestId('ai-owner-code-save').click();
      await toAddMeal(page);
      await page.getByTestId('meal-path-photo_ai').click();
      await page.getByTestId('photo-library-input').setInputFiles([F('p10-view-a.jpg'), F('p10-view-b.jpg')]);
      await page.getByTestId('photo-privacy-ack').click();
      await page.getByTestId('photo-send-consent').check();
      await page.getByTestId('photo-send').click();
      await page.getByTestId('tab-today').click();
      await page.getByTestId('today-add-meal').click();
      await page.getByTestId('diary-log-lunch').click(); // P0: a new meal is started from the diary
      await page.getByTestId('choice-yes').click(); // Claude P10b review: in-app dialog (was window.confirm)
      await page.waitForTimeout(2500);
      await expectEmptyForm(page);
      await expect(page.getByTestId('component-row')).toHaveCount(1);
      expect(posts(seen)).toHaveLength(1);
      expect(await meals(page)).toEqual([]);
      noErrors(page);
    });

    test(`${W}: a HEIC the browser cannot decode is refused with a clear message, nothing is sent, the typed draft stays; cancelling the picker changes nothing`, async ({ page }) => {
      const { seen } = await installApi(page);
      await open(page);
      await page.getByTestId('tab-settings').click();
      await page.getByTestId('ai-provider-live').check();
      await page.getByTestId('ai-owner-code').fill(H.OWNER_CODE);
      await page.getByTestId('ai-owner-code-save').click();
      await toAddMeal(page);
      await page.getByTestId('meal-path-photo_ai').click();
      await page.getByTestId('meal-description').fill('lentil soup');
      await page.getByTestId('photo-library-input').setInputFiles([F('p10-view-a.jpg'), F('p10-view-b.jpg')]);
      await expect(page.getByTestId('photo-preview')).toHaveCount(2);
      // picker opened and cancelled: no files -> nothing changes
      await page.getByTestId('photo-library-input').setInputFiles([]);
      await expect(page.getByTestId('photo-preview')).toHaveCount(2);
      await expect(page.getByTestId('meal-description')).toHaveValue('lentil soup');
      // Chrome cannot decode HEIC (Safari can; owner-device gate): the failure is explicit and fails closed
      await page.getByTestId('photo-library-input').setInputFiles({ name: 'IMG_0001.HEIC', mimeType: 'image/heic', buffer: fs.readFileSync(F('p9-fake.heic')) });
      await expect(page.getByTestId('photo-status')).toContainText(/could not be read|could not be prepared|not supported|HEIC/i);
      await expect(page.getByTestId('photo-send')).toHaveCount(0);
      await expect(page.getByTestId('meal-description')).toHaveValue('lentil soup');
      expect(posts(seen)).toHaveLength(0);
      expect(await meals(page)).toEqual([]);
      noErrors(page);
    });

    test(`${W}: Asia/Qatar midnight — Today and an untouched new-meal draft move to the new date; an unsaved draft keeps its date`, async ({ page }) => {
      await open(page, '2026-11-18T20:59:00.000Z'); // 23:59 Qatar, Wed 18 Nov
      await expect(page.getByTestId('today-card')).toContainText('Wed 18 Nov');
      await toAddMeal(page);
      await page.getByTestId('meal-path-manual').click();
      await expect(page.getByTestId('meal-date')).toHaveValue('2026-11-18');
      await page.clock.setFixedTime(new Date('2026-11-18T21:00:30.000Z')); // 00:00:30 Qatar, Thu 19 Nov
      await page.getByTestId('tab-today').click();
      await expect(page.getByTestId('today-card')).toContainText('Thu 19 Nov');
      await expect(page.getByTestId('today-card')).not.toContainText('Wed 18 Nov');
      await page.getByTestId('tab-add').click();
      await expect(page.getByTestId('meal-date')).toHaveValue('2026-11-19');
      // an unsaved draft started before midnight keeps its (visible, editable) date
      await manualMeal(page, 'Late snack', 150);
      await page.clock.setFixedTime(new Date('2026-11-19T21:00:30.000Z')); // next midnight
      await page.evaluate(() => document.dispatchEvent(new Event('visibilitychange')));
      await expect(page.getByTestId('meal-label')).toHaveValue('Late snack');
      await expect(page.getByTestId('meal-date')).toHaveValue('2026-11-19');
      await page.getByTestId('tab-today').click();
      await expect(page.getByTestId('today-card')).toContainText('Fri 20 Nov');
      noErrors(page);
    });

    test(`${W}: History, export, restore and reopen show each meal once with the same totals`, async ({ page }) => {
      await open(page);
      await toAddMeal(page);
      await manualMeal(page, 'Meal one', 300);
      await page.getByTestId('meal-confirm').click();
      await page.getByTestId('tab-add').click();
      await manualMeal(page, 'Meal two', 400);
      await page.getByTestId('meal-confirm').click();
      await expect(page.getByTestId('history-meal')).toHaveCount(2);
      await page.getByTestId('tab-settings').click();
      const [dl] = await Promise.all([page.waitForEvent('download'), page.getByTestId('export-btn').click()]);
      const file = await dl.path();
      const text = fs.readFileSync(file, 'utf8');
      expect(JSON.parse(text).meals.map((x) => x.label)).toEqual(['Meal one', 'Meal two']);
      await page.evaluate(() => localStorage.clear());
      await page.reload();
      await page.getByTestId('tab-settings').click();
      await page.getByTestId('import-file').setInputFiles(file);
      await page.getByTestId('import-confirm').click();
      await expect(page.getByTestId('import-result')).toBeVisible();
      await page.reload();
      await page.getByTestId('tab-history').click();
      await expect(page.getByTestId('history-meal')).toHaveCount(2);
      await page.getByTestId('tab-today').click();
      await expect(page.getByTestId('today-subtotal')).toContainText('700');
      expect((await meals(page)).map((x) => x.label)).toEqual(['Meal one', 'Meal two']);
      await page.getByTestId('tab-add').click();
      await page.getByTestId('add-mode-meal').click();
      await expectEmptyForm(page);
      noErrors(page);
    });
  });
}
