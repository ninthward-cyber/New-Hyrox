'use strict';
// Meron adversarial P4-O1 UI: try to bypass the empty-backup second confirmation.
// Byte-exact localStorage comparisons. Chrome emulation, not Safari/WebKit.
const { test, expect } = require('@playwright/test');
const { boot, pick, snapshot, EMPTY, ONE } = require('./p5-meron-e2e-lib');

test.describe('P4-O1 adversarial UI gate (Chrome emulation, not Safari/WebKit)', () => {
  test('tick then untick: Replace returns to disabled and writes nothing', async ({ page }) => {
    await boot(page, { seed: 'populated' });
    const before = await snapshot(page);
    await pick(page, EMPTY);
    const confirm = page.getByTestId('import-confirm');
    await expect(confirm).toBeDisabled();
    await page.getByTestId('import-empty-confirm').check();
    await expect(confirm).toBeEnabled();
    await page.getByTestId('import-empty-confirm').uncheck();
    await expect(confirm).toBeDisabled();
    await confirm.click({ force: true });
    expect(await snapshot(page)).toBe(before);
  });

  test('ticking, then re-picking the same empty file, clears the tick (tick does not survive a new preview)', async ({ page }) => {
    await boot(page, { seed: 'populated' });
    const before = await snapshot(page);
    await pick(page, EMPTY);
    await page.getByTestId('import-empty-confirm').check();
    await expect(page.getByTestId('import-confirm')).toBeEnabled();
    // input.value is cleared after each pick, so the same file fires change again.
    await pick(page, EMPTY, 'empty-backup-again.json');
    await expect(page.getByTestId('import-empty-warning')).toBeVisible();
    await expect(page.getByTestId('import-empty-confirm')).not.toBeChecked();
    await expect(page.getByTestId('import-confirm')).toBeDisabled();
    expect(await snapshot(page)).toBe(before);
  });

  test('changing the file after ticking: a non-empty file does not inherit the tick; empty re-pick starts over', async ({ page }) => {
    await boot(page, { seed: 'populated' });
    const before = await snapshot(page);
    await pick(page, EMPTY);
    await page.getByTestId('import-empty-confirm').check();
    await pick(page, ONE, 'one-weight.json');
    await expect(page.getByTestId('import-empty-warning')).toBeHidden();
    await expect(page.getByTestId('import-empty-confirm')).not.toBeChecked();
    await expect(page.getByTestId('import-confirm')).toBeEnabled();
    // Do not confirm the non-empty file — Cancel must still write nothing.
    await page.getByTestId('import-cancel').click();
    expect(await snapshot(page)).toBe(before);
    await pick(page, EMPTY, 'empty-again.json');
    await expect(page.getByTestId('import-empty-confirm')).not.toBeChecked();
    await expect(page.getByTestId('import-confirm')).toBeDisabled();
    expect(await snapshot(page)).toBe(before);
  });

  test('Enter on the disabled Replace button writes nothing', async ({ page }) => {
    await boot(page, { seed: 'populated' });
    const before = await snapshot(page);
    await pick(page, EMPTY);
    const confirm = page.getByTestId('import-confirm');
    await expect(confirm).toBeDisabled();
    await confirm.focus({ force: true });
    await page.keyboard.press('Enter');
    await page.keyboard.press('Space');
    expect(await snapshot(page)).toBe(before);
    await expect(page.getByTestId('import-preview')).toBeVisible();
    await expect(page.getByTestId('import-result')).toBeHidden();
  });

  test('double-click Replace after both confirmations restores once and is byte-stable', async ({ page }) => {
    await boot(page, { seed: 'populated' });
    await pick(page, EMPTY);
    await page.getByTestId('import-empty-confirm').check();
    await page.getByTestId('import-confirm').dblclick();
    await expect(page.getByTestId('import-result')).toContainText(/Restored 0 weight/i);
    const after = await page.evaluate(() => JSON.parse(localStorage.getItem('hyrox.v1')));
    expect(after.weight).toEqual([]);
    expect(after.workouts).toEqual([]);
    expect(after.nutrition).toEqual([]);
    await expect(page.getByTestId('import-preview')).toBeHidden();
    await expect(page.getByTestId('import-empty-confirm')).not.toBeChecked();
  });

  test('Cancel after ticking, then reopening the preview, starts with the tick cleared', async ({ page }) => {
    await boot(page, { seed: 'populated' });
    const before = await snapshot(page);
    await pick(page, EMPTY);
    await page.getByTestId('import-empty-confirm').check();
    await page.getByTestId('import-cancel').click();
    await expect(page.getByTestId('import-preview')).toBeHidden();
    expect(await snapshot(page)).toBe(before);
    await pick(page, EMPTY, 'empty-reopen.json');
    await expect(page.getByTestId('import-empty-confirm')).not.toBeChecked();
    await expect(page.getByTestId('import-confirm')).toBeDisabled();
    expect(await snapshot(page)).toBe(before);
  });

  test('leaving Settings after ticking, then returning, clears the tick and writes nothing; reload writes nothing', async ({ page }) => {
    await boot(page, { seed: 'populated' });
    const before = await snapshot(page);
    await pick(page, EMPTY);
    await page.getByTestId('import-empty-confirm').check();
    await page.getByTestId('tab-today').click();
    expect(await snapshot(page)).toBe(before);
    await page.getByTestId('tab-settings').click();
    await expect(page.getByTestId('import-empty-confirm')).not.toBeChecked();
    await expect(page.getByTestId('import-confirm')).toBeDisabled();
    expect(await snapshot(page)).toBe(before);
    await page.reload();
    expect(await snapshot(page)).toBe(before);
  });

  test('a genuine empty restore works after both confirmations, and empty-onto-empty has no extra gate', async ({ page }) => {
    await boot(page, { seed: 'populated' });
    await pick(page, EMPTY);
    await page.getByTestId('import-empty-confirm').check();
    await page.getByTestId('import-confirm').click();
    await expect(page.getByTestId('import-result')).toContainText(/Restored 0 weight/i);
    const emptied = await snapshot(page);
    await pick(page, EMPTY, 'empty-on-empty.json');
    await expect(page.getByTestId('import-empty-warning')).toBeHidden();
    await expect(page.getByTestId('import-empty-note')).toBeVisible();
    await expect(page.getByTestId('import-confirm')).toBeEnabled();
    await page.getByTestId('import-confirm').click();
    await expect(page.getByTestId('import-result')).toBeVisible();
    // Second restore of empty-onto-empty is allowed; live KEY stays empty lists.
    const after = await page.evaluate(() => JSON.parse(localStorage.getItem('hyrox.v1')));
    expect(after.weight.length + after.workouts.length + after.nutrition.length).toBe(0);
    expect(emptied).not.toBe(''); // first restore did write a new KEY / pre-import slot
  });

  test('forcing the disabled button via the DOM still writes nothing (handler re-checks the tick)', async ({ page }) => {
    await boot(page, { seed: 'populated' });
    const before = await snapshot(page);
    await pick(page, EMPTY);
    await page.evaluate(() => {
      const b = document.getElementById('import-confirm');
      b.disabled = false;
      b.click();
    });
    expect(await snapshot(page)).toBe(before);
    await expect(page.getByTestId('import-preview')).toBeVisible();
  });
});
