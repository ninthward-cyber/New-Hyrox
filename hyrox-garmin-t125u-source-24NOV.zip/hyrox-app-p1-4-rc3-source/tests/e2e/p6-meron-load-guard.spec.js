'use strict';
// P6 Meron: independent load-guard verification on the integration build.
// Chrome emulation, not Safari/WebKit. Synthetic data only. 390 and 320.
const { test, expect } = require('@playwright/test');

const SHOTS = process.env.P6_SHOTS || '/workspace/hyrox-p6/results/screens';
const MSG = 'Part of the app did not load. Your saved records are safe.';
const NOW = '2026-11-13T06:00:00.000Z';
const T = '2026-11-13T06:00:00.000Z';
const MEAL = {
  id: 'm-meron-lg', createdAt: T, updatedAt: T, date: '2026-11-13',
  label: 'Synthetic meron meal', source: 'MANUAL', lifecycle: 'CONFIRMED', confirmedAt: T, eatenFraction: 1,
  components: [{ name: 'Rice', role: 'MAIN', eatenFraction: null, kcal: { value: 200, state: 'KNOWN' }, proteinG: { value: 4, state: 'KNOWN' }, carbsG: { value: 44, state: 'KNOWN' }, fatG: { value: 1, state: 'KNOWN' } }],
};
const DATA = { version: 2, weight: [], workouts: [], nutrition: [], meals: [MEAL] };

const stored = (page) => page.evaluate(() => {
  const o = {};
  for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); o[k] = localStorage.getItem(k); }
  return o;
});
const noHScroll = async (page) => {
  const m = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
  expect(m.sw).toBeLessThanOrEqual(m.cw);
};

async function bootBlocked(page, pattern) {
  await page.clock.setFixedTime(new Date(NOW));
  await page.goto('./');
  await page.evaluate((data) => { localStorage.clear(); localStorage.setItem('hyrox.v1', JSON.stringify(data)); }, DATA);
  if (pattern) await page.route(pattern, (r) => r.abort('failed'));
  await page.reload();
}

for (const W of [390, 320]) {
  test.describe(`${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`load-guard ${W}: a missing Phase 3 script shows the exact warning, keeps hyrox.v1 byte-exact, and does not write`, async ({ page }) => {
      await bootBlocked(page, '**/src/ui/app-ext.js');
      const guard = page.getByTestId('load-guard');
      await expect(guard).toBeVisible();
      await expect(guard).toHaveAttribute('role', 'alert');
      await expect(page.getByTestId('load-guard-message')).toHaveText(MSG);
      await expect(page.getByTestId('load-guard-missing')).toContainText('src/ui/app-ext.js');
      const after = await stored(page);
      expect(after['hyrox.v1']).toBe(JSON.stringify(DATA));
      const box = await page.getByTestId('load-guard-reload').boundingBox();
      expect(box.height).toBeGreaterThanOrEqual(44);
      expect(box.width).toBeGreaterThanOrEqual(44);
      await noHScroll(page);
      await page.screenshot({ path: `${SHOTS}/meron-${W}-load-guard.png` });
      expect(await stored(page)).toEqual(after);
    });

    test(`load-guard ${W}: hyrox-foodcalc.js (not in Liya's script list) also trips the guard and writes nothing`, async ({ page }) => {
      await bootBlocked(page, '**/src/data/hyrox-foodcalc.js');
      await expect(page.getByTestId('load-guard-message')).toHaveText(MSG);
      await expect(page.getByTestId('load-guard-missing')).toContainText('src/data/hyrox-foodcalc.js');
      expect((await stored(page))['hyrox.v1']).toBe(JSON.stringify(DATA));
    });
  });
}

test('load-guard: a script served as HTML (login page) also warns and keeps the seeded meal', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await bootBlocked(page, null);
  await page.route('**/src/data/hyrox-data.js', (r) => r.fulfill({ status: 200, contentType: 'text/html', body: '<html>sign in</html>' }));
  await page.reload();
  await expect(page.getByTestId('load-guard-message')).toHaveText(MSG);
  await expect(page.getByTestId('load-guard-missing')).toContainText('src/data/hyrox-data.js');
  expect(JSON.parse((await stored(page))['hyrox.v1']).meals).toHaveLength(1);
});
