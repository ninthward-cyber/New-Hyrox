'use strict';
// RC2 review (Claude). Synthetic data only. CHROME MOBILE EMULATION, NOT SAFARI/WEBKIT. On RC1 these FAIL:
//  1. a fiber/sodium value the owner typed on a USDA item lost its "owner" origin once the meal was saved and reopened,
//     so a later kcal change cleared it as if USDA had supplied it;
//  2. restoring a backup did not say it replaces / removes the device's saved foods and favourites;
//  3. "fries" showed "Fry sauce" first and "french fries" showed restaurant chains above the plain food.
const { test, expect } = require('@playwright/test');
// P0 (22 Nov 2026): the meal diary moved from Today to Add > Meal ("Log meal" on Today opens it). This brings it on screen
// the way the owner does; it does nothing when the diary or a dedicated logger is already showing.
async function diary(page) {
  if (await page.getByTestId('meal-diary').isVisible()) return;
  if (await page.getByTestId('logger-head').isVisible()) return;
  if (!(await page.getByTestId('panel-today').isVisible())) await page.getByTestId('tab-today').click();
  await page.getByTestId('today-add-meal').click();
  await page.getByTestId('meal-diary').waitFor();
}

const NOW = '2026-11-19T09:00:00.000Z', T = '2026-11-19T08:00:00.000Z';
const K = (v) => ({ value: v, state: 'KNOWN' });
async function open(page, data) {
  page._errs = []; page._dialogs = [];
  page.on('pageerror', (e) => page._errs.push(e.message));
  page.on('dialog', (d) => { page._dialogs.push(d.message()); d.dismiss(); });
  await page.clock.setFixedTime(new Date(NOW));
  await page.goto('./'); await page.evaluate(() => localStorage.clear());
  if (data) await page.evaluate((d) => localStorage.setItem('hyrox.v1', JSON.stringify(d)), data);
  await page.reload(); await expect(page.getByTestId('app-error')).toBeHidden();
}
const stored = async (page) => JSON.parse((await page.evaluate(() => localStorage.getItem('hyrox.v1'))) || '{}');
const clean = (page) => { expect(page._errs).toEqual([]); expect(page._dialogs).toEqual([]); };

for (const W of [390, 320]) {
  test.describe(`RC2 review ${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`${W}: a typed sodium on a USDA item stays the owner's after save, reopen and a kcal change; USDA fiber is still cleared`, async ({ page }) => {
      await open(page);
      await page.getByTestId('tab-today').click();
      await diary(page); await page.getByTestId('diary-log-dinner').click(); await page.getByTestId('meal-add-foods').click();
      await page.getByTestId('foods-q').fill('banana'); await page.getByTestId('food-pick').first().click(); await page.getByTestId('food-add').click(); await page.getByTestId('foods-done').click();
      await page.getByTestId('component-extra').evaluate((d) => { d.open = true; });
      await expect(page.getByTestId('component-fiberG')).not.toHaveValue('');
      await page.getByTestId('component-sodiumMg').fill('77');
      await page.getByTestId('meal-confirm').click();
      let c = (await stored(page)).meals[0].components[0];
      expect(c.sodiumMg).toEqual({ value: 77, state: 'ESTIMATED', by: 'OWNER' });
      expect(c.fiberG.by).toBeUndefined();
      // reopen in a fresh form (the page is even reloaded first) and change kcal
      await page.reload();
      await page.getByTestId('tab-history').click(); await page.getByTestId('meal-edit').first().click();
      await page.getByTestId('component-extra').evaluate((d) => { d.open = true; });
      await page.getByTestId('component-kcal').fill('150');
      await expect(page.getByTestId('component-sodiumMg')).toHaveValue('77');
      await expect(page.getByTestId('component-fiberG')).toHaveValue('');
      await page.getByTestId('meal-confirm').click();
      c = (await stored(page)).meals[0].components[0];
      expect([c.kcal.value, c.sodiumMg, 'fiberG' in c, 'provenance' in c]).toEqual([150, { value: 77, state: 'ESTIMATED', by: 'OWNER' }, false, false]);
      expect((await stored(page)).meals).toHaveLength(1);
      clean(page);
    });

    test(`${W}: restore preview warns before replacing saved foods and favourites; confirming replaces them as warned`, async ({ page }) => {
      const mf = (id, name) => ({ id, name, portion: '1 bowl', kcal: K(300), proteinG: K(10), carbsG: K(50), fatG: K(5), basis: 'your values', savedAt: T, fromMealId: null });
      const settings = (x) => [Object.assign({ id: 'app-settings', date: '2026-11-18', createdAt: T, updatedAt: T }, x)];
      await open(page, { version: 2, weight: [], workouts: [], nutrition: [], meals: [], ownerSettings: settings({ myFoods: [mf('mf-1', 'Oats bowl'), mf('mf-2', 'Rice bowl')], favFoods: ['my:mf-1'] }) });
      const backup = await page.evaluate(() => { const o = JSON.parse(window.HyroxData.createStore().exportJSON()); delete o.ownerSettings[0].myFoods; delete o.ownerSettings[0].favFoods; return JSON.stringify(o); });
      await page.getByTestId('tab-settings').click();
      await page.getByTestId('import-file').setInputFiles({ name: 'old-backup.json', mimeType: 'application/json', buffer: Buffer.from(backup) });
      await expect(page.getByTestId('import-preview-saved-foods')).toHaveText('Restoring removes your 2 saved foods and 1 favourite from this device (this backup has none; it may be from an older version). Meals already logged are not changed. Export a backup first if you want to keep them.');
      await expect(page.getByTestId('import-preview-warnings')).toBeVisible();
      await page.getByTestId('import-confirm').click();
      await expect.poll(async () => ((await stored(page)).ownerSettings || []).find((r) => r.id === 'app-settings').myFoods).toBeUndefined();
      // the same backup again: nothing left to lose, so no saved-foods warning
      await page.getByTestId('import-file').setInputFiles({ name: 'old-backup.json', mimeType: 'application/json', buffer: Buffer.from(backup) });
      await expect(page.getByTestId('import-preview')).toBeVisible();
      await expect(page.getByTestId('import-preview-saved-foods')).toHaveCount(0);
      clean(page);
    });

    test(`${W}: Add foods — "fries" and "french fries" show plain French fries first; chains are still offered, nothing is chosen`, async ({ page }) => {
      await open(page);
      await page.getByTestId('tab-today').click();
      await diary(page); await page.getByTestId('diary-log-lunch').click(); await page.getByTestId('meal-add-foods').click();
      await page.getByTestId('foods-q').fill('fries');
      await expect(page.getByTestId('food-result').first()).toContainText('Potato, french fries, NFS');
      for (let i = 0; i < 5; i++) await expect(page.getByTestId('food-result').nth(i)).not.toContainText('Fry sauce');
      await page.getByTestId('foods-q').fill('french fries');
      await expect(page.getByTestId('food-result').first()).toContainText('Potato, french fries, NFS');
      await expect(page.getByTestId('food-restaurant')).not.toHaveCount(0);
      await expect(page.getByTestId('food-detail')).toHaveCount(0);
      clean(page);
    });
  });
}
