'use strict';
// RC1 independent review of P11.3 (food branch): fail-first regression tests for defect A-01 (US food file loaded once; retried after a failure).
// Synthetic data only; no AI; no network beyond the app's own static files. CHROME MOBILE EMULATION, NOT SAFARI/WEBKIT.
const { test, expect } = require('@playwright/test');
// P0 (22 Nov 2026): the meal diary moved from Today to Add > Meal ("Log meal" on Today opens it). This brings it on screen
// the way the owner does; it does nothing when the diary or a dedicated logger is already showing.
async function diary(page) {
  if (await page.getByTestId('meal-diary').isVisible()) return;
  if (await page.getByTestId('logger-head').isVisible()) return;
  if (!(await page.getByTestId('panel-today').isVisible())) await page.getByTestId('tab-today').click();
  await page.getByTestId('today-add-meal').click();
  await page.getByTestId('meal-diary').waitFor();
}

const NOW = '2026-11-19T09:00:00.000Z';
async function open(page) {
  page._errs = []; page.on('pageerror', (e) => page._errs.push(e.message));
  await page.clock.setFixedTime(new Date(NOW));
  await page.goto('./'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
}
const row = (page, name) => page.getByTestId('food-result').filter({ has: page.locator('.food-name', { hasText: new RegExp('^' + name.replace(/[()]/g, '\\$&') + '$') }) });
const stored = async (page) => JSON.parse((await page.evaluate(() => localStorage.getItem('hyrox.v1'))) || '{}');

for (const W of [390, 320]) {
  test.describe(`RC1 review A-01 ${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`${W}: A-01 the US food file is loaded once (one script, one request) even when Add foods is reopened while it is still loading`, async ({ page }) => {
      await open(page);
      let n = 0, release; const gate = new Promise((r) => { release = r; });
      await page.route(/food-db-us\.js$/, async (route) => { n++; if (n === 1) { await gate; await route.continue(); } else await route.abort(); });
      await diary(page); await page.getByTestId('diary-log-lunch').click();
      await page.getByTestId('meal-add-foods').click();
      await expect.poll(() => n).toBe(1);
      await page.getByTestId('foods-done').click();          // leave while the file is still loading
      await page.getByTestId('meal-add-foods').click();      // and come back
      await page.waitForTimeout(300);
      release();
      await expect(page.getByTestId('foods-status')).toContainText('13,598 foods');
      expect(n).toBe(1);
      expect(await page.evaluate(() => document.querySelectorAll('script[src$="food-db-us.js"]').length)).toBe(1);
      await expect(page.getByTestId('foods-status')).not.toContainText('could not be loaded');
      expect(page._errs).toEqual([]);
    });

    test(`${W}: A-01 after the US file fails once, the next Add foods open tries again and then searches 13,598 foods`, async ({ page }) => {
      await open(page);
      let n = 0;
      await page.route(/food-db-us\.js$/, async (route) => { n++; if (n === 1) await route.abort(); else await route.continue(); });
      await diary(page); await page.getByTestId('diary-log-lunch').click();
      await page.getByTestId('meal-add-foods').click();
      await expect(page.getByTestId('foods-status')).toContainText('could not be loaded');
      await expect(page.getByTestId('foods-status')).toContainText('8,167 foods');
      await page.getByTestId('foods-done').click();
      await page.getByTestId('meal-add-foods').click();
      await expect(page.getByTestId('foods-status')).toContainText('13,598 foods');
      await expect(page.getByTestId('foods-status')).not.toContainText('could not be loaded');
      expect(n).toBe(2);
      expect(page._errs).toEqual([]);
    });

  });
}
