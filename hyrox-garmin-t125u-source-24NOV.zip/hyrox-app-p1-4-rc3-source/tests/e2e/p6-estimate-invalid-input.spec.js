'use strict';
// P6 defect fix (Liya t75u; found by Meron on 60d8e40): an invalid estimate quantity/grams (empty, 0, negative) must never
// leave the old estimate standing or applicable. Real HyroxFoodCalc + food-db.js. CHROME EMULATION, NOT SAFARI/WEBKIT.
const { test, expect } = require('@playwright/test');
const { installFoodShim, REAL } = require('./p6-contract-shim');
const SHOTS = process.env.P6_SHOTS || '/workspace/hyrox-p6/results/liya-shots';

async function open(page, text) {
  await installFoodShim(page);
  await page.clock.setFixedTime(new Date('2026-11-12T06:00:00.000Z'));
  await page.goto('./');
  await page.evaluate(() => localStorage.clear());
  await page.reload();
  await page.getByTestId('tab-add').click();
  await page.getByTestId('add-mode-meal').click();
  await page.getByTestId('meal-path-description').click();
  await page.getByTestId('meal-description').fill(text);
  await page.getByTestId('estimate-run').click();
  await expect(page.getByTestId('estimate-items')).toBeVisible();
}
const first = (page) => page.getByTestId('estimate-item').first();

for (const W of [390, 320]) {
  test.describe(`invalid estimate input ${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.skip(!REAL.calc || !REAL.db || REAL.forced, 'needs the real food files');
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    for (const [field, id] of [['quantity', 'estimate-qty'], ['grams', 'estimate-grams']]) {
      for (const bad of ['0', '-1', '']) {
        test(`${W}: ${field} "${bad || '(empty)'}" drops the item, shows an inline error, disables Use-these-estimates; a valid value restores it`, async ({ page }) => {
          await open(page, '2 eggs, 1 cup milk');
          await expect(first(page).getByTestId('estimate-nutrients')).toContainText('143 kcal');
          await expect(page.getByTestId('estimate-totals')).toContainText('292 kcal');
          await first(page).getByTestId(id).fill(bad); // input event only: no blur, no Tab
          const item = first(page);
          await expect(item).toHaveAttribute('data-status', 'unparsed');
          await expect(item.getByTestId('estimate-nutrients')).toHaveCount(0);
          await expect(item.getByTestId('estimate-source')).toHaveCount(0);
          const err = item.getByTestId('estimate-input-error');
          await expect(err).toBeVisible();
          await expect(err).toContainText(field === 'grams' ? 'Grams must be a number greater than 0' : 'Quantity must be a number greater than 0');
          const errId = await err.getAttribute('id');
          expect(await item.getByTestId(id).getAttribute('aria-describedby')).toBe(errId);
          expect(await item.getByTestId(id).getAttribute('aria-invalid')).toBe('true');
          const bb = await err.boundingBox();
          expect(bb.x).toBeGreaterThanOrEqual(0); expect(bb.x + bb.width).toBeLessThanOrEqual(W);
          await expect(page.getByTestId('estimate-totals')).toContainText('149 kcal'); // milk only
          await expect(page.getByTestId('estimate-totals')).toContainText('1 matched item');
          await expect(page.getByTestId('estimate-apply')).toBeDisabled();
          await expect(page.getByTestId('estimate-apply-hint')).toBeVisible();
          const sw = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
          expect(sw.sw).toBeLessThanOrEqual(sw.cw);
          if (field === 'quantity' && bad === '0') {
            await err.scrollIntoViewIfNeeded();
            await page.screenshot({ path: `${SHOTS}/p6-${W}-estimate-invalid-qty-error.png` });
          }
          // blur must not resurrect the old estimate either
          await first(page).getByTestId(id).press('Tab');
          await expect(first(page).getByTestId('estimate-nutrients')).toHaveCount(0);
          await expect(page.getByTestId('estimate-apply')).toBeDisabled();
          // restore a valid value: recomputes and re-enables
          await first(page).getByTestId(id).fill(field === 'grams' ? '50' : '3');
          await expect(first(page)).toHaveAttribute('data-status', 'matched');
          await expect(first(page).getByTestId('estimate-input-error')).toHaveCount(0);
          await expect(first(page).getByTestId('estimate-nutrients')).toContainText(field === 'grams' ? '72 kcal' : '215 kcal');
          await expect(page.getByTestId('estimate-apply')).toBeEnabled();
          await expect(page.getByTestId('estimate-apply-hint')).toBeHidden();
        });
      }
    }

    test(`${W}: a valid value typed and the button tapped without leaving the field applies the NEW amount, never the old one`, async ({ page }) => {
      await open(page, '2 eggs');
      await first(page).getByTestId('estimate-qty').fill('3');
      await page.getByTestId('estimate-apply').click();
      const row = page.getByTestId('component-row').first();
      await expect(row.getByTestId('component-kcal')).toHaveValue('215');
    });

    test(`${W}: an item left invalid is never applied as the old amount (blocked, nothing added)`, async ({ page }) => {
      await open(page, '2 eggs, 1 cup milk');
      await first(page).getByTestId('estimate-qty').fill('0');
      await page.getByTestId('estimate-apply').click({ force: true });
      await expect(page.getByTestId('component-row')).toHaveCount(1); // only the editor's initial blank row
      await expect(page.getByTestId('component-row').first().getByTestId('component-provenance')).toHaveCount(0);
    });
  });
}
