'use strict';
// Claude Phase 11 independent review. Synthetic data only. CHROME EMULATION, NOT SAFARI/WEBKIT. On Grok's P11 these FAIL:
//  1. opening the dedicated logger left keyboard / VoiceOver focus on <body> (the tapped "+ Log" button was removed);
//     focus now moves to the logger heading;
//  2. Back and a save returned to the diary with focus on <body>; focus now returns to that meal's row;
//  3. leaving an UNTOUCHED logger through the tab bar kept it open, so the Add tab showed "Log lunch" with the
//     Workout/Body choices hidden until Back was pressed. An untouched logger now closes when you leave it; a logger
//     with anything typed, chosen or analysed stays open (never dropped silently).
const { test, expect } = require('@playwright/test');
// P0 (22 Nov 2026): the meal diary moved from Today to Add > Meal ("Log meal" on Today opens it). This brings it on screen
// the way the owner does; it does nothing when the diary or a dedicated logger is already showing.
async function diary(page) {
  if (await page.getByTestId('meal-diary').isVisible()) return;
  if (await page.getByTestId('logger-head').isVisible()) return;
  if (!(await page.getByTestId('panel-today').isVisible())) await page.getByTestId('tab-today').click();
  await page.getByTestId('today-add-meal').click();
  await page.getByTestId('meal-diary').waitFor();
}

// P0 (22 Nov 2026): "Meal name" is no longer a routine field; the optional custom name sits in a closed fold.
async function nameField(page) { const f = page.getByTestId('meal-label'); if (!(await f.isVisible())) await page.getByTestId('meal-name-toggle').click(); return f; }


async function open(page) {
  page._errs = []; page._dialogs = [];
  page.on('pageerror', (e) => page._errs.push(e.message));
  page.on('dialog', (d) => { page._dialogs.push(d.message()); d.dismiss(); });
  await page.clock.setFixedTime(new Date('2026-11-19T09:00:00.000Z'));
  await page.goto('./'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
  await page.getByTestId('tab-today').click();
}
const clean = (page) => { expect(page._errs).toEqual([]); expect(page._dialogs).toEqual([]); };
const focused = (page) => page.evaluate(() => (document.activeElement && document.activeElement.getAttribute('data-testid')) || (document.activeElement && document.activeElement.id) || document.activeElement.tagName);
const meals = (page) => page.evaluate(() => (JSON.parse(localStorage.getItem('hyrox.v1') || '{}').meals) || []);

for (const W of [390, 320]) {
  test.describe(`P11 Claude review ${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`${W}: focus moves to the logger heading on open, and back to the meal's row after Back and after a save`, async ({ page }) => {
      await open(page);
      await diary(page); await page.getByTestId('diary-log-lunch').click();
      await expect.poll(() => focused(page)).toBe('logger-title');
      await expect(page.getByTestId('logger-title')).toHaveText('Log lunch');
      await page.getByTestId('logger-back').click();
      await expect.poll(() => focused(page)).toBe('diary-log-lunch');
      await diary(page); await page.getByTestId('diary-log-dinner').click();
      await page.getByTestId('meal-path-manual').click();
      await (await nameField(page)).fill('Dinner A');
      await page.getByTestId('component-name').first().fill('Fish'); await page.getByTestId('component-kcal').first().fill('500');
      await page.getByTestId('meal-confirm').click();
      await expect(page.getByTestId('meal-diary')).toBeVisible();
      await expect.poll(() => focused(page)).toBe('diary-toggle-dinner');
      expect(await meals(page)).toHaveLength(1);
      clean(page);
    });

    test(`${W}: leaving an untouched logger by the tab bar closes it; Add shows the normal choices again`, async ({ page }) => {
      await open(page);
      await diary(page); await page.getByTestId('diary-log-breakfast').click();
      await expect(page.getByTestId('logger-head')).toBeVisible();
      await page.getByTestId('tab-history').click();
      await page.getByTestId('tab-add').click();
      await expect(page.getByTestId('logger-head')).toHaveCount(0);
      await expect(page.getByTestId('add-mode-workout')).toBeVisible();
      await page.getByTestId('add-mode-workout').click();
      await expect(page.getByTestId('session-form')).toBeVisible();
      clean(page);
    });

    test(`${W}: a logger with typed content survives the tab bar (never dropped), and Back still asks`, async ({ page }) => {
      await open(page);
      await diary(page); await page.getByTestId('diary-log-snacks').click();
      await page.getByTestId('meal-path-manual').click();
      await (await nameField(page)).fill('Dates');
      await page.getByTestId('tab-history').click();
      await page.getByTestId('tab-add').click();
      await expect(page.getByTestId('logger-title')).toHaveText('Log snacks');
      await expect(page.getByTestId('meal-label')).toHaveValue('Dates');
      await page.getByTestId('logger-back').click();
      await expect(page.getByTestId('choice-dialog')).toBeVisible();
      await page.getByTestId('choice-keep').click();
      await expect(page.getByTestId('meal-label')).toHaveValue('Dates');
      expect(await meals(page)).toEqual([]);
      clean(page);
    });
  });
}
