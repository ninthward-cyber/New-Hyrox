'use strict';
// P6 Meron: independent estimate-flow verification on the real food DB (not Liya's shim).
// Chrome emulation, not Safari/WebKit. Synthetic data only. 390 and 320.
const { test, expect } = require('@playwright/test');
// P0 (22 Nov 2026): "Meal name" is no longer a routine field; the optional custom name sits in a closed fold.
async function nameField(page) { const f = page.getByTestId('meal-label'); if (!(await f.isVisible())) await page.getByTestId('meal-name-toggle').click(); return f; }


const SHOTS = process.env.P6_SHOTS || '/workspace/hyrox-p6/results/screens';
const NOW = '2026-11-13T06:00:00.000Z';
const TODAY = '2026-11-13';

const stored = (page) => page.evaluate(() => {
  const o = {};
  // RE-POINTED by Sprint B2 (owner decision M1, 23 Nov 2026): the owner now WANTS an unfinished meal auto-saved in the UI-only
  // key hyrox.ui.meal-draft, so "writes nothing" means no data key changes; the draft key is excluded here and checked below.
  for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (k !== 'hyrox.ui.meal-draft') o[k] = localStorage.getItem(k); }
  return o;
});
const mealDraftOnly = (page) => page.evaluate(() => { const t = localStorage.getItem('hyrox.ui.meal-draft'); if (!t) return null; const d = JSON.parse(t); return { kind: d.kind, lifecycle: d.ms && d.ms.lifecycle }; });
const meals = (page) => page.evaluate(() => { const d = JSON.parse(localStorage.getItem('hyrox.v1') || '{}'); return d.meals || []; });
const noHScroll = async (page) => {
  const m = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
  expect(m.sw).toBeLessThanOrEqual(m.cw);
};

async function openMeal(page) {
  await page.clock.setFixedTime(new Date(NOW));
  await page.goto('./');
  await page.evaluate(() => localStorage.clear());
  await page.reload();
  await expect(page.getByTestId('load-guard')).toBeHidden();
  await page.getByTestId('tab-add').click();
  await page.getByTestId('add-mode-meal').click();
  await page.getByTestId('meal-path-description').click();
}

async function runEstimate(page, text) {
  await page.getByTestId('meal-description').fill(text);
  await page.getByTestId('estimate-run').click();
  await expect(page.getByTestId('estimate-items')).toBeVisible({ timeout: 15000 });
}

for (const W of [390, 320]) {
  test.describe(`${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`estimate ${W}: real USDA items, no_match, totals; estimating writes nothing`, async ({ page }) => {
      await openMeal(page);
      const before = await stored(page);
      await runEstimate(page, '2 eggs, 100g cooked white rice, 1 cup qwerty-zaq-unknown-food-xyz');
      const items = page.getByTestId('estimate-item');
      await expect(items).toHaveCount(3);
      await expect(items.nth(0).getByTestId('estimate-nutrients')).toContainText('143 kcal');
      await expect(items.nth(0).getByTestId('estimate-source')).toContainText('fdcId 171287');
      await expect(items.nth(1).getByTestId('estimate-nutrients')).toContainText('130 kcal');
      await expect(items.nth(2).getByTestId('estimate-nomatch')).toContainText('no match, enter manually');
      await expect(items.nth(2).getByTestId('estimate-nutrients')).toHaveCount(0);
      await expect(page.getByTestId('estimate-totals')).toContainText('ESTIMATE');
      await expect(page.getByTestId('estimate-totals')).toContainText('2 matched');
      await noHScroll(page);
      const runBox = await page.getByTestId('estimate-run').boundingBox();
      expect(runBox.height).toBeGreaterThanOrEqual(44);
      const applyBox = await page.getByTestId('estimate-apply').boundingBox();
      expect(applyBox.height).toBeGreaterThanOrEqual(44);
      await items.nth(0).scrollIntoViewIfNeeded();
      await page.screenshot({ path: `${SHOTS}/meron-${W}-estimate-items.png` });
      expect(await stored(page)).toEqual(before);
      expect(await meals(page)).toEqual([]);
      const md = await mealDraftOnly(page); // RE-POINTED by Sprint B2: if a local draft exists it is only the uncounted UI draft
      if (md) expect(md.kind).toBe('hyrox-meal-draft');
    });

    test(`estimate ${W}: needs-quantity (banana) is not assumed as 1 until the owner enters an amount`, async ({ page }) => {
      await openMeal(page);
      await runEstimate(page, 'banana');
      const it = page.getByTestId('estimate-item').first();
      await expect(it.getByTestId('estimate-needqty')).toBeVisible();
      await expect(it.getByTestId('estimate-nutrients')).toHaveCount(0);
      await expect(page.getByTestId('estimate-totals')).toContainText('nothing matched yet');
      expect(await meals(page)).toEqual([]);
      await it.getByTestId('estimate-qty').fill('1');
      await it.getByTestId('estimate-qty').press('Tab');
      await expect(page.getByTestId('estimate-item').first().getByTestId('estimate-nutrients')).toBeVisible();
      await expect(page.getByTestId('estimate-item').first().getByTestId('estimate-source')).toContainText('173944');
    });

    test(`estimate ${W}: portion/grams edit recomputes; ambiguous pick is required; changing the text drops the pick`, async ({ page }) => {
      await openMeal(page);
      await runEstimate(page, '100 g cooked white rice');
      const rice = page.getByTestId('estimate-item').first();
      await expect(rice.getByTestId('estimate-nutrients')).toContainText('130 kcal');
      await rice.getByTestId('estimate-grams').fill('50');
      await rice.getByTestId('estimate-grams').press('Tab');
      await expect(page.getByTestId('estimate-item').first().getByTestId('estimate-nutrients')).toContainText('65 kcal');

      await page.getByTestId('meal-description').fill('100 g chicken');
      await page.getByTestId('estimate-run').click();
      const chicken = page.getByTestId('estimate-item').first();
      await expect(chicken.getByTestId('estimate-ambiguous')).toBeVisible();
      await expect(chicken.getByTestId('estimate-nutrients')).toHaveCount(0);
      const select = chicken.getByTestId('estimate-food');
      const firstVal = await select.locator('option').nth(1).getAttribute('value');
      await select.selectOption(firstVal);
      await expect(page.getByTestId('estimate-item').first().getByTestId('estimate-nutrients')).toBeVisible();
      // Change the text and re-run: the previous pick must not stick.
      await page.getByTestId('meal-description').fill('2 eggs');
      await page.getByTestId('estimate-run').click();
      const egg = page.getByTestId('estimate-item').first();
      await expect(egg.getByTestId('estimate-item-raw')).toContainText('2 eggs');
      await expect(egg.getByTestId('estimate-nutrients')).toContainText('143 kcal');
      await expect(egg.getByTestId('estimate-source')).toContainText('171287');
    });

    test(`estimate ${W}: nothing counts until Confirm; un-confirming removes it; provenance survives export/restore byte-exact`, async ({ page }) => {
      await openMeal(page);
      await runEstimate(page, '2 eggs, 100g cooked white rice');
      await page.getByTestId('estimate-apply').click();
      expect(await meals(page)).toEqual([]);
      await (await nameField(page)).fill('Meron confirm meal');
      await page.getByTestId('meal-save-draft').click();
      expect((await meals(page))[0].lifecycle).toBe('DRAFT');
      await page.getByTestId('tab-today').click();
      await expect(page.getByTestId('glance-nutrition')).toContainText('nothing confirmed');

      await page.getByTestId('tab-history').click();
      await page.getByTestId('meal-review').click();
      await page.getByTestId('meal-confirm').click();
      const confirmed = (await meals(page)).filter((m) => m.lifecycle === 'CONFIRMED');
      expect(confirmed).toHaveLength(1);
      const prov = confirmed[0].components[0].provenance;
      expect(prov.fdcId).toBe(171287);
      const provJson = JSON.stringify(prov);
      await page.getByTestId('tab-today').click();
      await expect(page.getByTestId('glance-nutrition')).toContainText('273'); // 143+130
      await page.getByTestId('glance-nutrition').scrollIntoViewIfNeeded();
      await page.screenshot({ path: `${SHOTS}/meron-${W}-confirmed-totals.png` });

      const exported = await page.evaluate(() => {
        const st = window.HyroxData.createStore();
        return st.exportChecked();
      });
      expect(exported.ok).toBe(true);
      expect(exported.restorable).toBe(true);

      // Un-confirm via Edit -> Save draft: totals must drop.
      await page.getByTestId('tab-history').click();
      await page.getByTestId('meal-edit').click();
      await page.getByTestId('meal-save-draft').click();
      expect((await meals(page))[0].lifecycle).toBe('DRAFT');
      await page.getByTestId('tab-today').click();
      await expect(page.getByTestId('glance-nutrition')).toContainText('nothing confirmed');

      // Restore the earlier confirmed export (byte-exact provenance).
      const restored = await page.evaluate((text) => {
        const st = window.HyroxData.createStore();
        const p = st.previewImport(text);
        const opts = { confirm: 'REPLACE', confirmEmptyReplace: true };
        if (p.ok) {
          opts.expectCurrent = p.preview.current;
          opts.expectCurrentExt = p.preview.currentExt;
        }
        const r = st.applyImport(text, opts);
        const meals = (JSON.parse(localStorage.getItem('hyrox.v1') || '{}').meals) || [];
        return { ok: r.ok, code: r.code, provenance: meals[0] && meals[0].components[0] && meals[0].components[0].provenance };
      }, exported.text);
      expect(restored.ok).toBe(true);
      expect(JSON.stringify(restored.provenance)).toBe(provJson);
    });

    test(`estimate ${W}: leaving mid-flow writes nothing; a double Confirm does not create a second meal; editing after confirm updates the same meal`, async ({ page }) => {
      await openMeal(page);
      const empty = await stored(page);
      await runEstimate(page, '1 cup whole milk');
      // There is no meal-form Escape/cancel binding; leaving via Today is the cancel path.
      await page.keyboard.press('Escape');
      expect(await stored(page)).toEqual(empty);
      await page.getByTestId('tab-today').click();
      expect(await stored(page)).toEqual(empty);
      expect(await meals(page)).toEqual([]);

      await page.getByTestId('tab-add').click();
      await page.getByTestId('add-mode-meal').click();
      await page.getByTestId('meal-path-description').click();
      await runEstimate(page, '1 cup whole milk');
      await page.getByTestId('estimate-apply').click();
      await (await nameField(page)).fill('Double-tap');
      // Two click events in the same turn, before history navigation can unmount the button.
      await page.getByTestId('meal-confirm').evaluate((el) => { el.click(); el.click(); });
      const afterDouble = await meals(page);
      const confirmed = afterDouble.filter((m) => m.lifecycle === 'CONFIRMED');
      expect(confirmed).toHaveLength(1);
      const id = confirmed[0].id;

      await page.getByTestId('tab-history').click();
      await page.getByTestId('meal-edit').click();
      await (await nameField(page)).fill('Edited after confirm');
      await page.getByTestId('meal-confirm').click();
      const afterEdit = await meals(page);
      expect(afterEdit.filter((m) => m.lifecycle === 'CONFIRMED')).toHaveLength(1);
      expect(afterEdit[0].id).toBe(id);
      expect(afterEdit[0].label).toBe('Edited after confirm');
    });

    test(`DEFECT estimate ${W}: typing 0 or -1 in quantity still offers the previous 143 kcal estimate`, async ({ page }) => {
      await openMeal(page);
      await runEstimate(page, '2 eggs');
      const item = page.getByTestId('estimate-item').first();
      await expect(item.getByTestId('estimate-nutrients')).toContainText('143 kcal');
      await item.getByTestId('estimate-qty').fill('0');
      await item.getByTestId('estimate-qty').press('Tab');
      const afterZero = page.getByTestId('estimate-item').first();
      // DEFECT if the field shows 0 but the old 143 kcal estimate is still offered as if nothing changed.
      const stillCounted = await afterZero.getByTestId('estimate-nutrients').count();
      const text = stillCounted ? await afterZero.getByTestId('estimate-nutrients').innerText() : '';
      expect(text, 'zero quantity still showing the previous 143 kcal estimate').not.toMatch(/143 kcal/);
      await item.getByTestId('estimate-qty').fill('-1');
      await item.getByTestId('estimate-qty').press('Tab');
      const afterNeg = page.getByTestId('estimate-item').first();
      const negText = (await afterNeg.getByTestId('estimate-nutrients').count())
        ? await afterNeg.getByTestId('estimate-nutrients').innerText() : '';
      expect(negText, 'negative quantity still showing 143 kcal').not.toMatch(/143 kcal/);
    });
  });
}
