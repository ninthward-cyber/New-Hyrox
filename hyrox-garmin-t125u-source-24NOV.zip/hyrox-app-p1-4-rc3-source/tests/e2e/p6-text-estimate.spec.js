'use strict';
// P6 (Liya t75u): typed-text nutrition estimate in meal logging (USDA via HyroxFoodCalc), 390 px and 320 px.
// CHROME EMULATION, NOT SAFARI/WEBKIT. Synthetic data only. Uses p6-contract-shim.js unless the real foodcalc/food-db files exist.
const { test, expect } = require('@playwright/test');
const { installFoodShim } = require('./p6-contract-shim');
// Deliberate FIXTURE spec: always runs against the shim (synthetic fdcIds 9000xx) so edge cases stay reproducible;
// the real API is covered by p6-text-estimate-real.spec.js.

const SHOTS = process.env.P6_SHOTS || '/workspace/hyrox-p6/results/liya-shots';
const NOW = '2026-11-12T06:00:00.000Z';
const TEXT = '2 eggs, 150 g rice, 1 cup milk, mystery stew';

async function open(page, opts) {
  await installFoodShim(page, Object.assign({ force: true }, opts));
  await page.clock.setFixedTime(new Date(NOW));
  await page.goto('./');
  await page.evaluate(() => localStorage.clear());
  await page.reload();
  await expect(page.getByTestId('load-guard')).toBeHidden();
  await page.getByTestId('tab-add').click();
  await page.getByTestId('add-mode-meal').click();
  await page.getByTestId('meal-path-description').click();
}
const meals = (page) => page.evaluate(() => { const d = JSON.parse(localStorage.getItem('hyrox.v1') || '{}'); return d.meals || []; });
async function estimate(page, text = TEXT) {
  await page.getByTestId('meal-description').fill(text);
  await page.getByTestId('estimate-run').click();
  await expect(page.getByTestId('estimate-items')).toBeVisible();
}
const noHScroll = async (page) => { const m = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth })); expect(m.sw).toBeLessThanOrEqual(m.cw); };

for (const W of [390, 320]) {
  test.describe(`${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`estimate ${W}: per-item and total estimates with source; unmatched says "no match, enter manually"; nothing stored or counted`, async ({ page }) => {
      await open(page);
      await estimate(page);
      const items = page.getByTestId('estimate-item');
      await expect(items).toHaveCount(4);
      await expect(items.nth(0).getByTestId('estimate-nutrients')).toContainText('Estimate: 143 kcal'); // 2 large eggs = 100 g (fixture)
      await expect(items.nth(0).getByTestId('estimate-source')).toContainText('USDA FoodData Central');
      await expect(items.nth(0).getByTestId('estimate-source')).toContainText('fdcId 900001');
      await expect(items.nth(0).getByTestId('estimate-source')).toContainText('Estimate, not a measurement');
      await expect(items.nth(1).getByTestId('estimate-grams')).toHaveValue('150');
      await expect(items.nth(3).getByTestId('estimate-nomatch')).toContainText('no match, enter manually');
      await expect(items.nth(3).getByTestId('estimate-nutrients')).toHaveCount(0); // never guessed
      await expect(page.getByTestId('estimate-totals')).toContainText('ESTIMATE');
      await expect(page.getByTestId('estimate-unmatched-note')).toContainText('1 item is not included');
      await noHScroll(page);
      expect(await meals(page)).toEqual([]); // nothing saved by estimating
      await items.nth(0).scrollIntoViewIfNeeded();
      await page.screenshot({ path: `${SHOTS}/p6-${W}-estimate-items.png` });
      await page.getByTestId('estimate-totals').scrollIntoViewIfNeeded();
      await page.screenshot({ path: `${SHOTS}/p6-${W}-estimate-totals.png` });
    });

    test(`estimate ${W}: quantity, household measure and grams are editable and recompute`, async ({ page }) => {
      await open(page);
      await estimate(page, '1 cup milk, 150 g rice');
      const milk = page.getByTestId('estimate-item').nth(0), rice = page.getByTestId('estimate-item').nth(1);
      await expect(milk.getByTestId('estimate-grams')).toHaveValue('244');
      await milk.getByTestId('estimate-qty').fill('2'); await milk.getByTestId('estimate-qty').press('Tab');
      await expect(page.getByTestId('estimate-item').nth(0).getByTestId('estimate-grams')).toHaveValue('488');
      await rice.getByTestId('estimate-grams').fill('100'); await rice.getByTestId('estimate-grams').press('Tab');
      await expect(page.getByTestId('estimate-item').nth(1).getByTestId('estimate-nutrients')).toContainText('130 kcal');
      await expect(page.getByTestId('estimate-item').nth(1).getByTestId('estimate-source')).toContainText('100 g');
      const meas = page.getByTestId('estimate-item').nth(1).getByTestId('estimate-measure');
      await expect(meas).toHaveValue('g');
      await meas.selectOption({ label: '1 cup (158 g)' });
      await expect(page.getByTestId('estimate-item').nth(1).getByTestId('estimate-grams')).toHaveValue('158');
      await expect(page.getByTestId('estimate-item').nth(1).getByTestId('estimate-qty')).toHaveValue('1');
      await expect(page.getByTestId('estimate-totals')).toContainText('2 matched items');
    });

    test(`estimate ${W}: an ambiguous food is not assumed; nothing is counted until the owner picks`, async ({ page }) => {
      await open(page);
      await estimate(page, '1 piece chicken');
      const it = page.getByTestId('estimate-item').first();
      await expect(it.getByTestId('estimate-ambiguous')).toContainText('Choose one');
      await expect(it.getByTestId('estimate-nutrients')).toHaveCount(0);
      await expect(page.getByTestId('estimate-totals')).toContainText('nothing matched yet');
      await it.getByTestId('estimate-food').selectOption({ label: 'Chicken, thigh, roasted (SHIM) (Foundation Foods)' });
      await expect(page.getByTestId('estimate-item').first().getByTestId('estimate-nutrients')).toContainText('209 kcal');
    });

    test(`estimate ${W}: use as components -> DRAFT with ESTIMATED values + provenance; counts only after Confirm; survives export check`, async ({ page }) => {
      await open(page);
      await estimate(page);
      await page.getByTestId('estimate-apply').click();
      const rows = page.getByTestId('component-row');
      await expect(rows).toHaveCount(4);
      await expect(rows.nth(0).getByTestId('component-provenance')).toContainText('fdcId 900001');
      await expect(rows.nth(0).getByTestId('component-kcal-state')).toHaveValue('ESTIMATED');
      await expect(rows.nth(3).getByTestId('component-name')).toHaveValue('mystery stew');
      await expect(rows.nth(3).getByTestId('component-kcal')).toHaveValue('');
      await expect(rows.nth(3).getByTestId('component-kcal-state')).toHaveValue('UNKNOWN');
      expect(await meals(page)).toEqual([]);
      await page.getByTestId('meal-save-draft').click();
      let m = await meals(page);
      expect(m).toHaveLength(1); expect(m[0].lifecycle).toBe('DRAFT');
      expect(m[0].components[0].provenance.fdcId).toBe(900001);
      await page.getByTestId('tab-today').click();
      await expect(page.getByTestId('glance-nutrition')).toContainText('nothing confirmed'); // a draft counts for nothing
      // second meal: confirm
      await page.getByTestId('tab-add').click();
      await page.getByTestId('add-mode-meal').click();
      await page.getByTestId('meal-path-description').click();
      await estimate(page, '1 cup milk');
      await page.getByTestId('estimate-apply').click();
      await page.getByTestId('meal-confirm').click();
      m = await meals(page);
      const conf = m.filter((x) => x.lifecycle === 'CONFIRMED');
      expect(conf).toHaveLength(1);
      expect(conf[0].components[0].provenance.dbVersion).toBeTruthy();
      expect(conf[0].components[0].kcal).toEqual({ value: 149, state: 'ESTIMATED' });
      await page.getByTestId('tab-today').click();
      await expect(page.getByTestId('glance-nutrition')).toContainText('149');
      const chk = await page.evaluate(() => { const st = window.HyroxData.createStore(); return st.exportChecked ? st.exportChecked().restorable : null; });
      expect(chk).toBe(true);
    });

    test(`estimate ${W}: editing a number on an estimated component removes the USDA source note (it is then the owner's number)`, async ({ page }) => {
      await open(page);
      await estimate(page, '1 cup milk');
      await page.getByTestId('estimate-apply').click();
      const row = page.getByTestId('component-row').first();
      await expect(row.getByTestId('component-provenance')).toBeVisible();
      await row.getByTestId('component-kcal').fill('155');
      await expect(row.getByTestId('component-provenance')).toContainText('your own value');
      await page.getByTestId('meal-save-draft').click();
      expect((await meals(page))[0].components[0].provenance).toBeUndefined();
    });

    test(`estimate ${W}: food data file missing -> clear message, manual entry still works, nothing written`, async ({ page }) => {
      await open(page, { db: 'missing' });
      await page.getByTestId('meal-description').fill('1 cup milk');
      await page.getByTestId('estimate-run').click();
      await expect(page.getByTestId('estimate-message')).toContainText('Food data could not be loaded');
      await expect(page.getByTestId('estimate-message')).toContainText('Nothing was changed');
      await expect(page.getByTestId('load-guard')).toBeHidden(); // food-db.js is optional for the load guard
      await page.getByTestId('component-name').fill('Manual milk');
      await page.getByTestId('meal-save-draft').click();
      expect(await meals(page)).toHaveLength(1);
    });

    test(`estimate ${W}: controls are >=44px with >=16px text, no horizontal scroll`, async ({ page }) => {
      await open(page);
      await estimate(page, '1 cup milk, 150 g rice');
      const it = page.getByTestId('estimate-item').first();
      for (const id of ['estimate-qty', 'estimate-measure', 'estimate-grams']) {
        const loc = it.getByTestId(id);
        const b = await loc.boundingBox();
        expect(b.height, id).toBeGreaterThanOrEqual(44);
        const fs = await loc.evaluate((e) => parseFloat(getComputedStyle(e).fontSize));
        expect(fs, id + ' font').toBeGreaterThanOrEqual(16);
      }
      const ab = await page.getByTestId('estimate-run').boundingBox(); expect(ab.height).toBeGreaterThanOrEqual(44);
      const pb = await page.getByTestId('estimate-apply').boundingBox(); expect(pb.height).toBeGreaterThanOrEqual(44);
      await noHScroll(page);
    });
  });
}
