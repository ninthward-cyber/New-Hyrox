'use strict';
// Round 2 UI journeys (Liya 3aa277b) against owner decisions t47u.
// Synthetic data only. Chrome mobile emulation (390px), not Safari/WebKit.
// The clock is fixed in Asia/Qatar so plan weeks are deterministic.
const fs = require('fs');
const path = require('path');
const { test, expect } = require('@playwright/test');
const { openWhy, openFullPlan } = require('./p8-open');

const SCREEN = process.env.P3_SHOTS || path.join(__dirname, '..', 'out', 'screens'); // Claude P5: was /workspace/hyrox-p3/results/screens (not writable on other machines)
const T = '2026-11-17T06:00:00.000Z';
// Tests are independent (each boots its own storage/clock). Not serial, so one failure does not skip the rest.

async function boot(page, { now = '2026-11-19T06:00:00.000Z', data } = {}) {
  await page.clock.setFixedTime(new Date(now));
  await page.goto('./');
  await page.evaluate((d) => {
    localStorage.clear();
    if (typeof d === 'string') localStorage.setItem('hyrox.v1', d);
    else if (d) localStorage.setItem('hyrox.v1', JSON.stringify(d));
  }, data === undefined ? null : data);
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
  // Phase 8: Today's detail sits under two closed folds; open them so the checks below still read the same elements.
  await openWhy(page); await openFullPlan(page);
}
const stored = (page) => page.evaluate(() => JSON.parse(localStorage.getItem('hyrox.v1')));
const base = (extra) => Object.assign({ version: 2, weight: [], workouts: [], nutrition: [] }, extra);
const shot = (page, name) => page.screenshot({ path: path.join(SCREEN, name), fullPage: true });

function weekendValues(options) {
  return options.filter((d) => {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(d)) return false;
    const wd = new Date(d + 'T00:00:00Z').getUTCDay();
    return wd === 0 || wd === 6;
  });
}

test('R2 steps: W1 7,000 / W2 8,000 / W3 9,000 reference goals, missing stays unknown not 0, gate is unknown until complete', async ({ page }) => {
  await boot(page, { now: '2026-11-19T06:00:00.000Z' }); // Thu W1
  await expect(page.getByTestId('today-step-guidance-label')).toContainText('Daily guidance target (adaptive app suggestion)');
  await expect(page.getByTestId('today-step-reference-box')).toContainText('Plan reference goal (v2.1');
  await expect(page.getByTestId('today-step-reference')).toContainText('Week 1 reference goal: 7,000 steps/day');
  await expect(page.getByTestId('today-steps')).toContainText('not recorded');
  await expect(page.getByTestId('today-steps')).toContainText('unknown, not 0');
  await expect(page.getByTestId('today-step-reference-status')).toContainText('unknown');
  await expect(page.getByTestId('today-step-reference-status')).toContainText('not 0');
  await expect(page.getByTestId('today-step-gate')).toHaveAttribute('data-gate-status', 'UNKNOWN');
  await expect(page.getByTestId('today-step-gate')).toContainText('NOT passed');
  await expect(page.getByTestId('today-step-gate')).toContainText('not recorded (unknown)');
  await expect(page.getByTestId('today-step-gate')).not.toContainText('0/10');
  await expect(page.getByTestId('today-step-gate')).not.toContainText('0 h');
  await expect(page.getByTestId('step-guidance-unapproved')).toContainText('NOT approved');
  await shot(page, 'r2-today-steps-w1.png');

  await boot(page, { now: '2026-11-23T06:00:00.000Z' }); // Mon W2
  await expect(page.getByTestId('today-step-reference')).toContainText('Week 2 reference goal: 8,000 steps/day');
  await expect(page.getByTestId('today-steps')).toContainText('unknown, not 0');
  await expect(page.getByTestId('today-step-gate')).toHaveAttribute('data-gate-status', 'UNKNOWN');

  await boot(page, { now: '2026-11-30T06:00:00.000Z' }); // Mon W3
  await expect(page.getByTestId('today-step-reference')).toContainText('Week 3 reference goal: 9,000 steps/day');
  await expect(page.getByTestId('today-step-reference-status')).toContainText('unknown, not 0');
});

test('R2 steps: W4 up to 10,000 with the readiness gate shown as unknown, fail, or pass — never as 0', async ({ page }) => {
  await boot(page, { now: '2026-12-07T06:00:00.000Z' }); // Mon W4
  await expect(page.getByTestId('today-step-reference')).toContainText('Week 4 reference goal: up to 10,000 steps/day, only if you are tolerating the walking volume');
  await expect(page.getByTestId('today-step-do-not-force')).toContainText('Recovery first — do not force the reference goal today');
  await expect(page.getByTestId('today-step-do-not-force')).toContainText('Week 4 tolerance cannot be confirmed');
  await expect(page.getByTestId('today-step-gate')).toHaveAttribute('data-gate-status', 'UNKNOWN');
  await expect(page.getByTestId('today-step-gate')).toContainText('NOT passed');
  await expect(page.getByTestId('today-step-gate')).toContainText('not recorded (unknown)');
  await expect(page.getByTestId('today-step-gate')).not.toContainText('0/10');
  await expect(page.getByTestId('today-steps')).toContainText('unknown, not 0');
  await shot(page, 'r2-w4-gate-unknown.png');

  // FAIL: first-step pain above 2/10. The other three items are recorded and would pass.
  await page.getByTestId('today-checkin').click();
  await page.getByTestId('daily-footPain').fill('4');
  await page.getByTestId('daily-stairKneePain').fill('1');
  await page.getByTestId('daily-sleepH').fill('7');
  await page.getByTestId('daily-limp').selectOption('no');
  await page.getByTestId('daily-submit').click();
  await page.getByTestId('tab-today').click();
  await expect(page.getByTestId('today-step-gate')).toHaveAttribute('data-gate-status', 'FAIL');
  await expect(page.getByTestId('today-step-gate')).toContainText('FAILS');
  await expect(page.getByTestId('today-step-gate')).toContainText('do not force 10,000');
  await expect(page.getByTestId('today-step-do-not-force')).toContainText('a readiness check item failed');
  await expect(page.getByTestId('today-step-reference')).toContainText('up to 10,000');
  await shot(page, 'r2-w4-gate-fail.png');

  // PASS: all four recorded and within limits.
  await page.getByTestId('today-checkin').click();
  await page.getByTestId('daily-footPain').fill('1');
  await page.getByTestId('daily-stairKneePain').fill('1');
  await page.getByTestId('daily-sleepH').fill('7');
  await page.getByTestId('daily-limp').selectOption('no');
  await page.getByTestId('daily-submit').click();
  await page.getByTestId('tab-today').click();
  await expect(page.getByTestId('today-step-gate')).toHaveAttribute('data-gate-status', 'PASS');
  await expect(page.getByTestId('today-step-gate')).toContainText('All four items recorded and passed');
  await expect(page.getByTestId('today-step-reference')).toContainText('up to 10,000');
  await shot(page, 'r2-w4-gate-pass.png');
});

test('R2 variants: Source 25-min fallback shows the prescribed keep/drop/unspecified text, fabricates no loads, and does not complete a session', async ({ page }) => {
  await boot(page);
  await page.getByTestId('tab-add').click();
  await page.getByTestId('add-mode-workout').click();
  // Selecting a slot from an empty form does not confirm; only swapping in the 25-min block list does.
  await page.getByTestId('session-slot').selectOption('v2.1-W1-MON');
  page.once('dialog', (d) => {
    expect(d.message()).toContain('No loads, reps or times are filled in');
    d.accept();
  });
  await page.getByTestId('session-variant').selectOption('SOURCE_25_MIN');
  const rx = page.getByTestId('session-variant-rx');
  await expect(rx).toContainText('Source 25-min fallback');
  await expect(rx).toContainText('Back squat: 2 working sets');
  await expect(rx).toContainText('Bench press: 2 working sets');
  await expect(page.getByTestId('session-variant-keep')).toContainText('Back squat (2 working sets)');
  await expect(page.getByTestId('session-variant-drop')).toContainText('Chest-supported DB row');
  await expect(page.getByTestId('session-variant-unspecified')).toContainText('Reps, load and RPE');
  await expect(page.getByTestId('session-variant-unspecified')).toContainText('not specified');
  const loads = await page.getByTestId('block-loadKg').evaluateAll((els) => els.map((e) => e.value));
  const reps = await page.getByTestId('block-reps').evaluateAll((els) => els.map((e) => e.value));
  expect(loads.every((v) => v === '' || v == null)).toBe(true);
  expect(reps.every((v) => v === '' || v == null)).toBe(true);
  await expect(page.getByTestId('session-variant-summary')).toContainText('Prescribed: Source 25-min fallback');
  await expect(page.getByTestId('session-variant-summary')).toContainText('Actual duration: not recorded');
  await expect(page.getByTestId('session-variant-summary')).toContainText('Choosing a variant never marks a session done');
  // Choosing the variant must not invent a saved completed session.
  expect(await page.evaluate(() => localStorage.getItem('hyrox.v1'))).toBeNull();
  await page.getByTestId('session-status').selectOption('NOT_STARTED');
  await page.getByTestId('session-save').click();
  await expect(page.getByTestId('ext-toast')).toContainText('Saved');
  const raw = await stored(page);
  expect(raw.sessions[0].status).toBe('NOT_STARTED');
  expect(raw.sessions[0].variant).toBe('SOURCE_25_MIN');
  expect(raw.sessions[0].durationMin == null).toBe(true);
  expect((raw.sessions[0].blocks || []).every((b) => b.loadKg == null && b.reps == null)).toBe(true);
  await expect(page.getByTestId('history-session-variant')).toContainText('Prescribed: Source 25-min fallback');
  await expect(page.getByTestId('history-session-variant')).toContainText('Actual duration: not recorded');
  await expect(page.getByTestId('history-session-variant')).toContainText('Actual completion: NOT STARTED');
  await page.getByTestId('tab-today').click();
  await expect(page.getByTestId('plan-summary')).toContainText('20 planned weekday sessions');
  await expect(page.getByTestId('plan-summary')).toContainText('0 completed');
  await expect(page.getByTestId('plan-summary')).toContainText('numerator rule is an OPEN owner decision');
  await shot(page, 'r2-variant-25.png');
});

test('R2 weekend: optional Sat/Sun mobility stays visible; a weekday reschedule onto a cascade-freed Monday never lists Sat/Sun', async ({ page }) => {
  // Seed the approved W2 missed-Monday cascade so Monday 16 Nov is a free weekday.
  await boot(page, { now: '2026-11-23T06:00:00.000Z', data: base({
    planEvents: [{ id: 'e1', createdAt: T, updatedAt: T, date: '2026-11-23', kind: 'MISSED_MONDAY', week: 2 }],
  }) });
  await page.getByTestId('plan-week-2').click();
  const w2opts = page.getByTestId('calendar-weekend-option');
  await expect(w2opts.filter({ hasText: 'Sat 28 Nov' })).toContainText('not a gym make-up');
  await expect(w2opts.filter({ hasText: 'Sat 28 Nov' })).toContainText('Optional, easy');
  await expect(w2opts.filter({ hasText: 'Sun 29 Nov' })).toContainText('Optional 15–20 min mobility');
  await shot(page, 'r2-weekend-options-w2.png');

  await page.getByTestId('tab-add').click();
  await page.getByTestId('add-mode-workout').click();
  await page.getByTestId('session-slot').selectOption('v2.1-W1-TUE');
  await page.getByTestId('session-status').selectOption('SKIPPED');
  await page.getByTestId('session-skip-confirm').check();
  await page.getByTestId('skip-reschedule').check();
  const options = await page.getByTestId('skip-reschedule-date').locator('option').evaluateAll((o) => o.map((x) => x.value).filter(Boolean));
  expect(options).toContain('2026-11-23');
  expect(weekendValues(options)).toEqual([]);
  expect(options).not.toContain('2026-11-21');
  expect(options).not.toContain('2026-11-22');
  expect(options).not.toContain('2026-11-28');
  expect(options).not.toContain('2026-11-29');
  await page.getByTestId('skip-reschedule-date').selectOption('2026-11-23');
  await expect(page.getByTestId('skip-reschedule-caution')).toContainText('your decision');
  await page.getByTestId('session-save').click();
  await expect(page.getByTestId('ext-toast')).toContainText('Saved');
  const s = (await stored(page)).sessions[0];
  expect(s.status).toBe('SKIPPED');
  expect(s.skipDecision).toBe('RESCHEDULE');
  expect(s.rescheduledTo).toBe('2026-11-23');
  expect(s.scheduledDate).toBe('2026-11-17');
  await page.getByTestId('tab-today').click();
  await expect(page.getByTestId('plan-calendar').getByTestId('slot-skip-decision').first()).toContainText('rescheduled it to Mon 23 Nov');
  await expect(page.getByTestId('plan-calendar').getByTestId('slot-skip-decision').first()).toContainText('Original plan date kept: Tue 17 Nov');
  await expect(page.getByTestId('plan-summary')).toContainText('1 of the skipped rescheduled and not yet done');
});

test('R2 weekend: a Saturday gym session linked to a missed weekday is actual work, not a source-approved reschedule; the original prescription stays', async ({ page }) => {
  await boot(page, { now: '2026-11-23T06:00:00.000Z' });
  // Skip Tuesday permanently first, then log Saturday work against the same slot.
  await page.getByTestId('tab-add').click();
  await page.getByTestId('add-mode-workout').click();
  await page.getByTestId('session-slot').selectOption('v2.1-W1-TUE');
  await page.getByTestId('session-status').selectOption('SKIPPED');
  await page.getByTestId('session-skip-confirm').check();
  await page.getByTestId('skip-skip_permanent').check();
  await page.getByTestId('session-save').click();
  await expect(page.getByTestId('ext-toast')).toContainText('Saved');

  await page.getByTestId('tab-today').click();
  // Clock is Mon 23 Nov (W2); the missed Tuesday slot lives on the Week 1 calendar.
  await page.getByTestId('plan-week-1').click();
  await page.getByTestId('plan-calendar').getByTestId('log-slot-v2.1-W1-TUE').click();
  await page.getByTestId('session-date').fill('2026-11-21');
  await page.getByTestId('session-status').selectOption('COMPLETED');
  await expect(page.getByTestId('session-weekend-note')).toContainText('Performed on a weekend: this is logged as ACTUAL work, not as a source-approved reschedule');
  await expect(page.getByTestId('session-weekend-note')).toContainText('Tue 17 Nov');
  await page.getByTestId('session-save').click();
  await expect(page.getByTestId('ext-toast')).toContainText('Saved');

  const raw = await stored(page);
  const sat = raw.sessions.find((x) => x.date === '2026-11-21');
  const skipped = raw.sessions.find((x) => x.status === 'SKIPPED' && x.planSlotId === 'v2.1-W1-TUE');
  expect(sat && sat.status).toBe('COMPLETED');
  expect(sat.planSlotId).toBe('v2.1-W1-TUE');
  expect(skipped && skipped.scheduledDate).toBe('2026-11-17');
  expect(skipped.skipDecision).toBe('SKIP_PERMANENT');

  await page.getByTestId('tab-today').click();
  await page.getByTestId('plan-week-1').click();
  const tue = page.getByTestId('plan-calendar').getByTestId('slot-v2.1-W1-TUE');
  await expect(tue.getByTestId('slot-status')).toHaveText('Skipped (confirmed)');
  await expect(tue.getByTestId('slot-weekend-actual')).toContainText('Logged as ACTUAL work on Sat 21 Nov');
  await expect(tue.getByTestId('slot-weekend-actual')).toContainText('not a source-approved reschedule');
  await expect(tue.getByTestId('slot-weekend-actual')).toContainText('The original Tue 17 Nov prescription stays on record');
  await expect(tue.getByTestId('slot-skip-decision')).toContainText('skipped this permanently');
  await expect(page.getByTestId('plan-summary')).toContainText('weekend session(s) logged as actual work (not source-approved make-ups)');
  await page.getByTestId('tab-history').click();
  await expect(page.getByTestId('history-weekend-actual')).toContainText('Weekend actual work — not a source reschedule');
  await shot(page, 'r2-weekend-actual.png');
});
