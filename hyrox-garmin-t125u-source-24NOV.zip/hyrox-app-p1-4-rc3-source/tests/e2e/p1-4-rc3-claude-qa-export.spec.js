'use strict';
// Claude independent QA of Grok's P1.4-RC2, 23 Nov 2026 (delivered as P1.4-RC3): honest hand-over buttons and typed Garmin
// intensity minutes in the coaching snapshot. Helpers are the ones of p1-4-coach-export.spec.js.
// Sprint D (P1.4) Export for AI Coaching, browser tests CE-E-01..09 (HNC-E-COACH-001 section 10). The iPhone share sheet is
// EMULATED by stubbing navigator.share / navigator.canShare; this proves the app's labels and fallbacks, NOT that iOS accepts
// a JSON file (device test CE-D-02). Synthetic data only. CHROME EMULATION, NOT SAFARI/WEBKIT, not a physical iPhone.
const fs = require('fs');
const { test, expect } = require('@playwright/test');

const NOW = '2026-11-18T09:00:00.000Z'; // Wed 18 Nov 2026 12:00 Qatar
const FORBIDDEN = ['synced', 'uploaded', 'saved to drive', 'sent to chatgpt', 'backed up', 'up to date'];
const seedFn = () => {
  const HD = window.HyroxData, st = HD.createStore(), ts = new Date().toISOString();
  const E = (v) => ({ value: v, state: 'ESTIMATED' }), U = () => ({ value: null, state: 'UNKNOWN' });
  const put = (t, r) => { const x = st.putRecord(t, r); if (!x.ok) throw new Error(t + JSON.stringify(x.errors)); };
  put('meals', { id: 'm-1', date: '2026-11-16', time: '13:00', label: 'FT-LABEL', description: 'FT-DESC', source: 'DESCRIPTION', lifecycle: 'CONFIRMED', confirmedAt: ts, mealCategory: 'LUNCH',
    components: [{ name: 'Chicken', role: 'MAIN', portion: '200 g', preparation: '', eatenFraction: null, kcal: E(330), proteinG: E(62), carbsG: E(0), fatG: E(7) }, { name: 'Oil', role: 'OIL', portion: '', preparation: '', eatenFraction: null, kcal: U(), proteinG: U(), carbsG: U(), fatG: U() }] });
  put('meals', { id: 'm-2', date: '2026-11-17', time: '19:00', label: '', description: '', source: 'MANUAL', lifecycle: 'DRAFT', components: [{ name: 'SECRET-DRAFT-NAME', role: 'MAIN', portion: '', preparation: '', eatenFraction: null, kcal: E(700), proteinG: E(20), carbsG: E(90), fatG: E(20) }] });
  put('sessions', { id: 's-1', date: '2026-11-16', title: 'Strength A', status: 'COMPLETED', modified: false, variant: 'ORIGINAL_60', planSlotId: 'v2.1-W1-MON', planVersion: 'v2.1', scheduledDate: '2026-11-16', durationMin: 55, rpe: 7, notes: 'FT-NOTE', blocks: [] });
  put('daily', { date: '2026-11-16', steps: { state: 'OBSERVED', value: 7000 }, sleepH: { state: 'OBSERVED', value: 6 }, pain: { state: 'OBSERVED', value: 3 } });
  if (!st.addWeight({ date: '2026-11-16', kg: '98.4' }).ok) throw new Error('w');
  localStorage.setItem('hyrox.ai-owner-code', 'OWNER-CODE-SYNTH-1');
};
async function boot(page, opts) {
  opts = opts || {};
  const errs = []; page.on('pageerror', (e) => errs.push(e.message));
  const reqs = []; page.on('request', (r) => { if (!/^(data|blob):/.test(r.url())) reqs.push(r.url()); });
  await page.clock.setFixedTime(new Date(NOW));
  await page.addInitScript((mode) => {
    window.__shared = [];
    if (mode === 'none') { try { delete Navigator.prototype.share; delete Navigator.prototype.canShare; } catch (e) { /* */ } Object.defineProperty(navigator, 'share', { value: undefined, configurable: true }); Object.defineProperty(navigator, 'canShare', { value: undefined, configurable: true }); return; }
    Object.defineProperty(navigator, 'canShare', { configurable: true, value: (d) => mode !== 'reject' && !!(d && d.files && d.files.length) });
    Object.defineProperty(navigator, 'share', { configurable: true, value: async (d) => {
      const f = d.files[0]; window.__shared.push({ name: f.name, type: f.type, text: await f.text() });
      if (mode === 'abort') { const e = new Error('cancelled'); e.name = 'AbortError'; throw e; }
      if (mode === 'error') { const e = new Error('blocked'); e.name = 'NotAllowedError'; throw e; }
    } });
  }, opts.share || 'ok');
  await page.goto('./');
  await page.evaluate(() => localStorage.clear());
  if (opts.seed !== false) await page.evaluate(seedFn);
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
  await page.getByTestId('tab-settings').click();
  await page.getByTestId('coach-export').scrollIntoViewIfNeeded();
  return { errs, reqs };
}
const allKeys = (page) => page.evaluate(() => { const o = {}; for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); o[k] = localStorage.getItem(k); } return o; });
const panelText = async (page) => (await page.getByTestId('coach-export').innerText()).toLowerCase();


for (const W of [390, 320]) {
  test.describe(`P1.4-RC3 Claude QA: coaching export ${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    for (const mode of ['none', 'reject']) {
      test(`${W}: FAIL-FIRST — where a file cannot be shared (${mode}), no "Share again" is offered after the download fallback; the button says "Download again"`, async ({ page }) => {
        const { errs } = await boot(page, { share: mode });
        const [dl] = await Promise.all([page.waitForEvent('download'), page.getByTestId('ce-create').click()]);
        expect(dl.suggestedFilename()).toMatch(/^hyrox-coaching-.*\.json$/);
        await expect(page.getByTestId('ce-status')).toHaveAttribute('data-kind', 'fallback');
        await expect(page.getByTestId('ce-share')).toHaveCount(0);
        await expect(page.getByTestId('ce-download')).toHaveText('Download again');
        await page.waitForTimeout(750);
        const [dl2] = await Promise.all([page.waitForEvent('download'), page.getByTestId('ce-download').click()]);
        expect(dl2.suggestedFilename()).toBe(dl.suggestedFilename());
        await expect(page.getByTestId('ce-status')).toHaveText(/^Download started\./);
        expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
        expect(errs).toEqual([]);
      });
    }

    test(`${W}: GUARD (passes before and after) — where sharing works, "Share again" and "Download instead" are both offered`, async ({ page }) => {
      await boot(page, { share: 'abort' });
      await page.getByTestId('ce-create').click();
      await expect(page.getByTestId('ce-status')).toHaveAttribute('data-kind', 'cancelled');
      await expect(page.getByTestId('ce-share')).toHaveText('Share again');
      await expect(page.getByTestId('ce-download')).toHaveText('Download instead');
    });

    test(`${W}: FAIL-FIRST — the panel says that names (food, session, exercise) go out even with "Free-text notes" off, and the snapshot agrees`, async ({ page }) => {
      await boot(page, { share: 'none' });
      await expect(page.getByTestId('ce-cat-freeText')).not.toBeChecked();
      await expect(page.getByTestId('ce-names-note')).toContainText('always includes its names');
      const [dl] = await Promise.all([page.waitForEvent('download'), page.getByTestId('ce-create').click()]);
      const snap = JSON.parse(fs.readFileSync(await dl.path(), 'utf8'));
      expect(snap.selection.freeText).toBe(false);
      const names = snap.nutrition.meals.flatMap((m) => m.components.map((c) => c.name)).concat(snap.training.sessions.map((s) => s.title));
      expect(names.filter((n) => typeof n === 'string' && n).length).toBeGreaterThan(0);   // names are in the file
      expect(JSON.stringify(snap)).not.toContain('"notes"');                              // notes are not
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
    });

    test(`${W}: FAIL-FIRST — the snapshot carries the typed Garmin intensity minutes (46 stays 46) under Steps, and the Steps choice says so`, async ({ page }) => {
      await boot(page, { share: 'none' });
      await page.evaluate(() => { const d = JSON.parse(localStorage.getItem('hyrox.v1')); const r = d.daily.find((x) => x.date === '2026-11-16'); r.intensityMin = { state: 'OBSERVED', value: 46, source: 'GARMIN_MANUAL' }; localStorage.setItem('hyrox.v1', JSON.stringify(d)); });
      await page.reload(); await page.getByTestId('tab-settings').click();
      await expect(page.getByTestId('coach-export')).toContainText('Steps and intensity minutes');
      const [dl] = await Promise.all([page.waitForEvent('download'), page.getByTestId('ce-create').click()]);
      const snap = JSON.parse(fs.readFileSync(await dl.path(), 'utf8'));
      const row = snap.steps.daily.find((x) => x.date === '2026-11-16');
      expect(row.steps).toEqual({ state: 'OBSERVED', value: 7000 });
      expect(row.garminIntensityMin).toEqual({ state: 'OBSERVED', value: 46, source: 'GARMIN_MANUAL' });
      expect(snap.recovery).toBeUndefined(); expect(snap.symptoms).toBeUndefined();   // still off by default
    });
  });
}
