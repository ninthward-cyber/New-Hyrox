'use strict';
// Phase 11.3 part 1: the larger free US food list (USDA FNDDS 2021-2023) in Add foods. Synthetic data; no AI; no network
// while typing. CHROME MOBILE EMULATION, NOT SAFARI/WEBKIT.
const { test, expect } = require('@playwright/test');
// P0 (22 Nov 2026): the meal diary moved from Today to Add > Meal ("Log meal" on Today opens it). This brings it on screen
// the way the owner does; it does nothing when the diary or a dedicated logger is already showing.
async function diary(page) {
  if (await page.getByTestId('meal-diary').isVisible()) return;
  if (await page.getByTestId('logger-head').isVisible()) return;
  if (!(await page.getByTestId('panel-today').isVisible())) await page.getByTestId('tab-today').click();
  await page.getByTestId('today-add-meal').click();
  await page.getByTestId('meal-diary').waitFor();
}

const NOW = '2026-11-19T09:00:00.000Z';
async function open(page) {
  page._errs = []; page.on('pageerror', (e) => page._errs.push(e.message));
  page._reqs = []; page.on('request', (r) => page._reqs.push(r.url()));
  await page.clock.setFixedTime(new Date(NOW));
  await page.goto('./'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
}
async function foods(page, cat = 'lunch') {
  await diary(page); await page.getByTestId('diary-log-' + cat).click();
  await page.getByTestId('meal-add-foods').click();
  await expect(page.getByTestId('foods-status')).not.toContainText('Loading');
}
const row = (page, name) => page.getByTestId('food-result').filter({ has: page.locator('.food-name', { hasText: new RegExp('^' + name.replace(/[()]/g, '\\$&') + '$') }) });
const stored = async (page) => JSON.parse((await page.evaluate(() => localStorage.getItem('hyrox.v1'))) || '{}');

for (const W of [390, 320]) {
  test.describe(`P11.3 US foods ${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`${W}: "4 boiled eggs" finds SR + FNDDS eggs; quantity is chosen by the owner (never from the typed 4); fiber/sodium shown; no network while typing`, async ({ page }) => {
      await open(page); await foods(page, 'breakfast');
      await expect(page.getByTestId('foods-status')).toContainText('13,598 foods');
      expect(page._reqs.some((u) => /food-db-us\.js$/.test(u))).toBe(true); // one static file when the screen opens
      const before = page._reqs.length;
      await page.getByTestId('foods-q').pressSequentially('4 boiled eggs', { delay: 25 });
      await expect(page.getByTestId('food-result').first()).toContainText('Egg, whole, cooked, hard-boiled');
      const fn = row(page, 'Egg, whole, boiled or poached');
      await expect(fn).toContainText('USDA FNDDS 2021-2023 (survey)');
      expect(page._reqs.slice(before)).toEqual([]);
      await fn.getByTestId('food-pick').click();
      await expect(page.getByTestId('food-qty')).toHaveValue('1');
      await expect(page.getByTestId('food-preview')).toHaveText('1 egg (50 g) · 72 kcal · estimate');
      await page.getByTestId('food-qty').fill('4');
      await expect(page.getByTestId('food-preview')).toHaveText('4 × 1 egg (200 g) · 286 kcal · estimate');
      await page.getByTestId('food-more').locator('summary').click();
      await expect(page.getByTestId('food-fiberG')).toHaveText('0 g');
      await expect(page.getByTestId('food-sodiumMg')).toHaveText('258 mg');
      await expect(page.getByTestId('food-source')).toContainText('USDA FNDDS 2021-2023 (survey), fdcId 2707154');
      await page.getByTestId('food-add').click(); await page.getByTestId('foods-done').click();
      await page.getByTestId('meal-confirm').click();
      await expect(page.getByTestId('diary-sub-breakfast')).toHaveText('1 entry · 286 kcal');
      const c = (await stored(page)).meals[0].components[0];
      expect([c.provenance.dataset, c.provenance.fdcId, c.provenance.grams, c.sodiumMg, (await stored(page)).meals[0].source, (await stored(page)).version]).toEqual(['FN', 2707154, 200, { value: 258, state: 'ESTIMATED' }, 'MANUAL', 2]);
      expect(page._errs).toEqual([]);
    });

    test(`${W}: "1 can tuna" offers canned tuna with real USDA can sizes; "chicken breast 200g" finds chicken breast and still asks for the amount`, async ({ page }) => {
      await open(page); await foods(page);
      await page.getByTestId('foods-q').fill('1 can tuna');
      await expect(page.getByTestId('food-result').first()).toContainText('Fish, tuna, light, canned in water');
      const t = row(page, 'Fish, tuna, canned');
      await expect(t).toBeVisible();
      await t.getByTestId('food-pick').click();
      await page.getByTestId('food-serving').selectOption({ label: '1 standard can (115 g)' });
      await expect(page.getByTestId('food-preview')).toHaveText('1 standard can (115 g) · 98 kcal · estimate');
      await page.getByTestId('foods-q').fill('chicken breast 200g');
      await expect(page.getByTestId('food-result').first()).toContainText('Chicken, broilers or fryers, breast');
      await page.getByTestId('food-pick').first().click();
      await expect(page.getByTestId('food-qty')).toHaveValue('1');
      await page.getByTestId('food-serving').selectOption({ label: '1 g (1 g)' }); await page.getByTestId('food-qty').fill('200');
      await expect(page.getByTestId('food-error')).toContainText('quantity'); // > 50 servings refused: use 100 g × 2 instead
      await page.getByTestId('food-serving').selectOption({ label: '100 g (100 g)' }); await page.getByTestId('food-qty').fill('2');
      await expect(page.getByTestId('food-preview')).toContainText('2 × 100 g (200 g)');
      expect(page._errs).toEqual([]);
    });

    test(`${W}: chain items are labelled as USDA estimates (not official, may differ in Qatar); generic restaurant-style items are labelled apart`, async ({ page }) => {
      await open(page); await foods(page);
      await page.getByTestId('foods-q').fill('big mac');
      const fn = row(page, 'Big Mac (McDonalds)');
      await expect(fn.getByTestId('food-restaurant')).toHaveText('Chain item · USDA survey estimate (US)');
      await expect(row(page, "McDONALD'S, BIG MAC").getByTestId('food-restaurant')).toHaveText('Restaurant · US 2018');
      await fn.getByTestId('food-pick').click();
      await page.getByTestId('food-more').locator('summary').click();
      await expect(page.getByTestId('food-source')).toContainText("NOT the restaurant's official figure");
      await expect(page.getByTestId('food-source')).toContainText('Qatar branches');
      await page.getByTestId('foods-q').fill('chicken nuggets');
      await expect(row(page, 'Chicken nuggets, from fast food').getByTestId('food-restaurant-style')).toHaveText('Restaurant-style · generic USDA');
      await expect(row(page, 'Chicken nuggets, NFS').locator('.badge')).toHaveCount(0);
      expect(page._errs).toEqual([]);
    });

    test(`${W}: a chain's official value typed by the owner, confirmed, can be saved to My foods (kept as "your values", sodium kept) and reused`, async ({ page }) => {
      await open(page); await foods(page);
      await page.getByTestId('foods-q').fill('quarter pounder official');
      await expect(page.getByTestId('foods-none')).toBeVisible();
      await page.getByTestId('foods-none-manual').click();
      await page.getByTestId('component-name').fill('Quarter Pounder (US app value)');
      await page.getByTestId('component-kcal').fill('520');
      await page.getByTestId('component-kcal-state').selectOption('KNOWN');
      await page.getByTestId('component-extra').locator('summary').click();
      await page.getByTestId('component-sodiumMg').fill('1140');
      await page.getByTestId('meal-confirm').click();
      await page.getByTestId('tab-history').click();
      await page.getByTestId('meal-save-myfoods').click(); await page.getByTestId('myfoods-pick-save').click();
      const mf = (await stored(page)).ownerSettings[0].myFoods[0];
      expect([mf.name, mf.basis, mf.kcal, mf.sodiumMg, 'fiberG' in mf, 'provenance' in mf]).toEqual(['Quarter Pounder (US app value)', 'your values', { value: 520, state: 'KNOWN' }, { value: 1140, state: 'KNOWN', by: 'OWNER' }, false, false]); // RC2 review: typed sodium keeps its owner origin
      await page.getByTestId('tab-today').click(); await foods(page, 'dinner');
      await page.getByTestId('foods-tab-my').click();
      await expect(page.getByTestId('food-result')).toContainText('My food · your values');
      expect(page._errs).toEqual([]);
    });

    test(`${W}: if the larger list cannot load, search still runs on the original 8,167 foods and says so; offline after loading still works`, async ({ page, context }) => {
      await page.route('**/food-db-us.js', (r) => r.abort());
      await open(page); await foods(page);
      await expect(page.getByTestId('foods-status')).toContainText('8,167 foods');
      await expect(page.getByTestId('foods-status')).toContainText('could not be loaded');
      await page.getByTestId('foods-q').fill('banana');
      await expect(page.getByTestId('food-result').first()).toContainText('Bananas, raw');
      await expect(row(page, 'Banana, raw')).toHaveCount(0);
      await page.unroute('**/food-db-us.js');
      const p2 = await context.newPage(); p2._errs = []; p2.on('pageerror', (e) => p2._errs.push(e.message)); p2._reqs = []; p2.on('request', (r) => p2._reqs.push(r.url()));
      await p2.clock.setFixedTime(new Date(NOW)); await p2.goto('./'); await foods(p2);
      await context.setOffline(true);
      await p2.getByTestId('foods-q').fill('grilled cheese');
      await expect(p2.getByTestId('food-result').first()).toContainText('Grilled cheese sandwich, NFS');
      await context.setOffline(false);
      expect(page._errs).toEqual([]); expect(p2._errs).toEqual([]);
    });
  });
}
