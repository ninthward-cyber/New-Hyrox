'use strict';
// P5 (Liya t69u) test-only shim for /workspace/hyrox-p5/CONTRACT.md (FINAL, p5/data 55c165f), used by p5-restore-safety.spec.js.
// Chrome emulation, not Safari. Injected with page.addInitScript; it never ships in the app.
//  - mode 'auto' (default): if the data layer already has store.exportChecked (Dawit's P5 build), the REAL
//    store is used unchanged (only applyImport options are recorded for assertions); otherwise the
//    contract fields are emulated on top of the real P4 store, following CONTRACT.md literally.
//  - window.__P5_FORCE_APPLY (test-only): replaces applyImport's answer to show a given refusal code.
function p5ContractShim(cfg) {
  cfg = cfg || {};
  var LIST_KEYS = ['weight', 'workouts', 'nutrition', 'sessions', 'meals', 'body', 'daily', 'walks', 'dayStates', 'planEvents', 'ownerSettings'];
  var KEY = 'hyrox.v1', SLOT = 'hyrox.v1.pre-import-backup';
  window.__P5 = { applyCalls: [], shimmed: null, force: cfg.forceApply || null };
  function countsOf(obj) {
    var c = { total: 0 };
    LIST_KEYS.forEach(function (k) { var n = obj && Array.isArray(obj[k]) ? obj[k].length : 0; c[k] = n; c.total += n; });
    return c;
  }
  function storedCounts() { var raw = localStorage.getItem(KEY); try { return countsOf(raw ? JSON.parse(raw) : {}); } catch (e) { return countsOf({}); } }
  function slot() {
    var v = localStorage.getItem(SLOT); if (v === null) return null;
    try { var e = JSON.parse(v); return e && typeof e === 'object' ? e : null; } catch (x) { return null; }
  }
  function slotBlocks(e) {
    if (!e || e.restoreState !== 'pending') return false;
    if (e.raw === null || e.raw === undefined || e.raw === '') return false;
    return e.raw !== localStorage.getItem(KEY);
  }
  function wrapStore(real) {
    var native = typeof real.exportChecked === 'function' && cfg.mode !== 'force';
    window.__P5.shimmed = !native;
    var s = Object.create(real);
    s.applyImport = function (text, opts) {
      window.__P5.applyCalls.push(JSON.parse(JSON.stringify(opts || {})));
      if (window.__P5.force) return window.__P5.force;
      if (!native) {
        var e = slot();
        if (slotBlocks(e)) return { ok: false, code: 'prior_copy_unresolved', message: 'SHIM: Not restored: a previous restore did not finish; its pre-import copy is the only copy of your earlier data. Nothing was changed.', errors: [], rolledBack: false, backupKey: SLOT };
        var pv = real.previewImport(text);
        if (pv && pv.ok) {
          var inc = countsOf(JSON.parse(text)), cur = storedCounts(), st = real.status().state;
          if (inc.total === 0 && cur.total > 0 && st !== 'corrupt' && !(opts && opts.confirmEmptyReplace === true)) {
            return { ok: false, code: 'empty_replace_not_confirmed', message: 'SHIM: Not restored: this empty backup would remove the entries on this device. Confirm the empty restore a second time.', errors: [], rolledBack: false, backupKey: null };
          }
        }
      }
      return real.applyImport(text, opts);
    };
    if (native) return s;
    s.previewImport = function (text) {
      var r = real.previewImport(text);
      if (!r || r.ok !== true) return r;
      var p = Object.assign({}, r.preview);
      var inc = countsOf(JSON.parse(text)), cur = storedCounts(), st = p.currentState;
      p.replaceSummary = { incoming: inc, current: cur, currentState: st };
      p.emptyReplacesPopulated = inc.total === 0 && cur.total > 0 && st !== 'corrupt';
      var e = slot();
      p.priorCopy = e ? { blocksRestore: slotBlocks(e), restoreState: e.restoreState || 'completed', savedAt: e.savedAt || null } : null;
      return { ok: true, preview: p };
    };
    s.status = function () {
      var st = real.status();
      var e = slot();
      if (st && e) st = Object.assign({}, st, { priorCopy: { restoreState: e.restoreState || 'completed', blocksNextRestore: slotBlocks(e), savedAt: e.savedAt || null } });
      return st;
    };
    function check(text) {
      var pv = real.previewImport(text);
      if (pv && pv.ok) return { restorable: true, reasons: [] };
      var d = pv && Array.isArray(pv.details) ? pv.details : [];
      var reasons = d.length ? d.slice(0, 20).map(function (x) { return { code: x.code || pv.code, collection: x.collection, index: x.index, id: x.id, date: x.date, field: x.field, message: x.message, howToCorrect: x.howToCorrect }; })
        : [{ code: (pv && pv.code) || 'check_failed', message: (pv && pv.message) || 'The check failed.' }];
      return { restorable: false, reasons: reasons, reasonsTotal: pv && pv.detailsTotal || reasons.length };
    }
    s.exportChecked = function () {
      var text; try { text = real.exportJSON(); } catch (e) { return { ok: false, code: 'export_unavailable', message: 'SHIM: ' + e.message }; }
      var c = check(text);
      return { ok: true, text: text, exportedAt: null, restorable: c.restorable, reasons: c.reasons, reasonsTotal: c.reasonsTotal || 0, reasonsTruncated: false, warnings: [] };
    };
    s.rawRecoveryExport = function () {
      var v = real.rawRecoveryExport(); if (!v || typeof v !== 'object' || v.ok !== true) return v;
      var text; try { text = real.exportJSON(); } catch (e) { return v; }
      var c = check(text); return Object.assign({}, v, { normalRestorable: c.restorable, normalRestorableReasons: c.reasons });
    };
    return s;
  }
  var hd;
  Object.defineProperty(window, 'HyroxData', { configurable: true, get: function () { return hd; }, set: function (v) {
    if (v && typeof v.createStore === 'function') {
      var orig = v.createStore;
      v = Object.assign({}, v);
      v.createStore = function () { return wrapStore(orig.apply(this, arguments)); };
    }
    hd = v;
  } });
}
module.exports = { p5ContractShim };
