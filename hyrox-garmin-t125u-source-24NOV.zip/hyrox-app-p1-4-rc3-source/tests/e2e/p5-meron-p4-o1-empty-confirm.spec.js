'use strict';
// P5 Meron e2e for P4-O1 UI: empty backup onto populated data needs a SECOND,
// separate confirmation. Cancel / close / Escape write nothing. Warning must be an
// unmistakable EMPTY BACKUP message showing current vs incoming counts (replaceSummary).
// Chrome emulation, not Safari/WebKit. 390x844. Synthetic data only.
// Adapted from the Phase 5 red spec so it passes on the fixed UI without weakening
// the original assertions: the first Replace must still write nothing, and a
// separate second-confirm control (import-empty-confirm) is required. On the
// fixed UI, Replace is disabled until that tickbox is checked — a stronger gate
// than "click then look for a second control".
const { test, expect } = require('@playwright/test');
const { gotoClassic, gotoSettings, addWeight } = require('./helpers');

const EMPTY = JSON.stringify({
  app: 'hyrox-app',
  version: 2,
  exportedAt: '2026-11-11T09:00:00.000Z',
  weight: [], workouts: [], nutrition: [],
});

async function seedPopulated(page) {
  await page.goto('./');
  await addWeight(page, '80');
  await expect(page.getByTestId('weight-item').filter({ hasText: '80' })).toBeVisible();
}

async function pickEmptyBackup(page) {
  await gotoSettings(page);
  await page.getByTestId('import-file').setInputFiles({
    name: 'empty-backup.json',
    mimeType: 'application/json',
    buffer: Buffer.from(EMPTY, 'utf8'),
  });
}

async function storageSnap(page) {
  return page.evaluate(() => {
    const out = {};
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      out[k] = localStorage.getItem(k);
    }
    return JSON.stringify(Object.keys(out).sort().map((k) => [k, out[k]]));
  });
}

async function liveWeightCount(page) {
  return page.evaluate(() => {
    try {
      const raw = localStorage.getItem('hyrox.v1');
      if (!raw) return 0;
      const o = JSON.parse(raw);
      return Array.isArray(o.weight) ? o.weight.length : 0;
    } catch (e) { return -1; }
  });
}

function secondConfirm() {
  // Official second-confirm testid is import-empty-confirm (Liya). Keep the
  // original red-spec candidates so a rename cannot silently drop the gate.
  return [
    'import-confirm-empty',
    'import-empty-confirm',
    'import-confirm-empty-replace',
    'import-second-confirm',
    'import-empty-second-confirm',
  ];
}

test.describe('P4-O1 UI (Chrome emulation, not Safari/WebKit): empty backup onto populated data', () => {
  test('an EMPTY BACKUP warning is shown with current vs incoming counts', async ({ page }) => {
    await seedPopulated(page);
    await pickEmptyBackup(page);
    const preview = page.getByTestId('import-preview');
    await preview.waitFor({ state: 'visible' });
    await expect(page.getByTestId('import-count-weight')).toHaveText('0');
    await expect(page.getByTestId('import-count-workouts')).toHaveText('0');
    await expect(page.getByTestId('import-count-nutrition')).toHaveText('0');
    await expect(page.getByTestId('import-current')).toBeVisible();
    await expect(page.getByTestId('import-current')).toContainText(/1|weight/i);

    const warn = page.getByTestId('import-empty-warning');
    await expect(warn).toBeVisible();
    const text = await warn.innerText();
    expect(text, 'warning must say this backup is EMPTY: ' + text).toMatch(/empty/i);
    expect(text).toMatch(/EMPTY BACKUP/i);
    // Current vs incoming counts must be visible in the warning or the preview.
    const previewText = (await preview.innerText());
    expect(previewText, 'current vs incoming counts must be visible').toMatch(/0/);
    expect(previewText).toMatch(/1/);
    // A dedicated second-confirm control must be present (not a reuse of #import-confirm alone).
    const hasSecond = await (async () => {
      for (const id of secondConfirm()) {
        if (await page.getByTestId(id).count()) return id;
      }
      return null;
    })();
    expect(hasSecond, 'a separate second-confirm control must be present when the EMPTY BACKUP warning is shown').toBeTruthy();
    if (!hasSecond) {
      expect(
        text + ' ' + previewText,
        'without a separate second-confirm control, the warning must clearly require a further confirmation and show that incoming is empty / current has entries'
      ).toMatch(/confirm|replace \d+|with nothing/i);
    }
  });

  test('the first Replace click must NOT restore; a separate second confirmation is required', async ({ page }) => {
    await seedPopulated(page);
    await pickEmptyBackup(page);
    await page.getByTestId('import-preview').waitFor({ state: 'visible' });
    const before = await storageSnap(page);
    expect(await liveWeightCount(page)).toBe(1);

    const confirm = page.getByTestId('import-confirm');
    // Stronger than the baseline red check: Replace itself is disabled until the
    // separate tickbox is checked, so a first click cannot restore.
    await expect(confirm).toBeDisabled();

    let second = null;
    for (const id of secondConfirm()) {
      const loc = page.getByTestId(id);
      if (await loc.count() && await loc.isVisible()) { second = loc; break; }
    }
    expect(second, 'a separate second-confirmation control must be visible (missing on baseline)').toBeTruthy();

    // Force-click the disabled Replace (as a user or assistive tool might try).
    // Must write nothing.
    await confirm.click({ force: true });
    expect(await liveWeightCount(page), 'first Replace must not restore').toBe(1);
    expect(await storageSnap(page), 'first confirm must write nothing until the second confirmation').toBe(before);
  });

  test('Cancel writes nothing and dismisses the pending empty restore', async ({ page }) => {
    await seedPopulated(page);
    await pickEmptyBackup(page);
    await page.getByTestId('import-preview').waitFor({ state: 'visible' });
    const before = await storageSnap(page);
    await page.getByTestId('import-cancel').click();
    await expect(page.getByTestId('import-preview')).toBeHidden();
    await expect(page.getByTestId('import-status')).toContainText(/cancelled|nothing/i);
    expect(await storageSnap(page)).toBe(before);
    expect(await liveWeightCount(page)).toBe(1);
  });

  test('Escape writes nothing and dismisses the pending empty restore', async ({ page }) => {
    await seedPopulated(page);
    await pickEmptyBackup(page);
    await page.getByTestId('import-preview').waitFor({ state: 'visible' });
    const before = await storageSnap(page);
    await page.keyboard.press('Escape');
    await expect(page.getByTestId('import-preview')).toBeHidden();
    expect(await storageSnap(page), 'Escape must write nothing').toBe(before);
    expect(await liveWeightCount(page)).toBe(1);
  });

  test('a non-empty backup does not use the empty-backup second confirmation', async ({ page }) => {
    await seedPopulated(page);
    const nonempty = JSON.stringify({
      app: 'hyrox-app', version: 2, exportedAt: '2026-11-11T09:00:00.000Z',
      weight: [{ id: 'w-in', createdAt: '2026-11-11T09:00:00.000Z', date: '2026-11-10', kg: 77 }],
      workouts: [], nutrition: [],
    });
    await gotoSettings(page);
    await page.getByTestId('import-file').setInputFiles({
      name: 'one-weight.json', mimeType: 'application/json', buffer: Buffer.from(nonempty, 'utf8'),
    });
    await page.getByTestId('import-preview').waitFor({ state: 'visible' });
    await expect(page.getByTestId('import-count-weight')).toHaveText('1');
    await expect(page.getByTestId('import-empty-warning')).toBeHidden();
    await page.getByTestId('import-confirm').click();
    await expect(page.getByTestId('import-result')).toContainText(/restored/i);
    await gotoClassic(page);
    await expect(page.getByTestId('weight-item').filter({ hasText: '77' })).toBeVisible();
  });
});
