'use strict';
// Phase 11.2 part 2 (11.1 P1): compact healthy-habit rows on Today — steps (with the day's existing target), exercise
// (recorded sessions/walks only; no calorie burn), latest measured weight with its date. No water row: the app has no
// water-volume field (follow-up). Synthetic data. CHROME MOBILE EMULATION, NOT SAFARI/WEBKIT.
const { test, expect } = require('@playwright/test');
const NOW = '2026-11-19T09:00:00.000Z'; // 12:00 Asia/Qatar, Thu 19 Nov 2026
const T = '2026-11-19T05:00:00.000Z';
const base = (extra) => Object.assign({ version: 2, weight: [], workouts: [], nutrition: [] }, extra);
async function boot(page, data, at = NOW) {
  page._errs = []; page.on('pageerror', (e) => page._errs.push(e.message));
  await page.clock.setFixedTime(new Date(at));
  await page.goto('./');
  await page.evaluate((d) => { localStorage.clear(); if (d) localStorage.setItem('hyrox.v1', JSON.stringify(d)); }, data || null);
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
}
const noErrors = (page) => expect(page._errs).toEqual([]);
const SESSION = { id: 's1', createdAt: T, updatedAt: T, date: '2026-11-19', title: 'Aerobic HYROX', status: 'COMPLETED', modified: false, variant: 'ORIGINAL_60',
  planSlotId: 'v2.1-W1-THU', planVersion: 'v2.1', scheduledDate: '2026-11-19', durationMin: 55, blocks: [] };

for (const W of [390, 320]) {
  test.describe(`P11.2 healthy habits ${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`${W}: an empty day says unknown/not recorded — never 0, never "rest" — and shows no invented target`, async ({ page }) => {
      await boot(page);
      await expect(page.getByTestId('glance-steps-text')).toHaveText('Steps not recorded (unknown)');
      await expect(page.getByTestId('glance-exercise-text')).toHaveText('Nothing logged today (not assumed rest)');
      await expect(page.getByTestId('glance-weight-text')).toHaveText('No weight recorded');
      await expect(page.getByTestId('today-glance')).not.toContainText(/water/i);
      await expect(page.getByTestId('today-glance')).not.toContainText(/burn|calories out|streak/i);
      noErrors(page);
    });

    test(`${W}: recorded values — explicit 0 steps with your override target, a completed session + walk, latest weight with its own date`, async ({ page }) => {
      await boot(page, base({
        weight: [{ id: 'w1', createdAt: T, date: '2026-11-17', kg: 80 }, { id: 'w2', createdAt: T, date: '2026-11-18', kg: 79.4 }],
        daily: [{ id: 'daily-2026-11-19', createdAt: T, date: '2026-11-19', steps: { state: 'OBSERVED', value: 0 }, stepTargetOverride: 9000 }],
        sessions: [SESSION],
        walks: [{ id: 'wk1', createdAt: T, updatedAt: T, date: '2026-11-19', durationMin: 30 }, { id: 'wk0', createdAt: T, updatedAt: T, date: '2026-11-18', durationMin: 45 }],
      }));
      await expect(page.getByTestId('glance-steps-text')).toHaveText('Steps 0 (daily total)');
      await expect(page.getByTestId('glance-steps-target')).toHaveText('Target 9,000 (your override) · not reached yet');
      await expect(page.getByTestId('glance-exercise-text')).toHaveText('Aerobic HYROX completed (55 min) · 1 walk (30 min)');
      await expect(page.getByTestId('glance-weight-text')).toHaveText('79.4 kg · last measured Wed 18 Nov');
      // the primary planned workout stays visible above
      await expect(page.getByTestId('today-card')).toBeVisible();
      for (const id of ['glance-exercise-log', 'glance-weight-log', 'today-log-steps']) {
        const b = await page.getByTestId(id).boundingBox(); expect(b.height).toBeGreaterThanOrEqual(44);
      }
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
      noErrors(page);
    });

    test(`${W}: each row opens the existing entry screen (weight focuses its field; workout opens the workout form); a new weight today updates the row`, async ({ page }) => {
      await boot(page, base({ weight: [{ id: 'w1', createdAt: T, date: '2026-11-17', kg: 80 }] }));
      await page.getByTestId('glance-weight-log').click();
      await expect(page.getByTestId('panel-add')).toBeVisible();
      await expect(page.getByTestId('weight-kg')).toBeFocused();
      await page.getByTestId('weight-kg').fill('78.6');
      await page.getByTestId('weight-submit').click();
      await page.getByTestId('tab-today').click();
      await expect(page.getByTestId('glance-weight-text')).toHaveText('78.6 kg · today');
      await page.getByTestId('glance-exercise-log').click();
      await expect(page.getByTestId('panel-add')).toBeVisible();
      await expect(page.getByTestId('add-mode-workout')).toHaveAttribute('aria-pressed', 'true');
      noErrors(page);
    });

    test(`${W}: a weight dated after the shown day is not shown as current; the row follows the Asia/Qatar day`, async ({ page }) => {
      await boot(page, base({ weight: [{ id: 'w1', createdAt: T, date: '2026-11-18', kg: 79 }] }), '2026-11-18T20:59:00.000Z');
      await expect(page.getByTestId('glance-weight-text')).toHaveText('79 kg · today');
      await page.clock.setFixedTime(new Date('2026-11-18T21:00:30.000Z'));
      await page.evaluate(() => document.dispatchEvent(new Event('visibilitychange')));
      await expect(page.getByTestId('glance-weight-text')).toHaveText('79 kg · last measured Wed 18 Nov');
      noErrors(page);
    });
  });
}
