'use strict';
// P6 Meron: readiness links focus their daily fields; tap targets ≥44 px; no horizontal scroll.
// Chrome emulation, not Safari/WebKit. Synthetic data only. 390 and 320.
const { test, expect } = require('@playwright/test');

const SHOTS = process.env.P6_SHOTS || '/workspace/hyrox-p6/results/screens';
const NOW = '2026-11-13T06:00:00.000Z';

const noHScroll = async (page) => {
  const m = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
  expect(m.sw).toBeLessThanOrEqual(m.cw);
};

async function bootToday(page) {
  await page.clock.setFixedTime(new Date(NOW));
  await page.goto('./');
  await page.evaluate(() => localStorage.clear());
  await page.reload();
  await expect(page.getByTestId('load-guard')).toBeHidden();
  await page.getByTestId('tab-today').click();
}

async function visibleFocus(page, testid) {
  const info = await page.evaluate((id) => {
    const el = document.activeElement;
    const s = el ? getComputedStyle(el) : null;
    return {
      testid: el && el.getAttribute('data-testid'),
      tag: el && el.tagName,
      outlineWidth: s && s.outlineWidth,
      outlineStyle: s && s.outlineStyle,
      outlineColor: s && s.outlineColor,
      boxShadow: s && s.boxShadow,
      borderColor: s && s.borderColor,
    };
  }, testid);
  expect(info.testid, 'document.activeElement').toBe(testid);
  await expect(page.getByTestId(testid)).toBeFocused();
  const hasOutline = info.outlineStyle && info.outlineStyle !== 'none' && parseFloat(info.outlineWidth) > 0;
  const hasRing = info.boxShadow && info.boxShadow !== 'none';
  expect(hasOutline || hasRing, 'visible focus (outline or box-shadow) on ' + testid + ' got ' + JSON.stringify(info)).toBe(true);
  return info;
}

const LINKS = [
  { link: 'glance-missing-sleepH', field: 'daily-sleepH', label: /sleep/i },
  { link: 'glance-missing-soreness', field: 'daily-soreness', label: /soreness/i },
  { link: 'glance-missing-rhr', field: 'daily-rhr', label: /resting hr/i },
];

for (const W of [390, 320]) {
  test.describe(`${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`readiness links ${W}: each missing input is named, is ≥44 px, and focuses its field with a visible ring`, async ({ page }) => {
      await bootToday(page);
      const missing = page.getByTestId('glance-readiness-missing');
      await expect(missing).toBeVisible();
      for (const L of LINKS) {
        const btn = page.getByTestId(L.link);
        await expect(btn).toBeVisible();
        await expect(btn).toHaveText(L.label);
        const box = await btn.boundingBox();
        expect(box.height, L.link + ' height').toBeGreaterThanOrEqual(44);
        expect(box.width, L.link + ' width').toBeGreaterThanOrEqual(44);
      }
      await noHScroll(page);
      await missing.scrollIntoViewIfNeeded();
      await page.screenshot({ path: `${SHOTS}/meron-${W}-readiness-links.png` });

      for (const L of LINKS) {
        await page.getByTestId('tab-today').click();
        await page.getByTestId(L.link).click();
        await expect(page.getByTestId(L.field)).toBeVisible();
        await visibleFocus(page, L.field);
        const fieldBox = await page.getByTestId(L.field).boundingBox();
        expect(fieldBox.height, L.field + ' height').toBeGreaterThanOrEqual(44);
        await noHScroll(page);
        await page.screenshot({ path: `${SHOTS}/meron-${W}-focus-${L.field}.png` });
      }
    });
  });
}
