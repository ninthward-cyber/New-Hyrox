'use strict';
// P6 (Liya t75u): read-only storage-context banner/diagnostic (RC-1) and readiness summary links.
// CHROME EMULATION, NOT SAFARI/WEBKIT. Synthetic data only. Runs at 390 px and 320 px.
const fs = require('fs');
const { test, expect } = require('@playwright/test');

const SHOTS = process.env.P6_SHOTS || '/workspace/hyrox-p6/results/liya-shots';
const T = '2026-11-17T06:00:00.000Z', NOW = '2026-11-19T06:00:00.000Z', TODAY = '2026-11-19';
const O = (v) => ({ state: 'OBSERVED', value: v });

async function boot(page, { seed, standalone } = {}) {
  if (standalone) await page.addInitScript(() => { Object.defineProperty(navigator, 'standalone', { get: () => true }); });
  await page.clock.setFixedTime(new Date(NOW));
  await page.goto('./');
  await page.evaluate(([s]) => { localStorage.clear(); if (s) s(); }, [null]);
  if (seed) await page.evaluate(seed, { T, TODAY });
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
}
const stored = (page) => page.evaluate(() => { const o = {}; for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); o[k] = localStorage.getItem(k); } return o; });
const noHScroll = async (page) => { const m = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth })); expect(m.sw).toBeLessThanOrEqual(m.cw); };
const populate = (a) => { const st = window.HyroxData.createStore(); st.addWeight({ date: '2026-11-17', kg: 80 }); st.addWeight({ date: '2026-11-18', kg: 79.8 }); st.putRecord('walks', { date: '2026-11-18', durationMin: 30, steps: 4000 }); };
// today has only sleep; four prior days have resting HR (so a baseline exists but today's HR is missing)
const seedPartial = (a) => { const st = window.HyroxData.createStore(); const o = (v) => ({ state: 'OBSERVED', value: v });
  ['2026-11-15', '2026-11-16', '2026-11-17', '2026-11-18'].forEach((d, i) => st.putRecord('daily', { date: d, rhr: o(60 + i), sleepH: o(7), soreness: o(2) }));
  st.putRecord('daily', { date: a.TODAY, sleepH: o(7.5) }); };
const seedComplete = (a) => { const st = window.HyroxData.createStore(); const o = (v) => ({ state: 'OBSERVED', value: v });
  ['2026-11-15', '2026-11-16', '2026-11-17', '2026-11-18'].forEach((d, i) => st.putRecord('daily', { date: d, rhr: o(60 + i), sleepH: o(7), soreness: o(2) }));
  st.putRecord('daily', { date: a.TODAY, sleepH: o(7.5), soreness: o(2), rhr: o(61) }); };

for (const W of [390, 320]) {
  test.describe(`${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`storage context ${W}: an empty browser context shows a read-only banner with host, mode, key and counts; writes nothing`, async ({ page }) => {
      await boot(page);
      const b = page.getByTestId('storage-context');
      await expect(b).toBeVisible();
      await expect(page.getByTestId('storage-context-title')).toContainText('No saved data found in THIS browser context');
      const facts = (await page.getByTestId('storage-fact').allInnerTexts()).filter((t, i) => i < 4);
      expect(facts[0]).toMatch(/^Web address: 127\.0\.0\.1:\d+$/);
      expect(facts[1]).toBe('Opened as: Browser tab (not a Home Screen app)');
      expect(facts[2]).toBe('Saved-data key (hyrox.v1) present: no');
      expect(facts[3]).toMatch(/^Records stored here: 0 in total/);
      await expect(page.getByTestId('storage-context-note')).toContainText('not proof that anything was deleted');
      await expect(page.getByTestId('storage-context-guidance')).toContainText('same address or Home Screen icon');
      await noHScroll(page);
      await page.screenshot({ path: `${SHOTS}/p6-${W}-storage-context-empty.png` });
      expect(await stored(page)).toEqual({}); // nothing written by viewing it, no restore
    });

    test(`storage context ${W}: Home Screen (standalone) is reported`, async ({ page }) => {
      await boot(page, { standalone: true });
      await expect(page.getByTestId('storage-fact').nth(1)).toHaveText('Opened as: Home Screen app (standalone)');
    });

    test(`storage context ${W}: with saved data there is no banner; Settings shows the read-only diagnostic with counts`, async ({ page }) => {
      await boot(page, { seed: populate });
      await expect(page.getByTestId('storage-context')).toBeHidden();
      const before = await stored(page);
      await page.getByTestId('tab-settings').click();
      await page.getByTestId('storage-diagnostic-summary').click();
      const list = page.getByTestId('storage-diagnostic-list');
      await expect(list).toContainText('Saved-data key (hyrox.v1) present: yes');
      await expect(list).toContainText('3 in total');
      await expect(list).toContainText('weight 2');
      await expect(list).toContainText('walks 1');
      const sb = await page.getByTestId('storage-diagnostic-summary').boundingBox();
      expect(sb.height).toBeGreaterThanOrEqual(44);
      await noHScroll(page);
      await page.screenshot({ path: `${SHOTS}/p6-${W}-storage-diagnostic.png` });
      expect(await stored(page)).toEqual(before);
    });

    test(`storage context ${W}: the banner goes away after the first saved entry (no data was ever touched)`, async ({ page }) => {
      await boot(page);
      await page.getByTestId('tab-add').click();
      await page.getByTestId('add-mode-classic').click();
      await page.getByTestId('weight-kg').fill('81.5');
      await page.getByTestId('weight-submit').click();
      await expect(page.getByTestId('storage-context')).toBeHidden();
    });

    test(`readiness ${W}: the summary tile names each missing input; each is a >=44px link that opens the check-in and focuses it`, async ({ page }) => {
      await boot(page, { seed: seedPartial });
      const tile = page.getByTestId('glance-readiness');
      await expect(tile).toContainText('Readiness incomplete — log soreness, resting HR'); // Phase 8 wording (was 'Unconfirmed')
      await expect(tile).not.toContainText('inputs unknown');
      await expect(page.getByTestId('glance-missing-rhr')).toHaveText('Resting HR'); // Phase 8: short chip; the full wording is the aria-label
      await expect(page.getByTestId('glance-missing-rhr')).toHaveAttribute('aria-label', /Resting HR — not recorded/);
      await expect(page.getByTestId('glance-missing-soreness')).toHaveText('Soreness');
      await expect(page.getByTestId('glance-missing-soreness')).toHaveAttribute('aria-label', /Soreness — not recorded/);
      await expect(page.getByTestId('glance-missing-sleepH')).toHaveCount(0); // recorded, so not listed
      for (const id of ['rhr', 'soreness']) {
        const b = await page.getByTestId('glance-missing-' + id).boundingBox();
        expect(b.height, id + ' height').toBeGreaterThanOrEqual(44);
        expect(b.width, id + ' width').toBeGreaterThanOrEqual(44);
      }
      await noHScroll(page);
      await tile.scrollIntoViewIfNeeded();
      await page.screenshot({ path: `${SHOTS}/p6-${W}-readiness-links.png` });
      const before = await stored(page);
      await page.getByTestId('glance-missing-soreness').click();
      await expect(page.getByTestId('panel-add')).toBeVisible();
      await expect(page.getByTestId('daily-form')).toBeVisible();
      await expect(page.getByTestId('daily-soreness')).toBeFocused();
      expect(await stored(page)).toEqual(before); // jumping writes nothing
      await page.getByTestId('tab-today').click();
      await page.getByTestId('glance-missing-rhr').click();
      await expect(page.getByTestId('daily-rhr')).toBeFocused();
    });

    test(`readiness ${W}: keyboard activation (Enter) on a missing-input link focuses the field`, async ({ page }) => {
      await boot(page, { seed: (a) => { const st = window.HyroxData.createStore(); st.putRecord('daily', { date: a.TODAY, sleepH: { state: 'OBSERVED', value: 7 }, soreness: { state: 'OBSERVED', value: 2 } }); } });
      const l = page.getByTestId('glance-missing-rhr');
      await expect(l).toHaveText('Resting HR');
      await expect(l).toHaveAttribute('aria-label', /Resting HR — not recorded/);
      await l.focus();
      await page.keyboard.press('Enter');
      await expect(page.getByTestId('daily-rhr')).toBeFocused();
    });

    test(`readiness ${W}: an invalid stored value is named as invalid (unknown, never 0)`, async ({ page }) => {
      await boot(page, { seed: (a) => { const st = window.HyroxData.createStore(); const o = (v) => ({ state: 'OBSERVED', value: v });
        ['2026-11-15', '2026-11-16', '2026-11-17', '2026-11-18'].forEach((d, i) => st.putRecord('daily', { date: d, rhr: o(60 + i), sleepH: o(7), soreness: o(2) }));
        st.putRecord('daily', { date: a.TODAY, sleepH: o(7), soreness: o(2), rhr: o(61) });
        const raw = JSON.parse(localStorage.getItem('hyrox.v1')); const r = raw.daily.find((x) => x.date === a.TODAY); r.pain = { state: 'INVALID', value: 11 }; localStorage.setItem('hyrox.v1', JSON.stringify(raw)); } });
      const l = page.getByTestId('glance-missing-invalid-pain');
      await expect(l).toContainText('Pain — invalid value, counts as unknown');
      await l.click();
      await expect(page.getByTestId('daily-pain')).toBeFocused();
    });

    test(`readiness ${W}: with every input recorded there are no links and no "Unconfirmed"`, async ({ page }) => {
      await boot(page, { seed: seedComplete });
      await expect(page.getByTestId('glance-readiness')).toContainText('No flags');
      await expect(page.getByTestId('glance-readiness-missing')).toHaveCount(0);
    });
  });
}

test('storage context: a different browser container (separate storage) looks empty, and says so without alarm about deletion', async ({ browser, baseURL }) => {
  const a = await browser.newContext({ baseURL }); const pa = await a.newPage();
  await pa.clock.setFixedTime(new Date(NOW)); // Phase 8: populate() uses plan-week dates, which are later than the real clock until 16 Nov
  await pa.goto('./'); await pa.evaluate(populate);
  await pa.reload();
  await expect(pa.getByTestId('storage-context')).toBeHidden();
  const b = await browser.newContext({ baseURL }); const pb = await b.newPage();
  await pb.goto('./');
  await expect(pb.getByTestId('storage-context')).toBeVisible();
  await expect(pb.getByTestId('storage-context-note')).toContainText('not proof that anything was deleted');
  await a.close(); await b.close();
});
