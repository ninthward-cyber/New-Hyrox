'use strict';
// RC1 independent review of P11.3 (food branch): fail-first regression tests for defect A-02 (owner-typed fiber/sodium survives a kcal edit).
// Synthetic data only; no AI; no network beyond the app's own static files. CHROME MOBILE EMULATION, NOT SAFARI/WEBKIT.
const { test, expect } = require('@playwright/test');
// P0 (22 Nov 2026): the meal diary moved from Today to Add > Meal ("Log meal" on Today opens it). This brings it on screen
// the way the owner does; it does nothing when the diary or a dedicated logger is already showing.
async function diary(page) {
  if (await page.getByTestId('meal-diary').isVisible()) return;
  if (await page.getByTestId('logger-head').isVisible()) return;
  if (!(await page.getByTestId('panel-today').isVisible())) await page.getByTestId('tab-today').click();
  await page.getByTestId('today-add-meal').click();
  await page.getByTestId('meal-diary').waitFor();
}

const NOW = '2026-11-19T09:00:00.000Z';
async function open(page) {
  page._errs = []; page.on('pageerror', (e) => page._errs.push(e.message));
  await page.clock.setFixedTime(new Date(NOW));
  await page.goto('./'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
}
const row = (page, name) => page.getByTestId('food-result').filter({ has: page.locator('.food-name', { hasText: new RegExp('^' + name.replace(/[()]/g, '\\$&') + '$') }) });
const stored = async (page) => JSON.parse((await page.evaluate(() => localStorage.getItem('hyrox.v1'))) || '{}');

for (const W of [390, 320]) {
  test.describe(`RC1 review A-02 ${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`${W}: A-02 a fiber value the owner typed survives a later kcal change; only the USDA sodium is cleared`, async ({ page }) => {
      await open(page);
      await diary(page); await page.getByTestId('diary-log-breakfast').click();
      await page.getByTestId('meal-add-foods').click();
      await expect(page.getByTestId('foods-status')).toContainText('13,598 foods');
      await page.getByTestId('foods-q').fill('4 boiled eggs');
      await row(page, 'Egg, whole, boiled or poached').getByTestId('food-pick').click();
      await page.getByTestId('food-qty').fill('4');
      await page.getByTestId('food-add').click(); await page.getByTestId('foods-done').click();
      const extra = page.getByTestId('component-extra').first();
      if (!(await extra.evaluate((e) => e.open))) await extra.locator('summary').click();
      await expect(page.getByTestId('component-sodiumMg').first()).toHaveValue('258');
      await page.getByTestId('component-fiberG').first().fill('1.5');   // the owner's own number (certainty left as shown)
      await page.getByTestId('component-kcal').first().fill('300');     // then the owner changes kcal
      await expect(page.getByTestId('component-fiberG').first()).toHaveValue('1.5');
      await expect(page.getByTestId('component-sodiumMg').first()).toHaveValue('');
      await page.getByTestId('meal-confirm').click();
      const c = (await stored(page)).meals[0].components[0];
      expect([c.kcal.value, 'provenance' in c, c.fiberG && c.fiberG.value, 'sodiumMg' in c]).toEqual([300, false, 1.5, false]);
      expect(page._errs).toEqual([]);
    });
  });
}
