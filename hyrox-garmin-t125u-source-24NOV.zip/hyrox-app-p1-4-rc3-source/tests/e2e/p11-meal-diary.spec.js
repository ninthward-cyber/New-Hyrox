'use strict';
// Phase 11 P0: meal diary (Breakfast / Lunch / Dinner / Snacks) on Today with a dedicated full-screen logger, plus compact
// accessible typography. Every regression listed in the Phase 11 handover. Synthetic data; the photo path uses the real
// server handler with a STUBBED OpenAI (no network, no paid call). CHROME MOBILE EMULATION, NOT SAFARI/WEBKIT.
const fs = require('fs');
const path = require('path');
const { test, expect } = require('@playwright/test');
// P0 (22 Nov 2026): the meal diary moved from Today to Add > Meal ("Log meal" on Today opens it). This brings it on screen
// the way the owner does; it does nothing when the diary or a dedicated logger is already showing.
async function diary(page) {
  if (await page.getByTestId('meal-diary').isVisible()) return;
  if (await page.getByTestId('logger-head').isVisible()) return;
  if (!(await page.getByTestId('panel-today').isVisible())) await page.getByTestId('tab-today').click();
  await page.getByTestId('today-add-meal').click();
  await page.getByTestId('meal-diary').waitFor();
}

// P0 (22 Nov 2026): "Meal name" is no longer a routine field; the optional custom name sits in a closed fold.
async function nameField(page) { const f = page.getByTestId('meal-label'); if (!(await f.isVisible())) await page.getByTestId('meal-name-toggle').click(); return f; }


const FIX = path.join(__dirname, '..', 'fixtures');
const F = (n) => path.join(FIX, n);
let H;
test.beforeAll(() => {
  const out = path.join(__dirname, '..', 'out', 'p9-helpers.bundle.cjs');
  const esbuild = process.env.P9_ESBUILD || (() => { try { return require.resolve('esbuild/bin/esbuild'); } catch (e) { return '/workspace/p9-tools/node_modules/.bin/esbuild'; } })();
  require('child_process').execFileSync(esbuild, [path.join(__dirname, '..', 'p9-helpers.mjs'), '--bundle', '--platform=node', '--format=cjs', '--log-level=error', '--define:import.meta.url=' + JSON.stringify(require('url').pathToFileURL(path.join(__dirname, '..', 'p9-helpers.mjs')).href), '--outfile=' + out]);
  H = require(out);
});
async function installApi(page, opts = {}) {
  const ctx = H.setup({ script: opts.script || (() => H.openaiOk()), env: opts.env || {}, clock: { t: Date.UTC(2026, 10, 19, 6, 0, 0) } });
  const seen = [];
  await page.route('**/api/food-photo/**', async (route) => {
    const r = route.request();
    seen.push({ url: r.url(), method: r.method(), body: r.postData() });
    if (opts.delayMs && r.method() === 'POST') await new Promise((res) => setTimeout(res, opts.delayMs));
    const req = new Request(r.url(), { method: r.method(), headers: r.headers(), body: r.method() === 'GET' ? undefined : r.postData() });
    const res = await ctx.handle(req, { ip: '203.0.113.5' });
    try { await route.fulfill({ status: res.status, headers: Object.fromEntries(res.headers), body: await res.text() }); } catch (e) { /* page moved on */ }
  });
  return { ctx, seen };
}
const NOW = '2026-11-19T09:00:00.000Z'; // 12:00 Asia/Qatar, Thu 19 Nov 2026
async function open(page, at = NOW) {
  page._errs = []; page.on('pageerror', (e) => page._errs.push(e.message));
  await page.clock.setFixedTime(new Date(at));
  await page.goto('./');
  await page.evaluate(() => localStorage.clear());
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
}
const noErrors = (page) => expect(page._errs).toEqual([]);
const stored = (page) => page.evaluate(() => JSON.parse(localStorage.getItem('hyrox.v1') || '{}'));
const meals = async (page) => (await stored(page)).meals || [];
const posts = (seen) => seen.filter((s) => s.method === 'POST' && /analyze/.test(s.url)).map((s) => JSON.parse(s.body));
const noPhotoBytes = async (page) => { const raw = (await page.evaluate(() => localStorage.getItem('hyrox.v1'))) || ''; expect(/data:image|imageBase64|\/9j\//.test(raw)).toBe(false); };
const noHScroll = async (page) => expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
async function items(page, label, list) {
  await (await nameField(page)).fill(label);
  for (let i = 0; i < list.length; i++) {
    if (i) await page.getByTestId('meal-add-component').click();
    await page.getByTestId('component-name').nth(i).fill(list[i][0]);
    await page.getByTestId('component-kcal').nth(i).fill(String(list[i][1]));
  }
}
async function logManual(page, cat, label, kcal) {
  await diary(page); await page.getByTestId('diary-log-' + cat).click();
  await expect(page.getByTestId('logger-title')).toHaveText('Log ' + cat);
  await page.getByTestId('meal-path-manual').click();
  await items(page, label, [[label + ' item', kcal]]);
  await page.getByTestId('meal-confirm').click();
  await expect(page.getByTestId('meal-diary')).toBeVisible();
}
async function expectFresh(page, cat) {
  await expect(page.getByTestId('meal-form')).toContainText('Add a meal');
  if (cat) { await expect(page.getByTestId('logger-title')).toHaveText('Log ' + cat); await expect(page.getByTestId('meal-cat-' + cat)).toHaveAttribute('aria-pressed', 'true'); }
  await expect(page.getByTestId('meal-label')).toHaveValue('');
  await expect(page.getByTestId('meal-description')).toHaveValue('');
  await expect(page.getByTestId('photo-preview')).toHaveCount(0);
  await expect(page.getByTestId('photo-send-consent')).toHaveCount(0);
  await expect(page.getByTestId('meal-review-box')).toHaveCount(0);
  await expect(page.getByTestId('meal-error')).toHaveText('');
  const names = await page.getByTestId('component-name').evaluateAll((els) => els.map((e) => e.value));
  expect(names.every((v) => v === '')).toBe(true);
}
const row = (page, cat) => page.getByTestId('diary-row-' + cat);
async function chooseLive(page) {
  await page.getByTestId('tab-settings').click();
  await page.getByTestId('ai-provider-live').check();
  await page.getByTestId('ai-owner-code').fill(H.OWNER_CODE);
  await page.getByTestId('ai-owner-code-save').click();
  await page.getByTestId('tab-today').click();
}

for (const W of [390, 320]) {
  test.describe(`P11 meal diary ${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`${W}: category + Asia/Qatar date — Log lunch opens a dedicated logger for that slot and date; save returns to the diary; a past day stays chosen while Today stays today`, async ({ page }) => {
      await open(page);
      await expect(page.getByTestId('diary-date')).toContainText('Thu 19 Nov · today');
      for (const c of ['breakfast', 'lunch', 'dinner', 'snacks']) await expect(page.getByTestId('diary-sub-' + c)).toHaveText('Not logged');
      await expect(page.getByTestId('diary-total')).toContainText('unknown, not 0');
      await expect(page.getByTestId('diary-row-uncat')).toHaveCount(0);
      await diary(page); await page.getByTestId('diary-log-lunch').click();
      await expect(page.getByTestId('logger-title')).toHaveText('Log lunch');
      await expect(page.getByTestId('logger-date')).toContainText('Thu 19 Nov · today');
      await expect(page.getByTestId('logger-back')).toBeVisible();
      await expect(page.getByTestId('add-modes')).toBeHidden(); // only this entry's controls
      await expect(page.getByTestId('meal-cat-lunch')).toHaveAttribute('aria-pressed', 'true');
      await expect(page.getByTestId('meal-date')).toHaveValue('2026-11-19');
      await page.getByTestId('meal-path-manual').click();
      await expect(page.getByTestId('meal-cat-lunch')).toHaveAttribute('aria-pressed', 'true'); // a path switch keeps the slot
      await items(page, 'Synthetic dal', [['dal', 400]]);
      await page.getByTestId('meal-confirm').click();
      await expect(page.getByTestId('meal-diary')).toBeVisible();
      await expect(page.getByTestId('diary-sub-lunch')).toHaveText('1 entry · 400 kcal');
      await expect(row(page, 'lunch').getByTestId('diary-entry')).toHaveCount(1);
      await expect(page.getByTestId('diary-total')).toContainText('400 kcal confirmed so far — not a full day');
      // a deliberately chosen earlier day
      await diary(page); await page.getByTestId('diary-prev').click();
      await expect(page.getByTestId('diary-date')).toContainText('Wed 18 Nov');
      await expect(page.getByTestId('diary-not-today')).toBeVisible();
      await expect(page.getByTestId('diary-next')).toBeEnabled();
      await diary(page); await page.getByTestId('diary-log-breakfast').click();
      await expect(page.getByTestId('logger-title')).toHaveText('Log breakfast');
      await expect(page.getByTestId('logger-date')).toContainText('Wed 18 Nov');
      await expect(page.getByTestId('logger-not-today')).toBeVisible();
      await expect(page.getByTestId('meal-draft-date')).toHaveCount(0); // chosen on purpose: no "stale draft" warning
      await expect(page.getByTestId('meal-date')).toHaveValue('2026-11-18');
      await page.getByTestId('meal-path-manual').click();
      await items(page, 'Synthetic eggs', [['eggs', 250]]);
      await page.getByTestId('meal-confirm').click();
      await expect(page.getByTestId('diary-date')).toContainText('Wed 18 Nov'); // the chosen day is kept
      await expect(page.getByTestId('diary-sub-breakfast')).toHaveText('1 entry · 250 kcal');
      await expect(page.getByTestId('diary-sub-lunch')).toHaveText('Not logged');
      await expect(page.getByTestId('today-card')).toContainText('Thu 19 Nov'); // Today itself stays today
      await diary(page); await page.getByTestId('diary-next').click();
      await expect(page.getByTestId('diary-date')).toContainText('Thu 19 Nov · today');
      await expect(page.getByTestId('diary-next')).toBeDisabled();
      await expect(page.getByTestId('diary-sub-breakfast')).toHaveText('Not logged');
      const m = await meals(page);
      expect(m.map((x) => [x.label, x.date, x.mealCategory])).toEqual([['Synthetic dal', '2026-11-19', 'LUNCH'], ['Synthetic eggs', '2026-11-18', 'BREAKFAST']]);
      noErrors(page);
    });

    test(`${W}: several records in one category; a double tap saves once; every new Log is a fresh draft; Edit loads only that record; a category change never changes totals`, async ({ page }) => {
      await open(page);
      await diary(page); await page.getByTestId('diary-log-lunch').click();
      await page.getByTestId('meal-path-manual').click();
      await items(page, 'Lunch A', [['rice', 300]]);
      // two taps on Confirm in the same instant (the second reaches the old button): one record only
      await page.getByTestId('meal-confirm').evaluate((b) => { b.click(); b.click(); });
      await expect(page.getByTestId('meal-diary')).toBeVisible();
      expect(await meals(page)).toHaveLength(1);
      await diary(page); await page.getByTestId('diary-log-lunch').click();
      await expectFresh(page, 'lunch');
      await page.getByTestId('meal-path-manual').click();
      await items(page, 'Lunch B', [['soup', 200]]);
      await page.getByTestId('meal-confirm').click();
      await expect(page.getByTestId('diary-sub-lunch')).toHaveText('2 entries · 500 kcal');
      await expect(row(page, 'lunch').getByTestId('diary-entry')).toHaveCount(2);
      let m = await meals(page);
      expect(new Set(m.map((x) => x.id)).size).toBe(2);
      // Edit loads exactly the chosen record
      await row(page, 'lunch').getByTestId('diary-entry').filter({ hasText: 'Lunch A' }).getByTestId('diary-entry-edit').click();
      await expect(page.getByTestId('logger-title')).toHaveText('Edit lunch');
      await expect(page.getByTestId('meal-label')).toHaveValue('Lunch A');
      await expect(page.getByTestId('component-kcal').first()).toHaveValue('300');
      await page.getByTestId('component-kcal').first().fill('350');
      await page.getByTestId('meal-confirm').click();
      await expect(page.getByTestId('diary-sub-lunch')).toHaveText('2 entries · 550 kcal');
      const m2 = await meals(page);
      expect(m2.map((x) => [x.id, x.label, x.components[0].kcal.value])).toEqual([[m[0].id, 'Lunch A', 350], [m[1].id, 'Lunch B', 200]]);
      // moving Lunch B to Dinner moves it in the diary; the day total is unchanged
      await row(page, 'lunch').getByTestId('diary-entry').filter({ hasText: 'Lunch B' }).getByTestId('diary-entry-edit').click();
      await page.getByTestId('meal-cat-dinner').click();
      await expect(page.getByTestId('logger-title')).toHaveText('Edit dinner');
      await page.getByTestId('meal-confirm').click();
      await expect(page.getByTestId('diary-sub-lunch')).toHaveText('1 entry · 350 kcal');
      await expect(page.getByTestId('diary-sub-dinner')).toHaveText('1 entry · 200 kcal');
      await expect(page.getByTestId('diary-total')).toContainText('550 kcal confirmed');
      // the next Log after an edit is fresh, with nothing of the edited meal
      await diary(page); await page.getByTestId('diary-log-dinner').click();
      await expectFresh(page, 'dinner');
      expect((await meals(page)).map((x) => [x.label, x.mealCategory])).toEqual([['Lunch A', 'LUNCH'], ['Lunch B', 'DINNER']]);
      noErrors(page);
    });

    test(`${W}: Back protects unfinished input with the in-app Keep/Discard dialog (typed text, unanalysed photos); untouched Back just closes; nothing is sent or saved`, async ({ page }) => {
      const { seen } = await installApi(page);
      await open(page);
      await chooseLive(page);
      let dialogs = 0; page.on('dialog', async (d) => { dialogs++; await d.dismiss(); });
      await diary(page); await page.getByTestId('diary-log-dinner').click();
      await page.getByTestId('logger-back').click();
      await expect(page.getByTestId('choice-dialog')).toHaveCount(0);
      await expect(page.getByTestId('meal-diary')).toBeVisible();
      await diary(page); await page.getByTestId('diary-log-dinner').click();
      await page.getByTestId('meal-path-manual').click();
      await (await nameField(page)).fill('Half typed');
      await page.getByTestId('logger-back').click();
      await expect(page.getByTestId('choice-title')).toContainText('Discard the meal you have not saved yet');
      await page.getByTestId('choice-keep').click();
      await expect(page.getByTestId('logger-title')).toHaveText('Log dinner');
      await expect(page.getByTestId('meal-label')).toHaveValue('Half typed');
      await page.getByTestId('logger-back').click();
      await page.keyboard.press('Escape'); // Escape keeps
      await expect(page.getByTestId('meal-label')).toHaveValue('Half typed');
      await page.getByTestId('logger-back').click();
      await page.getByTestId('choice-yes').click();
      await expect(page.getByTestId('meal-diary')).toBeVisible();
      await diary(page); await page.getByTestId('diary-log-dinner').click();
      await expectFresh(page, 'dinner');
      // only unanalysed photos chosen: still asks
      await page.getByTestId('meal-path-photo_ai').click();
      await page.getByTestId('photo-library-input').setInputFiles([F('p10-view-a.jpg'), F('p10-view-b.jpg')]);
      await expect(page.getByTestId('photo-preview')).toHaveCount(2);
      await page.getByTestId('logger-back').click();
      await expect(page.getByTestId('choice-body')).toContainText('photos');
      await page.getByTestId('choice-yes').click();
      await diary(page); await page.getByTestId('diary-log-dinner').click();
      await expect(page.getByTestId('photo-preview')).toHaveCount(0);
      expect(dialogs).toBe(0); // never a native confirm
      expect(posts(seen)).toHaveLength(0); // selecting/previewing photos and Back never call the paid endpoint
      expect(await meals(page)).toEqual([]);
      noErrors(page);
    });

    test(`${W}: the input path of the last NEW meal is preferred for the next fresh entry; an edit does not change it`, async ({ page }) => {
      await open(page);
      await diary(page); await page.getByTestId('diary-log-breakfast').click();
      await page.getByTestId('meal-path-description').click();
      await page.getByTestId('meal-description').fill('two boiled eggs');
      await (await nameField(page)).fill('Eggs');
      await page.getByTestId('component-name').first().fill('eggs');
      await page.getByTestId('component-kcal').first().fill('150');
      await page.getByTestId('meal-confirm').click();
      await diary(page); await page.getByTestId('diary-log-lunch').click();
      await expect(page.getByTestId('meal-path-description')).toHaveClass(/active/);
      await expectFresh(page, 'lunch');
      await page.getByTestId('logger-back').click();
      await row(page, 'breakfast').getByTestId('diary-entry-edit').click();
      await page.getByTestId('meal-path-manual').click();
      await page.getByTestId('meal-confirm').click();
      await diary(page); await page.getByTestId('diary-log-snacks').click();
      await expect(page.getByTestId('meal-path-description')).toHaveClass(/active/);
      noErrors(page);
    });

    test(`${W}: 1, 2 and 3 photos — one consented request each, the meal lands in the chosen slot, and the next Log carries no photo, estimate, consent or request id`, async ({ page }) => {
      const { seen } = await installApi(page);
      await open(page);
      await chooseLive(page);
      const files = [F('p10-view-a.jpg'), F('p10-view-b.jpg'), F('p10-view-c.jpg')];
      for (const n of [1, 2, 3]) {
        await diary(page); await page.getByTestId('diary-log-lunch').click();
        if (n > 1) await expectFresh(page, 'lunch');
        if (n === 1) await page.getByTestId('meal-path-photo_ai').click();
        await expect(page.getByTestId('meal-path-photo_ai')).toHaveClass(/active/); // preferred path after a photo meal
        await page.getByTestId('meal-description').fill('rice and dal');
        await page.getByTestId('photo-library-input').setInputFiles(files.slice(0, n));
        await expect(page.getByTestId('photo-preview')).toHaveCount(n);
        if (n === 1) await page.getByTestId('photo-privacy-ack').click();
        await expect(page.getByTestId('photo-send-consent')).not.toBeChecked();
        expect(posts(seen)).toHaveLength(n - 1); // choosing photos sends nothing
        await page.getByTestId('photo-send-consent').check();
        await page.getByTestId('photo-send').click();
        await expect(page.getByTestId('component-row')).toHaveCount(3);
        expect(posts(seen)).toHaveLength(n);
        // Re-pointed by the P0 sprint photo + note fix (23 Nov 2026): the stubbed model returns chicken/rice/oil, so "dal" from the
        // note is now flagged "not accounted for" and must be acknowledged before Confirm (this test is about the meal lifecycle).
        await expect(page.getByTestId('unaccounted-item')).toHaveCount(1);
        await page.getByTestId('unaccounted-ack').click();
        await page.getByTestId('meal-eaten-100').click();
        await page.getByTestId('meal-confirm').click();
        await expect(page.getByTestId('meal-diary')).toBeVisible();
        await expect(page.getByTestId('diary-sub-lunch')).toContainText(n + (n === 1 ? ' entry' : ' entries'));
      }
      const p = posts(seen);
      expect(p.map((x) => (Array.isArray(x.images) ? x.images.length : x.imageBase64 ? 1 : 0))).toEqual([1, 2, 3]);
      expect(new Set(p.map((x) => x.requestId)).size).toBe(3);
      const m = await meals(page);
      expect(m.map((x) => [x.mealCategory, x.source, x.lifecycle])).toEqual([['LUNCH', 'PHOTO_AI', 'CONFIRMED'], ['LUNCH', 'PHOTO_AI', 'CONFIRMED'], ['LUNCH', 'PHOTO_AI', 'CONFIRMED']]);
      await noPhotoBytes(page);
      noErrors(page);
    });

    test(`${W}: a late analysis answer for a discarded draft never fills the next entry; still one request`, async ({ page }) => {
      const { seen } = await installApi(page, { delayMs: 2500 });
      await open(page);
      await chooseLive(page);
      await diary(page); await page.getByTestId('diary-log-lunch').click();
      await page.getByTestId('meal-path-photo_ai').click();
      await page.getByTestId('meal-description').fill('lentil soup');
      await page.getByTestId('photo-library-input').setInputFiles([F('p10-view-a.jpg'), F('p10-view-b.jpg')]);
      await page.getByTestId('photo-privacy-ack').click();
      await page.getByTestId('photo-send-consent').check();
      await page.getByTestId('photo-send').click();
      await page.getByTestId('logger-back').click();
      await page.getByTestId('choice-yes').click();
      await diary(page); await page.getByTestId('diary-log-dinner').click();
      await page.waitForTimeout(3200);
      await expectFresh(page, 'dinner');
      await expect(page.getByTestId('meal-path-manual')).toHaveClass(/active/); // nothing was saved, so the preferred path is unchanged
      await expect(page.getByTestId('component-row')).toHaveCount(1); // the one blank Manual row, not the 3 estimated items
      expect(posts(seen)).toHaveLength(1);
      expect(await meals(page)).toEqual([]);
      noErrors(page);
    });

    test(`${W}: a failed save keeps the logger open with every input; the retry saves exactly one record`, async ({ page }) => {
      await open(page);
      await diary(page); await page.getByTestId('diary-log-snacks').click();
      await page.getByTestId('meal-path-manual').click();
      await items(page, 'Synthetic dates', [['dates', 120]]);
      await page.evaluate(() => { const orig = Storage.prototype.setItem; window.__origSet = orig; Storage.prototype.setItem = function (k, v) { if (k === 'hyrox.v1') { const e = new Error('quota'); e.name = 'QuotaExceededError'; throw e; } return orig.call(this, k, v); }; });
      await page.getByTestId('meal-confirm').click();
      await expect(page.getByTestId('meal-error')).toContainText('Not saved');
      await expect(page.getByTestId('logger-title')).toHaveText('Log snacks');
      await expect(page.getByTestId('meal-label')).toHaveValue('Synthetic dates');
      expect(await meals(page)).toEqual([]);
      await page.evaluate(() => { Storage.prototype.setItem = window.__origSet; });
      await page.getByTestId('meal-confirm').click();
      await expect(page.getByTestId('diary-sub-snacks')).toHaveText('1 entry · 120 kcal');
      expect(await meals(page)).toHaveLength(1);
      noErrors(page);
    });

    test(`${W}: Asia/Qatar midnight — an untouched logger follows the new day, a typed one keeps its date with a notice, a deliberately chosen past diary day stays`, async ({ page }) => {
      await open(page, '2026-11-18T20:59:00.000Z'); // 23:59 Wed 18 Nov
      await diary(page); await page.getByTestId('diary-log-lunch').click();
      await expect(page.getByTestId('logger-date')).toContainText('Wed 18 Nov · today');
      await page.clock.setFixedTime(new Date('2026-11-18T21:00:30.000Z')); // 00:00:30 Thu 19 Nov
      await page.evaluate(() => document.dispatchEvent(new Event('visibilitychange')));
      await expect(page.getByTestId('logger-date')).toContainText('Thu 19 Nov · today');
      await expect(page.getByTestId('meal-date')).toHaveValue('2026-11-19');
      await expect(page.getByTestId('meal-cat-lunch')).toHaveAttribute('aria-pressed', 'true');
      await page.getByTestId('meal-path-manual').click();
      await (await nameField(page)).fill('Late lunch');
      await page.clock.setFixedTime(new Date('2026-11-19T21:00:30.000Z')); // 00:00:30 Fri 20 Nov
      await page.evaluate(() => document.dispatchEvent(new Event('visibilitychange')));
      await expect(page.getByTestId('meal-label')).toHaveValue('Late lunch');
      await expect(page.getByTestId('logger-date')).toContainText('Thu 19 Nov');
      await expect(page.getByTestId('logger-not-today')).toBeVisible();
      await expect(page.getByTestId('meal-draft-date')).toBeVisible();
      await page.getByTestId('logger-back').click();
      await page.getByTestId('choice-yes').click();
      await expect(page.getByTestId('today-card')).toContainText('Fri 20 Nov');
      await expect(page.getByTestId('diary-date')).toContainText('Fri 20 Nov · today');
      // a past day opened on purpose is not moved, and neither is a logger opened for it
      await diary(page); await page.getByTestId('diary-prev').click();
      await expect(page.getByTestId('diary-date')).toContainText('Thu 19 Nov');
      await diary(page); await page.getByTestId('diary-log-dinner').click();
      await page.clock.setFixedTime(new Date('2026-11-20T21:00:30.000Z')); // 00:00:30 Sat 21 Nov
      await page.evaluate(() => document.dispatchEvent(new Event('visibilitychange')));
      await expect(page.getByTestId('logger-date')).toContainText('Thu 19 Nov');
      await expect(page.getByTestId('meal-date')).toHaveValue('2026-11-19');
      await expect(page.getByTestId('meal-draft-date')).toHaveCount(0);
      await page.getByTestId('logger-back').click();
      await expect(page.getByTestId('diary-date')).toContainText('Thu 19 Nov');
      await expect(page.getByTestId('today-card')).toContainText('Sat 21 Nov');
      expect(await meals(page)).toEqual([]);
      noErrors(page);
    });

    test(`${W}: an older backup without categories restores unchanged; its meals (even one named "Lunch") are listed under Uncategorized / Earlier meals, never filed by name or time, and still counted`, async ({ page }) => {
      await open(page, '2026-11-10T09:00:00.000Z');
      await page.getByTestId('tab-settings').click();
      await page.getByTestId('import-file').setInputFiles(F('p3-phase3-export.json'));
      await page.getByTestId('import-confirm').click();
      await expect(page.getByTestId('import-result')).toBeVisible();
      await page.reload();
      const before = await page.evaluate(() => localStorage.getItem('hyrox.v1'));
      await diary(page);
      await expect(page.getByTestId('diary-row-uncat')).toBeVisible();
      await expect(page.getByTestId('diary-sub-lunch')).toHaveText('Not logged');
      await expect(page.getByTestId('diary-sub-uncat')).toContainText('2 entries');
      await expect(page.getByTestId('diary-uncat-note')).toBeVisible();
      await diary(page); await page.getByTestId('diary-toggle-uncat').click();
      await expect(page.getByTestId('diary-row-uncat').getByTestId('diary-entry')).toHaveCount(2);
      await expect(page.getByTestId('diary-total')).not.toContainText('unknown, not 0');
      await diary(page); await page.getByTestId('diary-view-all').click();
      expect(await page.evaluate(() => localStorage.getItem('hyrox.v1'))).toBe(before); // viewing never rewrites records
      const src = JSON.parse(fs.readFileSync(F('p3-phase3-export.json'), 'utf8'));
      const now = await stored(page);
      expect(now.meals.map((m) => m.mealCategory)).toEqual(src.meals.map(() => undefined));
      noErrors(page);
    });

    test(`${W}: an unrecognised stored category is kept exactly, listed under Uncategorized with a note, and survives an edit that does not choose one`, async ({ page }) => {
      await open(page);
      await logManual(page, 'lunch', 'Odd one', 310);
      await page.evaluate(() => { const d = JSON.parse(localStorage.getItem('hyrox.v1')); d.meals[0].mealCategory = 'BRUNCH'; localStorage.setItem('hyrox.v1', JSON.stringify(d)); });
      await page.reload();
      await expect(page.getByTestId('app-error')).toBeHidden();
      await expect(page.getByTestId('diary-sub-lunch')).toHaveText('Not logged');
      await expect(page.getByTestId('diary-sub-uncat')).toHaveText('1 entry · 310 kcal');
      await diary(page); await page.getByTestId('diary-toggle-uncat').click();
      await expect(page.getByTestId('diary-entry-orphan')).toBeVisible();
      await page.getByTestId('diary-entry-edit').click();
      await expect(page.getByTestId('logger-title')).toHaveText('Edit meal');
      await expect(page.getByTestId('meal-category-unknown')).toBeVisible();
      await page.getByTestId('component-kcal').first().fill('320');
      await page.getByTestId('meal-confirm').click();
      const m = await meals(page);
      expect(m.map((x) => [x.mealCategory, x.components[0].kcal.value])).toEqual([['BRUNCH', 320]]);
      await page.getByTestId('tab-history').click();
      await expect(page.getByTestId('meal-category-badge')).toHaveText(/Unrecognised category/i);
      noErrors(page);
    });

    test(`${W}: export, restore and reopen keep every record once, each in its slot, with the same qualified totals`, async ({ page }) => {
      await open(page);
      await logManual(page, 'breakfast', 'B1', 300);
      await logManual(page, 'lunch', 'L1', 400);
      await logManual(page, 'lunch', 'L2', 150);
      await page.getByTestId('tab-add').click(); await page.getByTestId('add-mode-meal').click();
      await page.getByTestId('meal-path-manual').click();
      await items(page, 'U1', [['bar', 100]]);
      await page.getByTestId('meal-confirm').click(); // direct Add path, no category chosen
      await page.getByTestId('tab-today').click();
      await expect(page.getByTestId('diary-total')).toContainText('950 kcal confirmed');
      await page.getByTestId('tab-settings').click();
      const [dl] = await Promise.all([page.waitForEvent('download'), page.getByTestId('export-btn').click()]);
      const file = await dl.path();
      expect(JSON.parse(fs.readFileSync(file, 'utf8')).meals.map((x) => [x.label, x.mealCategory])).toEqual([['B1', 'BREAKFAST'], ['L1', 'LUNCH'], ['L2', 'LUNCH'], ['U1', undefined]]);
      await page.evaluate(() => localStorage.clear());
      await page.reload();
      await page.getByTestId('tab-settings').click();
      await page.getByTestId('import-file').setInputFiles(file);
      await page.getByTestId('import-confirm').click();
      await expect(page.getByTestId('import-result')).toBeVisible();
      await page.reload();
      await expect(page.getByTestId('diary-sub-breakfast')).toHaveText('1 entry · 300 kcal');
      await expect(page.getByTestId('diary-sub-lunch')).toHaveText('2 entries · 550 kcal');
      await expect(page.getByTestId('diary-sub-uncat')).toHaveText('1 entry · 100 kcal');
      await expect(page.getByTestId('diary-total')).toContainText('950 kcal confirmed so far — not a full day');
      await expect(page.getByTestId('today-subtotal')).toContainText('950');
      await page.getByTestId('tab-history').click();
      await expect(page.getByTestId('history-meal')).toHaveCount(4);
      noErrors(page);
    });

    test(`${W}: the previous direct paths still work — Add → Meal shows the same form with an explicit category choice (none preset) and (P11.1) returns to the diary; Today's Log meal opens the diary and Photo meal opens the logger`, async ({ page }) => {
      await open(page);
      await page.getByTestId('tab-add').click(); await page.getByTestId('add-mode-meal').click();
      await expect(page.getByTestId('add-modes')).toBeVisible();
      await expect(page.getByTestId('logger-head')).toHaveCount(0);
      for (const c of ['breakfast', 'lunch', 'dinner', 'snacks']) await expect(page.getByTestId('meal-cat-' + c)).toHaveAttribute('aria-pressed', 'false');
      await expect(page.getByTestId('meal-category-none')).toBeVisible();
      await page.getByTestId('meal-path-manual').click();
      await page.getByTestId('meal-cat-dinner').click();
      await expect(page.getByTestId('meal-cat-dinner')).toHaveAttribute('aria-pressed', 'true');
      await items(page, 'Direct dinner', [['pasta', 500]]);
      await page.getByTestId('meal-confirm').click();
      // P11.1 (owner decision, agreed in Claude's P11 review): the direct Add > Meal confirmed save lands on the diary
      await expect(page.getByTestId('meal-diary')).toBeVisible();
      await expect(page.getByTestId('diary-sub-dinner')).toHaveText('1 entry · 500 kcal');
      await page.getByTestId('tab-history').click();
      await expect(page.getByTestId('panel-history')).toBeVisible();
      await expect(page.getByTestId('meal-category-badge')).toHaveText('Dinner');
      await page.getByTestId('tab-today').click();
      // P0 (22 Nov 2026): Today's "Log meal" opens the diary on Add > Meal (no logger yet, no category preset in the form under it)
      await page.getByTestId('today-add-meal').click();
      await expect(page.getByTestId('meal-diary')).toBeVisible();
      await expect(page.getByTestId('diary-sub-dinner')).toHaveText('1 entry · 500 kcal');
      await expect(page.getByTestId('logger-head')).toHaveCount(0);
      await expect(page.getByTestId('meal-category-none')).toBeVisible();
      await page.getByTestId('tab-today').click();
      await page.getByTestId('today-photo-meal').click();
      await expect(page.getByTestId('logger-title')).toHaveText('Log a meal');
      await expect(page.getByTestId('meal-path-photo_ai')).toHaveClass(/active/);
      await page.getByTestId('logger-back').click();
      await expect(page.getByTestId('meal-diary')).toBeVisible();
      noErrors(page);
    });

    test(`${W}: compact, accessible UI — >=44 px targets, >=16 px inputs, body 15 px, headings 18/22 px, readable dialog, zoom allowed, no sideways scroll`, async ({ page }) => {
      await open(page);
      await logManual(page, 'lunch', 'Size check', 200);
      const viewport = await page.evaluate(() => document.querySelector('meta[name="viewport"]').getAttribute('content'));
      expect(viewport).not.toMatch(/maximum-scale|user-scalable\s*=\s*(no|0)/i);
      expect(await page.evaluate(() => parseFloat(getComputedStyle(document.body).fontSize))).toBe(15);
      expect(await page.evaluate(() => parseFloat(getComputedStyle(document.querySelector('#diary-heading')).fontSize))).toBe(18);
      const small = await page.getByTestId('meal-diary').locator('button').evaluateAll((els) => els.filter((e) => e.offsetParent).map((e) => { const r = e.getBoundingClientRect(); return [e.getAttribute('data-testid'), Math.round(r.height), Math.round(r.width)]; }).filter((x) => x[1] < 44 || x[2] < 44));
      expect(small).toEqual([]);
      const secondary = await page.getByTestId('meal-diary').locator('.diary-cat-sub, .hint').evaluateAll((els) => els.map((e) => parseFloat(getComputedStyle(e).fontSize)));
      expect(Math.min(...secondary)).toBeGreaterThanOrEqual(12);
      await noHScroll(page);
      await diary(page); await page.getByTestId('diary-log-dinner').click();
      expect(await page.evaluate(() => parseFloat(getComputedStyle(document.querySelector('[data-testid="logger-title"]')).fontSize))).toBe(22);
      const loggerSmall = await page.locator('[data-testid="logger-head"] button, [data-testid="meal-category"] button, [data-testid="meal-form"] .segmented button').evaluateAll((els) => els.filter((e) => e.offsetParent).map((e) => [e.getAttribute('data-testid'), Math.round(e.getBoundingClientRect().height)]).filter((x) => x[1] < 44));
      expect(loggerSmall).toEqual([]);
      const fonts = await page.getByTestId('meal-form').locator('input:not([type=checkbox]):not([type=radio]):not([type=file]), select, textarea').evaluateAll((els) => els.map((e) => [e.getAttribute('data-testid'), parseFloat(getComputedStyle(e).fontSize)]).filter((x) => x[1] < 16));
      expect(fonts).toEqual([]);
      await noHScroll(page);
      // the Keep/Discard dialog is readable (it was white-on-white in the dark theme)
      await page.getByTestId('meal-path-manual').click();
      await (await nameField(page)).fill('x');
      await page.getByTestId('logger-back').click();
      const contrast = await page.evaluate(() => {
        const lum = (c) => { const v = c.match(/\d+(\.\d+)?/g).slice(0, 3).map(Number).map((x) => { x /= 255; return x <= 0.03928 ? x / 12.92 : Math.pow((x + 0.055) / 1.055, 2.4); }); return 0.2126 * v[0] + 0.7152 * v[1] + 0.0722 * v[2]; };
        const box = document.querySelector('.choice-box'), body = document.querySelector('[data-testid="choice-body"]');
        const a = lum(getComputedStyle(box).backgroundColor), b = lum(getComputedStyle(body).color);
        return (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05);
      });
      expect(contrast).toBeGreaterThanOrEqual(4.5);
      await page.getByTestId('choice-keep').click();
      noErrors(page);
    });
  });
}
