'use strict';
// Phase 8: quiet Today dashboard, Week 1 = 16 Nov re-anchor, old-date records, Moderate effort.
// Chrome emulation, not Safari/WebKit. Synthetic data only; the clock is fixed in Asia/Qatar.
const path = require('path');
const { test, expect } = require('@playwright/test');
const { openWhy, openFullPlan } = require('./p8-open');

const MON = '2026-11-16T06:00:00.000Z'; // Mon 16 Nov 09:00 Qatar = Week 1 Monday
const SCREEN = path.join(__dirname, '..', 'out', 'p8-screens');

async function boot(page, now, seed) {
  await page.clock.setFixedTime(new Date(now));
  await page.goto('./');
  await page.evaluate(() => localStorage.clear());
  if (seed) await page.evaluate(seed);
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
  await expect(page.getByTestId('today-glance')).toBeVisible();
}
const seedEggsAndWalk = () => {
  const HD = window.HyroxData, st = HD.createStore(), d = HD.todayQatar(), ts = new Date().toISOString(), k = (v) => ({ value: v, state: 'KNOWN' });
  const r1 = st.putRecord('meals', { id: 'm-eggs', createdAt: ts, date: d, time: '08:00', label: '4 boiled eggs', description: '4 boiled eggs', source: 'MANUAL', lifecycle: 'CONFIRMED', confirmedAt: ts,
    components: [{ name: 'Boiled egg', role: 'OTHER', portion: '4 eggs', preparation: '', eatenFraction: null, kcal: k(310), proteinG: k(25), carbsG: k(1.6), fatG: k(21) }] });
  const r2 = st.putRecord('walks', { id: 'w-1', date: d, durationMin: 60, steps: 7500 });
  if (!r1.ok || !r2.ok) throw new Error(JSON.stringify([r1, r2]));
};
const noOverflow = async (page) => expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);

for (const W of [320, 390]) {
  test.describe(`${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: 844 } });

    test(`today ${W}: date + Week 1/4, today's workout, readiness, steps and nutrition use the owner's wording; detail is folded away`, async ({ page }) => {
      await boot(page, MON, seedEggsAndWalk);
      await expect(page.getByTestId('today-card')).toContainText('Mon 16 Nov · Week 1/4');
      await expect(page.getByTestId('today-card').getByTestId('slot-v2.1-W1-MON')).toContainText('Strength A');
      await expect(page.getByTestId('slot-summary')).toContainText('Back squat');
      const card = page.getByTestId('today-card');
      await expect(card.getByTestId('log-slot-v2.1-W1-MON')).toHaveText('Log workout');
      await expect(card.getByTestId('slot-view-v2.1-W1-MON')).toHaveText('View workout');
      await expect(page.getByTestId('glance-readiness-text')).toHaveText('Readiness not checked — log sleep, soreness, resting HR');
      await expect(page.getByTestId('glance-readiness-missing')).toContainText('3 inputs needed');
      await expect(page.getByTestId('glance-steps-text')).toHaveText('Steps 7,500+ recorded (daily total unknown)');
      await expect(page.getByTestId('glance-nutrition-text')).toHaveText('Nutrition 310 kcal confirmed so far — not full day.');
      await expect(page.getByTestId('today-add-meal')).toHaveText('Log meal');
      // distinct, spaced macro labels
      const cells = page.getByTestId('glance-macros').locator('.macro-cell');
      await expect(cells).toHaveCount(3);
      await expect(cells.nth(0)).toContainText('Protein'); await expect(cells.nth(0)).toContainText('25 g');
      await expect(cells.nth(1)).toContainText('Carbs'); await expect(cells.nth(2)).toContainText('Fat');
      // the engineering text is not on the quiet screen
      for (const id of ['rhr-comparisons', 'today-step-gate', 'today-step-reference-box', 'step-guidance-unapproved', 'rhr-baseline', 'plan-calendar', 'readiness-guidance']) await expect(page.getByTestId(id)).toBeHidden();
      await expect(page.getByTestId('today-glance')).not.toContainText(/76 bpm|10,000|multiplier|cascade|HNC-BASE|citation/i);
      // each of the three inputs is a link to its field, and every touch target is large enough
      await page.screenshot({ path: path.join(SCREEN, `p8-today-${W}-fold.png`) });
      for (const id of ['sleepH', 'soreness', 'rhr']) {
        const b = await page.getByTestId('glance-missing-' + id).boundingBox();
        expect(b.height, id).toBeGreaterThanOrEqual(44); expect(b.width, id).toBeGreaterThanOrEqual(44);
      }
      for (const id of ['today-add-meal', 'today-photo-meal', 'log-slot-v2.1-W1-MON', 'slot-view-v2.1-W1-MON', 'today-checkin', 'today-why-toggle', 'today-fullplan-toggle']) {
        const b = await page.getByTestId('today-root').getByTestId(id).first().boundingBox();
        expect(b.height, id).toBeGreaterThanOrEqual(44);
      }
      await noOverflow(page);
    });

    test(`today ${W}: no empty list items, consistent row gaps, nothing wider than the screen`, async ({ page }) => {
      await boot(page, MON, seedEggsAndWalk);
      await openWhy(page); await openFullPlan(page);
      const empties = await page.evaluate(() => [...document.querySelectorAll('#today-root li')].filter((li) => !li.textContent.trim() && !li.querySelector('*')).length);
      expect(empties).toBe(0);
      const gaps = await page.evaluate(() => {
        const rows = [...document.querySelectorAll('[data-testid="today-glance"] .dash-row')];
        return rows.slice(1).map((r, i) => Math.round(r.getBoundingClientRect().top - rows[i].getBoundingClientRect().bottom));
      });
      expect(new Set(gaps).size).toBe(1); // identical gap between every pair of dashboard rows
      await noOverflow(page);
      await page.addStyleTag({ content: '.tabbar{position:static !important}' });
      await page.screenshot({ path: path.join(SCREEN, `p8-today-${W}-all-open.png`), fullPage: true });
    });
  });
}

test('why / full plan: closed by default, open on demand with the full source text; only today\'s prescription is expanded', async ({ page }) => {
  await boot(page, MON, seedEggsAndWalk);
  await expect(page.getByTestId('today-why')).not.toHaveAttribute('open', '');
  await expect(page.getByTestId('today-fullplan')).not.toHaveAttribute('open', '');
  await openWhy(page);
  await expect(page.getByTestId('rhr-baseline')).toContainText('configured: 76 bpm');
  await expect(page.getByTestId('today-step-reference')).toContainText('Week 1 reference goal: 7,000 steps/day');
  await expect(page.getByTestId('today-step-gate')).toContainText('NOT passed');
  await expect(page.getByTestId('step-guidance-unapproved')).toContainText('app suggestions that the owner has NOT approved');
  await expect(page.getByTestId('today-step-guidance-label')).toContainText('adaptive app suggestion');
  await expect(page.getByTestId('block-status-detail')).toHaveText('Block v2.1 (conditional approval, not medical clearance) — Week 1 of 4. Ends Sun 13 Dec 2026.');
  await openFullPlan(page);
  await expect(page.getByTestId('plan-week-1')).toBeVisible();
  await expect(page.getByTestId('plan-calendar')).toContainText('Mon 16 Nov');
  await expect(page.getByTestId('plan-calendar')).toContainText('Fri 20 Nov');
  // only today's slot has its prescription expanded
  const open = await page.evaluate(() => [...document.querySelectorAll('[data-testid="plan-calendar"] details')].map((d) => [d.closest('[data-testid^="slot-"]').getAttribute('data-testid'), d.open]));
  expect(open.filter((x) => x[1]).map((x) => x[0])).toEqual(['slot-v2.1-W1-MON']);
  expect(open.length).toBe(5);
  await page.getByTestId('plan-week-4').click();
  await expect(page.getByTestId('plan-calendar')).toContainText('Mon 7 Dec');
  await expect(page.getByTestId('plan-calendar')).toContainText('Fri 11 Dec');
  await expect(page.getByTestId('plan-calendar')).toContainText('deload');
  await expect(page.getByTestId('plan-calendar')).not.toContainText('Week 5');
  await expect(page.getByTestId('today-fullplan')).toHaveAttribute('open', ''); // stays open after switching week
  await page.getByTestId('today-card').getByTestId('slot-view-v2.1-W1-MON').click();
  await expect(page.getByTestId('slot-rx-v2.1-W1-MON')).toBeVisible();
  await expect(page.getByTestId('slot-rx-v2.1-W1-MON')).toContainText('Back squat');
});

test('triggered safety warnings stay prominent without opening anything; a missing check-in is never "fine"', async ({ page }) => {
  await boot(page, MON, () => {
    const st = window.HyroxData.createStore(), d = window.HyroxData.todayQatar(), O = (v) => ({ state: 'OBSERVED', value: v });
    const r = st.putRecord('daily', { date: d, sleepH: O(4.5), soreness: O(8), pain: O(6), rhr: O(90), footPain: O(5), limp: O(true), stairKneePain: O(1) });
    if (!r.ok) throw new Error(JSON.stringify(r));
  });
  const alerts = page.getByTestId('today-alerts');
  await expect(alerts).toBeVisible();
  await expect(alerts.getByTestId('readiness-flag').first()).toBeVisible();
  expect(await alerts.getByTestId('readiness-flag').count()).toBeGreaterThanOrEqual(1);
  await expect(alerts).toContainText('Pain recorded (6/10)');
  await expect(page.getByTestId('glance-readiness-text')).toContainText(/flag/);
  await expect(page.getByTestId('today-step-do-not-force')).toBeVisible();
  await expect(page.getByTestId('today-step-do-not-force')).toContainText('Recovery first — do not force the reference goal today');
  await expect(page.getByTestId('today-why')).not.toHaveAttribute('open', '');
});

test('nothing recorded: unknown stays unknown (no 0), a missing check-in is not "no problem"', async ({ page }) => {
  await boot(page, MON);
  await expect(page.getByTestId('glance-steps-text')).toHaveText('Steps not recorded (unknown)');
  await expect(page.getByTestId('glance-nutrition-text')).toHaveText('Nutrition: nothing confirmed (unknown)');
  await expect(page.getByTestId('glance-readiness-text')).not.toContainText(/no flags|fine|ok/i);
  await expect(page.getByTestId('today-alerts')).toHaveCount(0);
});

test('re-anchor: before the block (Sat 14 Nov), Day 0 (Sun 15 Nov), Week 4 end (Sun 13 Dec) and after (Mon 14 Dec) read honestly', async ({ page }) => {
  await boot(page, '2026-11-14T08:00:00.000Z');
  await expect(page.getByTestId('today-card')).toContainText('Sat 14 Nov · Week 1 starts Mon 16 Nov');
  await expect(page.getByTestId('block-status')).toHaveText('Block v2.1 starts Mon 16 Nov 2026 (source Day 0 Sun 15 Nov).');
  await expect(page.getByTestId('today-card').locator('[data-testid^="slot-v2.1"]')).toHaveCount(0);
  await boot(page, '2026-11-15T08:00:00.000Z');
  await expect(page.getByTestId('today-card')).toContainText('Sun 15 Nov · Day 0');
  await boot(page, '2026-11-18T08:00:00.000Z');
  await expect(page.getByTestId('today-card')).toContainText('Wed 18 Nov · Week 1/4');
  await expect(page.getByTestId('today-card').getByTestId('slot-v2.1-W1-WED')).toContainText('Strength B');
  await boot(page, '2026-12-13T08:00:00.000Z');
  await expect(page.getByTestId('today-card')).toContainText('Sun 13 Dec · Week 4/4');
  await expect(page.getByTestId('today-weekend')).toBeVisible();
  await boot(page, '2026-12-14T08:00:00.000Z');
  await expect(page.getByTestId('today-card')).toContainText('no active block');
  await expect(page.getByTestId('block-status')).toHaveText('No current approved training block');
  // Qatar midnight: 20:59Z Sunday is still Day 0, 21:00Z is Week 1 Monday
  await boot(page, '2026-11-15T20:59:00.000Z');
  await expect(page.getByTestId('today-card')).toContainText('Day 0');
  await boot(page, '2026-11-15T21:00:00.000Z');
  await expect(page.getByTestId('today-card')).toContainText('Mon 16 Nov · Week 1/4');
});

test('old-date records: stored bytes are untouched, History still lists them, the new Week 1 does not count them', async ({ page }) => {
  const OLD = { version: 2, weight: [], workouts: [], nutrition: [],
    sessions: [{ id: 'old-thu', createdAt: '2026-11-12T10:00:00.000Z', updatedAt: '2026-11-12T10:00:00.000Z', date: '2026-11-12', title: 'Aerobic HYROX (test entry)', status: 'COMPLETED',
      modified: false, variant: 'ORIGINAL_60', planSlotId: 'v2.1-W1-THU', planVersion: 'v2.1', scheduledDate: '2026-11-12', blocks: [] }],
    planEvents: [{ id: 'ev-old', createdAt: '2026-11-12T10:30:00.000Z', updatedAt: '2026-11-12T10:30:00.000Z', date: '2026-11-09', kind: 'MISSED_MONDAY', week: 1 }] };
  await page.clock.setFixedTime(new Date(MON));
  await page.goto('./');
  const text = JSON.stringify(OLD);
  await page.evaluate((t) => { localStorage.clear(); localStorage.setItem('hyrox.v1', t); }, text);
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
  // Monday is NOT treated as missed by the old (9 Nov) cascade: Strength A is shown today
  await expect(page.getByTestId('today-card').getByTestId('slot-v2.1-W1-MON')).toBeVisible();
  await openFullPlan(page);
  await expect(page.getByTestId('plan-summary')).toContainText('0 completed');
  await expect(page.getByTestId('plan-summary')).toContainText('20 not logged');
  await expect(page.getByTestId('plan-preblock-note')).toContainText('1 workout record and 1 plan change');
  await expect(page.getByTestId('plan-calendar').getByTestId('slot-v2.1-W1-THU').getByTestId('slot-status')).toHaveText('Not logged');
  await expect(page.getByTestId('cascade-missed_monday')).toContainText('Mark Monday missed');
  expect(await page.evaluate(() => localStorage.getItem('hyrox.v1'))).toBe(text); // opening, rendering and reading never write
  await page.getByTestId('tab-history').click();
  await expect(page.getByTestId('history-session')).toHaveCount(1);
  await expect(page.getByTestId('history-session')).toContainText('Aerobic HYROX (test entry)');
  await expect(page.getByTestId('history-preblock')).toContainText('Before Week 1');
  // export still carries them
  const [dl] = await Promise.all([page.waitForEvent('download'), (async () => { await page.getByTestId('tab-settings').click(); await page.getByTestId('export-btn').click(); })()]);
  const exp = JSON.parse(require('fs').readFileSync(await dl.path(), 'utf8'));
  expect(exp.sessions.map((s) => s.id)).toEqual(['old-thu']); expect(exp.planEvents.map((e) => e.id)).toEqual(['ev-old']);
});

test('Moderate effort: offered between Easy and Demanding with RPE hints, saved, shown in History, and counted as hard', async ({ page }) => {
  await boot(page, '2026-11-18T08:00:00.000Z');
  await page.getByTestId('tab-add').click();
  await page.getByTestId('add-mode-workout').click();
  const sel = page.getByTestId('session-intensity');
  expect(await sel.locator('option').allTextContents()).toEqual(['Not stated', 'Easy', 'Moderate', 'Demanding']);
  await expect(page.getByTestId('panel-add')).toContainText('Easy ≈ RPE 1–4 · Moderate ≈ RPE 5–6 · Demanding ≈ RPE 7–10');
  await expect(page.getByTestId('session-rpe')).toBeVisible(); // the numeric RPE field stays
  await page.getByTestId('session-title').fill('Steady jog (test)');
  await page.getByTestId('session-rpe').fill('3');
  await sel.selectOption('MODERATE');
  await page.getByTestId('session-save').click();
  await expect(page.getByTestId('ext-toast')).toContainText('Saved');
  const raw = await page.evaluate(() => JSON.parse(localStorage.getItem('hyrox.v1')));
  expect(raw.sessions[0].intensity).toBe('MODERATE'); expect(raw.sessions[0].rpe).toBe(3);
  await page.getByTestId('tab-history').click();
  await expect(page.getByTestId('history-session-intensity')).toHaveText('Moderate');
  // counted as hard: a reschedule onto that day would be refused (two hard sessions are never stacked)
  const code = await page.evaluate(() => { const s = window.HyroxData.createStore().records('sessions'); return window.HyroxPlan.rescheduleCheck('v2.1-W1-FRI', s[0].date, s, [], '2026-11-17'); });
  expect(code.ok).toBe(false);
});
