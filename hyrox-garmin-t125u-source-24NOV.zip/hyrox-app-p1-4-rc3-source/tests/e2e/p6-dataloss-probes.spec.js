'use strict';
// P6 data-disappearance probes, adopted from scratch-dataloss (Tewodros team) by Liya t75u.
// Chrome emulation, NOT Safari/WebKit. Synthetic data only. Installed Chrome, 390x844.
// P6-DL-2: one failed script download used to hide every Phase 3 record silently. The DESIRED case is now a real test:
// the app must say 'Part of the app did not load. Your saved records are safe.' and must change no stored data.
// The characterization cases are kept honest: stored data intact, the Phase 3 views really are absent, and (new) the warning shows.
const { test, expect } = require('@playwright/test');
const T = '2026-11-10T06:00:00.000Z', NOW = '2026-11-12T06:00:00.000Z';
const MSG = 'Part of the app did not load. Your saved records are safe.';
const MEAL = { id: 'm1', createdAt: T, updatedAt: T, date: '2026-11-11', label: 'Synthetic test meal', source: 'MANUAL', lifecycle: 'CONFIRMED', confirmedAt: T, eatenFraction: 1,
  components: [{ name: 'Rice', role: 'MAIN', eatenFraction: null, kcal: { value: 200, state: 'KNOWN' }, proteinG: { value: 4, state: 'KNOWN' }, carbsG: { value: 44, state: 'KNOWN' }, fatG: { value: 1, state: 'KNOWN' } }] };
const DATA = { version: 2, weight: [], workouts: [], nutrition: [], meals: [MEAL] };

async function boot(page, blockPattern) {
  await page.clock.setFixedTime(new Date(NOW));
  await page.goto('./');
  await page.evaluate((d) => { localStorage.clear(); localStorage.setItem('hyrox.v1', JSON.stringify(d)); }, DATA);
  if (blockPattern) await page.route(blockPattern, (r) => r.abort('failed'));
  await page.reload();
}
const stored = (page) => page.evaluate(() => { const o = {}; for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); o[k] = localStorage.getItem(k); } return o; });

test('control: all scripts load -> the confirmed meal is visible in History and no load warning', async ({ page }) => {
  await boot(page, null);
  await page.getByTestId('tab-history').click();
  await expect(page.getByText('Synthetic test meal')).toBeVisible();
  await expect(page.getByTestId('load-guard')).toBeHidden();
});

const SCRIPTS = ['src/ui/app-ext.js', 'src/data/hyrox-nutrition.js', 'src/data/hyrox-wellness.js', 'src/data/hyrox-plan.js', 'src/ai/photo-ai.js', 'src/integrations/stubs.js', 'src/ui/app.js'];
for (const f of SCRIPTS) {
  test('P6-DL-2: ' + f + ' fails to download -> visible "did not load" message, record intact, nothing written', async ({ page }) => {
    await boot(page, '**/' + f);
    const guard = page.getByTestId('load-guard');
    await expect(guard).toBeVisible();
    await expect(guard).toHaveAttribute('role', 'alert');
    await expect(page.getByTestId('load-guard-message')).toHaveText(MSG);
    await expect(page.getByTestId('load-guard-missing')).toContainText(f);
    const before = await stored(page);
    expect(JSON.parse(before['hyrox.v1']).meals).toHaveLength(1); // data still stored, exactly as seeded
    expect(before['hyrox.v1']).toBe(JSON.stringify(DATA));
    const b = await page.getByTestId('load-guard-reload').boundingBox();
    expect(b.height).toBeGreaterThanOrEqual(44);
    const m = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
    expect(m.sw).toBeLessThanOrEqual(m.cw);
    if (f === 'src/ui/app-ext.js') { // characterization kept: the Phase 3 History view is really absent in this state
      await page.getByTestId('tab-history').click();
      expect((await page.getByTestId('history-root').innerText()).trim()).toBe('');
      expect(await page.getByText('Synthetic test meal').count()).toBe(0);
    }
    expect(await stored(page)).toEqual(before); // looking at the page wrote nothing
  });
}

test('P6-DL-2: a script that is served but is not JavaScript (login page HTML) also triggers the message', async ({ page }) => {
  await boot(page, null);
  await page.route('**/src/data/hyrox-wellness.js', (r) => r.fulfill({ status: 200, contentType: 'text/html', body: '<html>sign in</html>' }));
  await page.reload();
  await expect(page.getByTestId('load-guard-message')).toHaveText(MSG);
  await expect(page.getByTestId('load-guard-missing')).toContainText('src/data/hyrox-wellness.js');
  expect(JSON.parse((await stored(page))['hyrox.v1']).meals).toHaveLength(1);
});

test('P6-DL-2 at 320 px: message readable, no horizontal scroll', async ({ page }) => {
  await page.setViewportSize({ width: 320, height: 568 });
  await boot(page, '**/src/ui/app-ext.js');
  await expect(page.getByTestId('load-guard-message')).toHaveText(MSG);
  const m = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
  expect(m.sw).toBeLessThanOrEqual(m.cw);
  await page.screenshot({ path: (process.env.P6_SHOTS || '/workspace/hyrox-p6/results/liya-shots') + '/p6-320-load-guard.png' });
});
