'use strict';
// Liya t59u regression (failing-first on b21cf93): meal total pills must wrap inside the card instead of
// pushing the page wider than the screen. Chrome emulation, NOT Safari. Synthetic data only.
// Run: NODE_PATH=/workspace/hyrox-p2/tools/node_modules LIYA_MATCH=p4-regress-meal-totals.spec.js \
//      /workspace/hyrox-p2/tools/node_modules/.bin/playwright test -c p4.config.js
const { test, expect } = require('@playwright/test');
const L = require('./p4-lib');

async function partialMeal(page) {
  await page.getByTestId('tab-add').click();
  await page.getByTestId('add-mode-meal').click();
  await page.getByTestId('meal-path-manual').click();
  await page.getByTestId('meal-add-component').click();
  await page.getByTestId('meal-add-component').click();
  const row = page.getByTestId('component-row').nth(0);
  await row.getByTestId('component-name').fill('Synthetic rice');
  const v = { kcal: '650', proteinG: '45.5', carbsG: '80', fatG: '22.5' };
  for (const k of Object.keys(v)) await row.getByTestId('component-' + k).fill(v[k]);
  await expect(page.getByTestId('meal-total-proteinG')).toContainText('unknown part');
}
function measure() {
  const vw = document.documentElement.clientWidth;
  return { vw, sw: document.documentElement.scrollWidth, pills: [...document.querySelectorAll('[data-testid^="meal-total-"]')].map((e) => {
    const b = e.getBoundingClientRect(); const c = e.closest('.card').getBoundingClientRect();
    return { id: e.dataset.testid, right: Math.round(b.right), cardRight: Math.round(c.right) }; }) };
}

test('meal totals with partial (unknown-part) values stay inside the card and the viewport', async ({ page }, ti) => {
  await L.boot(page, ti, { attention: false });
  await partialMeal(page);
  const m = await page.evaluate(measure);
  console.log(ti.project.metadata.w, JSON.stringify(m));
  expect(m.sw, 'page must not scroll sideways').toBeLessThanOrEqual(m.vw);
  if (process.env.LIYA_SHOT_TAG) { await page.getByTestId('meal-totals').scrollIntoViewIfNeeded(); await L.shot(page, ti.project.metadata.w + '-meal-totals-partial-' + process.env.LIYA_SHOT_TAG, false); }
  for (const p of m.pills) expect(p.right, p.id + ' inside card').toBeLessThanOrEqual(p.cardRight);
});

test('meal totals at the 150% page-zoom proxy (320/1.5 = 213 CSS px) do not widen the page', async ({ page }, ti) => {
  test.skip(ti.project.metadata.w !== 320, 'proxy only for the 320 project');
  await L.boot(page, ti, { attention: false });
  await page.setViewportSize({ width: 213, height: 379 });
  await page.getByTestId('tab-add').click();
  await page.getByTestId('add-mode-meal').click();
  const m = await page.evaluate(measure);
  console.log('213', JSON.stringify(m));
  expect(m.sw).toBeLessThanOrEqual(m.vw);
  for (const p of m.pills) expect(p.right, p.id + ' inside card').toBeLessThanOrEqual(p.cardRight);
});
