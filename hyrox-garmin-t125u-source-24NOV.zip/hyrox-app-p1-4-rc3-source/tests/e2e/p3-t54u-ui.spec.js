'use strict';
// t54u UI: restore refusal details and the stored out-of-range-pain skip (Liya 088220d).
// Synthetic data only. Chrome mobile emulation (390px), not Safari/WebKit.
// Runnable against the build tree via HYROX_APP_ROOT (data + UI from the served app).
const path = require('path');
const { test, expect } = require('@playwright/test');
const { openWhy, openFullPlan } = require('./p8-open');

const SCREEN = process.env.P3_SHOTS || path.join(__dirname, '..', 'out', 'screens'); // Claude P5: was /workspace/hyrox-p3/results/screens (not writable on other machines)
const T = '2026-11-17T06:00:00.000Z';
const NOW = '2026-11-19T06:00:00.000Z';

async function boot(page, { now = NOW, data } = {}) {
  await page.clock.setFixedTime(new Date(now));
  await page.goto('./');
  await page.evaluate((d) => {
    localStorage.clear();
    if (typeof d === 'string') localStorage.setItem('hyrox.v1', d);
    else if (d) localStorage.setItem('hyrox.v1', JSON.stringify(d));
  }, data === undefined ? null : data);
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
  // Phase 8: Today's detail sits under two closed folds; open them so the checks below still read the same elements.
  await openWhy(page); await openFullPlan(page);
}
const stored = (page) => page.evaluate(() => JSON.parse(localStorage.getItem('hyrox.v1')));
const shot = (page, name) => page.screenshot({ path: path.join(SCREEN, name), fullPage: true });

function fracBackup() {
  return JSON.stringify({
    app: 'hyrox-app', version: 2, exportedAt: T,
    weight: [{ id: 'w1', createdAt: T, date: '2026-11-17', kg: 80 }],
    workouts: [], nutrition: [],
    daily: [{ id: 'legacy-frac', createdAt: T, date: '2026-11-08', steps: { state: 'OBSERVED', value: 10.5 } }],
  });
}

test('t54u restore-details: a refused fractional daily backup shows exact field, value, rule and how-to-correct; nothing is changed', async ({ page }) => {
  await boot(page, {
    data: {
      version: 2,
      weight: [{ id: 'live-w', createdAt: T, date: '2026-11-17', kg: 79 }],
      workouts: [], nutrition: [], daily: [],
    },
  });
  const before = await page.evaluate(() => localStorage.getItem('hyrox.v1'));

  await page.getByTestId('tab-settings').click();
  await page.getByTestId('import-file').setInputFiles({
    name: 'hyrox-frac-daily.json',
    mimeType: 'application/json',
    buffer: Buffer.from(fracBackup(), 'utf8'),
  });

  await expect(page.getByTestId('import-details')).toBeVisible();
  await expect(page.getByTestId('import-details-total')).toContainText('1 problem found');
  await expect(page.getByTestId('import-details-unchanged')).toContainText('Nothing was changed: your data on this device is exactly as it was');
  const item = page.getByTestId('import-detail');
  await expect(item).toHaveCount(1);
  await expect(page.getByTestId('import-detail-where')).toContainText('daily');
  await expect(page.getByTestId('import-detail-where')).toContainText('legacy-frac');
  await expect(page.getByTestId('import-detail-where')).toContainText('2026-11-08');
  await expect(page.getByTestId('import-detail-field')).toContainText('steps.value');
  await expect(page.getByTestId('import-detail-value')).toHaveText('10.5');
  await expect(page.getByTestId('import-detail-type')).toContainText('number');
  await expect(page.getByTestId('import-detail-rule')).toContainText('whole number');
  await expect(page.getByTestId('import-detail-how')).toContainText('How to correct:');
  await expect(page.getByTestId('import-detail-how')).toContainText('steps.value');
  await expect(page.getByTestId('import-details-guide')).toContainText('The app will not round, repair or change any value for you');
  await expect(page.getByTestId('import-status')).toContainText('Not restored');
  await expect(page.getByTestId('import-status')).toContainText('was not changed');
  await expect(page.getByTestId('import-preview')).toBeHidden();
  expect(await page.evaluate(() => localStorage.getItem('hyrox.v1'))).toBe(before);
  await shot(page, 'r2-import-details.png');
});

// Round 2 independent review (Claude): this test REPLACES the "characterization (current behaviour)"
// test that asserted the valid sleep / limp values vanish from Today. That behaviour was repaired;
// the full journey (correction, backup, raw copy) is in tests/e2e/r2-claude-repairs.spec.js.
test('repaired (was a characterization): a stored daily with out-of-range pain keeps its valid sleep/limp/steps on Today and names the invalid field', async ({ page }) => {
  await boot(page, {
    now: NOW,
    data: {
      version: 2, weight: [], workouts: [], nutrition: [],
      daily: [{
        id: 'd-bad', createdAt: T, updatedAt: T, date: '2026-11-19',
        footPain: { state: 'OBSERVED', value: 11 },
        stairKneePain: { state: 'OBSERVED', value: 1 },
        sleepH: { state: 'OBSERVED', value: 7 },
        limp: { state: 'OBSERVED', value: false },
        steps: { state: 'OBSERVED', value: 8000 },
      }],
    },
  });
  const before = await page.evaluate(() => localStorage.getItem('hyrox.v1'));
  await expect(page.getByTestId('storage-warning')).toBeHidden();
  await expect(page.getByTestId('today-steps')).toContainText('8,000');
  await expect(page.getByTestId('today-step-gate')).toHaveAttribute('data-gate-status', 'UNKNOWN');
  await expect(page.getByTestId('today-step-gate')).toContainText('NOT passed');
  await expect(page.getByTestId('today-step-gate')).toContainText('7 h');
  await expect(page.getByTestId('today-step-gate')).toContainText('no limp recorded');
  await expect(page.getByTestId('today-step-gate-invalid')).toHaveAttribute('data-invalid', 'footPain');
  await expect(page.getByTestId('today-invalid-values')).toContainText('first-step foot pain: stored 11');
  expect(await page.evaluate(() => localStorage.getItem('hyrox.v1'))).toBe(before);
});
