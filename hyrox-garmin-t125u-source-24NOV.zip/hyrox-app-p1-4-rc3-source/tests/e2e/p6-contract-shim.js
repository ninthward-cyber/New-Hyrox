'use strict';
// P6 (Liya t75u) test-only stand-in for /workspace/hyrox-p6/CONTRACT-P6.md section 2-4 (v1.1), used by
// p6-text-estimate.spec.js until/unless Dawit's real src/data/hyrox-foodcalc.js + food-db.js exist in the tree.
// FIXTURE DATA ONLY: five invented foods with fdcIds 9000xx marked "(SHIM)". It is NOT a food database and never ships.
// Chrome emulation, not Safari/WebKit. With the real files present the real ones are served (set P6_SHIM=force to override).
const fs = require('fs');
const path = require('path');
const ROOT = path.resolve(__dirname, '..', '..');
const REAL_CALC = fs.existsSync(path.join(ROOT, 'src/data/hyrox-foodcalc.js'));
const REAL_DB = fs.existsSync(path.join(ROOT, 'src/data/food-db.js'));
const FORCE = process.env.P6_SHIM === 'force';
const REAL = { calc: REAL_CALC, db: REAL_DB, forced: FORCE };
// The shim is used when forced (P6_SHIM=force, or installFoodShim(page,{force:true}) for the deliberate edge-case spec) or when real files are missing.

const DB = { meta: { schema: 1, dbVersion: 'SHIM-FIXTURE-0', sources: [{ dataset: 'SR Legacy', release: 'fixture' }], license: 'fixture', citation: 'fixture', notes: 'fixture', foodCount: 6 }, foods: [
  [900001, 'SR', 'Egg, whole, raw (SHIM)', 143, 12.6, 0.7, 9.5, [[1, 'large', 50], [1, 'medium', 44]]],
  [900002, 'SR', 'Rice, white, cooked (SHIM)', 130, 2.7, 28, 0.3, [[1, 'cup', 158]]],
  [900003, 'SR', 'Milk, whole (SHIM)', 61, 3.2, 4.8, 3.3, [[1, 'cup', 244]]],
  [900004, 'SR', 'Oil, olive (SHIM)', 884, 0, 0, 100, [[1, 'tbsp', 13.5]]],
  [900005, 'SR', 'Chicken, breast, roasted (SHIM)', 165, 31, 0, 3.6, [[1, 'piece', 120]]],
  [900006, 'FF', 'Chicken, thigh, roasted (SHIM)', 209, 26, 0, 10.9, [[1, 'piece', 100]]] ] };

const CALC_SRC = `(function(){
  var UN={g:1,gram:1,grams:1,cup:'cup',cups:'cup',tbsp:'tbsp',tablespoon:'tbsp',tablespoons:'tbsp',ml:'ml',piece:'piece',pieces:'piece'};
  function db(d){ d=d||window.HyroxFoodDb; if(!d||!d.foods) return null; return d; }
  function parseOne(raw){ var m=/^\\s*(\\d+(?:\\.\\d+)?|a|an|one|two|half)?\\s*(g|grams?|cups?|tbsp|tablespoons?|ml|pieces?)?\\s*(?:of\\s+)?(.*?)\\s*$/i.exec(raw); var a=m[1]; var amt=a==null?1:({a:1,an:1,one:1,two:2,half:0.5}[a.toLowerCase()]||Number(a)); var u=m[2]?(UN[m[2].toLowerCase()]):null; if(u===1) u='g'; return {raw:raw,amount:amt,unit:u,food:m[3]}; }
  function parse(text){ var items=String(text).split(/,|;|\\n| and /).map(function(x){return x.trim();}).filter(Boolean).map(parseOne); return {ok:true,items:items}; }
  function cands(d,food){ var f=food.toLowerCase().replace(/s$/,''); if(!f) return []; return d.foods.filter(function(r){ return r[2].toLowerCase().indexOf(f)>=0 || (f==='olive oil'&&r[0]===900004); }).map(function(r){ return {fdcId:r[0],dataset:r[1],description:r[2],score:1}; }); }
  function build(p,d,o){ o=o||{}; var c=cands(d,p.food); var it={raw:p.raw,food:p.food,amount:o.amount!=null?o.amount:p.amount,unit:o.unit!==undefined?o.unit:p.unit,status:'no_match',candidates:c,chosen:null,portion:null,grams:null,nutrients:null,provenance:null,portions:[],message:'No food in the data matches this text.'};
    if(!c.length) return it;
    var pick=o.fdcId!=null?c.filter(function(x){return x.fdcId===o.fdcId&&(!o.dataset||x.dataset===o.dataset);})[0]:(c.length===1?c[0]:null);
    if(!pick){ it.status='ambiguous'; it.message='More than one food fits.'; return it; }
    var row=d.foods.filter(function(r){return r[0]===pick.fdcId;})[0]; it.chosen={fdcId:pick.fdcId,dataset:pick.dataset,description:pick.description};
    it.portions=row[7].map(function(q,i){return {index:i,amount:q[0],unit:q[1],label:q[0]+' '+q[1],grams:q[2]};});
    var g=null,portion=null;
    if(o.grams!=null){ g=o.grams; portion={amount:g,unit:'g',label:g+' g',grams:g,basis:'user_grams'}; }
    else if(o.portionIndex!=null){ var q=it.portions[o.portionIndex]; g=it.amount/q.amount*q.grams; portion={amount:q.amount,unit:q.unit,label:q.label,grams:q.grams,basis:'usda_portion'}; }
    else if(it.unit==='g'){ g=it.amount; portion={amount:g,unit:'g',label:g+' g',grams:g,basis:'mass'}; }
    else { var q2=it.portions.filter(function(x){return it.unit?x.unit===it.unit:true;})[0]; if(q2){ g=it.amount/q2.amount*q2.grams; portion={amount:q2.amount,unit:q2.unit,label:q2.label,grams:q2.grams,basis:'usda_portion'}; } }
    if(g==null){ it.status='no_portion'; it.message='No household measure for this unit.'; return it; }
    it.grams=Math.round(g*10)/10; it.portion=portion; it.status='matched'; it.message='';
    function n(v){ return Math.round(v*g/100*10)/10; }
    it.nutrients={kcal:Math.round(row[3]*g/100),proteinG:n(row[4]),carbsG:n(row[5]),fatG:n(row[6])};
    it.provenance={source:'USDA_FDC',dataset:pick.dataset,fdcId:pick.fdcId,description:pick.description,portion:portion.label,grams:it.grams,dbVersion:d.meta.dbVersion};
    return it; }
  function noDb(){ return {ok:false,code:'db_not_loaded',message:'The food data is not loaded.',items:[]}; }
  function estimate(text,d){ d=db(d); if(!d) return noDb(); var items=parse(text).items.map(function(p){return build(p,d);}); return {ok:true,dbVersion:d.meta.dbVersion,items:items,totals:null}; }
  function estimateItem(raw,d,o){ d=db(d); if(!d) return noDb(); return build(parseOne(raw),d,o); }
  function toComponents(r){ var out={components:[],unmatched:[]}; if(!r||!r.ok) return out; r.items.forEach(function(it){ if(it.status!=='matched'){ out.unmatched.push({raw:it.raw,status:it.status,message:it.message}); return; }
    out.components.push({name:it.chosen.description.slice(0,80),role:'OTHER',portion:(it.portion.label+' ('+it.grams+' g)').slice(0,80),preparation:'',eatenFraction:null,
      kcal:{value:it.nutrients.kcal,state:'ESTIMATED'},proteinG:{value:it.nutrients.proteinG,state:'ESTIMATED'},carbsG:{value:it.nutrients.carbsG,state:'ESTIMATED'},fatG:{value:it.nutrients.fatG,state:'ESTIMATED'},provenance:it.provenance}); }); return out; }
  window.HyroxFoodCalc={parse:parse,estimate:estimate,estimateItem:estimateItem,toComponents:toComponents,loadDb:function(x){return {ok:true,db:x};}};
})();`;

// db: 'ok' (default) | 'missing' (food-db.js request fails, like a lost file)
async function installFoodShim(page, { db = 'ok', force = false } = {}) {
  const usingShim = { calc: force || FORCE || !REAL_CALC }; usingShim.db = usingShim.calc || !REAL_DB; // shim calc needs the shim fixture db
  if (usingShim.calc) await page.route('**/src/data/hyrox-foodcalc.js', (r) => r.fulfill({ status: 200, contentType: 'application/javascript', body: CALC_SRC }));
  if (db === 'missing') await page.route('**/src/data/food-db.js', (r) => r.abort('failed'));
  else if (usingShim.db) await page.route('**/src/data/food-db.js', (r) => r.fulfill({ status: 200, contentType: 'application/javascript', body: 'window.HyroxFoodDb=' + JSON.stringify(DB) + ';' }));
}
module.exports = { installFoodShim, REAL };
