'use strict';
// P7: backup restore of meal component provenance through the real UI.
// Installed Chrome, 390x844 phone emulation. NOT WebKit, NOT iPhone Safari. Synthetic data only. No network, no AI.
const { test, expect } = require('@playwright/test');

const T = '2026-11-10T06:00:00.000Z';
const NOW = '2026-11-12T06:00:00.000Z';
const K = (v) => ({ value: v, state: 'KNOWN' }), E = (v) => ({ value: v, state: 'ESTIMATED' });
const prov = () => ({ source: 'USDA_FDC', dataset: 'SR', fdcId: 168878, description: 'Rice, white, long-grain, regular, enriched, cooked', portion: '150 g [mass]', grams: 150, dbVersion: 'usda-synthetic-test' });
const estMeal = (id, p) => ({ id, createdAt: T, date: '2026-11-11', time: '12:00', label: 'Synthetic estimate', source: 'DESCRIPTION', lifecycle: 'CONFIRMED', confirmedAt: T,
  components: [{ name: 'Rice', role: 'OTHER', portion: '150 g', preparation: '', eatenFraction: null, kcal: E(195), proteinG: E(4), carbsG: E(42), fatG: E(0.4), provenance: p }] });
const plainMeal = (id) => ({ id, createdAt: T, date: '2026-11-11', time: '08:00', label: 'Ordinary', source: 'MANUAL', lifecycle: 'CONFIRMED', confirmedAt: T,
  components: [{ name: 'Toast', role: 'OTHER', portion: '2', preparation: '', eatenFraction: null, kcal: K(160), proteinG: K(6), carbsG: K(30), fatG: K(2) }] });
const backup = (meals) => ({ app: 'hyrox-app', version: 2, exportedAt: T, weight: [], workouts: [], nutrition: [], meals });
const device = (meals) => ({ version: 2, weight: [{ id: 'w-keep', createdAt: T, date: '2026-11-10', kg: 81.5 }], workouts: [], nutrition: [], meals: meals || [] });

async function boot(page, data) {
  await page.clock.setFixedTime(new Date(NOW));
  await page.goto('./');
  await page.evaluate((d) => { localStorage.clear(); if (d) localStorage.setItem('hyrox.v1', JSON.stringify(d)); }, data || null);
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
  await page.getByTestId('tab-settings').click();
}
const choose = (page, obj) => page.getByTestId('import-file').setInputFiles({ name: 'hyrox-backup.json', mimeType: 'application/json', buffer: Buffer.from(typeof obj === 'string' ? obj : JSON.stringify(obj), 'utf8') });
const snapshot = (page) => page.evaluate(() => JSON.stringify(Object.keys(localStorage).sort().map((k) => [k, localStorage.getItem(k)])));

for (const vp of [{ width: 390, height: 844 }, { width: 320, height: 568 }]) {
  test.describe(`P7 provenance restore ${vp.width}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: vp });

    test(`${vp.width}: a malformed provenance is refused with a readable located message and the stored data is byte-identical`, async ({ page }) => {
      await boot(page, device([plainMeal('m-keep')]));
      const before = await snapshot(page);
      const bad = Object.assign(prov(), { fdcId: 'not a number' });
      await choose(page, backup([estMeal('m-bad', bad)]));
      await expect(page.getByTestId('import-error')).toBeVisible();
      await expect(page.getByTestId('import-preview')).toBeHidden();
      await expect(page.getByTestId('import-detail-field').first()).toContainText('components[0].provenance.fdcId');
      await expect(page.getByTestId('import-detail-message').first()).toContainText('must be a whole number');
      await expect(page.getByTestId('import-detail-how').first()).toContainText('Nothing on this device was changed');
      expect(await snapshot(page)).toBe(before);
      await page.reload();
      expect(await snapshot(page)).toBe(before);
    });

    test(`${vp.width}: reserved key, oversize text and a non-object provenance are all refused; nothing changes`, async ({ page }) => {
      await boot(page, device());
      const before = await snapshot(page);
      const proto = JSON.stringify(backup([estMeal('m-p', prov())])).replace('"source":"USDA_FDC"', '"__proto__":{"x":1},"source":"USDA_FDC"');
      for (const [label, payload, msg] of [
        ['proto', proto, 'reserved name'],
        ['oversize', backup([estMeal('m-o', Object.assign(prov(), { description: 'd'.repeat(500) }))]), 'up to 200'],
        ['string', backup([estMeal('m-s', 'USDA')]), 'must be a record'],
        ['array', backup([estMeal('m-a', [1, 2])]), 'must be a record'],
      ]) {
        await choose(page, payload);
        await expect(page.getByTestId('import-error'), label).toBeVisible();
        await expect(page.getByTestId('import-detail-message').first(), label).toContainText(msg);
        expect(await snapshot(page), label).toBe(before);
      }
    });

    test(`${vp.width}: a valid estimated meal (with the USDA clamp marker) and an ordinary meal restore with provenance unchanged; second restore of an old backup without provenance works`, async ({ page }) => {
      await boot(page, null);
      const p = Object.assign(prov(), { carbsClampedToZero: true, note: 'USDA lists a slightly negative carbohydrate-by-difference for this food; it is counted as 0 g.' });
      await choose(page, backup([estMeal('m-est', p), plainMeal('m-plain')]));
      await expect(page.getByTestId('import-preview')).toBeVisible();
      await page.getByTestId('import-confirm').click();
      await expect(page.getByTestId('import-result')).toContainText(/restored/i);
      const got = await page.evaluate(() => JSON.parse(localStorage.getItem('hyrox.v1')).meals);
      expect(JSON.stringify(got.find((m) => m.id === 'm-est').components[0].provenance)).toBe(JSON.stringify(p));
      expect(got.find((m) => m.id === 'm-plain').components[0].provenance).toBeUndefined();
      // Export again from the device and restore that (round trip), onto a fresh device.
      const text = await page.evaluate(() => window.HyroxData.createStore().exportJSON());
      await page.evaluate(() => localStorage.clear()); await page.reload(); await page.getByTestId('tab-settings').click();
      await choose(page, text);
      await expect(page.getByTestId('import-preview')).toBeVisible();
      await page.getByTestId('import-confirm').click();
      await expect(page.getByTestId('import-result')).toContainText(/restored/i);
      const again = await page.evaluate(() => JSON.parse(localStorage.getItem('hyrox.v1')).meals);
      expect(JSON.stringify(again.find((m) => m.id === 'm-est').components)).toBe(JSON.stringify(got.find((m) => m.id === 'm-est').components));
      // An older backup that has no provenance at all.
      await page.evaluate(() => localStorage.clear()); await page.reload(); await page.getByTestId('tab-settings').click();
      await choose(page, backup([plainMeal('m-old')]));
      await expect(page.getByTestId('import-preview')).toBeVisible();
      await page.getByTestId('import-confirm').click();
      await expect(page.getByTestId('import-result')).toContainText(/restored/i);
    });
  });
}
