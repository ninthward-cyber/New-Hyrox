'use strict';
// Phase 8: Today keeps the explanations under "Why? Detailed guidance" and the 4-week calendar under "Full plan".
// Both are <details> folds, closed by default. These helpers open them (idempotent) before a test reads inside them.
async function openFold(page, fold, toggle) {
  const d = page.getByTestId(fold);
  await d.waitFor({ state: 'attached' });
  if (!(await d.evaluate((e) => e.open))) await page.getByTestId(toggle).click();
}
const openWhy = (page) => openFold(page, 'today-why', 'today-why-toggle');
const openFullPlan = (page) => openFold(page, 'today-fullplan', 'today-fullplan-toggle');
module.exports = { openWhy, openFullPlan };
