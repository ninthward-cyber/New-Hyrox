'use strict';
// P6 Meron: empty-storage banner and Settings diagnostic are read-only (no hyrox.v1 writes).
// Chrome emulation, not Safari/WebKit. Synthetic data only. 390 and 320.
const { test, expect } = require('@playwright/test');

const SHOTS = process.env.P6_SHOTS || '/workspace/hyrox-p6/results/screens';
const NOW = '2026-11-13T06:00:00.000Z';

const stored = (page) => page.evaluate(() => {
  const o = {};
  for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); o[k] = localStorage.getItem(k); }
  return o;
});
const noHScroll = async (page) => {
  const m = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
  expect(m.sw).toBeLessThanOrEqual(m.cw);
};

async function boot(page, { seed } = {}) {
  await page.clock.setFixedTime(new Date(NOW));
  await page.goto('./');
  await page.evaluate(() => localStorage.clear());
  if (seed) await page.evaluate(seed);
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
  await expect(page.getByTestId('load-guard')).toBeHidden();
}

const seedSome = () => {
  const st = window.HyroxData.createStore();
  st.addWeight({ date: '2026-11-12', kg: 80.2 });
  st.putRecord('walks', { date: '2026-11-12', durationMin: 20, steps: 2500 });
};

for (const W of [390, 320]) {
  test.describe(`${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`empty-storage banner ${W}: names host, tab mode, key absent, zero counts; viewing writes nothing`, async ({ page }) => {
      await boot(page);
      const banner = page.getByTestId('storage-context');
      await expect(banner).toBeVisible();
      await expect(page.getByTestId('storage-context-title')).toContainText('No saved data found in THIS browser context');
      const facts = await page.getByTestId('storage-fact').allInnerTexts();
      expect(facts[0]).toMatch(/^Web address: 127\.0\.0\.1:\d+$/);
      expect(facts[1]).toBe('Opened as: Browser tab (not a Home Screen app)');
      expect(facts[2]).toBe('Saved-data key (hyrox.v1) present: no');
      expect(facts[3]).toMatch(/^Records stored here: 0 in total/);
      await expect(page.getByTestId('storage-context-note')).toContainText('not proof that anything was deleted');
      await noHScroll(page);
      await page.screenshot({ path: `${SHOTS}/meron-${W}-storage-empty.png` });
      expect(await stored(page)).toEqual({});
    });

    test(`Settings diagnostic ${W}: read-only, reports key present and counts, writes nothing to hyrox.v1 (write spy)`, async ({ page }) => {
      await boot(page, { seed: seedSome });
      await expect(page.getByTestId('storage-context')).toBeHidden();
      const before = await stored(page);
      expect(before['hyrox.v1']).toBeTruthy();
      const writes = await page.evaluate(() => {
        window.__hyroxWrites = [];
        const set = localStorage.setItem.bind(localStorage);
        const rem = localStorage.removeItem.bind(localStorage);
        const clr = localStorage.clear.bind(localStorage);
        localStorage.setItem = function (k, v) { window.__hyroxWrites.push({ op: 'setItem', key: k, value: v }); return set(k, v); };
        localStorage.removeItem = function (k) { window.__hyroxWrites.push({ op: 'removeItem', key: k }); return rem(k); };
        localStorage.clear = function () { window.__hyroxWrites.push({ op: 'clear' }); return clr(); };
        return true;
      });
      expect(writes).toBe(true);
      await page.getByTestId('tab-settings').click();
      const summary = page.getByTestId('storage-diagnostic-summary');
      await expect(summary).toBeVisible();
      const sb = await summary.boundingBox();
      expect(sb.height).toBeGreaterThanOrEqual(44);
      await summary.click();
      const list = page.getByTestId('storage-diagnostic-list');
      await expect(list).toContainText('Saved-data key (hyrox.v1) present: yes');
      await expect(list).toContainText('weight 1');
      await expect(list).toContainText('walks 1');
      await noHScroll(page);
      await list.scrollIntoViewIfNeeded();
      await page.screenshot({ path: `${SHOTS}/meron-${W}-settings-diagnostic.png` });
      expect(await stored(page)).toEqual(before);
      // Closing and reopening the panel still writes nothing.
      await summary.click();
      await summary.click();
      expect(await stored(page)).toEqual(before);
      const spy = await page.evaluate(() => window.__hyroxWrites.slice());
      const v1 = spy.filter((w) => w.key === 'hyrox.v1' || w.op === 'clear');
      expect(v1, 'Settings diagnostic wrote hyrox.v1: ' + JSON.stringify(v1)).toEqual([]);
    });
  });
}
