'use strict';
// User journeys for the two repaired defects (P0-A, P0-B) and the five owner rules of 2026-11-18.
// Synthetic data only. The photo provider is the MOCK TEST provider: nothing leaves the browser.
// The clock is fixed to Thu 19 Nov 2026 09:00 Qatar so the plan week is deterministic.
const fs = require('fs');
const path = require('path');
const { test, expect } = require('@playwright/test');
// P0 (22 Nov 2026): the meal diary moved from Today to Add > Meal ("Log meal" on Today opens it). This brings it on screen
// the way the owner does; it does nothing when the diary or a dedicated logger is already showing.
async function diary(page) {
  if (await page.getByTestId('meal-diary').isVisible()) return;
  if (await page.getByTestId('logger-head').isVisible()) return;
  if (!(await page.getByTestId('panel-today').isVisible())) await page.getByTestId('tab-today').click();
  await page.getByTestId('today-add-meal').click();
  await page.getByTestId('meal-diary').waitFor();
}

// P0 (22 Nov 2026): "Meal name" is no longer a routine field; the optional custom name sits in a closed fold.
async function nameField(page) { const f = page.getByTestId('meal-label'); if (!(await f.isVisible())) await page.getByTestId('meal-name-toggle').click(); return f; }

const { openWhy, openFullPlan } = require('./p8-open');

const FIX = path.join(__dirname, '..', 'fixtures');
const NOW = '2026-11-19T06:00:00.000Z';
const T = '2026-11-17T06:00:00.000Z';
test.describe.configure({ mode: 'serial' });

async function boot(page, data) {
  await page.clock.setFixedTime(new Date(NOW));
  await page.goto('./');
  await page.evaluate((d) => {
    localStorage.clear();
    if (typeof d === 'string') localStorage.setItem('hyrox.v1', d);
    else if (d) localStorage.setItem('hyrox.v1', JSON.stringify(d));
  }, data === undefined ? null : data);
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
  // Phase 8: Today's detail sits under two closed folds; open them so the checks below still read the same elements.
  await openWhy(page); await openFullPlan(page);
}
const stored = (page) => page.evaluate(() => JSON.parse(localStorage.getItem('hyrox.v1')));
const base = (extra) => Object.assign({ version: 1, weight: [], workouts: [], nutrition: [] }, extra);
const steps = (date, n) => ({ id: 'daily-' + date, createdAt: T, date, steps: { state: 'OBSERVED', value: n } });
const WEIGHT = { id: 'w1', createdAt: T, date: '2026-11-17', kg: 80 };

test('P0-A: a malformed stored collection is flagged, and the first save keeps a byte-exact recovery copy', async ({ page }) => {
  const raw = '{"version":1,"weight":[],"workouts":[],"nutrition":[],"sessions":{"historic":"keep-me"}}';
  await boot(page, raw);
  await expect(page.getByTestId('storage-warning')).toContainText('damaged');
  await expect(page.getByTestId('storage-warning')).toContainText('sessions');
  expect(await page.evaluate(() => localStorage.getItem('hyrox.v1'))).toBe(raw);
  await page.getByTestId('tab-add').click();
  await page.getByTestId('add-mode-walk').click();
  await page.getByTestId('walk-duration').fill('30');
  await page.getByTestId('walk-submit').click();
  await expect(page.getByTestId('ext-toast')).toContainText('Saved');
  expect(await page.evaluate(() => localStorage.getItem('hyrox.v1.corrupt-backup'))).toBe(raw);
  await expect(page.getByTestId('storage-warning')).toContainText('hyrox.v1.corrupt-backup');
});

test('P0-B: a completed Thursday session stays visible and counted when the Monday cascade omits Thursday', async ({ page }) => {
  await boot(page, base({ version: 2,
    sessions: [{ id: 's1', createdAt: '2026-11-19T05:00:00.000Z', updatedAt: '2026-11-19T05:00:00.000Z', date: '2026-11-19', title: 'Aerobic HYROX', status: 'COMPLETED',
      modified: false, variant: 'ORIGINAL_60', planSlotId: 'v2.1-W1-THU', planVersion: 'v2.1', scheduledDate: '2026-11-19', blocks: [] }],
    planEvents: [{ id: 'e1', createdAt: '2026-11-19T05:30:00.000Z', updatedAt: '2026-11-19T05:30:00.000Z', date: '2026-11-16', kind: 'MISSED_MONDAY', week: 1 }] }));
  const today = page.getByTestId('today-card');
  await expect(today.getByTestId('today-omitted')).toContainText('omitted by source rule');
  const row = today.getByTestId('slot-v2.1-W1-THU');
  await expect(row.getByTestId('slot-status')).toHaveText('Completed');
  await expect(row.getByTestId('slot-omission')).toBeVisible();
  await expect(row.getByTestId('slot-conflict')).toContainText('kept and shown');
  await expect(page.getByTestId('today-alerts').getByTestId('cascade-conflict')).toContainText( // Phase 8: warnings sit in the prominent alerts block, not in the workout card
   'entered after this session was logged');
  await expect(page.getByTestId('plan-summary')).toContainText('1 completed');
  await expect(page.getByTestId('plan-summary')).toContainText('0 source-omitted');
  await expect(page.getByTestId('plan-summary')).toContainText('1 logged on a source-omitted slot');
  await page.getByTestId('tab-history').click();
  await expect(page.getByTestId('history-session')).toContainText('Completed');
});

test('rule 1: resting-HR baseline is 76 by default, flags a reading, and can be changed in Settings', async ({ page }) => {
  await boot(page);
  await expect(page.getByTestId('rhr-baseline')).toContainText('configured: 76 bpm (owner default');
  await expect(page.getByTestId('rhr-baseline')).toContainText('not available (0 of 4 readings needed; not estimated)');
  await expect(page.getByTestId('readiness-missing')).toContainText('resting HR');
  await page.getByTestId('today-checkin').click();
  await page.getByTestId('daily-rhr').fill('84');
  await page.getByTestId('daily-sleepH').fill('8');
  await page.getByTestId('daily-soreness').fill('1');
  await page.getByTestId('daily-submit').click();
  await page.getByTestId('tab-today').click();
  await expect(page.getByTestId('readiness-flag')).toContainText('configured baseline (76 bpm)');
  await page.getByTestId('tab-settings').click();
  await expect(page.getByTestId('set-rhr-baseline')).toHaveValue('76');
  await page.getByTestId('set-rhr-baseline').fill('');
  await page.getByTestId('set-save').click();
  await expect(page.getByTestId('owner-settings-error')).toContainText('Not saved');
  await page.getByTestId('set-rhr-baseline').fill('80');
  await page.getByTestId('set-save').click();
  await expect(page.getByTestId('ext-toast')).toContainText('Saved');
  await page.reload();
  await expect(page.getByTestId('rhr-baseline')).toContainText('configured: 80 bpm (set by you');
  await expect(page.getByTestId('readiness-flag')).toHaveCount(0);
  expect((await stored(page)).ownerSettings[0].rhrBaselineBpm).toBe(80);
});

test('rule 2: photo meal needs an eaten amount; presets, custom % and item override scale all macros; nothing counts before Confirm', async ({ page }) => {
  await boot(page);
  await page.getByTestId('tab-settings').click();
  await page.getByTestId('ai-provider-mock').check();
  await page.getByTestId('tab-add').click();
  await page.getByTestId('add-mode-meal').click();
  await page.getByTestId('meal-path-photo_ai').click();
  await page.getByTestId('photo-library-input').setInputFiles(path.join(FIX, 'synthetic-food-exif.jpg'));
  await page.getByTestId('photo-privacy-ack').click();
  await page.getByTestId('photo-send-consent').check();
  await page.getByTestId('photo-send').click();
  await expect(page.getByTestId('component-row')).toHaveCount(3);
  await (await nameField(page)).fill('Half plate');
  // not stated -> unknown, and Confirm is refused
  await expect(page.getByTestId('meal-total-kcal')).toContainText('unknown');
  await page.getByTestId('meal-confirm').click();
  await expect(page.getByTestId('meal-error')).toContainText('how much of the photographed meal');
  expect(await page.evaluate(() => localStorage.getItem('hyrox.v1'))).toBeNull();
  // presets
  for (const [pct, kcal] of [['25', '115'], ['75', '345'], ['100', '460'], ['50', '230']]) {
    await page.getByTestId('meal-eaten-' + pct).click();
    await expect(page.getByTestId('meal-total-kcal')).toContainText(kcal);
  }
  await expect(page.getByTestId('meal-total-proteinG')).toContainText('22.5');
  await expect(page.getByTestId('meal-total-carbsG')).toContainText('26.5');
  await expect(page.getByTestId('meal-total-fatG')).toContainText('3');
  // custom percentage
  await page.getByTestId('meal-eaten-custom').click();
  await page.getByTestId('meal-eaten-custom-pct').fill('10');
  await expect(page.getByTestId('meal-total-kcal')).toContainText('46');
  await page.getByTestId('meal-eaten-50').click();
  // item-level override: all of the rice, half of everything else
  await page.getByTestId('component-eaten').nth(1).fill('100');
  await expect(page.getByTestId('meal-total-kcal')).toContainText('350');
  // the AI estimate stays editable
  await page.getByTestId('component-kcal').nth(0).fill('200');
  await expect(page.getByTestId('meal-total-kcal')).toContainText('340');
  // saved for later: not counted
  await page.getByTestId('meal-consumed-intent').click();
  await page.getByTestId('tab-today').click();
  await expect(page.getByTestId('today-subtotal')).toContainText('Calories unknown'); // Phase 8 label (was 'kcal unknown')
  // explicit confirm: counted
  await page.getByTestId('tab-history').click();
  // layout regression: a photo meal awaiting confirmation must fit the phone width so its buttons are reachable
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  await page.getByTestId('meal-review').click();
  await page.getByTestId('meal-confirm').click();
  await page.getByTestId('tab-today').click();
  await expect(page.getByTestId('today-subtotal')).toContainText('Calories 340 kcal'); // Phase 8 label (was 'kcal 340')
  const meal = (await stored(page)).meals[0];
  expect(meal.eatenFraction).toBe(0.5);
  expect(meal.components.map((c) => c.eatenFraction)).toEqual([null, 1, null]);
  expect(meal.lifecycle).toBe('CONFIRMED');
});

test('rule 3: an empty day is asked about; only a confirmed fast is 0 kcal; fasts are tracked apart from eating days', async ({ page }) => {
  await boot(page, base({ weight: [WEIGHT] }));
  // yesterday (Wed 18 Nov) has no food recorded -> asked on Today, unknown until answered
  const q = page.getByTestId('today-fast-question');
  await expect(q).toContainText('Wed 18 Nov');
  await expect(q).toContainText('unknown (not 0)');
  expect((await stored(page)).dayStates).toBeUndefined();
  await q.getByTestId('fast-not-logged').click();
  await expect(page.getByTestId('today-fast-question')).toHaveCount(0);
  await page.getByTestId('tab-history').click();
  const days = page.getByTestId('history-day');
  const wed = days.filter({ hasText: 'Wed 18 Nov' });
  await expect(wed.getByTestId('history-day-state')).toContainText('D3');
  await expect(wed.getByTestId('history-day-kcal')).toContainText('unknown');
  await expect(wed.getByTestId('history-day-not-logged')).toBeVisible();
  // Tue 17 Nov is still unanswered: listed with the question, calories unknown
  const tue = days.filter({ hasText: 'Tue 17 Nov' });
  await expect(tue.getByTestId('history-day-kcal')).toContainText('unknown');
  await tue.getByTestId('attest-complete').click(); // cannot be declared complete without the answer
  await expect(page.getByTestId('ext-toast')).toContainText('fasting question');
  expect((await stored(page)).dayStates.length).toBe(1);
  await tue.getByTestId('fast-confirm').click();
  await expect(tue.getByTestId('history-day-state')).toContainText('Confirmed full-day fast');
  await expect(tue.getByTestId('history-day-kcal')).toContainText('0 kcal');
  await page.getByTestId('tab-trends').click();
  await expect(page.getByTestId('avg-eating')).toContainText('n=0');
  await expect(page.getByTestId('avg-eating')).toContainText('no complete eating days yet');
  await expect(page.getByTestId('avg-fasting')).toContainText(': 1');
  await expect(page.getByTestId('avg-fasting')).toContainText('Tue 17 Nov');
  await expect(page.getByTestId('avg-excluded')).toContainText('1 day(s) excluded');
  const ds = (await stored(page)).dayStates;
  expect(ds.find((d) => d.date === '2026-11-17').fast).toBe('CONFIRMED_FULL_DAY_FAST');
  expect(ds.find((d) => d.date === '2026-11-18').fast).toBe('NOT_LOGGED');
  // logging food on the fast day withdraws the fast
  await page.getByTestId('tab-add').click();
  await page.getByTestId('add-mode-meal').click();
  await page.getByTestId('meal-path-manual').click();
  await page.getByTestId('meal-date').fill('2026-11-17');
  await (await nameField(page)).fill('Late oats');
  await page.getByTestId('component-name').fill('Oats');
  await page.getByTestId('component-kcal').fill('350');
  await page.getByTestId('meal-confirm').click();
  await expect(page.getByTestId('meal-diary')).toBeVisible(); // P11.1: a confirmed Add > Meal save now returns to the Today diary
  await page.getByTestId('tab-history').click();
  const tue2 = page.getByTestId('history-day').filter({ hasText: 'Tue 17 Nov' });
  await expect(tue2.getByTestId('history-day-state')).not.toContainText('fast');
  await expect(tue2.getByTestId('history-day-stale')).toBeVisible();
});

test('rule 4: skipping Monday asks what to do; "adjust the week" applies the source cascade and keeps the plan', async ({ page }) => {
  await boot(page);
  await page.getByTestId('log-slot-v2.1-W1-MON').first().click();
  await page.getByTestId('session-status').selectOption('SKIPPED');
  await page.getByTestId('session-skip-confirm').check();
  await expect(page.getByTestId('skip-recommendation')).toContainText('approved source cascade');
  await page.getByTestId('session-save').click();
  await expect(page.getByTestId('session-error')).toContainText('choose what should happen');
  expect(await page.evaluate(() => localStorage.getItem('hyrox.v1'))).toBeNull();
  await page.getByTestId('skip-adjust_week').check();
  await page.getByTestId('session-save').click();
  await expect(page.getByTestId('ext-toast')).toContainText('Saved');
  const raw = await stored(page);
  expect(raw.sessions[0].skipDecision).toBe('ADJUST_WEEK');
  expect(raw.sessions[0].planSlotId).toBe('v2.1-W1-MON');
  expect(raw.sessions[0].scheduledDate).toBe('2026-11-16');
  expect(raw.planEvents.map((e) => e.kind)).toEqual(['MISSED_MONDAY']);
  await page.getByTestId('tab-today').click();
  // Thursday (today): Tuesday's intervals moved here, aerobic omitted by source rule - not skipped
  await expect(page.getByTestId('today-card').getByTestId('today-omitted')).toContainText('MISSED_MONDAY_CASCADE');
  await expect(page.getByTestId('today-card')).toContainText('moved from TUE');
  await expect(page.getByTestId('plan-summary')).toContainText('1 skipped, 1 source-omitted');
  await expect(page.getByTestId('plan-calendar').getByTestId('slot-skip-decision')).toContainText('adjust the rest of the week');
});

test('rule 4: skipping Tuesday does not offer Saturday or Sunday as a make-up (weekdays only; no automatic weekend gym make-up)', async ({ page }) => {
  // Owner decision 2 / v2.1: do NOT automatically offer Sat/Sun as a make-up for any missed Mon–Fri gym session.
  // Optional light Saturday activity (from W2) and Sunday mobility stay available and are not gym make-ups.
  await boot(page);
  await expect(page.getByTestId('plan-summary')).toContainText('20 planned weekday sessions');
  const w1opts = page.getByTestId('calendar-weekend-option');
  await expect(w1opts).toHaveCount(2);
  await expect(w1opts.filter({ hasText: 'Sat 21 Nov' })).toContainText('not a gym make-up');
  await expect(w1opts.filter({ hasText: 'Sat 21 Nov' })).toContainText('no optional Saturday session this week');
  await expect(w1opts.filter({ hasText: 'Sun 22 Nov' })).toContainText('Optional 15–20 min mobility');
  await expect(w1opts.filter({ hasText: 'Sun 22 Nov' })).toContainText('Not a make-up');

  await page.getByTestId('tab-add').click();
  await page.getByTestId('add-mode-workout').click();
  await page.getByTestId('session-slot').selectOption('v2.1-W1-TUE');
  await page.getByTestId('session-status').selectOption('SKIPPED');
  await page.getByTestId('session-skip-confirm').check();
  await expect(page.getByTestId('skip-recommendation')).toContainText('leave it skipped');
  await expect(page.getByTestId('skip-adjust_week')).toBeDisabled();
  await expect(page.getByTestId('skip-adjust_week-note')).toContainText('only for a missed Monday or Wednesday');
  // With every weekday already holding a planned session, Reschedule is not offered (and weekends are never listed).
  await expect(page.getByTestId('skip-reschedule')).toBeDisabled();
  await expect(page.getByTestId('skip-reschedule-note')).toContainText('weekends are not gym make-up');
  await expect(page.getByTestId('skip-reschedule-date')).toHaveCount(0);
  await page.getByTestId('skip-skip_permanent').check();
  await page.getByTestId('session-save').click();
  await expect(page.getByTestId('ext-toast')).toContainText('Saved');
  const s = (await stored(page)).sessions[0];
  expect(s.status).toBe('SKIPPED'); expect(s.skipDecision).toBe('SKIP_PERMANENT');
  expect(s.rescheduledTo == null || s.rescheduledTo === undefined).toBe(true);
  expect(s.planSlotId).toBe('v2.1-W1-TUE'); expect(s.scheduledDate).toBe('2026-11-17');
  expect((await stored(page)).planEvents).toBeUndefined();
  await page.getByTestId('tab-today').click();
  const cal = page.getByTestId('plan-calendar');
  await expect(cal.getByTestId('slot-skip-decision').first()).toContainText('skipped this permanently');
  await expect(cal.getByTestId('slot-v2.1-W1-TUE').getByTestId('slot-status')).toHaveText('Skipped (confirmed)');
});

test('rule 4: an unplanned skip still only needs confirmation, and "skip permanently" works for a planned one', async ({ page }) => {
  await boot(page);
  await page.getByTestId('tab-add').click();
  await page.getByTestId('add-mode-workout').click();
  await page.getByTestId('session-slot').selectOption('v2.1-W1-WED');
  await page.getByTestId('session-status').selectOption('SKIPPED');
  await page.getByTestId('session-skip-confirm').check();
  await page.getByTestId('skip-skip_permanent').check();
  await page.getByTestId('session-save').click();
  await expect(page.getByTestId('history-session').first()).toContainText('Skipped (confirmed)');
  const raw = await stored(page);
  expect(raw.sessions[0].skipDecision).toBe('SKIP_PERMANENT');
  expect(raw.planEvents).toBeUndefined();
});

test('rule 5: adaptive step target from recent history, per-day override, manual baseline, weekly trend; no double counting', async ({ page }) => {
  const days = ['2026-11-13', '2026-11-14', '2026-11-15', '2026-11-16', '2026-11-17'];
  const vals = [8000, 9000, 7000, 8000, 10000];
  await boot(page, base({ version: 2, daily: days.map((d, i) => steps(d, vals[i])) }));
  await expect(page.getByTestId('today-steps')).toContainText('not recorded');
  // Thu 19 Nov has a planned session -> baseline target; median of the 5 recorded days = 8,000
  await expect(page.getByTestId('today-step-target')).toContainText('Step target today: 8,000');
  await expect(page.getByTestId('today-step-target')).toContainText('median of 5 recorded days');
  await expect(page.getByTestId('today-step-target')).toContainText('Progress unknown');
  await expect(page.getByTestId('step-recovery-unknown')).toContainText('soreness');
  // walk steps count when no daily total exists (lower bound)...
  await page.getByTestId('tab-add').click();
  await page.getByTestId('add-mode-walk').click();
  await page.getByTestId('walk-duration').fill('30');
  await page.getByTestId('walk-steps').fill('3000');
  await page.getByTestId('walk-submit').click();
  await page.getByTestId('tab-today').click();
  await expect(page.getByTestId('today-steps')).toContainText('3,000');
  await expect(page.getByTestId('today-steps')).toContainText('lower bound');
  // ...and are not added on top once the daily total is recorded; high soreness lowers the target 30%
  await page.getByTestId('today-checkin').click();
  await page.getByTestId('daily-steps').fill('7000');
  await page.getByTestId('daily-soreness').fill('7');
  await page.getByTestId('daily-submit').click();
  await page.getByTestId('tab-today').click();
  await expect(page.getByTestId('today-steps')).toContainText('7,000');
  await expect(page.getByTestId('today-steps')).not.toContainText('10,000');
  await expect(page.getByTestId('today-step-target')).toContainText('Step target today: 5,600');
  await expect(page.getByTestId('today-step-target')).toContainText('Recovery first');
  await expect(page.getByTestId('today-step-target')).toContainText('Reached');
  // owner override and clear
  await page.getByTestId('step-override').fill('12000');
  await page.getByTestId('step-override-save').click();
  await expect(page.getByTestId('today-step-target')).toContainText('12,000 (your override; adaptive suggestion was 5,600)');
  await expect(page.getByTestId('today-step-target')).toContainText('Not reached yet');
  expect((await stored(page)).daily.find((d) => d.date === '2026-11-19').stepTargetOverride).toBe(12000);
  await page.getByTestId('step-override-clear').click();
  await expect(page.getByTestId('today-step-target')).toContainText('Step target today: 5,600');
  // manual baseline
  await page.getByTestId('tab-settings').click();
  await expect(page.getByTestId('set-step-auto')).toContainText('8,000 steps');
  await page.getByTestId('set-step-mode').selectOption('MANUAL');
  await page.getByTestId('set-step-manual').fill('6000');
  await page.getByTestId('set-save').click();
  await page.getByTestId('tab-today').click();
  await expect(page.getByTestId('today-step-target')).toContainText('Step target today: 4,200');
  await expect(page.getByTestId('today-step-target')).toContainText('set by you');
  // weekly trend: missing days are missing, not zero
  await page.getByTestId('tab-trends').click();
  await expect(page.getByTestId('steps-week')).toHaveCount(4);
  const thisWeek = page.getByTestId('steps-week').last();
  await expect(thisWeek).toContainText('Week of Mon 16 Nov');
  await expect(thisWeek).toContainText('3 recorded day(s)');
  await expect(thisWeek).toContainText('1 of 4 day(s) missing (not counted as 0)');
});

test('schema guard: once detailed records exist, storage and the exported backup are version 2 and hold no image', async ({ page }) => {
  await boot(page, base({ weight: [WEIGHT] }));
  expect((await stored(page)).version).toBe(1);
  await page.getByTestId('tab-add').click();
  await page.getByTestId('add-mode-walk').click();
  await page.getByTestId('walk-duration').fill('30');
  await page.getByTestId('walk-submit').click();
  await expect(page.getByTestId('ext-toast')).toContainText('Saved');
  expect((await stored(page)).version).toBe(2);
  await page.getByTestId('tab-settings').click();
  const [dl] = await Promise.all([page.waitForEvent('download'), page.getByTestId('export-btn').click()]);
  const text = fs.readFileSync(await dl.path(), 'utf8');
  const exp = JSON.parse(text);
  expect(exp.version).toBe(2); expect(exp.walks.length).toBe(1); expect(exp.weight.length).toBe(1);
  expect(/data:image|\/9j\//.test(text)).toBe(false);
});

test('photo AI: the real-model provider cannot be switched on by a stray tap, is labelled REAL, and sends nothing without Send', async ({ page }) => {
  await boot(page);
  const external = [];
  page.on('request', (r) => { const u = r.url(); if (/^https?:/.test(u) && !u.startsWith('http://127.0.0.1')) external.push(u); });
  const api = [];
  page.on('request', (r) => { if (/\/api\//.test(r.url())) api.push(r.url()); });
  await page.getByTestId('tab-settings').click();
  await expect(page.getByTestId('ai-provider-none')).toBeChecked();
  // the confirmation is dismissed (Playwright's default) -> stays off
  await page.getByTestId('ai-provider-http').click();
  await expect(page.getByTestId('ai-provider-none')).toBeChecked();
  expect(await page.evaluate(() => localStorage.getItem('hyrox.ai-settings'))).toBeNull();
  // explicit acceptance -> on, clearly labelled, still nothing sent
  page.once('dialog', (d) => { expect(d.message()).toContain('NOT approved'); d.accept(); });
  await page.getByTestId('ai-provider-http').click();
  await expect(page.getByTestId('ai-provider-http')).toBeChecked();
  await page.getByTestId('tab-add').click();
  await page.getByTestId('add-mode-meal').click();
  await page.getByTestId('meal-path-photo_ai').click();
  await page.getByTestId('photo-library-input').setInputFiles(path.join(FIX, 'synthetic-food-exif.jpg'));
  await page.getByTestId('photo-privacy-ack').click();
  await expect(page.getByTestId('photo-box')).toContainText('REAL model call');
  await expect(page.getByTestId('photo-box')).toContainText('not approved yet');
  await expect(page.getByTestId('photo-send')).toBeDisabled();
  expect(external).toEqual([]);
  expect(api).toEqual([]);
  const dump = await page.evaluate(() => Object.keys(localStorage).map((k) => k + '=' + localStorage.getItem(k)).join('\n'));
  expect(/data:image|\/9j\/|base64|api[_-]?key|sk-/i.test(dump)).toBe(false);
});
