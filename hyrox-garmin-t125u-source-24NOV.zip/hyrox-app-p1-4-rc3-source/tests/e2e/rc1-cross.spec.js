'use strict';
// RC1 cross-branch: P11.3 food (USDA US file, fiber/sodium, My foods/favourites) × Phase 12 planner (planBlocks) in ONE
// settings record. Every settings writer must keep the other branch's fields. Date simulated with the Playwright test clock
// only. Synthetic data. CHROME MOBILE EMULATION, NOT SAFARI/WEBKIT.
const { test, expect } = require('@playwright/test');
// P0 (22 Nov 2026): the meal diary moved from Today to Add > Meal ("Log meal" on Today opens it). This brings it on screen
// the way the owner does; it does nothing when the diary or a dedicated logger is already showing.
async function diary(page) {
  if (await page.getByTestId('meal-diary').isVisible()) return;
  if (await page.getByTestId('logger-head').isVisible()) return;
  if (!(await page.getByTestId('panel-today').isVisible())) await page.getByTestId('tab-today').click();
  await page.getByTestId('today-add-meal').click();
  await page.getByTestId('meal-diary').waitFor();
}

const K = (v) => ({ value: v, state: 'KNOWN' });
const T = '2026-12-11T05:00:00.000Z';
const item = (name, kcal, x) => Object.assign({ name, role: 'MAIN', portion: '', preparation: '', eatenFraction: null, kcal: K(kcal), proteinG: K(10), carbsG: K(10), fatG: K(5) }, x || {});
const meal = (id, comps, date) => ({ id, createdAt: T, updatedAt: T, date: date || '2026-12-11', time: '12:00', label: 'Lunch', source: 'MANUAL', description: '', eatenFraction: 1, lifecycle: 'CONFIRMED', confirmedAt: T, ai: null, mealCategory: 'LUNCH', components: comps });
const MF = { id: 'mf-x', name: 'Synthetic lentil soup', portion: '1 bowl', kcal: K(250), proteinG: K(14), carbsG: K(35), fatG: K(5), sodiumMg: K(640), fiberG: K(9), basis: 'your values', savedAt: T, fromMealId: null };
const stored = (page) => page.evaluate(() => JSON.parse(localStorage.getItem('hyrox.v1') || '{}'));
const setRec = async (page) => ((await stored(page)).ownerSettings || []).find((r) => r.id === 'app-settings');
async function openFold(page, fold, toggle) { const d = page.getByTestId(fold); await d.waitFor({ state: 'attached' }); if (!(await d.evaluate((e) => e.open))) await page.getByTestId(toggle).click(); }
const openPlanner = (page) => openFold(page, 'today-planner', 'today-planner-toggle');
async function ready(page) { await expect(page.getByTestId('app-error')).toBeHidden(); await expect(page.getByTestId('today-glance')).toBeVisible(); }
async function boot(page, now, data) {
  page.on('dialog', (d) => d.accept()); page._errs = []; page.on('pageerror', (e) => page._errs.push(e.message));
  await page.clock.setFixedTime(new Date(now));
  await page.goto('./'); await page.evaluate(() => localStorage.clear());
  if (data) await page.evaluate((d) => localStorage.setItem('hyrox.v1', JSON.stringify(d)), data);
  await page.reload(); await ready(page);
}
async function activate(page, start) {
  await openPlanner(page);
  if (start) await page.getByTestId('planner-start').selectOption(start);
  await page.getByTestId('planner-create').click();
  await page.getByTestId('planner-preview-toggle').click();
  await page.getByTestId('planner-approve').check();
  await page.getByTestId('planner-activate').click();
  await expect(page.getByTestId('planner-active')).toBeVisible();
}
const base = (extra) => Object.assign({ version: 2, weight: [], workouts: [], nutrition: [], meals: [meal('m1', [item('Synthetic soup', 200, { sodiumMg: K(900), fiberG: K(3) })])],
  ownerSettings: [{ id: 'app-settings', date: '2026-12-11', createdAt: T, rhrBaselineBpm: 70, myFoods: [MF], favFoods: ['my:mf-x'] }] }, extra || {});

for (const W of [390, 320]) {
  test.describe(`RC1 cross-branch ${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`${W}: active Block 2 survives every food writer (Save to My foods, favourite, unfavourite), a Settings save and a damaged-settings Replace; foods keep fiber/sodium`, async ({ page }) => {
      await boot(page, '2026-12-11T09:00:00+03:00', base());
      await activate(page);
      const PB = (await setRec(page)).planBlocks;
      expect(PB[0].state).toBe('ACTIVATED');
      await page.getByTestId('tab-history').click();
      await page.getByTestId('meal-save-myfoods').click(); await page.getByTestId('myfoods-pick-save').click();
      let r = await setRec(page); expect([r.planBlocks, r.myFoods.length, r.myFoods.find((f) => f.id === 'mf-x').fiberG, r.myFoods.find((f) => f.id !== 'mf-x').fiberG]).toEqual([PB, 2, K(9), K(3)]);
      await page.getByTestId('tab-today').click(); await diary(page); await page.getByTestId('diary-log-dinner').click(); await page.getByTestId('meal-add-foods').click();
      await page.getByTestId('foods-tab-my').click(); await page.getByTestId('food-pick').first().click(); await page.getByTestId('food-fav').click();
      r = await setRec(page); expect(r.planBlocks).toEqual(PB);
      await page.getByTestId('foods-done').click(); await page.getByTestId('meal-discard').click().catch(() => {});
      await page.getByTestId('tab-settings').click(); await page.getByTestId('set-rhr-baseline').fill('66'); await page.getByTestId('set-save').click();
      r = await setRec(page); expect([r.planBlocks, r.rhrBaselineBpm, r.myFoods.length]).toEqual([PB, 66, 2]);
      // damage an unrelated field, then Replace (approve correction)
      await page.evaluate(() => { const raw = JSON.parse(localStorage.getItem('hyrox.v1')); raw.ownerSettings[0].rhrBaselineBpm = 'bad'; localStorage.setItem('hyrox.v1', JSON.stringify(raw)); });
      await page.reload(); await ready(page);
      await expect(page.getByTestId('today-card')).toContainText('Week 4/4'); // 11 Dec: Block 1 still shown while settings need attention
      await page.getByTestId('tab-settings').click();
      await expect(page.getByTestId('owner-settings-damaged')).toBeVisible();
      await page.getByTestId('set-rhr-baseline').fill('67'); await page.getByTestId('set-approve-correction').check(); await page.getByTestId('set-save').click();
      await expect(page.getByTestId('owner-settings-damaged')).toHaveCount(0);
      r = await setRec(page);
      expect([r.planBlocks, r.rhrBaselineBpm, r.myFoods.map((f) => f.id).includes('mf-x'), r.myFoods.find((f) => f.id === 'mf-x').sodiumMg]).toEqual([PB, 67, true, K(640)]);
      expect(page._errs).toEqual([]);
    });

    test(`${W}: two tabs — a food saved in tab A makes tab B's open planner stale: activation refused, nothing lost; after reload B activates and A's food is kept`, async ({ context }) => {
      const a = await context.newPage(), b = await context.newPage();
      await boot(a, '2026-12-11T09:00:00+03:00', base());
      await openPlanner(a); await a.getByTestId('planner-create').click();
      await b.clock.setFixedTime(new Date('2026-12-11T09:00:10+03:00')); b.on('dialog', (d) => d.accept()); await b.goto('./'); await ready(b);
      await openPlanner(b); await b.getByTestId('planner-preview-toggle').click(); await b.getByTestId('planner-approve').check();
      // tab A: Save to My foods (writes the settings record)
      await a.getByTestId('tab-history').click(); await a.getByTestId('meal-save-myfoods').click(); await a.getByTestId('myfoods-pick-save').click();
      expect((await setRec(a)).myFoods.length).toBe(2);
      await b.getByTestId('planner-activate').click();
      await expect(b.getByTestId('ext-toast')).toContainText('Not saved');
      let r = await setRec(b); expect([r.planBlocks[0].state, r.myFoods.length]).toEqual(['DRAFT', 2]);
      await b.reload(); await ready(b);
      await openPlanner(b); await b.getByTestId('planner-preview-toggle').click(); await b.getByTestId('planner-approve').check(); await b.getByTestId('planner-activate').click();
      await expect(b.getByTestId('planner-active')).toBeVisible();
      r = await setRec(b); expect([r.planBlocks[0].state, r.myFoods.length, r.favFoods]).toEqual(['ACTIVATED', 2, ['my:mf-x']]);
      // reverse: tab A (stale screen, opened before activation) favourites a food — the fresh re-read keeps the activation
      await a.getByTestId('tab-today').click(); await diary(a); await a.getByTestId('diary-log-dinner').click(); await a.getByTestId('meal-add-foods').click();
      await a.getByTestId('foods-tab-my').click(); await a.getByTestId('food-pick').first().click(); await a.getByTestId('food-fav').click();
      r = await setRec(a); expect(r.planBlocks[0].state).toBe('ACTIVATED');
    });

    test(`${W}: Block 2 day diary: USDA US search item with fiber/sodium logged on Mon 14 Dec while Block 2 W1 shows; search makes no network request`, async ({ page }) => {
      await boot(page, '2026-12-11T09:00:00+03:00', base());
      await activate(page);
      await page.clock.setFixedTime(new Date('2026-12-14T19:00:00+03:00')); await page.reload(); await ready(page);
      await expect(page.getByTestId('today-card')).toContainText('Mon 14 Dec · Block 2 · Week 1/4');
      await diary(page); await page.getByTestId('diary-log-dinner').click(); await page.getByTestId('meal-add-foods').click();
      const reqs = []; page.on('request', (q) => { if (!/food-db/.test(q.url())) reqs.push(q.url()); });
      await page.getByTestId('foods-q').fill('4 boiled eggs');
      await expect(page.getByTestId('food-pick').first()).toContainText(/egg/i);
      await page.getByTestId('food-pick').first().click(); await page.getByTestId('food-add').click(); await page.getByTestId('foods-done').click();
      await page.getByTestId('meal-confirm').click();
      const s = await stored(page);
      const m = s.meals.find((x) => x.date === '2026-12-14');
      expect(m.components[0].sodiumMg.state).toBe('ESTIMATED'); expect(m.components[0].sodiumMg.value).toBeGreaterThan(0); // USDA values are estimates by design (P11.3)
      expect(reqs.filter((u) => !/^http:\/\/127\.0\.0\.1/.test(u))).toEqual([]);
      expect(reqs.filter((u) => /food-photo|api/.test(u))).toEqual([]);
      expect((await setRec(page)).planBlocks[0].state).toBe('ACTIVATED');
      await expect(page.getByTestId('diary-sodium')).toContainText('mg');
      expect(page._errs).toEqual([]);
    });
  });
}
