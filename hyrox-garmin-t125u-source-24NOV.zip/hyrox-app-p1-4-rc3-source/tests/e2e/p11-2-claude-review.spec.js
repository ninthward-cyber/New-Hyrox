'use strict';
// Claude independent review of Phase 11.2 (19 Nov 2026). FAILING-FIRST against the Grok 11.2 tree (ff08c21d…).
// CHROME MOBILE EMULATION, NOT SAFARI/WEBKIT. Synthetic data only; no network, no AI call.
//   C-01 (MEDIUM) a damaged settings record blocks saving foods ("…need attention first (Settings)") and Settings →
//        "Replace the saved settings" then rebuilt the record WITHOUT myFoods / favFoods: every saved food was lost.
//   C-02 (LOW) a saved food without macro objects (older/hand-edited backup) threw while drawing My foods / search.
//   C-03 (MEDIUM, UX) "2 eggs" found nothing.
//   C-04 (LOW) the "just saved" diary marker was never cleared (stayed after leaving Today / changing day).
//   C-05 (LOW) Trends: the new first-date label was drawn over the minimum-value label (bottom-left of every chart).
const { test, expect } = require('@playwright/test');
// P0 (22 Nov 2026): the meal diary moved from Today to Add > Meal ("Log meal" on Today opens it). This brings it on screen
// the way the owner does; it does nothing when the diary or a dedicated logger is already showing.
async function diary(page) {
  if (await page.getByTestId('meal-diary').isVisible()) return;
  if (await page.getByTestId('logger-head').isVisible()) return;
  if (!(await page.getByTestId('panel-today').isVisible())) await page.getByTestId('tab-today').click();
  await page.getByTestId('today-add-meal').click();
  await page.getByTestId('meal-diary').waitFor();
}

const NOW = '2026-11-19T09:00:00.000Z'; // 12:00 Asia/Qatar, Thu 19 Nov
const KEY = 'hyrox.v1';
const MYF = (id, name, kcal) => ({ id, name, portion: '1 bowl', kcal: { value: kcal, state: 'KNOWN' }, proteinG: { value: 30, state: 'KNOWN' }, carbsG: { value: 40, state: 'KNOWN' }, fatG: { value: 10, state: 'KNOWN' }, basis: 'your values', savedAt: '2026-11-18T10:00:00.000Z', fromMealId: null });

async function open(page, seed) {
  page._errs = []; page.on('pageerror', (e) => page._errs.push(e.message));
  await page.clock.setFixedTime(new Date(NOW));
  await page.goto('./');
  await page.evaluate(() => localStorage.clear());
  if (seed) await page.evaluate(([k, v]) => localStorage.setItem(k, JSON.stringify(v)), [KEY, seed]);
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
}
const stored = async (page) => JSON.parse((await page.evaluate((k) => localStorage.getItem(k), KEY)) || '{}');
const settingsRec = async (page) => ((await stored(page)).ownerSettings || []).filter((r) => r.id === 'app-settings')[0];
async function openFoods(page, cat = 'lunch') {
  await page.getByTestId('tab-today').click();
  await diary(page); await page.getByTestId('diary-log-' + cat).click();
  await page.getByTestId('meal-add-foods').click();
  await expect(page.getByTestId('foods-screen')).toBeVisible();
  await expect(page.getByTestId('foods-status')).not.toContainText('Loading');
}
function seedWith(settings) {
  return { version: 2, weight: [], workouts: [], nutrition: [], ownerSettings: [Object.assign({ id: 'app-settings', date: '2026-11-18', createdAt: '2026-11-18T10:00:00.000Z' }, settings)] };
}

for (const W of [390, 320]) {
  test.describe(`P11.2 Claude review ${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`${W}: C-01 replacing a damaged settings record keeps My foods and favourites (it used to delete them)`, async ({ page }) => {
      const mf = [MYF('mf-1', 'Mum\'s machboos', 650), MYF('mf-2', 'Karak tea', 120)];
      await open(page, seedWith({ rhrBaselineBpm: 999, myFoods: mf, favFoods: ['my:mf-1', 'SR:173944'] }));
      await page.getByTestId('tab-settings').click();
      await expect(page.getByTestId('owner-settings-damaged')).toBeVisible();
      await expect(page.getByTestId('owner-settings-damaged')).toContainText('2 saved foods and 2 favourites are kept');
      await page.getByTestId('set-approve-correction').check();
      await page.getByTestId('set-save').click();
      await expect(page.getByTestId('owner-settings-damaged')).toHaveCount(0);
      const rec = await settingsRec(page);
      expect(rec.rhrBaselineBpm).toBe(76);
      expect(rec.myFoods.map((f) => f.name)).toEqual(['Mum\'s machboos', 'Karak tea']);
      expect(rec.favFoods).toEqual(['my:mf-1', 'SR:173944']);
      await openFoods(page);
      await page.getByTestId('foods-tab-my').click();
      await expect(page.getByTestId('food-result')).toHaveCount(2);
      expect(page._errs).toEqual([]);
    });

    test(`${W}: C-01 a healthy settings save still keeps My foods (unchanged behaviour)`, async ({ page }) => {
      await open(page, seedWith({ rhrBaselineBpm: 70, myFoods: [MYF('mf-1', 'Oats bowl', 300)], favFoods: ['my:mf-1'] }));
      await page.getByTestId('tab-settings').click();
      await page.getByTestId('set-save').click();
      const rec = await settingsRec(page);
      expect(rec.myFoods.length).toBe(1); expect(rec.favFoods).toEqual(['my:mf-1']);
    });

    test(`${W}: C-02 a saved food without macro values (older/hand-edited backup) shows "kcal unknown" and nothing breaks`, async ({ page }) => {
      await open(page, seedWith({ myFoods: [{ id: 'mf-x', name: 'Bare saved food' }, MYF('mf-2', 'Oats bowl', 300)] }));
      await openFoods(page);
      await page.getByTestId('foods-tab-my').click();
      await expect(page.getByTestId('food-result')).toHaveCount(2);
      await expect(page.getByTestId('food-result').filter({ hasText: 'Bare saved food' })).toContainText('kcal unknown');
      await page.getByTestId('foods-tab-search').click();
      await page.getByTestId('foods-q').fill('bare');
      await expect(page.getByTestId('food-result').first()).toContainText('Bare saved food');
      await page.getByTestId('food-result').first().getByTestId('food-pick').click();
      await page.getByTestId('food-add').click();
      await page.getByTestId('foods-done').click();
      await expect(page.getByTestId('meal-total-kcal')).toContainText('unknown'); // never 0
      expect(page._errs).toEqual([]);
    });

    test(`${W}: C-03 typing a count ("2 eggs") finds eggs and does NOT set the quantity for you`, async ({ page }) => {
      await open(page);
      await openFoods(page);
      await page.getByTestId('foods-q').fill('2 eggs');
      await expect(page.getByTestId('food-result').first()).toContainText(/Egg/);
      await page.getByTestId('food-result').first().getByTestId('food-pick').click();
      await expect(page.getByTestId('food-qty')).toHaveValue('1');
      await page.getByTestId('foods-q').fill('4 boiled eggs');
      await expect(page.getByTestId('food-result').filter({ hasText: 'hard-boiled' }).first()).toBeVisible();
    });

    test(`${W}: C-04 the "just saved" marker shows once, then clears after leaving Today or changing day`, async ({ page }) => {
      await open(page);
      await page.getByTestId('tab-add').click();
      await page.getByTestId('add-mode-meal').click();
      await page.getByTestId('meal-path-manual').click();
      await page.getByTestId('component-name').first().fill('Test toast');
      await page.getByTestId('component-kcal').first().fill('200');
      await page.getByTestId('meal-eaten-100').click();
      await page.getByTestId('meal-confirm').click();
      await expect(page.getByTestId('meal-diary')).toBeVisible();
      await expect(page.locator('[data-just-saved="true"]')).toHaveCount(1);
      await page.getByTestId('tab-history').click();
      await page.getByTestId('tab-today').click();
      const tg = page.getByTestId('diary-toggle-uncat');
      if ((await tg.getAttribute('aria-expanded')) !== 'true') await tg.click();
      const entry = page.getByTestId('meal-diary').getByTestId('diary-entry').filter({ hasText: 'Test toast' });
      await expect(entry).toHaveCount(1); // the meal is on screen ...
      await expect(page.locator('[data-just-saved="true"]')).toHaveCount(0); // ... but no longer marked as "just saved"
      // changing day and coming back also leaves it unmarked
      await diary(page); await page.getByTestId('diary-prev').click();
      await diary(page); await page.getByTestId('diary-next').click();
      if ((await tg.getAttribute('aria-expanded')) !== 'true') await tg.click();
      await expect(entry).toHaveCount(1);
      await expect(page.locator('[data-just-saved="true"]')).toHaveCount(0);
    });

    test(`${W}: C-05 chart date labels do not overlap the value labels`, async ({ page }) => {
      const w = [['2026-10-20', 106.0], ['2026-11-02', 105.2], ['2026-11-16', 103.9], ['2026-11-19', 103.4]].map(([date, kg], i) => ({ id: 'w' + i, date, kg, createdAt: '2026-11-19T08:00:00.000Z' }));
      await open(page, { version: 1, weight: w, workouts: [], nutrition: [] });
      await page.getByTestId('tab-trends').click();
      const svg = page.getByTestId('chart-weight');
      await expect(svg.locator('text.chart-date')).toHaveCount(2);
      const boxes = await svg.evaluate((el) => [...el.querySelectorAll('text')].map((t) => { const b = t.getBBox(); return { cls: t.getAttribute('class'), x: b.x, y: b.y, w: b.width, h: b.height, txt: t.textContent }; }));
      const dates = boxes.filter((b) => /chart-date/.test(b.cls)), values = boxes.filter((b) => !/chart-date/.test(b.cls));
      const hit = (a, b) => a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h;
      for (const d of dates) for (const v of values) expect(hit(d, v), d.txt + ' overlaps ' + v.txt).toBe(false);
    });
  });
}
