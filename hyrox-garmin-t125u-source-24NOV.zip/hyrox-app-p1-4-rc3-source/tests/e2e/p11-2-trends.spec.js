'use strict';
// Phase 11.2 part 3 (11.1 P1): Trends presentation — time window, latest-value summary with real dates and like-for-like
// comparisons, real date labels on charts. Same computations; only recorded observations; missing stays missing.
// Synthetic data. CHROME MOBILE EMULATION, NOT SAFARI/WEBKIT.
const { test, expect } = require('@playwright/test');
const NOW = '2026-11-19T09:00:00.000Z';
const T = '2026-11-19T05:00:00.000Z';
const base = (extra) => Object.assign({ version: 2, weight: [], workouts: [], nutrition: [] }, extra);
async function boot(page, data) {
  page._errs = []; page.on('pageerror', (e) => page._errs.push(e.message));
  await page.clock.setFixedTime(new Date(NOW));
  await page.goto('./');
  await page.evaluate((d) => { localStorage.clear(); if (d) localStorage.setItem('hyrox.v1', JSON.stringify(d)); }, data || null);
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
  await page.getByTestId('tab-trends').click();
}
const noErrors = (page) => expect(page._errs).toEqual([]);
const W8 = [['2026-09-01', 82], ['2026-10-30', 81], ['2026-11-12', 80.2], ['2026-11-18', 79.6]].map((x, i) => ({ id: 'w' + i, createdAt: T, date: x[0], kg: x[1] }));
const steps = (date, n) => ({ id: 'daily-' + date, createdAt: T, date, steps: { state: 'OBSERVED', value: n } });

for (const W of [390, 320]) {
  test.describe(`P11.2 trends ${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`${W}: empty data — every summary line says nothing recorded; no point is drawn or assumed`, async ({ page }) => {
      await boot(page);
      await expect(page.getByTestId('trends-sum-weight')).toContainText('No weight recorded in this window');
      await expect(page.getByTestId('trends-sum-steps')).toContainText('No daily totals recorded this week');
      await expect(page.getByTestId('trends-sum-workouts')).toContainText('No sessions logged');
      await expect(page.getByTestId('trends-sum-nutrition')).toContainText('No complete, quantified eating day');
      await expect(page.getByTestId('chart-weight')).toHaveText('No observations yet — nothing is assumed.');
      await expect(page.locator('svg.chart')).toHaveCount(0);
      noErrors(page);
    });

    test(`${W}: weight — latest value with its date, change vs the first measurement in the window; the window changes only what is shown`, async ({ page }) => {
      await boot(page, base({ weight: W8, daily: [steps('2026-11-16', 6000), steps('2026-11-18', 8000)],
        sessions: [{ id: 's1', createdAt: T, updatedAt: T, date: '2026-11-17', title: 'Strength', status: 'COMPLETED', modified: false, variant: 'ORIGINAL_60', blocks: [] },
          { id: 's2', createdAt: T, updatedAt: T, date: '2026-09-02', title: 'Old', status: 'PARTIAL', modified: false, variant: 'ORIGINAL_60', blocks: [] }] }));
      const before = await page.evaluate(() => localStorage.getItem('hyrox.v1'));
      await expect(page.getByTestId('trends-win-all')).toHaveAttribute('aria-pressed', 'true');
      await expect(page.getByTestId('trends-sum-weight')).toContainText('79.6 kg on Wed 18 Nov · -2.4 kg since Tue 1 Sept (4 measurements)');
      await expect(page.getByTestId('trends-sum-steps')).toContainText('Average 7,000 over 2 recorded day(s); 2 missing (not 0)');
      await expect(page.getByTestId('trends-sum-workouts')).toContainText('1 completed · 1 partial · 0 skipped');
      await expect(page.getByTestId('chart-weight').locator('circle')).toHaveCount(4);
      await expect(page.getByTestId('chart-weight').locator('text.chart-date')).toHaveText(['Tue 1 Sept', 'Wed 18 Nov']);
      await page.getByTestId('trends-win-4w').click();
      await expect(page.getByTestId('trends-win-4w')).toBeFocused();
      await expect(page.getByTestId('trends-window')).toContainText('Showing Fri 23 Oct – Thu 19 Nov');
      await expect(page.getByTestId('trends-sum-weight')).toContainText('79.6 kg on Wed 18 Nov · -1.4 kg since Fri 30 Oct (3 measurements)');
      await expect(page.getByTestId('trends-sum-workouts')).toContainText('1 completed · 0 partial · 0 skipped');
      await expect(page.getByTestId('chart-weight').locator('circle')).toHaveCount(3);
      expect(await page.evaluate(() => localStorage.getItem('hyrox.v1'))).toBe(before); // viewing never writes
      for (const k of ['4w', '12w', 'all']) { const b = await page.getByTestId('trends-win-' + k).boundingBox(); expect(b.height).toBeGreaterThanOrEqual(44); }
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
      noErrors(page);
    });

    test(`${W}: a single measurement is shown with no comparison; existing qualified nutrition/plan text is unchanged`, async ({ page }) => {
      await boot(page, base({ weight: [W8[3]] }));
      await expect(page.getByTestId('trends-sum-weight')).toContainText('79.6 kg on Wed 18 Nov · only 1 measurement, no comparison');
      await expect(page.getByTestId('chart-weight')).toContainText('Only 1 observation');
      await expect(page.getByTestId('avg-eating')).toContainText('no complete eating days yet');
      await expect(page.getByTestId('trends-plan-summary')).toContainText('Plan v2.1');
      await expect(page.getByTestId('trends-page')).toHaveCount(0);
      noErrors(page);
    });
  });
}
