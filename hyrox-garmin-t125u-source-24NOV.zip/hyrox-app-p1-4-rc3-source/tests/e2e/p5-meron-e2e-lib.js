'use strict';
// Shared helpers for Meron P5 adversarial e2e. Chrome emulation, not Safari/WebKit.
// Synthetic data only. Does not load Liya's contract shim — the integration build
// already has Dawit's P5 data layer; these tests talk to the real store.
const path = require('path');
const fs = require('fs');
if (fs.existsSync('/workspace/hyrox-p2/tools/node_modules/@playwright/test')) {
  module.paths.unshift('/workspace/hyrox-p2/tools/node_modules');
}
const { expect } = require('@playwright/test');

const KEY = 'hyrox.v1';
const PRE = 'hyrox.v1.pre-import-backup';
const T = '2026-11-10T06:00:00.000Z';
const EMPTY = JSON.stringify({ app: 'hyrox-app', version: 2, exportedAt: T, weight: [], workouts: [], nutrition: [] });
const ONE = JSON.stringify({
  app: 'hyrox-app', version: 2, exportedAt: T,
  weight: [{ id: 'w-syn-1', createdAt: T, date: '2026-11-10', kg: 79.5 }],
  workouts: [], nutrition: [],
});
const SHOTS = process.env.P5_SHOTS || path.join(__dirname, '..', 'out', 'screens'); // Claude P5: was /workspace/hyrox-p5/results/screens

function snapshotObj(page) {
  return page.evaluate(() => {
    const o = {};
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      o[k] = localStorage.getItem(k);
    }
    return o;
  });
}
async function snapshot(page) {
  const o = await snapshotObj(page);
  return JSON.stringify(Object.keys(o).sort().map((k) => [k, o[k]]));
}

async function boot(page, opts = {}) {
  await page.goto('./');
  await page.evaluate((o) => {
    localStorage.clear();
    const st = window.HyroxData.createStore();
    if (o.seed === 'populated' || o.seed === 'duplicate' || o.seed === 'dateskew' || o.seed === 'invalidkg') {
      st.addWeight({ date: '2026-11-10', kg: 80.2 });
      st.addWeight({ date: '2026-11-11', kg: 80.0 });
      st.addNutrition({ date: '2026-11-11', label: 'Synthetic oats', calories: 350, proteinG: 20 });
      st.putRecord('walks', { date: '2026-11-11', durationMin: 30, steps: 4000, notes: 'synthetic' });
    }
    if (o.seed === 'duplicate') {
      const raw = JSON.parse(localStorage.getItem('hyrox.v1'));
      raw.weight.push(
        { id: 'w-syn-dup', createdAt: o.T, date: '2026-11-08', kg: 80.6 },
        { id: 'w-syn-dup', createdAt: o.T, date: '2026-11-07', kg: 80.8 }
      );
      localStorage.setItem('hyrox.v1', JSON.stringify(raw));
    }
    if (o.seed === 'dateskew') {
      const raw = JSON.parse(localStorage.getItem('hyrox.v1'));
      raw.weight.push({ id: 'w-future', createdAt: o.T, date: '2027-06-01', kg: 81 });
      localStorage.setItem('hyrox.v1', JSON.stringify(raw));
    }
    if (o.seed === 'invalidkg') {
      const raw = JSON.parse(localStorage.getItem('hyrox.v1'));
      raw.weight.push({ id: 'w-heavy', createdAt: o.T, date: '2026-11-09', kg: 999 });
      localStorage.setItem('hyrox.v1', JSON.stringify(raw));
    }
    if (o.pendingSlot) {
      localStorage.setItem('hyrox.v1.pre-import-backup', JSON.stringify({
        kind: 'hyrox-pre-import',
        savedAt: o.T,
        restoreState: 'pending',
        raw: JSON.stringify({ version: 1, weight: [{ id: 'w-old', createdAt: o.T, date: '2026-11-01', kg: 81 }], workouts: [], nutrition: [] }),
      }));
    }
  }, { seed: opts.seed || 'none', pendingSlot: !!opts.pendingSlot, T });
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
  await page.getByTestId('tab-settings').click();
}

async function pick(page, text, name = 'synthetic-backup.json') {
  await page.getByTestId('import-file').setInputFiles({ name, mimeType: 'application/json', buffer: Buffer.from(text) });
  await expect(page.getByTestId('import-preview')).toBeVisible();
}

async function noHScroll(page) {
  const m = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
  expect(m.sw, 'no horizontal scroll (Chrome emulation, not Safari/WebKit)').toBeLessThanOrEqual(m.cw);
}

async function minTarget(loc, label) {
  const b = await loc.boundingBox();
  expect(b, label + ' visible').not.toBeNull();
  expect(b.height, label + ' height >= 44').toBeGreaterThanOrEqual(44);
  expect(b.width, label + ' width >= 44').toBeGreaterThanOrEqual(44);
}

async function notClipped(page, testId) {
  const info = await page.getByTestId(testId).evaluate((el) => {
    const r = el.getBoundingClientRect();
    const cs = getComputedStyle(el);
    return {
      id: el.getAttribute('data-testid'),
      text: (el.innerText || '').slice(0, 240),
      sw: el.scrollWidth, cw: el.clientWidth,
      sh: el.scrollHeight, ch: el.clientHeight,
      overflow: cs.overflow + '/' + cs.overflowX + '/' + cs.overflowY,
      hidden: cs.visibility === 'hidden' || cs.display === 'none',
      right: r.right, vw: document.documentElement.clientWidth,
    };
  });
  expect(info.hidden, testId + ' should be visible').toBe(false);
  expect(info.right, testId + ' must not overflow the viewport').toBeLessThanOrEqual(info.vw + 0.5);
  // Allow 1px subpixel wrapping; text must not be cut off horizontally.
  expect(info.sw, testId + ' text must not be clipped horizontally: ' + info.text).toBeLessThanOrEqual(info.cw + 1);
}

function shot(page, w, name) {
  fs.mkdirSync(SHOTS, { recursive: true });
  return page.screenshot({ path: path.join(SHOTS, `meron-${w}-${name}.png`), fullPage: false });
}

async function visibleFocus(page, testId) {
  const ring = await page.getByTestId(testId).evaluate((el) => {
    const cs = getComputedStyle(el);
    const within = el.matches(':focus-within') ? getComputedStyle(el) : null;
    return {
      outline: cs.outline,
      outlineWidth: cs.outlineWidth,
      boxShadow: cs.boxShadow,
      borderColor: cs.borderColor,
      focusWithinOutline: within ? within.outline : null,
    };
  });
  const has =
    (ring.outline && ring.outline !== 'none' && !/^0px /.test(ring.outlineWidth || '')) ||
    (ring.boxShadow && ring.boxShadow !== 'none') ||
    (ring.focusWithinOutline && ring.focusWithinOutline !== 'none');
  expect(has, testId + ' must show a visible focus ring: ' + JSON.stringify(ring)).toBe(true);
}

module.exports = {
  KEY, PRE, T, EMPTY, ONE, SHOTS,
  snapshot, snapshotObj, boot, pick, noHScroll, minTarget, notClipped, shot, visibleFocus,
};
