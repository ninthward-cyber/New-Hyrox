'use strict';
// Phase 11.3 part 2: optional fiber (g) / sodium (mg). Unknown never 0; eaten fraction once; partial = "known subtotal —
// incomplete"; complete only for a complete day with every item known. Synthetic data. CHROME MOBILE EMULATION, NOT SAFARI.
const { test, expect } = require('@playwright/test');
// P0 (22 Nov 2026): the meal diary moved from Today to Add > Meal ("Log meal" on Today opens it). This brings it on screen
// the way the owner does; it does nothing when the diary or a dedicated logger is already showing.
async function diary(page) {
  if (await page.getByTestId('meal-diary').isVisible()) return;
  if (await page.getByTestId('logger-head').isVisible()) return;
  if (!(await page.getByTestId('panel-today').isVisible())) await page.getByTestId('tab-today').click();
  await page.getByTestId('today-add-meal').click();
  await page.getByTestId('meal-diary').waitFor();
}

const NOW = '2026-11-19T09:00:00.000Z', T = '2026-11-19T08:00:00.000Z';
const K = (v) => ({ value: v, state: 'KNOWN' }), E = (v) => ({ value: v, state: 'ESTIMATED' });
const item = (name, kcal, x) => Object.assign({ name, role: 'MAIN', portion: '', preparation: '', eatenFraction: null, kcal: K(kcal), proteinG: K(10), carbsG: K(10), fatG: K(5) }, x || {});
const meal = (id, comps, x) => Object.assign({ id, createdAt: T, updatedAt: T, date: '2026-11-19', time: '12:00', label: 'Lunch', source: 'MANUAL', description: '', eatenFraction: 1, lifecycle: 'CONFIRMED', confirmedAt: T, ai: null, mealCategory: 'LUNCH', components: comps }, x || {});
const seed = (meals, extra) => Object.assign({ version: 2, weight: [], workouts: [], nutrition: [], meals }, extra || {});
async function open(page, data) {
  page._errs = []; page.on('pageerror', (e) => page._errs.push(e.message));
  await page.clock.setFixedTime(new Date(NOW));
  await page.goto('./'); await page.evaluate(() => localStorage.clear());
  if (data) await page.evaluate((d) => localStorage.setItem('hyrox.v1', JSON.stringify(d)), data);
  await page.reload(); await expect(page.getByTestId('app-error')).toBeHidden();
}
const stored = async (page) => JSON.parse((await page.evaluate(() => localStorage.getItem('hyrox.v1'))) || '{}');

for (const W of [390, 320]) {
  test.describe(`P11.3 fiber/sodium ${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`${W}: older meals (no fields) read "unknown"; partial coverage is a "known subtotal — incomplete" with counts; kcal line unchanged`, async ({ page }) => {
      await open(page, seed([meal('m1', [item('rice', 400), item('chicken', 300)])]));
      const kcal = await page.getByTestId('diary-total').textContent();
      await expect(page.getByTestId('diary-fiber')).toHaveText('Fiber: unknown (0 of 2 items known)');
      await expect(page.getByTestId('diary-sodium')).toHaveText('Sodium: unknown (0 of 2 items known)');
      await open(page, seed([meal('m1', [item('rice', 400, { fiberG: K(0.6), sodiumMg: K(5) }), item('chicken', 300, { sodiumMg: E(120) })])]));
      expect(await page.getByTestId('diary-total').textContent()).toBe(kcal);
      await expect(page.getByTestId('diary-fiber')).toHaveText('Fiber: 0.6 g known subtotal — incomplete (1 of 2 items known)');
      await expect(page.getByTestId('diary-sodium')).toHaveText('Sodium: 125 mg so far (2 of 2 items known, estimates included)');
      expect(page._errs).toEqual([]);
    });

    test(`${W}: "complete day total" only after "All food & drink entered" AND every item known; drafts never count`, async ({ page }) => {
      await open(page, seed([meal('m1', [item('oats', 300, { fiberG: K(8), sodiumMg: K(0) })]), meal('d1', [item('cake', 500, { fiberG: K(2) })], { lifecycle: 'DRAFT', confirmedAt: null })]));
      await expect(page.getByTestId('diary-fiber')).toHaveText('Fiber: 8 g so far (1 of 1 item known)');
      await page.getByTestId('tab-history').click(); // the draft (2 g fiber) never counts
      await page.getByTestId('attest-complete').first().click();
      await page.getByTestId('tab-today').click();
      await expect(page.getByTestId('diary-fiber')).toHaveText('Fiber: 8 g — complete day total (1 of 1 item known)');
      await expect(page.getByTestId('diary-sodium')).toHaveText('Sodium: 0 mg — complete day total (1 of 1 item known)');
      expect(page._errs).toEqual([]);
    });

    test(`${W}: typed fiber/sodium: blank = unknown, 0 = known 0, eaten fraction applied once in totals; a changed number clears USDA values`, async ({ page }) => {
      await open(page);
      await diary(page); await page.getByTestId('diary-log-lunch').click(); await page.getByTestId('meal-path-manual').click().catch(() => {});
      await page.getByTestId('component-name').fill('Soup'); await page.getByTestId('component-kcal').fill('200');
      await page.getByTestId('component-extra').locator('summary').click();
      for (const id of ['component-fiberG', 'component-sodiumMg']) expect(await page.getByTestId(id).evaluate((e) => parseFloat(getComputedStyle(e).fontSize))).toBeGreaterThanOrEqual(16);
      expect((await page.getByTestId('component-extra').locator('summary').boundingBox()).height).toBeGreaterThanOrEqual(44);
      await page.getByTestId('component-sodiumMg').fill('900');
      await page.getByTestId('component-fiberG').fill('0');
      await expect(page.getByTestId('meal-total-sodiumMg')).toHaveText('Sodium: 900 mg (1 of 1 known)');
      await page.getByTestId('meal-eaten-50').click();
      await expect(page.getByTestId('meal-total-sodiumMg')).toHaveText('Sodium: 450 mg (1 of 1 known)');
      await page.getByTestId('component-fiberG').fill('');
      await expect(page.getByTestId('meal-total-fiberG')).toHaveText('Fiber: unknown (0 of 1 known)');
      await page.getByTestId('meal-confirm').click();
      const c = (await stored(page)).meals[0];
      expect([c.eatenFraction, c.components[0].sodiumMg, 'fiberG' in c.components[0]]).toEqual([0.5, { value: 900, state: 'KNOWN', by: 'OWNER' }, false]); // RC2 review: a typed value is stored as the owner's
      await expect(page.getByTestId('diary-sodium')).toHaveText('Sodium: 450 mg so far (1 of 1 item known)');
      // USDA item: changing kcal removes the source note AND the USDA fiber/sodium (they belonged to that amount)
      await diary(page); await page.getByTestId('diary-log-dinner').click(); await page.getByTestId('meal-add-foods').click();
      await page.getByTestId('foods-q').fill('banana'); await page.getByTestId('food-pick').first().click(); await page.getByTestId('food-add').click(); await page.getByTestId('foods-done').click();
      await page.getByTestId('component-extra').locator('summary').click().catch(() => {});
      await expect(page.getByTestId('component-sodiumMg')).not.toHaveValue('');
      await page.getByTestId('component-kcal').fill('150');
      await expect(page.getByTestId('component-sodiumMg')).toHaveValue('');
      await expect(page.getByTestId('component-extra-note')).toContainText('cleared because you changed a number');
      expect(page._errs).toEqual([]);
    });

    test(`${W}: settings recovery (damaged settings → Replace) keeps saved foods WITH their fiber/sodium; History Copy keeps them`, async ({ page }) => {
      const mf = { id: 'mf-1', name: 'Chain fries (US app)', portion: '1 medium', kcal: K(320), proteinG: K(4), carbsG: K(43), fatG: K(15), sodiumMg: K(260), fiberG: K(4), basis: 'your values', savedAt: T, fromMealId: null };
      await open(page, seed([meal('m1', [item('fries', 320, { sodiumMg: K(260) })])], { ownerSettings: [{ id: 'app-settings', date: '2026-11-18', createdAt: T, rhrBaselineBpm: 999, myFoods: [mf], favFoods: ['my:mf-1'] }] }));
      await page.getByTestId('tab-settings').click();
      await page.getByTestId('set-approve-correction').check(); await page.getByTestId('set-save').click();
      await expect(page.getByTestId('owner-settings-damaged')).toHaveCount(0);
      const rec = (await stored(page)).ownerSettings.find((r) => r.id === 'app-settings');
      expect(rec.myFoods[0].sodiumMg).toEqual(K(260)); expect(rec.myFoods[0].fiberG).toEqual(K(4));
      await page.getByTestId('tab-history').click(); await page.getByTestId('meal-copy').first().click();
      await page.getByTestId('meal-confirm').click();
      const ms = (await stored(page)).meals;
      expect(ms.length).toBe(2); expect(ms.map((m) => m.components[0].sodiumMg)).toEqual([K(260), K(260)]);
      await page.getByTestId('tab-today').click();
      await expect(page.getByTestId('diary-sodium')).toHaveText('Sodium: 520 mg so far (2 of 2 items known)');
      expect(page._errs).toEqual([]);
    });

    test(`${W}: an unknown settings field (e.g. a future planBlocks) survives every 11.3 settings write: Save to My foods, favourite, rename, delete, a normal Settings save`, async ({ page }) => {
      const PB = [{ id: 'pb-1', weeks: 4, note: 'future Phase 12 field' }];
      await open(page, seed([meal('m1', [item('soup', 200, { sodiumMg: K(900) })])], { ownerSettings: [{ id: 'app-settings', date: '2026-11-18', createdAt: T, rhrBaselineBpm: 70, planBlocks: PB, futureNote: 'keep me' }] }));
      const set = async () => (await stored(page)).ownerSettings.find((r) => r.id === 'app-settings');
      await page.getByTestId('tab-history').click();
      await page.getByTestId('meal-save-myfoods').click(); await page.getByTestId('myfoods-pick-save').click();
      expect([(await set()).planBlocks, (await set()).futureNote, (await set()).myFoods[0].sodiumMg]).toEqual([PB, 'keep me', K(900)]);
      await page.getByTestId('tab-today').click(); await diary(page); await page.getByTestId('diary-log-dinner').click(); await page.getByTestId('meal-add-foods').click();
      await page.getByTestId('foods-tab-my').click(); await page.getByTestId('food-pick').first().click();
      await page.getByTestId('food-fav').click();
      expect([(await set()).planBlocks, (await set()).favFoods.length]).toEqual([PB, 1]);
      await page.getByTestId('foods-done').click(); await page.getByTestId('meal-discard').click().catch(() => {});
      await page.getByTestId('tab-settings').click(); await page.getByTestId('set-save').click();
      expect([(await set()).planBlocks, (await set()).futureNote, (await set()).myFoods.length]).toEqual([PB, 'keep me', 1]);
      expect(page._errs).toEqual([]);
    });

    test(`${W}: INTEGRATED (RC1, was the P11.3 INTEGRATION NOTE): damaged-settings "Replace" keeps My foods + favourites AND other fields such as planBlocks`, async ({ page }) => {
      // RC1: the Phase 12 repair carry (HB.repairCarry) now keeps every other valid field; the last check is flipped.
      const PB = [{ id: 'pb-1', weeks: 4 }];
      await open(page, seed([], { ownerSettings: [{ id: 'app-settings', date: '2026-11-18', createdAt: T, rhrBaselineBpm: 999, planBlocks: PB, myFoods: [{ id: 'mf-1', name: 'Oats', portion: '', kcal: K(300), proteinG: K(10), carbsG: K(50), fatG: K(5), sodiumMg: K(5), basis: 'your values', savedAt: T, fromMealId: null }] }] }));
      await page.getByTestId('tab-settings').click();
      await page.getByTestId('set-approve-correction').check(); await page.getByTestId('set-save').click();
      const rec = (await stored(page)).ownerSettings.find((r) => r.id === 'app-settings');
      expect([rec.rhrBaselineBpm, rec.myFoods[0].sodiumMg]).toEqual([76, K(5)]);
      expect(rec.planBlocks).toEqual(PB); // RC1: kept (P11.3 alone and Claude P11.2 dropped it here)
    });
  });
}
