'use strict';
// Phase 11.2 part 4 (P0): "Add foods" — local search over the bundled USDA list + My foods, multi-food draft, one confirm,
// diary return. No paid call, no third-party call, nothing on keystrokes. Synthetic data. CHROME MOBILE EMULATION, NOT SAFARI/WEBKIT.
const { test, expect } = require('@playwright/test');
// P0 (22 Nov 2026): the meal diary moved from Today to Add > Meal ("Log meal" on Today opens it). This brings it on screen
// the way the owner does; it does nothing when the diary or a dedicated logger is already showing.
async function diary(page) {
  if (await page.getByTestId('meal-diary').isVisible()) return;
  if (await page.getByTestId('logger-head').isVisible()) return;
  if (!(await page.getByTestId('panel-today').isVisible())) await page.getByTestId('tab-today').click();
  await page.getByTestId('today-add-meal').click();
  await page.getByTestId('meal-diary').waitFor();
}

const NOW = '2026-11-19T09:00:00.000Z'; // 12:00 Asia/Qatar, Thu 19 Nov
async function open(page, at = NOW) {
  page._errs = []; page.on('pageerror', (e) => page._errs.push(e.message));
  page._reqs = []; page.on('request', (r) => page._reqs.push(r.url()));
  await page.clock.setFixedTime(new Date(at));
  await page.goto('./');
  await page.evaluate(() => localStorage.clear());
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
}
const noErrors = (page) => expect(page._errs).toEqual([]);
const meals = async (page) => (JSON.parse((await page.evaluate(() => localStorage.getItem('hyrox.v1'))) || '{}').meals || []);
async function foods(page, cat = 'lunch') {
  await diary(page); await page.getByTestId('diary-log-' + cat).click();
  await page.getByTestId('meal-add-foods').click();
  await expect(page.getByTestId('foods-screen')).toBeVisible();
  await expect(page.getByTestId('foods-status')).not.toContainText('Loading');
}
async function pick(page, q, nameRe, opts = {}) {
  await page.getByTestId('foods-q').fill(q);
  const item = page.getByTestId('food-result').filter({ hasText: nameRe }).first();
  await item.getByTestId('food-pick').click();
  if (opts.serving) await page.getByTestId('food-serving').selectOption({ label: opts.serving });
  if (opts.qty) await page.getByTestId('food-qty').fill(String(opts.qty));
  return item;
}
async function add(page, q, nameRe, opts) { await pick(page, q, nameRe, opts); await page.getByTestId('food-add').click(); await expect(page.getByTestId('foods-q')).toHaveValue(''); }

for (const W of [390, 320]) {
  test.describe(`P11.2 Add foods ${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`${W}: two foods into the CURRENT draft, nothing saved until one confirm, then the diary shows the meal once under Lunch; no network while typing`, async ({ page }) => {
      await open(page);
      await foods(page);
      await expect(page.getByTestId('foods-q')).toBeFocused();
      await expect(page.getByTestId('foods-context')).toHaveText('Lunch · Thu 19 Nov · today');
      const before = page._reqs.length;
      await page.getByTestId('foods-q').pressSequentially('big mac', { delay: 30 });
      // P11.3: the larger US list adds "Big Mac (McDonalds)" (FNDDS) above the 2018 SR row; this flow still uses the SR row.
      const r = page.getByTestId('food-result').filter({ hasText: /^McDONALD'S, BIG MAC1 item/ });
      await expect(r).toContainText("McDONALD'S, BIG MAC");
      expect(page._reqs.slice(before)).toEqual([]); // typing never touches the network
      await expect(r.getByTestId('food-restaurant')).toBeVisible();
      await r.getByTestId('food-pick').click();
      await expect(page.getByTestId('food-preview')).toHaveText('1 item 7.6 oz (219 g) · 563 kcal · estimate');
      await page.getByTestId('food-more').locator('summary').click();
      await expect(page.getByTestId('food-source')).toContainText("NOT the restaurant's official figure");
      await expect(page.getByTestId('food-macros')).toContainText('Protein');
      await page.getByTestId('food-add').click();
      await expect(page.getByTestId('foods-q')).toBeFocused();
      await add(page, 'mcdonalds fries', /McDONALD'S, french fries/);
      await expect(page.getByTestId('foods-added')).toContainText('2 foods added');
      expect(await meals(page)).toEqual([]); // nothing saved by adding
      expect(page._reqs.slice(before).filter((u) => !/^http:\/\/127\.0\.0\.1/.test(u) || /\/api\//.test(u))).toEqual([]);
      await page.getByTestId('foods-done').click();
      await expect(page.getByTestId('meal-add-foods')).toBeFocused();
      await expect(page.getByTestId('component-row')).toHaveCount(2);
      await expect(page.getByTestId('meal-total-kcal')).toContainText('792');
      await page.getByTestId('meal-confirm').click();
      await expect(page.getByTestId('meal-diary')).toBeVisible();
      await expect(page.getByTestId('diary-sub-lunch')).toHaveText('1 entry · 792 kcal');
      await expect(page.getByTestId('diary-row-lunch').getByTestId('diary-entry')).toHaveCount(1);
      const m = await meals(page);
      expect(m.map((x) => [x.mealCategory, x.lifecycle, x.source, x.components.map((c) => c.provenance.fdcId)])).toEqual([['LUNCH', 'CONFIRMED', 'MANUAL', [170720, 170721].map(() => expect.any(Number))]]);
      expect(m[0].components.every((c) => c.kcal.state === 'ESTIMATED' && c.provenance.source === 'USDA_FDC')).toBe(true);
      // next Log is a fresh draft
      await diary(page); await page.getByTestId('diary-log-dinner').click();
      await expect(page.getByTestId('component-name').first()).toHaveValue('');
      noErrors(page);
    });

    test(`${W}: typos, aliases, prefixes; branded ambiguity lists choices and never picks one; no-result offers Manual and keeps kcal unknown (not 0)`, async ({ page }) => {
      await open(page);
      await foods(page);
      await page.getByTestId('foods-q').fill('brocoli');
      await expect(page.getByTestId('food-result').first()).toContainText('Broccoli');
      await expect(page.getByTestId('food-result').first().getByTestId('food-typo')).toBeVisible();
      await page.getByTestId('foods-q').fill('porridge');
      await expect(page.getByTestId('food-result').first()).toContainText('oats');
      await page.getByTestId('foods-q').fill('french fries');
      await expect(page.getByTestId('food-restaurant')).not.toHaveCount(0);
      expect(await page.getByTestId('food-result').count()).toBeGreaterThan(3);
      await expect(page.getByTestId('food-detail')).toHaveCount(0); // nothing opened or chosen by itself
      await page.getByTestId('foods-q').fill('starbucks frappuccino');
      await expect(page.getByTestId('foods-none')).toBeVisible();
      await page.getByTestId('foods-none-manual').click();
      await expect(page.getByTestId('component-name')).toHaveValue('starbucks frappuccino');
      await expect(page.getByTestId('component-kcal')).toBeFocused();
      await expect(page.getByTestId('meal-total-kcal')).toContainText('unknown');
      await page.getByTestId('meal-confirm').click();
      await expect(page.getByTestId('diary-sub-lunch')).toContainText('kcal unknown');
      await expect(page.getByTestId('diary-total')).not.toContainText(/\b0 kcal/);
      noErrors(page);
    });

    test(`${W}: serving + quantity; invalid quantity refused; duplicate asks first; Back with added foods asks Keep/Discard`, async ({ page }) => {
      await open(page);
      await foods(page, 'breakfast');
      await pick(page, 'egg', /^Egg, whole, raw, fresh/, { serving: '100 g (100 g)', qty: '1.5' });
      await expect(page.getByTestId('food-preview')).toHaveText('1.5 × 100 g (150 g) · 215 kcal · estimate');
      await page.getByTestId('food-qty').fill('0');
      await page.getByTestId('food-add').click();
      await expect(page.getByTestId('food-error')).toContainText('quantity');
      await page.getByTestId('food-qty').fill('2');
      await page.getByTestId('food-add').click();
      await pick(page, 'eggs', /^Egg, whole, raw, fresh/);
      await page.getByTestId('food-add').click();
      await expect(page.getByTestId('choice-dialog')).toContainText('Already in this meal');
      await page.getByTestId('choice-keep').click();
      await expect(page.getByTestId('foods-added')).toContainText('1 food added');
      await page.getByTestId('food-add').click();
      await page.getByTestId('choice-yes').click();
      await expect(page.getByTestId('foods-added')).toContainText('2 foods added');
      await page.getByTestId('foods-done').click();
      await expect(page.getByTestId('component-row')).toHaveCount(2);
      await page.getByTestId('logger-back').click();
      await expect(page.getByTestId('choice-dialog')).toBeVisible();
      await page.getByTestId('choice-yes').click();
      await expect(page.getByTestId('meal-diary')).toBeVisible();
      expect(await meals(page)).toEqual([]);
      await diary(page); await page.getByTestId('diary-log-breakfast').click();
      await expect(page.getByTestId('component-row')).toHaveCount(1);
      await expect(page.getByTestId('component-name')).toHaveValue('');
      noErrors(page);
    });

    test(`${W}: Save to My foods (explicit, from a confirmed meal) keeps the estimate status; Recent / Favorites / My foods; renaming never changes saved meals`, async ({ page }) => {
      await open(page);
      await foods(page, 'snacks');
      await add(page, 'banana', /^Bananas, raw/);
      await page.getByTestId('foods-done').click();
      await page.getByTestId('meal-confirm').click();
      const saved = JSON.stringify(await meals(page));
      await page.getByTestId('tab-history').click();
      await page.getByTestId('meal-save-myfoods').click();
      await page.getByTestId('myfoods-pick-save').click();
      await expect(page.getByTestId('ext-toast')).toContainText('My foods: 1 saved');
      await page.getByTestId('tab-today').click();
      await foods(page, 'dinner');
      await page.getByTestId('foods-tab-recent').click();
      await expect(page.getByTestId('food-result').first()).toContainText('Bananas, raw');
      await expect(page.getByTestId('food-detail')).toHaveCount(0);
      await page.getByTestId('foods-tab-my').click();
      const my = page.getByTestId('food-result').first();
      await expect(my).toContainText('USDA estimate');
      await my.getByTestId('food-pick').click();
      await page.getByTestId('food-fav').click();
      await page.getByTestId('myfood-name').fill('My banana');
      await page.getByTestId('myfood-rename').click();
      await page.getByTestId('foods-tab-fav').click();
      await expect(page.getByTestId('food-result')).toContainText('My banana');
      await page.getByTestId('foods-q').fill('my banana');
      await page.getByTestId('food-result').first().getByTestId('food-pick').click();
      await page.getByTestId('food-qty').fill('2');
      await page.getByTestId('food-add').click();
      await page.getByTestId('foods-done').click();
      await expect(page.getByTestId('component-name')).toHaveValue('My banana');
      await page.getByTestId('meal-confirm').click();
      const m = await meals(page);
      expect(JSON.stringify([m[0]])).toBe(saved); // the first meal is untouched by saving / renaming the food
      expect(m[1].components[0].kcal.state).toBe('ESTIMATED');
      expect(m[1].components[0].kcal.value).toBe(m[0].components[0].kcal.value * 2);
      noErrors(page);
    });

    test(`${W}: offline after the list loads — search still works; if the food file cannot load, Manual / My foods still work`, async ({ page, context }) => {
      await open(page);
      await foods(page);
      await context.setOffline(true);
      await page.getByTestId('foods-q').fill('apple');
      await expect(page.getByTestId('food-result').first()).toContainText('Apples');
      await context.setOffline(false);
      const p2 = await context.newPage();
      p2._errs = []; p2.on('pageerror', (e) => p2._errs.push(e.message));
      await p2.clock.setFixedTime(new Date(NOW));
      await p2.route('**/food-db.js', (r) => r.abort());
      await p2.goto('./'); await p2.evaluate(() => localStorage.clear()); await p2.reload();
      await diary(p2); await p2.getByTestId('diary-log-lunch').click();
      await p2.getByTestId('meal-add-foods').click();
      await expect(p2.getByTestId('foods-status')).toContainText('could not be loaded');
      await p2.getByTestId('foods-manual').click();
      await expect(p2.getByTestId('component-row')).toHaveCount(1);
      expect(p2._errs).toEqual([]);
      noErrors(page);
    });

    test(`${W}: Asia/Qatar midnight — foods added at 23:59 keep their date with the notice; confirm lands on that day's diary`, async ({ page }) => {
      await open(page, '2026-11-18T20:58:00.000Z');
      await foods(page, 'snacks');
      await add(page, 'yogurt greek', /^Yogurt, Greek/);
      await page.clock.setFixedTime(new Date('2026-11-18T21:00:30.000Z'));
      await page.evaluate(() => document.dispatchEvent(new Event('visibilitychange')));
      await page.getByTestId('foods-done').click();
      await expect(page.getByTestId('meal-date')).toHaveValue('2026-11-18');
      await page.getByTestId('meal-confirm').click();
      await expect(page.getByTestId('diary-date')).toContainText('Wed 18 Nov');
      await expect(page.getByTestId('diary-sub-snacks')).toContainText('1 entry');
      await expect(page.getByTestId('today-card')).toContainText('Thu 19 Nov');
      noErrors(page);
    });

    test(`${W}: compact accessible screen — 16 px inputs, ≥44 px targets, no sideways scroll, alternate actions open Photo / Describe`, async ({ page }) => {
      await open(page);
      await foods(page);
      await page.getByTestId('foods-q').fill('chicken');
      await page.getByTestId('food-pick').first().click();
      for (const id of ['foods-q', 'food-qty', 'food-serving']) expect(await page.getByTestId(id).evaluate((e) => parseFloat(getComputedStyle(e).fontSize))).toBeGreaterThanOrEqual(16);
      for (const id of ['foods-done', 'foods-tab-search', 'foods-tab-my', 'food-add', 'foods-alt-photo', 'foods-alt-describe', 'foods-manual']) {
        const b = await page.getByTestId(id).boundingBox(); expect(b.height, id).toBeGreaterThanOrEqual(44);
      }
      expect((await page.getByTestId('food-pick').first().boundingBox()).height).toBeGreaterThanOrEqual(44);
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
      await page.getByTestId('foods-alt-describe').click();
      await expect(page.getByTestId('meal-path-description')).toHaveClass(/active/);
      await page.getByTestId('meal-add-foods').click();
      await page.getByTestId('foods-alt-photo').click();
      await expect(page.getByTestId('meal-path-photo_ai')).toHaveClass(/active/);
      noErrors(page);
    });
  });
}
