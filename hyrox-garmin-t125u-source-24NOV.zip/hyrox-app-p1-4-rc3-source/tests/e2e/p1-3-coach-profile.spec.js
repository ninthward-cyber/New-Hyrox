'use strict';
// P1.3 Delivery B (CC execution order 23 Nov 2026, section 4): Settings > Nutrition Coach — collapsed profile, goals, confirmed
// targets with history, coach on/off, field-preserving and two-tab-safe writes, restore preview. Synthetic data only, no network.
// CHROME MOBILE EMULATION, NOT SAFARI/WEBKIT and not a physical iPhone.
const { test, expect } = require('@playwright/test');

const NOW = '2026-11-23T09:00:00.000Z'; // 12:00 Asia/Qatar, Mon 23 Nov 2026
const TODAY = '2026-11-23';
const T = '2026-11-01T06:00:00.000Z';
const BASE_SET = { id: 'app-settings', date: '2026-11-01', createdAt: T, rhrBaselineBpm: 61, rhrBaselineSource: 'OWNER_SET', stepBaselineMode: 'AUTO', weightUnit: 'lb',
  myFoods: [{ id: 'mf-syn-1', name: 'Synthetic oats bowl', basis: 'PER_SERVING', servingLabel: '1 bowl', kcal: 150, proteinG: 5, carbsG: 27, fatG: 3, createdAt: T }],
  favFoods: [], planBlocks: [] };
const seedOf = (more) => Object.assign({ version: 2, weight: [], workouts: [], nutrition: [], meals: [] }, more || {});
async function open(page, seed, at = NOW) {
  page._errs = []; page.on('pageerror', (e) => page._errs.push(e.message));
  page._net = []; page.on('request', (r) => { if (!/^http:\/\/127\.0\.0\.1:\d+\//.test(r.url())) page._net.push(r.url()); });
  page.on('dialog', (d) => d.accept());
  await page.clock.setFixedTime(new Date(at));
  await page.goto('./');
  await page.evaluate((s) => { localStorage.clear(); if (s) localStorage.setItem('hyrox.v1', JSON.stringify(s)); }, seed || null);
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
}
const stored = (page) => page.evaluate(() => JSON.parse(localStorage.getItem('hyrox.v1') || '{}'));
const setRec = async (page) => ((await stored(page)).ownerSettings || []).find((r) => r.id === 'app-settings');
async function toCoach(page) { await page.getByTestId('tab-settings').click(); await expect(page.getByTestId('coach-card')).toBeVisible(); }
async function fillProfileCm(page, cm, age) {
  const det = page.getByTestId('coach-profile');
  if (!(await det.evaluate((d) => d.open))) await page.getByTestId('coach-profile-summary').click();
  await page.getByTestId('coach-height-cm').fill(String(cm));
  await page.getByTestId('coach-age').fill(String(age));
}

for (const W of [390, 320]) {
  test.describe(`P1.3 Delivery B — Nutrition Coach settings ${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`${W}: FAIL-FIRST — Settings has a Nutrition Coach card, off by default, with a COLLAPSED profile and the provisional reference in use`, async ({ page }) => {
      await open(page, seedOf({ ownerSettings: [BASE_SET] }));
      await toCoach(page);
      const c = page.getByTestId('coach-card');
      await expect(c.getByTestId('coach-toggle')).toHaveText('Coach: Off');
      await expect(c.getByTestId('coach-toggle')).toHaveAttribute('aria-pressed', 'false');
      expect(await page.getByTestId('coach-profile').evaluate((d) => d.open)).toBe(false);
      await expect(c.getByTestId('coach-current-line')).toHaveText('In use today: 2,400 kcal · protein 190 g (floor 170 g) · fat — · carbs —');
      await expect(c.getByTestId('coach-notice')).toContainText('not medical advice');
      await expect(c.locator('[data-testid^="coach-goal-"]')).toHaveCount(4);
      await expect(c.getByTestId('coach-goal')).toContainText('Lose 1 lb a week — Recommended');
      // the profile is never shown on Home
      await page.getByTestId('tab-today').click();
      await expect(page.getByTestId('panel-today').locator('[data-testid^="coach-profile"], [data-testid="coach-card"]')).toHaveCount(0);
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
      expect(page._errs).toEqual([]); expect(page._net).toEqual([]);
    });

    test(`${W}: FAIL-FIRST — profile in ft/in is stored canonically in cm; sex is asked only for the equation; every other settings field is kept`, async ({ page }) => {
      await open(page, seedOf({ ownerSettings: [Object.assign({}, BASE_SET, { favFoods: ['SR:1001'], planBlocks: [{ id: 'syn-block', state: 'DRAFT' }], futureField: { a: 1 } })] }));
      await toCoach(page);
      await page.getByTestId('coach-profile-summary').click();
      await page.getByTestId('coach-height-unit-ftin').click();
      await page.getByTestId('coach-height-ft').fill('5');
      await page.getByTestId('coach-height-in').fill('10');
      await page.getByTestId('coach-age').fill('40');
      await expect(page.getByTestId('coach-sex')).toBeHidden();
      await page.getByTestId('coach-method-equation').check();
      await expect(page.getByTestId('coach-sex')).toBeVisible();
      await page.getByTestId('coach-method-none').check();
      await expect(page.getByTestId('coach-sex')).toBeHidden();
      await page.getByTestId('coach-activity').selectOption('A2');
      await page.getByTestId('coach-profile-save').click();
      await expect(page.getByTestId('coach-msg')).toContainText('Profile saved.');
      const r = await setRec(page);
      expect(r.nutritionCoach.profile).toEqual({ heightCm: 177.8, heightUnit: 'ftin', ageYears: 40, ageEnteredOn: TODAY, ageConfirmedOn: TODAY, estimateMethod: 'NONE', sexForEquation: null, activity: 'A2' });
      expect(r.favFoods).toEqual(['SR:1001']); expect(r.planBlocks).toEqual([{ id: 'syn-block', state: 'DRAFT' }]);
      expect(r.myFoods).toEqual(BASE_SET.myFoods); expect(r.weightUnit).toBe('lb'); expect(r.rhrBaselineBpm).toBe(61); expect(r.futureField).toEqual({ a: 1 });
      expect(Object.keys(r.nutritionCoach.profile).some((k) => /birth|dob/i.test(k))).toBe(false);
      // re-render: ft/in shown back from cm
      await expect(page.getByTestId('coach-height-ft')).toHaveValue('5');
      await expect(page.getByTestId('coach-height-in')).toHaveValue('10');
      expect(page._errs).toEqual([]); expect(page._net).toEqual([]);
    });

    test(`${W}: FAIL-FIRST — an invalid height is refused with a reason and nothing is written`, async ({ page }) => {
      await open(page, seedOf({ ownerSettings: [BASE_SET] }));
      await toCoach(page);
      const before = await page.evaluate(() => localStorage.getItem('hyrox.v1'));
      await fillProfileCm(page, 'abc', 40);
      await page.getByTestId('coach-profile-save').click();
      await expect(page.getByTestId('coach-profile-error')).toContainText('Nothing was changed.');
      expect(await page.evaluate(() => localStorage.getItem('hyrox.v1'))).toBe(before);
    });

    test(`${W}: FAIL-FIRST — own target: review, confirm screen shows old/new/arithmetic; Cancel writes nothing; Confirm keeps history and the coach-on reference`, async ({ page }) => {
      await open(page, seedOf({ ownerSettings: [BASE_SET] }));
      await toCoach(page);
      await page.getByTestId('coach-toggle').click();
      await expect(page.getByTestId('coach-toggle')).toHaveText('Coach: On');
      await page.getByTestId('coach-goal-lose_1').check();
      await expect(page.getByTestId('coach-msg')).toContainText('Goal set');
      const own = page.getByTestId('coach-own');
      await own.locator('summary').click();
      await page.getByTestId('coach-own-kcal').fill('2200');
      await page.getByTestId('coach-own-protein').fill('190');
      await page.getByTestId('coach-own-fat').fill('60');
      await page.getByTestId('coach-own-review').click();
      await expect(page.getByTestId('coach-confirm')).toBeVisible();
      await expect(page.getByTestId('coach-confirm-old')).toContainText('Now: 2,400 kcal');
      await expect(page.getByTestId('coach-confirm-new')).toContainText('New: 2,200 kcal · protein 190 g · fat 60 g · carbs —');
      await expect(page.getByTestId('coach-confirm-arith')).toContainText('carbs from the remainder: about 225 g');
      const before = await page.evaluate(() => localStorage.getItem('hyrox.v1'));
      await page.getByTestId('coach-confirm-cancel').click();
      await expect(page.getByTestId('coach-msg')).toHaveText('Cancelled. Nothing was changed.');
      expect(await page.evaluate(() => localStorage.getItem('hyrox.v1'))).toBe(before);
      await own.locator('summary').click();
      await page.getByTestId('coach-own-kcal').fill('2200');
      await page.getByTestId('coach-own-protein').fill('190');
      await page.getByTestId('coach-own-fat').fill('60');
      await page.getByTestId('coach-own-review').click();
      await page.getByTestId('coach-confirm-reason').fill('Synthetic test reason');
      await page.getByTestId('coach-confirm-ok').click();
      await expect(page.getByTestId('coach-msg')).toContainText('Target confirmed');
      await expect(page.getByTestId('coach-current-line')).toHaveText('In use today: 2,200 kcal · protein 190 g · fat 60 g · carbs —');
      const r = await setRec(page);
      expect(r.nutritionCoach.target).toMatchObject({ kcal: 2200, proteinG: 190, fatG: 60, carbsG: null, origin: 'OWNER_ENTERED', effectiveDate: TODAY, reason: 'Synthetic test reason', goal: 'LOSE_1' });
      expect(r.nutritionCoach.target.replaced).toEqual({ kcal: 2400, proteinG: 190, fatG: null, carbsG: null, origin: 'PROVISIONAL' });
      expect(r.nutritionCoach.history.length).toBe(1);
      expect(r.myFoods).toEqual(BASE_SET.myFoods);
      await page.getByTestId('coach-history').locator('summary').click();
      await expect(page.getByTestId('coach-history-entry')).toHaveCount(1);
      // switching the coach off returns every screen to the provisional reference, but keeps the confirmed target
      await page.getByTestId('coach-toggle').click();
      await expect(page.getByTestId('coach-current-line')).toContainText('2,400 kcal');
      expect((await setRec(page)).nutritionCoach.target.kcal).toBe(2200);
      expect(page._errs).toEqual([]); expect(page._net).toEqual([]);
    });

    test(`${W}: FAIL-FIRST — an impossible own target is refused with the reason; a low one shows warnings on the confirm screen`, async ({ page }) => {
      await open(page, seedOf({ ownerSettings: [BASE_SET] }));
      await toCoach(page);
      await page.getByTestId('coach-own').locator('summary').click();
      await page.getByTestId('coach-own-kcal').fill('1500'); await page.getByTestId('coach-own-protein').fill('250');
      await page.getByTestId('coach-own-fat').fill('80'); await page.getByTestId('coach-own-carbs').fill('100');
      await page.getByTestId('coach-own-review').click();
      await expect(page.getByTestId('coach-own-error')).toContainText('more than the 1500');
      await expect(page.getByTestId('coach-confirm')).toHaveCount(0);
      // Re-pointed for P1.3-RC3 (owner decision 1): 1,300 kcal is below the provisional floor and is now refused outright.
      await page.getByTestId('coach-own-kcal').fill('1300'); await page.getByTestId('coach-own-protein').fill('160');
      await page.getByTestId('coach-own-fat').fill('25'); await page.getByTestId('coach-own-carbs').fill('');
      await page.getByTestId('coach-own-review').click();
      await expect(page.getByTestId('coach-own-error')).toContainText('below the provisional floor');
      await expect(page.getByTestId('coach-confirm')).toHaveCount(0);
      // a low-but-allowed target still shows the other warnings on the confirm screen (protein 300 g leaves carbs under 130 g)
      await page.getByTestId('coach-own-kcal').fill('1600'); await page.getByTestId('coach-own-protein').fill('300');
      await page.getByTestId('coach-own-fat').fill('25'); await page.getByTestId('coach-own-carbs').fill('');
      await page.getByTestId('coach-own-review').click();
      const codes = await page.getByTestId('coach-confirm-warning').evaluateAll((els) => els.map((e) => e.getAttribute('data-code')));
      expect(codes).toEqual(expect.arrayContaining(['FAT_LOW', 'CARBS_LOW', 'LARGE_CHANGE']));
      expect(page._errs).toEqual([]);
    });

    test(`${W}: FAIL-FIRST — two tabs: a save from a screen drawn before another tab's change is refused; nothing is lost`, async ({ page, context }) => {
      await open(page, seedOf({ ownerSettings: [BASE_SET] }));
      await toCoach(page);
      await fillProfileCm(page, 180, 40);
      // the other tab saves a favourite meanwhile
      const p2 = await context.newPage();
      await p2.clock.setFixedTime(new Date(NOW));
      await p2.goto('./');
      await p2.evaluate(() => { const s = JSON.parse(localStorage.getItem('hyrox.v1')); const r = s.ownerSettings.find((x) => x.id === 'app-settings'); r.favFoods = ['SR:2002']; localStorage.setItem('hyrox.v1', JSON.stringify(s)); });
      await p2.close();
      const before = await page.evaluate(() => localStorage.getItem('hyrox.v1'));
      await page.getByTestId('coach-profile-save').click();
      await expect(page.getByTestId('coach-msg')).toContainText('Nothing was changed.');
      expect(await page.evaluate(() => localStorage.getItem('hyrox.v1'))).toBe(before);
      // the screen is redrawn from the fresh record; saving again keeps the other tab's favourite
      await fillProfileCm(page, 180, 40);
      await page.getByTestId('coach-profile-save').click();
      await expect(page.getByTestId('coach-msg')).toContainText('Profile saved.');
      const r = await setRec(page);
      expect(r.favFoods).toEqual(['SR:2002']); expect(r.nutritionCoach.profile.heightCm).toBe(180);
    });

    test(`${W}: FAIL-FIRST — restore preview names what a backup does to the coach; restoring brings the coach back with the rest`, async ({ page }) => {
      const coach = { schema: 1, enabled: true, profile: { heightCm: 180, heightUnit: 'cm', ageYears: 40, ageEnteredOn: '2026-11-01', ageConfirmedOn: '2026-11-01', estimateMethod: 'NONE', sexForEquation: null, activity: null }, goal: null, target: null, history: [] };
      await open(page, seedOf({ ownerSettings: [Object.assign({}, BASE_SET, { nutritionCoach: coach })] }));
      await toCoach(page);
      const [dl] = await Promise.all([page.waitForEvent('download'), page.getByTestId('export-btn').click()]);
      const text = require('fs').readFileSync(await dl.path(), 'utf8');
      expect(JSON.parse(text).version).toBe(2);
      expect(JSON.parse(text).ownerSettings[0].nutritionCoach).toEqual(coach);
      const oldObj = JSON.parse(text); delete oldObj.ownerSettings[0].nutritionCoach; const old = JSON.stringify(oldObj); // same backup as an older build would write it
      await page.getByTestId('import-file').setInputFiles({ name: 'hyrox-backup-old.json', mimeType: 'application/json', buffer: Buffer.from(old) });
      await expect(page.getByTestId('import-preview-coach')).toContainText("removes this device's Nutrition Coach profile");
      // wipe, then restore the exported backup
      await page.evaluate(() => localStorage.setItem('hyrox.v1', JSON.stringify({ version: 2, weight: [], workouts: [], nutrition: [] })));
      await page.reload(); await toCoach(page);
      await page.getByTestId('import-file').setInputFiles({ name: 'hyrox-backup-2026-11-23.json', mimeType: 'application/json', buffer: Buffer.from(text) });
      await expect(page.getByTestId('import-preview')).toBeVisible();
      await page.getByTestId('import-confirm').click();
      await expect.poll(async () => ((await setRec(page)) || {}).nutritionCoach).toEqual(coach);
      expect((await setRec(page)).myFoods).toEqual(BASE_SET.myFoods);
      expect(page._errs).toEqual([]); expect(page._net).toEqual([]);
    });

    test(`${W}: FAIL-FIRST — a damaged coach object shows a reason, proposes nothing, and "Reset coach settings only" keeps every other field`, async ({ page }) => {
      await open(page, seedOf({ ownerSettings: [Object.assign({}, BASE_SET, { favFoods: ['SR:1001'], nutritionCoach: { schema: 1, enabled: true, profile: { heightCm: 'tall' } } })] }));
      await toCoach(page);
      await expect(page.getByTestId('coach-invalid')).toContainText('not valid');
      await expect(page.getByTestId('coach-toggle')).toHaveCount(0);
      await expect(page.getByTestId('owner-settings')).toBeVisible();
      await page.getByTestId('coach-reset').click();
      await expect(page.getByTestId('coach-msg')).toHaveText('Coach settings removed. Everything else was kept.');
      const r = await setRec(page);
      expect(r.nutritionCoach).toBeUndefined(); expect(r.favFoods).toEqual(['SR:1001']); expect(r.myFoods).toEqual(BASE_SET.myFoods);
      await expect(page.getByTestId('coach-toggle')).toHaveText('Coach: Off');
      expect(page._errs).toEqual([]);
    });
  });
}
