'use strict';
// RC1 independent review of Phase 12 (planner branch): fail-first regression test for defect B-01 — the approval tick
// must belong to the exact content the owner previewed. Synthetic data; fixed Asia/Qatar test clock (page.clock, test-only;
// nothing in the app is overridden). CHROME MOBILE EMULATION, NOT SAFARI/WEBKIT.
const { test, expect } = require('@playwright/test');
const Q = (iso) => new Date(iso);
const seedDraft = () => {
  const HD = window.HyroxData, HB = window.HyroxBlocks, st = HD.createStore();
  const r = HB.createDraft([], '2026-12-14', '2026-11-19', '2026-11-19T09:00:00.000Z', () => 0);
  const p = st.putRecord('ownerSettings', { id: HD.SETTINGS_ID, date: '2026-11-19', planBlocks: r.blocks });
  if (!p.ok) throw new Error(JSON.stringify(p.errors));
  return r.block.id;
};
async function openPlanner(page) {
  const d = page.getByTestId('today-planner'); await d.waitFor({ state: 'attached' });
  if (!(await d.evaluate((e) => e.open))) await page.getByTestId('today-planner-toggle').click();
}
const settingsRec = async (page) => (JSON.parse(await page.evaluate(() => localStorage.getItem('hyrox.v1'))).ownerSettings || []).find((x) => x.id === 'app-settings');

for (const W of [390, 320]) {
  test.describe(`RC1 review B-01 ${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: 844 } });

    test(`${W}: B-01 approval needs the preview opened first and is tied to that content; a change made in another tab clears it`, async ({ context }) => {
      const a = await context.newPage();
      a.on('dialog', (d) => d.accept());
      await a.clock.setFixedTime(Q('2026-12-11T19:00:00+03:00'));
      await a.goto('./'); await a.evaluate(() => localStorage.clear());
      const id = await a.evaluate(seedDraft);
      await a.reload(); await expect(a.getByTestId('today-glance')).toBeVisible();
      await openPlanner(a);
      await expect(a.getByTestId('planner-approve')).toBeDisabled();          // not before the preview was opened
      await a.getByTestId('planner-preview-toggle').click();
      await expect(a.getByTestId('planner-approve')).toBeEnabled();
      await a.getByTestId('planner-approve').check();
      await expect(a.getByTestId('planner-activate')).toBeEnabled();
      // another tab (same device storage) changes the draft's content
      const b = await context.newPage();
      await b.clock.setFixedTime(Q('2026-12-11T19:01:00+03:00'));
      await b.goto('./'); await expect(b.getByTestId('today-glance')).toBeVisible();
      await openPlanner(b);
      await b.getByTestId('planner-opt-running-I1').check();
      await b.getByTestId('planner-apply-options').click();
      await expect.poll(async () => (await settingsRec(b)).planBlocks[0].options.running).toBe('I1');
      // tab A redraws for any reason (here: a local, unapplied radio change and back)
      await a.getByTestId('planner-opt-race-R1L').check();
      await a.getByTestId('planner-opt-race-hold').check();
      await expect(a.getByTestId('planner-approve')).not.toBeChecked();
      await expect(a.getByTestId('planner-activate')).toBeDisabled();
      const rec = await settingsRec(a);
      expect([rec.planBlocks[0].id, rec.planBlocks[0].state]).toEqual([id, 'DRAFT']);
    });
  });
}
