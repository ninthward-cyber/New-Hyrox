'use strict';
// Sprint B (P1.2 local draft recovery, workout part). Uses ONLY the existing UI key hyrox.ui.workout-draft (no new key,
// no change to hyrox.v1 / data version 2 / backups). Meal-draft persistence is HELD (it needs a new storage key): see
// CHANGES-SPRINT-B-DRAFT-RECOVERY.md. Synthetic data only. CHROME EMULATION, NOT SAFARI/WEBKIT, not a physical iPhone.
const { test, expect } = require('@playwright/test');

const KEY = 'hyrox.ui.workout-draft';
const NOW = '2026-11-18T09:00:00.000Z'; // Wed 18 Nov 12:00 Qatar
const stored = (page) => page.evaluate(() => JSON.parse(localStorage.getItem('hyrox.v1') || 'null'));
const draftRaw = (page) => page.evaluate((k) => localStorage.getItem(k), KEY);
async function boot(page, now, seed) {
  const errs = []; page.on('pageerror', (e) => errs.push(e.message));
  await page.clock.setFixedTime(new Date(now || NOW));
  await page.goto('./');
  await page.evaluate(() => localStorage.clear());
  if (seed) await page.evaluate(seed.fn, seed.arg);
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
  return errs;
}
async function typeWorkout(page, title, notes) {
  await page.getByTestId('tab-add').click();
  await page.getByTestId('add-mode-workout').click();
  await page.getByTestId('session-title').fill(title);
  if (notes) await page.getByTestId('session-notes').fill(notes);
  await expect.poll(() => draftRaw(page)).not.toBeNull();
}
const SAVED = { id: 's-edit-1', date: '2026-11-17', title: 'Saved run', status: 'COMPLETED', modified: false, variant: 'ORIGINAL_60', planSlotId: null, planVersion: null,
  scheduledDate: null, durationMin: 30, rpe: 5, notes: 'as saved', blocks: [], createdAt: '2026-11-17T10:00:00.000Z', updatedAt: '2026-11-17T10:00:00.000Z' };
const seedSaved = { fn: (s) => { localStorage.setItem('hyrox.v1', JSON.stringify({ version: 2, weight: [], workouts: [], nutrition: [], sessions: [s] })); }, arg: SAVED };

for (const W of [390, 320]) {
  test.describe(`P1.2 workout draft recovery ${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: 844 } });

    test(`${W}: abrupt reload keeps the unsaved workout; it is not saved, not completed and changes no stored data; explicit Resume and two-step Discard`, async ({ page }) => {
      const errs = await boot(page);
      const before = await page.evaluate(() => localStorage.getItem('hyrox.v1'));
      await typeWorkout(page, 'Sled push (draft)', 'set 3 felt heavy');
      expect(await page.evaluate(() => localStorage.getItem('hyrox.v1'))).toBe(before); // nothing written to the records
      await page.reload();
      const banner = page.getByTestId('today-workout-draft');
      await expect(banner).toContainText('not saved');
      await expect(page.getByTestId('today-workout-draft-discard')).toBeVisible();
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
      // Discard needs a second, explicit tap; "Keep it" changes nothing.
      await page.getByTestId('today-workout-draft-discard').click();
      await expect(page.getByTestId('today-workout-draft-discard-yes')).toBeVisible();
      await page.getByTestId('today-workout-draft-discard-keep').click();
      expect(await draftRaw(page)).not.toBeNull();
      await page.getByTestId('today-workout-draft-continue').click();
      await expect(page.getByTestId('session-title')).toHaveValue('Sled push (draft)');
      await expect(page.getByTestId('session-notes')).toHaveValue('set 3 felt heavy');
      await expect(page.getByTestId('workout-draft-restored')).toContainText('NOT saved');
      expect((await stored(page) || {}).sessions || []).toEqual([]);
      await page.getByTestId('tab-today').click();
      await page.getByTestId('today-workout-draft-discard').click();
      await page.getByTestId('today-workout-draft-discard-yes').click();
      await expect(page.getByTestId('today-workout-draft')).toHaveCount(0);
      expect(await draftRaw(page)).toBeNull();
      await page.reload();
      await expect(page.getByTestId('today-workout-draft')).toHaveCount(0);
      await page.getByTestId('tab-add').click(); await page.getByTestId('add-mode-workout').click();
      await expect(page.getByTestId('session-title')).toHaveValue('');
      expect(errs).toEqual([]);
    });
  });
}

test.describe('P1.2 workout draft recovery 390px (Chrome emulation, not Safari/WebKit)', () => {
  test.use({ viewport: { width: 390, height: 844 } });

  test('save clears the draft exactly once: one session stored, no banner after reload, no duplicate on a second Save tap', async ({ page }) => {
    await boot(page);
    await typeWorkout(page, 'Row 5k (draft)');
    await page.reload();
    await page.getByTestId('today-workout-draft-continue').click();
    await page.getByTestId('session-save').click();
    await expect(page.getByTestId('ext-toast')).toContainText('Saved');
    expect(await draftRaw(page)).toBeNull();
    expect((await stored(page)).sessions.length).toBe(1);
    await page.reload();
    await expect(page.getByTestId('today-workout-draft')).toHaveCount(0);
  });

  test('midnight (Asia/Qatar): a draft started yesterday says so, keeps its own workout date and is never moved to today', async ({ page }) => {
    await boot(page, '2026-11-18T20:50:00.000Z'); // 23:50 Wed 18 Nov Qatar
    await typeWorkout(page, 'Late wall balls');
    await page.clock.setFixedTime(new Date('2026-11-18T21:10:00.000Z')); // 00:10 Thu 19 Nov Qatar
    await page.reload();
    await expect(page.getByTestId('today-workout-draft-day')).toContainText('Wed 18 Nov');
    await page.getByTestId('today-workout-draft-continue').click();
    await expect(page.getByTestId('session-date')).toHaveValue('2026-11-18');
    await expect(page.getByTestId('workout-draft-restored')).toContainText('18 Nov');
  });

  for (const [name, raw] of [['blocks with junk entries', JSON.stringify({ savedAt: NOW, ws: { title: 7, date: 'not-a-date', blocks: [null, 5, 'x'] } })],
    ['unreadable JSON', '{"savedAt":"2026-11-18T09:00:00.000Z","ws":{"blocks":['],
    ['oversized draft', JSON.stringify({ savedAt: NOW, ws: { title: 'big', notes: 'x'.repeat(300000), blocks: [] } })]]) {
    test(`invalid partial draft (${name}): the app still opens, nothing is restored silently, and the owner can discard it`, async ({ page }) => {
      const errs = await boot(page, NOW, { fn: (a) => localStorage.setItem(a[0], a[1]), arg: [KEY, raw] });
      await expect(page.getByTestId('today-workout-draft-invalid')).toContainText('could not be read');
      await page.getByTestId('tab-add').click(); await page.getByTestId('add-mode-workout').click();
      await expect(page.getByTestId('session-title')).toHaveValue('');
      await expect(page.getByTestId('workout-draft-restored')).toHaveCount(0);
      await page.getByTestId('tab-today').click();
      await page.getByTestId('today-workout-draft-discard').click();
      await page.getByTestId('today-workout-draft-discard-yes').click();
      expect(await draftRaw(page)).toBeNull();
      expect(errs).toEqual([]);
    });
  }

  test('revision awareness: an edit draft whose saved workout changed elsewhere is not silently saved over it; the owner chooses', async ({ page }) => {
    await boot(page, NOW, seedSaved);
    await page.getByTestId('tab-history').click();
    await page.getByTestId('history-session-edit').first().click();
    await page.getByTestId('session-notes').fill('my edit');
    await expect.poll(() => draftRaw(page)).not.toBeNull();
    // Another tab (or a restore) changes the saved record after this edit started.
    await page.evaluate(() => { const st = window.HyroxData.createStore(); const s = st.records('sessions')[0]; s.notes = 'changed in another tab'; const r = st.putRecord('sessions', s); if (!r.ok) throw new Error('seed'); });
    await page.reload();
    await page.getByTestId('today-workout-draft-continue').click();
    await page.getByTestId('session-save').click();
    await expect(page.getByTestId('session-conflict')).toContainText('changed');
    expect((await stored(page)).sessions[0].notes).toBe('changed in another tab');
    await page.getByTestId('session-conflict-load-saved').click();
    await expect(page.getByTestId('session-notes')).toHaveValue('changed in another tab');
    await page.getByTestId('session-notes').fill('my edit again');
    // A fresh edit based on the current version saves normally.
    await page.getByTestId('session-save').click();
    await expect(page.getByTestId('ext-toast')).toContainText('Saved');
    const s = await stored(page);
    expect(s.sessions.length).toBe(1);
    expect(s.sessions[0].notes).toBe('my edit again');
  });

  test('revision awareness: "keep my version" replaces the newer saved version only after an explicit choice; still one record', async ({ page }) => {
    await boot(page, NOW, seedSaved);
    await page.getByTestId('tab-history').click();
    await page.getByTestId('history-session-edit').first().click();
    await page.getByTestId('session-notes').fill('mine');
    await page.evaluate(() => { const st = window.HyroxData.createStore(); const s = st.records('sessions')[0]; s.notes = 'theirs'; st.putRecord('sessions', s); });
    await page.getByTestId('session-save').click();
    await expect(page.getByTestId('session-conflict')).toBeVisible();
    await page.getByTestId('session-conflict-keep-mine').click();
    await expect(page.getByTestId('ext-toast')).toContainText('Saved');
    const s = await stored(page);
    expect(s.sessions.length).toBe(1);
    expect(s.sessions[0].notes).toBe('mine');
  });

  test('restore/rollback removed the saved workout an edit draft belongs to: Save explains and asks before creating it again', async ({ page }) => {
    const ws = Object.assign({}, SAVED, { id: 's-gone', notes: 'edit of a workout that is no longer stored' });
    await boot(page, NOW, { fn: (a) => localStorage.setItem(a[0], JSON.stringify({ savedAt: a[1], ws: a[2] })), arg: [KEY, NOW, ws] });
    await page.getByTestId('today-workout-draft-continue').click();
    await page.getByTestId('session-save').click();
    await expect(page.getByTestId('session-conflict')).toContainText('no longer');
    expect(((await stored(page)) || {}).sessions || []).toEqual([]);
    await page.getByTestId('session-conflict-keep-mine').click();
    await expect(page.getByTestId('ext-toast')).toContainText('Saved');
    expect((await stored(page)).sessions.length).toBe(1);
  });

  test('two tabs: a new workout saved in one tab is not saved again from the other tab’s stale copy (duplicate prevention)', async ({ page, context }) => {
    await boot(page);
    await typeWorkout(page, 'Shared draft');
    const b = await context.newPage();
    await b.clock.setFixedTime(new Date(NOW));
    await b.goto('./');
    await b.getByTestId('today-workout-draft-continue').click();
    await expect(b.getByTestId('session-title')).toHaveValue('Shared draft');
    await page.getByTestId('session-save').click();
    await expect(page.getByTestId('ext-toast')).toContainText('Saved');
    await expect(b.getByTestId('session-other-tab')).toBeVisible();
    await b.getByTestId('session-save').click();
    expect((await stored(page)).sessions.length).toBe(1);
    expect(await draftRaw(page)).toBeNull();
    await b.getByTestId('session-other-tab-discard').click();
    await expect(b.getByTestId('session-title')).toHaveValue('');
    expect((await stored(page)).sessions.length).toBe(1);
    expect(await draftRaw(page)).toBeNull();
  });

  test('an older-format draft (no extra fields, as RC3 wrote it) is still offered and restored', async ({ page }) => {
    const ws = { date: '2026-11-18', title: 'RC3 draft', status: 'COMPLETED', modified: false, variant: 'ORIGINAL_60', planSlotId: null, planVersion: null, scheduledDate: null, durationMin: 20, rpe: null, notes: '', blocks: [] };
    await boot(page, NOW, { fn: (a) => localStorage.setItem(a[0], JSON.stringify({ savedAt: a[1], ws: a[2] })), arg: [KEY, NOW, ws] });
    await page.getByTestId('today-workout-draft-continue').click();
    await expect(page.getByTestId('session-title')).toHaveValue('RC3 draft');
    await expect(page.getByTestId('session-duration')).toHaveValue('20');
  });

  test('the draft never enters hyrox.v1 or the backup file, and a backup restore leaves an unsaved draft as an unsaved draft', async ({ page }) => {
    await boot(page);
    await typeWorkout(page, 'Backup check draft');
    const [dl] = await Promise.all([page.waitForEvent('download'), page.getByTestId('tab-settings').click().then(() => page.getByTestId('export-btn').click())]);
    const txt = require('fs').readFileSync(await dl.path(), 'utf8');
    expect(txt).not.toContain('Backup check draft');
    expect(txt).not.toContain('workout-draft');
    expect(await page.evaluate(() => localStorage.getItem('hyrox.v1') || '')).not.toContain('Backup check draft');
  });
});
