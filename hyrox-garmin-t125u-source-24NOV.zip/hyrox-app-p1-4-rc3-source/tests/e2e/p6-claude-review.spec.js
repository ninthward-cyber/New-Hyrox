'use strict';
// Claude Phase 6 independent review: estimate -> meal confirm guard and single-candidate choice.
// Chrome emulation, NOT Safari/WebKit. Synthetic data only. 390 and 320.
// FAILS on Grok fd37069: (1) "1 bowl rice" showed a frozen chicken rice bowl entree with numbers; (2) Confirm with an
// estimate on screen that was not added to the meal said only "every component needs a name" (or, when editing a meal,
// confirmed the older components under a different estimate); there was no way to dismiss an unwanted estimate.
const { test, expect } = require('@playwright/test');

const NOW = '2026-11-13T06:00:00.000Z';
const raw = (page) => page.evaluate(() => localStorage.getItem('hyrox.v1'));
const meals = (page) => page.evaluate(() => { const d = JSON.parse(localStorage.getItem('hyrox.v1') || '{}'); return d.meals || []; });

async function openMeal(page) {
  await page.clock.setFixedTime(new Date(NOW));
  await page.goto('./');
  await page.evaluate(() => localStorage.clear());
  await page.reload();
  await page.getByTestId('tab-add').click();
  await page.getByTestId('add-mode-meal').click();
  await page.getByTestId('meal-path-description').click();
}
async function runEstimate(page, text) {
  await page.getByTestId('meal-description').fill(text);
  await page.getByTestId('estimate-run').click();
  await expect(page.getByTestId('estimate-items')).toBeVisible({ timeout: 15000 });
}

for (const W of [390, 320]) {
  test.describe(`${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`claude ${W}: "1 bowl rice" is not counted until the owner chooses the one food offered`, async ({ page }) => {
      await openMeal(page);
      await runEstimate(page, '1 bowl rice');
      const item = page.getByTestId('estimate-item');
      await expect(item).toHaveAttribute('data-status', 'ambiguous');
      await expect(item.getByTestId('estimate-nutrients')).toHaveCount(0);
      await expect(item.getByTestId('estimate-ambiguous')).toContainText('Check the food above and choose it');
      await expect(page.getByTestId('estimate-totals')).toContainText('nothing matched yet');
      const sel = item.getByTestId('estimate-food');
      await expect(sel).toHaveValue('');
      await sel.selectOption('SR:173339');
      await expect(page.getByTestId('estimate-item').getByTestId('estimate-nutrients')).toContainText('kcal');
      expect(await raw(page)).toBeNull(); // choosing writes nothing
    });

    test(`claude ${W}: Confirm with an estimate not yet in the meal is refused with the fix named; Clear estimate unblocks manual entry`, async ({ page }) => {
      await openMeal(page);
      await runEstimate(page, '2 eggs, 1 cup rice');
      await expect(page.getByTestId('estimate-totals')).toContainText('348 kcal');
      for (const b of ['meal-confirm', 'meal-save-draft', 'meal-consumed-intent']) {
        await page.getByTestId(b).click();
        await expect(page.getByTestId('meal-error')).toContainText('the estimate above is not in the meal yet');
        await expect(page.getByTestId('meal-error')).toContainText('Use these estimates in the meal');
      }
      expect(await raw(page)).toBeNull();
      const clear = page.getByTestId('estimate-clear');
      expect((await clear.boundingBox()).height).toBeGreaterThanOrEqual(44);
      await clear.click();
      await expect(page.getByTestId('estimate-items')).toHaveCount(0);
      await expect(page.getByTestId('estimate-message')).toContainText('Estimate cleared');
      // manual path works again: the existing name rule applies, then a named manual component saves
      await page.getByTestId('meal-confirm').click();
      await expect(page.getByTestId('meal-error')).toContainText('every component needs a name');
      await page.getByTestId('component-name').first().fill('Eggs and rice');
      await page.getByTestId('meal-confirm').click();
      await expect.poll(async () => (await meals(page)).length).toBe(1);
      const m = (await meals(page))[0];
      expect(m.lifecycle).toBe('CONFIRMED');
      expect(m.components.every((c) => !c.provenance)).toBe(true);
      const sw = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
      expect(sw).toBeLessThanOrEqual(0);
    });

    test(`claude ${W}: apply -> confirm counts the estimate; editing an item after apply needs apply again`, async ({ page }) => {
      await openMeal(page);
      await runEstimate(page, '2 eggs');
      await page.getByTestId('estimate-apply').click();
      await expect(page.getByTestId('estimate-applied')).toBeVisible();
      // change the quantity after applying: the meal would no longer match what is on screen
      const qty = page.getByTestId('estimate-qty').first();
      await qty.fill('3'); await qty.press('Enter');
      await expect(page.getByTestId('estimate-nutrients').first()).toContainText('215 kcal');
      await expect(page.getByTestId('estimate-applied')).toHaveCount(0);
      await page.getByTestId('meal-confirm').click();
      await expect(page.getByTestId('meal-error')).toContainText('not in the meal yet');
      expect(await raw(page)).toBeNull();
      await page.getByTestId('estimate-apply').click();
      await page.getByTestId('meal-confirm').click();
      await expect.poll(async () => (await meals(page)).length).toBe(1);
      const m = (await meals(page))[0];
      expect(m.lifecycle).toBe('CONFIRMED');
      expect(m.components.map((c) => [c.kcal.value, c.kcal.state, c.provenance && c.provenance.fdcId])).toEqual([[215, 'ESTIMATED', 171287]]);
      await page.getByTestId('tab-today').click();
      await expect(page.getByTestId('glance-nutrition')).toContainText('215');
    });
  });
}
