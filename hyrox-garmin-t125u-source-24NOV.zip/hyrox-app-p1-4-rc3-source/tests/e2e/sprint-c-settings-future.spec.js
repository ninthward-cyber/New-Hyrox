'use strict';
// Sprint C: the five inactive integration stubs live in one collapsed "Advanced / Future integrations" section.
// Nothing is enabled, connected or navigable; the WORKING photo analysis and coach settings stay visible.
// Synthetic, empty data. CHROME EMULATION, NOT SAFARI/WEBKIT.
const { test, expect } = require('@playwright/test');
for (const W of [320, 390]) {
  test(`${W}px settings: future integrations are folded, plainly inactive, and do not hide working settings (Chrome emulation, not Safari/WebKit)`, async ({ page }) => {
    await page.setViewportSize({ width: W, height: 844 });
    const errs = []; page.on('pageerror', (e) => errs.push(e.message));
    await page.clock.setFixedTime(new Date('2026-11-18T09:00:00.000Z'));
    await page.goto('./');
    await page.evaluate(() => localStorage.clear());
    await page.reload();
    await page.getByTestId('tab-settings').click();
    const fold = page.getByTestId('integrations-fold');
    await expect(fold).toHaveCount(1);
    expect(await fold.evaluate((d) => d.tagName === 'DETAILS' && !d.open)).toBe(true);
    await expect(page.getByTestId('integrations-fold-summary')).toHaveText('Advanced / Future integrations (5, none active)');
    for (const id of ['owner-auth', 'cloud-sync', 'health-import', 'food-catalogue', 'text-ai']) await expect(page.getByTestId('integration-' + id)).toBeHidden();
    // Working features stay discoverable without opening anything.
    await expect(page.getByTestId('ai-settings')).toBeVisible();
    await expect(page.getByTestId('ai-provider-live')).toBeVisible();
    await expect(page.getByTestId('coach-card')).toBeVisible();
    // Keyboard: the summary is focusable and opens the section.
    await page.getByTestId('integrations-fold-summary').focus();
    await page.keyboard.press('Enter');
    expect(await fold.evaluate((d) => d.open)).toBe(true);
    for (const id of ['owner-auth', 'cloud-sync', 'health-import', 'food-catalogue', 'text-ai']) {
      const row = page.getByTestId('integration-' + id);
      await expect(row).toBeVisible();
      await expect(row).toContainText('Not active');
    }
    const txt = (await fold.innerText()).toLowerCase();
    expect(txt).not.toContain('connected');
    expect(txt).not.toContain('(stub)');
    expect(await fold.locator('button, a, input, select, textarea').count()).toBe(0);
    await expect(page.getByTestId('integration-text-ai')).toContainText('Photo analysis');
    await expect(page.getByTestId('integration-text-ai')).toContainText('works');
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
    // Stubs stay disabled in code: every interface still answers NOT_ACTIVATED and makes no request.
    const codes = await page.evaluate(async () => { const I = window.HyroxIntegrations; return Promise.all([I.get('owner-auth').signIn(), I.get('cloud-sync').push('{}'), I.get('health-import').fetchDaily(), I.get('food-catalogue').search('egg'), I.get('text-ai').estimate('egg')]).then((r) => r.map((x) => x.code)); });
    expect(codes).toEqual(Array(5).fill('NOT_ACTIVATED'));
    expect(errs).toEqual([]);
  });
}
