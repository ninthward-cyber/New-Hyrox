'use strict';
// P1.3-RC3 (owner-approved Command Center decisions 1, 3, 4 and 5, 23 Nov 2026), browser level: refused below-floor own
// targets, estimates SHOWN rounded to 50 kcal (display only), the provisional reference named next to a first suggestion,
// and the hold note's numerator/denominator. Also the CC validation item "cutoff across Qatar Monday midnight".
// Uses the shared synthetic fixtures. CHROME MOBILE EMULATION, NOT SAFARI/WEBKIT and not a physical iPhone.
const { test, expect } = require('@playwright/test');
const L = require('./p1-3-coach-lib');

const W95 = [{ id: 'w1', date: '2026-11-17', kg: 96, createdAt: '2026-11-17T05:00:00.000Z' }, { id: 'w2', date: '2026-11-19', kg: 95, createdAt: '2026-11-19T05:00:00.000Z' }, { id: 'w3', date: '2026-11-21', kg: 94, createdAt: '2026-11-21T05:00:00.000Z' }];
function seed(o) {
  o = o || {};
  const h = L.history(o.hist || { kgPerWeek: -0.45 });
  return L.seedOf(Object.assign({ weight: h.weight, meals: h.meals.concat([L.meal('m-today', '2026-11-23', 600)]), dayStates: h.dayStates, sessions: L.planDone(), ownerSettings: [L.settingsWith(o.coach || L.coachObj())] }, o.more || {}));
}

for (const W of [390, 320]) {
  test.describe(`P1.3-RC3 ${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`${W}: FAIL-FIRST — the starting estimate is shown rounded to 50 kcal with the assumed activity in words; the stored attribute, calculation and suggested target stay exact`, async ({ page }) => {
      await L.open(page, L.seedOf({ sessions: L.planDone(), weight: W95, ownerSettings: [L.settingsWith(L.coachObj())] }));
      await page.getByTestId('tab-settings').click();
      const a = page.getByTestId('coach-stage-a');
      await expect(a).toHaveAttribute('data-maintenance', '2643');
      await expect(a).toContainText('Starting estimate: maintenance about 2,650 kcal a day (resting about 1,800 kcal × activity 1.45, your assumed activity: “Some walking most days, plus regular training”).');
      await expect(a).toContainText('Shown rounded to the nearest 50 kcal.');
      await expect(page.getByTestId('coach-proposal-arith')).toContainText('Calculation (exact figures): Maintenance estimate 2643 kcal - 500');
      await expect(page.getByTestId('coach-proposal-line')).toContainText('2,143 kcal'); // what a Confirm would store
      await expect(page.getByTestId('coach-proposal-reference')).toContainText('the provisional reference of 2,400 kcal / protein 190 g (protein floor 170 g) stays in force');
      // confirming stores the exact suggested figure, not a rounded one
      await page.getByTestId('coach-proposal-review').click();
      await page.getByTestId('coach-confirm-ok').click();
      await expect(page.getByTestId('coach-confirm')).toHaveCount(0);
      const t = (await L.setRec(page)).nutritionCoach.target;
      expect([t.kcal, t.origin, t.inputs.maintenance]).toEqual([2143, 'COMPUTED', 2643]);
      // and with a target confirmed, the reference note is gone
      await expect(page.getByTestId('coach-proposal-reference')).toHaveCount(0);
      expect(page._errs).toEqual([]); expect(page._net).toEqual([]);
    });

    test(`${W}: FAIL-FIRST — the personal estimate is shown rounded to 50 kcal and says so; the stored attribute stays exact`, async ({ page }) => {
      const hst = L.history({ estDows: [6], fastDates: ['2026-11-03'] });
      await L.open(page, L.seedOf(Object.assign({ sessions: L.planDone(), ownerSettings: [L.settingsWith(L.coachObj())] }, hst)));
      await page.getByTestId('tab-settings').click();
      const b = page.getByTestId('coach-stage-b');
      await expect(b).toHaveAttribute('data-maintenance', '2690');
      await expect(b).toContainText('Personal estimate about 2,700 kcal a day (HIGH coverage; shown rounded to the nearest 50 kcal)');
      await expect(page.getByTestId('coach-proposal-line')).toContainText('2,190 kcal');
      expect(page._errs).toEqual([]);
    });

    test(`${W}: FAIL-FIRST — the Trends hold note shows not-logged / eligible planned sessions`, async ({ page }) => {
      await L.open(page, seed({ more: { sessions: [] } }));
      await page.getByTestId('tab-trends').click();
      await expect(page.locator('[data-testid="review-concern"][data-code="SESSION_LOG"]')).toContainText('5 of 5 eligible planned sessions last week are not logged (unknown, not counted as missed)');
      expect(page._errs).toEqual([]);
    });

    test(`${W}: GUARD (passes before and after) — across Qatar Monday midnight the review week moves from 9–15 Nov to 16–22 Nov on the next screen draw; no data is written`, async ({ page }) => {
      await L.open(page, seed(), '2026-11-22T20:59:30.000Z'); // Sun 22 Nov 23:59:30 Asia/Qatar
      const before = await page.evaluate(() => localStorage.getItem('hyrox.v1'));
      await page.getByTestId('tab-trends').click();
      await expect(page.getByTestId('review-week')).toContainText('Completed week Mon 9 Nov – Sun 15 Nov');
      await expect(page.getByTestId('review-week')).toContainText('Next review Mon 23 Nov.');
      await page.clock.setFixedTime(new Date('2026-11-22T21:00:30.000Z')); // Mon 23 Nov 00:00:30 Asia/Qatar
      await page.getByTestId('tab-today').click();
      await expect(page.getByTestId('coach-status')).toContainText('(week to Sun 22 Nov)');
      await page.getByTestId('tab-trends').click();
      await expect(page.getByTestId('review-week')).toContainText('Completed week Mon 16 Nov – Sun 22 Nov');
      await expect(page.getByTestId('review-week')).toContainText('Today is review day.');
      expect(await page.evaluate(() => localStorage.getItem('hyrox.v1'))).toBe(before);
      expect(page._errs).toEqual([]);
    });
  });
}
