'use strict';
// P5 restore-safety UI (Liya t69u): P4-O1 empty-backup second confirmation, P4-F02 prior-copy refusal,
// P4-F01 never "verified restorable" when the export check refuses. CHROME EMULATION, NOT SAFARI.
// Synthetic data only. Runs at 390 px and 320 px. Uses p5-contract-shim.js (CONTRACT.md) when the data
// layer predates Dawit's P5 build; with his build the real store is used (set P5_SHIM=force to emulate anyway).
const path = require('path');
const fs = require('fs');
if (fs.existsSync('/workspace/hyrox-p2/tools/node_modules/@playwright/test')) module.paths.unshift('/workspace/hyrox-p2/tools/node_modules');
const { test, expect } = require('@playwright/test');
const { p5ContractShim } = require('./p5-contract-shim');

const SHOTS = process.env.P5_SHOTS || path.join(__dirname, '..', 'out', 'liya-shots'); // Claude P5: was /workspace/hyrox-p5/results/liya-shots
const T = '2026-11-10T06:00:00.000Z';
const NOW = '2026-11-12T06:00:00.000Z';
const EMPTY = JSON.stringify({ app: 'hyrox-app', version: 2, exportedAt: T, weight: [], workouts: [], nutrition: [] });
const ONE = JSON.stringify({ app: 'hyrox-app', version: 2, exportedAt: T, weight: [{ id: 'w-syn-1', createdAt: T, date: '2026-11-10', kg: 79.5 }], workouts: [], nutrition: [] });

async function boot(page, opts = {}) {
  await page.addInitScript(p5ContractShim, { mode: process.env.P5_SHIM || 'auto', forceApply: opts.forceApply || null });
  await page.clock.setFixedTime(new Date(NOW));
  await page.goto('./');
  await page.evaluate((o) => {
    localStorage.clear();
    const st = window.HyroxData.createStore();
    if (o.seed === 'populated' || o.seed === 'duplicate') {
      st.addWeight({ date: '2026-11-10', kg: 80.2 });
      st.addWeight({ date: '2026-11-11', kg: 80.0 });
      st.addNutrition({ date: '2026-11-11', label: 'Synthetic oats', calories: 350, proteinG: 20 });
      st.putRecord('walks', { date: '2026-11-11', durationMin: 30, steps: 4000, notes: 'synthetic' });
    }
    if (o.seed === 'duplicate') { // duplicate stored ids: exported as saved, refused by this build's restore (Dawit REPRO C)
      const raw = JSON.parse(localStorage.getItem('hyrox.v1'));
      raw.weight.push({ id: 'w-syn-dup', createdAt: o.T, date: '2026-11-08', kg: 80.6 }, { id: 'w-syn-dup', createdAt: o.T, date: '2026-11-07', kg: 80.8 });
      localStorage.setItem('hyrox.v1', JSON.stringify(raw));
    }
    if (o.pendingSlot) { // an unfinished earlier restore: its pre-import copy differs from what is stored now
      localStorage.setItem('hyrox.v1.pre-import-backup', JSON.stringify({ kind: 'hyrox-pre-import', savedAt: o.T, restoreState: 'pending',
        raw: JSON.stringify({ version: 1, weight: [{ id: 'w-old', createdAt: o.T, date: '2026-11-01', kg: 81 }], workouts: [], nutrition: [] }) }));
    }
  }, { seed: opts.seed || 'none', pendingSlot: !!opts.pendingSlot, T });
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
  await page.getByTestId('tab-settings').click();
}
const snapshot = (page) => page.evaluate(() => { const o = {}; for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); o[k] = localStorage.getItem(k); } return o; });
async function pick(page, text, name = 'synthetic-backup.json') {
  await page.getByTestId('import-file').setInputFiles({ name, mimeType: 'application/json', buffer: Buffer.from(text) });
  await expect(page.getByTestId('import-preview')).toBeVisible();
}
async function noHScroll(page) {
  const m = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
  expect(m.sw, 'no horizontal scroll').toBeLessThanOrEqual(m.cw);
}
async function minTarget(loc, label) {
  const b = await loc.boundingBox();
  expect(b, label + ' visible').not.toBeNull();
  expect(b.height, label + ' height >= 44').toBeGreaterThanOrEqual(44);
  expect(b.width, label + ' width >= 44').toBeGreaterThanOrEqual(44);
}
const shot = (page, w, name) => page.screenshot({ path: path.join(SHOTS, `p5-${w}-${name}.png`), fullPage: false });

for (const W of [390, 320]) {
  test.describe(`${W}px (Chrome emulation, not Safari)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`P4-O1 ${W}: empty backup over populated device shows the danger block, counts, and needs the second confirmation`, async ({ page }) => {
      await boot(page, { seed: 'populated' });
      expect(await page.evaluate(() => window.__P5.shimmed), 'real P5 data layer in use unless P5_SHIM=force').toBe(process.env.P5_SHIM === 'force');
      const before = await snapshot(page);
      await pick(page, EMPTY);
      const warn = page.getByTestId('import-empty-warning');
      await expect(warn).toBeVisible();
      await expect(warn).toHaveAttribute('role', 'alert');
      await expect(page.getByTestId('import-empty-title')).toContainText('EMPTY BACKUP — THIS WILL REMOVE CURRENT ENTRIES');
      await expect(page.getByTestId('import-empty-title')).toBeFocused();
      await expect(page.getByTestId('import-empty-note')).toBeHidden();
      await expect(page.getByTestId('import-empty-text')).toContainText('replaces 4 entries on this device with nothing');
      const rows = await page.getByTestId('import-empty-row').evaluateAll((trs) => trs.map((tr) => [tr.dataset.key, ...[...tr.cells].map((c) => c.textContent)]));
      expect(rows).toEqual([['weight', 'Weight', '2', '0'], ['nutrition', 'Nutrition', '1', '0'], ['walks', 'Walks', '1', '0'], ['total', 'Total', '4', '0']]);
      const confirm = page.getByTestId('import-confirm');
      await expect(confirm).toBeDisabled();
      await expect(confirm).toHaveAttribute('aria-describedby', 'import-empty-hint');
      await page.getByTestId('import-empty-confirm-label').click();
      await expect(page.getByTestId('import-empty-confirm')).toBeChecked();
      await expect(confirm).toBeEnabled();
      await page.getByTestId('import-empty-confirm').uncheck();
      await expect(confirm).toBeDisabled();
      await minTarget(page.getByTestId('import-empty-confirm-label'), 'tickbox label');
      await minTarget(page.getByTestId('import-cancel'), 'cancel');
      await minTarget(confirm, 'confirm');
      await noHScroll(page);
      await warn.scrollIntoViewIfNeeded();
      await shot(page, W, 'empty-backup-warning');
      // Cancel writes nothing.
      await page.getByTestId('import-cancel').click();
      await expect(page.getByTestId('import-status')).toContainText('Nothing was changed');
      expect(await snapshot(page)).toEqual(before);
      expect(await page.evaluate(() => window.__P5.applyCalls.length)).toBe(0);
    });

    test(`P4-O1 ${W}: Escape, leaving the tab, a forced click without the tick, and reload all write nothing`, async ({ page }) => {
      await boot(page, { seed: 'populated' });
      const before = await snapshot(page);
      await pick(page, EMPTY);
      await page.keyboard.press('Escape');
      await expect(page.getByTestId('import-preview')).toBeHidden();
      await expect(page.getByTestId('import-file')).toBeFocused();
      expect(await snapshot(page)).toEqual(before);
      // Tick, leave Settings, come back: the tick is cleared and Replace is off again.
      await pick(page, EMPTY);
      await page.getByTestId('import-empty-confirm').check();
      await page.getByTestId('tab-today').click();
      await page.getByTestId('tab-settings').click();
      await expect(page.getByTestId('import-empty-confirm')).not.toBeChecked();
      await expect(page.getByTestId('import-confirm')).toBeDisabled();
      // Forcing the disabled button (devtools-style) still writes nothing: the click handler re-checks.
      await page.evaluate(() => { const b = document.getElementById('import-confirm'); b.disabled = false; b.click(); });
      expect(await page.evaluate(() => window.__P5.applyCalls.length)).toBe(0);
      expect(await snapshot(page)).toEqual(before);
      await page.reload();
      expect(await snapshot(page)).toEqual(before);
      // The data layer itself refuses an empty-over-populated restore without confirmEmptyReplace (writes nothing).
      const r = await page.evaluate((t) => { const st = window.HyroxData.createStore(); const p = st.previewImport(t).preview; return st.applyImport(t, { confirm: 'REPLACE', expectCurrent: p.current, expectCurrentExt: p.currentExt }); }, EMPTY);
      expect(r.code).toBe('empty_replace_not_confirmed');
      expect(await snapshot(page)).toEqual(before);
    });

    test(`P4-O1 ${W}: after both confirmations a legitimate empty restore works (confirmEmptyReplace:true sent)`, async ({ page }) => {
      await boot(page, { seed: 'populated' });
      await pick(page, EMPTY);
      await page.getByTestId('import-empty-confirm').check();
      await page.getByTestId('import-confirm').click();
      await expect(page.getByTestId('import-result')).toContainText('Restored 0 weight');
      const calls = await page.evaluate(() => window.__P5.applyCalls);
      expect(calls.length).toBe(1);
      expect(calls[0].confirm).toBe('REPLACE');
      expect(calls[0].confirmEmptyReplace).toBe(true);
      const after = await page.evaluate(() => JSON.parse(localStorage.getItem('hyrox.v1')));
      expect(after.weight.length + after.nutrition.length + (after.walks || []).length).toBe(0);
      await expect(page.getByTestId('import-empty-warning')).toBeHidden();
      await expect(page.getByTestId('import-empty-confirm')).not.toBeChecked();
    });

    test(`P4-O1 ${W}: empty backup on an empty device and a normal backup need no second confirmation`, async ({ page }) => {
      await boot(page, { seed: 'none' });
      await pick(page, EMPTY);
      await expect(page.getByTestId('import-empty-warning')).toBeHidden();
      await expect(page.getByTestId('import-empty-note')).toBeVisible();
      await expect(page.getByTestId('import-confirm')).toBeEnabled();
      await page.getByTestId('import-confirm').click();
      await expect(page.getByTestId('import-result')).toBeVisible();
      await pick(page, ONE);
      await expect(page.getByTestId('import-empty-warning')).toBeHidden();
      await expect(page.getByTestId('import-empty-note')).toBeHidden();
      await page.getByTestId('import-confirm').click();
      await expect(page.getByTestId('import-result')).toContainText('Restored 1 weight');
      const calls = await page.evaluate(() => window.__P5.applyCalls);
      expect(calls.map((c) => c.confirmEmptyReplace)).toEqual([undefined, undefined]);
    });

    test(`P4-O1 ${W}: data-layer refusal empty_replace_not_confirmed is shown plainly, nothing changed`, async ({ page }) => {
      const msg = 'Not restored: this empty backup would remove the entries on this device. Confirm the empty restore a second time.';
      await boot(page, { seed: 'populated', forceApply: { ok: false, code: 'empty_replace_not_confirmed', message: msg, errors: [], rolledBack: false, backupKey: null } });
      const before = await snapshot(page);
      await pick(page, EMPTY);
      await page.getByTestId('import-empty-confirm').check();
      await page.getByTestId('import-confirm').click();
      await expect(page.getByTestId('import-error')).toBeVisible();
      await expect(page.getByTestId('import-error-message')).toContainText('This empty backup would remove the entries on this device');
      await expect(page.getByTestId('import-status')).toContainText('Your data on this device was not changed');
      expect(await snapshot(page)).toEqual(before);
    });

    test(`P4-F02 ${W}: an unfinished earlier restore blocks restore early and the refusal is plain`, async ({ page }) => {
      await boot(page, { seed: 'populated', pendingSlot: true });
      const before = await snapshot(page);
      await expect(page.getByTestId('import-backup-note')).toContainText('the next restore will be refused');
      await expect(page.getByTestId('raw-recovery')).toBeVisible();
      await pick(page, ONE);
      await expect(page.getByTestId('import-prior-blocked')).toBeVisible();
      await expect(page.getByTestId('import-prior-blocked')).toContainText('Nothing will be changed');
      await expect(page.getByTestId('import-confirm')).toBeDisabled();
      await expect(page.getByTestId('import-confirm')).toHaveAttribute('aria-describedby', 'import-prior-blocked');
      await noHScroll(page);
      await page.getByTestId('import-prior-blocked').scrollIntoViewIfNeeded();
      await shot(page, W, 'prior-copy-blocked-preview');
      expect(await snapshot(page)).toEqual(before);
    });

    test(`P4-F02 ${W}: apply-time refusal prior_copy_unresolved (slot became pending after the preview) shows the data layer message and how to recover`, async ({ page }) => {
      await boot(page, { seed: 'populated' });
      await pick(page, ONE);
      await expect(page.getByTestId('import-prior-blocked')).toBeHidden();
      // e.g. another tab's restore stopped half-way after this preview was opened
      await page.evaluate((T) => localStorage.setItem('hyrox.v1.pre-import-backup', JSON.stringify({ kind: 'hyrox-pre-import', savedAt: T, restoreState: 'pending',
        raw: JSON.stringify({ version: 1, weight: [{ id: 'w-old', createdAt: T, date: '2026-11-01', kg: 81 }], workouts: [], nutrition: [] }) })), T);
      const before = await snapshot(page);
      await page.getByTestId('import-confirm').click();
      await expect(page.getByTestId('import-error')).toBeVisible();
      const r = await page.evaluate(() => window.__P5.applyCalls.length);
      expect(r).toBe(1);
      await expect(page.getByTestId('import-error-message')).not.toHaveText('');
      const shown = await page.getByTestId('import-error-message').innerText();
      if (process.env.P5_SHIM !== 'force') expect(shown).not.toMatch(/^SHIM/);
      await expect(page.getByTestId('import-error-detail')).toContainText('Download emergency raw copy');
      await expect(page.getByTestId('import-status')).toContainText('not changed');
      await expect(page.getByTestId('raw-recovery')).toBeVisible();
      await noHScroll(page);
      await page.getByTestId('import-error').scrollIntoViewIfNeeded();
      await shot(page, W, 'prior-copy-refusal');
      expect(await snapshot(page)).toEqual(before);
    });

    test(`P4-F02 ${W}: stubbed apply refusal shows Dawit's exact message text (test-only forced answer)`, async ({ page }) => {
      const msg = 'Not restored: a previous restore did not finish, and its pre-import copy is the only copy of your earlier data. Nothing was changed.';
      await boot(page, { seed: 'populated', forceApply: { ok: false, code: 'prior_copy_unresolved', message: msg, errors: [], rolledBack: false, backupKey: 'hyrox.v1.pre-import-backup' } });
      const before = await snapshot(page);
      await pick(page, ONE);
      await page.getByTestId('import-confirm').click();
      await expect(page.getByTestId('import-error-message')).toHaveText('A previous restore did not finish, and its pre-import copy is the only copy of your earlier data. Nothing was changed.');
      expect(await snapshot(page)).toEqual(before);
    });

    test(`P4-F01 ${W}: an export this build would refuse is NOT called restorable; the warning and raw copy show`, async ({ page }) => {
      await boot(page, { seed: 'duplicate' });
      const dl = page.waitForEvent('download');
      await page.getByTestId('export-btn').click();
      await dl;
      const box = page.getByTestId('export-not-restorable');
      await expect(box).toBeVisible();
      await expect(page.getByTestId('export-not-restorable-head')).toContainText('NOT a verified restorable backup');
      await expect(page.getByTestId('export-not-restorable-reason').first()).toContainText('w-syn-dup');
      await expect(page.getByTestId('raw-recovery')).toBeVisible();
      await expect(page.getByTestId('raw-recovery-btn')).toBeEnabled();
      await expect(page.getByTestId('export-not-restorable-raw')).toBeVisible();
      const txt = await page.locator('#panel-settings').innerText();
      expect(txt).not.toMatch(/verified restorable(?! backup\. Keep)/i);
      await noHScroll(page);
      await box.scrollIntoViewIfNeeded();
      await shot(page, W, 'export-not-restorable');
    });

    test(`P4-F01 ${W}: a clean export shows no not-restorable warning`, async ({ page }) => {
      await boot(page, { seed: 'populated' });
      const dl = page.waitForEvent('download');
      await page.getByTestId('export-btn').click();
      await dl;
      await expect(page.getByTestId('export-not-restorable')).toBeHidden();
      await expect(page.getByTestId('export-error')).toHaveText('');
    });
  });
}

test.describe('150% zoom proxy (Chrome emulation, not Safari)', () => {
  for (const W of [213, 260]) {
    test(`P4-O1 danger block readable without horizontal scroll at ${W} CSS px`, async ({ page }) => {
      await page.setViewportSize({ width: W, height: 560 });
      await boot(page, { seed: 'populated' });
      await pick(page, EMPTY);
      await expect(page.getByTestId('import-empty-warning')).toBeVisible();
      await noHScroll(page);
      const wide = await page.evaluate(() => { const vw = document.documentElement.clientWidth; return [...document.querySelectorAll('#import-preview *')].filter((e) => e.getBoundingClientRect().right > vw + 0.5).map((e) => e.tagName + '#' + e.id); });
      expect(wide).toEqual([]);
      await minTarget(page.getByTestId('import-empty-confirm-label'), 'tickbox label');
      await page.getByTestId('import-empty-warning').scrollIntoViewIfNeeded();
      await shot(page, W, 'zoom150-empty-backup-warning');
      await page.getByTestId('import-empty-rows').evaluate((e) => e.scrollIntoView({ block: 'start' }));
      await shot(page, W, 'zoom150-empty-backup-counts');
    });
  }
});
