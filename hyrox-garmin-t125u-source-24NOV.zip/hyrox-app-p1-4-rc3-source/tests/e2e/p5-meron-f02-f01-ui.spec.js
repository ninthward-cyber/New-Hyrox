'use strict';
// Meron adversarial P4-F02 / P4-F01 UI against the real data layer (no contract shim).
// Byte-exact localStorage comparisons. Chrome emulation, not Safari/WebKit.
const { test, expect } = require('@playwright/test');
const { boot, pick, snapshot, snapshotObj, ONE, PRE, T, shot } = require('./p5-meron-e2e-lib');

const PRIOR_APPLY_MSG = 'An earlier restore did not finish, and the only saved copy of your previous data is kept in this browser under hyrox.v1.pre-import-backup. A new restore would overwrite it, so nothing was changed. Save a raw recovery copy first and do not clear site data.';

test.describe('P4-F02 / P4-F01 adversarial UI (Chrome emulation, not Safari/WebKit)', () => {
  test('a pending pre-import slot shows the blocked message in full, writes nothing, and offers raw recovery', async ({ page }) => {
    await boot(page, { seed: 'populated', pendingSlot: true });
    const before = await snapshot(page);
    await expect(page.getByTestId('import-backup-note')).toContainText('the next restore will be refused');
    await expect(page.getByTestId('raw-recovery')).toBeVisible();
    await expect(page.getByTestId('raw-recovery-btn')).toBeEnabled();
    await pick(page, ONE);
    const blocked = page.getByTestId('import-prior-blocked');
    await expect(blocked).toBeVisible();
    const text = await blocked.innerText();
    expect(text).toMatch(/did not finish/i);
    expect(text).toMatch(/only copy/i);
    expect(text).toMatch(/Nothing will be changed/i);
    expect(text).toMatch(/Download emergency raw copy/i);
    await expect(page.getByTestId('import-confirm')).toBeDisabled();
    await page.getByTestId('import-confirm').click({ force: true });
    expect(await snapshot(page), 'forcing Replace on a blocked preview must write nothing').toBe(before);
    const dl = page.waitForEvent('download');
    await page.getByTestId('raw-recovery-btn').click();
    const file = await dl;
    expect(file.suggestedFilename()).toMatch(/RAW-RECOVERY/i);
    expect(await snapshot(page), 'raw recovery download is read-only').toBe(before);
  });

  test('apply-time prior_copy_unresolved (slot planted after preview) shows the data-layer message in full', async ({ page }) => {
    await boot(page, { seed: 'populated' });
    await pick(page, ONE);
    await expect(page.getByTestId('import-prior-blocked')).toBeHidden();
    await expect(page.getByTestId('import-confirm')).toBeEnabled();
    await page.evaluate(({ PRE, T }) => {
      localStorage.setItem(PRE, JSON.stringify({
        kind: 'hyrox-pre-import', savedAt: T, restoreState: 'pending',
        raw: JSON.stringify({ version: 1, weight: [{ id: 'w-old', createdAt: T, date: '2026-11-01', kg: 81 }], workouts: [], nutrition: [] }),
      }));
    }, { PRE, T });
    const before = await snapshot(page);
    await page.getByTestId('import-confirm').click();
    await expect(page.getByTestId('import-error')).toBeVisible();
    const shown = await page.getByTestId('import-error-message').innerText();
    expect(shown).toBe(PRIOR_APPLY_MSG);
    await expect(page.getByTestId('import-error-detail')).toContainText('Download emergency raw copy');
    await expect(page.getByTestId('import-status')).toContainText('not changed');
    await expect(page.getByTestId('raw-recovery')).toBeVisible();
    await expect(page.getByTestId('raw-recovery-btn')).toBeEnabled();
    expect(await snapshot(page)).toBe(before);
  });

  for (const kind of [
    { seed: 'duplicate', needle: /w-syn-dup|duplicate/i, label: 'duplicate ids' },
    { seed: 'dateskew', needle: /2027-06-01|future|date/i, label: 'date skew' },
    { seed: 'invalidkg', needle: /999|kg|weight/i, label: 'invalid classic kg' },
  ]) {
    test(`P4-F01: a non-restorable export (${kind.label}) is never called verified/restorable; reasons and raw recovery show`, async ({ page }) => {
      await boot(page, { seed: kind.seed });
      const beforeObj = await snapshotObj(page);
      const dl = page.waitForEvent('download');
      await page.getByTestId('export-btn').click();
      await dl;
      const box = page.getByTestId('export-not-restorable');
      await expect(box).toBeVisible();
      await expect(page.getByTestId('export-not-restorable-head')).toContainText('NOT a verified restorable backup');
      const reasons = await page.getByTestId('export-not-restorable-reason').allInnerTexts();
      expect(reasons.length, 'at least one reason must be listed').toBeGreaterThan(0);
      expect(reasons.join('\n'), kind.label + ' reason listed: ' + reasons.join(' | ')).toMatch(kind.needle);
      const panel = await page.locator('#panel-settings').innerText();
      expect(panel).not.toMatch(/verified restorable(?! backup)/i);
      await expect(page.getByTestId('raw-recovery')).toBeVisible();
      await expect(page.getByTestId('raw-recovery-btn')).toBeEnabled();
      await expect(page.getByTestId('export-not-restorable-raw')).toBeVisible();
      const afterObj = await snapshotObj(page);
      // P0 (22 Nov 2026, owner-authorised): a normal export leaves ONE note of its own - when a backup download was started,
      // and that this file was not restorable. It is outside the saved records; every stored key is still untouched.
      expect(Object.keys(afterObj).filter((k) => !(k in beforeObj)), 'the backup note is the only key an export may add').toEqual(['hyrox.backup-note']);
      expect(JSON.parse(afterObj['hyrox.backup-note']).restorable, 'the note must not call this file restorable').toBe(false);
      delete afterObj['hyrox.backup-note'];
      expect(afterObj, 'export must not rewrite stored keys').toEqual(beforeObj);
    });
  }

  test('P4-F01: a genuinely restorable export is not flagged as unrestorable', async ({ page }) => {
    await boot(page, { seed: 'populated' });
    const before = await snapshot(page);
    const chk = await page.evaluate(() => {
      const c = window.HyroxData.createStore().exportChecked();
      return { ok: c.ok, restorable: c.restorable, reasons: c.reasons };
    });
    expect(chk.ok && chk.restorable === true, 'seed must be restorable according to the data layer: ' + JSON.stringify(chk)).toBe(true);
    const dl = page.waitForEvent('download');
    await page.getByTestId('export-btn').click();
    await dl;
    await expect(page.getByTestId('export-not-restorable')).toBeHidden();
    await expect(page.getByTestId('export-error')).toHaveText('');
    const panel = await page.locator('#panel-settings').innerText();
    expect(panel).not.toMatch(/NOT a verified restorable backup/i);
    // The app does not print a positive "verified restorable" toast on a clean
    // export (P1: no general success line). Absence of the danger warning is the
    // official "this export is accepted" signal.
    // P0 (22 Nov 2026): the one key an export may add is its own backup note; every saved record is byte-identical.
    const afterClean = await snapshotObj(page);
    expect(JSON.parse(afterClean['hyrox.backup-note']).restorable).toBe(true);
    delete afterClean['hyrox.backup-note'];
    expect(JSON.stringify(Object.keys(afterClean).sort().map((k) => [k, afterClean[k]])), 'a clean export is read-only').toBe(before);
  });
});
