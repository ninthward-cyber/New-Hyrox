'use strict';
// P6 Meron readiness UI. Chrome emulation, not Safari/WebKit. 390x844. Synthetic data only.
// The Readiness *card* already names missing inputs — that is locked and must keep passing.
// The Today glance tile must name each missing input and link to its field (CONTRACT-P6.md v2
// glance-readiness-missing / glance-missing-<id>). The desired test auto-runs when the tile
// names sleep / soreness / resting HR; otherwise it skips with an explicit reason.
const { test, expect } = require('@playwright/test');
const { openWhy, openFullPlan } = require('./p8-open');

async function boot(page) {
  await page.clock.setFixedTime(new Date('2026-11-20T09:00:00.000Z'));
  await page.goto('./');
  await page.evaluate(() => localStorage.clear());
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
  // Phase 8: Today's detail sits under two closed folds; open them so the checks below still read the same elements.
  await openWhy(page); await openFullPlan(page);
  await page.getByTestId('tab-today').click();
}

test('the Readiness card names each missing input (sleep, soreness, resting HR) and offers Daily check-in', async ({ page }) => {
  await boot(page);
  const missing = page.getByTestId('readiness-missing');
  await expect(missing).toBeVisible();
  await expect(missing).toContainText('sleep');
  await expect(missing).toContainText('soreness');
  await expect(missing).toContainText('resting HR');
  await page.getByTestId('today-checkin').click();
  await expect(page.getByTestId('daily-sleepH')).toBeVisible();
  await expect(page.getByTestId('daily-soreness')).toBeVisible();
  await expect(page.getByTestId('daily-rhr')).toBeVisible();
});

test('the glance readiness tile currently counts unknowns and does not itself jump to a field', async ({ page }) => {
  await boot(page);
  const tile = page.getByTestId('glance-readiness');
  await expect(tile).toBeVisible();
  const text = await tile.innerText();
  // Characterization of today's UI (not a lock of the defect): it says "inputs unknown".
  // If the Phase 6 fix is present, this test still passes as long as the tile is visible.
  if (/input[s]? unknown/i.test(text)) {
    expect(text).toMatch(/input[s]? unknown/i);
    expect(text).not.toMatch(/sleep/i);
  }
});

test('desired: the glance readiness tile names each missing input and each links to its field', async ({ page }, testInfo) => {
  await boot(page);
  const tile = page.getByTestId('glance-readiness');
  await expect(tile).toBeVisible();
  const text = await tile.innerText();
  const namesEach = /sleep/i.test(text) && /soreness/i.test(text) && /resting HR/i.test(text);
  if (!namesEach) {
    testInfo.skip(true, 'The Today glance tile on this tree (p6/qa + p6/data b418faa only) still counts unknowns ("<n> inputs unknown") and has no per-input links. CONTRACT-P6.md v2 defines glance-readiness-missing and glance-missing-<id> (Liya, p6/ui), which are not on this data-layer tree. Skipped until the tile names each missing input and links to daily-sleepH / daily-soreness / daily-rhr.');
    return;
  }
  await expect(tile).toContainText(/sleep/i);
  await expect(tile).toContainText(/soreness/i);
  await expect(tile).toContainText(/resting HR/i);
  // Each named input is a control that jumps to the matching check-in field.
  for (const [label, field] of [['sleep', 'daily-sleepH'], ['soreness', 'daily-soreness'], ['resting HR', 'daily-rhr']]) {
    const link = tile.getByRole('link', { name: new RegExp(label, 'i') })
      .or(tile.getByRole('button', { name: new RegExp(label, 'i') }));
    await expect(link).toBeVisible();
    await link.click();
    await expect(page.getByTestId(field)).toBeVisible();
    await page.getByTestId('tab-today').click();
  }
});
