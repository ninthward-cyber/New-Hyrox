'use strict';
// Phase 12: Block 2 planner UI (Chrome emulation, not Safari/WebKit). Synthetic data only; the clock is fixed in Asia/Qatar.
// Covers: draft has no effect, options locked before 11 Dec and never pre-selected, both-increases confirm, approval +
// activation, duplicate activation, Asia/Qatar midnight 13/14 Dec, late start gap, block-scoped cascade, logging and
// skip/adjust into the block only, future-only revisions, ST0 step text, readiness unchanged, restore-preview warning,
// field-preserving settings writers (stale screen + damaged-settings replace) and a corrupt planBlocks value.
const path = require('path');
const fs = require('fs');
const { test, expect } = require('@playwright/test');

const SCREEN = process.env.P12_SCREENS || '/workspace/p12-screens';
try { fs.mkdirSync(SCREEN, { recursive: true }); } catch (e) { /* screenshots optional */ }
const Q = (iso) => new Date(iso); // ISO strings below carry +03:00 (Asia/Qatar)
const BID = 'b-20261214-aaaa';

async function boot(page, now, seed, arg) {
  page.on('dialog', (d) => d.accept());
  await page.clock.setFixedTime(Q(now));
  await page.goto('./');
  await page.evaluate(() => localStorage.clear());
  let out = null;
  if (seed) out = await page.evaluate(seed, arg === undefined ? null : arg);
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
  await expect(page.getByTestId('today-glance')).toBeVisible();
  return out;
}
async function setNow(page, now) { await page.clock.setFixedTime(Q(now)); await page.reload(); await expect(page.getByTestId('today-glance')).toBeVisible(); }
// Seeds one Block 2 (draft or activated) through the app's own engine + validated store.
const seedBlock = (o) => {
  const HD = window.HyroxData, HB = window.HyroxBlocks, st = HD.createStore();
  o = o || {};
  let r = HB.createDraft([], o.start || '2026-12-14', '2026-11-19', '2026-11-19T09:00:00.000Z', () => 0);
  if (!r.ok) throw new Error(r.text);
  if (o.active) { r = HB.activate(r.blocks, r.block.id, '2026-12-11', '2026-12-11T09:00:00.000Z', { approved: true }); if (!r.ok) throw new Error(r.text); }
  const rec = Object.assign({ id: HD.SETTINGS_ID, date: '2026-11-19' }, o.extra || {}, { planBlocks: r.blocks });
  const p = st.putRecord('ownerSettings', rec); if (!p.ok) throw new Error(JSON.stringify(p.errors));
  return r.block.id;
};
const stored = (page) => page.evaluate(() => JSON.parse(localStorage.getItem('hyrox.v1')));
const settingsRec = async (page) => { const s = await stored(page); return (s.ownerSettings || []).find((x) => x.id === 'app-settings'); };
async function openFold(page, fold, toggle) { const d = page.getByTestId(fold); await d.waitFor({ state: 'attached' }); if (!(await d.evaluate((e) => e.open))) await page.getByTestId(toggle).click(); }
const openPlanner = (page) => openFold(page, 'today-planner', 'today-planner-toggle');
const openFullPlan = (page) => openFold(page, 'today-fullplan', 'today-fullplan-toggle');
const noOverflow = async (page) => expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);

for (const W of [390, 320]) {
  test.describe(`P12 planner ${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: 844 } });

    test(`${W}: before 11 Dec a draft can be created and previewed, but options and activation are locked; the draft has no effect`, async ({ page }) => {
      await boot(page, '2026-11-19T12:00:00+03:00');
      const before = await page.getByTestId('today-card').innerText();
      await openPlanner(page);
      await expect(page.getByTestId('planner-b1-review')).toContainText('Block 1 review');
      await expect(page.getByTestId('planner-start').locator('option').first()).toHaveAttribute('value', '2026-12-14');
      expect(await page.getByTestId('planner-start').locator('option').evaluateAll((os) => os.map((o) => o.value).filter((v) => v < '2026-12-14'))).toEqual([]);
      await page.getByTestId('planner-create').click();
      await expect(page.getByTestId('planner-draft')).toBeVisible();
      await expect(page.getByTestId('planner-draft-label')).toHaveText('Draft — pending owner approval after 11 Dec');
      await page.getByTestId('planner-preview-toggle').click();
      await expect(page.getByTestId('planner-preview-day')).toHaveCount(20);
      await expect(page.getByTestId('planner-preview-closure')).toHaveCount(3);
      await expect(page.getByTestId('planner-rules')).toContainText('ST0');
      await expect(page.getByTestId('planner-options-locked')).toContainText('Options open on');
      for (const g of ['running', 'race', 'lifting']) await expect(page.getByTestId(`planner-opt-${g}-hold`)).toBeChecked();
      await expect(page.getByTestId('planner-opt-running-I1')).toBeDisabled();
      await expect(page.getByTestId('planner-opt-running-I1')).not.toBeChecked();
      await expect(page.getByTestId('planner-approve')).toBeDisabled();
      await expect(page.getByTestId('planner-activate')).toBeDisabled();
      await expect(page.getByTestId('planner-activate-status')).toContainText('Activation opens on');
      await noOverflow(page);
      await page.screenshot({ path: path.join(SCREEN, `p12-draft-locked-${W}.png`), fullPage: true });
      // the draft changes nothing anywhere
      expect(await page.getByTestId('today-card').innerText()).toBe(before);
      const rec = await settingsRec(page);
      expect(rec.planBlocks.length).toBe(1); expect(rec.planBlocks[0].state).toBe('DRAFT');
      expect(((await stored(page)).planEvents || []).length).toBe(0);
      await page.getByTestId('tab-add').click(); await page.locator('[data-mode="workout"]').click();
      expect(await page.getByTestId('session-slot').locator('option').evaluateAll((os) => os.filter((o) => o.value.startsWith('b-')).length)).toBe(0);
    });

    test(`${W}: on 11 Dec options open (none pre-selected), both increases need a confirm, approval + activation; no second activation`, async ({ page }) => {
      const id = await boot(page, '2026-12-11T19:00:00+03:00', seedBlock, {});
      await openPlanner(page);
      for (const g of ['running', 'race', 'lifting']) await expect(page.getByTestId(`planner-opt-${g}-hold`)).toBeChecked();
      await expect(page.getByTestId('planner-activate')).toBeDisabled();
      await page.getByTestId('planner-opt-running-I1').check();
      await page.getByTestId('planner-opt-lifting-S1').check();
      await expect(page.getByTestId('planner-both-warning')).toContainText('do not increase both running volume and lifting load');
      await page.getByTestId('planner-apply-options').click();
      await page.getByTestId('planner-preview-toggle').click(); // RC1 B-01: the approval is offered once the preview was opened
      await page.getByTestId('planner-approve').check();
      await expect(page.getByTestId('planner-activate-status')).toContainText('You chose both');
      await expect(page.getByTestId('planner-activate')).toBeDisabled();
      await page.getByTestId('planner-both-confirm').check();
      await page.getByTestId('planner-apply-options').click();
      await expect(page.getByTestId('planner-approve')).not.toBeChecked(); // new content needs a new approval
      await page.getByTestId('planner-approve').check();
      await expect(page.getByTestId('planner-activate')).toBeEnabled();
      await page.screenshot({ path: path.join(SCREEN, `p12-options-${W}.png`), fullPage: true });
      await page.getByTestId('planner-activate').click();
      await expect(page.getByTestId('planner-active')).toBeVisible();
      await expect(page.getByTestId('planner-active-state')).toContainText('starts Mon 14 Dec');
      await expect(page.getByTestId('planner-draft')).toHaveCount(0);
      const rec = await settingsRec(page);
      expect(rec.planBlocks[0].id).toBe(id); expect(rec.planBlocks[0].state).toBe('ACTIVATED');
      expect(rec.planBlocks[0].options).toMatchObject({ running: 'I1', lifting: 'S1', bothConfirmed: true });
      // a new draft can only start after this block (no overlap); Block 1 still owns 11 Dec
      expect(await page.getByTestId('planner-start').locator('option').evaluateAll((os) => os.map((o) => o.value))).not.toContain('2026-12-21');
      await expect(page.getByTestId('today-card')).toContainText('Week 4/4');
      await noOverflow(page);
      await page.screenshot({ path: path.join(SCREEN, `p12-activated-${W}.png`), fullPage: true });
    });

    test(`${W}: Asia/Qatar midnight — 23:59:59 on 13 Dec is Block 1, 00:00 on 14 Dec is Block 2 Week 1; ST0 step text; readiness unchanged`, async ({ page }) => {
      await boot(page, '2026-12-13T23:59:59+03:00', seedBlock, { active: true });
      await expect(page.getByTestId('today-card')).toContainText('Week 4/4');
      await expect(page.getByTestId('today-card')).not.toContainText('Block 2');
      await setNow(page, '2026-12-14T00:00:00+03:00');
      await expect(page.getByTestId('today-card')).toContainText('Mon 14 Dec · Block 2 · Week 1/4');
      await expect(page.getByTestId('today-card').getByTestId(`slot-${BID}-W1-MON`)).toContainText('Strength A');
      const rWith = await page.getByTestId('glance-readiness-text').innerText();
      await openFold(page, 'today-why', 'today-why-toggle');
      await expect(page.getByTestId('today-step-reference')).toContainText('no plan step reference goal in this block (ST0)');
      await expect(page.getByTestId('today-step-reference')).toContainText('10,000 steps/day is not assumed');
      await noOverflow(page);
      await page.screenshot({ path: path.join(SCREEN, `p12-today-b2-${W}.png`), fullPage: true });
      // readiness is plan-independent: same text without any block
      await page.evaluate(() => localStorage.clear()); await page.reload();
      expect(await page.getByTestId('glance-readiness-text').innerText()).toBe(rWith);
    });
  });
}

test.describe('P12 planner details 390px (Chrome emulation, not Safari/WebKit)', () => {
  test.use({ viewport: { width: 390, height: 844 } });

  test('end of Block 2: 23:59:59 on 10 Jan is Week 4, 00:00 on 11 Jan is no active block (no automatic rollover)', async ({ page }) => {
    await boot(page, '2027-01-10T23:59:59+03:00', seedBlock, { active: true });
    await expect(page.getByTestId('today-card')).toContainText('Block 2 · Week 4/4');
    await setNow(page, '2027-01-11T00:00:00+03:00');
    await expect(page.getByTestId('today-card')).toContainText('no active block');
    await expect(page.getByTestId('today-card')).not.toContainText('Block 2 · Week');
  });

  test('late start: gap days before a later Monday are not counted and not missed', async ({ page }) => {
    await boot(page, '2026-12-15T09:00:00+03:00', seedBlock, { active: true, start: '2026-12-21' });
    await expect(page.getByTestId('block-status')).toContainText('starts Mon 21 Dec');
    await expect(page.getByTestId('block-status')).toContainText('not counted and not missed');
    await setNow(page, '2026-12-21T09:00:00+03:00');
    await expect(page.getByTestId('today-card')).toContainText('Block 2 · Week 1/4');
  });

  test('Block 2 calendar: picker, possible closures flagged only, missed Monday cascade stored in the block only (Block 1 unaffected)', async ({ page }) => {
    await boot(page, '2026-12-15T09:00:00+03:00', seedBlock, { active: true });
    await openFullPlan(page);
    await expect(page.getByTestId('plan-block-picker')).toBeVisible();
    await expect(page.getByTestId('plan-calendar-b2')).toBeVisible();
    await expect(page.getByTestId('b2-possible-closure')).toContainText('Qatar National Day');
    await expect(page.getByTestId(`slot-${BID}-W1-FRI`).getByTestId('slot-status')).toHaveText('Not logged');
    await page.getByTestId('b2-cascade-missed_monday').click();
    await expect(page.getByTestId('b2-cascade-missed_monday')).toContainText('Undo');
    await expect(page.getByTestId('calendar-omitted')).toContainText('omitted by source rule (MISSED_MONDAY_CASCADE)');
    const s = await stored(page);
    expect((s.planEvents || []).length).toBe(0);
    expect(s.ownerSettings[0].planBlocks[0].events.map((e) => e.kind)).toEqual(['MISSED_MONDAY']);
    await page.screenshot({ path: path.join(SCREEN, 'p12-calendar-b2-390.png'), fullPage: true });
    await page.getByTestId('plan-block-b1').click();
    await expect(page.getByTestId('plan-calendar')).toBeVisible();
    await expect(page.getByTestId('calendar-omitted')).toHaveCount(0);
    await page.getByTestId(`plan-block-${BID}`).click();
    await page.getByTestId('b2-week-2').click();
    await expect(page.getByTestId('b2-cascade-missed_monday')).toBeDisabled(); // future week
  });

  test('logging a Block 2 session and skip + adjust week write to the block, never to legacy planEvents', async ({ page }) => {
    await boot(page, '2026-12-16T18:00:00+03:00', seedBlock, { active: true });
    await page.getByTestId('today-card').getByTestId(`log-slot-${BID}-W1-WED`).click();
    await expect(page.getByTestId('session-slot')).toHaveValue(`${BID}-W1-WED`);
    await page.getByTestId('session-status').selectOption('SKIPPED');
    await page.getByTestId('session-skip-confirm').check();
    await page.getByTestId('skip-adjust_week').check();
    await page.getByTestId('session-save').click();
    await expect(page.getByTestId('history-session').first()).toContainText(`planned ${BID}-W1-WED`);
    const s = await stored(page);
    expect((s.planEvents || []).length).toBe(0);
    expect(s.ownerSettings[0].planBlocks[0].events.map((e) => e.kind)).toEqual(['MISSED_WEDNESDAY']);
    expect(s.sessions[0]).toMatchObject({ planSlotId: `${BID}-W1-WED`, planVersion: 'b2-hold-1', skipDecision: 'ADJUST_WEEK', status: 'SKIPPED' });
    await page.getByTestId('tab-today').click();
    await openFullPlan(page);
    await expect(page.getByTestId('calendar-omitted')).toContainText('MISSED_WEDNESDAY_CASCADE');
  });

  test('revisions: future + unlogged only; planned rest is its own status; no owner-written deload; 20-slot count kept', async ({ page }) => {
    await boot(page, '2026-12-14T09:00:00+03:00', seedBlock, { active: true });
    await openPlanner(page);
    const opts = await page.getByTestId('planner-revise-slot').locator('option').evaluateAll((os) => os.map((o) => o.value));
    expect(opts).not.toContain(`${BID}-W1-MON`); // today is not revisable
    await page.getByTestId('planner-revise-slot').selectOption(`${BID}-W4-TUE`);
    await page.getByTestId('planner-revise-kind').selectOption('OWNER_TEXT');
    await expect(page.getByTestId('planner-revise-status')).toContainText('deload week cannot get owner-written content');
    await expect(page.getByTestId('planner-revise')).toBeDisabled();
    await page.getByTestId('planner-revise-slot').selectOption(`${BID}-W2-TUE`);
    await page.getByTestId('planner-revise-kind').selectOption('PLANNED_REST');
    await page.getByTestId('planner-revise').click();
    await expect(page.getByTestId('planner-revision')).toContainText('Planned rest');
    await expect(page.getByTestId('planner-active-summary')).toContainText('20 planned sessions');
    await expect(page.getByTestId('planner-active-summary')).toContainText('1 planned rest');
    const b = (await settingsRec(page)).planBlocks[0];
    expect(b.revisions.length).toBe(1); expect(b.slots.find((x) => x.id === `${BID}-W2-TUE`).prescription[0]).toContain('10 min warm-up'); // snapshot unchanged
    await page.screenshot({ path: path.join(SCREEN, 'p12-revise-390.png'), fullPage: true });
    await openFullPlan(page);
    await page.getByTestId('b2-week-2').click();
    await expect(page.getByTestId(`slot-${BID}-W2-TUE`).getByTestId('slot-status')).toHaveText('Planned rest (your choice)');
  });

  test('restore preview warns when a backup without Block 2 would replace a device that has it', async ({ page }) => {
    await boot(page, '2026-12-15T09:00:00+03:00', seedBlock, { active: true });
    const backup = await page.evaluate(() => { const o = JSON.parse(window.HyroxData.createStore().exportJSON()); delete o.ownerSettings[0].planBlocks; return JSON.stringify(o); });
    await page.getByTestId('tab-settings').click();
    await page.getByTestId('import-file').setInputFiles({ name: 'old-backup.json', mimeType: 'application/json', buffer: Buffer.from(backup) });
    await expect(page.getByTestId('import-preview-plan-blocks')).toContainText('Restoring removes Block 2 from this device');
    await page.screenshot({ path: path.join(SCREEN, 'p12-restore-warning-390.png'), fullPage: true });
  });

  test('Settings baselines save re-reads the stored record: plan blocks and saved foods written meanwhile are kept (stale screen)', async ({ page }) => {
    await boot(page, '2026-12-15T09:00:00+03:00', () => { const HD = window.HyroxData; HD.createStore().putRecord('ownerSettings', { id: HD.SETTINGS_ID, date: '2026-12-01', rhrBaselineBpm: 70 }); });
    await page.getByTestId('tab-settings').click();
    await expect(page.getByTestId('set-rhr-baseline')).toHaveValue('70');
    // another tab / writer adds plan blocks and a saved food while this screen is open
    await page.evaluate(() => {
      const HD = window.HyroxData, st = HD.createStore(), rec = JSON.parse(JSON.stringify(st.settings().record));
      rec.myFoods = [{ id: 'mf-1', name: 'Synthetic oats', source: 'OWNER', per: { kcal: { value: 380, state: 'KNOWN' } } }]; rec.favFoods = ['mf-1'];
      rec.planBlocks = [{ id: 'kept-as-is', note: 'synthetic' }]; rec.p113Future = { x: 1 };
      const r = st.putRecord('ownerSettings', rec); if (!r.ok) throw new Error(JSON.stringify(r.errors));
    });
    await page.getByTestId('set-rhr-baseline').fill('64');
    await page.getByTestId('set-save').click();
    const rec = await settingsRec(page);
    expect(rec.rhrBaselineBpm).toBe(64);
    expect(rec.planBlocks).toEqual([{ id: 'kept-as-is', note: 'synthetic' }]);
    expect(rec.favFoods).toEqual(['mf-1']); expect(rec.p113Future).toEqual({ x: 1 });
  });

  test('C-01 path (D9 fail-first, no planner needed): "Replace the saved settings" keeps planBlocks, foods and unrelated fields; only the damaged field is replaced', async ({ page }) => {
    await boot(page, '2026-12-15T09:00:00+03:00', () => {
      const HD = window.HyroxData;
      const r = HD.createStore().putRecord('ownerSettings', { id: HD.SETTINGS_ID, date: '2026-12-01', rhrBaselineBpm: 70,
        myFoods: [{ id: 'mf-1', name: 'Synthetic oats', source: 'OWNER', per: { kcal: { value: 380, state: 'KNOWN' } } }], favFoods: ['mf-1'],
        planBlocks: [{ id: 'synthetic-block', state: 'DRAFT' }], laterField: { keep: true } });
      if (!r.ok) throw new Error(JSON.stringify(r.errors));
      const raw = JSON.parse(localStorage.getItem('hyrox.v1')); raw.ownerSettings[0].rhrBaselineBpm = 'not-a-number'; localStorage.setItem('hyrox.v1', JSON.stringify(raw));
    });
    await page.getByTestId('tab-settings').click();
    await expect(page.getByTestId('owner-settings-damaged')).toBeVisible();
    await page.getByTestId('set-rhr-baseline').fill('66');
    await page.getByTestId('set-approve-correction').check();
    await page.getByTestId('set-save').click();
    await expect(page.getByTestId('owner-settings-damaged')).toHaveCount(0);
    const rec = await settingsRec(page);
    expect(rec.rhrBaselineBpm).toBe(66);
    expect(rec.planBlocks).toEqual([{ id: 'synthetic-block', state: 'DRAFT' }]);
    expect(rec.laterField).toEqual({ keep: true });
    expect(rec.favFoods).toEqual(['mf-1']); expect(rec.myFoods.length).toBe(1);
  });

  test('replacing a damaged settings record keeps plan blocks (and saved foods); a corrupt planBlocks value is reported, never overwritten', async ({ page }) => {
    await boot(page, '2026-12-15T09:00:00+03:00', seedBlock, { active: true, extra: { rhrBaselineBpm: 70 } });
    await page.evaluate(() => { const raw = JSON.parse(localStorage.getItem('hyrox.v1')); raw.ownerSettings[0].rhrBaselineBpm = 'not-a-number'; localStorage.setItem('hyrox.v1', JSON.stringify(raw)); });
    await page.reload();
    await expect(page.getByTestId('today-card')).toContainText('Block 2 · Week 1/4'); // still shown while settings need attention
    await page.getByTestId('tab-settings').click();
    await expect(page.getByTestId('owner-settings-damaged')).toContainText('Your training plan blocks are kept');
    await page.getByTestId('set-rhr-baseline').fill('66');
    await page.getByTestId('set-approve-correction').check();
    await page.getByTestId('set-save').click();
    const rec = await settingsRec(page);
    expect(rec.rhrBaselineBpm).toBe(66); expect(rec.planBlocks.length).toBe(1); expect(rec.planBlocks[0].state).toBe('ACTIVATED');
    // corrupt planBlocks value
    await page.evaluate(() => { const raw = JSON.parse(localStorage.getItem('hyrox.v1')); raw.ownerSettings[0].planBlocks = 'oops'; localStorage.setItem('hyrox.v1', JSON.stringify(raw)); });
    await page.reload();
    await openPlanner(page);
    await expect(page.getByTestId('planner-malformed')).toBeVisible();
    await expect(page.getByTestId('planner-create')).toHaveCount(0);
    expect((await settingsRec(page)).planBlocks).toBe('oops');
    await expect(page.getByTestId('today-card')).toContainText('no active block');
  });
});
