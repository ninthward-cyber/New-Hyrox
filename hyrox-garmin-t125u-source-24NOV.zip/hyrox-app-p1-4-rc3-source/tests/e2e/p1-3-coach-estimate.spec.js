'use strict';
// P1.3 Delivery C (CC execution order 23 Nov 2026, section 5): starting estimate, personal estimate, computed proposal with
// provisional screens, confirm-only changes. Synthetic data only, no network. CHROME MOBILE EMULATION, NOT SAFARI/WEBKIT.
const { test, expect } = require('@playwright/test');
const L = require('./p1-3-coach-lib');

async function toCoach(page) { await page.getByTestId('tab-settings').click(); await expect(page.getByTestId('coach-card')).toBeVisible(); }

for (const W of [390, 320]) {
  test.describe(`P1.3 Delivery C — computed estimate ${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`${W}: FAIL-FIRST — Stage A shows the approximate starting estimate with its inputs; Stage B not ready shows the exact shortfall`, async ({ page }) => {
      const w = [{ id: 'w1', date: '2026-11-17', kg: 96, createdAt: '2026-11-17T05:00:00.000Z' }, { id: 'w2', date: '2026-11-19', kg: 95, createdAt: '2026-11-19T05:00:00.000Z' }, { id: 'w3', date: '2026-11-21', kg: 94, createdAt: '2026-11-21T05:00:00.000Z' }];
      await L.open(page, L.seedOf({ sessions: L.planDone(), weight: w, ownerSettings: [L.settingsWith(L.coachObj())] }));
      await toCoach(page);
      const a = page.getByTestId('coach-stage-a');
      await expect(a).toHaveAttribute('data-maintenance', String(Math.round(1822.5 * 1.45)));
      await expect(a).toContainText('Starting estimate: maintenance about 2,650 kcal a day (resting about 1,800 kcal × activity 1.45'); await expect(a).toContainText('Approximate — not a measured maintenance'); // re-pointed for P1.3-RC3 (decision 5: shown rounded to 50 kcal; data-maintenance above stays exact)
      await expect(page.getByTestId('coach-stage-a-inputs')).toContainText('weight 95 kg (mean of 3 weigh-in days, Tue 17 Nov – Sat 21 Nov)');
      await expect(page.getByTestId('coach-stage-a-inputs')).toContainText('never added on top');
      await expect(page.getByTestId('coach-stage-b')).toHaveAttribute('data-ready', 'false');
      await expect(page.getByTestId('coach-stage-b')).toContainText('0 of 4 completed weeks qualify (3 needed)');
      await expect(page.getByTestId('coach-stage-b-week').last()).toHaveText('Mon 16 Nov – Sun 22 Nov: 0 complete days (4 needed); no complete weekend day (1 needed)'); // re-pointed by the independent review (C2: Monday-Sunday weeks)
      await expect(page.getByTestId('coach-proposal')).toHaveAttribute('data-state', 'AVAILABLE');
      await expect(page.getByTestId('coach-proposal-line')).toContainText('2,143 kcal · protein 190 g · fat 60 g · carbs');
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
      expect(page._errs).toEqual([]); expect(page._net).toEqual([]);
    });

    test(`${W}: FAIL-FIRST — confirming a computed suggestion stores origin COMPUTED with inputs and method; nothing changes before Confirm`, async ({ page }) => {
      const w = [{ id: 'w1', date: '2026-11-21', kg: 95, createdAt: '2026-11-21T05:00:00.000Z' }];
      await L.open(page, L.seedOf({ sessions: L.planDone(), weight: w, ownerSettings: [L.settingsWith(L.coachObj())] }));
      await toCoach(page);
      const before = await page.evaluate(() => localStorage.getItem('hyrox.v1'));
      await page.getByTestId('coach-proposal-review').click();
      await expect(page.getByTestId('coach-confirm-new')).toContainText('(computed starting estimate)');
      await expect(page.getByTestId('coach-confirm-inputs')).toContainText('Maintenance estimate 2643 kcal - 500 kcal');
      expect(await page.evaluate(() => localStorage.getItem('hyrox.v1'))).toBe(before);
      await page.getByTestId('coach-confirm-ok').click();
      await expect(page.getByTestId('coach-msg')).toContainText('Target confirmed');
      const t = (await L.setRec(page)).nutritionCoach.target;
      expect(t).toMatchObject({ kcal: 2143, proteinG: 190, fatG: 60, origin: 'COMPUTED', method: 'MSJ_ACTIVITY_GOAL', goal: 'LOSE_1' });
      expect(t.carbsG).toBe(Math.floor((2143 - 760 - 540) / 4));
      expect(t.inputs).toMatchObject({ stage: 'A', maintenance: 2643, resting: 1823, factor: 1.45, weightKg: 95, heightCm: 178, ageYears: 49, sexForEquation: 'MALE' });
      await expect(page.getByTestId('coach-current-origin')).toContainText('computed starting estimate, confirmed by you');
      // the same suggestion again is "nothing to change"
      await expect(page.getByTestId('coach-proposal-same')).toBeVisible();
      expect(page._errs).toEqual([]); expect(page._net).toEqual([]);
    });

    test(`${W}: FAIL-FIRST — 2 lb/week shows why no computed target is offered; own target remains possible`, async ({ page }) => {
      const w = [{ id: 'w1', date: '2026-11-21', kg: 95, createdAt: '2026-11-21T05:00:00.000Z' }];
      await L.open(page, L.seedOf({ sessions: L.planDone(), weight: w, ownerSettings: [L.settingsWith(L.coachObj({ goal: { id: 'LOSE_2', setAt: '2026-11-01' } }))] }));
      await toCoach(page);
      await expect(page.getByTestId('coach-proposal')).toHaveAttribute('data-state', 'GATED');
      const gates = await page.getByTestId('coach-proposal-gate').evaluateAll((els) => els.map((e) => e.getAttribute('data-gate')));
      expect(gates).toEqual(expect.arrayContaining(['G-RATE', 'G-DEFICIT', 'G-FLOOR']));
      await expect(page.getByTestId('coach-proposal-review')).toHaveCount(0);
      await expect(page.getByTestId('coach-own')).toBeVisible();
    });

    test(`${W}: FAIL-FIRST — stale weight or missing inputs: no estimate, the exact missing items, no invented values`, async ({ page }) => {
      const w = [{ id: 'w1', date: '2026-11-01', kg: 95, createdAt: '2026-11-01T05:00:00.000Z' }];
      await L.open(page, L.seedOf({ sessions: L.planDone(), weight: w, ownerSettings: [L.settingsWith(L.coachObj({ profile: Object.assign({}, L.PROFILE, { activity: null }) }))] }));
      await toCoach(page);
      await expect(page.getByTestId('coach-stage-a-needs')).toHaveText('Starting estimate needs: usual activity, a weigh-in in the last 14 days. Your latest weigh-in (2026-11-01) is more than 14 days old. Weigh in to get a starting estimate.');
      await expect(page.getByTestId('coach-stage-a')).toHaveCount(0);
      await expect(page.getByTestId('coach-proposal')).toHaveAttribute('data-state', 'NEEDS_INPUT');
    });

    test(`${W}: FAIL-FIRST — Stage B ready: aligned completed weeks, included/excluded/fast days and estimated share; the suggestion uses it`, async ({ page }) => {
      const hst = L.history({ estDows: [6], fastDates: ['2026-11-03'] });
      await L.open(page, L.seedOf(Object.assign({ sessions: L.planDone(), ownerSettings: [L.settingsWith(L.coachObj())] }, hst)));
      await toCoach(page);
      const b = page.getByTestId('coach-stage-b');
      await expect(b).toHaveAttribute('data-ready', 'true');
      await expect(b).toHaveAttribute('data-maintenance', '2690'); // one-decimal stored weights (the pure 2,685 case is in the unit test). Re-pointed by the independent review (C2): Monday-Sunday weeks give 2,690 instead of 2,675 - the 0.1 kg rounding of stored weights alone moves the estimate by about +/-15 kcal
      await expect(b).toContainText('HIGH coverage');
      await expect(page.getByTestId('coach-stage-b-days')).toContainText('Window Mon 26 Oct – Sun 22 Nov'); // re-pointed by the independent review (C2: Monday-Sunday weeks)
      await expect(page.getByTestId('coach-stage-b-days')).toContainText('Included: 27 complete days');
      await expect(page.getByTestId('coach-stage-b-days')).toContainText('1 confirmed fast day kept apart');
      await expect(page.getByTestId('coach-stage-b-days')).toContainText('Estimated share of the counted kcal: 15 %');
      await expect(page.getByTestId('coach-proposal-line')).toContainText('from the personal estimate): 2,190 kcal'); // re-pointed (C2): 2,690 - 500
      expect(page._errs).toEqual([]); expect(page._net).toEqual([]);
    });

    test(`${W}: FAIL-FIRST — a lower suggestion is HELD while weight is falling fast (no reduction on a rapid-loss concern)`, async ({ page }) => {
      const hst = L.history({ kgPerWeek: -1.3, d5Dows: [0, 1, 2] }); // personal estimate not ready, so the starting estimate (lower than the current target) is used
      const co = L.coachObj({ target: { kcal: 2500, proteinG: 190, fatG: null, carbsG: null, origin: 'OWNER_ENTERED', method: 'OWNER', effectiveDate: '2026-10-01', confirmedAt: '2026-10-01T06:00:00.000Z', reason: 'synthetic', version: 'coach-1', goal: 'LOSE_1', inputs: null, warnings: [], replaced: null } });
      co.history = [co.target];
      await L.open(page, L.seedOf(Object.assign({ sessions: L.planDone(), ownerSettings: [L.settingsWith(co)] }, hst)));
      await toCoach(page);
      await expect(page.getByTestId('coach-proposal')).toHaveAttribute('data-state', 'HELD');
      await expect(page.getByTestId('coach-proposal-held')).toContainText('faster than about 1 % a week for 2 weeks');
      await expect(page.getByTestId('coach-proposal-review')).toHaveCount(0);
      expect(page._errs).toEqual([]);
    });
  });
}
