'use strict';
// P1.3 Delivery D (CC execution order 23 Nov 2026, section 6): one compact coaching status line on Home's Nutrition summary and the
// weekly review in Trends. Synthetic data only, no network. CHROME MOBILE EMULATION, NOT SAFARI/WEBKIT.
const { test, expect } = require('@playwright/test');
const L = require('./p1-3-coach-lib');

const T = '2026-10-01T05:00:00.000Z';
const O = (v) => ({ state: 'OBSERVED', value: v });
const im = (v) => ({ state: 'OBSERVED', value: v, source: 'GARMIN_MANUAL' });
const daily = (date, extra) => Object.assign({ id: 'daily-' + date, date, createdAt: T }, extra || {});
const sess = (id, date, sets, extra) => Object.assign({ id, createdAt: date + 'T06:00:00.000Z', date, title: 'Synthetic strength', status: 'COMPLETED', modified: false, variant: 'ORIGINAL_60', durationMin: 50, rpe: 7, notes: '',
  blocks: sets.map((s) => ({ kind: 'strength_set', label: s[0], exercise: s[0], setType: 'WORKING', sets: 3, reps: s[2], loadKg: s[1], distanceM: null, durationSec: null, notes: '' })) }, extra || {});
const todayMeal = () => L.meal('m-today', '2026-11-23', 600);
// 3 of the 5 plan v2.1 sessions of 16-20 Nov completed (at least half; otherwise the sessions concern applies, as designed)
const planDone = () => [['MON', '16'], ['TUE', '17'], ['WED', '18']].map((x) => sess('p-' + x[0], '2026-11-' + x[1], [], { planSlotId: 'v2.1-W1-' + x[0], planVersion: 'v2.1', scheduledDate: '2026-11-' + x[1] }));
function seed(opts) {
  const o = opts || {};
  const h = L.history(o.hist || { kgPerWeek: -0.45 });
  const meals = h.meals.concat(o.noToday ? [] : [todayMeal()]);
  return L.seedOf(Object.assign({ weight: h.weight, meals, dayStates: h.dayStates, sessions: planDone(), ownerSettings: [L.settingsWith(o.coach === null ? null : (o.coach || L.coachObj()), o.set)] }, o.more || {}));
}
function contrast(fg, bg) {
  const lum = (c) => { const v = c.match(/\d+(\.\d+)?/g).slice(0, 3).map(Number).map((x) => { x /= 255; return x <= 0.03928 ? x / 12.92 : Math.pow((x + 0.055) / 1.055, 2.4); }); return 0.2126 * v[0] + 0.7152 * v[1] + 0.0722 * v[2]; };
  const a = lum(fg), b = lum(bg); return (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05);
}

for (const W of [390, 320]) {
  test.describe(`P1.3 Delivery D — status line and weekly review ${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`${W}: FAIL-FIRST — one status line inside Home's Nutrition section (text + icon, contrast >= 4.5); today's partial day stays "so far", never a failure`, async ({ page }) => {
      await L.open(page, seed());
      const nr = page.getByTestId('glance-nutrition');
      await expect(page.getByTestId('glance-nutrition-text')).toHaveText('Nutrition 600 kcal confirmed so far — not full day.');
      const line = nr.getByTestId('coach-status');
      await expect(line).toHaveCount(1);
      await expect(page.getByTestId('panel-today').getByTestId('coach-status')).toHaveCount(1);
      await expect(line).toHaveAttribute('data-level', 'GREEN');
      await expect(line).toHaveText('✓Coach · On track (week to Sun 22 Nov): On track: −0.4 kg a week over 2 weeks. Today’s food above is “logged so far”, not this result.');
      await expect(line.locator('.coach-status-icon')).toHaveAttribute('aria-hidden', 'true');
      const order = await nr.evaluate((el) => Array.from(el.querySelectorAll('[data-testid]')).map((x) => x.getAttribute('data-testid')));
      expect(order.indexOf('glance-macros')).toBeLessThan(order.indexOf('coach-status'));
      expect(order.indexOf('coach-status')).toBeLessThan(order.indexOf('today-add-meal'));
      const col = await line.evaluate((el) => { const s = getComputedStyle(el); return [s.color, s.backgroundColor]; });
      expect(contrast(col[0], col[1])).toBeGreaterThanOrEqual(4.5);
      // no coach card, profile or weekly review on Home
      await expect(page.getByTestId('panel-today').locator('[data-testid="coach-card"], [data-testid^="coach-profile"], [data-testid="trends-coach-review"]')).toHaveCount(0);
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
      expect(page._errs).toEqual([]); expect(page._net).toEqual([]);
    });

    test(`${W}: GUARD (passes before and after) — coach off: Home and Trends are unchanged (no status line, no weekly review)`, async ({ page }) => {
      await L.open(page, seed({ coach: L.coachObj({ enabled: false }) }));
      await expect(page.getByTestId('coach-status')).toHaveCount(0);
      await page.getByTestId('tab-trends').click();
      await expect(page.getByTestId('trends-coach-review')).toHaveCount(0);
      await expect(page.getByTestId('trends-body')).toBeVisible();
    });

    test(`${W}: FAIL-FIRST — red on repeated recovery flags (no reduction suggested); amber on rapid loss; gray without enough weigh-ins`, async ({ page }) => {
      const flags = ['2026-11-16', '2026-11-17', '2026-11-18'].map((d) => daily(d, { sleepH: O(5), soreness: O(7) }));
      await L.open(page, seed({ more: { daily: flags } }));
      let line = page.getByTestId('coach-status');
      await expect(line).toHaveAttribute('data-level', 'RED');
      await expect(line).toContainText('Check recovery');
      await expect(line).toContainText('No reduction is suggested');
      for (const lv of ['RED']) { const col = await line.evaluate((el) => { const s = getComputedStyle(el); return [s.color, s.backgroundColor]; }); expect(contrast(col[0], col[1])).toBeGreaterThanOrEqual(4.5, lv); }
      await L.open(page, seed({ hist: { kgPerWeek: -1.2 } }));
      line = page.getByTestId('coach-status');
      await expect(line).toHaveAttribute('data-level', 'AMBER');
      await expect(line).toContainText('Faster is not better here');
      let col = await line.evaluate((el) => { const s = getComputedStyle(el); return [s.color, s.backgroundColor]; }); expect(contrast(col[0], col[1])).toBeGreaterThanOrEqual(4.5);
      await L.open(page, seed({ hist: { weighDows: [1, 4] } }));
      line = page.getByTestId('coach-status');
      await expect(line).toHaveAttribute('data-level', 'GRAY');
      await expect(line).toContainText('Not enough data: 2 weigh-in days last week, 3 needed.');
      col = await line.evaluate((el) => { const s = getComputedStyle(el); return [s.color, s.backgroundColor]; }); expect(contrast(col[0], col[1])).toBeGreaterThanOrEqual(4.5);
      // Re-pointed by the independent review (C3): planned sessions with NOTHING logged are unknown, not skipped. They no longer
      // turn the status amber; they only hold a reduction (see p1-3-review-fixes.spec.js). Confirmed skips still give amber there.
      await L.open(page, seed({ more: { sessions: [] } }));
      await expect(page.getByTestId('coach-status')).toHaveAttribute('data-level', 'GREEN');
      await expect(page.getByTestId('coach-status')).not.toContainText('Fewer than half');
      expect(page._errs).toEqual([]);
    });

    test(`${W}: FAIL-FIRST — Trends weekly review: dated weight vs latest reading, waist + waist-to-height, comparable strength, coverage, Garmin minutes with day count, steps, planned vs completed, recovery, gaps`, async ({ page }) => {
      const dl = ['2026-11-16', '2026-11-17', '2026-11-18', '2026-11-19', '2026-11-20'].map((d, i) => daily(d, { steps: O(9000 + i * 100), intensityMin: im(30 + i), pain: O(2) })); // re-pointed into the Monday-Sunday review week (C2)
      const sessions = [sess('s1', '2026-11-03', [['Back squat', 100, 5]]), sess('s2', '2026-11-10', [['Back squat', 102.5, 5], ['Bench press', 60, 12]]),
        sess('s3', '2026-11-16', [['Back squat', 105, 6], ['Bench press', 70, 5]], { planSlotId: 'v2.1-W1-MON', planVersion: 'v2.1', scheduledDate: '2026-11-16' })].concat(planDone().slice(1));
      const body = [{ id: 'b1', createdAt: T, date: '2026-11-14', metric: 'waist_cm', state: 'OBSERVED', value: 89, source: 'manual' }];
      await L.open(page, seed({ more: { daily: dl, sessions, body } }));
      await page.getByTestId('tab-trends').click();
      const c = page.getByTestId('trends-coach-review');
      await expect(c.getByTestId('review-week')).toHaveText('Completed week Mon 16 Nov – Sun 22 Nov (Monday–Sunday, Asia/Qatar, the same weeks as the training plan). Today is review day. The current week is not judged until it is complete.'); // re-pointed by the independent review (C2: Monday-Sunday weeks)
      await expect(c.getByTestId('review-status')).toHaveAttribute('data-level', 'GREEN');
      await expect(c.getByTestId('review-weight-week')).toHaveCount(4);
      await expect(c.getByTestId('review-weight-week').last()).toContainText('Mon 16 Nov – Sun 22 Nov: weekly mean'); // re-pointed by the independent review (C2: Monday-Sunday weeks)
      await expect(c.getByTestId('review-weight-latest')).toContainText('on Sun 22 Nov — a single reading, not the trend.'); // re-pointed by the independent review (C2: Monday-Sunday weeks)
      await expect(c.getByTestId('review-waist-line')).toHaveText('Latest waist 89 cm on Sat 14 Nov.');
      await expect(c.getByTestId('review-whtr')).toContainText('Waist-to-height ratio 0.50 (informational only)');
      await expect(c.getByTestId('review-whtr')).toContainText('NICE guideline NG246 (rec. 1.9.14)');
      await expect(c.locator('[data-testid="review-strength-line"][data-result="UP"]')).toHaveText('Back squat: 105 kg × 6 vs 102.5 kg × 5 (higher).');
      await expect(c.locator('[data-testid="review-strength-line"][data-result="NOT_COMPARABLE"]')).toContainText('Bench press: 70 kg × 5 — not comparable');
      await expect(c.getByTestId('review-nutrition-line')).toContainText('7 of 7 days complete and quantified (D5), 2 of them at the weekend');
      await expect(c.getByTestId('review-intensity')).toHaveText('Garmin intensity minutes: 160 over 5 recorded days (as Garmin shows them, already weighted — not doubled again).');
      await expect(c.getByTestId('review-steps')).toHaveText('Steps: average 9,200 over 5 recorded days.');
      await expect(c.getByTestId('review-planned')).toHaveText('Planned sessions: 5 · completed 3 · partial 0 · skipped (logged as skipped) 0 · not logged (unknown) 2.'); // re-pointed (C3): skips and unknowns named for what they are
      await expect(c.getByTestId('review-recovery')).toContainText('highest pain recorded: 2/10 (pain recorded on 5 of 7 days)');
      const gaps = await c.getByTestId('review-gap').allTextContents();
      expect(gaps).toEqual(expect.arrayContaining(['intensity minutes missing on 2 days.', 'steps missing on 2 days.', 'pain not recorded on 2 days.']));
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
      expect(page._errs).toEqual([]); expect(page._net).toEqual([]);
    });

    test(`${W}: GUARD (passes before and after) — Garmin minutes, steps and workouts never change the suggested target`, async ({ page }) => {
      await L.open(page, seed());
      await page.getByTestId('tab-settings').click();
      const before = await page.getByTestId('coach-proposal-line').textContent();
      const dl = ['2026-11-15', '2026-11-16', '2026-11-17', '2026-11-18', '2026-11-19', '2026-11-20', '2026-11-21', '2026-11-22'].map((d) => daily(d, { steps: O(25000), intensityMin: im(300) }));
      await L.open(page, seed({ more: { daily: dl, sessions: planDone().concat([sess('s9', '2026-11-20', [['Back squat', 100, 5]])]) } }));
      await page.getByTestId('tab-settings').click();
      await expect(page.getByTestId('coach-proposal-line')).toHaveText(before);
      expect(page._errs).toEqual([]);
    });
  });
}
