'use strict';
// Phase 4 overnight QA (Meron): damaged-record approval tickbox, and bottom-nav
// hit-testing at 390px. Chrome mobile emulation, not Safari/WebKit. Synthetic data.
// NEW FILE. Real coverage defects are left failing and clearly named.
const { test, expect } = require('@playwright/test');
const { openWhy, openFullPlan } = require('./p8-open');

const T = '2026-11-17T06:00:00.000Z';
const NOW = '2026-11-19T06:00:00.000Z';
const D = '2026-11-19';
const O = (v) => ({ state: 'OBSERVED', value: v });

async function boot(page, data) {
  await page.clock.setFixedTime(new Date(NOW));
  await page.goto('./');
  await page.evaluate((d) => {
    localStorage.clear();
    if (d) localStorage.setItem('hyrox.v1', typeof d === 'string' ? d : JSON.stringify(d));
  }, data || null);
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
}
const rawText = (page) => page.evaluate(() => localStorage.getItem('hyrox.v1'));
const base = (extra) => Object.assign({
  version: 2,
  weight: [{ id: 'w1', createdAt: T, date: '2026-11-17', kg: 80 }],
  workouts: [], nutrition: [],
}, extra);
const badDaily = () => ({
  id: 'daily-' + D, createdAt: T, updatedAt: T, date: D,
  footPain: O(11), stairKneePain: O(1), sleepH: O(7),
  limp: { state: 'OBSERVED', value: false }, steps: O(8000), soreness: O(2), rhr: O(60),
});

test('approval tickbox starts unchecked, cannot be pre-set from the URL, and writes nothing until it is ticked', async ({ page }) => {
  await boot(page, base({ daily: [badDaily()] }));
  const before = await rawText(page);

  await page.clock.setFixedTime(new Date(NOW));
  await page.goto('./?approveCorrection=true&approveDamaged=true&approve=1#approveCorrection');
  await page.clock.setFixedTime(new Date(NOW));
  await expect(page.getByTestId('app-error')).toBeHidden();
  await page.getByTestId('tab-add').click();
  await page.getByTestId('add-mode-daily').click();
  const box = page.getByTestId('daily-approve-correction');
  await expect(box).toBeVisible();
  await expect(box).not.toBeChecked();
  await expect(page.getByTestId('daily-damaged')).toContainText('not valid');

  await page.getByTestId('daily-footPain').fill('2');
  await page.getByTestId('daily-submit').click();
  await expect(page.getByTestId('daily-error')).toContainText('Nothing was changed');
  expect(await rawText(page)).toBe(before);

  // Changing date away and back must not leave a previous tick in place (no replay).
  await box.check();
  await expect(box).toBeChecked();
  await page.getByTestId('daily-date').fill('2026-11-18');
  await page.getByTestId('daily-date').fill(D);
  await expect(page.getByTestId('daily-approve-correction')).not.toBeChecked();
  await page.getByTestId('daily-submit').click();
  await expect(page.getByTestId('daily-error')).toContainText('Nothing was changed');
  expect(await rawText(page)).toBe(before);

  await page.getByTestId('daily-approve-correction').check();
  await page.getByTestId('daily-footPain').fill('2');
  await page.getByTestId('daily-submit').click();
  await expect(page.getByTestId('ext-toast')).toContainText('Saved');
  const after = JSON.parse(await rawText(page));
  expect(after.daily[0].footPain).toEqual(O(2));
  expect(after.daily[0].sleepH).toEqual(O(7));
  expect(after.daily[0].steps).toEqual(O(8000));
});

test('Chrome emulation, not Safari/WebKit: every interactive control on every screen can be scrolled into view and is not covered by the fixed bottom nav at 390px', async ({ page }) => {
  // Seed enough synthetic data that History, Today and Settings show their full control sets,
  // including a damaged check-in (approval tickbox) and a legacy fractional walk (correction field).
  await boot(page, base({
    daily: [badDaily()],
    walks: [{ id: 'w-frac', createdAt: T, updatedAt: T, date: D, durationMin: 30, steps: 10.5 }],
    meals: [{
      id: 'm1', createdAt: T, updatedAt: T, date: D, label: 'Synthetic oats', source: 'MANUAL',
      lifecycle: 'CONFIRMED', confirmedAt: T,
      components: [{ name: 'Oats', role: 'MAIN', eatenFraction: 1, kcal: { state: 'ESTIMATED', value: 200 }, proteinG: { state: 'ESTIMATED', value: 8 }, carbsG: { state: 'ESTIMATED', value: 30 }, fatG: { state: 'ESTIMATED', value: 4 } }],
    }],
    sessions: [{
      id: 's1', createdAt: T, updatedAt: T, date: D, status: 'COMPLETED', modified: false,
      variant: 'NONE', title: 'Synthetic session', durationMin: 40, blocks: [],
    }],
    body: [{ id: 'b1', createdAt: T, updatedAt: T, date: D, metric: 'waist_cm', state: 'OBSERVED', value: 80, source: 'manual' }],
  }));

  const screens = [
    // Phase 8: Today keeps its detail under two closed folds; open both so every control inside them is still checked.
    { name: 'Today', setup: async () => { await page.getByTestId('tab-today').click(); await openWhy(page); await openFullPlan(page); } },
    { name: 'Add · Meal', setup: async () => { await page.getByTestId('tab-add').click(); await page.getByTestId('add-mode-meal').click(); } },
    { name: 'Add · Workout', setup: async () => { await page.getByTestId('tab-add').click(); await page.getByTestId('add-mode-workout').click(); } },
    { name: 'Add · Weight & waist', setup: async () => { await page.getByTestId('tab-add').click(); await page.getByTestId('add-mode-body').click(); } },
    { name: 'Add · Check-in (damaged, approval box visible)', setup: async () => { await page.getByTestId('tab-add').click(); await page.getByTestId('add-mode-daily').click(); } },
    { name: 'Add · Walk', setup: async () => { await page.getByTestId('tab-add').click(); await page.getByTestId('add-mode-walk').click(); } },
    { name: 'Add · Quick log', setup: async () => { await page.getByTestId('tab-add').click(); await page.getByTestId('add-mode-classic').click(); } },
    { name: 'History · All', setup: async () => { await page.getByTestId('tab-history').click(); await page.getByTestId('history-filter-all').click(); } },
    { name: 'History · Workouts', setup: async () => { await page.getByTestId('tab-history').click(); await page.getByTestId('history-filter-workouts').click(); } },
    { name: 'History · Meals', setup: async () => { await page.getByTestId('tab-history').click(); await page.getByTestId('history-filter-meals').click(); } },
    { name: 'History · Body & check-ins', setup: async () => { await page.getByTestId('tab-history').click(); await page.getByTestId('history-filter-body').click(); } },
    { name: 'History · Walks', setup: async () => { await page.getByTestId('tab-history').click(); await page.getByTestId('history-filter-walks').click(); } },
    { name: 'Trends', setup: async () => { await page.getByTestId('tab-trends').click(); } },
    { name: 'Settings', setup: async () => { await page.getByTestId('tab-settings').click(); } },
  ];

  const covered = [];
  for (const screen of screens) {
    await screen.setup();
    const controls = await page.evaluate(() => {
      const tabbar = document.querySelector('[data-testid="tabbar"]');
      const sel = 'button, a[href], input, select, textarea, [role="button"], [role="tab"]';
      return [...document.querySelectorAll(sel)]
        .filter((el) => {
          if (tabbar && tabbar.contains(el)) return false; // tab bar itself is tested separately
          const st = getComputedStyle(el);
          if (st.display === 'none' || st.visibility === 'hidden' || Number(st.opacity) === 0) return false;
          if (el.disabled) return false;
          const closed = el.closest('details:not([open])'); // a control inside a closed fold is not on screen (its summary is)
          if (closed && !(el.tagName === 'SUMMARY' && el.parentElement === closed)) return false;
          const r = el.getBoundingClientRect();
          return r.width > 0 && r.height > 0;
        })
        .map((el, i) => {
          if (!el.dataset.meronHit) el.dataset.meronHit = 'h' + i + '-' + Math.random().toString(36).slice(2, 7);
          return {
            hook: el.dataset.meronHit,
            testid: el.getAttribute('data-testid') || '',
            tag: el.tagName.toLowerCase(),
            type: el.getAttribute('type') || '',
            label: (el.getAttribute('aria-label') || el.innerText || el.id || '').replace(/\s+/g, ' ').slice(0, 80),
          };
        });
    });
    // Trends is display-only (no in-panel buttons or fields). Other screens must have controls.
    if (controls.length === 0) {
      expect(screen.name, 'only Trends is allowed to have no in-panel controls').toBe('Trends');
      continue;
    }

    for (const c of controls) {
      const loc = page.locator('[data-meron-hit="' + c.hook + '"]');
      await loc.evaluate((el) => el.scrollIntoView({ block: 'center', inline: 'nearest' }));
      const result = await page.evaluate((hook) => {
        const el = document.querySelector('[data-meron-hit="' + hook + '"]');
        const tabbar = document.querySelector('[data-testid="tabbar"]');
        const r = el.getBoundingClientRect();
        const bar = tabbar.getBoundingClientRect();
        const x = r.left + r.width / 2;
        const y = r.top + r.height / 2;
        // If the centre is still under the bar, try one more scroll so it sits above it.
        if (y + 4 >= bar.top) {
          const delta = y - (bar.top - 12);
          window.scrollBy(0, delta);
        }
        const r2 = el.getBoundingClientRect();
        const bar2 = tabbar.getBoundingClientRect();
        const x2 = r2.left + r2.width / 2;
        const y2 = r2.top + r2.height / 2;
        const top = document.elementFromPoint(x2, y2);
        const coveredByTabbar = !!(top && (top === tabbar || tabbar.contains(top)));
        const isSelf = !!(top && (top === el || el.contains(top) || top.contains(el) || (el.labels && [...el.labels].some((l) => l === top || l.contains(top)))));
        return {
          coveredByTabbar,
          isSelf,
          y: y2,
          barTop: bar2.top,
          hit: top ? (top.getAttribute('data-testid') || top.tagName) : null,
        };
      }, c.hook);
      const name = (c.testid || c.label || c.tag) + ' on ' + screen.name;
      if (result.coveredByTabbar || result.y + 4 >= result.barTop) {
        covered.push({ name, testid: c.testid, screen: screen.name, y: result.y, barTop: result.barTop, hit: result.hit });
      }
    }
  }

  // The tab bar's own five tabs must themselves be hittable at their centre.
  for (const id of ['tab-today', 'tab-add', 'tab-history', 'tab-trends', 'tab-settings']) {
    const hit = await page.evaluate((testid) => {
      const el = document.querySelector('[data-testid="' + testid + '"]');
      const r = el.getBoundingClientRect();
      const top = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
      return !!(top && (top === el || el.contains(top) || top.contains(el)));
    }, id);
    expect(hit, id + ' tab centre should be hittable').toBe(true);
  }

  if (covered.length) {
    expect.soft(covered, 'DEFECT: fixed bottom nav covers or intercepts these controls at 390px (Chrome emulation, not Safari/WebKit): ' +
      covered.map((c) => c.name).join('; ')).toEqual([]);
  }
  expect(covered, 'DEFECT: fixed bottom nav covers or intercepts interactive controls at 390px (Chrome emulation, not Safari/WebKit)').toEqual([]);
});
