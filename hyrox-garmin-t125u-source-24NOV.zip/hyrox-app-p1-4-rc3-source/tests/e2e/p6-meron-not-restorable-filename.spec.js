'use strict';
// P6 Meron lock: a backup this app would refuse is downloaded with NOT-RESTORABLE
// in its file name. Chrome emulation, not Safari/WebKit. 390x844. Synthetic data only.
// Must pass on baseline c5cdd73 and after Phase 6.
const { test, expect } = require('@playwright/test');

const T = '2026-11-10T06:00:00.000Z';
const NOW = '2026-11-12T06:00:00.000Z';
const W = (id, kg) => ({ id, createdAt: T, date: '2026-11-10', kg });

async function boot(page, data) {
  await page.clock.setFixedTime(new Date(NOW));
  await page.goto('./');
  await page.evaluate((d) => {
    localStorage.clear();
    if (d) localStorage.setItem('hyrox.v1', JSON.stringify(d));
  }, data || null);
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
}

test('unrestorable export file name is hyrox-backup-<today>-NOT-RESTORABLE.json; storage is unchanged', async ({ page }) => {
  await boot(page, { version: 1, weight: [W('w-syn-dup', 80), W('w-ok', 81), W('w-syn-dup', 82)], workouts: [], nutrition: [] });
  const before = await page.evaluate(() => localStorage.getItem('hyrox.v1'));
  await page.getByTestId('tab-settings').click();
  const [dl] = await Promise.all([page.waitForEvent('download'), page.getByTestId('export-btn').click()]);
  expect(dl.suggestedFilename()).toBe('hyrox-backup-2026-11-12-NOT-RESTORABLE.json');
  await expect(page.getByTestId('export-not-restorable-head')).toContainText('its name ends in NOT-RESTORABLE');
  expect(await page.evaluate(() => localStorage.getItem('hyrox.v1'))).toBe(before);
});

test('a restorable export keeps the normal file name hyrox-backup-<today>.json and does not say NOT-RESTORABLE', async ({ page }) => {
  await boot(page, { version: 1, weight: [W('w1', 80)], workouts: [], nutrition: [] });
  const before = await page.evaluate(() => localStorage.getItem('hyrox.v1'));
  await page.getByTestId('tab-settings').click();
  const [dl] = await Promise.all([page.waitForEvent('download'), page.getByTestId('export-btn').click()]);
  expect(dl.suggestedFilename()).toBe('hyrox-backup-2026-11-12.json');
  expect(dl.suggestedFilename()).not.toMatch(/NOT-RESTORABLE/);
  await expect(page.getByTestId('export-not-restorable')).toBeHidden();
  expect(await page.evaluate(() => localStorage.getItem('hyrox.v1'))).toBe(before);
});
