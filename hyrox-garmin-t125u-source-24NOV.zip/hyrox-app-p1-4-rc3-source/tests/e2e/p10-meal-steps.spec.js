'use strict';
// Phase 10: meal review (butter-chicken acceptance fixture), stale estimates, 1–3 photos in ONE request through the REAL
// server code (in-process, stubbed OpenAI, no network, no key), safe error details, Quick "Log steps" on Today, 320/390 px,
// fast navigation. Synthetic images and data only. CHROME EMULATION, NOT SAFARI/WEBKIT.
const fs = require('fs');
const path = require('path');
const { test, expect } = require('@playwright/test');

const FIX = path.join(__dirname, '..', 'fixtures');
const SHOTS = process.env.P10_SHOTS || '';
let H;
test.beforeAll(() => {
  const out = path.join(__dirname, '..', 'out', 'p9-helpers.bundle.cjs');
  const esbuild = process.env.P9_ESBUILD || (() => { try { return require.resolve('esbuild/bin/esbuild'); } catch (e) { return '/workspace/p9-tools/node_modules/.bin/esbuild'; } })();
  require('child_process').execFileSync(esbuild, [path.join(__dirname, '..', 'p9-helpers.mjs'), '--bundle', '--platform=node', '--format=cjs', '--log-level=error', '--define:import.meta.url=' + JSON.stringify(require('url').pathToFileURL(path.join(__dirname, '..', 'p9-helpers.mjs')).href), '--outfile=' + out]);
  H = require(out);
});

async function installApi(page, opts = {}) {
  const ctx = H.setup({ script: opts.script || (() => H.openaiOk()), env: opts.env || {}, clock: { t: Date.UTC(2026, 10, 16, 6, 0, 0) } });
  const seen = [];
  await page.route('**/api/food-photo/**', async (route) => {
    const r = route.request();
    seen.push({ url: r.url(), method: r.method(), body: r.postData() });
    if (opts.delayMs && r.method() === 'POST') await new Promise((res) => setTimeout(res, opts.delayMs));
    const req = new Request(r.url(), { method: r.method(), headers: r.headers(), body: r.method() === 'GET' ? undefined : r.postData() });
    const res = await ctx.handle(req, { ip: '203.0.113.5' });
    try { await route.fulfill({ status: res.status, headers: Object.fromEntries(res.headers), body: await res.text() }); } catch (e) { /* page moved on */ }
  });
  return { ctx, seen };
}
const NOW = '2026-11-18T09:00:00.000Z'; // 12:00 Asia/Qatar, 18 Nov
async function open(page, data, at = NOW) {
  await page.clock.setFixedTime(new Date(at));
  await page.goto('./');
  await page.evaluate((d) => { localStorage.clear(); if (d) localStorage.setItem('hyrox.v1', JSON.stringify(d)); }, data || null);
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
}
async function chooseLive(page) {
  await page.getByTestId('tab-settings').click();
  await page.getByTestId('ai-provider-live').check();
  await page.getByTestId('ai-owner-code').fill(H.OWNER_CODE);
  await page.getByTestId('ai-owner-code-save').click();
  await page.getByTestId('ai-live-check').click();
  await expect(page.getByTestId('ai-live-status')).toContainText('Ready');
}
async function toPhotoPath(page) {
  await page.getByTestId('tab-add').click();
  await page.getByTestId('add-mode-meal').click();
  await page.getByTestId('meal-path-photo_ai').click();
}
const posts = (seen) => seen.filter((s) => s.method === 'POST' && /analyze/.test(s.url)).map((s) => JSON.parse(s.body));
const stored = (page) => page.evaluate(() => JSON.parse(localStorage.getItem('hyrox.v1') || '{}'));
const noHorizontalScroll = async (page) => expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
const noPhotoBytes = async (page) => { const raw = (await page.evaluate(() => localStorage.getItem('hyrox.v1'))) || ''; expect(/data:image|imageBase64|\/9j\//.test(raw)).toBe(false); };
const shot = async (page, name) => { if (SHOTS) { fs.mkdirSync(SHOTS, { recursive: true }); await page.screenshot({ path: path.join(SHOTS, name + '.png'), fullPage: true }); } };
const F = (n) => path.join(FIX, n);
async function openSteps(page) {
  const b = page.getByTestId('today-log-steps');
  await expect(b).toBeVisible();
  if ((await b.getAttribute('aria-expanded')) !== 'true') await b.click();
  await expect(page.getByTestId('quick-steps')).toBeVisible();
}

for (const W of [390, 320]) {
  test.describe(`P10 ${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`${W}: butter chicken — note "all chicken eaten, 60% sauce" applied exactly once = 430 kcal (partial), never 250+300+180`, async ({ page }) => {
      await open(page);
      await page.getByTestId('tab-settings').click();
      await page.getByTestId('ai-provider-mock').check();
      await page.getByTestId('ai-mock-scenario').selectOption('butterChicken');
      await toPhotoPath(page);
      await page.getByTestId('meal-description').fill('butter chicken, all chicken eaten, 60% sauce');
      await page.getByTestId('photo-library-input').setInputFiles(F('p10-view-a.jpg'));
      await expect(page.getByTestId('photo-preview')).toHaveCount(1);
      await page.getByTestId('photo-privacy-ack').click();
      // Claude P10 review (owner decision 17 Nov 2026): amounts are not sent, food words are (was '“butter chicken”').
      await expect(page.getByTestId('photo-note-local')).toContainText('“butter chicken, chicken, sauce”'); // eaten amounts are not sent
      await page.getByTestId('photo-send-consent').check();
      await page.getByTestId('photo-send').click();
      await expect(page.getByTestId('component-row')).toHaveCount(3);
      // one review list, served basis, compact rows (details folded)
      await expect(page.getByTestId('meal-review-box')).toHaveCount(1);
      await expect(page.getByTestId('review-item')).toHaveCount(3);
      await expect(page.getByTestId('review-item').nth(0)).toContainText('(as served)');
      await expect(page.getByTestId('component-details')).toHaveCount(3);
      await expect(page.getByTestId('meal-overlap-warning')).toHaveCount(0);
      await expect(page.getByTestId('note-fraction')).toHaveCount(2);
      await expect(page.getByTestId('note-fraction').nth(0)).toContainText(/Chicken pieces.*: 100% eaten/);
      await expect(page.getByTestId('note-fraction').nth(1)).toContainText(/sauce.*: 60% eaten/);
      await expect(page.getByTestId('review-total')).toContainText('unknown'); // nothing applied yet: not counted
      await shot(page, `p10-butter-before-apply-${W}`);
      await page.getByTestId('meal-note-fractions-apply').click();
      await expect(page.getByTestId('note-fractions-applied')).toBeVisible();
      await expect(page.getByTestId('meal-note-fractions-apply')).toHaveCount(0); // cannot be applied twice
      await expect(page.getByTestId('component-eaten').nth(0)).toHaveValue('100');
      await expect(page.getByTestId('component-eaten').nth(1)).toHaveValue('60');
      await expect(page.getByTestId('review-total')).toContainText('430 kcal');
      await expect(page.getByTestId('review-total')).toContainText('partial');
      await expect(page.getByTestId('review-total')).not.toContainText('730');
      // changing only the eaten amount in the note: no stale warning, no new analysis
      await page.getByTestId('meal-description').fill('butter chicken, all chicken eaten, 40% sauce');
      await expect(page.getByTestId('photo-estimate-stale')).toHaveCount(0);
      await page.getByTestId('meal-note-fractions-apply').click();
      await expect(page.getByTestId('review-total')).toContainText('370 kcal');
      // the meal-level amount covers only the unseen ghee; it never multiplies the item amounts
      await page.getByTestId('meal-eaten-100').click();
      await expect(page.getByTestId('review-total')).toContainText('370 kcal');
      await noHorizontalScroll(page);
      await shot(page, `p10-butter-applied-${W}`);
      await page.getByTestId('meal-confirm').click();
      const meal = (await stored(page)).meals[0];
      expect(meal.lifecycle).toBe('CONFIRMED');
      expect(meal.components.map((c) => c.eatenFraction)).toEqual([1, 0.4, null]);
      await noPhotoBytes(page);
      await page.getByTestId('tab-today').click();
      await expect(page.getByTestId('today-subtotal')).toContainText('370');
    });

    test(`${W}: stale estimate — changing the food words or the photos marks it; Confirm is refused until re-analysed or kept as mine`, async ({ page }) => {
      await open(page);
      await page.getByTestId('tab-settings').click();
      await page.getByTestId('ai-provider-mock').check();
      await toPhotoPath(page);
      await page.getByTestId('meal-description').fill('chicken and rice');
      await page.getByTestId('photo-library-input').setInputFiles(F('p10-view-a.jpg'));
      await page.getByTestId('photo-privacy-ack').click();
      await page.getByTestId('photo-send-consent').check();
      await page.getByTestId('photo-send').click();
      await expect(page.getByTestId('component-row')).toHaveCount(3);
      await page.getByTestId('component-kcal').nth(0).fill('200'); // owner edit
      await page.getByTestId('meal-description').fill('chicken and rice, ate half');
      await expect(page.getByTestId('photo-estimate-stale')).toHaveCount(0);
      await page.getByTestId('meal-description').fill('lamb and rice, ate half');
      await expect(page.getByTestId('photo-estimate-stale')).toBeVisible();
      await page.getByTestId('meal-eaten-50').click();
      await page.getByTestId('meal-confirm').click();
      await expect(page.getByTestId('meal-error')).toBeVisible();
      expect((await stored(page)).meals || []).toEqual([]);
      await page.getByTestId('meal-description').fill('chicken and rice, ate half');
      await expect(page.getByTestId('photo-estimate-stale')).toHaveCount(0);
      // adding a photo also makes it stale
      await page.getByTestId('photo-library-input').setInputFiles(F('p10-view-b.jpg'));
      await expect(page.getByTestId('photo-preview')).toHaveCount(2);
      await expect(page.getByTestId('photo-estimate-stale')).toBeVisible();
      await page.getByTestId('photo-stale-keep').click();
      await expect(page.getByTestId('photo-estimate-stale')).toHaveCount(0);
      await expect(page.getByTestId('component-kcal').nth(0)).toHaveValue('200'); // edits kept
      await page.getByTestId('meal-confirm').click();
      const meal = (await stored(page)).meals[0];
      expect(meal.lifecycle).toBe('CONFIRMED');
      expect(meal.components[0].kcal.value).toBe(200);
      expect(meal.ai.userCorrected).toBe(true);
      await noPhotoBytes(page);
    });

    test(`${W}: 1–3 photos as ONE consented request through the real server; 4th refused; duplicate refused; labels and order kept`, async ({ page }) => {
      const { ctx, seen } = await installApi(page);
      await open(page);
      await chooseLive(page);
      await toPhotoPath(page);
      await page.getByTestId('photo-library-input').setInputFiles([F('p10-view-a.jpg'), F('p10-view-b.jpg'), F('p10-view-c.jpg'), F('synthetic-food-exif.jpg')]);
      await expect(page.getByTestId('photo-preview')).toHaveCount(3);
      await expect(page.getByTestId('photo-status')).toContainText('3');
      await expect(page.getByTestId('photo-count')).toContainText('3 of 3');
      await expect(page.getByTestId('photo-sanitized')).toHaveCount(3);
      await page.getByTestId('photo-discard').nth(2).click();
      await expect(page.getByTestId('photo-preview')).toHaveCount(2);
      await page.getByTestId('photo-library-input').setInputFiles(F('p10-view-a.jpg'));
      await expect(page.getByTestId('photo-status')).toContainText('already');
      await expect(page.getByTestId('photo-preview')).toHaveCount(2);
      await page.getByTestId('photo-library-input').setInputFiles(F('p10-view-c.jpg'));
      await expect(page.getByTestId('photo-preview')).toHaveCount(3);
      await page.getByTestId('photo-label').nth(0).selectOption('BEFORE');
      await page.getByTestId('photo-label').nth(1).selectOption('AFTER');
      await page.getByTestId('photo-label').nth(2).selectOption('EXTRA_DISH');
      await page.getByTestId('photo-privacy-ack').click();
      await expect(page.getByTestId('photo-box')).toContainText('THESE 3 photos');
      await expect(page.getByTestId('photo-send')).toHaveText('Analyze 3 photos');
      await expect(page.getByTestId('photo-send')).toBeDisabled();
      expect(posts(seen)).toHaveLength(0); // nothing before consent
      await page.getByTestId('photo-send-consent').check();
      await noHorizontalScroll(page);
      await shot(page, `p10-three-photos-${W}`);
      await page.getByTestId('photo-send').click();
      await expect(page.getByTestId('component-row')).toHaveCount(3);
      const p = posts(seen);
      expect(p).toHaveLength(1);
      expect(p[0].images.map((i) => i.label)).toEqual(['BEFORE', 'AFTER', 'EXTRA_DISH']);
      expect(ctx.fetchStub.calls).toHaveLength(1);
      const content = ctx.fetchStub.calls[0].body.input[0].content;
      expect(content.filter((c) => c.type === 'input_image')).toHaveLength(3);
      await page.getByTestId('meal-eaten-100').click();
      await page.getByTestId('meal-confirm').click();
      expect((await stored(page)).meals[0].lifecycle).toBe('CONFIRMED');
      await noPhotoBytes(page);
    });

    test(`${W}: photos keep the order they were chosen in; one unreadable file in a multi-select clears the set but not the typed draft`, async ({ page }) => {
      await installApi(page);
      await open(page);
      await chooseLive(page);
      await toPhotoPath(page);
      await page.getByTestId('meal-description').fill('rice and dal');
      await page.getByTestId('photo-library-input').setInputFiles([F('p10-over-1600.jpg'), F('p10-view-a.jpg'), F('p10-view-c.jpg')]);
      await expect(page.getByTestId('photo-preview')).toHaveCount(3);
      const alts = await page.getByTestId('photo-preview').evaluateAll((els) => els.map((e) => e.naturalWidth + 'x' + e.naturalHeight));
      expect(alts[1]).toBe('640x480'); expect(alts[2]).toBe('600x600'); // chosen order, not encode-finish order
      await page.getByTestId('photo-discard').nth(0).click();
      await page.getByTestId('photo-discard').nth(0).click();
      await page.getByTestId('photo-library-input').setInputFiles([{ name: 'b.jpg', mimeType: 'image/jpeg', buffer: fs.readFileSync(F('p10-view-b.jpg')) }, { name: 'bad.jpg', mimeType: 'image/jpeg', buffer: Buffer.from('not an image') }]);
      await expect(page.getByTestId('photo-status')).toContainText('could not be read');
      await page.waitForTimeout(500);
      await expect(page.getByTestId('photo-preview')).toHaveCount(0);
      await expect(page.getByTestId('photo-send')).toHaveCount(0);
      await expect(page.getByTestId('meal-description')).toHaveValue('rice and dal');
    });

    test(`${W}: a provider failure shows a plain action + safe owner details; retrying the same photos reuses the request id`, async ({ page }) => {
      const { ctx, seen } = await installApi(page, { script: (c, n) => n === 1 ? { status: 401, body: { error: { message: 'Incorrect API key sk-LEAKME provided', type: 'invalid_request_error', code: 'invalid_api_key' } } } : n === 2 ? { status: 500, body: { error: { message: 'boom', type: 'server_error' } } } : H.openaiOk() });
      await open(page);
      await chooseLive(page);
      await toPhotoPath(page);
      await page.getByTestId('photo-library-input').setInputFiles([F('p10-view-a.jpg'), F('p10-view-b.jpg')]);
      await expect(page.getByTestId('photo-preview')).toHaveCount(2);
      await page.getByTestId('photo-privacy-ack').click();
      await page.getByTestId('photo-send-consent').check();
      await page.getByTestId('photo-send').click();
      await expect(page.getByTestId('photo-status')).toContainText('OPENAI_API_KEY');
      await expect(page.getByTestId('photo-status')).toContainText('manually');
      await page.getByTestId('photo-error-details').locator('summary').click();
      await expect(page.getByTestId('photo-error-diag')).toContainText('KEY_INVALID');
      await expect(page.getByTestId('photo-error-diag')).toContainText('401');
      await expect(page.getByTestId('photo-error-diag')).toContainText('invalid_api_key');
      await expect(page.getByTestId('photo-box')).not.toContainText('LEAKME');
      await expect(page.getByTestId('photo-box')).not.toContainText('Incorrect API key');
      await page.getByTestId('photo-send-consent').check();
      await page.getByTestId('photo-send').click();
      await expect(page.getByTestId('photo-status')).toContainText('had a problem');
      await expect(page.getByTestId('photo-error-diag')).toContainText('PROVIDER_DOWN');
      await page.getByTestId('photo-send-consent').check();
      await page.getByTestId('photo-send').click();
      await expect(page.getByTestId('component-row')).toHaveCount(3);
      const p = posts(seen);
      expect(p).toHaveLength(3);
      expect(new Set(p.map((x) => x.requestId)).size).toBe(1); // same photos + note -> same id (failed attempts are not billed)
      expect(ctx.logs.join('\n')).not.toMatch(/LEAKME|Incorrect API key|imageBase64|\/9j\//);
    });

    test(`${W}: fast navigation during an analysis neither crashes, duplicates the call, nor saves anything`, async ({ page }) => {
      const { seen } = await installApi(page, { delayMs: 1500 });
      await open(page);
      await chooseLive(page);
      await toPhotoPath(page);
      await page.getByTestId('photo-library-input').setInputFiles([F('p10-view-a.jpg'), F('p10-view-b.jpg')]);
      await page.getByTestId('photo-privacy-ack').click();
      await page.getByTestId('photo-send-consent').check();
      await page.getByTestId('photo-send').click();
      for (const t of ['tab-today', 'tab-history', 'tab-add', 'tab-trends', 'tab-today', 'tab-add']) await page.getByTestId(t).click();
      await page.waitForTimeout(2200);
      await expect(page.getByTestId('app-error')).toBeHidden();
      expect(posts(seen)).toHaveLength(1);
      expect((await stored(page)).meals || []).toEqual([]);
      await noHorizontalScroll(page);
    });

    test(`${W}: Quick "Log steps" — today, yesterday, a chosen date; replace needs a tick; blank/future refused; other check-in values kept`, async ({ page }) => {
      const T = '2026-11-17T05:00:00.000Z';
      await open(page, { version: 2, weight: [], workouts: [], nutrition: [],
        daily: [{ id: 'daily-2026-11-17', createdAt: T, updatedAt: T, date: '2026-11-17', sleepH: { state: 'OBSERVED', value: 7 }, footPain: { state: 'OBSERVED', value: 1 }, steps: { state: 'MISSING', value: null } }] });
      await page.getByTestId('tab-today').click();
      await openSteps(page);
      await expect(page.getByTestId('qsteps-today')).toHaveAttribute('aria-pressed', 'true');
      await expect(page.getByTestId('qsteps-existing')).toContainText('no daily total');
      await noHorizontalScroll(page);
      await shot(page, `p10-quick-steps-${W}`);
      await page.getByTestId('qsteps-save').click();
      await expect(page.getByTestId('qsteps-error')).toContainText('Not saved');
      await page.getByTestId('qsteps-input').fill('8,500');
      await page.getByTestId('qsteps-save').click();
      await expect(page.getByTestId('glance-steps-text')).toContainText('8,500');
      // yesterday: keeps sleep and pain
      await openSteps(page);
      await page.getByTestId('qsteps-yesterday').click();
      await page.getByTestId('qsteps-input').fill('7000');
      await page.getByTestId('qsteps-save').click();
      let d = (await stored(page)).daily.find((x) => x.date === '2026-11-17');
      await expect.poll(async () => ((await stored(page)).daily.find((x) => x.date === '2026-11-17').steps || {}).value).toBe(7000);
      d = (await stored(page)).daily.find((x) => x.date === '2026-11-17');
      expect(d.id).toBe('daily-2026-11-17'); expect(d.sleepH.value).toBe(7); expect(d.footPain.value).toBe(1);
      // replacing needs the tick
      await openSteps(page);
      await page.getByTestId('qsteps-yesterday').click();
      await expect(page.getByTestId('qsteps-existing')).toContainText('7,000');
      await page.getByTestId('qsteps-input').fill('7200');
      await page.getByTestId('qsteps-save').click();
      await expect(page.getByTestId('qsteps-error')).toContainText('tick');
      await page.getByTestId('qsteps-replace').check();
      await page.getByTestId('qsteps-save').click();
      await expect.poll(async () => (await stored(page)).daily.find((x) => x.date === '2026-11-17').steps.value).toBe(7200);
      expect((await stored(page)).daily.filter((x) => x.date === '2026-11-17')).toHaveLength(1);
      // chosen older date: explicit zero stays zero
      await openSteps(page);
      await page.getByTestId('qsteps-choose').click();
      await page.getByTestId('qsteps-date').fill('2026-11-10');
      await page.getByTestId('qsteps-input').fill('0');
      await page.getByTestId('qsteps-save').click();
      await expect.poll(async () => ((await stored(page)).daily.find((x) => x.date === '2026-11-10') || { steps: {} }).steps.value).toBe(0);
      // future refused
      await openSteps(page);
      await page.getByTestId('qsteps-choose').click();
      await page.getByTestId('qsteps-date').fill('2026-11-19');
      await expect(page.getByTestId('qsteps-existing')).toContainText('future');
      if (await page.getByTestId('qsteps-input').count()) { await page.getByTestId('qsteps-input').fill('100'); await page.getByTestId('qsteps-save').click(); await expect(page.getByTestId('qsteps-error')).toContainText('Not saved'); }
      expect((await stored(page)).daily.find((x) => x.date === '2026-11-19')).toBeUndefined();
      await expect(page.getByTestId('today-catch-up')).toHaveCount(0);
    });

    test(`${W}: Quick "Log steps" — a damaged check-in is not changed here; midnight rollover refuses the save`, async ({ page }) => {
      const T = '2026-11-17T05:00:00.000Z', O = (v) => ({ state: 'OBSERVED', value: v });
      await open(page, { version: 2, weight: [], workouts: [], nutrition: [],
        daily: [{ id: 'daily-2026-11-17', createdAt: T, updatedAt: T, date: '2026-11-17', footPain: O(11), stairKneePain: O(1), sleepH: O(7), limp: { state: 'OBSERVED', value: false }, steps: O(8000), soreness: O(2), rhr: O(60) }] });
      const before = await page.evaluate(() => localStorage.getItem('hyrox.v1'));
      await page.getByTestId('tab-today').click();
      await openSteps(page);
      await page.getByTestId('qsteps-yesterday').click();
      await expect(page.getByTestId('qsteps-damaged')).toBeVisible();
      await expect(page.getByTestId('qsteps-input')).toHaveCount(0);
      expect(await page.evaluate(() => localStorage.getItem('hyrox.v1'))).toBe(before);
      await page.getByTestId('qsteps-open-checkin').click();
      await expect(page.getByTestId('daily-damaged')).toBeVisible();
      await expect(page.getByTestId('daily-approve-correction')).not.toBeChecked();
      // midnight: open at 23:59:30 Asia/Qatar, save after 00:00
      await page.clock.setFixedTime(new Date('2026-11-18T20:59:30.000Z'));
      await page.getByTestId('tab-today').click();
      await openSteps(page);
      await page.getByTestId('qsteps-today').click();
      await expect(page.getByTestId('qsteps-existing')).toContainText('Wed 18 Nov');
      await page.getByTestId('qsteps-input').fill('12000');
      await page.clock.setFixedTime(new Date('2026-11-18T21:00:30.000Z'));
      await page.getByTestId('qsteps-save').click();
      await expect(page.getByTestId('qsteps-error')).toContainText('midnight');
      expect(await page.evaluate(() => localStorage.getItem('hyrox.v1'))).toBe(before);
    });
  });
}
