'use strict';
// Meron keyboard / mobile checks at 390px and 320px (Chrome emulation, not Safari/WebKit).
// Focus order and visible focus, tap targets >= 44px for the new controls, no
// horizontal scroll, text not clipped. Screenshots under results/screens/.
const { test, expect } = require('@playwright/test');
const {
  boot, pick, noHScroll, minTarget, notClipped, shot, visibleFocus, EMPTY, ONE,
} = require('./p5-meron-e2e-lib');

for (const W of [390, 320]) {
  test.describe(`${W}px keyboard/mobile (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`P4-O1 ${W}: focus lands on the EMPTY BACKUP title; tab order and visible focus; targets >= 44px; no clip or h-scroll`, async ({ page }) => {
      await boot(page, { seed: 'populated' });
      await pick(page, EMPTY);
      await expect(page.getByTestId('import-empty-title')).toBeFocused();
      await visibleFocus(page, 'import-empty-title');
      await page.keyboard.press('Tab');
      await expect(page.getByTestId('import-empty-confirm')).toBeFocused();
      await visibleFocus(page, 'import-empty-confirm-label');
      await minTarget(page.getByTestId('import-empty-confirm-label'), 'empty-confirm label');
      await minTarget(page.getByTestId('import-cancel'), 'cancel');
      await minTarget(page.getByTestId('import-confirm'), 'confirm');
      await noHScroll(page);
      await notClipped(page, 'import-empty-title');
      await notClipped(page, 'import-empty-text');
      // Scroll the heading into view so the 320px shot includes EMPTY BACKUP
      // (the full danger block is taller than 568px).
      await page.getByTestId('import-empty-title').scrollIntoViewIfNeeded();
      await shot(page, W, 'empty-backup-warning');
    });

    test(`P4-F02 ${W}: blocked-restore message is fully visible, targets >= 44px, no h-scroll`, async ({ page }) => {
      await boot(page, { seed: 'populated', pendingSlot: true });
      await pick(page, ONE);
      const blocked = page.getByTestId('import-prior-blocked');
      await expect(blocked).toBeVisible();
      await blocked.scrollIntoViewIfNeeded();
      await noHScroll(page);
      await notClipped(page, 'import-prior-blocked');
      await minTarget(page.getByTestId('raw-recovery-btn'), 'raw recovery');
      await minTarget(page.getByTestId('import-cancel'), 'cancel');
      await shot(page, W, 'prior-copy-blocked');
    });

    test(`P4-F01 ${W}: non-restorable export warning is fully visible, raw-recovery target >= 44px, no h-scroll`, async ({ page }) => {
      await boot(page, { seed: 'duplicate' });
      const dl = page.waitForEvent('download');
      await page.getByTestId('export-btn').click();
      await dl;
      const box = page.getByTestId('export-not-restorable');
      await expect(box).toBeVisible();
      await box.scrollIntoViewIfNeeded();
      await noHScroll(page);
      await notClipped(page, 'export-not-restorable-head');
      await minTarget(page.getByTestId('raw-recovery-btn'), 'raw recovery');
      await minTarget(page.getByTestId('export-btn'), 'export');
      await shot(page, W, 'export-not-restorable');
    });
  });
}
