'use strict';
// Claude Phase 10b independent review. Synthetic data, stubbed OpenAI via the real server code. CHROME EMULATION, NOT SAFARI/WEBKIT.
// On Grok's 10b these FAIL:
//  1. switching the input path silently dropped photos that were chosen but not yet analysed (owner decision: ask first);
//  2. editing a saved meal and switching away from Photo silently dropped its chosen photos;
//  3. the discard prompt was window.confirm, which iOS Safari is documented to stop showing after back/forward
//     navigation; it is now an accessible in-app dialog (safe choice focused, Escape keeps), and no native dialog fires;
//  4. an unsaved draft carried past Asia/Qatar midnight kept its date silently; now a notice names the date, and there is
//     an explicit "Discard this draft" control;
//  5. an untouched COPIED meal was replaced by a blank draft at midnight (its copied items were lost);
//  6. the "replace items with the estimate?" prompt was window.confirm.
//  7. (passes on Grok's 10b; guards a defect found in Claude's first fix) tapping the path already in use must not ask.
const fs = require('fs');
const path = require('path');
const { test, expect } = require('@playwright/test');
// P0 (22 Nov 2026): "Meal name" is no longer a routine field; the optional custom name sits in a closed fold.
async function nameField(page) { const f = page.getByTestId('meal-label'); if (!(await f.isVisible())) await page.getByTestId('meal-name-toggle').click(); return f; }


const F = (n) => path.join(__dirname, '..', 'fixtures', n);
let H;
test.beforeAll(() => {
  const out = path.join(__dirname, '..', 'out', 'p9-helpers.bundle.cjs');
  const esbuild = process.env.P9_ESBUILD || (() => { try { return require.resolve('esbuild/bin/esbuild'); } catch (e) { return '/workspace/p9-tools/node_modules/.bin/esbuild'; } })();
  require('child_process').execFileSync(esbuild, [path.join(__dirname, '..', 'p9-helpers.mjs'), '--bundle', '--platform=node', '--format=cjs', '--log-level=error', '--define:import.meta.url=' + JSON.stringify(require('url').pathToFileURL(path.join(__dirname, '..', 'p9-helpers.mjs')).href), '--outfile=' + out]);
  H = require(out);
});
async function installApi(page) {
  const ctx = H.setup({ script: () => H.openaiOk(), clock: { t: Date.UTC(2026, 10, 18, 6, 0, 0) } });
  const seen = [];
  await page.route('**/api/food-photo/**', async (route) => {
    const r = route.request(); seen.push({ url: r.url(), method: r.method() });
    const req = new Request(r.url(), { method: r.method(), headers: r.headers(), body: r.method() === 'GET' ? undefined : r.postData() });
    const res = await ctx.handle(req, { ip: '203.0.113.5' });
    try { await route.fulfill({ status: res.status, headers: Object.fromEntries(res.headers), body: await res.text() }); } catch (e) { /* */ }
  });
  return seen;
}
async function open(page, at = '2026-11-18T09:00:00.000Z') {
  page._errs = []; page._dialogs = [];
  page.on('pageerror', (e) => page._errs.push(e.message));
  page.on('dialog', (d) => { page._dialogs.push(d.message()); d.dismiss(); });
  await page.clock.setFixedTime(new Date(at));
  await page.goto('./'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
}
const clean = (page) => { expect(page._errs).toEqual([]); expect(page._dialogs, 'no native dialog may fire in meal flows').toEqual([]); };
const meals = (page) => page.evaluate(() => (JSON.parse(localStorage.getItem('hyrox.v1') || '{}').meals) || []);
async function toAddMeal(page) { await page.getByTestId('tab-add').click(); await page.getByTestId('add-mode-meal').click(); }
async function liveCode(page) {
  await page.getByTestId('tab-settings').click();
  await page.getByTestId('ai-provider-live').check();
  await page.getByTestId('ai-owner-code').fill(H.OWNER_CODE);
  await page.getByTestId('ai-owner-code-save').click();
}

for (const W of [390, 320]) {
  test.describe(`P10b Claude review ${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`${W}: chosen but unanalysed photos are never dropped by a path switch without asking`, async ({ page }) => {
      await open(page); await toAddMeal(page);
      await page.getByTestId('meal-path-photo_ai').click();
      await page.getByTestId('photo-library-input').setInputFiles([F('p10-view-a.jpg'), F('p10-view-b.jpg')]);
      await expect(page.getByTestId('photo-preview')).toHaveCount(2);
      await page.getByTestId('meal-path-manual').click();
      const dlg = page.getByTestId('choice-dialog');
      await expect(dlg).toBeVisible();
      await expect(page.getByTestId('choice-body')).toContainText('photos');
      // accessible: alertdialog, labelled, safe choice focused, 44 px targets
      const box = dlg.locator('[role="alertdialog"]');
      await expect(box).toHaveAttribute('aria-modal', 'true');
      await expect(page.getByTestId('choice-keep')).toBeFocused();
      for (const b of ['choice-keep', 'choice-yes']) expect((await page.getByTestId(b).boundingBox()).height).toBeGreaterThanOrEqual(44);
      await page.keyboard.press('Escape'); // Escape keeps
      await expect(dlg).toHaveCount(0);
      await expect(page.getByTestId('photo-preview')).toHaveCount(2);
      await page.getByTestId('meal-path-manual').click();
      await page.getByTestId('choice-yes').click();
      await expect(page.getByTestId('photo-preview')).toHaveCount(0);
      expect(await meals(page)).toEqual([]);
      clean(page);
    });

    test(`${W}: tapping the input path already in use never asks and keeps the draft`, async ({ page }) => {
      await open(page); await toAddMeal(page);
      await page.getByTestId('meal-path-description').click();
      await page.getByTestId('meal-description').fill('1 cup whole milk');
      await (await nameField(page)).fill('Keep');
      await page.getByTestId('meal-path-description').click();
      await expect(page.getByTestId('choice-dialog')).toHaveCount(0);
      await expect(page.getByTestId('meal-description')).toHaveValue('1 cup whole milk');
      await expect(page.getByTestId('meal-label')).toHaveValue('Keep');
      clean(page);
    });

    test(`${W}: editing a saved meal, photos chosen then a switch to Manual asks; the saved items are kept`, async ({ page }) => {
      await open(page); await toAddMeal(page);
      await page.getByTestId('meal-path-manual').click();
      await (await nameField(page)).fill('Lunch');
      await page.getByTestId('component-name').first().fill('Rice'); await page.getByTestId('component-kcal').first().fill('300');
      await page.getByTestId('meal-confirm').click();
      await expect.poll(async () => (await meals(page)).length).toBe(1);
      await page.getByTestId('tab-history').click();
      await page.getByTestId('history-meal').first().getByRole('button', { name: /^Edit/ }).click();
      await page.getByTestId('meal-path-photo_ai').click();
      await page.getByTestId('photo-library-input').setInputFiles([F('p10-view-a.jpg')]);
      await expect(page.getByTestId('photo-preview')).toHaveCount(1);
      await page.getByTestId('meal-path-manual').click();
      await expect(page.getByTestId('choice-title')).toContainText('Remove the chosen photos');
      await page.getByTestId('choice-keep').click();
      await expect(page.getByTestId('photo-preview')).toHaveCount(1);
      await page.getByTestId('meal-path-manual').click(); await page.getByTestId('choice-yes').click();
      await expect(page.getByTestId('photo-preview')).toHaveCount(0);
      await expect(page.getByTestId('component-name').first()).toHaveValue('Rice');
      const m = await meals(page); expect(m).toHaveLength(1); expect(m[0].components[0].name).toBe('Rice');
      clean(page);
    });

    test(`${W}: an unsaved draft past Qatar midnight names its date; "Discard this draft" asks, then empties it`, async ({ page }) => {
      await open(page, '2026-11-18T20:58:00.000Z'); // 23:58 Qatar
      await toAddMeal(page); await page.getByTestId('meal-path-manual').click();
      await expect(page.getByTestId('meal-draft-date')).toHaveCount(0);
      await (await nameField(page)).fill('Late snack');
      await page.getByTestId('component-name').first().fill('Dates'); await page.getByTestId('component-kcal').first().fill('140');
      await page.clock.setFixedTime(new Date('2026-11-18T21:00:30.000Z')); // 00:00:30 Qatar, 19 Nov
      await page.evaluate(() => document.dispatchEvent(new Event('visibilitychange')));
      await expect(page.getByTestId('meal-draft-date')).toContainText('dated 2026-11-18, not today (2026-11-19)');
      await expect(page.getByTestId('meal-label')).toHaveValue('Late snack');
      await expect(page.getByTestId('meal-date')).toHaveValue('2026-11-18');
      await page.getByTestId('meal-discard').click();
      await expect(page.getByTestId('choice-body')).toContainText('2026-11-18');
      await page.getByTestId('choice-keep').click();
      await expect(page.getByTestId('meal-label')).toHaveValue('Late snack');
      await page.getByTestId('meal-discard').click(); await page.getByTestId('choice-yes').click();
      await expect(page.getByTestId('meal-label')).toHaveValue('');
      await expect(page.getByTestId('meal-date')).toHaveValue('2026-11-19');
      await expect(page.getByTestId('meal-draft-date')).toHaveCount(0);
      expect(await meals(page)).toEqual([]);
      clean(page);
    });

    test(`${W}: an untouched COPIED meal keeps its items at midnight (only its date moves); the original is unchanged`, async ({ page }) => {
      await open(page, '2026-11-18T20:57:00.000Z'); // 23:57 Qatar
      await toAddMeal(page); await page.getByTestId('meal-path-manual').click();
      await (await nameField(page)).fill('Oats');
      await page.getByTestId('component-name').first().fill('Oats bowl'); await page.getByTestId('component-kcal').first().fill('350');
      await page.getByTestId('meal-confirm').click();
      await expect.poll(async () => (await meals(page)).length).toBe(1);
      const before = JSON.stringify(await meals(page));
      await page.getByTestId('tab-history').click();
      await page.getByTestId('history-meal').first().getByRole('button', { name: /^Copy/ }).click();
      await expect(page.getByTestId('component-name').first()).toHaveValue('Oats bowl');
      await page.clock.setFixedTime(new Date('2026-11-18T21:00:30.000Z'));
      await page.evaluate(() => document.dispatchEvent(new Event('visibilitychange')));
      await expect(page.getByTestId('component-name').first()).toHaveValue('Oats bowl');
      await expect(page.getByTestId('meal-date')).toHaveValue('2026-11-19');
      expect(JSON.stringify(await meals(page))).toBe(before);
      clean(page);
    });

    test(`${W}: re-analysis over edited items asks in-app; "Keep my items" keeps them; no native dialog`, async ({ page }) => {
      const seen = await installApi(page);
      await open(page); await liveCode(page); await toAddMeal(page);
      await page.getByTestId('meal-path-photo_ai').click();
      await page.getByTestId('photo-library-input').setInputFiles([F('p10-view-a.jpg')]);
      await page.getByTestId('photo-privacy-ack').click();
      await page.getByTestId('photo-send-consent').check();
      await page.getByTestId('photo-send').click();
      await expect(page.getByTestId('component-name').first()).not.toHaveValue('', { timeout: 15000 });
      await page.getByTestId('component-name').first().fill('My own rice');
      await page.getByTestId('photo-send-consent').check();
      await page.getByTestId('photo-send').click();
      await expect(page.getByTestId('choice-title')).toContainText('Replace the current items with the estimate', { timeout: 15000 });
      await expect(page.getByTestId('choice-keep')).toBeFocused();
      await page.getByTestId('choice-keep').click();
      await expect(page.getByTestId('component-name').first()).toHaveValue('My own rice');
      expect(seen.filter((s) => s.method === 'POST').length).toBeLessThanOrEqual(2);
      expect(await meals(page)).toEqual([]);
      clean(page);
    });
  });
}
