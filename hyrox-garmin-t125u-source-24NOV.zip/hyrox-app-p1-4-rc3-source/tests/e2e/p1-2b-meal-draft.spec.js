'use strict';
// Sprint B2 (owner decision M1, 23 Nov 2026): an unfinished MEAL survives a reload in the UI-only key hyrox.ui.meal-draft and
// comes back ONLY by an explicit Resume (or goes by an explicit Discard). Owner safeguards tested here: bounded auto-save of
// descriptions/portions/quantities/edits; no photo files/bytes/data URLs, owner code or credentials in the draft (photos must be
// reattached, said on Resume); cleared only by a verified save or an explicit Discard (not by a failed or refused save, leaving
// the form, or a reload); never counted (day totals / D5 unchanged); hyrox.v1, backups and restore untouched by the key.
// Also: Asia/Qatar midnight, revision conflict with another tab, damaged drafts, duplicates, the photo+note gate after Resume.
// Synthetic data only; the photo analysis uses the REAL server code in-process with a stubbed model (no network, no key, no
// paid call). CHROME MOBILE EMULATION, NOT SAFARI/WEBKIT, not a physical iPhone.
const path = require('path');
const fs = require('fs');
const { test, expect } = require('@playwright/test');
const FX = require('../fixtures/p0-photo-note-fixtures.js');

const KEY = 'hyrox.ui.meal-draft';
const FIX = path.join(__dirname, '..', 'fixtures');
let H;
test.beforeAll(() => {
  const out = path.join(__dirname, '..', 'out', 'p9-helpers.bundle.cjs');
  const esbuild = process.env.P9_ESBUILD || (() => { try { return require.resolve('esbuild/bin/esbuild'); } catch (e) { return '/workspace/p9-tools/node_modules/.bin/esbuild'; } })();
  require('child_process').execFileSync(esbuild, [path.join(__dirname, '..', 'p9-helpers.mjs'), '--bundle', '--platform=node', '--format=cjs', '--log-level=error', '--define:import.meta.url=' + JSON.stringify(require('url').pathToFileURL(path.join(__dirname, '..', 'p9-helpers.mjs')).href), '--outfile=' + out]);
  H = require(out);
});
async function installApi(page, text) {
  const ctx = H.setup({ script: () => H.openaiOk(text), clock: { t: Date.UTC(2026, 10, 18, 6, 0, 0) } });
  await page.route('**/api/food-photo/**', async (route) => {
    const r = route.request();
    const req = new Request(r.url(), { method: r.method(), headers: r.headers(), body: r.method() === 'GET' ? undefined : r.postData() });
    const res = await ctx.handle(req, { ip: '203.0.113.5' });
    try { await route.fulfill({ status: res.status, headers: Object.fromEntries(res.headers), body: await res.text() }); } catch (e) { /* page moved on */ }
  });
}
const NOW = '2026-11-18T09:00:00.000Z'; // Wed 18 Nov 2026, 12:00 Asia/Qatar
const TS = '2026-11-18T05:00:00.000Z';
const E = (v) => ({ value: v, state: 'ESTIMATED' }), U = () => ({ value: null, state: 'UNKNOWN' });
const SEED_MEAL = { id: 'meal-seed-1', date: '2026-11-18', time: '08:00', label: '', source: 'MANUAL', description: 'seed breakfast', eatenFraction: 1, lifecycle: 'CONFIRMED',
  confirmedAt: TS, createdAt: TS, updatedAt: TS, mealCategory: 'BREAKFAST', components: [{ name: 'Oats', role: 'MAIN', portion: '1 bowl', preparation: '', eatenFraction: null, kcal: E(500), proteinG: E(20), carbsG: E(80), fatG: E(8) }] };
async function open(page, opts = {}) {
  page._errs = []; page.on('pageerror', (e) => page._errs.push(e.message));
  await page.clock.setFixedTime(new Date(opts.at || NOW));
  await page.goto('./');
  await page.evaluate((o) => { localStorage.clear(); if (o.data) localStorage.setItem('hyrox.v1', JSON.stringify(o.data)); if (o.draft !== undefined) localStorage.setItem('hyrox.ui.meal-draft', o.draft); }, { data: opts.data || null, draft: opts.draft });
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
}
const raw = (page, k) => page.evaluate((x) => localStorage.getItem(x), k);
const draft = async (page) => JSON.parse((await raw(page, KEY)) || 'null');
const meals = async (page) => (JSON.parse((await raw(page, 'hyrox.v1')) || '{}').meals || []);
const noHScroll = async (page) => expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
async function toAddMeal(page) { await page.getByTestId('tab-add').click(); await page.getByTestId('add-mode-meal').click(); }
async function portion(page, i, v) {
  const p = page.getByTestId('component-portion').nth(i);
  if (!(await p.isVisible())) await page.getByTestId('component-details').nth(i).locator('summary').click();
  await p.fill(v);
}
async function typeManual(page, o) {
  await toAddMeal(page);
  await page.getByTestId('meal-path-manual').click();
  await page.getByTestId('meal-description').fill(o.desc || 'DRAFT-DESC rice and chicken');
  await page.getByTestId('component-name').first().fill(o.name || 'Chicken rice');
  await page.getByTestId('component-kcal').first().fill(String(o.kcal || 900));
  await portion(page, 0, o.portion || '1.5 plates');
}
async function reloadToToday(page) { await page.reload(); await expect(page.getByTestId('app-error')).toBeHidden(); await expect(page.getByTestId('panel-today')).toBeVisible(); }

for (const W of [390, 320]) {
  test.describe(`P1.2 meal draft recovery ${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`${W}: FAIL-FIRST — a typed meal survives a reload; it is offered with explicit Resume/Discard, not counted, and restored exactly; Confirm saves once and clears it`, async ({ page }) => {
      await open(page, { data: { version: 2, weight: [], workouts: [], nutrition: [], meals: [SEED_MEAL] } });
      const v1Before = await raw(page, 'hyrox.v1');
      await expect(page.getByTestId('today-subtotal')).toContainText('500');
      await typeManual(page, {});
      await expect.poll(async () => (await draft(page)) && (await draft(page)).ms.description).toBe('DRAFT-DESC rice and chicken');
      expect(await raw(page, 'hyrox.v1')).toBe(v1Before); // the draft is never a record
      await reloadToToday(page);
      const note = page.getByTestId('today-meal-draft');
      await expect(note).toBeVisible();
      await expect(note).toContainText('not saved yet and does not count');
      await expect(page.getByTestId('today-meal-draft-resume')).toBeVisible();
      await expect(page.getByTestId('today-meal-draft-discard')).toBeVisible();
      await expect(page.getByTestId('today-subtotal')).toContainText('500'); // not 1400
      await expect(page.getByTestId('today-subtotal')).not.toContainText('1400');
      expect(await raw(page, 'hyrox.v1')).toBe(v1Before);
      await noHScroll(page);
      // nothing is restored into the form without Resume
      await toAddMeal(page);
      await expect(page.getByTestId('meal-description')).toHaveValue('');
      await expect(page.getByTestId('meal-draft-pending')).toBeVisible();
      await page.getByTestId('meal-draft-pending-resume').click();
      await expect(page.getByTestId('meal-draft-restored')).toBeVisible();
      await expect(page.getByTestId('meal-description')).toHaveValue('DRAFT-DESC rice and chicken');
      await expect(page.getByTestId('component-name').first()).toHaveValue('Chicken rice');
      await expect(page.getByTestId('component-kcal').first()).toHaveValue('900');
      await expect(page.getByTestId('component-portion').first()).toHaveValue('1.5 plates');
      expect(await raw(page, 'hyrox.v1')).toBe(v1Before);
      await noHScroll(page);
      await page.getByTestId('meal-confirm').click();
      await expect.poll(async () => (await meals(page)).length).toBe(2);
      expect(await raw(page, KEY)).toBeNull();
      await page.getByTestId('meal-confirm').click().catch(() => {}); // a second tap on the fresh form saves nothing
      await reloadToToday(page);
      await expect(page.getByTestId('today-meal-draft')).toHaveCount(0);
      expect((await meals(page)).length).toBe(2);
      await expect(page.getByTestId('today-subtotal')).toContainText('1400');
      expect(page._errs).toEqual([]);
    });

    test(`${W}: explicit two-step Discard removes only the draft; "Keep it" and "Keep editing" keep it`, async ({ page }) => {
      await open(page);
      await typeManual(page, {});
      await expect.poll(() => raw(page, KEY)).not.toBeNull();
      // form-level Discard asks; Keep editing keeps the draft
      await page.getByTestId('meal-discard').click();
      await page.getByTestId('choice-keep').click();
      expect(await raw(page, KEY)).not.toBeNull();
      await reloadToToday(page);
      await page.getByTestId('today-meal-draft-discard').click();
      await page.getByTestId('today-meal-draft-discard-keep').click();
      expect(await raw(page, KEY)).not.toBeNull();
      await page.getByTestId('today-meal-draft-discard').click();
      await page.getByTestId('today-meal-draft-discard-yes').click();
      expect(await raw(page, KEY)).toBeNull();
      await expect(page.getByTestId('today-meal-draft')).toHaveCount(0);
      expect(await meals(page)).toEqual([]);
      // the form-level dialog "Discard it" also clears it
      await typeManual(page, { desc: 'second meal' });
      await expect.poll(() => raw(page, KEY)).not.toBeNull();
      await page.getByTestId('meal-discard').click();
      await page.getByTestId('choice-yes').click();
      expect(await raw(page, KEY)).toBeNull();
      expect(page._errs).toEqual([]);
    });
  });
}

test.describe('P1.2 meal draft recovery 390px (Chrome emulation, not Safari/WebKit)', () => {
  test('a failed save, a refused save, leaving the form and a reload never clear the draft; the next good save does', async ({ page }) => {
    await open(page);
    await typeManual(page, {});
    // refused: an item without a name
    await page.getByTestId('meal-add-component').click();
    await page.getByTestId('meal-confirm').click();
    await expect(page.getByTestId('meal-error')).toContainText('needs a name');
    expect((await draft(page)).ms.components.length).toBe(2);
    await page.getByTestId('component-remove').nth(1).click();
    // failed: storage refuses hyrox.v1
    await page.evaluate(() => { const o = Storage.prototype.setItem; window.__o = o; Storage.prototype.setItem = function (k, v) { if (k === 'hyrox.v1') { const e = new Error('quota'); e.name = 'QuotaExceededError'; throw e; } return o.call(this, k, v); }; });
    await page.getByTestId('meal-confirm').click();
    await expect(page.getByTestId('meal-error')).not.toHaveText('');
    expect(await meals(page)).toEqual([]);
    expect((await draft(page)).ms.description).toBe('DRAFT-DESC rice and chicken');
    await page.evaluate(() => { Storage.prototype.setItem = window.__o; });
    // leaving the form (another tab of the app) keeps it
    await page.getByTestId('tab-today').click();
    expect(await draft(page)).not.toBeNull();
    await reloadToToday(page);
    expect(await draft(page)).not.toBeNull();
    await page.getByTestId('today-meal-draft-resume').click();
    await page.getByTestId('meal-confirm').click();
    await expect.poll(async () => (await meals(page)).length).toBe(1);
    expect(await raw(page, KEY)).toBeNull();
    expect(page._errs).toEqual([]);
  });

  test('"Save draft" (a DRAFT record) is a verified save: the local copy goes, the record stays uncounted', async ({ page }) => {
    await open(page);
    await typeManual(page, {});
    await expect.poll(() => raw(page, KEY)).not.toBeNull();
    await page.getByTestId('meal-save-draft').click();
    await expect.poll(async () => (await meals(page)).length).toBe(1);
    expect((await meals(page))[0].lifecycle).toBe('DRAFT');
    expect(await raw(page, KEY)).toBeNull();
    await reloadToToday(page);
    await expect(page.getByTestId('today-meal-draft')).toHaveCount(0);
    await expect(page.getByTestId('today-subtotal')).not.toContainText('900');
  });

  test('Add foods quantities and edits are kept: 2 x banana with its portion and kcal comes back after Resume', async ({ page }) => {
    await open(page);
    await page.getByTestId('today-add-meal').click();
    await page.getByTestId('diary-log-lunch').click();
    await page.getByTestId('meal-add-foods').click();
    await expect(page.getByTestId('foods-status')).not.toContainText('Loading');
    await page.getByTestId('foods-q').fill('banana');
    await page.getByTestId('food-result').filter({ hasText: /^Bananas, raw/ }).first().getByTestId('food-pick').click();
    await page.getByTestId('food-qty').fill('2');
    await page.getByTestId('food-add').click();
    await page.getByTestId('foods-done').click();
    const por = await page.getByTestId('component-portion').first().inputValue();
    const kc = await page.getByTestId('component-kcal').first().inputValue();
    expect(por).toMatch(/^2 × /);
    await expect.poll(async () => (await draft(page)) && (await draft(page)).ms.components[0].portion).toBe(por);
    expect((await draft(page)).ctx).toMatchObject({ cat: 'LUNCH', date: '2026-11-18' });
    await reloadToToday(page);
    await page.getByTestId('today-meal-draft-resume').click();
    await expect(page.getByTestId('logger-title')).toHaveText('Log lunch');
    await expect(page.getByTestId('component-portion').first()).toHaveValue(por);
    await expect(page.getByTestId('component-kcal').first()).toHaveValue(kc);
    await page.getByTestId('meal-confirm').click();
    await expect.poll(async () => (await meals(page)).length).toBe(1);
    expect((await meals(page))[0].mealCategory).toBe('LUNCH');
  });

  test('photos are never stored in the draft; Resume says they must be reattached; the analysed items are kept and can be confirmed', async ({ page }) => {
    await open(page);
    await page.getByTestId('tab-settings').click();
    await page.getByTestId('ai-provider-mock').check();
    await toAddMeal(page);
    await page.getByTestId('meal-path-photo_ai').click();
    await page.getByTestId('meal-description').fill('chicken and rice');
    await page.getByTestId('photo-library-input').setInputFiles([path.join(FIX, 'p10-view-a.jpg'), path.join(FIX, 'p10-view-b.jpg')]);
    await expect(page.getByTestId('photo-preview')).toHaveCount(2);
    await page.getByTestId('photo-privacy-ack').click();
    await page.getByTestId('photo-send-consent').check();
    await page.getByTestId('photo-send').click();
    await expect(page.getByTestId('component-row')).toHaveCount(3);
    await page.getByTestId('meal-eaten-100').click();
    const t = await raw(page, KEY);
    expect(t).not.toBeNull();
    expect(/data:|blob:|base64|\/9j\/|imageBase64|"image"|"photos"/i.test(t)).toBe(false);
    expect(JSON.parse(t).photoCount).toBe(2);
    await reloadToToday(page);
    await expect(page.getByTestId('today-meal-draft-photos')).toContainText('2 photos');
    await page.getByTestId('today-meal-draft-resume').click();
    await expect(page.getByTestId('meal-draft-photos-reattach')).toContainText('attach them again');
    await expect(page.getByTestId('photo-preview')).toHaveCount(0);
    await expect(page.getByTestId('component-row')).toHaveCount(3);
    await page.getByTestId('meal-confirm').click();
    await expect.poll(async () => (await meals(page)).length).toBe(1);
    expect(/data:image|base64/.test(await raw(page, 'hyrox.v1'))).toBe(false);
    expect(await raw(page, KEY)).toBeNull();
  });

  test('the A fix gate survives Resume: foods the note names but the estimate missed still block Confirm; the owner code never enters the draft', async ({ page }) => {
    await open(page);
    await installApi(page, FX.YOGURT_ONLY);
    await page.getByTestId('tab-settings').click();
    await page.getByTestId('ai-provider-live').check();
    await page.getByTestId('ai-owner-code').fill(H.OWNER_CODE);
    await page.getByTestId('ai-owner-code-save').click();
    await page.getByTestId('ai-live-check').click();
    await expect(page.getByTestId('ai-live-status')).toContainText('Ready');
    await toAddMeal(page);
    await page.getByTestId('meal-path-photo_ai').click();
    await page.getByTestId('meal-description').fill(FX.NOTE);
    await page.getByTestId('photo-library-input').setInputFiles(path.join(FIX, 'p10-view-a.jpg'));
    await page.getByTestId('photo-privacy-ack').click();
    await page.getByTestId('photo-send-consent').check();
    await page.getByTestId('photo-send').click();
    await expect(page.getByTestId('unaccounted-item')).toHaveCount(2);
    await page.getByTestId('meal-eaten-100').click();
    // the owner pastes the access code into the note by mistake: it is never kept in the draft
    await page.getByTestId('meal-name-toggle').click();
    await page.getByTestId('meal-label').fill('code ' + H.OWNER_CODE);
    await expect.poll(async () => ((await raw(page, KEY)) || '').includes('[removed]')).toBe(true);
    const t = await raw(page, KEY);
    expect(t.includes(H.OWNER_CODE)).toBe(false);
    expect(/ai-owner-code|ai-settings|Bearer|apiKey/i.test(t)).toBe(false);
    await reloadToToday(page);
    await page.getByTestId('today-meal-draft-resume').click();
    await expect(page.getByTestId('meal-draft-photos-reattach')).toBeVisible();
    await expect(page.getByTestId('unaccounted-item')).toHaveCount(2);
    await page.getByTestId('meal-confirm').click();
    await expect(page.getByTestId('meal-error')).toContainText('does not account for');
    expect(await meals(page)).toEqual([]);
    expect(await raw(page, KEY)).not.toBeNull(); // refused: kept
    await page.getByTestId('unaccounted-ack').first().click();
    await page.getByTestId('unaccounted-ack').first().click();
    await expect(page.getByTestId('meal-unaccounted')).toHaveCount(0);
    await page.getByTestId('meal-confirm').click();
    await expect.poll(async () => (await meals(page)).length).toBe(1);
    expect((await meals(page))[0].ai.acks.length).toBe(2);
    expect(await raw(page, KEY)).toBeNull();
  });

  test('Asia/Qatar midnight: a meal started 23:50 on 17 Nov keeps its date after a reload at 00:10 on 18 Nov and says so', async ({ page }) => {
    await open(page, { at: '2026-11-17T20:50:00.000Z' }); // 23:50 Qatar, 17 Nov
    await typeManual(page, {});
    await expect.poll(async () => (await draft(page)) && (await draft(page)).day).toBe('2026-11-17');
    await page.clock.setFixedTime(new Date('2026-11-17T21:10:00.000Z')); // 00:10 Qatar, 18 Nov
    await reloadToToday(page);
    await expect(page.getByTestId('today-meal-draft-day')).toContainText('Started on');
    await expect(page.getByTestId('today-meal-draft-day')).toContainText('17 Nov');
    await page.getByTestId('today-meal-draft-resume').click();
    await expect(page.getByTestId('meal-date')).toHaveValue('2026-11-17');
    await expect(page.getByTestId('meal-draft-restored-day')).toBeVisible();
    await expect(page.getByTestId('meal-draft-date')).toBeVisible();
    await page.getByTestId('meal-confirm').click();
    await expect.poll(async () => (await meals(page)).length).toBe(1);
    expect((await meals(page))[0].date).toBe('2026-11-17');
  });

  test('revision conflict: an edit started here is not silently saved over a newer version saved in another tab; the owner chooses', async ({ page, context }) => {
    await open(page, { data: { version: 2, weight: [], workouts: [], nutrition: [], meals: [SEED_MEAL] } });
    await page.getByTestId('tab-history').click();
    await page.getByTestId('history-meal').first().getByTestId('meal-edit').click();
    await page.getByTestId('component-kcal').first().fill('650');
    await expect.poll(async () => (await draft(page)) && (await draft(page)).ms.components[0].kcal.value).toBe(650);
    expect((await draft(page)).baseUpdatedAt).toBe(TS);
    // another tab edits and saves the same meal
    const b = await context.newPage();
    await b.clock.setFixedTime(new Date('2026-11-18T09:30:00.000Z'));
    await b.goto('./');
    await b.getByTestId('tab-history').click();
    await b.getByTestId('history-meal').first().getByTestId('meal-edit').click();
    await b.getByTestId('component-kcal').first().fill('700');
    await b.getByTestId('meal-confirm').click();
    await expect.poll(async () => (await meals(page))[0].components[0].kcal.value).toBe(700);
    // back here: Confirm must not replace 700 silently
    await page.getByTestId('meal-confirm').click();
    await expect(page.getByTestId('meal-conflict')).toBeVisible();
    expect((await meals(page))[0].components[0].kcal.value).toBe(700);
    expect(await raw(page, KEY)).not.toBeNull();
    // reload + Resume: still guarded
    await reloadToToday(page);
    await expect(page.getByTestId('today-meal-draft-edit')).toBeVisible();
    await page.getByTestId('today-meal-draft-resume').click();
    await page.getByTestId('meal-confirm').click();
    await expect(page.getByTestId('meal-conflict')).toBeVisible();
    await page.getByTestId('meal-conflict-keep-mine').click();
    await expect.poll(async () => (await meals(page))[0].components[0].kcal.value).toBe(650);
    expect((await meals(page)).length).toBe(1); // replaced, never duplicated
    expect(await raw(page, KEY)).toBeNull();
    await b.close();
  });

  test('revision conflict: "Load the saved version" drops my edits only on that explicit choice', async ({ page, context }) => {
    await open(page, { data: { version: 2, weight: [], workouts: [], nutrition: [], meals: [SEED_MEAL] } });
    await page.getByTestId('tab-history').click();
    await page.getByTestId('history-meal').first().getByTestId('meal-edit').click();
    await page.getByTestId('component-kcal').first().fill('650');
    await expect.poll(async () => (await draft(page)) && (await draft(page)).ms.components[0].kcal.value).toBe(650);
    await page.evaluate(() => { const st = window.HyroxData.createStore(); const m = st.records('meals')[0]; const c = JSON.parse(JSON.stringify(m)); c.components[0].kcal = { value: 720, state: 'ESTIMATED' }; st.putRecord('meals', c); });
    await page.getByTestId('meal-confirm').click();
    await expect(page.getByTestId('meal-conflict')).toBeVisible();
    await page.getByTestId('meal-conflict-load-saved').click();
    await expect(page.getByTestId('component-kcal').first()).toHaveValue('720');
    expect(await raw(page, KEY)).toBeNull();
    expect((await meals(page))[0].components[0].kcal.value).toBe(720);
  });

  for (const [name, val] of [['not JSON', '{"savedAt": "2026-11-18T08'], ['wrong shape', JSON.stringify({ savedAt: '2026-11-18T08:00:00.000Z', ms: { date: 'yesterday', components: 'x' } })],
    ['oversized', JSON.stringify({ savedAt: '2026-11-18T08:00:00.000Z', ms: { date: '2026-11-18', components: [], description: 'x'.repeat(210000) } })]]) {
    test(`damaged draft (${name}): the app opens, nothing is restored or counted, and the owner can discard it`, async ({ page }) => {
      await open(page, { data: { version: 2, weight: [], workouts: [], nutrition: [], meals: [SEED_MEAL] }, draft: val });
      await expect(page.getByTestId('today-meal-draft-invalid')).toBeVisible();
      await expect(page.getByTestId('today-meal-draft-invalid-resume')).toHaveCount(0);
      await expect(page.getByTestId('today-subtotal')).toContainText('500');
      await toAddMeal(page);
      await expect(page.getByTestId('meal-description')).toHaveValue('');
      await page.getByTestId('tab-today').click();
      await page.getByTestId('today-meal-draft-invalid-discard').click();
      await page.getByTestId('today-meal-draft-invalid-discard-yes').click();
      expect(await raw(page, KEY)).toBeNull();
      expect((await meals(page)).length).toBe(1);
      expect(page._errs).toEqual([]);
    });
  }

  test('two tabs: a meal confirmed in one tab is not saved again from the other tab (duplicate prevention)', async ({ page, context }) => {
    await open(page);
    await typeManual(page, {});
    await expect.poll(() => raw(page, KEY)).not.toBeNull();
    const b = await context.newPage();
    await b.clock.setFixedTime(new Date(NOW));
    await b.goto('./');
    await b.getByTestId('today-meal-draft-resume').click();
    await expect(b.getByTestId('meal-description')).toHaveValue('DRAFT-DESC rice and chicken');
    await b.getByTestId('meal-confirm').click();
    await expect.poll(async () => (await meals(page)).length).toBe(1);
    await expect(page.getByTestId('meal-other-tab')).toBeVisible();
    await page.getByTestId('meal-confirm').click();
    await expect(page.getByTestId('meal-error')).toContainText('another tab');
    expect((await meals(page)).length).toBe(1);
    await page.getByTestId('meal-other-tab-discard').click();
    await expect(page.getByTestId('meal-description')).toHaveValue('');
    expect((await meals(page)).length).toBe(1);
    expect(await raw(page, KEY)).toBeNull();
    await b.close();
  });

  test('an earlier draft that waits is never overwritten by a new meal typed before Resume/Discard', async ({ page }) => {
    await open(page);
    await typeManual(page, { desc: 'FIRST meal' });
    await expect.poll(async () => (await draft(page)) && (await draft(page)).ms.description).toBe('FIRST meal');
    await reloadToToday(page);
    await typeManual(page, { desc: 'SECOND meal' });
    await page.getByTestId('component-kcal').first().fill('901');
    expect((await draft(page)).ms.description).toBe('FIRST meal');
    await page.getByTestId('meal-confirm').click();
    await expect.poll(async () => (await meals(page)).length).toBe(1);
    expect((await draft(page)).ms.description).toBe('FIRST meal'); // saving the second meal does not remove the first draft
    await reloadToToday(page);
    await expect(page.getByTestId('today-meal-draft')).toBeVisible();
  });

  test('backups and restore never include or touch the draft; hyrox.v1 stays byte-identical while a draft exists', async ({ page }) => {
    await open(page, { data: { version: 2, weight: [], workouts: [], nutrition: [], meals: [SEED_MEAL] } });
    await typeManual(page, { desc: 'BACKUP-MARKER draft' });
    await expect.poll(() => raw(page, KEY)).not.toBeNull();
    const before = await raw(page, KEY);
    await page.getByTestId('tab-settings').click();
    const [dl] = await Promise.all([page.waitForEvent('download'), page.getByTestId('export-btn').click()]);
    const b = fs.readFileSync(await dl.path(), 'utf8');
    expect(b.includes('BACKUP-MARKER')).toBe(false);
    expect(b.includes('meal-draft')).toBe(false);
    // restore that backup: the draft key is left exactly as it was
    await page.getByTestId('import-file').setInputFiles({ name: 'hyrox-backup.json', mimeType: 'application/json', buffer: Buffer.from(b) });
    await expect(page.getByTestId('import-preview')).toBeVisible();
    await page.getByTestId('import-confirm').click();
    await expect.poll(async () => (await meals(page)).length).toBe(1);
    expect(await raw(page, KEY)).toBe(before);
    expect(await raw(page, 'hyrox.v1')).not.toContain('BACKUP-MARKER');
  });
});
