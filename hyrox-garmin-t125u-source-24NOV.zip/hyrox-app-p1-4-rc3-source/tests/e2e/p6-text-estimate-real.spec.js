'use strict';
// P6 (Liya t75u): the same typed-text estimate flow against Dawit's REAL src/data/hyrox-foodcalc.js + food-db.js (no shim).
// Skipped automatically when those files are absent or P6_SHIM=force. CHROME EMULATION, NOT SAFARI/WEBKIT. Synthetic data only.
const { test, expect } = require('@playwright/test');
const { installFoodShim, REAL } = require('./p6-contract-shim');

const SHOTS = process.env.P6_SHOTS || '/workspace/hyrox-p6/results/liya-shots';
const TEXT = '2 eggs, 150 g rice, 1 cup milk, mystery stew';
const meals = (page) => page.evaluate(() => (JSON.parse(localStorage.getItem('hyrox.v1') || '{}').meals) || []);
async function open(page, opts) {
  await installFoodShim(page, opts); // real files are served as-is when both exist
  await page.clock.setFixedTime(new Date('2026-11-12T06:00:00.000Z'));
  await page.goto('./');
  await page.evaluate(() => localStorage.clear());
  await page.reload();
  await expect(page.getByTestId('load-guard')).toBeHidden();
  await page.getByTestId('tab-add').click();
  await page.getByTestId('add-mode-meal').click();
  await page.getByTestId('meal-path-description').click();
}
async function estimate(page, text) {
  await page.getByTestId('meal-description').fill(text);
  await page.getByTestId('estimate-run').click();
  await expect(page.getByTestId('estimate-items')).toBeVisible();
}

for (const W of [390, 320]) {
  test.describe(`REAL food API ${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.skip(!REAL.calc || !REAL.db || REAL.forced, 'real hyrox-foodcalc.js / food-db.js not both present (or P6_SHIM=force)');
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`real ${W}: "2 eggs, 150 g rice, 1 cup milk" -> per-item + total estimates, USDA fdcId provenance, unmatched = no match`, async ({ page }) => {
      await open(page);
      await estimate(page, TEXT);
      const items = page.getByTestId('estimate-item');
      await expect(items).toHaveCount(4);
      await expect(items.nth(0).getByTestId('estimate-nutrients')).toContainText('Estimate: 143 kcal');
      await expect(items.nth(0).getByTestId('estimate-source')).toContainText('fdcId 171287');
      await expect(items.nth(0).getByTestId('estimate-source')).toContainText('assumed default size');
      await expect(items.nth(1).getByTestId('estimate-grams')).toHaveValue('150');
      await expect(items.nth(1).getByTestId('estimate-nutrients')).toContainText('195 kcal');
      await expect(items.nth(2).getByTestId('estimate-nutrients')).toContainText('149 kcal');
      await expect(items.nth(3).getByTestId('estimate-nomatch')).toContainText('no match, enter manually');
      await expect(items.nth(3).getByTestId('estimate-nutrients')).toHaveCount(0);
      await expect(page.getByTestId('estimate-totals')).toContainText('487 kcal');
      await expect(page.getByTestId('estimate-totals')).toContainText('ESTIMATE');
      expect(await meals(page)).toEqual([]);
      const m = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
      expect(m.sw).toBeLessThanOrEqual(m.cw);
      await items.nth(2).scrollIntoViewIfNeeded();
      await page.screenshot({ path: `${SHOTS}/p6-${W}-real-estimate-items.png` });
      await page.getByTestId('estimate-totals').scrollIntoViewIfNeeded();
      await page.screenshot({ path: `${SHOTS}/p6-${W}-real-estimate-totals.png` });
    });

    test(`real ${W}: quantity, measure and grams edits recompute through estimateItem`, async ({ page }) => {
      await open(page);
      await estimate(page, '1 cup milk');
      const it = () => page.getByTestId('estimate-item').first();
      await it().getByTestId('estimate-qty').fill('2'); await it().getByTestId('estimate-qty').press('Tab');
      await expect(it().getByTestId('estimate-grams')).toHaveValue('488');
      await expect(it().getByTestId('estimate-nutrients')).toContainText('298 kcal');
      await it().getByTestId('estimate-measure').selectOption({ label: 'fl oz (30.5 g)' });
      await expect(it().getByTestId('estimate-grams')).toHaveValue('30.5');
      await expect(it().getByTestId('estimate-qty')).toHaveValue('1');
      await it().getByTestId('estimate-grams').fill('100'); await it().getByTestId('estimate-grams').press('Tab');
      await expect(it().getByTestId('estimate-nutrients')).toContainText('61 kcal');
      await expect(it().getByTestId('estimate-source')).toContainText('grams you entered');
    });

    test(`real ${W}: ambiguous "chicken" needs a choice, then counts only after meal confirm; provenance saved`, async ({ page }) => {
      await open(page);
      await estimate(page, '100 g chicken');
      const it = () => page.getByTestId('estimate-item').first();
      await expect(it().getByTestId('estimate-ambiguous')).toBeVisible();
      await expect(it().getByTestId('estimate-nutrients')).toHaveCount(0);
      await expect(page.getByTestId('estimate-totals')).toContainText('nothing matched yet');
      await it().getByTestId('estimate-food').selectOption({ index: 3 }); // an actual choice made by the owner
      await expect(it().getByTestId('estimate-nutrients')).toContainText('kcal');
      await page.getByTestId('estimate-apply').click();
      await page.getByTestId('meal-save-draft').click();
      let m = await meals(page);
      expect(m[0].lifecycle).toBe('DRAFT');
      expect(m[0].components[0].provenance.source).toBe('USDA_FDC');
      expect(typeof m[0].components[0].provenance.fdcId).toBe('number');
      expect(m[0].components[0].kcal.state).toBe('ESTIMATED');
      await page.getByTestId('tab-today').click();
      await expect(page.getByTestId('glance-nutrition')).toContainText('nothing confirmed');
    });

    test(`real ${W}: apply + Confirm -> CONFIRMED meal counts 487 kcal(+unknown), export check restorable`, async ({ page }) => {
      await open(page);
      await estimate(page, TEXT);
      await page.getByTestId('estimate-apply').click();
      await expect(page.getByTestId('component-row')).toHaveCount(4);
      await expect(page.getByTestId('component-row').nth(0).getByTestId('component-provenance')).toContainText('fdcId 171287');
      await page.getByTestId('meal-confirm').click();
      const m = await meals(page);
      expect(m).toHaveLength(1);
      expect(m[0].lifecycle).toBe('CONFIRMED');
      expect(m[0].components.slice(0, 3).map((c) => c.kcal.value)).toEqual([143, 195, 149]);
      await page.getByTestId('tab-today').click();
      await expect(page.getByTestId('glance-nutrition')).toContainText('487');
      const ok = await page.evaluate(() => window.HyroxData.createStore().exportChecked().restorable);
      expect(ok).toBe(true);
    });

    test(`real ${W}: no quantity ("banana") is not assumed as 1: owner enters an amount; RACC rows are hidden from the measure select`, async ({ page }) => {
      await open(page);
      await estimate(page, 'banana');
      const it = () => page.getByTestId('estimate-item').first();
      await expect(it()).toHaveAttribute('data-status', 'unparsed');
      await expect(it().getByTestId('estimate-needqty')).toContainText('Add a quantity');
      await expect(it().getByTestId('estimate-nutrients')).toHaveCount(0);
      await expect(it().getByTestId('estimate-qty')).toHaveValue('');
      await expect(page.getByTestId('estimate-totals')).toContainText('nothing matched yet');
      await it().getByTestId('estimate-qty').fill('2'); await it().getByTestId('estimate-qty').press('Tab');
      await expect(it()).toHaveAttribute('data-status', 'matched');
      await expect(it().getByTestId('estimate-nutrients')).toContainText('kcal');
      // RACC (Foundation regulatory reference amount) never appears as a household measure
      await page.getByTestId('meal-description').fill('100 g tomatoes grape raw');
      await page.getByTestId('estimate-run').click();
      const opts = await page.getByTestId('estimate-item').first().getByTestId('estimate-measure').locator('option').allTextContents();
      expect(opts.length).toBeGreaterThan(1);
      expect(opts.join('|')).not.toMatch(/RACC/i);
    });

    test(`real ${W}: range / too-large amounts are "not understood, enter manually" and never counted`, async ({ page }) => {
      await open(page);
      await estimate(page, '2-3 eggs, 100000 g rice');
      const items = page.getByTestId('estimate-item');
      await expect(items.nth(0)).toHaveAttribute('data-status', 'unparsed');
      await expect(items.nth(0).getByTestId('estimate-unparsed')).toContainText('not a range');
      await expect(items.nth(0).getByTestId('estimate-nutrients')).toHaveCount(0);
      await expect(items.nth(1)).toHaveAttribute('data-status', 'unparsed');
      await expect(page.getByTestId('estimate-totals')).toContainText('nothing matched yet');
    });

    test(`real ${W}: over-long input shows a plain truncation note`, async ({ page }) => {
      await open(page);
      await estimate(page, Array.from({ length: 60 }, () => '1 egg').join(', '));
      await expect(page.getByTestId('estimate-truncated')).toContainText('only the first part was read');
      await expect(page.getByTestId('estimate-item')).toHaveCount(50);
    });

    test(`real ${W}: "1 cup mac and cheese" stays ONE ambiguous item: owner picks a candidate (or enters grams / edits the text); nothing auto-chosen`, async ({ page }) => {
      await open(page);
      await estimate(page, '1 cup mac and cheese');
      const items = page.getByTestId('estimate-item');
      await expect(items).toHaveCount(1);
      await expect(items.first()).toHaveAttribute('data-status', 'ambiguous');
      await expect(items.first().getByTestId('estimate-ambiguous')).toContainText('use a comma to enter the foods separately');
      await expect(items.first().getByTestId('estimate-nutrients')).toHaveCount(0);
      await expect(page.getByTestId('estimate-totals')).toContainText('nothing matched yet');
      const sel = items.first().getByTestId('estimate-food');
      await expect(sel).toHaveValue(''); // placeholder: no candidate chosen for them
      const labels = await sel.locator('option').allTextContents();
      expect(labels.length).toBeGreaterThanOrEqual(3);
      expect(labels.join('|')).toMatch(/Macaroni and cheese, frozen entree/i);
      await page.screenshot({ path: `${SHOTS}/p6-${W}-real-mac-and-cheese-ambiguous.png` });
      // pick a candidate that has a "cup" measure
      await sel.selectOption('SR:173342');
      await expect(items.first()).toHaveAttribute('data-status', 'matched');
      await expect(items.first().getByTestId('estimate-source')).toContainText('fdcId 173342');
      await expect(items.first().getByTestId('estimate-grams')).toHaveValue('137');
      await expect(page.getByTestId('estimate-totals')).not.toContainText('nothing matched yet');
      // pick a candidate WITHOUT a cup measure: no density guessed, owner types grams
      await items.first().getByTestId('estimate-food').selectOption('SR:173325');
      await expect(items.first()).toHaveAttribute('data-status', 'no_portion');
      await expect(items.first().getByTestId('estimate-noportion')).toContainText('No household measure');
      await expect(items.first().getByTestId('estimate-nutrients')).toHaveCount(0);
      await items.first().getByTestId('estimate-grams').fill('200'); await items.first().getByTestId('estimate-grams').press('Tab');
      await expect(items.first()).toHaveAttribute('data-status', 'matched');
      await expect(items.first().getByTestId('estimate-source')).toContainText('grams you entered');
      const m = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
      expect(m.sw).toBeLessThanOrEqual(m.cw);
      await page.screenshot({ path: `${SHOTS}/p6-${W}-real-mac-and-cheese-picked.png` });
    });

    test(`real ${W}: editing the text with a comma splits "mac and cheese" into separate items`, async ({ page }) => {
      await open(page);
      await estimate(page, '1 cup mac and cheese');
      await expect(page.getByTestId('estimate-item')).toHaveCount(1);
      await estimate(page, '1 cup mac, 1 egg');
      await expect(page.getByTestId('estimate-item')).toHaveCount(2);
      await expect(page.getByTestId('estimate-item').nth(1)).toHaveAttribute('data-status', 'matched');
    });

    test(`real ${W}: food-db.js unreachable -> message, manual entry works, no load warning`, async ({ page }) => {
      await open(page, { db: 'missing' });
      await page.getByTestId('meal-description').fill('1 cup milk');
      await page.getByTestId('estimate-run').click();
      await expect(page.getByTestId('estimate-message')).toContainText('Food data could not be loaded');
      await expect(page.getByTestId('load-guard')).toBeHidden();
      await page.getByTestId('component-name').fill('Manual milk');
      await page.getByTestId('meal-save-draft').click();
      expect(await meals(page)).toHaveLength(1);
    });
  });
}
