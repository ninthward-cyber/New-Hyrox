'use strict';
// RC1: Block 2 activation with a SIMULATED December date. The date is simulated ONLY by Playwright's test clock
// (page.clock.setFixedTime / page.clock.install + fastForward); the app has no override, flag, query parameter or debug
// hook (see rc1-no-override.test.js, which greps the deploy publish/ files). Synthetic data only.
// Downgrade tests open the VERIFIED older deploy packages (Claude P11.2 c85d8247…, Claude P11 b8275adb…, P10b da206f89…)
// on the SAME origin (same localStorage) via a second local static server. CHROME MOBILE EMULATION, NOT SAFARI/WEBKIT.
const { test, expect } = require('@playwright/test');
const fs = require('fs'), os = require('os'), path = require('path'), { spawn } = require('child_process');

const Q = (iso) => new Date(iso); // every ISO below carries +03:00 (Asia/Qatar)
const OLD = {
  c112: process.env.RC1_OLD_C112 || '/workspace/rc1-old/c112/hyrox-phase11-2-deploy-claude/publish',
  p11: process.env.RC1_OLD_P11 || '/workspace/rc1-old/p11/hyrox-phase11-deploy/publish',
  p10b: process.env.RC1_OLD_P10B || '/workspace/rc1-old/p10b/hyrox-phase10b-deploy/publish',
};
const K = (v) => ({ value: v, state: 'KNOWN' });
const MYFOOD = { id: 'mf-rc1', name: 'Labneh wrap (my value)', portion: '1 wrap', kcal: K(410), proteinG: K(18), carbsG: K(45), fatG: K(17), sodiumMg: K(720), basis: 'your values', savedAt: '2026-11-19T08:00:00.000Z', fromMealId: null };

const stored = (page) => page.evaluate(() => JSON.parse(localStorage.getItem('hyrox.v1') || '{}'));
const settingsRec = async (page) => ((await stored(page)).ownerSettings || []).find((x) => x.id === 'app-settings');
async function openFold(page, fold, toggle) { const d = page.getByTestId(fold); await d.waitFor({ state: 'attached' }); if (!(await d.evaluate((e) => e.open))) await page.getByTestId(toggle).click(); }
const openPlanner = (page) => openFold(page, 'today-planner', 'today-planner-toggle');
async function ready(page) { await expect(page.getByTestId('app-error')).toBeHidden(); await expect(page.getByTestId('today-glance')).toBeVisible(); }
async function boot(page, now, opts) {
  opts = opts || {};
  page.on('dialog', (d) => d.accept());
  page._errs = []; page.on('pageerror', (e) => page._errs.push(e.message));
  await page.clock.setFixedTime(Q(now));
  await page.goto(opts.url || './');
  if (opts.clear !== false) await page.evaluate(() => localStorage.clear());
  if (opts.seed) await page.evaluate((s) => localStorage.setItem('hyrox.v1', JSON.stringify(s)), opts.seed);
  await page.reload(); await ready(page);
}
async function setNow(page, now) { await page.clock.setFixedTime(Q(now)); await page.reload(); await ready(page); }
// Draft created through the UI (planner fold) on the current simulated date.
async function createDraftUI(page, start) {
  await openPlanner(page);
  if (start) await page.getByTestId('planner-start').selectOption(start);
  await page.getByTestId('planner-create').click();
  await expect(page.getByTestId('planner-draft')).toBeVisible();
}
async function approveAndActivate(page) {
  await openPlanner(page);
  await page.getByTestId('planner-preview-toggle').click();
  await page.getByTestId('planner-approve').check();
  await expect(page.getByTestId('planner-activate')).toBeEnabled();
  await page.getByTestId('planner-activate').click();
  await expect(page.getByTestId('planner-active')).toBeVisible();
}
async function exportText(page) {
  await page.getByTestId('tab-settings').click();
  const [dl] = await Promise.all([page.waitForEvent('download'), page.getByTestId('export-btn').click()]);
  return fs.readFileSync(await dl.path(), 'utf8');
}

for (const W of [390, 320]) {
  test.describe(`RC1 activation, simulated date ${W}px (Chrome emulation, not Safari/WebKit)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });

    test(`${W}: 10 Dec 23:59:59 refused → 11 Dec 00:00:00 allowed (UI); activates for Mon 14 Dec; saved foods untouched`, async ({ page }) => {
      await boot(page, '2026-11-19T10:00:00+03:00');
      await page.evaluate((mf) => { const HD = window.HyroxData; const r = HD.createStore().putRecord('ownerSettings', { id: HD.SETTINGS_ID, date: '2026-11-19', myFoods: [mf], favFoods: ['my:' + mf.id] }); if (!r.ok) throw new Error('seed'); }, MYFOOD);
      await page.reload(); await ready(page);
      await createDraftUI(page);
      await setNow(page, '2026-12-10T23:59:59+03:00');
      await openPlanner(page);
      await page.getByTestId('planner-preview-toggle').click();
      await expect(page.getByTestId('planner-approve')).toBeDisabled();
      await expect(page.getByTestId('planner-activate')).toBeDisabled();
      await expect(page.getByTestId('planner-activate-status')).toContainText('Activation opens on');
      // engine check with the app's own today (simulated clock): refused before 11 Dec
      expect(await page.evaluate(() => { const HB = window.HyroxBlocks, HD = window.HyroxData; const s = HD.createStore().settings().record; return HB.activationCheck(s.planBlocks, s.planBlocks[0].id, HD.todayQatar(), { approved: true }).code; })).toBe('BEFORE_DECISION_DATE');
      await setNow(page, '2026-12-11T00:00:00+03:00');
      await approveAndActivate(page);
      await expect(page.getByTestId('planner-active-state')).toContainText('starts Mon 14 Dec');
      const rec = await settingsRec(page);
      expect([rec.planBlocks.length, rec.planBlocks[0].state, rec.planBlocks[0].startDate, rec.planBlocks[0].activatedAt.slice(0, 10)]).toEqual([1, 'ACTIVATED', '2026-12-14', '2026-12-10']); // 00:00 +03 = 21:00Z on 10 Dec
      expect([rec.myFoods, rec.favFoods]).toEqual([[MYFOOD], ['my:mf-rc1']]);
      await expect(page.getByTestId('today-card')).toContainText('Week 4/4'); // 11 Dec is still Block 1 (Benchmark 2 day)
      expect(((await stored(page)).planEvents || []).length).toBe(0);
      expect(page._errs).toEqual([]);
    });

    test(`${W}: resume across Asia/Qatar midnight without reload: 13 Dec 23:59:50 Block 1 → 14 Dec Block 2 Week 1 (running clock)`, async ({ page }) => {
      await boot(page, '2026-12-11T09:00:00+03:00');
      await createDraftUI(page); await approveAndActivate(page);
      const id = (await settingsRec(page)).planBlocks[0].id;
      await page.clock.install({ time: Q('2026-12-13T23:59:50+03:00') });
      await page.reload(); await ready(page);
      await expect(page.getByTestId('today-card')).toContainText('Week 4/4');
      await expect(page.getByTestId('today-card')).not.toContainText('Block 2 ·');
      await page.clock.fastForward('00:20');
      await page.evaluate(() => document.dispatchEvent(new Event('visibilitychange'))); // the app's own new-day check (checkDay)
      await expect(page.getByTestId('today-card')).toContainText('Mon 14 Dec · Block 2 · Week 1/4');
      await expect(page.getByTestId('today-card').getByTestId(`slot-${id}-W1-MON`)).toContainText('Strength A');
      expect(page._errs).toEqual([]);
    });
  });
}

test.describe('RC1 activation details 390px (Chrome emulation, not Safari/WebKit)', () => {
  test.use({ viewport: { width: 390, height: 844 } });

  test('late Monday start (21 Dec): 14–20 Dec not counted, not missed; Block 2 W1 is 21 Dec', async ({ page }) => {
    await boot(page, '2026-12-11T10:00:00+03:00');
    await createDraftUI(page, '2026-12-21'); await approveAndActivate(page);
    const b = (await settingsRec(page)).planBlocks[0];
    expect([b.startDate, b.endDate, b.slots[0].date, b.slots[19].date]).toEqual(['2026-12-21', '2027-01-17', '2026-12-21', '2027-01-15']);
    await setNow(page, '2026-12-16T09:00:00+03:00');
    await expect(page.getByTestId('block-status')).toContainText('Days before it are not counted and not missed');
    await expect(page.getByTestId('today-card')).not.toContainText('Week 1/4');
    await setNow(page, '2026-12-21T00:00:00+03:00');
    await expect(page.getByTestId('today-card')).toContainText('Mon 21 Dec · Block 2 · Week 1/4');
    const sum = await page.evaluate(() => { const HB = window.HyroxBlocks, s = window.HyroxData.createStore(); return HB.summary(s.settings().record.planBlocks[0], s.records('sessions')); });
    expect([sum.denominator, sum.NOT_LOGGED]).toEqual([20, 20]);
  });

  test('end of Block 2: 10 Jan 23:59:59 Week 4 (deload) → 11 Jan 00:00 no active block, no automatic rollover', async ({ page }) => {
    await boot(page, '2026-12-11T10:00:00+03:00');
    await createDraftUI(page); await approveAndActivate(page);
    await setNow(page, '2027-01-10T23:59:59+03:00');
    await expect(page.getByTestId('today-card')).toContainText('Block 2 · Week 4/4');
    await setNow(page, '2027-01-11T00:00:00+03:00');
    await expect(page.getByTestId('today-card')).not.toContainText('Block 2 ·');
    await expect(page.getByTestId('today-card')).toContainText('no active block');
    const rec = await settingsRec(page);
    expect(rec.planBlocks.map((b) => [b.state, b.startDate])).toEqual([['ACTIVATED', '2026-12-14']]); // nothing new was created
    await openPlanner(page);
    await expect(page.getByTestId('planner-active-state')).toHaveText('Finished');
  });

  test('Block 1 last session day + Block 2 first day: each log stays in its own block; Block 1 slot ids and history unchanged', async ({ page }) => {
    await boot(page, '2026-12-11T18:00:00+03:00');
    const b1Before = await page.evaluate(() => JSON.stringify(window.HyroxPlan.SLOTS));
    await createDraftUI(page); await approveAndActivate(page);
    const id = (await settingsRec(page)).planBlocks[0].id;
    await page.getByTestId('today-card').getByTestId('log-slot-v2.1-W4-FRI').click();
    await page.getByTestId('session-status').selectOption('PARTIAL');
    await page.getByTestId('session-save').click();
    await expect(page.getByTestId('ext-toast')).toContainText('Saved');
    await setNow(page, '2026-12-14T18:00:00+03:00');
    await page.getByTestId('today-card').getByTestId(`log-slot-${id}-W1-MON`).click();
    await expect(page.getByTestId('session-slot')).toHaveValue(`${id}-W1-MON`);
    await page.getByTestId('session-status').selectOption('PARTIAL');
    await page.getByTestId('session-save').click();
    await expect(page.getByTestId('ext-toast')).toContainText('Saved');
    const s = await stored(page);
    expect(s.sessions.map((x) => [x.date, x.planSlotId, x.planVersion]).sort()).toEqual([['2026-12-11', 'v2.1-W4-FRI', 'v2.1'], ['2026-12-14', `${id}-W1-MON`, 'b2-hold-1']]);
    const res = await page.evaluate(() => { const HP = window.HyroxPlan, HB = window.HyroxBlocks, st = window.HyroxData.createStore(), ss = st.records('sessions');
      return { b1: HP.summary(ss, st.records('planEvents')), b2: HB.summary(st.settings().record.planBlocks[0], ss), slots: JSON.stringify(HP.SLOTS) }; });
    expect([res.b1.PARTIAL, res.b1.denominator, res.b2.PARTIAL, res.b2.denominator]).toEqual([1, 20, 1, 20]);
    expect(res.slots).toBe(b1Before);
    expect((s.planEvents || []).length).toBe(0);
  });

  test('duplicate activation in two tabs: the second tab is refused (stale) and exactly one activation is stored', async ({ context }) => {
    const a = await context.newPage(), b = await context.newPage();
    await boot(a, '2026-12-11T10:00:00+03:00');
    await createDraftUI(a);
    await b.clock.setFixedTime(Q('2026-12-11T10:00:30+03:00')); b.on('dialog', (d) => d.accept());
    await b.goto('./'); await ready(b);
    for (const p of [a, b]) { await openPlanner(p); await p.getByTestId('planner-preview-toggle').click(); await p.getByTestId('planner-approve').check(); await expect(p.getByTestId('planner-activate')).toBeEnabled(); }
    await a.getByTestId('planner-activate').click();
    await expect(a.getByTestId('planner-active')).toBeVisible();
    const first = (await settingsRec(a)).planBlocks[0].activatedAt;
    await b.getByTestId('planner-activate').click();
    await expect(b.getByTestId('ext-toast')).toContainText('Not saved');
    const rec = await settingsRec(b);
    expect(rec.planBlocks.filter((x) => x.state === 'ACTIVATED').length).toBe(1);
    expect(rec.planBlocks[0].activatedAt).toBe(first);
  });

  test('backup with an active block + saved foods: export → wipe → restore → reopen: Block 2 still active, foods intact', async ({ page }) => {
    await boot(page, '2026-12-11T10:00:00+03:00');
    await page.evaluate((mf) => { const HD = window.HyroxData; HD.createStore().putRecord('ownerSettings', { id: HD.SETTINGS_ID, date: '2026-12-11', myFoods: [mf], favFoods: ['my:' + mf.id, 'FN:2707154'] }); }, MYFOOD);
    await page.reload(); await ready(page);
    await createDraftUI(page); await approveAndActivate(page);
    await setNow(page, '2026-12-15T09:00:00+03:00');
    const before = await settingsRec(page);
    const text = await exportText(page);
    expect(JSON.parse(text).ownerSettings[0].planBlocks[0].state).toBe('ACTIVATED');
    await page.evaluate(() => localStorage.clear()); await page.reload(); await ready(page);
    await expect(page.getByTestId('today-card')).not.toContainText('Block 2 ·');
    await page.getByTestId('tab-settings').click();
    await page.getByTestId('import-file').setInputFiles({ name: 'rc1-backup.json', mimeType: 'application/json', buffer: Buffer.from(text) });
    await expect(page.getByTestId('import-preview-plan-blocks')).toContainText('Plan blocks differ');
    await page.getByTestId('import-confirm').click();
    await expect(page.getByTestId('import-result')).toContainText(/restored/i);
    await page.reload(); await ready(page);
    const after = await settingsRec(page);
    expect(after.planBlocks).toEqual(before.planBlocks);
    expect([after.myFoods, after.favFoods]).toEqual([before.myFoods, before.favFoods]);
    await page.getByTestId('tab-today').click();
    await expect(page.getByTestId('today-card')).toContainText('Tue 15 Dec · Block 2 · Week 1/4');
  });
});

// ---------- downgrade after activation: the verified older deploy packages on the same origin ----------
const MIX_PORT = Number(process.env.HYROX_RC1_MIX_PORT || 4493), MIX = 'http://127.0.0.1:' + MIX_PORT;
let server, root;
test.describe('RC1 downgrade after activation 390px (Chrome emulation, not Safari/WebKit)', () => {
  test.use({ viewport: { width: 390, height: 844 } });
  test.beforeAll(async () => {
    root = fs.mkdtempSync(path.join(os.tmpdir(), 'rc1-mix-'));
    fs.symlinkSync(process.env.HYROX_APP_ROOT || path.join(__dirname, '..', '..'), path.join(root, 'rc1'));
    for (const [k, v] of Object.entries(OLD)) { if (!fs.existsSync(path.join(v, 'index.html'))) throw new Error('missing verified old deploy ' + v); fs.symlinkSync(v, path.join(root, k)); }
    server = spawn(process.execPath, [path.join(__dirname, '..', 'static-server.js')], { env: Object.assign({}, process.env, { HYROX_APP_ROOT: root, HYROX_APP_PORT: String(MIX_PORT) }), stdio: 'ignore' });
    for (let i = 0; i < 50; i++) { try { const r = await fetch(MIX + '/rc1/index.html'); if (r.ok) return; } catch (e) { /* wait */ } await new Promise((r) => setTimeout(r, 100)); }
    throw new Error('mix server did not start');
  });
  test.afterAll(() => { if (server) server.kill(); if (root) fs.rmSync(root, { recursive: true, force: true }); });

  for (const tree of ['c112', 'p11', 'p10b']) {
    test(`activated Block 2 + a Block 2 session + saved foods opened in ${tree}: settings save and export keep planBlocks, foods and the session link; back in RC1 Block 2 is active`, async ({ page }) => {
      await boot(page, '2026-12-11T10:00:00+03:00', { url: MIX + '/rc1/index.html' });
      await page.evaluate((mf) => { const HD = window.HyroxData; HD.createStore().putRecord('ownerSettings', { id: HD.SETTINGS_ID, date: '2026-12-11', myFoods: [mf], favFoods: ['my:' + mf.id] }); }, MYFOOD);
      await page.reload(); await ready(page);
      await createDraftUI(page); await approveAndActivate(page);
      const id = (await settingsRec(page)).planBlocks[0].id;
      await setNow(page, '2026-12-14T18:00:00+03:00');
      await page.getByTestId('today-card').getByTestId(`log-slot-${id}-W1-MON`).click();
      await page.getByTestId('session-status').selectOption('PARTIAL');
      await page.getByTestId('session-save').click();
      await expect(page.getByTestId('ext-toast')).toContainText('Saved');
      const before = await stored(page);
      // older build, same origin, same storage
      await page.goto(MIX + '/' + tree + '/index.html'); await expect(page.getByTestId('app-error')).toBeHidden();
      await page.getByTestId('tab-settings').click(); await page.getByTestId('set-save').click();
      const exp = JSON.parse(await exportText(page));
      const os2 = exp.ownerSettings.find((x) => x.id === 'app-settings');
      expect(os2.planBlocks).toEqual(before.ownerSettings[0].planBlocks);
      expect(os2.myFoods).toEqual([MYFOOD]);
      expect(exp.sessions.map((x) => x.planSlotId)).toEqual([`${id}-W1-MON`]);
      expect(exp.version).toBe(2);
      // back to RC1
      await page.goto(MIX + '/rc1/index.html'); await ready(page);
      await expect(page.getByTestId('today-card')).toContainText('Mon 14 Dec · Block 2 · Week 1/4');
      await expect(page.getByTestId('today-card').getByTestId(`slot-${id}-W1-MON`)).toContainText('Partial');
      expect((await settingsRec(page)).planBlocks).toEqual(before.ownerSettings[0].planBlocks);
    });
  }
});
