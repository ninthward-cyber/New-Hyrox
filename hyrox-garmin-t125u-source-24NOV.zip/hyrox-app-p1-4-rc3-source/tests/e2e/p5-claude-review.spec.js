'use strict';
// Claude Phase 5 independent review: browser checks for the two changes made in this review.
// Installed Chrome, 390x844 phone emulation. NOT WebKit, NOT iPhone Safari. Synthetic data only.
const fs = require('fs');
const { test, expect } = require('@playwright/test');

const T = '2026-11-10T06:00:00.000Z';
const NOW = '2026-11-12T06:00:00.000Z';
test.describe.configure({ mode: 'serial' });

async function boot(page, data) {
  await page.clock.setFixedTime(new Date(NOW));
  await page.goto('./');
  await page.evaluate((d) => { localStorage.clear(); if (d) localStorage.setItem('hyrox.v1', JSON.stringify(d)); }, data || null);
  await page.reload();
  await expect(page.getByTestId('app-error')).toBeHidden();
}
const W = (id, kg) => ({ id, createdAt: T, date: '2026-11-10', kg });

test('a backup this app would refuse is downloaded with NOT-RESTORABLE in its file name; content is the normal export', async ({ page }) => {
  await boot(page, { version: 1, weight: [W('w-syn-dup', 80), W('w-ok', 81), W('w-syn-dup', 82)], workouts: [], nutrition: [] });
  const before = await page.evaluate(() => localStorage.getItem('hyrox.v1'));
  await page.getByTestId('tab-settings').click();
  const [dl] = await Promise.all([page.waitForEvent('download'), page.getByTestId('export-btn').click()]);
  expect(dl.suggestedFilename()).toBe('hyrox-backup-2026-11-12-NOT-RESTORABLE.json');
  const text = fs.readFileSync(await dl.path(), 'utf8');
  const fromStore = await page.evaluate(() => window.HyroxData.createStore().exportJSON());
  expect(text.replace(/"exportedAt": "[^"]+"/, '')).toBe(fromStore.replace(/"exportedAt": "[^"]+"/, ''));
  await expect(page.getByTestId('export-not-restorable-head')).toContainText('its name ends in NOT-RESTORABLE');
  await expect(page.getByTestId('raw-recovery')).toBeVisible();
  expect(await page.evaluate(() => localStorage.getItem('hyrox.v1'))).toBe(before);
});

test('a healthy backup keeps the normal file name and shows no not-restorable warning', async ({ page }) => {
  await boot(page, { version: 1, weight: [W('w1', 80)], workouts: [], nutrition: [] });
  await page.getByTestId('tab-settings').click();
  const [dl] = await Promise.all([page.waitForEvent('download'), page.getByTestId('export-btn').click()]);
  expect(dl.suggestedFilename()).toBe('hyrox-backup-2026-11-12.json');
  await expect(page.getByTestId('export-not-restorable')).toBeHidden();
});

test('a year of daily logging exports as a restorable backup and restores through the UI onto an empty device', async ({ page }) => {
  test.setTimeout(90000);
  const O = (v) => ({ state: 'OBSERVED', value: v }), K = (v) => ({ value: v, state: 'KNOWN' });
  const d = (i) => new Date(Date.UTC(2026, 10, 11) - i * 864e5).toISOString().slice(0, 10);
  const data = { version: 2, weight: [], workouts: [], nutrition: [], meals: [], daily: [], walks: [] };
  for (let i = 0; i < 365; i++) {
    const D = d(i);
    data.weight.push({ id: 'w' + i, createdAt: T, date: D, kg: 80 });
    data.daily.push({ id: 'daily-' + D, createdAt: T, date: D, steps: O(8000), sleepH: O(7), soreness: O(2), rhr: O(60) });
    for (let j = 0; j < 4; j++) data.meals.push({ id: 'm' + i + '-' + j, createdAt: T, updatedAt: T, date: D, label: 'Meal ' + j, source: 'MANUAL', lifecycle: 'CONFIRMED', confirmedAt: T,
      eatenFraction: 1, components: [0, 1, 2].map((c) => ({ name: 'Item ' + c, role: 'MAIN', eatenFraction: null, kcal: K(300), proteinG: K(20), carbsG: K(30), fatG: K(10) })) });
    data.walks.push({ id: 'k' + i, createdAt: T, updatedAt: T, date: D, durationMin: 30, steps: 3000 });
  }
  await boot(page, data);
  await page.getByTestId('tab-settings').click();
  const [dl] = await Promise.all([page.waitForEvent('download'), page.getByTestId('export-btn').click()]);
  expect(dl.suggestedFilename()).toBe('hyrox-backup-2026-11-12.json');
  const text = fs.readFileSync(await dl.path(), 'utf8');
  expect(text.length).toBeGreaterThan(2000000); // over the old limit
  await expect(page.getByTestId('export-not-restorable')).toBeHidden();
  // new, empty device
  await page.evaluate(() => localStorage.clear());
  await page.reload();
  await page.getByTestId('tab-settings').click();
  await page.getByTestId('import-file').setInputFiles({ name: 'hyrox-backup-2026-11-12.json', mimeType: 'application/json', buffer: Buffer.from(text, 'utf8') });
  await expect(page.getByTestId('import-preview')).toBeVisible();
  await page.getByTestId('import-confirm').click();
  await expect(page.getByTestId('import-result')).toContainText(/restored/i, { timeout: 30000 });
  const n = await page.evaluate(() => { const s = window.HyroxData.createStore(); return [s.list('weight').length, s.records('meals').length, s.records('daily').length, s.records('walks').length]; });
  expect(n).toEqual([365, 1460, 365, 365]);
});

test('with a year of daily logging the app opens and saves in seconds, not ~15 s, and a save shows at once', async ({ page }) => {
  test.setTimeout(120000);
  const O = (v) => ({ state: 'OBSERVED', value: v }), K = (v) => ({ value: v, state: 'KNOWN' });
  const d = (i) => new Date(Date.UTC(2026, 10, 11) - i * 864e5).toISOString().slice(0, 10);
  const data = { version: 2, weight: [], workouts: [], nutrition: [], meals: [], daily: [], walks: [] };
  for (let i = 0; i < 365; i++) {
    const D = d(i);
    data.weight.push({ id: 'w' + i, createdAt: T, date: D, kg: 80 });
    data.daily.push({ id: 'daily-' + D, createdAt: T, date: D, steps: O(8000), sleepH: O(7), soreness: O(2), rhr: O(60) });
    for (let j = 0; j < 4; j++) data.meals.push({ id: 'm' + i + '-' + j, createdAt: T, updatedAt: T, date: D, label: 'Meal ' + j, source: 'MANUAL', lifecycle: 'CONFIRMED', confirmedAt: T,
      eatenFraction: 1, components: [0, 1, 2].map((c) => ({ name: 'Item ' + c, role: 'MAIN', eatenFraction: null, kcal: K(300), proteinG: K(20), carbsG: K(30), fatG: K(10) })) });
    data.walks.push({ id: 'k' + i, createdAt: T, updatedAt: T, date: D, durationMin: 30, steps: 3000 });
  }
  await page.clock.setFixedTime(new Date(NOW));
  await page.goto('./');
  await page.evaluate((x) => { localStorage.clear(); localStorage.setItem('hyrox.v1', JSON.stringify(x)); }, data);
  let t0 = Date.now();
  await page.reload();
  await expect(page.getByTestId('today-root')).not.toBeEmpty();
  const openMs = Date.now() - t0;
  await page.getByTestId('tab-add').click();
  await page.getByTestId('add-mode-walk').click();
  await page.getByTestId('walk-duration').fill('47');
  t0 = Date.now();
  await page.getByTestId('walk-submit').click();
  await expect(page.getByTestId('ext-toast')).toContainText('Saved');
  const saveMs = Date.now() - t0;
  console.log('# year of data: open ' + openMs + ' ms, save ' + saveMs + ' ms (Grok 9ba6e34: ~15,000 / ~14,000 ms here)');
  expect(openMs).toBeLessThan(5000);
  expect(saveMs).toBeLessThan(5000);
  // no stale screen: the new walk is listed straight away, and Today counts it
  await page.getByTestId('tab-history').click();
  await expect(page.getByTestId('history-walk').filter({ hasText: 'Walk 47 min' })).toHaveCount(1);
});
