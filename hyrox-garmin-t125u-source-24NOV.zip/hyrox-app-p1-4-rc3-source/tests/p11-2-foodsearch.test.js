'use strict';
// Phase 11.2 part 4: local food search (hyrox-foodsearch.js) and My foods storage. Pure / in-memory; no network, no AI.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const S = require('../src/data/hyrox-foodsearch.js');
const C = require('../src/data/hyrox-foodcalc.js');
const db = require('../src/data/food-db.json');
const ix = S.buildIndex(db, C.ALIASES);
const top = (q, o) => S.search(ix, q, o).results.map((r) => r.name);
const first = (q, o) => S.search(ix, q, o).results[0];

test('index: every USDA food is searchable, in memory only, built quickly', () => {
  assert.equal(ix.ok, true); assert.equal(ix.foods.length, 8167);
  const t = Date.now(); S.buildIndex(db, C.ALIASES); assert.ok(Date.now() - t < 2000);
  const src = fs.readFileSync(path.join(__dirname, '..', 'src', 'data', 'hyrox-foodsearch.js'), 'utf8');
  const code = src.replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, '');
  assert.equal(/localStorage|sessionStorage|indexedDB|fetch\(|XMLHttpRequest|WebSocket|sendBeacon/.test(code), false, 'no storage or network in the search module');
});
test('common US foods: alias / exact first', () => {
  assert.equal(first('egg').name, 'Egg, whole, raw, fresh'); assert.equal(first('egg').matchType, 'alias');
  assert.equal(first('eggs').name, 'Egg, whole, raw, fresh');
  assert.match(first('banana').name, /^Bananas, raw/);
  assert.match(first('rice').name, /^Rice, white, long-grain/);
  assert.match(first('oatmeal').name, /oats/i);
  assert.match(first('porridge').name, /oats/i); // alias outside the typed words
  assert.match(first('coke').name, /cola/i);
  assert.match(first('greek yogurt').name, /^Yogurt, Greek/);
});
test('brands and restaurant items (USDA SR Legacy, US market 2018)', () => {
  assert.equal(first('big mac').name, "McDONALD'S, BIG MAC");
  assert.equal(first('big mac').restaurant, true);
  assert.equal(first('mcdonalds fries').name, "McDONALD'S, french fries");
  assert.match(first('burger king whopper').name, /^BURGER KING, WHOPPER/);
  assert.ok(top('subway').every((n) => /SUBWAY/.test(n)));
});
test('branded ambiguity: a generic word lists several chains and never picks one by itself', () => {
  const r = S.search(ix, 'french fries');
  const chains = r.results.filter((x) => x.restaurant).map((x) => x.name.split(',')[0]);
  assert.ok(new Set(chains).size >= 3, 'several restaurants offered');
  assert.ok(r.results.every((x) => !('selected' in x) && !('component' in x)), 'search returns a list only');
});
test('typo tolerance and prefixes; every typed word must match', () => {
  assert.match(first('brocoli').name, /^Broccoli/); assert.equal(first('brocoli').matchType, 'typo');
  assert.match(first('bananna').name, /^Bananas, raw/);
  assert.match(first('chiken breast').name, /Chicken/);
  assert.match(first('banan').name, /^Bananas/); // prefix while typing
  assert.equal(S.search(ix, 'egg zzqqx').results.length, 0);
});
test('no result recovery: unknown text returns nothing (never a guess); empty / stop-word queries return nothing', () => {
  assert.equal(S.search(ix, 'xyzzy').results.length, 0);
  assert.equal(S.search(ix, 'starbucks').results.length, 0);
  assert.equal(S.search(ix, '').results.length, 0);
  assert.equal(S.search(ix, 'the of and').results.length, 0);
  assert.equal(S.search(ix, 'x'.repeat(500)).query.length <= S.MAX_QUERY, true);
});
test('recent and favourites are boosted but never beat an exact / alias match and are never auto-selected', () => {
  const plain = S.search(ix, 'milk').results;
  const sheep = plain[15];
  const boosted = S.search(ix, 'milk', { recentKeys: [sheep.key], favKeys: [sheep.key] }).results;
  assert.equal(boosted[0].matchType, 'alias'); // whole milk alias still first
  assert.ok(boosted.findIndex((x) => x.key === sheep.key) < plain.findIndex((x) => x.key === sheep.key));
  assert.equal(boosted.find((x) => x.key === sheep.key).recent, true);
});
test('servings, quantity and nutrients: USDA rounding, default serving, RACC never default, limits', () => {
  const sv = S.servingsFor(ix, 'SR:171287', 'large');
  assert.equal(sv.find((s) => s.isDefault).label, '1 large');
  assert.ok(sv.some((s) => s.label === '100 g') && sv.some((s) => s.label === '1 oz'));
  const r = S.usdaComponent(ix, 'SR:171287', sv.find((s) => s.isDefault), 2);
  assert.equal(r.ok, true);
  assert.deepEqual([r.component.kcal, r.component.proteinG.state, r.component.provenance.grams, r.component.provenance.fdcId], [{ value: 143, state: 'ESTIMATED' }, 'ESTIMATED', 100, 171287]);
  assert.equal(r.component.portion, '2 × 1 large (100 g)');
  // the same 100 g through the existing text estimator gives the same numbers
  const e = C.estimateItem('100 g egg', db); assert.equal(e.nutrients.kcal, r.component.kcal.value); assert.equal(e.nutrients.proteinG, r.component.proteinG.value);
  assert.equal(S.usdaComponent(ix, 'SR:171287', sv[0], 0).ok, false);
  assert.equal(S.usdaComponent(ix, 'SR:171287', sv[0], 51).ok, false);
  assert.equal(S.usdaComponent(ix, 'SR:171287', sv[0], NaN).ok, false);
  for (const f of ix.foods.slice(0, 400)) { const d = S.servingsFor(ix, f.key).find((s) => s.isDefault); assert.ok(d && !d.racc, f.key); }
});
test('a negative USDA carbohydrate is counted as 0 g and marked in provenance (valid for the meals validator)', () => {
  const f = ix.foods.find((x) => x.per100[2] < 0);
  const r = S.usdaComponent(ix, f.key, { label: '100 g', grams: 100 }, 1);
  assert.equal(r.component.carbsG.value, 0); assert.equal(r.component.provenance.carbsClampedToZero, true);
});

// ---------- My foods: storage in the owner-settings record (optional fields), round trips and rollback ----------
const HD = require('../src/data/hyrox-data.js');
const NOW = new Date('2026-11-19T09:00:00Z');
const mem = () => { const m = {}; return { getItem: (k) => (k in m ? m[k] : null), setItem(k, v) { m[k] = String(v); }, removeItem(k) { delete m[k]; } }; };
function mealWith(comps) {
  return { date: '2026-11-19', time: '12:00', label: 'Lunch', source: 'MANUAL', description: '', eatenFraction: 1, lifecycle: 'CONFIRMED', confirmedAt: NOW.toISOString(), ai: null, mealCategory: 'LUNCH', components: comps };
}
test('My foods keep source and estimate status; scaling keeps states; unknown stays unknown', () => {
  const usda = S.usdaComponent(ix, 'SR:171287', { label: '1 large', grams: 50 }, 1).component;
  const a = S.myFoodFromComponent(usda, { id: 'mf-a', mealId: 'm1' }).food;
  assert.equal(a.basis, 'USDA estimate'); assert.equal(a.kcal.state, 'ESTIMATED'); assert.equal(a.provenance.fdcId, 171287);
  const manual = { name: 'Home curry', role: 'MAIN', portion: '1 bowl', preparation: '', eatenFraction: null, kcal: { value: 450, state: 'KNOWN' }, proteinG: { value: null, state: 'UNKNOWN' }, carbsG: { value: 40, state: 'KNOWN' }, fatG: { value: null, state: 'UNKNOWN' } };
  const b = S.myFoodFromComponent(manual, { id: 'mf-b' }).food;
  assert.equal(b.basis, 'your values');
  const c2 = S.myFoodComponent(b, 2).component;
  assert.deepEqual([c2.kcal, c2.proteinG, c2.carbsG], [{ value: 900, state: 'KNOWN' }, { value: null, state: 'UNKNOWN' }, { value: 80, state: 'KNOWN' }]);
  const photo = S.myFoodFromComponent(Object.assign({}, manual, { kcal: { value: 300, state: 'ESTIMATED' } }), { id: 'mf-c', mealSource: 'PHOTO_AI' }).food;
  assert.equal(photo.basis, 'photo estimate'); assert.equal(photo.kcal.state, 'ESTIMATED'); // an estimate is never promoted
});
function storeWithFoods(H, n) {
  const st = H.createStore(mem(), { now: () => NOW });
  const usda = S.usdaComponent(ix, 'SR:171287', { label: '1 large', grams: 50 }, 1).component;
  const r = st.putRecord('meals', mealWith([usda])); assert.equal(r.ok, true, JSON.stringify(r.errors));
  const foods = [];
  for (let i = 0; i < n; i++) foods.push(S.myFoodFromComponent(i % 2 ? usda : Object.assign({}, usda, { provenance: undefined, name: 'Food ' + i }), { id: 'mf-' + i, savedAt: NOW.toISOString(), mealId: r.entry.id }).food);
  const s = st.putRecord('ownerSettings', { id: H.SETTINGS_ID, date: '2026-11-19', myFoods: foods, favFoods: ['SR:171287', 'my:mf-1'] });
  assert.equal(s.ok, true, JSON.stringify(s.errors));
  return st;
}
const roundTrip = (H, text) => {
  const storage = mem(), st = H.createStore(storage, { now: () => NOW });
  const p = st.previewImport(text); assert.equal(p.ok, true, JSON.stringify(p.errors || p.message));
  const r = st.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt }); assert.equal(r.ok, true, JSON.stringify(r));
  return H.createStore(storage, { now: () => NOW });
};
test('My foods / favourites (up to the 200 limit) save, export and restore exactly on this version; settings defaults unchanged', () => {
  const st = storeWithFoods(HD, S.MAX_MY_FOODS);
  const set = st.settings(); assert.equal(set.rhrBaselineSource, 'OWNER_DEFAULT'); assert.equal(set.stepBaselineMode, 'AUTO');
  const text = st.exportJSON();
  assert.ok(text.length < 400000, 'compact');
  const back = roundTrip(HD, text).settings().record;
  assert.equal(back.myFoods.length, 200); assert.deepEqual(back.favFoods, ['SR:171287', 'my:mf-1']);
  assert.deepEqual(back.myFoods, JSON.parse(text).ownerSettings[0].myFoods);
});
test('editing / deleting a saved food never changes a saved meal (copies, not links)', () => {
  const st = storeWithFoods(HD, 2);
  const mealBefore = JSON.stringify(st.records('meals'));
  const rec = JSON.parse(JSON.stringify(st.settings().record));
  rec.myFoods[1].name = 'Renamed'; rec.myFoods[1].kcal = { value: 999, state: 'KNOWN' }; rec.myFoods.splice(0, 1);
  assert.equal(st.putRecord('ownerSettings', rec).ok, true);
  assert.equal(JSON.stringify(st.records('meals')), mealBefore);
});
// Claude 11.2 review: environment overrides so these rollback tests can run off Grok's machine (paths only; assertions unchanged).
const OLD = { 'claude-p11': process.env.P112_P11_SRC || '/workspace/hyrox-p11-2-before/src', 'claude-p10b': process.env.P112_P10B_SRC || '/workspace/hyrox-p11-before/src', p9: process.env.P112_P9_SRC || '/workspace/hyrox-p9/src' };
for (const [name, dir] of Object.entries(OLD)) {
  const present = fs.existsSync(path.join(dir, 'data', 'hyrox-data.js'));
  (present ? test : test.skip)(`rollback: the ${name} data layer restores a Phase 11.2 backup with meals, provenance, myFoods and favFoods intact, and exports them again`, () => {
    const text = storeWithFoods(HD, 20).exportJSON();
    const OH = require(path.join(dir, 'data', 'hyrox-data.js'));
    const st = roundTrip(OH, text);
    const out = JSON.parse(st.exportJSON()), src = JSON.parse(text);
    assert.deepEqual(out.ownerSettings[0].myFoods, src.ownerSettings[0].myFoods);
    assert.deepEqual(out.ownerSettings[0].favFoods, src.ownerSettings[0].favFoods);
    assert.deepEqual(out.meals.map((m) => m.components), src.meals.map((m) => m.components));
  });
}
test('a P11 / P10b-era backup without myFoods restores on this version unchanged (no fields added)', () => {
  const st = HD.createStore(mem(), { now: () => NOW });
  st.putRecord('meals', mealWith([{ name: 'Toast', role: 'MAIN', portion: '', preparation: '', eatenFraction: null, kcal: { value: 100, state: 'KNOWN' }, proteinG: { value: null, state: 'UNKNOWN' }, carbsG: { value: null, state: 'UNKNOWN' }, fatG: { value: null, state: 'UNKNOWN' } }]));
  const text = st.exportJSON();
  const out = JSON.parse(roundTrip(HD, text).exportJSON());
  assert.deepEqual(out.meals, JSON.parse(text).meals); assert.equal(out.ownerSettings === undefined || out.ownerSettings.length === 0, true);
});
test('recentKeys: only CONFIRMED meals, newest first, distinct', () => {
  const c = (id) => ({ name: 'x', provenance: { source: 'USDA_FDC', dataset: 'SR', fdcId: id } });
  const meals = [{ lifecycle: 'CONFIRMED', confirmedAt: '2026-11-18T10:00:00Z', components: [c(1), c(2)] }, { lifecycle: 'DRAFT', components: [c(3)] }, { lifecycle: 'CONFIRMED', confirmedAt: '2026-11-19T10:00:00Z', components: [c(2), c(4)] }];
  assert.deepEqual(S.recentKeys(meals), ['SR:2', 'SR:4', 'SR:1']);
});
