'use strict';
// DAWIT 1: running-workout steps, daily-total priority, partial lower bound, NULL never 0.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const HW = require(path.resolve(__dirname, '../src/data/hyrox-wellness.js'));
const { HD, KEY, mem, mk, O, MISSING, ts, backup, restore } = require('./p3-helpers.js');

const D = '2026-11-11';
const day = (o) => Object.assign({ id: 'daily-' + D, createdAt: ts, date: D }, o);
const walk = (id, steps, extra) => Object.assign({ id, createdAt: ts, date: D, durationMin: 30, steps }, extra);
const run = (id, runSteps, extra) => Object.assign({ id, createdAt: ts, date: D, status: 'COMPLETED', modified: false, variant: 'NONE', blocks: [{ kind: 'run', distanceM: 5000, durationSec: 1500 }],
  runSteps, runStepsSource: runSteps == null ? undefined : 'DEVICE' }, extra);

describe('daySteps: priority, lower bound, missing', () => {
  it('a recorded daily total wins and walk + run steps are never added to it', () => {
    const r = HW.daySteps(D, { dailies: [day({ steps: O(12000) })], walks: [walk('w1', 3000)], sessions: [run('s1', 6000)] });
    assert.equal(r.total, 12000); assert.equal(r.source, 'daily'); assert.equal(r.complete, true);
    assert.equal(r.walkSteps, 3000); assert.equal(r.runSteps, 6000);
    assert.deepEqual(r.flags, ['WORKOUT_STEPS_NOT_ADDED']);
  });
  it('a daily total lower than the workout steps is kept as recorded and only flagged', () => {
    const r = HW.daySteps(D, { dailies: [day({ steps: O(4000) })], walks: [walk('w1', 3000)], sessions: [run('s1', 6000)] });
    assert.equal(r.total, 4000); assert.equal(r.source, 'daily');
    assert.deepEqual(r.flags, ['WORKOUT_STEPS_NOT_ADDED', 'DAILY_BELOW_WORKOUT_STEPS']);
  });
  it('without a daily total, walk + run steps are summed as a partial lower bound, never complete', () => {
    for (const dailies of [[], [day({ steps: MISSING })], [day({ steps: { state: 'NOT_TRACKED', value: null } })], [day({})]]) {
      const r = HW.daySteps(D, { dailies, walks: [walk('w1', 3000), walk('w2', 1000)], sessions: [run('s1', 6000)] });
      assert.equal(r.total, 10000); assert.equal(r.source, 'partial_lower_bound'); assert.equal(r.complete, false);
      assert.deepEqual(r.flags, ['LOWER_BOUND_NOT_DAY_TOTAL']);
    }
  });
  it('run steps alone or walk steps alone also form a lower bound; the absent part is not 0, it is absent', () => {
    const a = HW.daySteps(D, { sessions: [run('s1', 6000)] });
    assert.equal(a.total, 6000); assert.equal(a.walkSteps, null); assert.equal(a.walkCount, 0); assert.equal(a.source, 'partial_lower_bound');
    const b = HW.daySteps(D, { walks: [walk('w1', 3000)] });
    assert.equal(b.total, 3000); assert.equal(b.runSteps, null);
  });
  it('missing is NULL, never 0; a recorded 0 is a real 0', () => {
    const none = HW.daySteps(D, { dailies: [day({ steps: MISSING })], walks: [walk('w1', null)], sessions: [run('s1', null)] });
    assert.equal(none.total, null); assert.equal(none.source, null); assert.deepEqual(none.flags, ['NO_STEP_DATA']);
    assert.equal(HW.daySteps(D, {}).total, null);
    assert.equal(HW.daySteps(D, { dailies: [day({ steps: O(0) })] }).total, 0);
    const zeroRun = HW.daySteps(D, { sessions: [run('s1', 0)] });
    assert.equal(zeroRun.total, 0); assert.equal(zeroRun.source, 'partial_lower_bound');
  });
  it('never infers steps from distance or duration', () => {
    const r = HW.daySteps(D, { walks: [walk('w1', undefined, { distanceKm: 5, durationMin: 60 })], sessions: [run('s1', null)] });
    assert.equal(r.total, null);
  });
  it('no double counting: the same record passed twice counts once; other days do not count', () => {
    const s = run('s1', 6000), w = walk('w1', 3000);
    const r = HW.daySteps(D, { walks: [w, w, walk('w9', 999, { date: '2026-11-10' })], sessions: [s, s, run('s9', 777, { date: '2026-11-10' })] });
    assert.equal(r.total, 9000); assert.equal(r.walkCount, 1); assert.equal(r.runCount, 1);
  });
  it('omitting sessions reproduces the previous canonicalSteps behaviour exactly', () => {
    const c = HW.canonicalSteps(D, [day({ steps: MISSING })], [walk('w1', 3000)]);
    assert.equal(c.value, 3000); assert.equal(c.partial, true);
    assert.equal(c.source, 'walk sessions only — no daily total recorded, so this is a lower bound');
    assert.equal(HW.canonicalSteps(D, [day({ steps: O(7000) })], [walk('w1', 3000)]).source, 'declared daily total (walk steps not added)');
  });
  it('canonicalSteps and stepTarget include run steps when sessions are passed', () => {
    const c = HW.canonicalSteps(D, [], [walk('w1', 3000)], [run('s1', 6000)]);
    assert.equal(c.value, 9000); assert.equal(c.partial, true); assert.match(c.source, /walk and run sessions only/);
    assert.equal(c.detail.source, 'partial_lower_bound');
    const t = HW.stepTarget(D, { dailies: [], walks: [], sessions: [run('s1', 6000)], settings: { stepBaselineMode: 'MANUAL', stepBaselineManual: 8000 }, plannedToday: 1, recentSessions: [] });
    assert.equal(t.steps.value, 6000); assert.equal(t.met, null, 'a lower bound below target is unknown, not missed');
    const t2 = HW.stepTarget(D, { dailies: [], walks: [], sessions: [run('s1', 9000)], settings: { stepBaselineMode: 'MANUAL', stepBaselineManual: 8000 }, plannedToday: 1, recentSessions: [] });
    assert.equal(t2.met, true);
  });
});

describe('sessions.runSteps validation (putRecord and import)', () => {
  const base = { date: D, status: 'COMPLETED', modified: false, variant: 'NONE', blocks: [] };
  it('accepts a whole number with a source, and null/absent with no source', () => {
    const st = mk(mem());
    assert.equal(st.putRecord('sessions', Object.assign({}, base, { runSteps: 6000, runStepsSource: 'DEVICE' })).ok, true);
    assert.equal(st.putRecord('sessions', Object.assign({}, base, { runSteps: 0, runStepsSource: 'MANUAL' })).ok, true);
    assert.equal(st.putRecord('sessions', Object.assign({}, base, { runSteps: null })).ok, true);
    assert.equal(st.putRecord('sessions', base).ok, true);
    assert.equal(st.records('sessions').length, 4);
  });
  it('rejects negatives, fractions, strings, out-of-range, missing or unknown source, orphan source', () => {
    const st = mk(mem());
    const bad = [{ runSteps: -1, runStepsSource: 'DEVICE' }, { runSteps: 10.5, runStepsSource: 'DEVICE' }, { runSteps: '6000', runStepsSource: 'DEVICE' },
      { runSteps: 200001, runStepsSource: 'DEVICE' }, { runSteps: 6000 }, { runSteps: 6000, runStepsSource: 'ESTIMATED' }, { runStepsSource: 'DEVICE' },
      { runSteps: NaN, runStepsSource: 'DEVICE' }];
    bad.forEach((b) => assert.equal(st.putRecord('sessions', Object.assign({}, base, b)).ok, false, JSON.stringify(b)));
  });
  it('rejects run steps on a session that was not started or was skipped', () => {
    const st = mk(mem());
    assert.equal(st.putRecord('sessions', Object.assign({}, base, { status: 'NOT_STARTED', runSteps: 10, runStepsSource: 'DEVICE' })).ok, false);
    assert.equal(st.putRecord('sessions', Object.assign({}, base, { status: 'SKIPPED', skipConfirmed: true, runSteps: 10, runStepsSource: 'DEVICE' })).ok, false);
    assert.equal(st.putRecord('sessions', Object.assign({}, base, { status: 'PARTIAL', runSteps: 10, runStepsSource: 'DEVICE' })).ok, true);
  });
  it('walk stepsSource is optional; old walks without it stay valid; a source needs a count', () => {
    const st = mk(mem());
    assert.equal(st.putRecord('walks', { date: D, durationMin: 30, steps: 3000 }).ok, true);
    assert.equal(st.putRecord('walks', { date: D, durationMin: 30, steps: 3000, stepsSource: 'DEVICE' }).ok, true);
    assert.equal(st.putRecord('walks', { date: D, durationMin: 30, stepsSource: 'DEVICE' }).ok, false);
    assert.equal(st.putRecord('walks', { date: D, durationMin: 30, steps: 3000, stepsSource: 'GUESS' }).ok, false);
  });
  it('import validates the new field: one bad runSteps rejects the whole file and writes nothing', () => {
    const s = mem(); const st = mk(s); st.addWeight({ date: D, kg: 80 });
    const before = s.m[KEY], writes = s.writes;
    const text = backup({ sessions: [run('s1', 6000), run('s2', -5)] });
    const p = st.previewImport(text);
    assert.equal(p.ok, false); assert.equal(p.code, 'invalid_records');
    assert.ok(p.errors.some((e) => e.list === 'sessions' && e.index === 1 && e.field === 'runSteps'));
    assert.equal(st.applyImport(text, { confirm: 'REPLACE', expectCurrent: { weight: 1, workouts: 0, nutrition: 0 } }).ok, false);
    assert.equal(s.m[KEY], before); assert.equal(s.writes, writes);
  });
  it('export -> import -> reload preserves runSteps, its source, and null exactly', () => {
    const s = mem(); const st = mk(s);
    st.putRecord('sessions', Object.assign({}, base, { id: 'a', runSteps: 6000, runStepsSource: 'DEVICE' }));
    st.putRecord('sessions', Object.assign({}, base, { id: 'b', runSteps: null }));
    st.putRecord('walks', { id: 'w', date: D, durationMin: 30, steps: 0, stepsSource: 'MANUAL' });
    const text = st.exportJSON();
    const s2 = mem(); const st2 = mk(s2);
    assert.equal(restore(st2, text).ok, true);
    const got = mk(s2).records('sessions');
    const a = got.find((x) => x.id === 'a'), b = got.find((x) => x.id === 'b');
    assert.equal(a.runSteps, 6000); assert.equal(a.runStepsSource, 'DEVICE');
    assert.equal(b.runSteps, null); assert.notEqual(b.runSteps, 0);
    assert.equal(mk(s2).records('walks')[0].steps, 0);
    assert.equal(JSON.parse(mk(s2).exportJSON()).sessions.length, 2);
    // repeat import: no duplicates
    assert.equal(restore(st2, text).ok, true);
    assert.equal(mk(s2).records('sessions').length, 2);
  });
  it('old data and backups without the new fields keep their meaning (no steps = not recorded)', () => {
    const text = backup({ sessions: [{ id: 's', createdAt: ts, date: D, status: 'COMPLETED', modified: false, variant: 'NONE', blocks: [{ kind: 'run', distanceM: 5000 }] }],
      walks: [{ id: 'w', createdAt: ts, date: D, durationMin: 30, steps: 2500 }] }, 1);
    const s = mem(); const st = mk(s);
    assert.equal(restore(st, text).ok, true);
    const r = HW.daySteps(D, { dailies: st.records('daily'), walks: st.records('walks'), sessions: st.records('sessions') });
    assert.equal(r.total, 2500); assert.equal(r.runSteps, null); assert.equal(r.source, 'partial_lower_bound');
    assert.deepEqual(HD.ENUMS.stepsSource, ['DEVICE', 'MANUAL']);
  });
});
