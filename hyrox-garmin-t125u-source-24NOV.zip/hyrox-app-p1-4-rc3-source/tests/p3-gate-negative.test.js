'use strict';
const test = require('node:test');
const assert = require('node:assert');
const W = require('../src/data/hyrox-wellness.js');

test('step10kGate: a negative pain value is UNKNOWN, never PASS', () => {
  const a = W.step10kGate({ footPain: -1, limp: false, stairKneePain: 1, sleepH: 7 });
  assert.strictEqual(a.status, 'UNKNOWN'); assert.strictEqual(a.pass, false); assert.deepStrictEqual(a.missing, ['footPain']);
  const b = W.step10kGate({ footPain: 1, limp: false, stairKneePain: -1, sleepH: 7 });
  assert.strictEqual(b.status, 'UNKNOWN'); assert.strictEqual(b.pass, false); assert.deepStrictEqual(b.missing, ['stairKneePain']);
});
test('step10kGate: a failed input still wins over an invalid one', () => {
  const g = W.step10kGate({ footPain: -1, limp: true, stairKneePain: 1, sleepH: 7 });
  assert.strictEqual(g.status, 'FAIL'); assert.deepStrictEqual(g.failed, ['limp']);
});
test('step10kGate: boundaries 0 and 2 pass, 3 fails, 11 (out of range, owner t54u), NaN and strings are UNKNOWN', () => {
  const ok = { limp: false, sleepH: 7 };
  assert.strictEqual(W.step10kGate(Object.assign({ footPain: 0, stairKneePain: 2 }, ok)).status, 'PASS');
  assert.strictEqual(W.step10kGate(Object.assign({ footPain: 3, stairKneePain: 0 }, ok)).status, 'FAIL');
  assert.strictEqual(W.step10kGate(Object.assign({ footPain: 11, stairKneePain: 0 }, ok)).status, 'UNKNOWN');
  assert.strictEqual(W.step10kGate(Object.assign({ footPain: NaN, stairKneePain: 0 }, ok)).status, 'UNKNOWN');
  assert.strictEqual(W.step10kGate(Object.assign({ footPain: '1', stairKneePain: 0 }, ok)).status, 'UNKNOWN');
});
