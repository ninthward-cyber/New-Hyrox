'use strict';
// Phase 10, on-device logic (no browser, no network): eaten amounts read from the meal note (butter-chicken acceptance
// fixture), served-vs-eaten scaling applied exactly once, partial/unknown totals, stale-estimate basis, double-count
// warnings, the multi-photo client session, stable request ids, safe diagnostics, Quick "Log steps", older-backup
// compatibility and rollback to the corrected Phase 9 data layer.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { execFileSync } = require('node:child_process');
const AI = require(path.resolve(__dirname, '../src/ai/photo-ai.js'));
const HN = require(path.resolve(__dirname, '../src/data/hyrox-nutrition.js'));
const { HD, NOW, mem, mk, O, MISSING, restore } = require('./p8-helpers.js'); // NOW = 18 Nov 2026 12:00 Asia/Qatar

const FIX = path.join(__dirname, 'fixtures');
const jpeg = (n) => ({ sanitized: true, mime: 'image/jpeg', bytes: AI.stripJpegMetadata(new Uint8Array(fs.readFileSync(path.join(FIX, n)))) });
const CONSENT = { privacyAck: true, sendThisPhoto: true };
const M = (v) => ({ value: v, state: 'ESTIMATED' });
const UNK = { value: null, state: 'UNKNOWN' };

// The P10 acceptance fixture, as the photo model returns it (served basis, two non-overlapping items + unseen ghee).
function butterChickenDraft() {
  const comps = AI.resultToComponents(AI.MOCK_FIXTURES.butterChicken);
  return { date: '2026-11-18', time: '13:00', label: 'Butter chicken', source: 'PHOTO_AI', description: 'butter chicken, all chicken eaten, 60% sauce',
    eatenFraction: null, components: comps, ai: { mode: 'MOCK', provider: 'mock-fixture', model: 'mock-fixture-v1', analyzedAt: NOW.toISOString(), warnings: [], userCorrected: false }, lifecycle: 'NEEDS_REVIEW' };
}
function applyNote(meal) {
  const nf = AI.noteFractions(meal.description, meal.components);
  nf.suggestions.forEach((s) => { meal.components[s.index].eatenFraction = s.fraction; });
  if (nf.meal) meal.eatenFraction = nf.meal.fraction;
  return nf;
}

describe('P10 butter-chicken acceptance fixture', () => {
  it('the model result has chicken pieces and the sauce as distinct items, served-portion numbers, and no eaten amount', () => {
    const comps = AI.resultToComponents(AI.MOCK_FIXTURES.butterChicken);
    assert.deepEqual(comps.map((c) => c.role), ['MAIN', 'SAUCE', 'OIL']);
    assert.ok(comps.every((c) => c.eatenFraction === null));
    assert.deepEqual(AI.overlapWarnings(comps), []); // no whole dish + its sauce
    assert.equal(comps[2].kcal.state, 'UNKNOWN'); // unseen ghee stays unknown, never invented
  });
  it('the note typed once maps to chicken 100% and sauce 60% (deterministic), nothing for the ghee, no meal-level guess', () => {
    const m = butterChickenDraft();
    const nf = AI.noteFractions(m.description, m.components);
    assert.deepEqual(nf.suggestions.map((s) => [s.index, s.fraction]), [[0, 1], [1, 0.6]]);
    assert.equal(nf.meal, null); assert.deepEqual(nf.unmatched, []);
    // Claude P10 review (owner decision 17 Nov 2026): amounts are removed, food words are kept (was 'butter chicken').
    assert.equal(AI.analysisNote(m.description), 'butter chicken, chicken, sauce'); // what the photo model is told: served basis + food context
  });
  it('applied exactly once: 250 x 100% + 300 x 60% = 430 kcal; applying again changes nothing; never 250 + 300 + 180', () => {
    const m = butterChickenDraft();
    applyNote(m);
    m.eatenFraction = 1; // owner states the rest (the unseen ghee) so the meal can be confirmed
    const t1 = HN.mealTotals(m);
    assert.equal(t1.kcal.value, 430); assert.equal(t1.proteinG.value, 38 + 2.4); assert.equal(t1.fatG.value, 10 + 15.6);
    assert.equal(t1.kcal.state, 'PARTIAL'); // the ghee is unknown: a partial total, not a complete one
    applyNote(m); applyNote(m);
    assert.deepEqual(HN.mealTotals(m), t1);
    // the meal-level amount never multiplies an item that has its own amount
    m.eatenFraction = 0.5;
    assert.equal(HN.mealTotals(m).kcal.value, 430);
    assert.equal(HN.fractionStated(m), true);
  });
  it('without a stated amount for every item the photo meal cannot be confirmed (owner rule kept)', () => {
    const m = butterChickenDraft();
    applyNote(m);
    assert.equal(HN.fractionStated(m), false); // ghee has no amount and there is no meal-level amount
  });
  it('a whole dish next to its own sauce is flagged as a possible double count', () => {
    const w = AI.overlapWarnings([{ name: 'Butter chicken', role: 'MAIN' }, { name: 'Butter chicken sauce', role: 'SAUCE' }]);
    assert.equal(w.length, 1); assert.equal(w[0].kind, 'DISH_AND_SAUCE');
    const d = AI.overlapWarnings([{ name: 'White rice', role: 'SIDE' }, { name: 'white rice', role: 'SIDE' }]);
    assert.equal(d[0].kind, 'SAME_NAME'); // same plate seen in two photos, listed twice
  });
});

describe('P10 note parsing rules (deterministic; user confirms)', () => {
  const comps = [{ name: 'Grilled chicken', role: 'MAIN' }, { name: 'White rice', role: 'SIDE' }, { name: 'Garlic sauce', role: 'SAUCE' }];
  for (const [note, expected, meal] of [
    ['ate half the rice', [[1, 0.5]], null],
    ['finished all the chicken; 25% rice', [[0, 1], [1, 0.25]], null],
    ['ate none of the sauce', [[2, 0]], null],
    ['ate half', [], 0.5],
    ['rice 75%', [[1, 0.75]], null],
    ['three quarters of the rice eaten', [[1, 0.75]], null],
  ]) it(`"${note}"`, () => {
    const nf = AI.noteFractions(note, comps);
    assert.deepEqual(nf.suggestions.map((s) => [s.index, s.fraction]), expected);
    assert.equal(nf.meal ? nf.meal.fraction : null, meal);
  });
  it('descriptions of the food itself are NOT read as eaten amounts and are sent for analysis', () => {
    for (const note of ['half portion, no sauce', 'a whole chicken breast', 'a glass of 2% milk', '200 g rice 50% brown']) {
      assert.equal(AI.noteFractions(note, comps).suggestions.length, 0, note);
    }
    assert.equal(AI.analysisNote('half portion, no sauce'), 'half portion, no sauce');
    assert.equal(AI.analysisNote('a glass of 2% milk, ate half the rice'), 'a glass of 2% milk, rice'); // Claude P10 review: 'rice' kept (was dropped)
  });
  it('an eaten amount for a food that is not in the list is reported, not dropped or guessed', () => {
    const nf = AI.noteFractions('60% bread', comps);
    assert.deepEqual(nf.suggestions, []); assert.deepEqual(nf.unmatched, ['60% bread']);
  });
  it('out-of-range percentages are ignored', () => {
    assert.equal(AI.noteFractions('rice 150%', comps).suggestions.length, 0);
  });
});

describe('P10 stale-estimate basis', () => {
  it('changing only eaten amounts in the note keeps the analysis note (no new call); changing the food changes it', () => {
    const a = AI.analysisNote('butter chicken, all chicken eaten, 60% sauce');
    assert.equal(AI.analysisNote('butter chicken, all chicken eaten, 40% sauce'), a);
    // Claude P10 review: same foods with other amounts -> same note; dropping a food ("sauce") now changes the food context.
    assert.equal(AI.analysisNote('butter chicken, ate half the chicken, all the sauce eaten'), a);
    assert.notEqual(AI.analysisNote('butter chicken, ate half the chicken'), a);
    assert.notEqual(AI.analysisNote('paneer butter masala, 60% sauce'), a);
  });
});

describe('P10 multi-photo client session', () => {
  const A = jpeg('p10-view-a.jpg'), B = jpeg('p10-view-b.jpg'), C = jpeg('p10-view-c.jpg');
  function capture() {
    const seen = [];
    const p = AI.providers.http({ endpoint: '/api/food-photo', fetchImpl: (url, init) => { seen.push(JSON.parse(init.body)); return Promise.resolve({ status: 200, json: () => Promise.resolve(AI.MOCK_FIXTURES.butterChicken) }); } });
    return { p, seen };
  }
  it('1 photo -> exactly the P9 single-photo body (keys unchanged)', async () => {
    const { p, seen } = capture();
    const r = await AI.createSession(p).analyze({ images: [{ image: A, label: 'SAME_PLATE' }], description: 'x', consent: CONSENT, requestId: 'req-1' });
    assert.equal(r.ok, true);
    // Re-pointed by the P0 sprint photo + note fix: the phone now also asks for item bases (itemBasis: true); nothing else changed.
    assert.deepEqual(Object.keys(seen[0]).sort(), ['consent', 'description', 'imageBase64', 'itemBasis', 'mimeType', 'requestId']);
    assert.equal(seen[0].itemBasis, true);
  });
  it('3 photos -> ONE request with an ordered, labelled image list and one result', async () => {
    const { p, seen } = capture();
    const r = await AI.createSession(p).analyze({ images: [{ image: A, label: 'BEFORE' }, { image: B, label: 'AFTER' }, { image: C, label: 'EXTRA_DISH' }], description: 'butter chicken', consent: CONSENT, requestId: 'req-3' });
    assert.equal(r.ok, true); assert.equal(seen.length, 1);
    assert.deepEqual(Object.keys(seen[0]).sort(), ['consent', 'description', 'images', 'itemBasis', 'requestId']); // re-pointed by the P0 sprint fix (itemBasis)
    assert.deepEqual(seen[0].images.map((i) => i.label), ['BEFORE', 'AFTER', 'EXTRA_DISH']);
    for (const im of seen[0].images) { assert.deepEqual(Object.keys(im).sort(), ['imageBase64', 'label', 'mimeType']); assert.equal(AI.hasMetadata(new Uint8Array(Buffer.from(im.imageBase64, 'base64'))), false); }
    assert.equal(r.result.items.length, 3);
  });
  it('4 photos, an unknown label, an unsanitized or metadata-bearing photo, or an oversize set -> refused, nothing sent', async () => {
    const { p, seen } = capture();
    const s = AI.createSession(p);
    const exifRaw = { sanitized: true, mime: 'image/jpeg', bytes: new Uint8Array(fs.readFileSync(path.join(FIX, 'synthetic-food-exif.jpg'))) };
    const big = { sanitized: true, mime: 'image/jpeg', bytes: new Uint8Array(600000) };
    big.bytes[0] = 0xFF; big.bytes[1] = 0xD8;
    for (const [images, code] of [
      [[A, B, C, A].map((image) => ({ image, label: 'SAME_PLATE' })), 'TOO_MANY_IMAGES'],
      [[{ image: A, label: 'LUNCH WITH BOSS' }, { image: B }], 'BAD_REQUEST'],
      [[{ image: A }, { image: { ...B, sanitized: false } }], 'NOT_SANITIZED'],
      [[{ image: A }, { image: exifRaw }], 'NOT_SANITIZED'],
      [[{ image: A }, { image: big }], 'TOO_LARGE'],
    ]) assert.equal((await s.analyze({ images, consent: CONSENT })).code, code);
    assert.equal(seen.length, 0);
  });
  it('no consent -> nothing sent for the whole set', async () => {
    const { p, seen } = capture();
    const r = await AI.createSession(p).analyze({ images: [{ image: A }, { image: B }], consent: { privacyAck: true } });
    assert.equal(r.code, 'NO_CONSENT'); assert.equal(seen.length, 0);
  });
  it('stable request id: same draft + same ordered photos/labels/note -> same id; any change -> new id', () => {
    const set = [{ image: A, label: 'SAME_PLATE' }, { image: B, label: 'AFTER' }];
    const k = AI.requestKey(set, 'curry', 'n1');
    assert.match(k, /^[A-Za-z0-9_.-]{4,64}$/);
    assert.equal(AI.requestKey(set, 'curry', 'n1'), k);
    assert.notEqual(AI.requestKey([set[1], set[0]], 'curry', 'n1'), k);
    assert.notEqual(AI.requestKey([set[0], { image: B, label: 'BEFORE' }], 'curry', 'n1'), k);
    assert.notEqual(AI.requestKey(set, 'curry 2', 'n1'), k);
    assert.notEqual(AI.requestKey(set, 'curry', 'n2'), k);
  });
  it('a second tap while the first is running is refused on the phone (single flight)', async () => {
    const p = { id: 'slow', mode: 'REAL', calls: 0, analyze() { this.calls++; return new Promise((r) => setTimeout(() => r({ httpStatus: 200, body: AI.MOCK_FIXTURES.plate }), 30)); } };
    const s = AI.createSession(p);
    const [a, b] = await Promise.all([s.analyze({ images: [{ image: A }, { image: B }], consent: CONSENT }), s.analyze({ images: [{ image: A }, { image: B }], consent: CONSENT })]);
    assert.equal(a.ok, true); assert.equal(b.code, 'IN_FLIGHT'); assert.equal(p.calls, 1);
  });
});

describe('P10 safe error categories on the phone', () => {
  it('only allowlisted, pattern-checked diagnostics are kept', () => {
    assert.deepEqual(AI.safeDiag({ category: 'KEY_INVALID', providerStatus: 401, providerCode: 'invalid_api_key', providerRequestId: 'req_ABC123', message: 'secret' }),
      { category: 'KEY_INVALID', providerStatus: 401, providerCode: 'invalid_api_key', providerRequestId: 'req_ABC123' });
    assert.equal(AI.safeDiag({ category: '<b>', providerRequestId: 'req <script>', providerStatus: 'x' }), null);
  });
  it('each category has one plain user action; budget/timeout/network keep their P9 wording', () => {
    for (const k of ['KEY_INVALID', 'MODEL_ACCESS', 'SCHEMA_REJECTED', 'REQUEST_REJECTED', 'PROVIDER_DOWN', 'NETWORK', 'INCOMPLETE', 'REFUSED', 'INVALID_OUTPUT']) {
      const m = AI.friendlyMessage('PROVIDER_ERROR', 'x', { category: k });
      assert.ok(m.length > 20 && /Nothing was saved|manually|Owner/.test(m), k);
    }
    assert.match(AI.friendlyMessage('PROVIDER_ERROR', 'x', { category: 'KEY_INVALID' }), /OPENAI_API_KEY/);
    assert.match(AI.friendlyMessage('PROVIDER_ERROR', 'x', { category: 'PROVIDER_DOWN' }), /had a problem/);
    assert.equal(AI.friendlyMessage('BUDGET_EXHAUSTED', 'x', { category: 'QUOTA' }), AI.friendlyMessage('BUDGET_EXHAUSTED'));
    assert.equal(AI.friendlyMessage('TIMEOUT', 'x', { category: 'TIMEOUT' }), AI.friendlyMessage('TIMEOUT'));
  });
  it('the session passes the server category through, never the server body', async () => {
    const p = AI.providers.http({ endpoint: '/x', fetchImpl: () => Promise.resolve({ status: 502, json: () => Promise.resolve({ detail: { code: 'PROVIDER_ERROR', message: 'm', category: 'MODEL_ACCESS', providerStatus: 404, providerRequestId: 'req_1234567', raw: 'leak' } }) }) });
    const r = await AI.createSession(p).analyze({ images: [{ image: jpeg('p10-view-a.jpg') }], consent: CONSENT });
    assert.equal(r.ok, false); assert.deepEqual(r.diag, { category: 'MODEL_ACCESS', providerStatus: 404, providerRequestId: 'req_1234567' });
  });
});

describe('P10 Quick "Log steps" (same validator and record identity as the daily check-in)', () => {
  const TODAY = HD.todayQatar(NOW), YDAY = AI.addDaysIso(TODAY, -1);
  function save(st, date, raw) {
    const ex = st.records('daily').filter((d) => d.date === date)[0] || null;
    const r = AI.quickStepsUpdate(ex, date, raw, HD.todayQatar(NOW));
    if (!r.ok) return r;
    return Object.assign(st.putRecord('daily', r.rec), { built: r });
  }
  it('Asia/Qatar today is 18 Nov at 12:00 local; yesterday is 17 Nov', () => { assert.equal(TODAY, '2026-11-18'); assert.equal(YDAY, '2026-11-17'); });
  it('yesterday and an older date save as whole-day totals with the check-in record id; other values kept', () => {
    const st = mk(mem());
    assert.equal(st.putRecord('daily', { id: 'daily-' + YDAY, date: YDAY, sleepH: O(7.5), pain: O(2), soreness: O(3), rhr: O(52), steps: MISSING, limp: { state: 'OBSERVED', value: false } }).ok, true);
    const r = save(st, YDAY, '9,450');
    assert.equal(r.ok, true, JSON.stringify(r));
    const got = st.records('daily').filter((d) => d.date === YDAY)[0];
    assert.equal(got.id, 'daily-' + YDAY); assert.deepEqual(got.steps, O(9450));
    assert.deepEqual([got.sleepH, got.pain, got.soreness, got.rhr, got.limp], [O(7.5), O(2), O(3), O(52), { state: 'OBSERVED', value: false }]);
    const old = save(st, '2026-11-02', '12000');
    assert.equal(old.ok, true);
    assert.equal(st.records('daily').length, 2);
  });
  it('repeated edit replaces the same record (no duplicate day); explicit zero stays zero; blank is refused (stays missing)', () => {
    const st = mk(mem());
    assert.equal(save(st, TODAY, '5000').ok, true);
    assert.equal(save(st, TODAY, '7000').ok, true);
    assert.equal(st.records('daily').filter((d) => d.date === TODAY).length, 1);
    assert.deepEqual(st.records('daily')[0].steps, O(7000));
    assert.equal(save(st, TODAY, '0').ok, true);
    assert.deepEqual(st.records('daily')[0].steps, O(0));
    const blank = save(st, TODAY, '   ');
    assert.equal(blank.ok, false); assert.deepEqual(st.records('daily')[0].steps, O(0));
  });
  it('future dates and invalid numbers are refused, by the helper AND by the store validator', () => {
    const st = mk(mem());
    for (const [d, v] of [['2026-11-19', '100'], [TODAY, '-5'], [TODAY, '1.5'], [TODAY, '200001'], [TODAY, 'abc'], ['2026-02-30', '1']]) assert.equal(save(st, d, v).ok, false, d + ' ' + v);
    assert.equal(st.putRecord('daily', { id: 'daily-2026-11-19', date: '2026-11-19', steps: O(100) }).ok, false); // store: future date
    assert.equal(st.records('daily').length, 0);
  });
  it('midnight rollover: "today" is computed from the Asia/Qatar clock at save time', () => {
    const before = new Date('2026-11-18T20:59:59Z'), after = new Date('2026-11-18T21:00:00Z');
    assert.equal(HD.todayQatar(before), '2026-11-18'); assert.equal(HD.todayQatar(after), '2026-11-19');
    assert.equal(AI.quickStepsUpdate(null, '2026-11-19', '10', HD.todayQatar(before)).ok, false);
    assert.equal(AI.quickStepsUpdate(null, '2026-11-19', '10', HD.todayQatar(after)).ok, true);
  });
  it('backup round trip keeps the quick-logged totals and every other value; a fresh store reads the same', () => {
    const st = mk(mem());
    st.putRecord('daily', { id: 'daily-' + YDAY, date: YDAY, sleepH: O(6), steps: MISSING });
    save(st, YDAY, '8800'); save(st, TODAY, '0');
    const text = st.exportJSON();
    const target = mk(mem());
    const r = restore(target, text);
    assert.equal(r.ok, true, JSON.stringify(r));
    const rec = (s, d) => s.records('daily').filter((x) => x.date === d)[0];
    assert.deepEqual(rec(target, YDAY).steps, O(8800)); assert.deepEqual(rec(target, YDAY).sleepH, O(6)); assert.deepEqual(rec(target, TODAY).steps, O(0));
  });
});

describe('P10 data compatibility and rollback', () => {
  const P9_SRC = process.env.P10_P9_SRC || '/workspace/hyrox-p10-inputs/src-unz/hyrox-app-phase9/src';
  const hasP9 = fs.existsSync(path.join(P9_SRC, 'data', 'hyrox-data.js'));
  const sha = (f) => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
  it('Phase 10 changes NO file under src/data/ (compared with the baseline tag in git)', () => {
    let out;
    try { out = execFileSync('git', ['-C', path.resolve(__dirname, '..'), 'diff', '--name-only', 'p10/baseline', '--', 'src/data'], { encoding: 'utf8' }); } catch (e) { return; } // no git in a source-zip extract
    assert.equal(out.trim(), '');
  });
  (hasP9 ? it : it.skip)('a Phase 10 backup (butter-chicken photo meal with per-item amounts + quick-logged steps) restores on the corrected Phase 9 data layer', () => {
    const st = mk(mem());
    const m = butterChickenDraft(); applyNote(m); m.eatenFraction = 1; m.lifecycle = 'CONFIRMED'; m.confirmedAt = NOW.toISOString();
    assert.equal(st.putRecord('meals', m).ok, true);
    const r1 = AI.quickStepsUpdate(null, '2026-11-17', '9000', '2026-11-18'); assert.equal(st.putRecord('daily', r1.rec).ok, true);
    const text = st.exportJSON();
    assert.equal(/imageBase64|data:image|\/9j\//.test(text), false); // no photo bytes in a backup
    const GARMIN_R_PINS = require('./fixtures/garmin-r-data-pins.json'); // RE-POINTED R1-R8 (24 Nov 2026): changed data files are hash-pinned, not exempted; other src/data files stay byte-identical to the Phase 9 tree.
    for (const f of fs.readdirSync(path.join(P9_SRC, 'data'))) {
      const cur = sha(path.resolve(__dirname, '../src/data', f));
      if (GARMIN_R_PINS[f]) assert.equal(cur, GARMIN_R_PINS[f], f + ' (R1-R8 pin)');
      else assert.equal(sha(path.join(P9_SRC, 'data', f)), cur, f);
    }
    const OLD = require(path.join(P9_SRC, 'data', 'hyrox-data.js'));
    const target = OLD.createStore(mem(), { now: () => NOW });
    const p = target.previewImport(text); assert.equal(p.ok, true, JSON.stringify(p.errors || p.message || ''));
    assert.equal(target.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt }).ok, true);
    const got = target.records('meals')[0];
    assert.deepEqual(got.components.map((c) => c.eatenFraction), [1, 0.6, null]);
    assert.equal(HN.mealTotals(got).kcal.value, 430);
    assert.deepEqual(target.records('daily')[0].steps, O(9000));
    assert.equal(typeof target.damagedRecords === 'function' ? target.damagedRecords().length : 0, 0);
  });
  it('an older (Phase 9) backup with a live photo meal still restores and reads the same on Phase 10', () => {
    const text = fs.readFileSync(path.join(FIX, 'p9-live-export.json'), 'utf8');
    const st = mk(mem());
    const r = restore(st, text);
    assert.equal(r.ok, true, JSON.stringify(r));
    const meal = st.records('meals')[0];
    assert.equal(meal.ai.mode, 'REAL'); assert.equal(meal.components[2].kcal.state, 'UNKNOWN');
  });
});
