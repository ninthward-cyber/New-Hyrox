'use strict';
// Meron (QA): risks of blocking two sessions on one day, and cascade non-erasure.
// Does NOT change the rescheduling policy — that is an owner decision.
// Synthetic data only. New file; no edits to src/ or existing tests.

const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('path');
const HD = require(path.resolve(__dirname, '../src/data/hyrox-data.js'));
const HP = require(path.resolve(__dirname, '../src/data/hyrox-plan.js'));

// "As of Wednesday" — used for rescheduleCheck policy characterization.
const TODAY = '2026-11-18';
const SAT = '2026-11-21';
// Clock after Thursday and Saturday so putRecord will accept those dates (the
// store refuses future dates). Qatar is UTC+3; these instants are afternoon local.
const NOW_WED = new Date('2026-11-18T09:00:00Z');
const NOW_FRI = new Date('2026-11-20T09:00:00Z'); // Friday 12:00 Qatar; Thursday is past
const NOW_SAT = new Date('2026-11-21T09:00:00Z'); // Saturday 12:00 Qatar

function mem(init) {
  const m = Object.assign({}, init || {});
  return {
    m,
    getItem(k) { return Object.prototype.hasOwnProperty.call(m, k) ? m[k] : null; },
    setItem(k, v) { m[k] = String(v); },
    removeItem(k) { delete m[k]; },
  };
}
const mk = (now) => HD.createStore(mem(), { now: () => now });

function session(over) {
  return Object.assign({
    date: SAT,
    status: 'COMPLETED',
    modified: false,
    variant: 'NONE',
    blocks: [],
    title: 'Made-up easy walk',
    rpe: 2,
    planSlotId: null,
  }, over);
}

describe('characterization (current policy, not an approval): rescheduleCheck treats any two sessions as a stack', () => {
  it('refuses to reschedule a planned workout onto a day that already has an easy walk logged as a session', () => {
    // Owner rule 4 / policy hold: "never stack" should mean two *demanding* sessions,
    // not gentle walking plus strength. The current check does not distinguish load.
    const easyWalk = session({ id: 'walk-sat', date: SAT, title: 'Easy walking', rpe: 2 });
    const chk = HP.rescheduleCheck('v2.1-W1-TUE', SAT, [easyWalk], [], TODAY);
    assert.equal(chk.ok, false);
    assert.match(chk.reason, /already logged|never stacked|weekend make-up/i); // Round 2: weekend refused first (owner decision 2)
  });

  it('a walks[] record (not a session) on the same date does not trip rescheduleCheck', () => {
    const st = mk(NOW_SAT);
    const walkRes = st.putRecord('walks', { date: SAT, durationMin: 40, steps: 4500, notes: 'Easy walking' });
    assert.equal(walkRes.ok, true, JSON.stringify(walkRes));
    const chk = HP.rescheduleCheck('v2.1-W1-TUE', SAT, st.records('sessions'), [], SAT);
    // Round 2 (owner decision 2): Saturday is refused as a weekend make-up, but never because of the walk log.
    assert.equal(chk.code, 'WEEKEND_NO_GYM_MAKEUP', 'a walk log is not a second *session*: ' + JSON.stringify(chk));
    assert.doesNotMatch(chk.reason, /already logged/);
  });

  it('the data layer still allows logging a walk record and a planned session on the same date', () => {
    const st = mk(NOW_WED);
    assert.equal(st.putRecord('walks', { date: '2026-11-17', durationMin: 30, steps: 4000, notes: 'Easy walking' }).ok, true);
    const workout = session({
      date: '2026-11-17',
      planSlotId: 'v2.1-W1-TUE',
      title: 'Made-up strength session',
      rpe: 7,
      scheduledDate: '2026-11-17',
    });
    const res = st.putRecord('sessions', workout);
    assert.equal(res.ok, true, JSON.stringify(res));
    assert.equal(st.records('walks').length, 1);
    assert.equal(st.records('sessions').length, 1);
    assert.equal(st.records('walks')[0].date, st.records('sessions')[0].date);
  });
});

describe('Decision 2 / F3: easy walking plus a workout must not be treated as two demanding sessions', () => {
  it('rescheduleCheck allows a planned session onto a weekday that only has an easy (low-RPE walk) session', () => {
    // The original assertion used Saturday 2026-11-21. Under Decision 2 that date is
    // refused as WEEKEND_NO_GYM_MAKEUP, so this test now uses cascade-freed Monday
    // 2026-11-23 (W2 Monday, freed by a MISSED_MONDAY event).
    const DATE = '2026-11-23';
    const ev = [{ kind: 'MISSED_MONDAY', week: 2 }];
    const easyWalk = session({
      id: 'walk-mon', date: DATE, title: 'Easy walking', rpe: 2,
      planSlotId: null, blocks: [{ kind: 'walk' }],
    });
    const chk = HP.rescheduleCheck('v2.1-W1-TUE', DATE, [easyWalk], ev, TODAY);
    assert.equal(chk.ok, true, JSON.stringify(chk));
    assert.equal(chk.code, 'OK');
  });
});

describe('cascade must never erase an actual logged session', () => {
  it('adding a Monday cascade event leaves a pre-existing Thursday COMPLETED session in storage and in slotStatus', () => {
    const st = mk(NOW_FRI);
    const thu = session({
      date: '2026-11-19',
      planSlotId: 'v2.1-W1-THU',
      title: 'Made-up aerobic session',
      rpe: 5,
      scheduledDate: '2026-11-19',
      status: 'COMPLETED',
    });
    assert.equal(st.putRecord('sessions', thu).ok, true);
    const before = JSON.parse(JSON.stringify(st.records('sessions')));
    const ev = st.putRecord('planEvents', { date: '2026-11-16', kind: 'MISSED_MONDAY', week: 1 });
    assert.equal(ev.ok, true, JSON.stringify(ev));
    const after = st.records('sessions');
    assert.equal(after.length, before.length);
    assert.equal(after[0].id, before[0].id);
    assert.equal(after[0].status, 'COMPLETED');
    assert.equal(after[0].date, '2026-11-19');
    const status = HP.slotStatus('v2.1-W1-THU', after, st.records('planEvents'));
    assert.equal(status.code, 'COMPLETED');
    assert.equal(status.session.id, after[0].id);
    assert.equal(status.omission, 'MISSED_MONDAY_CASCADE');
    assert.equal(status.conflict, 'ACTUAL_SESSION_ON_SOURCE_OMITTED_SLOT');
    // The planned slot definition itself is not rewritten.
    assert.equal(HP.slotById('v2.1-W1-THU').date, '2026-11-19');
  });

  it('effectiveWeek omits the Thursday prescription but does not drop the stored session record', () => {
    const st = mk(NOW_FRI);
    const put = st.putRecord('sessions', session({
      date: '2026-11-19', planSlotId: 'v2.1-W1-THU', title: 'Made-up aerobic', scheduledDate: '2026-11-19',
    }));
    assert.equal(put.ok, true, JSON.stringify(put));
    st.putRecord('planEvents', { date: '2026-11-16', kind: 'MISSED_MONDAY', week: 1 });
    const week = HP.effectiveWeek(1, st.records('planEvents'));
    const thu = week.days.filter((d) => d.date === '2026-11-19')[0];
    assert.ok(thu.omitted.some((o) => o.reason === 'MISSED_MONDAY_CASCADE'));
    assert.equal(st.records('sessions').length, 1);
    assert.equal(st.records('sessions')[0].status, 'COMPLETED');
  });
});
