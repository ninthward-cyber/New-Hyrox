'use strict';
// P4 overnight QA (Dawit, owner t59u). FAILING-FIRST regression tests for two reproduced
// prototype-key defects in src/data/hyrox-data.js. Synthetic data only.
//   P4-D1: a stored nutrition entry dated "__proto__" made dailyNutritionTotals() write to
//          Object.prototype; afterwards every session block inherited `count: NaN`, so every
//          session turned DAMAGED and vanished from records() and from the normal backup.
//   P4-D2: a stored top-level "__proto__" field was assigned as the prototype of the working
//          copy, so its contents showed up as inherited collections and the field was silently
//          dropped by the next unrelated write (the store promises to keep unknown top-level fields).
const { describe, it, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const { HD, NOW, KEY, ts } = require('./p3-helpers.js');

// Map-backed storage: no Object.assign, so "__proto__" keys are plain data here.
function mapStorage(init) {
  const m = new Map(Object.entries(init || {}));
  return { m, writes: 0, getItem(k) { return m.has(k) ? m.get(k) : null; }, setItem(k, v) { this.writes++; m.set(k, String(v)); }, removeItem(k) { this.writes++; m.delete(k); } };
}
const mk = (s) => HD.createStore(s, { now: () => NOW });
const SESSION = { id: 's1', date: '2026-11-10', createdAt: ts, status: 'COMPLETED', modified: false, variant: 'ORIGINAL_60', blocks: [{ kind: 'run', durationSec: 600 }] };
const POLLUTABLE = ['calories', 'proteinG', 'count', 'date'];
function cleanPrototype() { POLLUTABLE.forEach((k) => { delete Object.prototype[k]; delete Object[k]; }); }

describe('P4-D1: dailyNutritionTotals never writes to a prototype', () => {
  afterEach(cleanPrototype);
  for (const badDate of ['__proto__', 'constructor', 'hasOwnProperty']) {
    it('stored classic nutrition dated "' + badDate + '" does not pollute Object.prototype or hide sessions', () => {
      const raw = JSON.stringify({ version: 2, weight: [], workouts: [], nutrition: [
        { id: 'n1', createdAt: ts, date: badDate, label: 'x', calories: 500, proteinG: 30 },
        { id: 'n2', createdAt: ts, date: '2026-11-10', label: 'y', calories: 200, proteinG: 10 }], sessions: [SESSION] });
      const s = mapStorage({ [KEY]: raw });
      const st = mk(s);
      assert.equal(st.records('sessions').length, 1);
      const totals = st.dailyNutritionTotals();
      POLLUTABLE.forEach((k) => assert.equal(Object.prototype.hasOwnProperty.call(Object.prototype, k), false, 'Object.prototype.' + k + ' was written'));
      assert.equal(({}).count, undefined);
      // The odd-dated entry is still totalled under its own (stored) date; nothing is lost or merged.
      assert.deepEqual(totals.map((t) => [t.date, t.calories, t.count]).sort(), [['2026-11-10', 200, 1], [badDate, 500, 1]].sort());
      assert.ok(totals.every((t) => Object.getPrototypeOf(t) === Object.prototype), 'totals stay plain objects');
      // Sessions stay visible and in the normal backup; nothing was written.
      assert.equal(st.records('sessions').length, 1);
      assert.equal(JSON.parse(st.exportJSON()).sessions.length, 1);
      assert.equal(st.exportSummary().omittedExt, undefined);
      assert.equal(s.writes, 0);
      assert.equal(s.m.get(KEY), raw);
    });
  }
});

describe('P4-D2: a stored top-level "__proto__" field is ordinary unknown data', () => {
  const raw = '{"version":2,"weight":[],"workouts":[],"nutrition":[],"__proto__":{"meals":[{"id":"m1"}],"sessions":[]},"keepme":1}';
  it('does not appear as inherited Phase 3 collections', () => {
    const st = mk(mapStorage({ [KEY]: raw }));
    assert.deepEqual(st.extCounts(), {});
    assert.deepEqual(st.records('meals'), []);
    assert.equal(st.exportSummary().omittedExt, undefined);
    assert.equal(JSON.parse(st.exportJSON()).meals, undefined);
    assert.equal(st.status().state, 'ok');
  });
  it('survives an unrelated write byte-for-byte (like every other unknown top-level field)', () => {
    const s = mapStorage({ [KEY]: raw });
    const st = mk(s);
    assert.equal(st.addWeight({ date: '2026-11-10', kg: 80 }).ok, true);
    const after = s.m.get(KEY);
    assert.ok(after.includes('"__proto__":{"meals":[{"id":"m1"}],"sessions":[]}'), 'the "__proto__" field was dropped: ' + after);
    assert.ok(after.includes('"keepme":1'));
    const parsed = JSON.parse(after);
    assert.equal(Object.prototype.hasOwnProperty.call(parsed, '__proto__'), true);
    assert.equal(parsed.weight.length, 1);
    // Still not mistaken for a collection after the write, and the store reads back ok.
    assert.deepEqual(st.extCounts(), {});
    assert.equal(st.status().state, 'ok');
  });
  it('a restore still ignores a top-level "__proto__" in a backup file (unchanged behaviour)', () => {
    const s = mapStorage();
    const st = mk(s);
    const text = '{"app":"hyrox-app","version":2,"exportedAt":"' + ts + '","weight":[],"workouts":[],"nutrition":[],"__proto__":{"meals":[{"id":"m1"}]}}';
    const p = st.previewImport(text);
    assert.equal(p.ok, true);
    assert.equal(p.preview.extCounts, undefined);
    const r = st.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt });
    assert.equal(r.ok, true);
    assert.equal(s.m.get(KEY).includes('__proto__'), false);
  });
});
