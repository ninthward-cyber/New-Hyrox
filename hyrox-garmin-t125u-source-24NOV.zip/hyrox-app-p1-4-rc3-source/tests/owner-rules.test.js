'use strict';
// The five owner decisions of 2026-11-18 (hyroxowner.md), at the data/logic layer.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const HD = require(path.resolve(__dirname, '../src/data/hyrox-data.js'));
const HP = require(path.resolve(__dirname, '../src/data/hyrox-plan.js'));
const HN = require(path.resolve(__dirname, '../src/data/hyrox-nutrition.js'));
const HW = require(path.resolve(__dirname, '../src/data/hyrox-wellness.js'));
const AI = require(path.resolve(__dirname, '../src/ai/photo-ai.js'));

const NOW = new Date('2026-11-18T09:00:00Z');
const TODAY = '2026-11-18';
function mem() {
  const m = {};
  return { m, getItem(k) { return Object.prototype.hasOwnProperty.call(m, k) ? m[k] : null; }, setItem(k, v) { m[k] = String(v); }, removeItem(k) { delete m[k]; } };
}
const mk = (s) => HD.createStore(s || mem(), { now: () => NOW });
const U = { value: null, state: 'UNKNOWN' };
const K = (v) => ({ value: v, state: 'KNOWN' });
const E = (v) => ({ value: v, state: 'ESTIMATED' });
const O = (v) => ({ state: 'OBSERVED', value: v });
const MISSING = { state: 'MISSING', value: null };
const day = (date, extra) => Object.assign({ id: 'daily-' + date, date }, extra);

// ---------------------------------------------------------------- rule 1
describe('owner rule 1: resting-HR baseline is 76 bpm and configurable', () => {
  it('defaults to 76 bpm as an owner default, without writing anything', () => {
    const s = mem(); const set = mk(s).settings();
    assert.equal(set.rhrBaselineBpm, 76); assert.equal(set.rhrBaselineSource, 'OWNER_DEFAULT'); assert.equal(set.stored, false);
    assert.deepEqual(Object.keys(s.m), []);
  });
  it('can be changed, is validated, survives reload and round-trips through a backup', () => {
    const s = mem(); const st = mk(s);
    assert.equal(st.putRecord('ownerSettings', { id: HD.SETTINGS_ID, date: TODAY, rhrBaselineBpm: 500 }).ok, false);
    assert.equal(st.putRecord('ownerSettings', { id: 'other', date: TODAY, rhrBaselineBpm: 70 }).ok, false);
    assert.equal(st.putRecord('ownerSettings', { id: HD.SETTINGS_ID, date: TODAY, rhrBaselineBpm: 72 }).ok, true);
    const set = mk(s).settings();
    assert.equal(set.rhrBaselineBpm, 72); assert.equal(set.rhrBaselineSource, 'OWNER_SET');
    assert.equal(st.putRecord('ownerSettings', { id: HD.SETTINGS_ID, date: TODAY, rhrBaselineBpm: 74 }).ok, true);
    assert.equal(st.records('ownerSettings').length, 1, 'one settings record, replaced in place');
    const text = st.exportJSON(); const s2 = mem(); const st2 = mk(s2);
    const p = st2.previewImport(text);
    assert.equal(st2.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt }).ok, true);
    assert.equal(st2.settings().rhrBaselineBpm, 74);
  });
  it('a reading is flagged against the configured baseline with no reading history at all', () => {
    const set = { rhrBaselineBpm: 76, rhrBaselineSource: 'OWNER_DEFAULT' };
    const r = HW.readiness(TODAY, [day(TODAY, { rhr: O(83), sleepH: O(8), soreness: O(1) })], set);
    assert.equal(r.flags.length, 1); assert.match(r.flags[0], /configured baseline \(76 bpm\)/);
    assert.equal(r.missing.indexOf('resting HR'), -1);
    const below = HW.readiness(TODAY, [day(TODAY, { rhr: O(82), sleepH: O(8), soreness: O(1) })], set);
    assert.deepEqual(below.flags, []);
  });
  it('changing the baseline changes the result (configurable, not hard-wired)', () => {
    const d = [day(TODAY, { rhr: O(80), sleepH: O(8), soreness: O(1) })];
    assert.deepEqual(HW.readiness(TODAY, d, { rhrBaselineBpm: 76 }).flags, []);
    assert.equal(HW.readiness(TODAY, d, { rhrBaselineBpm: 70, rhrBaselineSource: 'OWNER_SET' }).flags.length, 1);
  });
  it('configured and observed baselines are reported separately and never merged', () => {
    const hist = ['2026-11-13', '2026-11-14', '2026-11-15', '2026-11-16', '2026-11-17'].map((x) => day(x, { rhr: O(60) }));
    const a = HW.rhrAssessment(70, TODAY, hist, { rhrBaselineBpm: 76, rhrBaselineSource: 'OWNER_SET' });
    assert.deepEqual(a.configured, { value: 76, source: 'OWNER_SET' });
    assert.deepEqual(a.observed, { valid: true, n: 5, value: 60 });
    // 70 is below 76+7 but 10 above the observed mean: the source weekly-baseline flag still fires.
    assert.match(a.flag, /observed 7-day mean \(60 bpm, n=5\)/); assert.doesNotMatch(a.flag, /configured/);
  });
  it('an observed baseline with too few readings is "not available", never estimated', () => {
    const a = HW.rhrAssessment(80, TODAY, [day('2026-11-17', { rhr: O(60) })], { rhrBaselineBpm: 76 });
    assert.deepEqual(a.observed, { valid: false, n: 1, value: null });
    assert.equal(a.flag, null);
  });
  it('a missing reading is missing - not zero and not "fine"', () => {
    const r = HW.readiness(TODAY, [day(TODAY, { rhr: MISSING, sleepH: O(8), soreness: O(1) })], { rhrBaselineBpm: 76 });
    assert.ok(r.missing.includes('resting HR')); assert.deepEqual(r.flags, []);
    assert.match(r.guidance, /cannot be confirmed/);
    assert.equal(r.rhr.reading, null);
  });
  it('the RHR flag counts once toward the source two-flag rule, and the safety text is kept', () => {
    const hist = ['2026-11-14', '2026-11-15', '2026-11-16', '2026-11-17'].map((x) => day(x, { rhr: O(60) }));
    const r = HW.readiness(TODAY, hist.concat([day(TODAY, { rhr: O(90), sleepH: O(8), soreness: O(1) })]), { rhrBaselineBpm: 76 });
    assert.equal(r.flags.length, 1); assert.match(r.flags[0], /configured.*and.*observed/);
    assert.match(r.guidance, /one flag/); assert.match(r.safety, /not a diagnosis/);
  });
});

// ---------------------------------------------------------------- rule 2
describe('owner rule 2: eaten fraction', () => {
  const comps = () => [
    { name: 'Chicken', role: 'MAIN', eatenFraction: null, kcal: E(220), proteinG: E(40), carbsG: E(0), fatG: E(5) },
    { name: 'Rice', role: 'SIDE', eatenFraction: null, kcal: E(240), proteinG: E(5), carbsG: E(53), fatG: E(1) }];
  const photo = (extra) => Object.assign({ date: TODAY, label: 'Plate', source: 'PHOTO_AI', lifecycle: 'NEEDS_REVIEW', components: comps(),
    ai: { mode: 'MOCK', provider: 'mock-fixture', model: 'm' } }, extra);

  it('the meal-level fraction scales calories, protein, carbs and fat alike, for every preset', () => {
    assert.deepEqual(HN.EATEN_PRESETS, [0.25, 0.5, 0.75, 1]);
    HN.EATEN_PRESETS.forEach((f) => {
      const t = HN.mealTotals(photo({ eatenFraction: f }));
      assert.equal(t.kcal.value, Math.round(460 * f * 10) / 10);
      assert.equal(t.proteinG.value, Math.round(45 * f * 10) / 10);
      assert.equal(t.carbsG.value, Math.round(53 * f * 10) / 10);
      assert.equal(t.fatG.value, Math.round(6 * f * 10) / 10);
    });
  });
  it('custom percentages work (e.g. 33% and 0%)', () => {
    assert.equal(HN.mealTotals(photo({ eatenFraction: 0.33 })).kcal.value, 151.8);
    assert.equal(HN.mealTotals(photo({ eatenFraction: 0 })).kcal.value, 0);
  });
  it('an item-level amount overrides the meal-level amount for that item only', () => {
    const m = photo({ eatenFraction: 0.5 });
    m.components[1].eatenFraction = 1; // all the rice, half the chicken
    const t = HN.mealTotals(m);
    assert.equal(t.kcal.value, 110 + 240); assert.equal(t.proteinG.value, 20 + 5);
  });
  it('a photographed meal with no stated amount has UNKNOWN totals - never the whole plate', () => {
    const m = photo();
    assert.equal(HN.fractionStated(m), false);
    const t = HN.mealTotals(m);
    assert.equal(t.kcal.value, null); assert.equal(t.kcal.state, 'UNKNOWN');
  });
  it('the AI/mock result never supplies the eaten amount, even if the model returns one', () => {
    const out = AI.resultToComponents({ items: [{ name: 'Rice', role: 'SIDE', eatenFraction: 1, kcal: 240, proteinG: 5, carbsG: 53, fatG: 1 }] });
    assert.equal(out[0].eatenFraction, null);
    assert.equal(out[0].kcal.state, 'ESTIMATED', 'AI values arrive as editable estimates');
  });
  it('a photographed meal cannot be CONFIRMED until the amount eaten is stated', () => {
    const st = mk();
    const confirmed = { lifecycle: 'CONFIRMED', confirmedAt: NOW.toISOString() };
    const r = st.putRecord('meals', photo(confirmed));
    assert.equal(r.ok, false); assert.match(r.errors.eatenFraction, /how much of the photographed meal/);
    assert.equal(st.records('meals').length, 0);
    assert.equal(st.putRecord('meals', photo(Object.assign({ eatenFraction: 0.75 }, confirmed))).ok, true);
    const perItem = photo(confirmed); perItem.components.forEach((c) => { c.eatenFraction = 0.5; });
    assert.equal(st.putRecord('meals', perItem).ok, true);
    const oneMissing = photo(confirmed); oneMissing.components[0].eatenFraction = 0.5;
    assert.equal(st.putRecord('meals', oneMissing).ok, false);
  });
  it('it can still be saved for later review without an amount, and then counts for nothing', () => {
    const st = mk();
    assert.equal(st.putRecord('meals', photo()).ok, true);
    assert.equal(st.putRecord('meals', photo({ lifecycle: 'CONSUMED_INTENT', label: 'B' })).ok, true);
    const ds = HN.dayState(TODAY, st.records('meals'), null);
    assert.equal(ds.confirmedCount, 0); assert.equal(ds.subtotal.kcal.value, null); assert.equal(ds.dayKcal, null);
  });
  it('nothing counts toward the day until the meal is explicitly confirmed', () => {
    ['DRAFT', 'NEEDS_REVIEW', 'CONSUMED_INTENT'].forEach((lc) => {
      const ds = HN.dayState(TODAY, [photo({ id: 'a', lifecycle: lc, eatenFraction: 1 })], null);
      assert.equal(ds.subtotal.kcal.value, null, lc);
    });
    const ok = HN.dayState(TODAY, [photo({ id: 'a', lifecycle: 'CONFIRMED', confirmedAt: NOW.toISOString(), eatenFraction: 0.5 })], null);
    assert.equal(ok.subtotal.kcal.value, 230);
  });
  it('fractions are validated (0-1) at meal and item level', () => {
    const st = mk();
    assert.equal(st.putRecord('meals', photo({ eatenFraction: 1.5 })).ok, false);
    const bad = photo({ eatenFraction: 0.5 }); bad.components[0].eatenFraction = -0.1;
    assert.equal(st.putRecord('meals', bad).ok, false);
  });
  it('typed meals and records made before this change keep their totals', () => {
    const manual = { source: 'MANUAL', components: [{ name: 'Oats', kcal: K(350), proteinG: K(12), carbsG: U, fatG: U }] };
    assert.equal(HN.mealTotals(manual).kcal.value, 350);
    const oldPhoto = { source: 'PHOTO_AI', components: [{ name: 'Rice', eatenFraction: 0.5, kcal: E(400), proteinG: K(10), carbsG: K(80), fatG: K(2) }] };
    assert.equal(HN.mealTotals(oldPhoto).kcal.value, 200);
  });
  it('changing the amount eaten invalidates an earlier day declaration', () => {
    const m = photo({ id: 'a', lifecycle: 'CONFIRMED', confirmedAt: NOW.toISOString(), eatenFraction: 1 });
    const att = { attestation: 'COMPLETE', basis: HN.dayState(TODAY, [m], null).basis };
    assert.equal(HN.dayState(TODAY, [m], att).code, 'D5');
    const half = Object.assign({}, m, { eatenFraction: 0.5 });
    assert.equal(HN.dayState(TODAY, [half], att).staleAttestation, true);
  });
});

// ---------------------------------------------------------------- rule 3
describe('owner rule 3: water-only day', () => {
  const water = { id: 'w', date: TODAY, lifecycle: 'CONFIRMED', source: 'MANUAL', components: [{ name: 'Water', role: 'DRINK', kcal: K(0), proteinG: K(0), carbsG: K(0), fatG: K(0) }] };
  const basisOf = (meals) => HN.dayState(TODAY, meals, null).basis;

  it('a day with no meals is unknown, not zero, and the question is open', () => {
    const ds = HN.dayState(TODAY, [], null);
    assert.equal(ds.code, 'D1'); assert.equal(ds.dayKcal, null); assert.equal(ds.subtotal.kcal.value, null);
    assert.equal(ds.waterOnly, true); assert.equal(ds.fastQuestionOpen, true); assert.equal(ds.fastDay, false);
  });
  it('only an explicit fast confirmation records 0 kcal', () => {
    const att = { attestation: 'COMPLETE', fast: 'CONFIRMED_FULL_DAY_FAST', basis: basisOf([]) };
    const ds = HN.dayState(TODAY, [], att);
    assert.equal(ds.code, 'DF'); assert.equal(ds.dayKcal, 0); assert.equal(ds.fastDay, true);
    assert.equal(ds.fullDay, false, 'a fast is not an eating day'); assert.equal(ds.fastQuestionOpen, false);
  });
  it('"food not logged" keeps calories unknown and closes the question', () => {
    const ds = HN.dayState(TODAY, [], { attestation: 'INCOMPLETE', fast: 'NOT_LOGGED', basis: basisOf([]) });
    assert.equal(ds.code, 'D3'); assert.equal(ds.dayKcal, null); assert.equal(ds.fastQuestionOpen, false); assert.equal(ds.fastDay, false);
  });
  it('declaring the day complete WITHOUT the fast answer is not a fast and not zero (old D4 behaviour corrected)', () => {
    [[], [water]].forEach((meals) => {
      const ds = HN.dayState(TODAY, meals, { attestation: 'COMPLETE', basis: basisOf(meals) });
      assert.equal(ds.code, 'D4'); assert.equal(ds.dayKcal, null); assert.equal(ds.fastDay, false); assert.equal(ds.fastQuestionOpen, true);
    });
  });
  it('logged water (0 kcal) alone never makes a fast; confirming does', () => {
    assert.equal(HN.dayState(TODAY, [water], null).dayKcal, null);
    const ds = HN.dayState(TODAY, [water], { attestation: 'COMPLETE', fast: 'CONFIRMED_FULL_DAY_FAST', basis: basisOf([water]) });
    assert.equal(ds.code, 'DF'); assert.equal(ds.dayKcal, 0);
  });
  it('a fast cannot be claimed on a day with food, unknown calories, or unconfirmed meals', () => {
    const food = { id: 'f', date: TODAY, lifecycle: 'CONFIRMED', source: 'MANUAL', components: [{ name: 'Oats', kcal: K(350), proteinG: K(12), carbsG: U, fatG: U }] };
    const unknown = { id: 'u', date: TODAY, lifecycle: 'CONFIRMED', source: 'MANUAL', components: [{ name: 'Sauce', kcal: U, proteinG: U, carbsG: U, fatG: U }] };
    const draft = { id: 'd', date: TODAY, lifecycle: 'DRAFT', source: 'MANUAL', components: [{ name: 'Oats', kcal: K(350), proteinG: U, carbsG: U, fatG: U }] };
    const pending = Object.assign({}, draft, { id: 'p', lifecycle: 'CONSUMED_INTENT' });
    [[food], [unknown], [draft], [pending]].forEach((meals) => {
      const base = HN.dayState(TODAY, meals, null);
      assert.equal(base.waterOnly, false); assert.equal(HN.canConfirmFast(base).ok, false);
      const forced = HN.dayState(TODAY, meals, { attestation: 'COMPLETE', fast: 'CONFIRMED_FULL_DAY_FAST', basis: base.basis });
      assert.notEqual(forced.code, 'DF'); assert.notEqual(forced.dayKcal, 0);
    });
    assert.equal(HN.canConfirmFast(HN.dayState(TODAY, [], null)).ok, true);
  });
  it('adding a meal after confirming a fast withdraws the fast (stale) instead of keeping 0 kcal', () => {
    const att = { attestation: 'COMPLETE', fast: 'CONFIRMED_FULL_DAY_FAST', basis: basisOf([]) };
    const food = { id: 'f', date: TODAY, lifecycle: 'CONFIRMED', source: 'MANUAL', updatedAt: NOW.toISOString(), components: [{ name: 'Oats', kcal: K(350), proteinG: K(12), carbsG: U, fatG: U }] };
    const ds = HN.dayState(TODAY, [food], att);
    assert.equal(ds.staleAttestation, true); assert.notEqual(ds.code, 'DF'); assert.equal(ds.fastDay, false); assert.equal(ds.dayKcal, null);
  });
  it('fasting days are a separate cohort; unknown days are excluded from averages, never averaged as 0', () => {
    const eat = (id, kcal, protein) => ({ id, date: id, lifecycle: 'CONFIRMED', source: 'MANUAL', components: [{ name: 'x', kcal: K(kcal), proteinG: K(protein), carbsG: K(1), fatG: K(1) }] });
    const mA = eat('2026-11-14', 2000, 150), mB = eat('2026-11-15', 2400, 170);
    const states = [
      HN.dayState('2026-11-14', [mA], { attestation: 'COMPLETE', basis: HN.dayState('2026-11-14', [mA], null).basis }),
      HN.dayState('2026-11-15', [mB], { attestation: 'COMPLETE', basis: HN.dayState('2026-11-15', [mB], null).basis }),
      HN.dayState('2026-11-16', [], { attestation: 'COMPLETE', fast: 'CONFIRMED_FULL_DAY_FAST', basis: HN.dayState('2026-11-16', [], null).basis }),
      HN.dayState('2026-11-17', [], null), // nothing logged, unanswered
      HN.dayState(TODAY, [], { attestation: 'INCOMPLETE', fast: 'NOT_LOGGED', basis: HN.dayState(TODAY, [], null).basis }),
    ];
    const avg = HN.dayAverages(states);
    assert.deepEqual(avg.eatingDays, { n: 2, kcalMean: 2200, proteinMean: 160 });
    assert.deepEqual(avg.fastingDays, { n: 1, dates: ['2026-11-16'] });
    assert.equal(avg.excluded.n, 2);
    assert.equal(HN.dayAverages([]).eatingDays.kcalMean, null);
  });
  it('the fast answer is validated and stored with the day declaration', () => {
    const st = mk();
    assert.equal(st.putRecord('dayStates', { date: TODAY, attestation: 'COMPLETE', basis: '0:x', fast: 'MAYBE' }).ok, false);
    assert.equal(st.putRecord('dayStates', { date: TODAY, attestation: 'INCOMPLETE', basis: '0:x', fast: 'CONFIRMED_FULL_DAY_FAST' }).ok, false);
    assert.equal(st.putRecord('dayStates', { date: TODAY, attestation: 'COMPLETE', basis: '0:x', fast: 'NOT_LOGGED' }).ok, false);
    assert.equal(st.putRecord('dayStates', { date: TODAY, attestation: 'COMPLETE', basis: '0:x', fast: 'CONFIRMED_FULL_DAY_FAST' }).ok, true);
    assert.equal(st.putRecord('dayStates', { date: '2026-11-17', attestation: 'INCOMPLETE', basis: '0:x' }).ok, true, 'older records without the field stay valid');
  });
});

// ---------------------------------------------------------------- rule 4
describe('owner rule 4: explicitly skipped sessions', () => {
  const skip = (slotId, extra) => Object.assign({ id: 'sk-' + slotId, planSlotId: slotId, date: TODAY, status: 'SKIPPED', skipConfirmed: true, modified: false,
    variant: 'NONE', blocks: [], createdAt: NOW.toISOString(), updatedAt: NOW.toISOString() }, extra || {});

  it('an unlogged workout is never treated as skipped', () => {
    assert.equal(HP.slotStatus('v2.1-W1-MON', [], []).code, 'NOT_LOGGED');
    assert.equal(HP.summary([], []).SKIPPED, 0);
  });
  it('a skip still needs explicit confirmation, and the decision must be a known choice', () => {
    const st = mk();
    const base = { date: TODAY, status: 'SKIPPED', modified: false, variant: 'NONE', blocks: [], planSlotId: 'v2.1-W1-TUE' };
    assert.equal(st.putRecord('sessions', base).ok, false);
    assert.equal(st.putRecord('sessions', Object.assign({ skipConfirmed: true, skipDecision: 'WHATEVER' }, base)).ok, false);
    assert.equal(st.putRecord('sessions', Object.assign({ skipConfirmed: true, skipDecision: 'RESCHEDULE' }, base)).ok, false, 'reschedule needs a date');
    assert.equal(st.putRecord('sessions', Object.assign({ skipConfirmed: true, skipDecision: 'SKIP_PERMANENT', rescheduledTo: '2026-11-21' }, base)).ok, false);
    assert.equal(st.putRecord('sessions', Object.assign({ skipConfirmed: true, skipDecision: 'RESCHEDULE', rescheduledTo: '2026-11-21' }, base)).ok, true);
    assert.equal(st.putRecord('sessions', { date: TODAY, status: 'COMPLETED', modified: false, variant: 'NONE', blocks: [], skipDecision: 'SKIP_PERMANENT' }).ok, false);
    assert.equal(st.putRecord('sessions', Object.assign({ skipConfirmed: true }, base, { planSlotId: 'v2.1-W1-WED' })).ok, true, 'older skip records without a decision stay valid');
  });
  it('the three options are always offered; Monday/Wednesday recommend the approved cascade', () => {
    const a = HP.skipAdvice('v2.1-W1-MON', [], [], TODAY);
    assert.deepEqual(Object.keys(a.options), ['RESCHEDULE', 'SKIP_PERMANENT', 'ADJUST_WEEK']);
    assert.equal(a.recommended, 'ADJUST_WEEK'); assert.equal(a.options.ADJUST_WEEK.kind, 'MISSED_MONDAY');
    assert.match(a.options.ADJUST_WEEK.note, /Thursday aerobic is omitted by source rule/);
    const w = HP.skipAdvice('v2.1-W1-WED', [], [], TODAY);
    assert.equal(w.recommended, 'ADJUST_WEEK'); assert.equal(w.options.ADJUST_WEEK.kind, 'MISSED_WEDNESDAY');
  });
  it('the cascade itself is unchanged: source-defined moves and the Thursday omission', () => {
    const mon = HP.effectiveWeek(1, [{ kind: 'MISSED_MONDAY', week: 1 }]);
    assert.deepEqual(mon.days.map((d) => d.show.map((x) => x.slot.day)), [[], ['MON'], ['WED'], ['TUE'], ['FRI']]);
    assert.equal(mon.days[3].omitted[0].reason, 'MISSED_MONDAY_CASCADE');
    const wed = HP.effectiveWeek(1, [{ kind: 'MISSED_WEDNESDAY', week: 1 }]);
    assert.deepEqual(wed.days.map((d) => d.show.map((x) => x.slot.day)), [['MON'], ['TUE'], [], ['WED'], ['FRI']]);
    assert.equal(wed.days[3].omitted[0].reason, 'MISSED_WEDNESDAY_CASCADE');
  });
  it('both Monday and Wednesday missed stays unresolved: no automatic adjustment is offered', () => {
    const a = HP.skipAdvice('v2.1-W1-WED', [], [{ kind: 'MISSED_MONDAY', week: 1 }], TODAY);
    assert.equal(a.options.ADJUST_WEEK.available, false); assert.match(a.options.ADJUST_WEEK.note, /no rule for both/);
    assert.equal(a.recommended, 'SKIP_PERMANENT');
  });
  it('a future session cannot be marked missed (no retroactive or anticipatory auto-skips)', () => {
    const a = HP.skipAdvice('v2.1-W2-MON', [], [], TODAY);
    assert.equal(a.options.ADJUST_WEEK.available, false); assert.match(a.options.ADJUST_WEEK.note, /future/);
  });
  it('Tuesday/Thursday/Friday have no source adjustment; the safe recommendation is to leave it skipped', () => {
    ['TUE', 'THU', 'FRI'].forEach((d) => {
      const a = HP.skipAdvice('v2.1-W1-' + d, [], [], TODAY);
      assert.equal(a.options.ADJUST_WEEK.available, false); assert.equal(a.recommended, 'SKIP_PERMANENT');
    });
  });
  it('a missed Friday has no weekend make-up (source rule) and no other free day', () => {
    assert.equal(HP.rescheduleCheck('v2.1-W1-FRI', '2026-11-21', [], [], TODAY).ok, false);
    assert.match(HP.rescheduleCheck('v2.1-W1-FRI', '2026-11-21', [], [], TODAY).reason, /no weekend make-up/);
    assert.equal(HP.skipAdvice('v2.1-W1-FRI', [], [], '2026-11-20').options.RESCHEDULE.available, false);
  });
  it('rescheduling never stacks two sessions on one day', () => {
    const chk = (date, sessions, events) => HP.rescheduleCheck('v2.1-W1-TUE', date, sessions || [], events || [], TODAY);
    assert.match(chk('2026-11-19').reason, /never stacked/);                 // Thursday already has aerobic
    // Round 2 (owner decision 2, t47u): weekends are no longer make-up days for any weekday slot.
    assert.equal(chk('2026-11-21').ok, false); assert.equal(chk('2026-11-21').code, 'WEEKEND_NO_GYM_MAKEUP');
    const mon2 = [{ kind: 'MISSED_MONDAY', week: 2 }];                       // Mon 16 Nov is free under the cascade
    assert.equal(chk('2026-11-23', [], mon2).ok, true);
    assert.match(chk('2026-11-23', [], mon2).caution, /your decision/);
    const other = skip('v2.1-W1-WED', { skipDecision: 'RESCHEDULE', rescheduledTo: '2026-11-23' });
    assert.match(chk('2026-11-23', [other], mon2).reason, /already rescheduled/);
    const logged = { id: 'x', date: '2026-11-23', status: 'COMPLETED', planSlotId: null, blocks: [] };
    assert.match(chk('2026-11-23', [logged], mon2).reason, /already logged/);
    assert.match(chk('2026-11-17').reason, /past|original/);
    assert.match(chk('2026-12-14').reason, /outside block/);
    assert.equal(HP.rescheduleDates('v2.1-W1-TUE', [], [], TODAY).some((d) => ['SAT', 'SUN'].includes(['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'][new Date(d + 'T00:00:00Z').getUTCDay()])), false);
  });
  it('the reschedule is recorded separately; the original planned slot is untouched', () => {
    const s = skip('v2.1-W1-TUE', { skipDecision: 'RESCHEDULE', rescheduledTo: '2026-11-21', scheduledDate: '2026-11-17' });
    const st = HP.slotStatus('v2.1-W1-TUE', [s], []);
    assert.equal(st.code, 'SKIPPED'); assert.equal(st.skipDecision, 'RESCHEDULE'); assert.equal(st.rescheduledTo, '2026-11-21');
    assert.equal(HP.slotById('v2.1-W1-TUE').date, '2026-11-17');
    assert.deepEqual(HP.rescheduledOn('2026-11-21', [s]).map((x) => x.id), ['v2.1-W1-TUE']);
    assert.equal(HP.summary([s], []).rescheduledPending, 1); assert.equal(HP.summary([s], []).denominator, 20);
  });
  it('once the rescheduled session is actually done, the slot shows the work and the skip record remains', () => {
    const s = skip('v2.1-W1-TUE', { skipDecision: 'RESCHEDULE', rescheduledTo: '2026-11-21' });
    const done = { id: 'done', planSlotId: 'v2.1-W1-TUE', date: '2026-11-21', status: 'COMPLETED', modified: false, variant: 'ORIGINAL_60', blocks: [], createdAt: '2026-11-21T08:00:00.000Z', updatedAt: '2026-11-21T08:00:00.000Z' };
    // Round 2 (owner decision 2, t47u): weekend work is kept as actual work but does not relabel the weekday slot.
    const st = HP.slotStatus('v2.1-W1-TUE', [s, done], []);
    assert.equal(st.code, 'SKIPPED'); assert.equal(st.rescheduleNotSourceApproved, true);
    assert.deepEqual(st.weekendWork.map((x) => x.id), ['done']);
    assert.deepEqual(HP.rescheduledOn('2026-11-21', [s, done]), []);
    assert.equal(HP.summary([s, done], []).SKIPPED, 1); assert.equal(HP.summary([s, done], []).weekendActual, 1);
  });
  it('SKIPPED (owner) and SOURCE_OMITTED (source rule) are different statuses', () => {
    const ev = [{ kind: 'MISSED_MONDAY', week: 1 }];
    const sum = HP.summary([skip('v2.1-W1-FRI', { skipDecision: 'SKIP_PERMANENT' })], ev);
    assert.equal(sum.SKIPPED, 1); assert.equal(sum.SOURCE_OMITTED, 1);
    assert.match(HP.skipAdvice('v2.1-W1-THU', [], ev, TODAY).recommendation, /already omitted by the source cascade/);
  });
});

// ---------------------------------------------------------------- rule 5
describe('owner rule 5: adaptive daily step target', () => {
  const hist = (vals, endBefore) => vals.map((v, i) => day(HP.addDays(endBefore || TODAY, -(vals.length - i)), { steps: v === null ? MISSING : O(v) }));
  const ctx = (extra) => Object.assign({ dailies: hist([8000, 9000, 7000, 8000, 10000]), walks: [], settings: { stepBaselineMode: 'AUTO' }, plannedToday: 1, recentSessions: [] }, extra);

  it('the baseline comes from actual recent history (median of recorded daily totals)', () => {
    const b = HW.stepBaseline(TODAY, hist([8000, 9000, 7000, 8000, 10000]), { stepBaselineMode: 'AUTO' });
    assert.deepEqual(b, { value: 8000, source: 'AUTO', n: 5, reason: null });
  });
  it('missing step days are left out of the baseline, never counted as zero', () => {
    const b = HW.stepBaseline(TODAY, hist([8000, null, null, 8000, null, 8000]), { stepBaselineMode: 'AUTO' });
    assert.equal(b.value, 8000); assert.equal(b.n, 3);
  });
  it('with too little history there is no invented target', () => {
    const t = HW.stepTarget(TODAY, ctx({ dailies: hist([8000, 9000]) }));
    assert.equal(t.target, null); assert.equal(t.source, 'NONE'); assert.match(t.baseline.reason, /Not enough step history/);
    assert.equal(t.met, null);
  });
  it('the baseline is configurable: a manual value replaces the automatic one', () => {
    const t = HW.stepTarget(TODAY, ctx({ settings: { stepBaselineMode: 'MANUAL', stepBaselineManual: 6000 } }));
    assert.equal(t.baseline.source, 'MANUAL'); assert.equal(t.target, 6000);
    const st = mk();
    assert.equal(st.putRecord('ownerSettings', { id: HD.SETTINGS_ID, date: TODAY, stepBaselineMode: 'MANUAL' }).ok, false, 'manual needs a number');
    assert.equal(st.putRecord('ownerSettings', { id: HD.SETTINGS_ID, date: TODAY, stepBaselineMode: 'MANUAL', stepBaselineManual: 6000 }).ok, true);
    assert.equal(st.settings().stepBaselineMode, 'MANUAL'); assert.equal(st.settings().rhrBaselineBpm, 76);
  });
  it('adapts to load: baseline on a training day, more on a light day, less after a demanding session', () => {
    assert.equal(HW.stepTarget(TODAY, ctx()).target, 8000);
    assert.equal(HW.stepTarget(TODAY, ctx({ plannedToday: 0 })).target, 8800);
    const hard = [{ date: '2026-11-17', status: 'COMPLETED', rpe: 8, type: 'STRENGTH_A' }];
    assert.equal(HW.stepTarget(TODAY, ctx({ plannedToday: 0, recentSessions: hard })).target, 6800);
    const hardNoRpe = [{ date: '2026-11-17', status: 'PARTIAL', rpe: null, type: 'INTERVALS' }];
    assert.equal(HW.stepTarget(TODAY, ctx({ recentSessions: hardNoRpe })).target, 6800);
    const easy = [{ date: '2026-11-17', status: 'COMPLETED', rpe: 4, type: 'RACE' }];
    assert.equal(HW.stepTarget(TODAY, ctx({ recentSessions: easy })).target, 8000);
    const skipped = [{ date: '2026-11-17', status: 'SKIPPED', rpe: 9, type: 'RACE' }];
    assert.equal(HW.stepTarget(TODAY, ctx({ recentSessions: skipped })).target, 8000, 'a skipped session is not load');
  });
  it('recovery comes first when soreness, pain or low readiness is recorded', () => {
    const withToday = (o) => ctx({ plannedToday: 0, dailies: hist([8000, 9000, 7000, 8000, 10000]).concat([day(TODAY, o)]) });
    assert.equal(HW.stepTarget(TODAY, withToday({ soreness: O(7) })).target, 5600);
    assert.equal(HW.stepTarget(TODAY, withToday({ pain: O(4) })).target, 5600);
    assert.equal(HW.stepTarget(TODAY, withToday({ readiness: O(3) })).target, 5600);
    assert.equal(HW.stepTarget(TODAY, withToday({ soreness: O(2), readiness: O(8) })).target, 8800);
    assert.match(HW.stepTarget(TODAY, withToday({ soreness: O(7) })).reason, /Recovery first/);
  });
  it('unrecorded soreness/readiness is reported as unknown, not assumed fine', () => {
    assert.deepEqual(HW.stepTarget(TODAY, ctx()).recoveryUnknown, ['soreness', 'readiness']);
  });
  it('the owner can override any day, and clear the override', () => {
    const d = hist([8000, 9000, 7000, 8000, 10000]).concat([day(TODAY, { stepTargetOverride: 12000 })]);
    const t = HW.stepTarget(TODAY, ctx({ dailies: d }));
    assert.equal(t.target, 12000); assert.equal(t.source, 'OVERRIDE'); assert.equal(t.adaptive, 8000);
    const st = mk();
    assert.equal(st.putRecord('daily', { id: 'daily-' + TODAY, date: TODAY, stepTargetOverride: 12000.5 }).ok, false);
    assert.equal(st.putRecord('daily', { id: 'daily-' + TODAY, date: TODAY, stepTargetOverride: 12000 }).ok, true);
    assert.equal(st.putRecord('daily', { id: 'daily-' + TODAY, date: TODAY, stepTargetOverride: null }).ok, true);
    assert.equal(HW.stepTarget(TODAY, ctx({ dailies: st.records('daily').concat(hist([8000, 9000, 7000])) })).source, 'ADAPTIVE');
  });
  it('targets never rise to make up for missed or low days', () => {
    const normal = HW.stepTarget(TODAY, ctx()).target;
    const afterMissed = HW.stepTarget(TODAY, ctx({ dailies: hist([8000, 9000, 7000, 8000, 10000, null, null, null]) })).target;
    const afterLow = HW.stepTarget(TODAY, ctx({ dailies: hist([8000, 9000, 7000, 8000, 10000, 500, 300, 200]) })).target;
    assert.ok(afterMissed <= normal, afterMissed + ' <= ' + normal);
    assert.ok(afterLow <= normal, afterLow + ' <= ' + normal);
    // exhaustive check: appending any number of low or missing days never raises the target
    for (let n = 1; n <= 9; n++) {
      [null, 0, 1000].forEach((v) => {
        const t = HW.stepTarget(TODAY, ctx({ dailies: hist([8000, 9000, 7000, 8000, 10000].concat(Array(n).fill(v))) })).target;
        assert.ok(t === null || t <= normal, 'n=' + n + ' v=' + v + ' -> ' + t);
      });
    }
  });
  it('walk steps are never added on top of a recorded daily total', () => {
    const walks = [{ date: TODAY, durationMin: 30, steps: 3000 }, { date: TODAY, durationMin: 20, steps: 2000 }];
    const s = HW.canonicalSteps(TODAY, [day(TODAY, { steps: O(7000) })], walks);
    assert.equal(s.value, 7000); assert.equal(s.partial, false);
  });
  it('walk steps count when no daily total exists, marked as a lower bound', () => {
    const walks = [{ date: TODAY, durationMin: 30, steps: 3000 }, { date: TODAY, durationMin: 20, steps: 2000 }, { date: '2026-11-17', durationMin: 20, steps: 999 }];
    const s = HW.canonicalSteps(TODAY, [day(TODAY, { steps: MISSING })], walks);
    assert.equal(s.value, 5000); assert.equal(s.partial, true); assert.match(s.source, /lower bound/);
    const t = HW.stepTarget(TODAY, ctx({ walks }));
    assert.equal(t.met, null, 'a lower bound below target is "unknown", not "missed"');
    assert.equal(HW.stepTarget(TODAY, ctx({ walks: [{ date: TODAY, durationMin: 90, steps: 9000 }] })).met, true);
  });
  it('missing steps are null, never zero', () => {
    assert.equal(HW.canonicalSteps(TODAY, [], []).value, null);
    assert.equal(HW.canonicalSteps(TODAY, [day(TODAY, { steps: MISSING })], [{ date: TODAY, durationMin: 30 }]).value, null);
    assert.equal(HW.stepTarget(TODAY, ctx()).met, null);
    assert.equal(HW.canonicalSteps(TODAY, [day(TODAY, { steps: O(0) })], []).value, 0, 'a recorded 0 is a real 0');
  });
  it('weekly trend and consistency: means over recorded days only, missing days reported as missing', () => {
    // week of Mon 9 Nov: 3 recorded days; week of Mon 16 Nov: Mon+Tue recorded, Wed (today) missing
    const d = [day('2026-11-09', { steps: O(6000) }), day('2026-11-10', { steps: O(8000) }), day('2026-11-12', { steps: O(10000) }),
      day('2026-11-16', { steps: O(9000) }), day('2026-11-17', { steps: O(5000) }), day(TODAY, { steps: MISSING })];
    const w = HW.weeklySteps(TODAY, d, () => 8000, 2);
    assert.deepEqual(w[0], { weekStart: '2026-11-09', daysElapsed: 7, daysRecorded: 3, daysMissing: 4, mean: 8000, total: 24000, daysMetTarget: 2, daysWithTarget: 3 });
    assert.deepEqual(w[1], { weekStart: '2026-11-16', daysElapsed: 3, daysRecorded: 2, daysMissing: 1, mean: 7000, total: 14000, daysMetTarget: 1, daysWithTarget: 2 });
    const empty = HW.weeklySteps(TODAY, [], null, 1)[0];
    assert.equal(empty.mean, null); assert.equal(empty.total, null); assert.equal(empty.daysMetTarget, null);
  });
});
