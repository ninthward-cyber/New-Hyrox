'use strict';
// P1.1 packaging: release name, the 17th app file in the list / page / load guard / README, and what did NOT change.
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const root = path.join(__dirname, '..');
const read = (f) => fs.readFileSync(path.join(root, f), 'utf8');
const sha = (f) => crypto.createHash('sha256').update(fs.readFileSync(path.join(root, f))).digest('hex');

test('P1.1 package: release label P1.1-RC2 (re-pointed: P1.3-RC1 now; checked in p1-3-package.test.js), source copy unstamped', () => {
  const html = read('index.html');
  assert.match(html, /<meta name="hyrox-release" content="(P1\.1-RC2|P1\.3-RC1|P1\.3-RC2|P1\.3-RC3|P1\.4-RC[123])">/); // RE-POINTED by P1.4-RC2 (Sprint B2, 23 Nov 2026); // RE-POINTED by the integrated candidate P1.4-RC1 (23 Nov 2026); // P1.3-RC2 added by the independent review // RE-POINTED by P1.4-RC3 (Claude independent QA, 23 Nov 2026)
  assert.match(html, /<meta name="hyrox-build-id" content="dev">/);
});

test('P1.1 package: hyrox-morning.js is listed, loaded before the UI scripts, and checked by the load guard', () => {
  const list = read('DEPLOY-FILES.txt').split('\n').map((l) => l.trim()).filter((l) => /^(index\.html|src\/.+)$/.test(l));
  assert.strictEqual(list.length, 20); // RE-POINTED R8 (24 Nov 2026): +src/integrations/garmin-import.js -> 20; Sprint D added hyrox-coach-export.js (re-pointed, not removed)
  assert.ok(list.includes('src/data/hyrox-coach.js'));
  assert.ok(list.includes('src/data/hyrox-morning.js'));
  assert.ok(list.includes('src/integrations/garmin-import.js')); // RE-POINTED R8
  const html = read('index.html');
  const at = (s) => { const i = html.indexOf(s); assert.ok(i > 0, s); return i; };
  assert.ok(at('<script src="src/data/hyrox-morning.js"></script>') < at('<script src="src/ui/app.js"></script>'));
  assert.ok(at('<script src="src/data/hyrox-data.js"></script>') < at('<script src="src/data/hyrox-morning.js"></script>'));
  assert.match(html, /\['src\/data\/hyrox-morning\.js', 'HyroxMorning'\]/);
  assert.strictEqual(html.split('src/data/hyrox-morning.js"></script>').length, 2);
  assert.match(html, /data-mode="morning" data-testid="add-mode-morning"/);
});

test('P1.1 package: the deploy README and notes name this package and its limits', () => {
  const readme = read('deploy/README-DEPLOY.txt'); // re-pointed for P1.3: the README keeps the P1.1-RC2 history; Home is no longer unchanged
  for (const re of [/P1\.1-RC2/, /DEPLOY-P1\.1-RC2\.md/, /SHA256SUMS-p1-1-rc2\.txt/, /F-1 fixed/, /the 19 static app files/, /* RE-POINTED by Sprint D (P1.4): 18 -> 19 app files */ /hyrox-morning\.js/, /No new storage key/, /NOT deploy approval/, /Today \(Home\) was unchanged/]) assert.match(readme, re);
  const dep = read('DEPLOY-P1.1-RC2.md'), chg = read('CHANGES-P1.1-RC1.md'), chg2 = read('CHANGES-P1.1-RC2.md');
  assert.match(dep, /661aa5b546a72c2e3c9cf54d146da1ac1d00df5280e0e0788b0f3a532833a14c/); assert.match(chg2, /980add45831935866f8f6dbdac15a09cc3f24e9c/); assert.match(chg2, /Root cause/);
  assert.match(dep, /not deploy approval/); assert.match(dep, /F-1 check/); assert.match(dep, /34251d47a6978d80ddac6f4fa157399c8163f083816ea02002e5822fee1593cb/);
  assert.match(chg, /ccea61fc22460ac9c82e6d8c31da8292d38aeb27c29ebd1dcb523bbd8b06b45e/); assert.match(chg, /fefa19366150dc2590fe6b7a5a69cd38b5594818/);
  assert.match(chg, /Not Safari, not a physical iPhone/); assert.match(chg, /F-1[^\n]*not touched/);
});

test('P1.1 scope: style.css keeps the P0-RC3 rules byte-for-byte (P1.3 only appends); no new storage key; no network, provider or Garmin/Apple Health call was added', () => {
  // Re-pointed for P1.3 (not removed): the P0-RC3 file (sha256 5b150e67...0158) must still be an unchanged PREFIX; P1.3 appends
  // its Home closeout and Nutrition Coach rules after it and changes no earlier rule.
  const css = fs.readFileSync(path.join(__dirname, '..', 'src', 'ui', 'style.css'));
  const p0Len = Number(fs.readFileSync(path.join(__dirname, 'fixtures', 'p0-rc3-style-length.txt'), 'utf8').trim());
  assert.strictEqual(require('crypto').createHash('sha256').update(css.subarray(0, p0Len)).digest('hex'), '5b150e67fb0db28cb0d2d55bf687c5f8284941a9c6543084290b3c09d9210158');
  assert.match(css.subarray(p0Len).toString('utf8'), /^\n\/\* P1\.3 Delivery A/);
  const ext = read('src/ui/app-ext.js'), app = read('src/ui/app.js'), hm = read('src/data/hyrox-morning.js');
  assert.doesNotMatch(hm, /localStorage|sessionStorage|indexedDB|fetch\(|XMLHttpRequest|navigator\.|import\(/);
  // every literal storage key in the UI scripts is one that P0-RC3 already had
  const keys = new Set(); for (const s of [ext, app]) for (const m of s.matchAll(/'(hyrox\.[a-z0-9.-]+)'/g)) keys.add(m[1]);
  for (const k of keys) assert.ok(['hyrox.v1', 'hyrox.v1.corrupt-backup', 'hyrox.v1.pre-import-backup', 'hyrox.ai-settings', 'hyrox.ai-owner-code', 'hyrox.ui.workout-draft', 'hyrox.ui.meal-draft', 'hyrox.backup-note'].includes(k), 'unexpected storage key ' + k); /* RE-POINTED by Sprint B2 (owner decision M1, 23 Nov 2026): + UI-only key hyrox.ui.meal-draft */
  for (const s of [ext, app, hm]) assert.doesNotMatch(s, /connect\.garmin|healthkit|apple-health|googleapis|oauth/i);
});

test('P1.1 scope: the morning log never scales, estimates or merges - the weekly sum has no input but check-ins', () => {
  const hm = read('src/data/hyrox-morning.js').replace(/\/\*[\s\S]*?\*\/|\/\/.*$/gm, '');
  assert.doesNotMatch(hm, /\b(sessions|walks|workouts|kcal|durationMin)\b/);
  assert.doesNotMatch(hm, /\* *7 *\/|\/ *daysRecorded|\/ *rec\b/); // no "x 7 / recorded days" projection
});
