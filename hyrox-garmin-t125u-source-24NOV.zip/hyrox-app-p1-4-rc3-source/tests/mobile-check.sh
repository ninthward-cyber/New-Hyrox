#!/usr/bin/env bash
# Screenshot index.html at an iPhone-sized viewport with headless Chrome.
# Usage: tests/mobile-check.sh [path-to-index.html]
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
OUT_DIR="$SCRIPT_DIR/out"
SCREENSHOT="$OUT_DIR/iphone-390x844.png"
CHROME="${CHROME_BIN:-/usr/bin/google-chrome}"
UA='Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1'

find_index() {
  local candidates=(
    "$REPO_ROOT/index.html"
    "$REPO_ROOT/src/index.html"
    "/workspace/hyrox-wt/frontend/index.html"
    "/workspace/hyrox-wt/frontend/src/index.html"
  )
  local p
  for p in "${candidates[@]}"; do
    if [[ -f "$p" ]]; then
      echo "$p"
      return 0
    fi
  done
  return 1
}

if [[ "${1:-}" != "" ]]; then
  INDEX="$1"
else
  if ! INDEX="$(find_index)"; then
    echo "index.html not found. Pass a path, or place it at the repo root, under src/, or in /workspace/hyrox-wt/frontend/." >&2
    exit 1
  fi
fi

if [[ ! -f "$INDEX" ]]; then
  echo "index.html not found at: $INDEX" >&2
  exit 1
fi

if [[ ! -x "$CHROME" && ! -f "$CHROME" ]]; then
  echo "Chrome not found at $CHROME" >&2
  exit 1
fi

INDEX_ABS="$(cd "$(dirname "$INDEX")" && pwd)/$(basename "$INDEX")"
mkdir -p "$OUT_DIR"

echo "Using index: $INDEX_ABS"
echo "Screenshot:  $SCREENSHOT"

"$CHROME" \
  --headless=new \
  --disable-gpu \
  --no-sandbox \
  --disable-dev-shm-usage \
  --hide-scrollbars \
  --window-size=390,844 \
  --user-agent="$UA" \
  --screenshot="$SCREENSHOT" \
  "file://${INDEX_ABS}"

if [[ ! -s "$SCREENSHOT" ]]; then
  echo "Chrome ran but did not write a screenshot to $SCREENSHOT" >&2
  exit 1
fi

echo "Wrote $SCREENSHOT ($(wc -c < "$SCREENSHOT") bytes)"
