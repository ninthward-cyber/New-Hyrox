'use strict';
// Meron (QA): OWNER-DECISIONS-t47u.txt Decision 3 — SOURCE_45_MIN / SOURCE_25_MIN
// prescriptions from HNC-BASE-v2.1 section 9 (line 121). Synthetic data only. New file.

const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const HP = require(path.resolve(__dirname, '../src/data/hyrox-plan.js'));
const { mem, mk, ts } = require('./p8-helpers.js');

const D = '2026-11-18';

function fallbackApi() {
  const names = ['fallbackPrescription', 'variantPrescription', 'sourceFallback', 'busyDayPrescription', 'fallbackPlan'];
  for (let i = 0; i < names.length; i++) {
    if (typeof HP[names[i]] === 'function') return { name: names[i], fn: HP[names[i]] };
  }
  return null;
}
function prescription(slotId, variant) {
  const api = fallbackApi();
  if (!api) return null;
  try { return api.fn(slotId, variant); } catch (e) {
    const slot = HP.slotById(slotId);
    return api.fn(slot, variant);
  }
}
function textOf(p) {
  if (!p) return '';
  if (typeof p === 'string') return p;
  if (Array.isArray(p)) return p.map(textOf).join('\n');
  if (Array.isArray(p.prescription)) return p.prescription.map(textOf).join('\n');
  if (Array.isArray(p.blocks)) return p.blocks.map((b) => [b.label, b.exercise, b.kind, b.notes].filter(Boolean).join(' ')).join('\n');
  return JSON.stringify(p);
}

describe('Decision 3 (already on this build): variant, duration and completion are separate; 15-min machine limit; 17/20 numerator stays open', () => {
  it('SOURCE_45_MIN and SOURCE_25_MIN are loggable variants, distinct from actual duration and completion status', () => {
    // "Clearly distinguish prescribed variant, actual duration and actual completion"
    const st = mk(mem());
    const logged = st.putRecord('sessions', {
      date: D, status: 'PARTIAL', modified: false, variant: 'SOURCE_25_MIN',
      durationMin: 28, planSlotId: 'v2.1-W1-WED', title: 'Made-up 25-min strength', blocks: [],
    });
    assert.equal(logged.ok, true, JSON.stringify(logged));
    const e = logged.entry;
    assert.equal(e.variant, 'SOURCE_25_MIN');
    assert.equal(e.durationMin, 28);
    assert.equal(e.status, 'PARTIAL');
    assert.notEqual(e.status, 'COMPLETED');
  });

  it('choosing a fallback variant does not by itself create a completed session or invent a 17/20 qualifying numerator', () => {
    // "Add tests and verify variant logging does not fabricate completed sessions or silently alter the unresolved 17/20 count rule."
    // "17/20 numerator remains an explicit owner decision; show 20 planned weekday sessions, but no definitive qualifying numerator until criteria are approved."
    const unfinished = [{
      planSlotId: 'v2.1-W1-MON', status: 'NOT_STARTED', modified: false, variant: 'SOURCE_45_MIN', createdAt: ts, date: '2026-11-16',
    }];
    const sum0 = HP.summary(unfinished, []);
    assert.equal(sum0.denominator, 20);
    assert.equal(sum0.COMPLETED, 0);
    assert.equal(sum0.fallback, 1);
    assert.equal(sum0.planned, 20);
    assert.equal(sum0.qualifyingNumerator, null);
    assert.equal(sum0.qualified, undefined);
    assert.equal(sum0.numerator, undefined);
    assert.match(sum0.note, /20/);
    assert.match(sum0.note, /OPEN owner decision|17\/20/i);

    const done = [{
      planSlotId: 'v2.1-W1-MON', status: 'COMPLETED', modified: false, variant: 'SOURCE_25_MIN', createdAt: ts, date: '2026-11-16',
    }];
    const sum1 = HP.summary(done, []);
    assert.equal(sum1.COMPLETED, 1);
    assert.equal(sum1.fallback, 1);
    assert.equal(sum1.denominator, 20);
    assert.equal(sum1.qualified, undefined, 'must not invent a qualifying 17/20 numerator');
    assert.match(sum1.note, /OPEN owner decision|17\/20/i);
    const b = HP.benchmarks(done);
    // A variant completion is not a comparable original-60 benchmark (when applied to a benchmark slot).
  });

  it('the per-machine 15-minute uninterrupted limit still validates (900 within, 960 overrun, never clipped)', () => {
    assert.equal(HP.MACHINE_LIMIT_SEC, 900);
    assert.equal(HP.machineCompliance({ kind: 'skierg', durationSec: 900 }), 'WITHIN_LIMIT');
    const b = { kind: 'row', durationSec: 960 };
    assert.equal(HP.machineCompliance(b), 'OVERRUN');
    assert.equal(b.durationSec, 960, 'recorded duration is never clipped');
    assert.equal(HP.machineCompliance({ kind: 'bike' }), 'UNVERIFIED');
  });

  it('the planned session type is still strength on Mon/Wed and HYROX on Tue/Thu/Fri', () => {
    assert.equal(HP.slotById('v2.1-W1-MON').type, 'STRENGTH_A');
    assert.equal(HP.slotById('v2.1-W1-WED').type, 'STRENGTH_B');
    assert.ok(['INTERVALS', 'HYROX', 'AEROBIC', 'RACE'].includes(HP.slotById('v2.1-W1-TUE').type) || /HYROX|INTERVAL/i.test(HP.slotById('v2.1-W1-TUE').type + HP.slotById('v2.1-W1-TUE').title));
    assert.equal(HP.slotById('v2.1-W1-THU').type, 'AEROBIC');
    assert.ok(HP.slotById('v2.1-W1-FRI').type === 'RACE' || /race/i.test(HP.slotById('v2.1-W1-FRI').title));
  });
});

describe('Decision 3: implement real SOURCE_45_MIN and SOURCE_25_MIN prescriptions from HNC-BASE-v2.1 §9', () => {
  it('fallbackPrescription is the same function as variantPrescription; a draft is NOT_STARTED with no loads', () => {
    assert.equal(HP.fallbackPrescription, HP.variantPrescription);
    const d = HP.variantDraft('v2.1-W1-MON', 'SOURCE_25_MIN');
    assert.equal(d.status, 'NOT_STARTED');
    assert.equal(d.durationMin, null);
    assert.equal(d.variant, 'SOURCE_25_MIN');
    const blob = JSON.stringify(d);
    assert.equal(/"loadKg":\s*[0-9]/.test(blob), false);
    assert.equal(/"reps":\s*[0-9]/.test(blob), false);
    const st = mk(mem());
    assert.equal(st.putRecord('sessions', d).ok, true);
    assert.equal(HP.summary(st.records('sessions'), []).COMPLETED, 0);
    assert.equal(HP.summary(st.records('sessions'), []).planned, 20);
    assert.equal(HP.summary(st.records('sessions'), []).qualifyingNumerator, null);
  });

  it('45 min: preserve the main strength lift OR the main HYROX circuit; omit accessories', () => {
    // Decision 3 and source §9: "45 minutes: keep main lift or main HYROX circuit, drop accessories."
    const mon45 = prescription('v2.1-W1-MON', 'SOURCE_45_MIN');
    const tue45 = prescription('v2.1-W1-TUE', 'SOURCE_45_MIN');
    const monT = textOf(mon45);
    const tueT = textOf(tue45);
    assert.match(monT, /squat|bench|main lift/i);
    assert.doesNotMatch(monT, /dead bug|back extension|farmer/i); // accessories omitted; source §4 lists these as later-block accessories
    assert.ok(tueT.length > 0, 'HYROX 45 must keep the main circuit');
    // "never fabricate loads, splits or repetitions"
    assert.doesNotMatch(monT + tueT, /\b\d+\s*kg\b|\b\d+\s*lb\b/i);
  });

  it('25 min strength: warm-up plus 2 work sets of squat+bench (Monday) or deadlift+press (Wednesday)', () => {
    // "25 minutes strength: warm up then 2 working sets each of squat+bench (Monday) or deadlift+press (Wednesday)."
    const mon = textOf(prescription('v2.1-W1-MON', 'SOURCE_25_MIN'));
    const wed = textOf(prescription('v2.1-W1-WED', 'SOURCE_25_MIN'));
    assert.match(mon, /warm/i);
    assert.match(mon, /squat/i);
    assert.match(mon, /bench/i);
    assert.doesNotMatch(mon, /deadlift/i);
    assert.match(wed, /warm/i);
    assert.match(wed, /deadlift/i);
    assert.match(wed, /press/i);
    assert.doesNotMatch(wed, /squat/i);
    assert.match(mon, /2|two/i);
    // Type matches the planned session: strength 25 is not used as a HYROX 25 template.
    const tue = textOf(prescription('v2.1-W1-TUE', 'SOURCE_25_MIN'));
    assert.doesNotMatch(tue, /squat \+ bench|deadlift \+ press/i);
  });

  it('25 min HYROX: 5-minute warm-up, two short run/station rounds, 3-minute cooldown', () => {
    // "25 minutes HYROX: 5 min warm-up, two short run/station rounds, 3 min cooldown."
    const tue = textOf(prescription('v2.1-W1-TUE', 'SOURCE_25_MIN'));
    const thu = textOf(prescription('v2.1-W1-THU', 'SOURCE_25_MIN'));
    const fri = textOf(prescription('v2.1-W1-FRI', 'SOURCE_25_MIN'));
    [tue, thu, fri].forEach((t) => {
      assert.match(t, /5\s*min/i);
      assert.match(t, /warm/i);
      assert.match(t, /two|2/i);
      assert.match(t, /round/i);
      assert.match(t, /3\s*min/i);
      assert.match(t, /cool/i);
      // "For details source does not specify (station selections, interval distances, extra exact durations), preserve what is already defined ... rather than inventing prescriptions."
      // No invented race loads:
      assert.doesNotMatch(t, /\b\d+\s*kg\b|\b\d+\s*lb\b/i);
    });
  });
});
