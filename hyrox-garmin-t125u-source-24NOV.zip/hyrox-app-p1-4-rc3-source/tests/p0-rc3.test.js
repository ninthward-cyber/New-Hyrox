'use strict';
// P0: build label. The packaged index.html carries a source id that equals an independent SHA-256 over the app files (16 at P0-RC3, 17 since P1.1) of
// the source tree; the source tree itself stays "dev"; the package is otherwise a byte copy; a rebuild is identical.
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFileSync } = require('child_process');

const root = path.resolve(__dirname, '..');
const APP = fs.readFileSync(path.join(root, 'DEPLOY-FILES.txt'), 'utf8').split('\n').map((l) => l.trim()).filter((l) => /^(index\.html|src\/.+)$/.test(l));
function build() {
  const out = fs.mkdtempSync(path.join(os.tmpdir(), 'hyrox-p0-'));
  execFileSync(process.execPath, [path.join(root, 'tools', 'build-deploy-package.mjs'), path.join(out, 'pkg')], { stdio: 'pipe' });
  return path.join(out, 'pkg');
}
function independentId() {
  const h = crypto.createHash('sha256');
  for (const f of APP) { h.update(f); h.update('\0'); h.update(fs.readFileSync(path.join(root, f))); h.update('\0'); }
  return h.digest('hex').slice(0, 12);
}
const meta = (html, name) => { const m = new RegExp('<meta name="' + name + '" content="([^"]*)">').exec(html); return m ? m[1] : null; };

test('P0 build label: the source index.html is unstamped ("dev") and names the release and build date', () => {
  const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
  assert.strictEqual(meta(html, 'hyrox-build-id'), 'dev');
  assert.match(meta(html, 'hyrox-release'), /^[A-Za-z0-9.-]{2,20}$/);
  assert.match(meta(html, 'hyrox-build-date'), /^\d{4}-\d{2}-\d{2}$/);
  assert.strictEqual(html.split('name="hyrox-build-id"').length, 2);
});

test('P0 build label: the packaged index.html carries the source id = SHA-256 over the source app files; every other file is a byte copy', () => {
  assert.strictEqual(APP.length, 20); // RE-POINTED R8 (24 Nov 2026): +src/integrations/garmin-import.js -> 20; Sprint D added hyrox-coach-export.js
  const pkg = build(), id = independentId();
  const html = fs.readFileSync(path.join(pkg, 'publish', 'index.html'), 'utf8');
  assert.match(id, /^[0-9a-f]{12}$/);
  assert.strictEqual(meta(html, 'hyrox-build-id'), id);
  const src = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
  assert.strictEqual(html, src.replace('<meta name="hyrox-build-id" content="dev">', '<meta name="hyrox-build-id" content="' + id + '">'));
  for (const f of APP) if (f !== 'index.html') assert.ok(fs.readFileSync(path.join(pkg, 'publish', f)).equals(fs.readFileSync(path.join(root, f))), f);
});

test('P0 build label: a rebuild gives identical bytes; changing any app file changes the id', () => {
  const a = build(), b = build();
  for (const f of APP) assert.ok(fs.readFileSync(path.join(a, 'publish', f)).equals(fs.readFileSync(path.join(b, 'publish', f))), f);
  const h = crypto.createHash('sha256');
  for (const f of APP) { h.update(f); h.update('\0'); h.update(Buffer.concat([fs.readFileSync(path.join(root, f)), Buffer.from(f === 'src/ui/style.css' ? ' ' : '')])); h.update('\0'); }
  assert.notStrictEqual(h.digest('hex').slice(0, 12), independentId());
});

test('P0 scope: the data layer, nutrition, plan, blocks, wellness, estimator, food data, photo AI and every server file are byte-identical to RC2', () => {
  // RC2 pins (sha256 of the files in hyrox-app-rc2-source.zip, source sha256 70f75120…)
  // Re-pointed by the P0 sprint photo + note fix (23 Nov 2026): photo-ai.js, openai.mjs and handler.mjs changed on purpose;
  // they are checked against their documented RC2 hash AND their new sprint hash (tests/p0-sprint-pins.js). All others: RC2.
  assert.ok(require('./p0-sprint-pins.js').checkRc2PinsWithSprint(root) >= 18);
});

test('P0: the deploy README still names P0-RC3, its deploy notes and the build-label check; it lists every app file', () => {
  const readme = fs.readFileSync(path.join(root, 'deploy', 'README-DEPLOY.txt'), 'utf8');
  assert.match(readme, /P0-RC3/); assert.match(readme, /DEPLOY-P0-RC3\.md/); assert.match(readme, /About this build/);
  assert.match(readme, /NOT deploy approval/); assert.match(readme, /11 Dec 2026/); assert.match(readme, /byte-identical to RC2/);
  for (const f of APP) assert.ok(readme.includes(f.replace(/^src\/[a-z]+\//, '')), 'README lists ' + f);
  assert.ok(fs.existsSync(path.join(root, 'DEPLOY-P0-RC3.md')) && fs.existsSync(path.join(root, 'CHANGES-P0-RC3.md')));
  const rel = /<meta name="hyrox-release" content="([^"]*)">/.exec(fs.readFileSync(path.join(root, 'index.html'), 'utf8'))[1];
  assert.match(rel, /^(P0-RC3|P1\.[1-4]-RC\d+)$/); // later increments rename the release; P1.1 is checked in tests/p1-1-package.test.js
});
