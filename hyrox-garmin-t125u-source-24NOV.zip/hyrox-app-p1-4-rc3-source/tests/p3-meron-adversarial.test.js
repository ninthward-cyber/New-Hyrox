'use strict';
// Meron (QA): adversarial probes of Dawit's step / recovery / import work.
// Synthetic data only. New file; no edits to src/ or existing tests.
// Tests under a describe name starting with 'DEFECT:' are expected to FAIL
// on this build; they assert the contract, not the current (wrong) behaviour.

const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const HW = require(path.resolve(__dirname, '../src/data/hyrox-wellness.js'));
const { HD, KEY, mem, mk, O, MISSING, ts, backup, restore } = require('./p3-helpers.js');

const D = '2026-11-11';
const baseSess = { date: D, status: 'COMPLETED', modified: false, variant: 'NONE', blocks: [] };
const run = (id, runSteps, extra) => Object.assign({
  id, createdAt: ts, date: D, status: 'COMPLETED', modified: false, variant: 'NONE', blocks: [],
  runSteps, runStepsSource: runSteps == null ? undefined : 'DEVICE',
}, extra);

describe('adversarial: runSteps / walk / daily validation (putRecord and import)', () => {
  it('rejects negative, fractional, string, huge, boolean and array runSteps', () => {
    const st = mk(mem());
    const bad = [
      { runSteps: -1, runStepsSource: 'DEVICE' },
      { runSteps: 10.5, runStepsSource: 'DEVICE' },
      { runSteps: '6000', runStepsSource: 'DEVICE' },
      { runSteps: 200001, runStepsSource: 'DEVICE' },
      { runSteps: 1e6, runStepsSource: 'DEVICE' },
      { runSteps: true, runStepsSource: 'DEVICE' },
      { runSteps: false, runStepsSource: 'DEVICE' },
      { runSteps: [6000], runStepsSource: 'DEVICE' },
      { runSteps: 6000, runStepsSource: 'ESTIMATED' },
      { runSteps: 6000 },
    ];
    bad.forEach((b) => {
      const r = st.putRecord('sessions', Object.assign({}, baseSess, b));
      assert.equal(r.ok, false, 'should reject ' + JSON.stringify(b));
    });
  });

  it('Infinity / NaN / -Infinity with a source are refused (not stored)', () => {
    const st = mk(mem());
    ['Infinity', 'NaN', '-Infinity'].forEach((name) => {
      const v = name === 'NaN' ? NaN : name === '-Infinity' ? -Infinity : Infinity;
      const r = st.putRecord('sessions', Object.assign({}, baseSess, { runSteps: v, runStepsSource: 'DEVICE' }));
      assert.equal(r.ok, false, name + ' with source must be refused');
    });
    assert.equal(st.records('sessions').length, 0);
  });

  it('a string walk-step value is refused; a recorded daily 0 is kept and missing stays null', () => {
    const st = mk(mem());
    assert.equal(st.putRecord('walks', { date: D, durationMin: 30, steps: '3000' }).ok, false);
    assert.equal(st.putRecord('daily', { date: D, steps: O(0) }).ok, true);
    assert.equal(st.records('daily')[0].steps.value, 0);
    assert.equal(HW.daySteps(D, { dailies: st.records('daily') }).total, 0);
    assert.equal(HW.daySteps(D, { dailies: [{ id: 'd', createdAt: ts, date: D, steps: MISSING }] }).total, null);
  });

  it('import of one bad runSteps (fraction or string) rejects the whole file and writes nothing', () => {
    const payloads = [
      run('s-bad', 10.5),
      Object.assign(run('s-str', 1), { runSteps: '1000', runStepsSource: 'DEVICE' }),
    ];
    payloads.forEach((bad) => {
      const s = mem();
      const st = mk(s);
      st.addWeight({ date: D, kg: 80 });
      const before = s.m[KEY], writes = s.writes;
      const text = backup({ sessions: [run('s-ok', 4000), bad] });
      const p = st.previewImport(text);
      assert.equal(p.ok, false, JSON.stringify(bad));
      assert.equal(p.code, 'invalid_records');
      assert.equal(st.applyImport(text, { confirm: 'REPLACE', expectCurrent: { weight: 1, workouts: 0, nutrition: 0 } }).ok, false);
      assert.equal(s.m[KEY], before);
      assert.equal(s.writes, writes);
    });
  });
});

describe('adversarial: __proto__ / constructor / prototype keys and duplicate ids', () => {
  it('top-level __proto__, constructor and prototype keys do not pollute Object.prototype and write nothing until a valid apply', () => {
    const text = JSON.stringify({
      app: 'hyrox-app', version: 2, exportedAt: ts,
      weight: [{ id: 'w', createdAt: ts, date: D, kg: 80 }],
      workouts: [], nutrition: [],
      __proto__: { polluted: true },
      constructor: { polluted: true },
      prototype: { polluted: true },
    });
    const s = mem();
    const st = mk(s);
    const p = st.previewImport(text);
    assert.equal(p.ok, true, p.code + ' ' + JSON.stringify(p.errors));
    assert.equal(Object.prototype.polluted, undefined);
    assert.equal(({}).polluted, undefined);
    // preview is read-only
    assert.equal(s.m[KEY], undefined);
  });

  it('session ids named __proto__, constructor and prototype import and daySteps counts each once', () => {
    const text = backup({
      sessions: [run('__proto__', 1000), run('constructor', 2000), run('prototype', 3000)],
    });
    const st = mk(mem());
    assert.equal(restore(st, text).ok, true);
    const ids = st.records('sessions').map((x) => x.id).sort();
    assert.deepEqual(ids, ['__proto__', 'constructor', 'prototype']);
    const ds = HW.daySteps(D, { sessions: st.records('sessions') });
    assert.equal(ds.total, 6000);
    assert.equal(ds.runCount, 3);
    assert.equal(Object.prototype.polluted, undefined);
  });

  it('a duplicate session id rejects the whole file and writes nothing', () => {
    const s = mem();
    const st = mk(s);
    st.addWeight({ date: D, kg: 80 });
    const before = s.m[KEY], writes = s.writes;
    const text = backup({ sessions: [run('dup', 1000), run('dup', 2000)] });
    const p = st.previewImport(text);
    assert.equal(p.ok, false);
    assert.equal(p.code, 'duplicate_ids');
    assert.equal(st.applyImport(text, { confirm: 'REPLACE', expectCurrent: { weight: 1, workouts: 0, nutrition: 0 } }).ok, false);
    assert.equal(s.m[KEY], before);
    assert.equal(s.writes, writes);
  });
});

describe('adversarial: raw recovery vs normal import, corrupt/truncated files, repeated import', () => {
  it('parseRawRecovery rejects a truncated file, a checksum mismatch, and a normal backup', () => {
    const t = mk(mem({ [KEY]: '{"version":2,"weight":[],"workouts":[],"nutrition":[]}' })).rawRecoveryExport().text;
    assert.equal(HD.parseRawRecovery(t).ok, true);
    assert.equal(HD.parseRawRecovery(t.slice(0, t.length - 10)).code, 'not_raw_recovery');
    const edited = JSON.parse(t);
    edited.sources[0].raw = edited.sources[0].raw.replace('version', 'VERSION');
    assert.equal(HD.parseRawRecovery(JSON.stringify(edited)).code, 'damaged');
    const lied = JSON.parse(t);
    lied.sources[0].checksum = 'deadbeef';
    assert.equal(HD.parseRawRecovery(JSON.stringify(lied)).code, 'damaged');
    assert.equal(HD.parseRawRecovery(backup({})).code, 'not_raw_recovery');
  });

  it('a raw recovery file is refused by previewImport/applyImport; a normal backup is refused by parseRawRecovery', () => {
    const rawText = mk(mem({ [KEY]: '{"version":2,"weight":[{"id":"w","createdAt":"' + ts + '","date":"2026-11-10","kg":80}],"workouts":[],"nutrition":[]}' })).rawRecoveryExport().text;
    const s = mem();
    const st = mk(s);
    st.addWeight({ date: '2026-11-10', kg: 70 });
    const before = JSON.stringify(s.m), writes = s.writes;
    assert.equal(st.previewImport(rawText).code, 'raw_recovery_file');
    const a = st.applyImport(rawText, { confirm: 'REPLACE', expectCurrent: { weight: 1, workouts: 0, nutrition: 0 } });
    assert.equal(a.ok, false);
    assert.equal(a.code, 'raw_recovery_file');
    assert.equal(JSON.stringify(s.m), before);
    assert.equal(s.writes, writes);
    assert.equal(HD.parseRawRecovery(st.exportJSON()).code, 'not_raw_recovery');
  });

  it('repeated import of the same valid file does not duplicate records', () => {
    const src = mk(mem());
    src.putRecord('sessions', Object.assign({}, baseSess, { id: 'a', runSteps: 1000, runStepsSource: 'DEVICE' }));
    const text = src.exportJSON();
    const s = mem();
    const st = mk(s);
    assert.equal(restore(st, text).ok, true);
    assert.equal(restore(st, text).ok, true);
    assert.equal(restore(st, text).ok, true);
    assert.equal(st.records('sessions').length, 1);
    assert.equal(st.records('sessions')[0].runSteps, 1000);
  });
});

describe('DEFECT: putRecord silently coerces NaN/Infinity step values to null and accepts the write', () => {
  // JSON.stringify turns NaN/Infinity into null before validation, so a walk
  // (or a session runSteps with no source) is stored as "not recorded" with ok:true.
  it('walk steps of Infinity, NaN or -Infinity must be rejected, not stored as null', () => {
    [Infinity, NaN, -Infinity].forEach((v) => {
      const s = mem();
      const st = mk(s);
      const r = st.putRecord('walks', { date: D, durationMin: 30, steps: v });
      assert.equal(r.ok, false, String(v) + ' must be rejected, got entry ' + JSON.stringify(r.entry));
    });
  });

  it('session runSteps of Infinity or NaN with no source must be rejected, not stored as null', () => {
    [Infinity, NaN, -Infinity].forEach((v) => {
      const s = mem();
      const st = mk(s);
      const r = st.putRecord('sessions', Object.assign({}, baseSess, { runSteps: v }));
      assert.equal(r.ok, false, String(v) + ' must be rejected, got entry ' + JSON.stringify(r.entry));
    });
  });
});

describe('DEFECT: a fractional OBSERVED daily total is accepted, but the contract requires an integer 0..200000', () => {
  it('putRecord and import refuse daily steps of 10.5', () => {
    const st = mk(mem());
    const put = st.putRecord('daily', { date: D, steps: O(10.5) });
    assert.equal(put.ok, false, 'putRecord accepted 10.5: ' + JSON.stringify(put.entry));
    const s = mem();
    const st2 = mk(s);
    st2.addWeight({ date: D, kg: 80 });
    const before = s.m[KEY];
    const text = backup({ daily: [{ id: 'd', createdAt: ts, date: D, steps: O(10.5) }] });
    const p = st2.previewImport(text);
    assert.equal(p.ok, false, 'import accepted 10.5: ' + JSON.stringify(p));
    assert.equal(s.m[KEY], before);
  });
});

describe('DEFECT: daySteps counts runSteps on SKIPPED and NOT_STARTED sessions', () => {
  // Contract: runSteps are only allowed when status is IN_PROGRESS, COMPLETED or PARTIAL.
  // putRecord/import already refuse those records, and records() hides them, but the
  // public daySteps() API still sums them if they are passed in.
  it('runSteps on SKIPPED or NOT_STARTED must not enter the lower bound', () => {
    const skipped = run('sk', 5000, { status: 'SKIPPED', skipConfirmed: true });
    const notStarted = run('ns', 4000, { status: 'NOT_STARTED' });
    const a = HW.daySteps(D, { sessions: [skipped] });
    const b = HW.daySteps(D, { sessions: [notStarted] });
    assert.equal(a.total, null, 'SKIPPED runSteps were counted: ' + JSON.stringify(a));
    assert.equal(a.source, null);
    assert.equal(b.total, null, 'NOT_STARTED runSteps were counted: ' + JSON.stringify(b));
  });
});
