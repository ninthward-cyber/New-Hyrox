// Phase 10: the Netlify function with 1-3 photos of one meal, ordered idempotency, worst-case cost bound and safe
// provider diagnostics. Same offline harness as Phase 9: in-memory Blobs store, stub OpenAI (injected fetch), no network,
// no real key, synthetic images only. NO paid call.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import * as H from './p9-helpers.mjs';
import { readConfig, worstCaseUsd, imageTokenBound, MULTI, IMAGE_LABELS, TOKEN_BOUND } from '../netlify/lib/config.mjs';
import { requestTextChars, buildRequest, INSTRUCTIONS, MULTI_INSTRUCTIONS, classifyProviderError } from '../netlify/lib/openai.mjs';
import { createHandler } from '../netlify/lib/handler.mjs';

const run = async (c, req) => H.j(await c.handle(req, { ip: '198.51.100.7' }));
const codeOf = (r) => r.body.detail && r.body.detail.code;
const b64 = (n) => H.jpegB64(n);
const A = b64('p10-view-a.jpg'), B = b64('p10-view-b.jpg'), C = b64('p10-view-c.jpg');
const img = (imageBase64, label) => ({ imageBase64, mimeType: 'image/jpeg', ...(label ? { label } : {}) });
const multi = (images, over = {}) => H.analyzeReq({ body: JSON.stringify({ images, description: '', consent: true, requestId: 'req-' + Math.random().toString(36).slice(2, 10), ...over }) });
const ledger = (c) => (c.store.m.get('ledger/v1') || { data: null }).data;
// A JPEG padded with COM segments (dropped by the server's strip, but counted in the raw/encoded size checks).
function padded(baseB64, extraBytes) {
  const b = Buffer.from(baseB64, 'base64'); const parts = [b.subarray(0, 2)]; let left = extraBytes;
  while (left > 0) { const n = Math.min(65000, left); const seg = Buffer.alloc(4 + n, 0x41); seg[0] = 0xFF; seg[1] = 0xFE; seg.writeUInt16BE(n + 2, 2); parts.push(seg); left -= n; }
  parts.push(b.subarray(2)); return Buffer.concat(parts).toString('base64');
}
// Same JPEG with its SOF width/height rewritten (the server walks markers; it never decodes pixels).
function withDims(baseB64, w, hgt) {
  const b = Buffer.from(baseB64, 'base64');
  for (let i = 2; i < b.length - 9;) {
    if (b[i] !== 0xFF) break; const m = b[i + 1]; const len = b.readUInt16BE(i + 2);
    if (m === 0xC0 || m === 0xC2) { b.writeUInt16BE(hgt, i + 5); b.writeUInt16BE(w, i + 7); return b.toString('base64'); }
    i += 2 + len;
  }
  throw new Error('no SOF');
}

describe('P10 multi-photo: shape, labels, one request, one component list', () => {
  it('2 photos -> ONE provider call with 2 labelled images, the multi-photo rules, store:false; result is one list', async () => {
    const c = H.setup();
    const r = await run(c, multi([img(A, 'BEFORE'), img(B, 'AFTER')], { description: 'butter chicken' }));
    assert.equal(r.status, 200); assert.equal(c.fetchStub.calls.length, 1);
    const body = c.fetchStub.calls[0].body;
    const content = body.input[0].content;
    assert.equal(content.filter((x) => x.type === 'input_image').length, 2);
    assert.deepEqual(content.map((x) => x.type), ['input_text', 'input_text', 'input_image', 'input_text', 'input_image']);
    assert.match(content[1].text, /Photo 1 of 2: before eating/); assert.match(content[3].text, /Photo 2 of 2: after eating/);
    assert.ok(body.instructions.includes(MULTI_INSTRUCTIONS)); assert.ok(body.instructions.startsWith(INSTRUCTIONS));
    assert.equal(body.store, false); assert.equal(body.text.format.strict, true);
    assert.ok(Array.isArray(r.body.items)); assert.equal(ledger(c).day.calls, 1);
  });
  it('3 photos are accepted as one call; 4 photos are refused before any provider call or ledger write', async () => {
    const c = H.setup();
    assert.equal((await run(c, multi([img(A), img(B), img(C)]))).status, 200);
    assert.equal(c.fetchStub.calls.length, 1);
    const before = JSON.stringify(ledger(c));
    const r4 = await run(c, multi([img(A), img(B), img(C), img(H.jpegB64())]));
    assert.equal(r4.status, 400); assert.equal(codeOf(r4), 'TOO_MANY_IMAGES');
    assert.equal(c.fetchStub.calls.length, 1); assert.equal(JSON.stringify(ledger(c)), before);
  });
  it('the single-photo P9 request shape is unchanged (content = [text, image]) and still works', async () => {
    const c = H.setup();
    const r = await run(c, H.analyzeReq());
    assert.equal(r.status, 200);
    const content = c.fetchStub.calls[0].body.input[0].content;
    assert.deepEqual(content.map((x) => x.type), ['input_text', 'input_image']);
    assert.equal(c.fetchStub.calls[0].body.instructions, INSTRUCTIONS);
  });
  it('a list with one photo is the single-photo request', async () => {
    const c = H.setup();
    assert.equal((await run(c, multi([img(A)]))).status, 200);
    assert.deepEqual(c.fetchStub.calls[0].body.input[0].content.map((x) => x.type), ['input_text', 'input_image']);
  });
  it('served-portion basis and no-overlap rule are in the instructions; eaten amounts are never asked of the model', () => {
    assert.match(INSTRUCTIONS, /whole portion as served/); assert.match(INSTRUCTIONS, /must not overlap/); assert.match(INSTRUCTIONS, /Do not guess how much of the meal was eaten/);
    assert.match(MULTI_INSTRUCTIONS, /count each food once, never once per photo/); assert.match(MULTI_INSTRUCTIONS, /never add it as more food/);
  });
  it('refused before any call: both shapes at once, empty list, unknown or free-text label, extra keys, non-JPEG, malformed photo 2', async () => {
    const c = H.setup();
    const cases = [
      [H.analyzeReq({ body: JSON.stringify({ images: [img(A)], imageBase64: A, mimeType: 'image/jpeg', consent: true, requestId: 'req-both' }) }), 'BAD_REQUEST'],
      [multi([]), 'BAD_REQUEST'],
      [multi([img(A, 'PLATE OF MY BOSS')]), 'BAD_REQUEST'],
      [multi([{ ...img(A), note: 'x' }]), 'BAD_REQUEST'],
      [multi([img(A), { imageBase64: fs.readFileSync(H.FIX('synthetic-food-clean.png')).toString('base64'), mimeType: 'image/jpeg' }]), 'UNSUPPORTED_TYPE'],
      [multi([img(A), img(Buffer.from('hello this is text not an image').toString('base64'))]), 'UNSUPPORTED_TYPE'],
      [multi([img(A), img(A.slice(0, 4000))]), 'CORRUPT_IMAGE'],
      [multi([img(A), img('***not base64***')]), 'BAD_REQUEST'],
    ];
    for (const [req, code] of cases) {
      const r = await run(c, req);
      assert.equal(codeOf(r), code, JSON.stringify(r.body));
    }
    const r = await run(c, multi([img(A), img(A.slice(0, 4000))]));
    assert.match(r.body.detail.message, /^Photo 2:/);
    assert.equal(c.fetchStub.calls.length, 0); assert.equal(ledger(c), null);
  });
  it('the same photo twice in one set is refused (same-plate duplication), no call', async () => {
    const c = H.setup();
    const r = await run(c, multi([img(A), img(A, 'BEFORE')]));
    assert.equal(r.status, 400); assert.equal(codeOf(r), 'DUPLICATE_IMAGE'); assert.equal(c.fetchStub.calls.length, 0);
  });
  it('every photo is stripped of EXIF/GPS/comments before OpenAI sees it (per-photo privacy)', async () => {
    const c = H.setup();
    const exif = fs.readFileSync(H.FIX('synthetic-food-exif.jpg')).toString('base64');
    const r = await run(c, multi([img(A), img(exif, 'SAME_PLATE'), img(padded(C, 2000))]));
    assert.equal(r.status, 200);
    const imgs = c.fetchStub.calls[0].body.input[0].content.filter((x) => x.type === 'input_image').map((x) => Buffer.from(x.image_url.split(',')[1], 'base64'));
    assert.equal(imgs.length, 3);
    for (const im of imgs) {
      for (const s of ['Exif', 'SyntheticCam', 'synthetic fixture comment', 'AAAAAAAAAAAAAAAA']) assert.equal(im.includes(Buffer.from(s)), false, s);
      assert.equal(im[0], 0xFF); assert.equal(im[im.length - 1], 0xD9);
    }
    assert.equal(c.logs.join('\n').includes(A.slice(0, 64)), false);
  });
});

describe('P10 multi-photo size, resolution and cost bounds (body limit NOT raised)', () => {
  it('config keeps the P9 body and image limits; multi limits fit inside them', () => {
    const cfg = readConfig(H.BASE_ENV).config;
    assert.equal(cfg.maxBodyBytes, 2_400_000); assert.equal(cfg.maxImageBytes, 1_650_000);
    assert.equal(cfg.maxImages, 3); assert.equal(cfg.maxMultiTotalBytes, cfg.maxImageBytes);
    assert.ok(Math.ceil(cfg.maxMultiTotalBytes / 3) * 4 + 4096 < cfg.maxBodyBytes); // encoded set + JSON fits the body cap
    assert.ok(cfg.maxBodyBytes < 6_000_000); // Netlify buffered payload limit (6 MB)
    assert.deepEqual(IMAGE_LABELS, ['SAME_PLATE', 'BEFORE', 'AFTER', 'EXTRA_DISH']);
  });
  it('one photo over 600 KB in a multi request -> 413, no call', async () => {
    const c = H.setup();
    const r = await run(c, multi([img(A), img(padded(B, 620_000))]));
    assert.equal(r.status, 413); assert.equal(codeOf(r), 'TOO_LARGE'); assert.equal(c.fetchStub.calls.length, 0);
  });
  it('three photos that together exceed the 1.65 MB set budget -> 413 before decoding, no call', async () => {
    const c = H.setup();
    const r = await run(c, multi([img(padded(A, 580_000)), img(padded(B, 580_000)), img(padded(C, 580_000))]));
    assert.equal(r.status, 413); assert.equal(codeOf(r), 'TOO_LARGE'); assert.equal(c.fetchStub.calls.length, 0);
  });
  it('a body over 2.4 MB is still refused as before', async () => {
    const c = H.setup();
    const r = await run(c, multi([img(padded(A, 900_000)), img(padded(B, 900_000)), img(padded(C, 900_000))]));
    assert.equal(r.status, 413); assert.equal(c.fetchStub.calls.length, 0);
  });
  it('a photo larger than 1600 px in a multi request -> 413, no call; the real 1700 px fixture too', async () => {
    const c = H.setup();
    let r = await run(c, multi([img(A), img(withDims(B, 2400, 1800))]));
    assert.equal(r.status, 413); assert.equal(c.fetchStub.calls.length, 0);
    r = await run(c, multi([img(A), img(b64('p10-over-1600.jpg'))]));
    assert.equal(r.status, 413); assert.equal(c.fetchStub.calls.length, 0);
  });
  it('worst case for 3 photos at the 1600 px cap, max note and max output stays under the $0.004 reservation', () => {
    const cfg = readConfig(H.BASE_ENV).config;
    const ims = [1, 2, 3].map(() => ({ width: 1600, height: 1600 }));
    assert.equal(imageTokenBound(1600, 1600), Math.ceil(50 * 50 * TOKEN_BOUND.patchMultiplier)); // 6250
    const photos = ims.map(() => ({ b64: '', label: 'EXTRA_DISH' }));
    const chars = requestTextChars(cfg, photos, 'x'.repeat(500));
    const worst = worstCaseUsd(cfg, ims, chars);
    assert.ok(chars < 6000, String(chars));
    assert.ok(worst <= cfg.reserveUsd, String(worst));
    assert.ok(worst > 0.003, String(worst)); // the bound is not trivially small: 3 x 6250 image tokens + text + 3000 output
  });
  // Claude P10 review (owner decision 17 Nov 2026): the cost bound now applies to single photos too, so the last line expects 413 (was 200).
  it('if a price override makes the worst case exceed the reservation, a multi request is refused before any call; a single photo is refused too', async () => {
    const c = H.setup({ env: { HYROX_PRICE_IN_PER_M: '1.00', HYROX_PRICE_OUT_PER_M: '5.00' } });
    const r = await run(c, multi([img(A), img(B)]));
    assert.equal(r.status, 413); assert.match(r.body.detail.message, /cost limit/); assert.equal(c.fetchStub.calls.length, 0); assert.equal(ledger(c), null);
    assert.ok(c.logs.some((l) => l.includes('analyze_cost_bound')));
    const s = await run(c, H.analyzeReq());
    assert.equal(s.status, 413); assert.match(s.body.detail.message, /HYROX_RESERVE_USD/); assert.equal(c.fetchStub.calls.length, 0); assert.equal(ledger(c), null);
  });
});

describe('P10 ordered idempotency and concurrency', () => {
  it('same id + same ordered set + same note -> replay, 1 provider call', async () => {
    const c = H.setup();
    const a = await run(c, multi([img(A), img(B, 'AFTER')], { requestId: 'req-set-1', description: 'curry' }));
    const b = await c.handle(multi([img(A), img(B, 'AFTER')], { requestId: 'req-set-1', description: 'curry' }), { ip: '198.51.100.7' });
    assert.equal(a.status, 200); assert.equal(b.status, 200); assert.equal(b.headers.get('X-Hyrox-Replay'), 'true');
    assert.equal(c.fetchStub.calls.length, 1); assert.equal(ledger(c).day.calls, 1);
  });
  it('same id with photos reordered, a label changed or the note changed -> 409, never a second call', async () => {
    const c = H.setup();
    assert.equal((await run(c, multi([img(A), img(B)], { requestId: 'req-set-2', description: 'x' }))).status, 200);
    for (const req of [multi([img(B), img(A)], { requestId: 'req-set-2', description: 'x' }), multi([img(A), img(B, 'AFTER')], { requestId: 'req-set-2', description: 'x' }),
      multi([img(A), img(B)], { requestId: 'req-set-2', description: 'y' })]) {
      const r = await run(c, req); assert.equal(r.status, 409); assert.equal(codeOf(r), 'BAD_REQUEST');
    }
    assert.equal(c.fetchStub.calls.length, 1);
  });
  it('a single-photo request id also covers the note: same photo, other note, same id -> 409', async () => {
    const c = H.setup();
    assert.equal((await run(c, H.analyzeReq({ bodyObj: { requestId: 'req-one-1', description: 'a' } }))).status, 200);
    assert.equal((await run(c, H.analyzeReq({ bodyObj: { requestId: 'req-one-1', description: 'b' } }))).status, 409);
    assert.equal(c.fetchStub.calls.length, 1);
  });
  it('5 simultaneous identical multi-photo taps -> exactly 1 provider call; others replay or are told it is in flight', async () => {
    let release; const gate = new Promise((r) => { release = r; });
    const c = H.setup({ script: async () => { await gate; return H.openaiOk(); } });
    const reqs = [1, 2, 3, 4, 5].map(() => c.handle(multi([img(A), img(B), img(C)], { requestId: 'req-tap' }), { ip: '198.51.100.7' }));
    await new Promise((r) => setTimeout(r, 50)); release();
    const res = await Promise.all(reqs);
    assert.equal(c.fetchStub.calls.length, 1);
    assert.equal(res.filter((r) => r.status === 200).length >= 1, true);
    assert.ok(res.every((r) => r.status === 200 || r.status === 409));
    assert.equal(ledger(c).day.calls, 1);
  });
  it('5 rapid multi-photo requests with different ids -> 1 call (minimum gap and in-flight reservation)', async () => {
    const c = H.setup({ env: { HYROX_MIN_GAP_SECONDS: '4' } });
    const res = await Promise.all([1, 2, 3, 4, 5].map((i) => c.handle(multi([img(A), img(B)], { requestId: 'req-diff-' + i }), { ip: '198.51.100.7' })));
    assert.equal(c.fetchStub.calls.length, 1);
    assert.equal(res.filter((r) => r.status === 429).length, 4);
  });
});

describe('P10 caps, missing usage, storage outage (multi-photo requests)', () => {
  it('a 3-photo request counts as ONE call; the 21st call of the day is refused before sending (20/day unchanged)', async () => {
    const c = H.setup();
    for (let i = 0; i < 20; i++) { c.clock.t += 11 * 60 * 1000; assert.equal((await run(c, multi([img(A), img(B), img(C)], { requestId: 'req-cap-' + i }))).status, 200); } // past the 10-min burst window
    assert.equal(ledger(c).day.calls, 20);
    c.clock.t += 11 * 60 * 1000;
    const r = await run(c, multi([img(A), img(B), img(C)], { requestId: 'req-cap-21' }));
    assert.equal(r.status, 429); assert.equal(codeOf(r), 'QUOTA_EXHAUSTED'); assert.equal(c.fetchStub.calls.length, 20);
  });
  it('caps are unchanged: $5 total, $3 a month, 20 a day, 300 a month, reserve $0.004', () => {
    const cfg = readConfig(H.BASE_ENV).config;
    assert.deepEqual([cfg.totalUsd, cfg.monthlyUsd, cfg.dailyCalls, cfg.monthlyCalls, cfg.reserveUsd], [5, 3, 20, 300, 0.004]);
  });
  it('month spend at $2.997 -> a multi-photo request is refused before any call', async () => {
    const c = H.setup();
    await run(c, H.analyzeReq()); // creates the ledger
    const led = c.store.m.get('ledger/v1'); led.data.month.usd = 2.997; led.data.total.usd = 2.997;
    const r = await run(c, multi([img(A), img(B)]));
    assert.equal(r.status, 402); assert.equal(codeOf(r), 'BUDGET_EXHAUSTED'); assert.equal(c.fetchStub.calls.length, 1);
  });
  it('a successful multi-photo answer WITHOUT a usage figure is charged the reservation (Claude P9 fix kept)', async () => {
    const c = H.setup({ script: () => H.openaiOk(undefined, null) });
    const r = await run(c, multi([img(A), img(B)]));
    assert.equal(r.status, 200); assert.equal(ledger(c).total.usd, 0.004); assert.deepEqual(ledger(c).inflight, {});
  });
  it('with usage, the real cost is recorded (3 photos, 7,000 in / 900 out = $0.00115)', async () => {
    const c = H.setup({ script: () => H.openaiOk(undefined, { input_tokens: 7000, output_tokens: 900 }) });
    assert.equal((await run(c, multi([img(A), img(B), img(C)]))).status, 200);
    assert.equal(ledger(c).total.usd, 0.00115);
  });
  it('storage outage -> 503 STORAGE_UNAVAILABLE, nothing sent (multi)', async () => {
    const st = H.memStore(); st.down = true;
    const c = H.setup({ store: st });
    const r = await run(c, multi([img(A), img(B)]));
    assert.equal(r.status, 503); assert.equal(codeOf(r), 'STORAGE_UNAVAILABLE'); assert.equal(c.fetchStub.calls.length, 0);
  });
});

describe('P10 provider error categories (allowlisted, sanitized, with provider request id)', () => {
  function withHeaders(status, body, rid) {
    const f = async (url, init) => { f.calls.push(1); return new Response(JSON.stringify(body), { status, headers: rid === undefined ? {} : { 'x-request-id': rid } }); };
    f.calls = []; return f;
  }
  async function call(status, body, rid = 'req_abc123XYZ') {
    const st = H.memStore(); const logs = [];
    const f = withHeaders(status, body, rid);
    const h = createHandler({ env: { ...H.BASE_ENV }, fetch: f, getStore: () => st, now: () => Date.UTC(2026, 10, 16, 6), log: (s) => logs.push(s) });
    const res = await H.j(await h(multi([img(A), img(B)], { description: 'my secret lunch note' }), { ip: '1.2.3.4' }));
    return { res, logs, st };
  }
  const SECRET = 'PROVIDER-SECRET-TEXT sk-live-0123456789abcdef';
  for (const [name, status, body, code, category, httpOut] of [
    ['missing/invalid key', 401, { error: { message: SECRET, type: 'invalid_request_error', code: 'invalid_api_key' } }, 'PROVIDER_ERROR', 'KEY_INVALID', 502],
    ['permission', 403, { error: { message: SECRET, type: 'permission_error', code: null } }, 'PROVIDER_ERROR', 'MODEL_ACCESS', 502],
    ['model access', 404, { error: { message: SECRET, type: 'invalid_request_error', code: 'model_not_found' } }, 'PROVIDER_ERROR', 'MODEL_ACCESS', 502],
    ['rejected schema', 400, { error: { message: SECRET, type: 'invalid_request_error', code: 'invalid_json_schema', param: 'text.format.schema' } }, 'PROVIDER_ERROR', 'SCHEMA_REJECTED', 502],
    ['rejected request (image)', 400, { error: { message: SECRET, type: 'invalid_request_error', code: 'invalid_image' } }, 'PROVIDER_ERROR', 'REQUEST_REJECTED', 502],
    ['quota', 429, { error: { message: SECRET, type: 'insufficient_quota', code: 'insufficient_quota' } }, 'BUDGET_EXHAUSTED', 'QUOTA', 402],
    ['rate limit', 429, { error: { message: SECRET, type: 'rate_limit_error', code: 'rate_limit_exceeded' } }, 'RATE_LIMIT', 'RATE_LIMITED', 429],
    ['provider down', 503, { error: { message: SECRET, type: 'server_error' } }, 'PROVIDER_ERROR', 'PROVIDER_DOWN', 502],
  ]) it(`${name}: ${httpOut} ${code} / ${category}, request id kept, no provider text, not billed`, async () => {
    const { res, logs, st } = await call(status, body);
    assert.equal(res.status, httpOut); assert.equal(res.body.detail.code, code); assert.equal(res.body.detail.category, category);
    assert.equal(res.body.detail.providerStatus, status); assert.equal(res.body.detail.providerRequestId, 'req_abc123XYZ');
    assert.deepEqual(Object.keys(res.body.detail).sort().filter((k) => !['code', 'message', 'category', 'providerStatus', 'providerCode', 'providerRequestId'].includes(k)), []);
    const all = JSON.stringify(res.body) + logs.join('\n');
    for (const bad of ['PROVIDER-SECRET', 'sk-live', H.FAKE_KEY, H.OWNER_CODE, 'my secret lunch note', A.slice(0, 60)]) assert.equal(all.includes(bad), false, bad);
    assert.ok(logs.some((l) => l.includes('"category":"' + category + '"') && l.includes('req_abc123XYZ')));
    const led = st.m.get('ledger/v1').data; assert.equal(led.total.usd, 0); assert.equal(led.day.calls, 0);
  });
  it('an unknown provider error code is reported as "other", never echoed', () => {
    const d = classifyProviderError(400, { error: { code: 'weird_<script>', type: 'odd type', message: 'x' } });
    assert.equal(d.providerCode, 'other'); assert.equal(d.providerType, 'other'); assert.equal(d.category, 'REQUEST_REJECTED');
  });
  it('a request id that is not a plain token is dropped', async () => {
    const { res } = await call(500, { error: {} }, 'req_<img src=x>');
    assert.equal(res.body.detail.providerRequestId, undefined);
  });
  it('network failure -> NETWORK, timeout -> TIMEOUT (charged as before)', async () => {
    const st = H.memStore();
    const h = createHandler({ env: { ...H.BASE_ENV }, fetch: async () => { throw new TypeError('fetch failed'); }, getStore: () => st, now: () => Date.UTC(2026, 10, 16, 6), log: () => {} });
    let r = await H.j(await h(multi([img(A), img(B)]), { ip: '1.2.3.4' }));
    assert.equal(r.status, 502); assert.equal(r.body.detail.category, 'NETWORK');
    const c = H.setup({ env: { HYROX_PROVIDER_TIMEOUT_MS: '1000' }, script: () => 'hang' });
    r = await run(c, multi([img(A), img(B)]));
    assert.equal(r.status, 504); assert.equal(r.body.detail.category, 'TIMEOUT'); assert.equal(ledger(c).total.usd, 0.004);
  });
  it('invalid model output -> INVALID_OUTPUT category; success responses carry no diagnostics', async () => {
    let c = H.setup({ script: () => H.openaiOk('not json') });
    let r = await run(c, multi([img(A), img(B)]));
    assert.equal(r.status, 502); assert.equal(r.body.detail.category, 'INVALID_OUTPUT');
    c = H.setup();
    r = await run(c, multi([img(A), img(B)]));
    assert.deepEqual(Object.keys(r.body).sort(), ['items', 'model', 'provider', 'schemaVersion', 'warnings']);
  });
  it('no new endpoint: anything but /status (GET) and /analyze (POST) is still refused', async () => {
    const c = H.setup();
    const r = await H.j(await c.handle(new Request('https://hyrox.test/api/food-photo/diagnostics', { method: 'PUT' }), { ip: '1.1.1.1' }));
    assert.equal(r.status, 405);
  });
});
