'use strict';
// Phase 11: the optional meal field `mealCategory` needs NO data-layer change. The validator keeps unknown record fields, so a
// categorised meal (and an unrecognised value) is stored, exported and restored exactly, and older data layers (Claude P10b,
// P9, P8, P7 — the rollback targets) restore a Phase 11 backup with the field intact. Records without it stay valid.
// Older source trees are read-only; those checks are SKIPPED (visibly) when absent.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const HERE = path.resolve(__dirname, '..', 'src');
const NOW = new Date('2026-11-19T09:00:00Z');
const mem = () => { const m = {}; return { m, getItem: (k) => (k in m ? m[k] : null), setItem(k, v) { m[k] = String(v); }, removeItem(k) { delete m[k]; } }; };
const sha = (f) => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
const byLabel = (list) => list.slice().sort((a, b) => (a[0] < b[0] ? -1 : 1)); // older layers list newest first
const unk = () => ({ value: null, state: 'UNKNOWN' });
const meal = (label, cat, kcal) => {
  const m = { date: '2026-11-19', time: '12:00', label, source: 'MANUAL', description: '', eatenFraction: 1, lifecycle: 'CONFIRMED', confirmedAt: NOW.toISOString(), ai: null,
    components: [{ name: label + ' item', role: 'MAIN', portion: '', preparation: '', eatenFraction: null, kcal: { value: kcal, state: 'KNOWN' }, proteinG: unk(), carbsG: unk(), fatG: unk() }] };
  if (cat !== undefined) m.mealCategory = cat;
  return m;
};

// Claude P10b (34bdf3d) data layer, byte for byte: Phase 11 changes no file under src/data.
const P10B_DATA = {
  'food-db.js': '312e75c5b5fb6703e323a5311e7d04b937e306805f177c7d3c42df8f809f4279',
  'hyrox-data.js': '35fe4ac633b40d69871b79ef652089acb46aed69653248a3da61811b44022870', /* RE-POINTED t112b (24 Nov 2026): t112b Dawit R4-D1/D2 + Meron R4-D1–D8 / O-1. No version bump, no new storage key. */
  'hyrox-foodcalc.js': 'c15605f0af39d82432e9ada6599dde01dba9c00511c2ae3b31a30366a0715f6c',
  'hyrox-nutrition.js': 'f3da951f134fb805e126d34ef9e3eb3aa22514e195a423cec4876045e6055064',
  'hyrox-plan.js': '77a3694274dc207c851626f4bb03e71cbc651d10a5da6fe590e13f51a800ac05',
  'hyrox-wellness.js': 'b962208da03e4d259791104ef671f3b3902ef40a48bca8e7aa8386976c2c7b84',
};
test('Phase 11 leaves the data layer byte-identical to Claude P10b 34bdf3d', () => {
  for (const [f, h] of Object.entries(P10B_DATA)) assert.equal(sha(path.join(HERE, 'data', f)), h, f);
});

function makeExport(HD) {
  const st = HD.createStore(mem(), { now: () => NOW });
  for (const m of [meal('B1', 'BREAKFAST', 300), meal('L1', 'LUNCH', 400), meal('Odd', 'BRUNCH', 120), meal('Old', undefined, 90)]) {
    const r = st.putRecord('meals', m); assert.equal(r.ok, true, JSON.stringify(r.errors));
  }
  return st;
}
test('current data layer: categories (and an unrecognised value) are stored, exported and restored exactly; no category stays valid', () => {
  const HD = require(path.join(HERE, 'data', 'hyrox-data.js'));
  const st = makeExport(HD);
  assert.deepEqual(byLabel(st.records('meals').map((m) => [m.label, m.mealCategory])), [['B1', 'BREAKFAST'], ['L1', 'LUNCH'], ['Odd', 'BRUNCH'], ['Old', undefined]]);
  const text = st.exportJSON();
  const storage = mem(), st2 = HD.createStore(storage, { now: () => NOW });
  const p = st2.previewImport(text); assert.equal(p.ok, true, JSON.stringify(p.errors || p.message));
  const r = st2.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt }); assert.equal(r.ok, true, JSON.stringify(r));
  const back = HD.createStore(storage, { now: () => NOW }).records('meals');
  assert.deepEqual(byLabel(back.map((m) => [m.label, m.mealCategory])), [['B1', 'BREAKFAST'], ['L1', 'LUNCH'], ['Odd', 'BRUNCH'], ['Old', undefined]]);
  // a category never changes the nutrition totals
  const HN = require(path.join(HERE, 'data', 'hyrox-nutrition.js'));
  const a = HN.dayState('2026-11-19', back, null).subtotal.kcal.value;
  const stripped = back.map((m) => { const c = JSON.parse(JSON.stringify(m)); delete c.mealCategory; return c; });
  assert.equal(a, 910); assert.equal(HN.dayState('2026-11-19', stripped, null).subtotal.kcal.value, a);
});

const OLD = {
  'claude-p10b': process.env.P11_P10B_SRC || '/workspace/hyrox-p11-before/src',
  p9: process.env.P11_P9_SRC || '/workspace/hyrox-p9/src',
  p8: process.env.P9_P8_SRC || '/workspace/hyrox-p8/src',
  p7: process.env.P9_P7_SRC || '/workspace/hyrox-p7/repo/src',
};
for (const [name, dir] of Object.entries(OLD)) {
  const present = fs.existsSync(path.join(dir, 'data', 'hyrox-data.js'));
  (present ? test : test.skip)(`rollback: the ${name} data layer restores a Phase 11 backup with mealCategory intact and exports it again`, () => {
    const text = makeExport(require(path.join(HERE, 'data', 'hyrox-data.js'))).exportJSON();
    const HD = require(path.join(dir, 'data', 'hyrox-data.js'));
    const storage = mem(), st = HD.createStore(storage, { now: () => NOW });
    const p = st.previewImport(text); assert.equal(p.ok, true, JSON.stringify(p.errors || p.message));
    const r = st.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt }); assert.equal(r.ok, true, JSON.stringify(r));
    const st2 = HD.createStore(storage, { now: () => NOW });
    assert.deepEqual(byLabel(st2.records('meals').map((m) => [m.label, m.mealCategory])), [['B1', 'BREAKFAST'], ['L1', 'LUNCH'], ['Odd', 'BRUNCH'], ['Old', undefined]]);
    assert.deepEqual(byLabel(JSON.parse(st2.exportJSON()).meals.map((m) => [m.label, m.mealCategory])), [['B1', 'BREAKFAST'], ['L1', 'LUNCH'], ['Odd', 'BRUNCH'], ['Old', undefined]]);
  });
}
