'use strict';
// Phase 8 P1: "Moderate" session effort between Easy and Demanding. Additive enum value; scheduling stays conservative.
// Synthetic data only. In-memory storage.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const HD = require(path.resolve(__dirname, '../src/data/hyrox-data.js'));
const HP = require(path.resolve(__dirname, '../src/data/hyrox-plan.js'));

const NOW = new Date('2026-11-20T09:00:00Z');
const mem = (init) => { const m = Object.assign({}, init || {}); return { m, getItem(k) { return Object.prototype.hasOwnProperty.call(m, k) ? m[k] : null; }, setItem(k, v) { m[k] = String(v); }, removeItem(k) { delete m[k]; } }; };
const mk = (s) => HD.createStore(s || mem(), { now: () => NOW });
const sess = (over) => Object.assign({ date: '2026-11-18', status: 'COMPLETED', modified: false, variant: 'NONE', blocks: [], title: 'Synthetic jog', rpe: 5, planSlotId: null }, over);

describe('P8 Moderate: stored enum and validation', () => {
  it('EASY, MODERATE and DEMANDING are valid; anything else is refused and nothing is written', () => {
    ['EASY', 'MODERATE', 'DEMANDING'].forEach((i) => assert.equal(mk().putRecord('sessions', sess({ intensity: i })).ok, true, i));
    ['MEDIUM', 'moderate', '', 5].forEach((i) => {
      const s = mem(), st = mk(s); const r = st.putRecord('sessions', sess({ intensity: i }));
      assert.equal(r.ok, false, String(i)); assert.equal(s.m['hyrox.v1'], undefined);
    });
    assert.equal(mk().putRecord('sessions', sess({})).ok, true, 'intensity stays optional');
    assert.deepEqual(HD.ENUMS ? HD.ENUMS.intensity : ['EASY', 'MODERATE', 'DEMANDING'], ['EASY', 'MODERATE', 'DEMANDING']);
  });
  it('the numeric RPE field is independent of the effort label (Moderate with RPE 3 or 9 is stored as entered)', () => {
    const st = mk();
    assert.equal(st.putRecord('sessions', sess({ id: 'a', intensity: 'MODERATE', rpe: 3 })).ok, true);
    assert.equal(st.putRecord('sessions', sess({ id: 'b', intensity: 'MODERATE', rpe: 9 })).ok, true);
    assert.deepEqual(st.records('sessions').map((x) => [x.id, x.rpe, x.intensity]).sort(), [['a', 3, 'MODERATE'], ['b', 9, 'MODERATE']]);
  });
  it('export and restore keep MODERATE exactly; older backups with EASY / DEMANDING / no value still import', () => {
    const st = mk();
    st.putRecord('sessions', sess({ id: 'm', intensity: 'MODERATE' })); st.putRecord('sessions', sess({ id: 'e', intensity: 'EASY', date: '2026-11-17' })); st.putRecord('sessions', sess({ id: 'n', date: '2026-11-16' }));
    const text = st.exportJSON();
    const t = mk(); const p = t.previewImport(text); assert.equal(p.ok, true, JSON.stringify(p));
    assert.equal(t.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt }).ok, true);
    assert.deepEqual(t.records('sessions').map((x) => [x.id, x.intensity || null]).sort(), [['e', 'EASY'], ['m', 'MODERATE'], ['n', null]]);
  });
});

describe('P8 Moderate: scheduling stays conservative', () => {
  it('a Moderate session counts as hard: only EASY (or low-RPE walking) is exempt from "never stack"', () => {
    assert.equal(HP.isDemandingSession(sess({ intensity: 'MODERATE' })), true);
    assert.equal(HP.isDemandingSession(sess({ intensity: 'MODERATE', rpe: 2 })), true, 'a low RPE number does not override the owner\'s Moderate label');
    assert.equal(HP.isDemandingSession(sess({ intensity: 'EASY', rpe: 8 })), false, 'Easy unchanged');
    assert.equal(HP.isDemandingSession(sess({ intensity: 'DEMANDING', rpe: 2 })), true, 'Demanding unchanged');
    assert.equal(HP.isDemandingSession(sess({ rpe: null })), true, 'unknown stays demanding');
    assert.equal(HP.isDemandingSession(sess({ planSlotId: 'v2.1-W1-MON', intensity: 'EASY' })), true, 'a programmed gym slot stays demanding');
  });
  it('rescheduleCheck refuses a day that already holds a logged Moderate session; an Easy one is still allowed', () => {
    // Week 2 with a missed Monday leaves Mon 23 Nov free (Mon->Tue, Tue->Thu, Thu omitted); "today" is Sun 22 Nov.
    const events = [{ kind: 'MISSED_MONDAY', week: 2, date: '2026-11-23' }];
    const c1 = HP.rescheduleCheck('v2.1-W1-FRI', '2026-11-23', [sess({ id: 'mod2', date: '2026-11-23', intensity: 'MODERATE' })], events, '2026-11-22');
    assert.equal(c1.ok, false); assert.equal(c1.code, 'DEMANDING_SESSION_LOGGED');
    const c2 = HP.rescheduleCheck('v2.1-W1-FRI', '2026-11-23', [sess({ id: 'easy2', date: '2026-11-23', intensity: 'EASY', rpe: 2 })], events, '2026-11-22');
    assert.equal(c2.ok, true, JSON.stringify(c2));
  });
  it('dayLoad: Moderate + Demanding on one day raises the two-hard-sessions flag; Moderate + Easy does not', () => {
    const d = '2026-11-18';
    const a = HP.dayLoad(d, [sess({ id: '1', date: d, intensity: 'MODERATE' }), sess({ id: '2', date: d, intensity: 'DEMANDING', rpe: 8 })], []);
    assert.equal(a.stackedDemanding, true); assert.equal(a.flag, 'TWO_DEMANDING_SESSIONS_LOGGED');
    const b = HP.dayLoad(d, [sess({ id: '1', date: d, intensity: 'MODERATE' }), sess({ id: '2', date: d, intensity: 'EASY', rpe: 2 })], []);
    assert.equal(b.stackedDemanding, false); assert.equal(b.flag, null);
  });
  it('Moderate changes no plan status, count or cascade (it is only a label on a logged session)', () => {
    const base = [sess({ id: 'x', date: '2026-11-17', planSlotId: 'v2.1-W1-TUE', status: 'COMPLETED', rpe: 6 })];
    const withMod = [Object.assign({}, base[0], { intensity: 'MODERATE' })];
    assert.deepEqual(HP.summary(withMod, []).COMPLETED, HP.summary(base, []).COMPLETED);
    assert.equal(HP.slotStatus('v2.1-W1-TUE', withMod, []).code, 'COMPLETED');
    assert.deepEqual(HP.effectiveWeek(1, []).days.map((x) => x.show.length), [1, 1, 1, 1, 1]);
  });
});
