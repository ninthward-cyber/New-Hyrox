'use strict';
// P5 Meron RED tests for P4-O1: empty backup replacing populated data needs a second
// explicit confirmation. Against baseline df5bb7b these must FAIL for the right reason
// (the guard is missing and/or applyImport with only confirm:REPLACE wipes live data).
// Contract: /workspace/hyrox-p5/CONTRACT.md. Synthetic data only. Does not edit src/.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const {
  HD, TS, KEY, PRE, RECOVERY, ALL,
  mem, mk, backup, emptyBackup, validWeight, storedPopulated,
  plant, livePopulated, applyReplace, zeroAll,
} = require('./p5-meron-helpers.js');

function assertNothingWritten(s, before, res, what) {
  assert.equal(s.snapshot(), before, what + ': storage must be byte-identical (got writes ' + JSON.stringify(s.writes()) + ')');
  if (res) {
    assert.equal(res.ok, false, what + ': expected refusal, got ' + JSON.stringify(res).slice(0, 300));
    assert.equal(res.rolledBack, false, what + ': rolledBack must be false when nothing was written');
    assert.equal(res.backupKey, null, what + ': backupKey must be null when nothing was written');
  }
}

function mustFlag(preview, expectTrue, label) {
  assert.equal(typeof preview.emptyReplacesPopulated, 'boolean',
    label + ': preview.emptyReplacesPopulated must always be a boolean (missing on baseline)');
  assert.equal(preview.emptyReplacesPopulated, expectTrue,
    label + ': emptyReplacesPopulated expected ' + expectTrue + ', got ' + preview.emptyReplacesPopulated);
  assert.ok(preview.replaceSummary && typeof preview.replaceSummary === 'object',
    label + ': preview.replaceSummary must always be present');
  const rs = preview.replaceSummary;
  assert.ok(rs.incoming && rs.current, label + ': replaceSummary needs incoming and current');
  ALL.forEach((k) => {
    assert.equal(typeof rs.incoming[k], 'number', label + ': incoming.' + k);
    assert.equal(typeof rs.current[k], 'number', label + ': current.' + k);
  });
  assert.equal(typeof rs.incoming.total, 'number', label + ': incoming.total');
  assert.equal(typeof rs.current.total, 'number', label + ': current.total');
  assert.ok(['ok', 'empty', 'corrupt'].includes(rs.currentState),
    label + ': currentState ' + rs.currentState);
}

describe('P4-O1 holds that already exist (near-empty / not-a-backup files are not treated as empty backups)', () => {
  it('a backup missing one classic empty-array collection is refused as not_hyrox; nothing is written', () => {
    const { s, st, before } = livePopulated();
    const o = { app: 'hyrox-app', version: 2, exportedAt: TS, weight: [], workouts: [] }; // nutrition missing
    const p = st.previewImport(JSON.stringify(o));
    assert.equal(p.ok, false);
    assert.equal(p.code, 'not_hyrox');
    assert.equal(s.snapshot(), before);
  });

  it('collections given as objects or null are refused as not_hyrox; nothing is written', () => {
    const { s, st, before } = livePopulated();
    for (const bad of [
      backup({ weight: {} }),
      backup({ workouts: null }),
      backup({ nutrition: '[]' }),
    ]) {
      const p = st.previewImport(bad);
      assert.equal(p.ok, false, bad.slice(0, 80));
      assert.equal(p.code, 'not_hyrox');
      assert.equal(s.snapshot(), before);
    }
  });

  it('whitespace-only or non-object entries are invalid_records, not an empty backup; nothing is written', () => {
    const { s, st, before } = livePopulated();
    const text = backup({ weight: ['   ', { id: 'w1', createdAt: TS, date: '2026-11-10', kg: 80 }] });
    const p = st.previewImport(text);
    assert.equal(p.ok, false);
    assert.equal(p.code, 'invalid_records');
    assert.equal(s.snapshot(), before);
  });

  it('a backup with any collection non-empty (including Phase 3 only, or a single weight) is not an empty replace', () => {
    const { s, st, before } = livePopulated();
    const cases = [
      backup({ weight: [validWeight('w-in', 77)] }),
      backup({ walks: [{ id: 'k1', createdAt: TS, date: '2026-11-10', durationMin: 30 }] }),
    ];
    for (const text of cases) {
      const p = st.previewImport(text);
      assert.equal(p.ok, true, JSON.stringify(p).slice(0, 200));
      if (typeof p.preview.emptyReplacesPopulated === 'boolean') {
        assert.equal(p.preview.emptyReplacesPopulated, false);
      }
      const a = st.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt });
      assert.equal(a.ok, true, 'non-empty restore must still work with only confirm:REPLACE: ' + JSON.stringify(a).slice(0, 200));
      // reset for the next case
      plant(s, storedPopulated());
    }
  });

  it('empty backup onto newer-version stored data is still refused as storage_newer; nothing is written', () => {
    const s = mem({ [KEY]: JSON.stringify({ version: 3, weight: [], workouts: [], nutrition: [] }) });
    const st = mk(s);
    const before = s.snapshot();
    const p = st.previewImport(emptyBackup());
    assert.equal(p.ok, false);
    assert.equal(p.code, 'storage_newer');
    const a = applyReplace(st, emptyBackup());
    assert.equal(a.ok, false);
    assert.equal(a.code, 'storage_newer');
    assert.equal(s.snapshot(), before);
  });

  it('preview/apply expectCurrent mismatch is still stale_plan and writes nothing', () => {
    const { s, st, before } = livePopulated();
    const text = backup({ weight: [validWeight('w-in', 77)] });
    const p = st.previewImport(text);
    assert.equal(p.ok, true);
    const a = st.applyImport(text, { confirm: 'REPLACE', expectCurrent: { weight: 0, workouts: 0, nutrition: 0 } });
    assert.equal(a.ok, false);
    assert.equal(a.code, 'stale_plan');
    assert.equal(s.snapshot(), before);
  });
});

describe('P4-O1 characterization (accepted limit): a fully stripped emergency file is not claimed distinguishable from a genuine empty backup', () => {
  it('a hand-forged {app,version,exportedAt,empty lists} file (P4-L1) previews as a genuine empty backup, never as raw_recovery_file', () => {
    const { st } = livePopulated();
    const text = JSON.stringify({ app: 'hyrox-app', version: 2, exportedAt: TS, weight: [], workouts: [], nutrition: [] });
    const p = st.previewImport(text);
    assert.equal(p.ok, true, 'must not claim a stripped emergency file is distinguishable: ' + JSON.stringify(p).slice(0, 300));
    assert.notEqual(p.code, 'raw_recovery_file');
    if (p.preview.counts) {
      assert.deepEqual({ weight: p.preview.counts.weight, workouts: p.preview.counts.workouts, nutrition: p.preview.counts.nutrition },
        { weight: 0, workouts: 0, nutrition: 0 });
    }
  });
});

describe('DEFECT P4-O1: previewImport must flag empty-replaces-populated and provide replaceSummary', () => {
  it('an empty backup onto a populated device previews ok with emptyReplacesPopulated true and current vs incoming counts', () => {
    const { st } = livePopulated();
    const p = st.previewImport(emptyBackup());
    assert.equal(p.ok, true, 'preview of a genuine empty backup must still be ok: ' + JSON.stringify(p).slice(0, 300));
    mustFlag(p.preview, true, 'empty onto populated');
    assert.equal(p.preview.replaceSummary.incoming.total, 0);
    assert.ok(p.preview.replaceSummary.current.total >= 1, 'current.total must count the stored weight');
    assert.equal(p.preview.replaceSummary.current.weight, 1);
    assert.equal(p.preview.replaceSummary.currentState, 'ok');
    // Existing preview fields stay present.
    assert.deepEqual(p.preview.counts, { weight: 0, workouts: 0, nutrition: 0 });
    assert.deepEqual(p.preview.current, { weight: 1, workouts: 0, nutrition: 0 });
  });

  it('partial / Phase 3 counts are reported exactly in replaceSummary (empty classic lists plus a walk is NOT an empty replace)', () => {
    const { st } = livePopulated();
    const text = backup({
      walks: [{ id: 'k1', createdAt: TS, date: '2026-11-10', durationMin: 30 }],
      workouts: [{ id: 'ik2', createdAt: TS, date: '2026-11-10', activity: 'Half', durationMin: 20, partial: true, notes: '' }],
    });
    const p = st.previewImport(text);
    assert.equal(p.ok, true, JSON.stringify(p).slice(0, 200));
    mustFlag(p.preview, false, 'partial / walk backup');
    assert.equal(p.preview.partialCount, 1);
    assert.equal(p.preview.replaceSummary.incoming.workouts, 1);
    assert.equal(p.preview.replaceSummary.incoming.walks, 1);
    assert.ok(p.preview.replaceSummary.incoming.total >= 2);
    assert.equal(p.preview.replaceSummary.current.weight, 1);
  });

  it('empty backup plus unknown top-level fields is still an empty replace (warning only; still flagged)', () => {
    const { st } = livePopulated();
    const p = st.previewImport(emptyBackup({ note: 'hello', extra: 1 }));
    assert.equal(p.ok, true, JSON.stringify(p).slice(0, 200));
    mustFlag(p.preview, true, 'empty plus unknown fields');
    assert.equal(p.preview.replaceSummary.incoming.total, 0);
    assert.ok(Array.isArray(p.preview.warnings) && p.preview.warnings.length >= 1);
  });

  it('empty onto empty is flagged false (no second confirm) and replaceSummary currentState is empty', () => {
    const s = mem();
    const st = mk(s);
    const p = st.previewImport(emptyBackup());
    assert.equal(p.ok, true);
    mustFlag(p.preview, false, 'empty onto empty');
    assert.equal(p.preview.replaceSummary.incoming.total, 0);
    assert.equal(p.preview.replaceSummary.current.total, 0);
    assert.equal(p.preview.replaceSummary.currentState, 'empty');
  });

  it('a damaged stored record still counts as populated, so an empty backup is flagged', () => {
    const s = mem();
    plant(s, { version: 2, weight: [{ id: 'broken', date: '2026-11-10' }], workouts: [], nutrition: [] });
    const st = mk(s);
    const p = st.previewImport(emptyBackup());
    assert.equal(p.ok, true);
    mustFlag(p.preview, true, 'damaged stored record counts as populated');
    assert.ok(p.preview.replaceSummary.current.total >= 1);
    assert.equal(p.preview.replaceSummary.current.weight, 1);
  });

});

describe('DEFECT P4-O1: applyImport of an empty backup onto populated data without confirmEmptyReplace===true must refuse and write nothing', () => {
  it('calling applyImport directly with only confirm:REPLACE (UI guard bypassed) must return empty_replace_not_confirmed and write nothing', () => {
    const { s, st, before, raw } = livePopulated();
    const text = emptyBackup();
    const p = st.previewImport(text);
    assert.equal(p.ok, true);
    const a = st.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt });
    assert.equal(a.ok, false, 'baseline currently wipes live data with only confirm:REPLACE: ' + JSON.stringify(a).slice(0, 300));
    assert.equal(a.code, 'empty_replace_not_confirmed');
    assert.match(String(a.message), /empty|second|confirm/i);
    assert.ok(Array.isArray(a.errors));
    assertNothingWritten(s, before, a, 'REPLACE-only empty apply');
    assert.equal(s.getItem(KEY), raw);
    assert.equal(s.getItem(PRE), null);
  });

  it('truthy-but-wrong second-confirm options (string "true", 1, "YES", {}) are not sufficient; nothing is written', () => {
    const { s, st, before } = livePopulated();
    const text = emptyBackup();
    const p = st.previewImport(text);
    assert.equal(p.ok, true);
    const optsBase = { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt };
    for (const wrong of ['true', 1, 'YES', {}, 'EMPTY', 'REPLACE']) {
      const a = st.applyImport(text, Object.assign({}, optsBase, { confirmEmptyReplace: wrong }));
      assert.equal(a.ok, false, 'confirmEmptyReplace=' + JSON.stringify(wrong) + ' must be refused, got ' + JSON.stringify(a).slice(0, 200));
      assert.equal(a.code, 'empty_replace_not_confirmed');
      assertNothingWritten(s, before, a, 'wrong option ' + JSON.stringify(wrong));
    }
  });

  it('an empty backup plus unknown top-level fields still requires the second confirm (cannot sneak through as a normal restore)', () => {
    const { s, st, before } = livePopulated();
    const a = applyReplace(st, emptyBackup({ leftover: 'x' }));
    assert.equal(a.ok, false, 'baseline currently applies this and wipes: ' + JSON.stringify(a).slice(0, 200));
    assert.equal(a.code, 'empty_replace_not_confirmed');
    assertNothingWritten(s, before, a, 'empty plus extra fields');
  });

  it('the stripped P4-L1 empty file also requires the second confirm (same path as a genuine empty backup; not claimed distinguishable)', () => {
    const { s, st, before } = livePopulated();
    const a = applyReplace(st, JSON.stringify({ app: 'hyrox-app', version: 2, exportedAt: TS, weight: [], workouts: [], nutrition: [] }));
    assert.equal(a.ok, false);
    assert.equal(a.code, 'empty_replace_not_confirmed');
    assertNothingWritten(s, before, a, 'P4-L1 empty file');
  });

  it('double-apply without the second confirm: both attempts refuse and live data stays byte-identical', () => {
    const { s, st, before } = livePopulated();
    const text = emptyBackup();
    const a1 = applyReplace(st, text);
    const a2 = applyReplace(st, text);
    assert.equal(a1.code, 'empty_replace_not_confirmed');
    assert.equal(a2.code, 'empty_replace_not_confirmed');
    assertNothingWritten(s, before, a2, 'second attempt');
  });
});

describe('P4-O1: confirmEmptyReplace === true is the official second confirm (guarded so this is not a false green on the baseline)', () => {
  it('empty backup onto populated data with confirm:REPLACE and confirmEmptyReplace:true restores as today', () => {
    const { s, st, raw } = livePopulated();
    const text = emptyBackup();
    const p = st.previewImport(text);
    assert.equal(p.ok, true);
    const probe = st.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt });
    assert.equal(probe.ok, false,
      'guard missing: confirm:REPLACE alone wiped populated data, so a success-with-confirmEmptyReplace test would be a false green on this baseline');
    assert.equal(probe.code, 'empty_replace_not_confirmed');
    assert.equal(s.getItem(KEY), raw);

    const a = st.applyImport(text, {
      confirm: 'REPLACE',
      expectCurrent: p.preview.current,
      expectCurrentExt: p.preview.currentExt,
      confirmEmptyReplace: true,
    });
    assert.equal(a.ok, true, 'with both confirmations the empty replace must succeed: ' + JSON.stringify(a).slice(0, 300));
    assert.deepEqual(a.counts, { weight: 0, workouts: 0, nutrition: 0 });
    assert.equal(st.list('weight').length, 0);
    const env = JSON.parse(s.getItem(PRE));
    assert.equal(env.kind, 'hyrox-pre-import');
    assert.equal(env.raw, raw);
  });

  it('empty backup onto an already-empty device still restores with only confirm:REPLACE (no second confirm required)', () => {
    const s = mem();
    const st = mk(s);
    const beforeWrites = s.writes().length;
    const a = applyReplace(st, emptyBackup());
    assert.equal(a.ok, true, JSON.stringify(a).slice(0, 200));
    assert.deepEqual(a.counts, { weight: 0, workouts: 0, nutrition: 0 });
    assert.equal(st.list('weight').length, 0);
    assert.ok(st.status().ok === true || st.status().state === 'empty' || st.status().state === 'ok');
  });

  it('confirmEmptyReplace:true is ignored on a normal (non-empty) restore, which still works with confirm:REPLACE', () => {
    const { st } = livePopulated();
    const text = backup({ weight: [validWeight('w-in', 77)] });
    const a = applyReplace(st, text, { confirmEmptyReplace: true });
    assert.equal(a.ok, true, JSON.stringify(a).slice(0, 200));
    assert.equal(st.list('weight')[0].kg, 77);
  });
});

describe('P4-O1 known limit (NOT a defect; Tewodros decision pending): a corrupt-state device is not counted as populated', () => {
  it('unreadable stored text is not flagged as emptyReplacesPopulated; an empty backup may still be applied with only confirm:REPLACE; existing recovery bytes stay', () => {
    const existingRecovery = '{older-corrupt';
    const s = mem({ [KEY]: '{broken', [RECOVERY]: existingRecovery });
    const st = mk(s);
    const p = st.previewImport(emptyBackup());
    assert.equal(p.ok, true, JSON.stringify(p).slice(0, 200));
    if (typeof p.preview.emptyReplacesPopulated === 'boolean') {
      assert.equal(p.preview.emptyReplacesPopulated, false, 'contract FINAL: corrupt is not populated');
      assert.equal(p.preview.replaceSummary.currentState, 'corrupt');
    }
    const a = applyReplace(st, emptyBackup());
    assert.equal(a.ok, true, 'empty onto corrupt without second confirm remains allowed (existing test / pending decision): ' + JSON.stringify(a).slice(0, 200));
    assert.equal(s.getItem(RECOVERY), existingRecovery, 'existing corrupt-backup copy must not be overwritten with different bytes');
  });
});

describe('P4-O1 extra apply-time and shape probes', () => {
  it('a legacy v1 empty backup onto a populated device also requires confirmEmptyReplace', () => {
    const { s, st, before, raw } = livePopulated();
    const v1 = JSON.stringify({ app: 'hyrox-app', version: 1, exportedAt: TS, weight: [], workouts: [], nutrition: [] });
    const p = st.previewImport(v1);
    assert.equal(p.ok, true);
    mustFlag(p.preview, true, 'v1 empty');
    const a = st.applyImport(v1, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt });
    assert.equal(a.ok, false);
    assert.equal(a.code, 'empty_replace_not_confirmed');
    assertNothingWritten(s, before, a, 'v1 empty');
    assert.equal(s.getItem(KEY), raw);
  });

  it('a stored record with no id (not isValidEntry) still counts as populated', () => {
    const s = mem();
    plant(s, { version: 2, weight: [{ date: '2026-11-10', kg: 80 }], workouts: [], nutrition: [] });
    const st = mk(s);
    const before = s.snapshot();
    const p = st.previewImport(emptyBackup());
    assert.equal(p.ok, true);
    mustFlag(p.preview, true, 'no-id stored record');
    assert.ok(p.preview.replaceSummary.current.total >= 1);
    const a = applyReplace(st, emptyBackup());
    assert.equal(a.ok, false);
    assert.equal(a.code, 'empty_replace_not_confirmed');
    assertNothingWritten(s, before, a, 'no-id populated');
  });

  it('a preview taken on an empty device cannot be reused after the device is populated (stale_plan; no wipe)', () => {
    const s = mem();
    const st = mk(s);
    const p = st.previewImport(emptyBackup());
    assert.equal(p.ok, true);
    if (typeof p.preview.emptyReplacesPopulated === 'boolean') {
      assert.equal(p.preview.emptyReplacesPopulated, false);
    }
    plant(s, storedPopulated());
    const a = st.applyImport(emptyBackup(), { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt });
    assert.equal(a.ok, false);
    assert.equal(a.code, 'stale_plan');
    assert.equal(st.list('weight').length, 1);
  });

  it('confirmEmptyReplace:true without confirm:REPLACE is not_confirmed and writes nothing', () => {
    const { s, st, before, raw } = livePopulated();
    const a = st.applyImport(emptyBackup(), { confirmEmptyReplace: true });
    assert.equal(a.ok, false);
    assert.equal(a.code, 'not_confirmed');
    assert.equal(s.getItem(KEY), raw);
    assert.equal(s.snapshot(), before);
  });
});
