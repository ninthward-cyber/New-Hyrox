'use strict';
// P5 Meron RED tests for P4-F02: a second restore must not overwrite the only pre-import
// recovery copy after rollback_failed / while restoreState is 'pending'. Fail closed.
// Against baseline df5bb7b these must FAIL for the right reason (the slot is silently rotated).
// Contract: /workspace/hyrox-p5/CONTRACT.md. Synthetic data only. Does not edit src/.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const {
  HD, TS, KEY, PRE, RECOVERY,
  mem, faultStorage, mk, backup, validWeight, storedPopulated,
  plant, livePopulated, applyReplace, slotRaw,
} = require('./p5-meron-helpers.js');

const OTHER = backup({ weight: [validWeight('w-other', 70, '2026-11-09')] });

function envelope(raw, restoreState, savedAt) {
  const env = { kind: 'hyrox-pre-import', savedAt: savedAt || TS, raw: raw };
  if (restoreState !== undefined) env.restoreState = restoreState;
  return JSON.stringify(env);
}

// Drive applyImport until rollback_failed: first KEY write is torn, the rollback KEY write throws.
function rollbackFailedStorage(init) {
  let keySets = 0;
  return faultStorage(init, {
    set: (k, v, n) => {
      if (k !== KEY) return;
      keySets += 1;
      if (keySets === 1) return 'truncate';
      if (keySets >= 2) return 'throw';
    },
  });
}

describe('P4-F02 holds: first ordinary restore still works; slots that are not the only unresolved copy are not blocked', () => {
  it('the first ordinary restore on a device with no pre-import slot still succeeds and writes a slot', () => {
    const { s, st, raw } = livePopulated();
    const a = applyReplace(st, OTHER);
    assert.equal(a.ok, true, JSON.stringify(a).slice(0, 200));
    assert.equal(st.list('weight')[0].kg, 70);
    const env = slotRaw(s);
    assert.equal(env.kind, 'hyrox-pre-import');
    assert.equal(env.raw, raw);
    // After a verified restore the new slot, if stamped, must be completed (not left pending).
    if (env.restoreState !== undefined) assert.equal(env.restoreState, 'completed');
  });

  it('an older-build slot with no restoreState is treated as completed and does not block the next restore', () => {
    const raw = storedPopulated();
    const s = mem({ [KEY]: raw, [PRE]: envelope(raw) }); // no restoreState
    const st = mk(s);
    const a = applyReplace(st, OTHER);
    assert.equal(a.ok, true, 'older slot must not block: ' + JSON.stringify(a).slice(0, 200));
  });

  it('a slot stamped completed or rolled_back does not block the next restore', () => {
    const raw = storedPopulated();
    for (const state of ['completed', 'rolled_back']) {
      const s = mem({ [KEY]: raw, [PRE]: envelope(raw, state) });
      const st = mk(s);
      const a = applyReplace(st, OTHER);
      assert.equal(a.ok, true, state + ' must not block: ' + JSON.stringify(a).slice(0, 200));
    }
  });

  it('a pending slot whose saved text is byte-identical to live storage does not block (nothing would be lost)', () => {
    const raw = storedPopulated();
    const s = mem({ [KEY]: raw, [PRE]: envelope(raw, 'pending') });
    const st = mk(s);
    const a = applyReplace(st, OTHER);
    assert.equal(a.ok, true, 'identical pending slot must not block: ' + JSON.stringify(a).slice(0, 200));
  });

  it('a pending slot whose saved text is empty/null does not block (nothing to lose)', () => {
    const raw = storedPopulated();
    for (const empty of [null, '']) {
      const s = mem({ [KEY]: raw, [PRE]: envelope(empty, 'pending') });
      const st = mk(s);
      const a = applyReplace(st, OTHER);
      assert.equal(a.ok, true, 'empty pending raw=' + JSON.stringify(empty) + ' must not block: ' + JSON.stringify(a).slice(0, 200));
    }
  });
});

describe('DEFECT P4-F02: a pending / rollback_failed pre-import copy must not be overwritten; fail closed', () => {
  it('after rollback_failed, a second restore is refused as prior_copy_unresolved and the slot stays byte-identical', () => {
    const raw = storedPopulated();
    const s = rollbackFailedStorage({ [KEY]: raw });
    const st = mk(s);
    const first = applyReplace(st, OTHER);
    assert.equal(first.ok, false, 'injected first restore must fail, got ' + JSON.stringify(first).slice(0, 200));
    assert.equal(first.code, 'rollback_failed');
    const slotBefore = s.getItem(PRE);
    assert.equal(typeof slotBefore, 'string', 'rollback_failed must leave a pre-import copy');
    assert.equal(JSON.parse(slotBefore).raw, raw);
    const slotSnap = slotBefore;

    const p2 = st.previewImport(backup({ weight: [validWeight('w-third', 65)] }));
    // Preview may be ok (torn KEY may still classify) or not; apply must not rotate the slot.
    if (p2.ok) {
      assert.ok(p2.preview.priorCopy && p2.preview.priorCopy.blocksRestore === true,
        'preview.priorCopy.blocksRestore must be true after rollback_failed (missing on baseline): ' + JSON.stringify(p2.preview.priorCopy));
      const a2 = st.applyImport(backup({ weight: [validWeight('w-third', 65)] }), {
        confirm: 'REPLACE',
        expectCurrent: p2.preview.current,
        expectCurrentExt: p2.preview.currentExt,
      });
      assert.equal(a2.ok, false, 'second restore must be refused; baseline silently rotates the only copy: ' + JSON.stringify(a2).slice(0, 300));
      assert.equal(a2.code, 'prior_copy_unresolved');
      assert.equal(a2.backupKey, PRE);
      assert.equal(a2.rolledBack, false);
    } else {
      assert.fail('unexpected: preview of a valid backup failed after rollback_failed: ' + JSON.stringify(p2).slice(0, 200));
    }
    assert.equal(s.getItem(PRE), slotSnap, 'the only pre-import copy must stay byte-identical');
  });

  it('a planted pending slot whose raw is NOT the live KEY blocks the next restore and is not overwritten', () => {
    const original = storedPopulated();
    const liveNow = JSON.stringify({ version: 2, weight: [validWeight('w-torn', 1)], workouts: [], nutrition: [] });
    const slot = envelope(original, 'pending');
    const s = mem({ [KEY]: liveNow, [PRE]: slot });
    const st = mk(s);
    const before = s.snapshot();
    const p = st.previewImport(OTHER);
    assert.equal(p.ok, true, JSON.stringify(p).slice(0, 200));
    assert.ok(p.preview.priorCopy && typeof p.preview.priorCopy === 'object',
      'preview.priorCopy must be present when a slot exists (missing on baseline)');
    assert.equal(p.preview.priorCopy.blocksRestore, true);
    assert.equal(p.preview.priorCopy.restoreState, 'pending');
    const stStatus = st.status();
    assert.ok(stStatus.priorCopy && stStatus.priorCopy.blocksNextRestore === true,
      'status().priorCopy.blocksNextRestore must be true (contract FINAL: this is a new top-level field, not importBackup): ' + JSON.stringify(stStatus.priorCopy));
    assert.equal(stStatus.priorCopy.restoreState, 'pending');
    // importBackup shape stays unchanged (key, savedAt, counts only).
    if (stStatus.importBackup) {
      assert.equal(stStatus.importBackup.blocksNextRestore, undefined);
      assert.equal(stStatus.importBackup.restoreState, undefined);
    }

    const a = st.applyImport(OTHER, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt });
    assert.equal(a.ok, false, 'baseline overwrites the pending slot: ' + JSON.stringify(a).slice(0, 300));
    assert.equal(a.code, 'prior_copy_unresolved');
    assert.equal(a.backupKey, PRE);
    assert.equal(a.rolledBack, false);
    assert.ok(Array.isArray(a.errors));
    assert.equal(s.getItem(PRE), slot, 'pending slot must stay byte-identical');
    assert.equal(s.getItem(KEY), liveNow, 'live KEY must be unchanged');
    assert.equal(s.snapshot(), before);
  });

  it('failure injection on a blocked second restore never overwrites the pending slot and never returns ok', () => {
    const original = storedPopulated();
    const liveNow = JSON.stringify({ version: 2, weight: [validWeight('w-torn', 1)], workouts: [], nutrition: [] });
    const slot = envelope(original, 'pending');
    const init = { [KEY]: liveNow, [PRE]: slot };
    const p = mk(mem(init)).previewImport(OTHER);
    assert.equal(p.ok, true);
    const modes = ['throw', 'ignore', 'truncate', 'swap'];
    for (const mode of modes) {
      for (const target of [KEY, PRE, RECOVERY]) {
        const s = faultStorage(init, { set: (k) => (k === target ? mode : undefined) });
        const r = mk(s).applyImport(OTHER, {
          confirm: 'REPLACE',
          expectCurrent: p.preview.current,
          expectCurrentExt: p.preview.currentExt,
        });
        assert.equal(r.ok, false, 'mode=' + mode + ' target=' + target + ' must not succeed: ' + JSON.stringify(r).slice(0, 200));
        assert.equal(s.getItem(PRE), slot, 'mode=' + mode + ' target=' + target + ' rotated the pending slot');
        assert.equal(s.getItem(KEY), liveNow, 'mode=' + mode + ' target=' + target + ' changed KEY');
      }
    }
  });

  it('repeated restore attempts after rollback_failed keep failing closed with the same exact slot bytes', () => {
    const raw = storedPopulated();
    const s = rollbackFailedStorage({ [KEY]: raw });
    const st = mk(s);
    const first = applyReplace(st, OTHER);
    assert.equal(first.code, 'rollback_failed');
    const slotSnap = s.getItem(PRE);
    for (let i = 0; i < 3; i++) {
      const p = st.previewImport(OTHER);
      if (!p.ok) continue;
      const r = st.applyImport(OTHER, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt });
      assert.equal(r.ok, false, 'attempt ' + i + ' must refuse: ' + JSON.stringify(r).slice(0, 200));
      assert.equal(r.code, 'prior_copy_unresolved');
      assert.equal(s.getItem(PRE), slotSnap);
    }
  });
});

describe('P4-F02 preview/status additive fields (always-shaped when a slot exists)', () => {
  it('when there is no slot, preview.priorCopy is null and status() has no priorCopy key', () => {
    const { st } = livePopulated();
    const p = st.previewImport(OTHER);
    assert.equal(p.ok, true);
    if (Object.prototype.hasOwnProperty.call(p.preview, 'priorCopy')) {
      assert.equal(p.preview.priorCopy, null);
    } else {
      assert.fail('preview.priorCopy must be present and null when there is no slot (missing on baseline)');
    }
    const stStatus = st.status();
    assert.equal(Object.prototype.hasOwnProperty.call(stStatus, 'priorCopy'), false,
      'status().priorCopy must be absent when there is no slot (so status() stays byte-identical): keys=' + Object.keys(stStatus).join(','));
  });
});

describe('P4-F02 extra: pending slot vs empty-replace and read faults', () => {
  it('a pending slot also blocks an empty backup that carries both confirmations; the slot stays byte-identical', () => {
    const original = storedPopulated();
    const liveNow = JSON.stringify({ version: 2, weight: [validWeight('w-torn', 1)], workouts: [], nutrition: [] });
    const slot = envelope(original, 'pending');
    const s = mem({ [KEY]: liveNow, [PRE]: slot });
    const st = mk(s);
    const before = s.snapshot();
    const a = applyReplace(st, backup({ weight: [], workouts: [], nutrition: [] }), { confirmEmptyReplace: true });
    assert.equal(a.ok, false);
    assert.equal(a.code, 'prior_copy_unresolved');
    assert.equal(s.getItem(PRE), slot);
    assert.equal(s.getItem(KEY), liveNow);
    assert.equal(s.snapshot(), before);
  });
});
