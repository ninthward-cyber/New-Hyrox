'use strict';
// t112b Meron R4-D1..D8 fail-first tests, using her r4-meron-fixtures/probe-r4.js cases.
// D9 is Dawit R4-D1 (already fixed); C4-03 is included as the same defect's truncate fixture.
// Synthetic only; no network.
const test = require('node:test');
const assert = require('node:assert/strict');
const { requireGarmin, loadData } = require('./garmin-helpers');
const X = require('../src/data/hyrox-coach-export.js');
const HN = require('../src/data/hyrox-nutrition.js');
const HC = require('../src/data/hyrox-coach.js');

const G = requireGarmin();
const HD = loadData();
const QA = { timeZone: 'Asia/Qatar' };
const P = '2026-11-22';
const KEY = HD.STORAGE_KEY;
const NOW_ISO = '2026-11-24T06:00:00.000Z';

function mem(init) {
  const m = new Map(Object.entries(init || {}));
  return {
    getItem: (k) => (m.has(k) ? m.get(k) : null),
    setItem: (k, v) => { m.set(k, String(v)); },
    removeItem: (k) => m.delete(k),
    keys: () => [...m.keys()],
    _m: m
  };
}
function v2(over) {
  return Object.assign({
    version: 2, weight: [], workouts: [], nutrition: [],
    sessions: [], meals: [], body: [], daily: [], walks: [],
    dayStates: [], planEvents: [], ownerSettings: []
  }, over || {});
}
function mk(doc, nowIso, extra) {
  const init = Object.assign({}, extra || {});
  if (doc !== null && doc !== undefined) init[KEY] = typeof doc === 'string' ? doc : JSON.stringify(doc);
  const s = mem(init);
  const now = () => new Date(nowIso || NOW_ISO);
  return { s, api: HD.createStore(s, { now }), raw: () => s.getItem(KEY), data: () => JSON.parse(s.getItem(KEY) || 'null') };
}
function chron(date, endH, endM) {
  const [y, m, d] = date.split('-').map(Number);
  const ls = Date.UTC(y, m - 1, d);
  const p = (n) => String(n).padStart(2, '0');
  const f = (ms) => {
    const t = new Date(ms);
    return t.getUTCFullYear() + '-' + p(t.getUTCMonth() + 1) + '-' + p(t.getUTCDate()) + 'T' + p(t.getUTCHours()) + ':' + p(t.getUTCMinutes()) + ':00.0';
  };
  const eh = endH == null ? 23 : endH, em = endM == null ? 59 : endM;
  const el = ls + (eh * 60 + em) * 60000;
  return {
    startTimestampGmt: f(ls - 3 * 3600000),
    startTimestampLocal: f(ls),
    endTimestampGmt: f(el - 3 * 3600000),
    endTimestampLocal: f(el),
    totalDurationInMillis: el - ls
  };
}
function row(date, over) {
  return Object.assign({
    calendarDate: date, source: 'garmin', uuid: 'syn-' + date, includesWellnessData: true,
    movement: { steps: { value: 8421 } },
    intensityMinutes: { moderate: 20, vigorous: 8 },
    wellnessChronology: chron(date)
  }, over || {});
}
function tick(dates, which) {
  const o = {};
  dates.forEach((d) => { o[d] = true; });
  const c = {};
  (which || ['steps', 'int']).forEach((w) => {
    c[w === 'steps' ? 'applySteps' : 'applyIntensity'] = Object.assign({}, o);
  });
  return c;
}
function apply(t, rows, conf, ctx) {
  return G.applyMerge(t.api, conf, Object.assign({ settings: QA, dailyPayload: { data: rows }, nowIso: NOW_ISO }, ctx || {}));
}
function daily(t, date) {
  const d = t.data();
  return d && (d.daily || []).filter((x) => x.date === date)[0];
}
function settingsOf(d) {
  return ((d && d.ownerSettings) || []).filter((e) => e && e.id === 'app-settings')[0] || null;
}
function withLedger() {
  return v2({
    daily: [{ id: 'daily-' + P, date: P, createdAt: '2026-11-22T05:00:00.000Z', steps: { state: 'OBSERVED', value: 8421, source: 'GARMIN_PERSONAL_API' } }],
    ownerSettings: [{
      id: 'app-settings', date: '2026-11-20', createdAt: '2026-11-20T05:00:00.000Z', rhrBaselineBpm: 55,
      garminLedger: {
        identity: { subject: 'syn-owner-canary' },
        byDate: { [P]: { keys: { daily: { calendarDate: P, localId: 'daily-' + P } } } },
        tombstones: [{ collection: 'daily', date: '2026-11-19', localId: 'daily-2026-11-19' }]
      }
    }]
  });
}

test('Meron R4-D1 / C1-11: ticked invalid intensity plus valid unticked steps writes nothing', () => {
  const t = mk(v2());
  const r = apply(t, [row(P, { intensityMinutes: { moderate: 20 } })], tick([P], ['int']));
  assert.equal(!!r.wrote, false);
  assert.equal(daily(t, P), undefined, 'no metadata-only daily-' + P);
});

test('Meron R4-D1 / C1-11b: ticked invalid steps plus valid unticked intensity writes nothing', () => {
  const t = mk(v2());
  const r = apply(t, [row(P, { movement: { steps: { value: 'x' } } })], tick([P], ['steps']));
  assert.equal(!!r.wrote, false);
  assert.equal(daily(t, P), undefined);
});

test('Meron R4-D2 / C1-12: a past day whose chronology ends at 10:00 local is held, not written as complete', () => {
  const t = mk(v2());
  const r = apply(t, [row(P, { wellnessChronology: chron(P, 10, 0), movement: { steps: { value: 3100 } } })], tick([P]));
  assert.equal(daily(t, P), undefined, 'incomplete day must not be written: ' + JSON.stringify(r));
  const pv = G.preview({ settings: QA, dailyPayload: { data: [row(P, { wellnessChronology: chron(P, 10, 0), movement: { steps: { value: 3100 } } })] }, storeData: v2(), api: t.api, nowIso: NOW_ISO });
  const held = (pv.items || []).filter((i) => i.date === P && i.status === 'HOLD');
  assert.ok(held.length, 'preview must HOLD the incomplete day: ' + JSON.stringify(pv.items));
});

test('Meron R4-D3 / C1-16: mappedRows today with inProgress missing is never written; today comes from Qatar midnight', () => {
  const t = mk(v2());
  const r = G.applyMerge(t.api, tick(['2026-11-24'], ['steps']), {
    settings: QA, mappedRows: { daily: [{ calendarDate: '2026-11-24', steps: { state: 'OBSERVED', value: 4000 } }] }, nowIso: NOW_ISO
  });
  assert.equal(!!(daily(t, '2026-11-24') && daily(t, '2026-11-24').steps && daily(t, '2026-11-24').steps.state === 'OBSERVED'), false, JSON.stringify(r));
});

test('Meron R4-D3 / C1-16: future inProgress false and bad values skip only that row; a valid past day is still saved', () => {
  const t = mk(v2());
  const rows = [
    { calendarDate: '2026-11-26', inProgress: false, steps: { state: 'OBSERVED', value: 4000 } },
    { calendarDate: P, steps: { state: 'OBSERVED', value: 999999 } },
    { calendarDate: P, steps: { state: 'OBSERVED', value: Number.POSITIVE_INFINITY } },
    { calendarDate: '2026-11-21', steps: { state: 'OBSERVED', value: 4000 } }
  ];
  const conf = { applySteps: { '2026-11-26': true, '2026-11-21': true, [P]: true } };
  const r = G.applyMerge(t.api, conf, { settings: QA, mappedRows: { daily: rows }, nowIso: NOW_ISO });
  assert.notEqual(r.code, 'INVALID_RECORD', 'must not fail the whole batch with raw validator text: ' + JSON.stringify(r));
  const msg = G.ownerMessageForApply(r) || r.message || '';
  assert.doesNotMatch(msg, /Date cannot be in the future/);
  assert.doesNotMatch(msg, /steps must be a number from 0 to 200000/);
  assert.equal(daily(t, '2026-11-26'), undefined);
  assert.equal(daily(t, P), undefined);
  const kept = daily(t, '2026-11-21');
  assert.ok(kept && kept.steps && kept.steps.value === 4000 && kept.steps.source === 'GARMIN_PERSONAL_API', 'valid past row must still be saved: ' + JSON.stringify(r) + ' ' + JSON.stringify(kept));
  assert.ok(r.wrote === true);
});

test('Meron R4-D4: coach export names Garmin-derived observations, not “nothing is imported”', () => {
  const s = mem({
    'hyrox.v1': JSON.stringify(v2({
      daily: [{
        id: 'daily-' + P, date: P, createdAt: '2026-11-22T05:00:00.000Z',
        steps: { state: 'OBSERVED', value: 8421, source: 'GARMIN_PERSONAL_API' },
        intensityMin: { state: 'OBSERVED', value: 36, source: 'GARMIN_PERSONAL_API', moderate: 20, vigorous: 8 }
      }]
    }))
  });
  const api = HD.createStore(s, { now: () => new Date(NOW_ISO) });
  const r = X.build(X.collect(api, { HD, HN, HC, to: '2026-11-24', planned: [], noActivePlanDates: [] }), {
    from: '2026-11-17', to: '2026-11-24', now: new Date(NOW_ISO), rand: () => 0.5
  });
  assert.equal(r.ok, true, JSON.stringify(r));
  const note = r.snapshot.unavailable.deviceImportedActivity.note;
  assert.equal(r.snapshot.unavailable.deviceImportedActivity.status, 'RECORDED_IN_APP');
  assert.doesNotMatch(note, /Nothing is imported from Garmin/);
  assert.match(note, /Garmin-derived observation/i);
  assert.doesNotMatch(note, /Steps and Garmin intensity minutes are typed by the owner \(steps\.daily\)\.$/);
});

test('Meron R4-D5 / C1-15: same-date conflicting rows HOLD the date; first row does not win', () => {
  const rows = [row(P, { movement: { steps: { value: 5000 } } }), row(P, { movement: { steps: { value: 15000 } } })];
  const t = mk(v2());
  const r = apply(t, rows, tick([P]));
  assert.equal(daily(t, P), undefined, 'must not silently keep 5000: ' + JSON.stringify(r) + ' ' + JSON.stringify(daily(t, P)));
  const pv = G.preview({ settings: QA, dailyPayload: { data: rows }, storeData: v2(), api: mk(v2()).api, nowIso: NOW_ISO });
  const held = (pv.items || []).filter((i) => (i.date === P || i.calendarDate === P) && i.status === 'HOLD');
  assert.ok(held.length, 'preview must HOLD the conflicting date: ' + JSON.stringify(pv.items));
  const msg = G.ownerMessageForApply(r) || '';
  assert.match(msg, /did not agree|not saved/i);
});

test('Meron R4-D6 / C2-07: garminLedger:undefined in a settings save keeps the ledger and tombstones', () => {
  const t = mk(null);
  apply(t, [row(P)], tick([P]));
  assert.equal(t.api.removeRecord('daily', 'daily-' + P), true);
  const nr2 = JSON.parse(JSON.stringify(settingsOf(t.data())));
  nr2.garminLedger = undefined;
  nr2.rhrBaselineBpm = 53;
  t.api.putRecord('ownerSettings', nr2);
  const led = settingsOf(t.data()).garminLedger;
  assert.ok(led && /"collection":"daily"/.test(JSON.stringify(led)), 'ledger=' + JSON.stringify(led));
});

test('Meron R4-D7 / N-4 residual: non-list tombstones are LEDGER_CORRUPT, not merge failed, with apply wording', () => {
  const t = mk(v2({
    daily: [{ id: 'daily-2026-11-20', date: '2026-11-20', createdAt: '2026-11-20T05:00:00.000Z', rhr: { state: 'OBSERVED', value: 55 } }],
    ownerSettings: [{ id: 'app-settings', date: '2026-11-20', createdAt: '2026-11-20T05:00:00.000Z', garminLedger: { v: 1, tombstones: 'x' } }]
  }));
  const before = t.raw();
  const r = apply(t, [row(P)], tick([P], ['steps']));
  assert.equal(t.raw(), before);
  assert.equal(r.wrote, false);
  assert.equal(r.code, 'LEDGER_CORRUPT');
  assert.notEqual(r.message, 'merge failed');
  const owner = G.ownerMessageForApply(r);
  assert.doesNotMatch(owner, /merge failed/);
  assert.match(owner, /Garmin import links in your settings could not be read/i);
  assert.match(owner, /Nothing was changed/);
  assert.doesNotMatch(owner, /Nothing was deleted/);
  assert.doesNotMatch(owner, /this check-in/i);
});

test('Meron R4-D8 / H-08: duplicate settings records get a plain owner sentence, not raw id text', () => {
  const d = withLedger();
  d.ownerSettings.push({ id: 'app-settings', date: '2026-11-21', createdAt: '2026-11-21T05:00:00.000Z', rhrBaselineBpm: 60 });
  const t = mk(d);
  const before = t.raw();
  const r = apply(t, [row('2026-11-21')], tick(['2026-11-21']));
  assert.equal(r.ok, false);
  assert.equal(r.wrote, false);
  assert.equal(t.raw(), before);
  const owner = G.ownerMessageForApply(r);
  assert.doesNotMatch(owner, /ownerSettings id app-settings/);
  assert.match(owner, /Nothing was changed/);
  assert.match(owner, /settings could not be used|Saved settings/i);
});

test('Meron R4-D9 / C4-03: empty-store truncated setItem leaves no partial diary (same fix as Dawit R4-D1)', () => {
  const s = mem();
  const realSet = s.setItem.bind(s);
  s.setItem = (k, v) => { realSet(k, k === KEY ? String(v).slice(0, 20) : v); };
  const api = HD.createStore(s, { now: () => new Date(NOW_ISO) });
  const r = G.applyMerge(api, tick([P]), { settings: QA, dailyPayload: { data: [row(P)] }, nowIso: NOW_ISO });
  assert.equal(r.ok, false);
  assert.equal(r.code, 'save_failed');
  assert.equal(s.getItem(KEY), null);
  assert.equal(r.rolledBack, true);
});

test('t118u / Meron O-1: Garmin 0 steps is not imported; preview uses the owner phrase and is not tickable', () => {
  assert.equal(G.TREAT_ZERO_STEPS_AS_MISSING, true, 't118u: a Garmin 0 means not worn and is not imported');
  assert.equal(G.ZERO_STEPS_STATUS, 'Garmin shows 0 steps, likely not worn');
  const t = mk(v2());
  const r0 = row(P);
  r0.movement.steps.value = 0;
  delete r0.intensityMinutes;
  const r = apply(t, [r0], tick([P], ['steps']));
  assert.equal(!!r.wrote, false);
  assert.equal(daily(t, P), undefined);
  const pv = G.preview({ settings: QA, dailyPayload: { data: [r0] }, storeData: v2(), api: t.api, nowIso: NOW_ISO });
  const z = (pv.items || []).filter((i) => i.date === P && i.reason === 'ZERO_STEPS_AS_MISSING');
  assert.ok(z.length, 'preview must include the 0-steps day: ' + JSON.stringify(pv.items));
  assert.equal(z[0].status, 'Garmin shows 0 steps, likely not worn');
  assert.equal(z[0].ticked, false);
  assert.equal(z[0].writable, false);
  assert.match(z[0].hint, /Morning or Daily check-in/);
  assert.match(G.ownerMessageForApply(r), /likely not worn/);
});

function previewHost() {
  function el(tag) {
    const n = {
      tagName: String(tag).toUpperCase(),
      attrs: {},
      children: [],
      textContent: '',
      disabled: false,
      checked: false,
      type: '',
      style: {},
      listeners: {},
      setAttribute(k, v) { this.attrs[k] = String(v); },
      getAttribute(k) { return this.attrs[k]; },
      addEventListener(type, fn) { (this.listeners[type] = this.listeners[type] || []).push(fn); },
      click() { (this.listeners.click || []).forEach((fn) => fn()); },
      appendChild(c) { this.children.push(c); return c; }
    };
    return n;
  }
  const host = {
    children: [],
    textContent: '',
    get firstChild() { return this.children[0] || null; },
    appendChild(c) { this.children.push(c); return c; },
    removeChild(c) { this.children = this.children.filter((x) => x !== c); return c; }
  };
  const controls = {};
  const doc = {
    createElement: el,
    querySelector(sel) { return controls[sel] || null },
    _controls: controls
  };
  host.ownerDocument = doc;
  return { host, doc, controls, el };
}

test('t118u: 0 steps is never written even if ticked', () => {
  const t = mk(v2());
  const r0 = row(P, { movement: { steps: { value: 0 } }, intensityMinutes: { moderate: 20, vigorous: 8 } });
  const r = apply(t, [r0], Object.assign(tick([P], ['steps']), tick([P], ['int'])));
  // intensity may be writable, but 0 steps must not be stored
  const d = daily(t, P);
  if (d) {
    assert.ok(!d.steps || d.steps.state !== 'OBSERVED' || d.steps.value !== 0, '0 steps must not be stored as OBSERVED 0: ' + JSON.stringify(d));
    assert.notEqual(d.steps && d.steps.value, 0);
  }
  const stepsOnly = mk(v2());
  const r2 = apply(stepsOnly, [row(P, { movement: { steps: { value: 0 } }, intensityMinutes: undefined })], tick([P], ['steps']));
  // row() with intensityMinutes: undefined still has default intensity — force no intensity
  assert.ok(!r2.wrote || !daily(stepsOnly, P) || !daily(stepsOnly, P).steps || daily(stepsOnly, P).steps.value !== 0);
});

test('t118u: after a Garmin 0, manual Morning/check-in steps for that date still work', () => {
  const t = mk(v2());
  const r0 = row(P);
  r0.movement.steps.value = 0;
  delete r0.intensityMinutes;
  apply(t, [r0], tick([P], ['steps']));
  assert.equal(daily(t, P), undefined);
  const saved = t.api.putRecord('daily', {
    id: 'daily-' + P, date: P, createdAt: P + 'T05:00:00.000Z',
    steps: { state: 'OBSERVED', value: 8000 }
  });
  assert.equal(saved.ok, true, JSON.stringify(saved));
  const d = daily(t, P);
  assert.ok(d && d.steps && d.steps.state === 'OBSERVED' && d.steps.value === 8000, JSON.stringify(d));
});

test('t118u: a later non-zero Garmin value does not override manual steps without Replace', () => {
  const t = mk(v2({
    daily: [{ id: 'daily-' + P, date: P, createdAt: P + 'T05:00:00.000Z', steps: { state: 'OBSERVED', value: 8000 } }]
  }));
  // Garmin 0 first (no write), then a non-zero later import without Replace
  const zero = row(P);
  zero.movement.steps.value = 0;
  apply(t, [zero], tick([P], ['steps']));
  const later = apply(t, [row(P)], tick([P], ['steps']));
  const d = daily(t, P);
  assert.equal(d.steps.value, 8000, 'manual steps must be kept without Replace: ' + JSON.stringify(later) + ' ' + JSON.stringify(d));
  assert.notEqual(d.steps.source, 'GARMIN_PERSONAL_API');
  const replaced = apply(t, [row(P)], Object.assign(tick([P], ['steps']), { replaceSteps: { [P]: true } }));
  const d2 = daily(t, P);
  assert.equal(d2.steps.value, 8421);
  assert.equal(d2.steps.source, 'GARMIN_PERSONAL_API');
  assert.equal(replaced.wrote, true);
});

test('t118u: preview render is unticked, not tickable, and Open Morning clicks the existing Add > Morning controls', () => {
  const t = mk(v2());
  const r0 = row(P);
  r0.movement.steps.value = 0;
  delete r0.intensityMinutes;
  const pv = G.preview({ settings: QA, dailyPayload: { data: [r0] }, storeData: v2(), api: t.api, nowIso: NOW_ISO });
  const ui = previewHost();
  let addClicks = 0, morningClicks = 0;
  ui.controls['[data-testid="tab-add"]'] = { click() { addClicks++; } };
  ui.controls['[data-testid="add-mode-morning"]'] = { click() { morningClicks++; } };
  const out = G.renderPreview(ui.host, Object.assign({ forceRender: true }, pv));
  assert.equal(out.ok, true);
  const all = [];
  function walk(n) { if (!n) return; all.push(n); (n.children || []).forEach(walk); }
  ui.host.children.forEach(walk);
  const label = all.find((n) => n.attrs && n.attrs['data-testid'] === 'garmin-zero-steps');
  const box = all.find((n) => n.attrs && n.attrs['data-testid'] === 'garmin-preview-tick');
  const btn = all.find((n) => n.attrs && n.attrs['data-testid'] === 'garmin-zero-steps-morning');
  assert.ok(label, 'expected garmin-zero-steps label');
  assert.match(label.textContent, /Garmin shows 0 steps, likely not worn/);
  assert.match(label.textContent, /Morning or Daily check-in/);
  assert.equal(box.checked, false);
  assert.equal(box.disabled, true, '0-steps tick must not be tickable');
  assert.ok(btn, 'expected Open Morning button');
  btn.click();
  assert.equal(addClicks, 1, 'must click the existing Add tab');
  assert.equal(morningClicks, 1, 'must click the existing Morning mode control');
});
