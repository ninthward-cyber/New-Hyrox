'use strict';
// P1.3 QA screenshots + larger-text check (not part of the normal suite; copy into tests/e2e of a P1.3 copy to run).
// Writes PNGs to P13_SCREENS (under /workspace/hyrox-p1-3/screens only). SYNTHETIC data only (no owner numbers).
// CHROME MOBILE EMULATION, NOT SAFARI/WEBKIT. "Larger text" = CSS zoom 1.35 on the page (close to Safari's aA page zoom);
// the app's px font sizes are NOT scaled by iOS Dynamic Type, which cannot be emulated here (residual for the iPhone check).
const { test, expect } = require('@playwright/test');
const path = require('path');
const L = require('./p1-3-coach-lib');
const OUT = process.env.P13_SCREENS;
const O = (v) => ({ state: 'OBSERVED', value: v });
const T = '2026-10-01T05:00:00.000Z';
function seed(coachMore, histOpt) {
  const h = L.history(histOpt || { kgPerWeek: -0.45 });
  const co = L.coachObj(coachMore);
  const daily = ['2026-11-15', '2026-11-16', '2026-11-17', '2026-11-18', '2026-11-19'].map((d, i) => ({ id: 'daily-' + d, date: d, createdAt: T, steps: O(8000 + i * 300), pain: O(2),
    intensityMin: { state: 'OBSERVED', value: 25 + i, source: 'GARMIN_MANUAL' } }));
  const body = [{ id: 'b1', createdAt: T, date: '2026-11-14', metric: 'waist_cm', state: 'OBSERVED', value: 92, source: 'manual' }];
  return L.seedOf({ weight: h.weight, meals: h.meals.concat([L.meal('m-today', '2026-11-23', 640)]), dayStates: h.dayStates, sessions: L.planDone(), daily, body, ownerSettings: [L.settingsWith(co)] });
}
const TGT = { kcal: 2200, proteinG: 190, fatG: 60, carbsG: null, origin: 'OWNER_ENTERED', method: 'OWNER', effectiveDate: '2026-11-02', confirmedAt: '2026-11-02T06:00:00.000Z', reason: 'synthetic', version: 'coach-1', goal: 'LOSE_1', inputs: null, warnings: [], replaced: { kcal: 2400, proteinG: 190, fatG: null, carbsG: null, origin: 'PROVISIONAL' } };
const noOverflow = (page) => page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1);
async function shot(page, name) { if (OUT) await page.screenshot({ path: path.join(OUT, name + '.png'), fullPage: true }); }

for (const W of [390, 320]) for (const zoom of [1, 1.35]) {
  const tag = W + (zoom === 1 ? '' : '-largetext');
  test.describe(`P1.3 QA screens ${tag} (Chrome emulation, not Safari)`, () => {
    test.use({ viewport: { width: W, height: W === 320 ? 568 : 844 } });
    async function z(page) { if (zoom !== 1) await page.evaluate((k) => { document.documentElement.style.zoom = String(k); }, zoom); }

    test(`${tag}: Home with closeout and coach status; Settings coach; Trends weekly review; confirm screen`, async ({ page }) => {
      await L.open(page, seed({ target: TGT, history: [TGT] })); await z(page);
      await expect(page.getByTestId('today-closeout')).toBeVisible();
      await expect(page.getByTestId('coach-status')).toBeVisible();
      expect(await noOverflow(page)).toBe(true);
      await shot(page, tag + '-01-home');
      // the diet reference shown in the Today details equals the confirmed target (current and prior screens consistent)
      await page.getByTestId('tab-settings').click(); await z(page);
      await expect(page.getByTestId('coach-current-line')).toHaveText('In use today: 2,200 kcal · protein 190 g · fat 60 g · carbs —');
      await page.getByTestId('coach-profile-summary').click();
      expect(await noOverflow(page)).toBe(true);
      await shot(page, tag + '-02-settings-coach');
      await page.getByTestId('coach-own').locator('summary').click();
      await page.getByTestId('coach-own-kcal').fill('2100'); await page.getByTestId('coach-own-protein').fill('190'); await page.getByTestId('coach-own-fat').fill('60');
      await page.getByTestId('coach-own-review').click();
      await expect(page.getByTestId('coach-confirm')).toBeVisible();
      expect(await noOverflow(page)).toBe(true);
      await shot(page, tag + '-03-confirm');
      await page.getByTestId('coach-confirm-cancel').click();
      await page.getByTestId('tab-trends').click(); await z(page);
      await expect(page.getByTestId('trends-coach-review')).toBeVisible();
      expect(await noOverflow(page)).toBe(true);
      await page.getByTestId('trends-coach-review').scrollIntoViewIfNeeded();
      await shot(page, tag + '-04-trends-review');
      expect(page._errs).toEqual([]); expect(page._net).toEqual([]);
    });

    test(`${tag}: status line levels (red, amber, gray) and coach off`, async ({ page }) => {
      const flags = ['2026-11-16', '2026-11-17', '2026-11-18'].map((d) => ({ id: 'daily-' + d, date: d, createdAt: T, sleepH: O(5), soreness: O(7) }));
      const s = seed(); s.daily = flags;
      await L.open(page, s); await z(page);
      await expect(page.getByTestId('coach-status')).toHaveAttribute('data-level', 'RED');
      expect(await noOverflow(page)).toBe(true); await page.getByTestId('glance-nutrition').screenshot(OUT ? { path: path.join(OUT, tag + '-05-status-red.png') } : {});
      await L.open(page, seed({}, { kgPerWeek: -1.2 })); await z(page);
      await expect(page.getByTestId('coach-status')).toHaveAttribute('data-level', 'AMBER');
      await page.getByTestId('glance-nutrition').screenshot(OUT ? { path: path.join(OUT, tag + '-06-status-amber.png') } : {});
      await L.open(page, seed({}, { weighDows: [1] })); await z(page);
      await expect(page.getByTestId('coach-status')).toHaveAttribute('data-level', 'GRAY');
      await page.getByTestId('glance-nutrition').screenshot(OUT ? { path: path.join(OUT, tag + '-07-status-gray.png') } : {});
      await L.open(page, seed({ enabled: false })); await z(page);
      await expect(page.getByTestId('coach-status')).toHaveCount(0);
      await page.getByTestId('glance-nutrition').screenshot(OUT ? { path: path.join(OUT, tag + '-08-coach-off.png') } : {});
      expect(page._errs).toEqual([]);
    });
  });
}
