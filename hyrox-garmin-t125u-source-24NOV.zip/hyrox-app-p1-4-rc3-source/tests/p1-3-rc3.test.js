'use strict';
// P1.3-RC3 (owner-approved Command Center decisions 1 and 5, 23 Nov 2026):
//  1. an own target below the provisional floor (or the resting estimate, if higher) is REFUSED, never clamped;
//  5. computed calorie ESTIMATES are shown rounded to the nearest 50 kcal - display only: stored values, calculations,
//     suggested targets (what a Confirm would store), own targets and alert boundaries stay exact.
// Also decision 3: the "not logged" hold note shows numerator, denominator and excluded slots.
// Synthetic data only. These tests FAIL on P1.3-RC2 (a5f2862).
const test = require('node:test');
const assert = require('node:assert');
const path = require('path');
const HC = require(path.join(__dirname, '..', 'src', 'data', 'hyrox-coach.js'));

// ---------- decision 5: display rounding ----------
test('RC3 rounding: estimates round to the nearest 50 kcal for display; ties go up; non-numbers give no text', () => {
  const cases = [[2643, 2650], [2624, 2600], [2625, 2650], [2675, 2700], [2690, 2700], [2685, 2700], [1822.5, 1800], [1825, 1850], [1849.9, 1850], [2400, 2400], [0, 0]];
  for (const [v, want] of cases) assert.strictEqual(HC.roundKcal50(v), want, String(v));
  assert.strictEqual(HC.estimateKcalText(2643), 'about 2,650 kcal');
  assert.strictEqual(HC.estimateKcalText(1822.5), 'about 1,800 kcal');
  for (const bad of [null, undefined, NaN, '2643', Infinity]) assert.strictEqual(HC.roundKcal50(bad), null, String(bad));
});

test('RC3 rounding is display-only: starting estimate, personal estimate, proposals and arithmetic keep exact values', () => {
  const coach = Object.assign(HC.emptyCoach(), { enabled: true, profile: { heightCm: 178, heightUnit: 'cm', ageYears: 49, ageEnteredOn: '2026-11-01', ageConfirmedOn: '2026-11-01', estimateMethod: 'EQUATION', sexForEquation: 'MALE', activity: 'A2' } });
  const est = HC.startingEstimate(coach, [{ date: '2026-11-21', kg: 95 }], '2026-11-23');
  assert.deepStrictEqual([est.resting, est.maintenance], [1823, 2643]); // exact, unrounded
  const pr = HC.proposal({ maintenance: est.maintenance, resting: est.resting, source: 'STAGE_A', weightKg: 95, sex: 'MALE', goalId: 'LOSE_1', current: { kcal: 2400, proteinG: 190 }, concerns: [] });
  assert.strictEqual(pr.target.kcal, 2143); // what a Confirm stores: exact
  assert.match(pr.arithmetic, /Maintenance estimate 2643 kcal - 500/); // calculation shown exactly
  // personal estimate: exact number kept, text rounded and says so
  const days = [], weights = [];
  const TD = '2026-11-23';
  const ws = HC.reviewWeeks(TD, 4);
  for (let d = ws[0].start; d <= ws[3].end; d = HC.addDays(d, 1)) {
    const t = HC.daysBetween(ws[0].start, d), dw = new Date(d + 'T00:00:00Z').getUTCDay();
    if ([0, 2, 4, 6].includes(dw)) weights.push({ date: d, kg: Math.round((100 - 0.35 * t / 7) * 1000) / 1000 });
    days.push({ date: d, code: 'D5', kcal: 2300, estKcal: 0 });
  }
  const sb = HC.stageB(days, weights, TD);
  assert.strictEqual(sb.maintenance, 2685);
  assert.match(sb.text, /^Personal estimate about 2,700 kcal a day/);
  assert.match(sb.text, /rounded to the nearest 50 kcal/);
});

test('RC3 rounding never touches alert boundaries: the low-target floor and resting comparisons use exact values', () => {
  // resting 1,823 exact: 1,822 is below it, 1,823 is not (a rounded 1,800 would wrongly accept 1,810)
  assert.strictEqual(HC.checkOwnerTarget({ kcal: '1822', proteinG: '190' }, { sex: 'MALE', restingKcal: 1823 }).ok, false);
  assert.strictEqual(HC.checkOwnerTarget({ kcal: '1823', proteinG: '190' }, { sex: 'MALE', restingKcal: 1823 }).ok, true);
  assert.strictEqual(HC.checkOwnerTarget({ kcal: '1810', proteinG: '190' }, { sex: 'MALE', restingKcal: 1823 }).ok, false);
});

// ---------- decision 1: refuse below the provisional floor ----------
test('RC3 refuse: an own target below the provisional floor is refused with both numbers; never clamped or changed', () => {
  const r = HC.checkOwnerTarget({ kcal: '1000', proteinG: '190', fatG: '', carbsG: '' }, { sex: 'MALE', restingKcal: 1850, currentKcal: 2400 });
  assert.strictEqual(r.ok, false); assert.strictEqual(r.target, null);
  assert.ok(r.errors.some((e) => /1,000 kcal is below the provisional floor of 1,850 kcal/.test(e)), r.errors.join(' | '));
  assert.ok(r.errors.some((e) => /not a medical rule/.test(e) && /clinician/.test(e)));
  assert.strictEqual(r.needsAck, undefined);
  // general floor when no resting estimate: male 1,500, female 1,200, unknown sex uses the higher (1,500)
  assert.strictEqual(HC.checkOwnerTarget({ kcal: '1499', proteinG: '150' }, { sex: 'MALE' }).ok, false);
  assert.strictEqual(HC.checkOwnerTarget({ kcal: '1500', proteinG: '150' }, { sex: 'MALE' }).ok, true);
  assert.strictEqual(HC.checkOwnerTarget({ kcal: '1199', proteinG: '100' }, { sex: 'FEMALE' }).ok, false);
  assert.strictEqual(HC.checkOwnerTarget({ kcal: '1200', proteinG: '100' }, { sex: 'FEMALE' }).ok, true);
  assert.strictEqual(HC.checkOwnerTarget({ kcal: '1499', proteinG: '150' }, {}).ok, false);
  // at or above the floor: accepted; the other warnings are unchanged
  const ok = HC.checkOwnerTarget({ kcal: '1900', proteinG: '160', fatG: '', carbsG: '' }, { sex: 'MALE', restingKcal: 1850, currentKcal: 2400 });
  assert.strictEqual(ok.ok, true); assert.deepStrictEqual(ok.target.kcal, 1900);
  assert.ok(ok.warnings.some((w) => w.code === 'PROTEIN_BELOW_REFERENCE_FLOOR'));
  assert.ok(!ok.warnings.some((w) => w.code === 'BELOW_FLOOR' || w.code === 'BELOW_RESTING'));
});

test('RC3 GUARD (passes before and after): a below-floor target already stored (from RC2 or a restored backup) is kept as stored, not changed, and stays an amber concern', () => {
  const t = { kcal: 1000, proteinG: 190, fatG: null, carbsG: null, origin: 'OWNER_ENTERED', effectiveDate: '2026-11-20', confirmedAt: '2026-11-20T05:00:00.000Z' };
  const rc = HC.readCoach({ nutritionCoach: { schema: 1, enabled: true, target: t, history: [t] } });
  assert.strictEqual(rc.valid, true);
  assert.strictEqual(HC.targetFor(rc.coach, '2026-11-23', { kcal: 2400, proteinG: 190, proteinFloorG: 170 }).kcal, 1000);
  const c = HC.concerns({ weeks: [] }, [], { floorKcal: 1500, target: t });
  assert.deepStrictEqual(c.map((x) => [x.code, x.level]), [['LOW_TARGET', 'AMBER']]);
});

// ---------- decision 3: hold note shows numerator, denominator and excluded slots ----------
test('RC3 sessions: the hold note gives not-logged / eligible and names slots excluded by the plan', () => {
  const c = HC.concerns({ weeks: [] }, [], { recovery: { flagDays: 0, maxPain: null, slots: { planned: 5, completed: 0, partial: 0, skipped: 0, unlogged: 3, omitted: 2 } } });
  assert.deepStrictEqual(c.map((x) => [x.code, x.level]), [['SESSION_LOG', 'HOLD']]);
  assert.match(c[0].text, /3 of 3 eligible planned sessions last week are not logged/);
  assert.match(c[0].text, /2 omitted by the plan’s own rules are excluded/);
  const n = HC.concerns({ weeks: [] }, [], { recovery: { flagDays: 0, maxPain: null, slots: { planned: 5, completed: 1, partial: 0, skipped: 0, unlogged: 4, omitted: 0 } } });
  assert.match(n[0].text, /4 of 5 eligible planned sessions last week are not logged/);
  assert.doesNotMatch(n[0].text, /excluded/);
});

test('RC3 package: label, build folder and notes name the base, the decisions, the iPhone checks and the RC2 sizes', () => {
  const fs = require('fs'), rd = (f) => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');
  assert.match(rd('index.html'), /<meta name="hyrox-release" content="(P1\.3-RC3|P1\.4-RC[123])">/); // RE-POINTED by P1.4-RC2 (Sprint B2, 23 Nov 2026); // RE-POINTED by the integrated candidate P1.4-RC1 (23 Nov 2026) // RE-POINTED by P1.4-RC3 (Claude independent QA, 23 Nov 2026)
  assert.match(rd('tools/build-deploy-package.mjs'), /'hyrox-p1-(3-rc3|4-rc[123])-deploy'/); // RE-POINTED by P1.4-RC2 (Sprint B2, 23 Nov 2026); // RE-POINTED by the integrated candidate P1.4-RC1 (23 Nov 2026) // RE-POINTED by P1.4-RC3 (Claude independent QA, 23 Nov 2026)
  const c = rd('CHANGES-P1.3-RC3.md'), d = rd('DEPLOY-P1.3-RC3.md'), b = rd('P1.3-RC3-OWNER-BRIEF.md'), r = rd('deploy/README-DEPLOY.txt');
  for (const re of [/a5f2862bc8280d33ecb8eeddfc7310dbb1a2da9e/, /686c3be0836b/, /5016d0ff70ca7048d8226597201e1c2b5db57db45ecf81c392d2fd659fa0d7bc/, /refused/, /nearest 50 kcal/, /Display only/, /Not deployed, not pushed/, /Not Safari, not a physical iPhone/]) assert.match(c, re);
  for (const re of [/\| `686c3be0836b` \| 381896 \| 45241 \|/, /refused/, /Rounding/, /After midnight/, /same origin/, /F-1/, /not deploy approval/i]) assert.match(d, re);
  assert.doesNotMatch(d, /Confirm without the tick/);
  assert.match(b, /refused/); assert.match(b, /protein 190 g, with a protein floor of 170 g/);
  assert.match(r, /^HYROX Command (P1\.3-RC3|P1\.4-RC[123]) deploy package/m); // RE-POINTED by P1.4-RC2 (Sprint B2, 23 Nov 2026); // RE-POINTED by the integrated candidate P1.4-RC1 (23 Nov 2026); assert.match(r, /DEPLOY-P1\.3-RC3\.md/); assert.match(r, /SHA256SUMS-p1-3-rc3\.txt/); // RE-POINTED by P1.4-RC3 (Claude independent QA, 23 Nov 2026)
});
