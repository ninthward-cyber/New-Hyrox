'use strict';

const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

function resolveDataPath() {
  if (process.env.HYROX_DATA_PATH) {
    return path.resolve(process.env.HYROX_DATA_PATH);
  }
  const defaultPath = path.resolve(__dirname, '../src/data/hyrox-data.js');
  if (fs.existsSync(defaultPath)) return defaultPath;
  const fallback = '/workspace/hyrox-wt/data/src/data/hyrox-data.js';
  if (fs.existsSync(fallback)) return fallback;
  throw new Error(
    'hyrox-data.js not found. Set HYROX_DATA_PATH or place the module at ../src/data/hyrox-data.js'
  );
}

function loadHyroxData() {
  const dataPath = resolveDataPath();
  delete require.cache[require.resolve(dataPath)];
  const exported = require(dataPath);
  if (exported && typeof exported.createStore === 'function' && typeof exported.todayQatar === 'function') {
    return exported;
  }
  if (
    typeof globalThis.HyroxData === 'object' &&
    globalThis.HyroxData &&
    typeof globalThis.HyroxData.createStore === 'function'
  ) {
    return globalThis.HyroxData;
  }
  throw new Error('Module did not export HyroxData via module.exports or global HyroxData');
}

const HyroxData = loadHyroxData();
const STORAGE_KEY = HyroxData.STORAGE_KEY || 'hyrox.v1';
const RECOVERY_KEY = HyroxData.RECOVERY_KEY || 'hyrox.v1.corrupt-backup';
const PRE_IMPORT_KEY = 'hyrox.v1.pre-import-backup';

// Fixed clock: 2026-11-10 15:00 in Asia/Qatar (UTC+3).
const FIXED_NOW = new Date('2026-11-10T12:00:00.000Z');
const TODAY = '2026-11-10';

function memoryStorage(seed) {
  const m = Object.assign({}, seed);
  return {
    _m: m,
    getItem(k) {
      return Object.prototype.hasOwnProperty.call(m, k) ? m[k] : null;
    },
    setItem(k, v) {
      m[k] = String(v);
    },
    removeItem(k) {
      delete m[k];
    },
  };
}

function hookStorage(base, hooks) {
  return {
    getItem(k) {
      if (hooks.getItem) return hooks.getItem(k, () => base.getItem(k));
      return base.getItem(k);
    },
    setItem(k, v) {
      if (hooks.setItem) return hooks.setItem(k, v, () => base.setItem(k, v));
      return base.setItem(k, v);
    },
    removeItem(k) {
      if (hooks.removeItem) return hooks.removeItem(k, () => base.removeItem && base.removeItem(k));
      if (base.removeItem) return base.removeItem(k);
      return undefined;
    },
  };
}

function makeStore(storage, now) {
  const clock = now === undefined ? FIXED_NOW : now;
  return HyroxData.createStore(storage, { now: () => (clock instanceof Date ? clock : new Date(clock)) });
}

function requireImport(store) {
  assert.equal(typeof store.previewImport, 'function', 'previewImport is required (Phase 2 data layer)');
  assert.equal(typeof store.applyImport, 'function', 'applyImport is required (Phase 2 data layer)');
}

function goodBackup(overrides) {
  return Object.assign(
    {
      app: 'hyrox-app',
      exportedAt: '2026-11-10T12:00:00.000Z',
      version: 1,
      weight: [{ id: 'w-test-1', createdAt: '2026-11-10T10:00:00.000Z', date: TODAY, kg: 72.5 }],
      workouts: [
        {
          id: 'wo-full-1',
          createdAt: '2026-11-10T10:01:00.000Z',
          date: TODAY,
          activity: 'SkiErg intervals',
          durationMin: 45,
          partial: false,
          notes: 'Made-up session',
        },
        {
          id: 'wo-part-1',
          createdAt: '2026-11-10T10:02:00.000Z',
          date: TODAY,
          activity: 'Half sim',
          durationMin: 20,
          partial: true,
          notes: '',
        },
      ],
      nutrition: [
        {
          id: 'n-oats-1',
          createdAt: '2026-11-10T10:03:00.000Z',
          date: TODAY,
          label: 'Test oats',
          calories: 350,
          proteinG: 22.5,
        },
      ],
    },
    overrides
  );
}

function textOf(backup) {
  return typeof backup === 'string' ? backup : JSON.stringify(backup);
}

function currentCounts(store) {
  return {
    weight: store.list('weight').length,
    workouts: store.list('workouts').length,
    nutrition: store.list('nutrition').length,
  };
}

// Binding contract: warnings is a string[] (empty when none);
// preview.current / expectCurrent are {weight, workouts, nutrition} count objects.
function assertWarnings(value) {
  assert.ok(Array.isArray(value), 'warnings must be an array, got ' + typeof value);
  for (const w of value) {
    assert.equal(typeof w, 'string', 'warnings entries must be strings, got ' + typeof w);
  }
}

function assertCountObject(obj, label) {
  assert.equal(typeof obj, 'object', label + ' must be an object');
  assert.ok(obj && !Array.isArray(obj), label + ' must be a plain count object');
  for (const key of ['weight', 'workouts', 'nutrition']) {
    assert.equal(typeof obj[key], 'number', label + '.' + key + ' must be a number');
  }
  assert.deepEqual(Object.keys(obj).sort(), ['nutrition', 'weight', 'workouts']);
}

function assertOkPreview(res) {
  assert.equal(res && res.ok, true, 'expected preview ok:true, got ' + JSON.stringify(res));
  assertWarnings(res.preview.warnings);
  assertCountObject(res.preview.current, 'preview.current');
  return res.preview;
}

function applyReplace(store, backup, expectCurrent) {
  return store.applyImport(textOf(backup), {
    confirm: 'REPLACE',
    expectCurrent: expectCurrent || currentCounts(store),
  });
}

function assertNotOk(res) {
  assert.equal(res && res.ok, false, 'expected ok:false, got ' + JSON.stringify(res));
  return res;
}

function assertLiveIsNotEnvelope(storage, label) {
  const raw = storage.getItem(STORAGE_KEY);
  if (raw == null) return;
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (e) {
    return; // corrupt raw is allowed to remain corrupt
  }
  assert.notEqual(
    parsed && parsed.kind,
    'hyrox-pre-import',
    (label || 'hyrox.v1') + ' must not hold the pre-import envelope, got ' + raw.slice(0, 200)
  );
}

function unwrapPreImport(storage) {
  const wrapped = storage.getItem(PRE_IMPORT_KEY);
  assert.ok(wrapped != null, 'expected a pre-import slot');
  const parsed = JSON.parse(wrapped);
  assert.equal(parsed.kind, 'hyrox-pre-import');
  return parsed;
}

function seedGoodLive(storage) {
  const live = {
    version: 1,
    weight: [{ id: 'live-w', createdAt: '2026-11-09T08:00:00.000Z', date: '2026-11-09', kg: 80 }],
    workouts: [],
    nutrition: [],
  };
  const raw = JSON.stringify(live);
  storage.setItem(STORAGE_KEY, raw);
  return raw;
}

describe('import API presence', () => {
  it('exposes previewImport and applyImport on a store', () => {
    const store = makeStore(memoryStorage());
    requireImport(store);
  });
});

describe('previewImport is read-only', () => {
  it('makes zero setItem calls on valid and invalid input', () => {
    const base = memoryStorage();
    const prior = seedGoodLive(base);
    let sets = 0;
    const storage = hookStorage(base, {
      setItem(k, v, pass) {
        sets += 1;
        return pass();
      },
    });
    const store = makeStore(storage);
    requireImport(store);
    const okPrev = assertOkPreview(store.previewImport(textOf(goodBackup())));
    assert.deepEqual(okPrev.warnings, []);
    assert.deepEqual(okPrev.current, { weight: 1, workouts: 0, nutrition: 0 });
    assert.equal(store.previewImport('{not-json').ok, false);
    assert.equal(store.previewImport(textOf(goodBackup({ version: 3 }))).ok, false);
    assert.equal(sets, 0);
    assert.equal(base.getItem(STORAGE_KEY), prior);
  });
});

describe('setItem failures and quota: no false ok:true, live data intact', () => {
  it('a throw when writing the pre-import slot returns backup_failed and leaves hyrox.v1 unchanged', () => {
    const base = memoryStorage();
    const prior = seedGoodLive(base);
    const storage = hookStorage(base, {
      setItem(k, v, pass) {
        if (k === PRE_IMPORT_KEY) {
          const err = new Error('QuotaExceededError');
          err.name = 'QuotaExceededError';
          throw err;
        }
        return pass();
      },
    });
    const store = makeStore(storage);
    requireImport(store);
    const res = assertNotOk(applyReplace(store, goodBackup()));
    assert.equal(res.code, 'backup_failed');
    assert.equal(base.getItem(STORAGE_KEY), prior);
    assertLiveIsNotEnvelope(base, 'after backup_failed');
    assert.equal(store.list('weight')[0].kg, 80);
  });

  it('a throw when writing hyrox.v1 rolls back to the UNWRAPPED previous raw, never the envelope', () => {
    const base = memoryStorage();
    const prior = seedGoodLive(base);
    const storage = hookStorage(base, {
      setItem(k, v, pass) {
        if (k === STORAGE_KEY) {
          const err = new Error('QuotaExceededError');
          err.name = 'QuotaExceededError';
          throw err;
        }
        return pass();
      },
    });
    const store = makeStore(storage);
    const res = assertNotOk(applyReplace(store, goodBackup()));
    assert.notEqual(res.code, undefined);
    assert.notEqual(res.ok, true);
    assert.equal(base.getItem(STORAGE_KEY), prior);
    assertLiveIsNotEnvelope(base, 'after write throw');
    assert.equal(JSON.parse(base.getItem(STORAGE_KEY)).weight[0].kg, 80);
  });

  it('an interrupted restore (setItem writes then throws) rolls back unwrapped raw, not the envelope', () => {
    const base = memoryStorage();
    const prior = seedGoodLive(base);
    const storage = hookStorage(base, {
      setItem(k, v, pass) {
        if (k === STORAGE_KEY) {
          pass(); // write happens, then crash — the rollback path must undo this
          throw new Error('interrupted mid-write');
        }
        return pass();
      },
    });
    const store = makeStore(storage);
    const res = assertNotOk(applyReplace(store, goodBackup()));
    assert.notEqual(res.ok, true);
    assert.equal(base.getItem(STORAGE_KEY), prior, 'live key must equal the original unwrapped raw');
    assertLiveIsNotEnvelope(base, 'after interrupted write');
    const slot = base.getItem(PRE_IMPORT_KEY);
    if (slot != null) {
      const env = JSON.parse(slot);
      assert.equal(env.kind, 'hyrox-pre-import');
      assert.equal(env.raw, prior);
    }
  });

  it('a silently truncated hyrox.v1 write (every write, including rollback) returns rollback_failed and keeps prior raw in the pre-import slot', () => {
    const base = memoryStorage();
    const prior = seedGoodLive(base);
    const storage = hookStorage(base, {
      setItem(k, v, pass) {
        if (k === STORAGE_KEY) return base.setItem(k, String(v).slice(0, 10));
        return pass();
      },
    });
    const store = makeStore(storage);
    const res = assertNotOk(applyReplace(store, goodBackup()));
    assert.equal(res.code, 'rollback_failed');
    assert.equal(res.rolledBack, false);
    assert.equal(res.backupKey, PRE_IMPORT_KEY);
    const env = unwrapPreImport(base);
    assert.equal(env.raw, prior);
  });

  it('a silently truncated first hyrox.v1 write (rollback intact) returns rolledBack true and restores unwrapped prior', () => {
    const base = memoryStorage();
    const prior = seedGoodLive(base);
    let mainWrites = 0;
    const storage = hookStorage(base, {
      setItem(k, v, pass) {
        if (k === STORAGE_KEY) {
          mainWrites += 1;
          if (mainWrites === 1) return base.setItem(k, String(v).slice(0, 10));
        }
        return pass();
      },
    });
    const store = makeStore(storage);
    const res = assertNotOk(applyReplace(store, goodBackup()));
    assert.equal(res.ok, false);
    assert.equal(res.rolledBack, true);
    assert.equal(base.getItem(STORAGE_KEY), prior);
    assertLiveIsNotEnvelope(base, 'after first-write truncate');
  });

  it('when prior storage was empty (raw null), a failed apply leaves hyrox.v1 absent — not an envelope and not the string "null"', () => {
    const base = memoryStorage();
    const storage = hookStorage(base, {
      setItem(k, v, pass) {
        if (k === STORAGE_KEY) throw new Error('QuotaExceededError');
        return pass();
      },
    });
    const store = makeStore(storage);
    requireImport(store);
    const preview = assertOkPreview(store.previewImport(textOf(goodBackup())));
    assert.deepEqual(preview.current, { weight: 0, workouts: 0, nutrition: 0 });
    const res = assertNotOk(
      store.applyImport(textOf(goodBackup()), { confirm: 'REPLACE', expectCurrent: preview.current })
    );
    assert.notEqual(res.ok, true);
    const live = base.getItem(STORAGE_KEY);
    assert.ok(live == null || live === '', 'expected hyrox.v1 removed or empty, got ' + JSON.stringify(live));
    assertLiveIsNotEnvelope(base, 'empty-prior failed apply');
  });
});

describe('successful import envelope stays off the live key', () => {
  it('stores the wrapped pre-import slot, and hyrox.v1 is the new v1 object not the envelope', () => {
    const base = memoryStorage();
    const prior = seedGoodLive(base);
    const store = makeStore(base);
    requireImport(store);
    const preview = assertOkPreview(store.previewImport(textOf(goodBackup())));
    assert.deepEqual(preview.warnings, []);
    const res = applyReplace(store, goodBackup(), preview.current);
    assert.equal(res.ok, true, JSON.stringify(res));
    assert.equal(res.backupKey, PRE_IMPORT_KEY);
    assert.deepEqual(res.counts, { weight: 1, workouts: 2, nutrition: 1 });
    assertLiveIsNotEnvelope(base, 'after success');
    const live = JSON.parse(base.getItem(STORAGE_KEY));
    assert.equal(live.version, 1);
    assert.equal(live.weight[0].kg, 72.5);
    const env = unwrapPreImport(base);
    assert.equal(env.raw, prior);
    assert.equal(typeof env.savedAt, 'string');
  });
});

describe('corrupt prior storage', () => {
  it('a valid REPLACE succeeds; pre-import raw is the corrupt text; an existing corrupt-backup is untouched', () => {
    const corruptRaw = '{"version":1,"weight":[{"id":"a","date":"2026-11-01","kg":80}';
    const existingRecovery = '{first-break';
    const base = memoryStorage({
      [STORAGE_KEY]: corruptRaw,
      [RECOVERY_KEY]: existingRecovery,
    });
    const store = makeStore(base);
    requireImport(store);
    assert.equal(store.status().state, 'corrupt');
    const preview = assertOkPreview(store.previewImport(textOf(goodBackup())));
    const res = store.applyImport(textOf(goodBackup()), {
      confirm: 'REPLACE',
      expectCurrent: preview.current,
    });
    assert.equal(res.ok, true, JSON.stringify(res));
    assert.equal(base.getItem(RECOVERY_KEY), existingRecovery);
    const env = unwrapPreImport(base);
    assert.equal(env.raw, corruptRaw);
    assertLiveIsNotEnvelope(base, 'after replace over corrupt');
    assert.equal(store.list('weight')[0].kg, 72.5);
    assert.equal(makeStore(base).list('workouts').length, 2);
  });
});

describe('duplicate ids and repeat import', () => {
  it('duplicate ids within a list reject the whole file and leave live data unchanged', () => {
    const base = memoryStorage();
    const prior = seedGoodLive(base);
    const store = makeStore(base);
    requireImport(store);
    const dup = goodBackup({
      weight: [
        { id: 'same-id', createdAt: '2026-11-10T10:00:00.000Z', date: TODAY, kg: 72.5 },
        { id: 'same-id', createdAt: '2026-11-10T10:04:00.000Z', date: TODAY, kg: 73 },
      ],
    });
    const preview = store.previewImport(textOf(dup));
    assert.equal(preview.ok, false);
    assert.equal(preview.code, 'duplicate_ids');
    const res = assertNotOk(applyReplace(store, dup));
    assert.equal(res.code, 'duplicate_ids');
    assert.equal(base.getItem(STORAGE_KEY), prior);
  });

  it('importing the same file twice (REPLACE) does not double entries', () => {
    const base = memoryStorage();
    seedGoodLive(base);
    const store = makeStore(base);
    requireImport(store);
    const file = goodBackup();
    const first = applyReplace(store, file);
    assert.equal(first.ok, true, JSON.stringify(first));
    const second = applyReplace(store, file);
    assert.equal(second.ok, true, JSON.stringify(second));
    assert.deepEqual(second.counts, { weight: 1, workouts: 2, nutrition: 1 });
    assert.equal(store.list('weight').length, 1);
    assert.equal(store.list('workouts').length, 2);
    assert.equal(store.list('nutrition').length, 1);
    assert.equal(store.list('workouts').filter((w) => w.partial).length, 1);
  });
});

describe('restore date rule: max(todayQatar(), Qatar date of exportedAt), fixed clock', () => {
  // Fixed now is 2026-11-10T12:00Z → todayQatar() is 2026-11-10.
  // 2026-11-11T08:00Z is 11 Nov 11:00 in Qatar.

  it('accepts a date equal to the Qatar date of exportedAt even when that is after todayQatar()', () => {
    const store = makeStore(memoryStorage());
    requireImport(store);
    const file = goodBackup({
      exportedAt: '2026-11-11T08:00:00.000Z',
      weight: [{ id: 'w-future-ok', createdAt: '2026-11-11T08:00:00.000Z', date: '2026-11-11', kg: 72.5 }],
    });
    const preview = assertOkPreview(store.previewImport(textOf(file)));
    const res = applyReplace(store, file, preview.current);
    assert.equal(res.ok, true, JSON.stringify(res));
    assert.equal(store.list('weight')[0].date, '2026-11-11');
  });

  it('rejects a date after both todayQatar() and the Qatar date of exportedAt', () => {
    const base = memoryStorage();
    const prior = seedGoodLive(base);
    const store = makeStore(base);
    const file = goodBackup({
      exportedAt: '2026-11-11T08:00:00.000Z',
      weight: [{ id: 'w-too-late', createdAt: '2026-11-12T08:00:00.000Z', date: '2026-11-12', kg: 72.5 }],
    });
    const preview = store.previewImport(textOf(file));
    assert.equal(preview.ok, false);
    assert.equal(preview.code, 'invalid_records');
    const res = assertNotOk(applyReplace(store, file));
    assert.equal(res.code, 'invalid_records');
    assert.equal(base.getItem(STORAGE_KEY), prior);
  });

  it('rejects an impossible calendar date (2026-02-30)', () => {
    const store = makeStore(memoryStorage());
    const file = goodBackup({
      weight: [{ id: 'w-bad-cal', createdAt: '2026-11-10T10:00:00.000Z', date: '2026-02-30', kg: 72.5 }],
    });
    const preview = store.previewImport(textOf(file));
    assert.equal(preview.ok, false);
    assert.equal(preview.code, 'invalid_records');
  });

  it('when exportedAt is missing or not a valid ISO date, the ceiling is todayQatar()', () => {
    const store = makeStore(memoryStorage());
    const missing = goodBackup({ exportedAt: undefined });
    delete missing.exportedAt;
    missing.weight = [{ id: 'w-no-exp', createdAt: '2026-11-11T08:00:00.000Z', date: '2026-11-11', kg: 72.5 }];
    const p1 = store.previewImport(textOf(missing));
    assert.equal(p1.ok, false);
    assert.equal(p1.code, 'invalid_records');

    const badExp = goodBackup({
      exportedAt: 'not-a-date',
      weight: [{ id: 'w-bad-exp', createdAt: '2026-11-11T08:00:00.000Z', date: '2026-11-11', kg: 72.5 }],
    });
    const p2 = store.previewImport(textOf(badExp));
    assert.equal(p2.ok, false);
    assert.equal(p2.code, 'invalid_records');
  });
});

describe('applyImport confirmation and stale plan', () => {
  it('returns not_confirmed and writes nothing when confirm is not REPLACE', () => {
    const base = memoryStorage();
    const prior = seedGoodLive(base);
    const store = makeStore(base);
    requireImport(store);
    const res = assertNotOk(store.applyImport(textOf(goodBackup()), { confirm: 'nope', expectCurrent: currentCounts(store) }));
    assert.equal(res.code, 'not_confirmed');
    assert.equal(base.getItem(STORAGE_KEY), prior);
  });

  it('returns stale_plan when expectCurrent does not match current counts', () => {
    const base = memoryStorage();
    const prior = seedGoodLive(base);
    const store = makeStore(base);
    const res = assertNotOk(
      store.applyImport(textOf(goodBackup()), {
        confirm: 'REPLACE',
        expectCurrent: { weight: 0, workouts: 0, nutrition: 0 },
      })
    );
    assert.equal(res.code, 'stale_plan');
    assert.equal(base.getItem(STORAGE_KEY), prior);
  });
});
