'use strict';
// P4 (Meron): further bypass hunt against Dawit's 9e9f2e1 rawMarker (depth-3 wrappers,
// top-level leftover markers, core-entry sources, key normalization). Not P4-L1:
// a file stripped of every recovery marker, or a Cyrillic/un-folded look-alike with
// every other marker removed, is not filed as a defect. Synthetic data only.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const { HD, KEY, PRE, mem, mk, O, ts, backup } = require('./p3-helpers.js');

const D = '2026-11-10';
const snapAll = (s) => JSON.stringify(Object.keys(s.m).sort().map((k) => [k, s.m[k]]));

function liveDevice() {
  const s = mem();
  const st = mk(s);
  assert.equal(st.addWeight({ date: D, kg: 80 }).ok, true);
  assert.equal(st.putRecord('walks', { date: D, durationMin: 30, steps: 3000 }).ok, true);
  const p = st.previewImport(st.exportJSON());
  assert.equal(p.ok, true);
  return { s, st, current: p.preview.current, currentExt: p.preview.currentExt, before: snapAll(s), writes: s.writes };
}

function emptyCore(extra) {
  return Object.assign({
    app: 'hyrox-app', version: 2, exportedAt: ts,
    weight: [], workouts: [], nutrition: [],
  }, extra || {});
}

function sourcesCopies() {
  return [{ key: 'hyrox.v1', raw: '{"version":2,"weight":[],"workouts":[],"nutrition":[]}', length: 54, checksum: 'deadbeef' }];
}

// Both paths; a refusal must write nothing and leave live data byte-identical.
function refusedBoth(text, expectCode) {
  const { s, st, current, currentExt, before, writes } = liveDevice();
  const p = st.previewImport(text);
  assert.equal(p.ok, false, 'previewImport must refuse: ' + JSON.stringify(p));
  if (expectCode) assert.equal(p.code, expectCode);
  assert.equal(s.writes, writes, 'preview writes nothing');
  assert.equal(snapAll(s), before);
  const a = st.applyImport(text, { confirm: 'REPLACE', expectCurrent: current, expectCurrentExt: currentExt });
  assert.equal(a.ok, false, 'direct applyImport must refuse: ' + JSON.stringify(a));
  if (expectCode) assert.equal(a.code, expectCode);
  assert.equal(s.writes, writes, 'apply writes nothing');
  assert.equal(snapAll(s), before);
  assert.equal(Object.prototype.hasOwnProperty.call(s.m, PRE), false);
  assert.equal(st.list('weight').length, 1);
  assert.equal(st.list('weight')[0].kg, 80);
  assert.equal(st.records('walks').length, 1);
  return { p, a };
}

// Used by DEFECT tests: the file MUST be refused. If it is accepted, live data was at risk.
function assertWipesOrReplaces(text) {
  const { s, st, current, currentExt, before, writes } = liveDevice();
  const p = st.previewImport(text);
  assert.equal(p.ok, false, 'previewImport must refuse an edited emergency file; got ' + JSON.stringify(p));
  assert.equal(p.code, 'raw_recovery_file');
  const a = st.applyImport(text, { confirm: 'REPLACE', expectCurrent: current, expectCurrentExt: currentExt });
  assert.equal(a.ok, false, 'applyImport (direct) must refuse an edited emergency file; got ' + JSON.stringify(a));
  assert.equal(a.code, 'raw_recovery_file');
  assert.equal(s.writes, writes);
  assert.equal(snapAll(s), before);
  assert.equal(st.list('weight').length, 1);
  assert.equal(st.list('weight')[0].kg, 80);
}

describe('P4 further-bypass holds (9e9f2e1): refusals write nothing; type / wrapper / key tricks that are already covered', () => {
  it('NFKC fullwidth, soft-hyphen, ideographic space, and narrow nbsp around a sources-like key are refused on both paths; nothing written', () => {
    refusedBoth(JSON.stringify(emptyCore({ '\uFF53\uFF4F\uFF55\uFF52\uFF43\uFF45\uFF53': sourcesCopies() })), 'raw_recovery_file');
    refusedBoth(JSON.stringify(emptyCore({ 'SOUR\u00ADCES': sourcesCopies() })), 'raw_recovery_file');
    refusedBoth(JSON.stringify(emptyCore({ '\u3000sources\u3000': sourcesCopies() })), 'raw_recovery_file');
    refusedBoth(JSON.stringify(emptyCore({ '\u202Fsources': sourcesCopies() })), 'raw_recovery_file');
  });

  it('a unicode-escaped sources key and a duplicate JSON sources key (last value still sources) are refused; nothing written', () => {
    refusedBoth('{"app":"hyrox-app","version":2,"exportedAt":"' + ts + '","weight":[],"workouts":[],"nutrition":[],"\\u0073ources":[]}', 'raw_recovery_file');
    const text = '{"app":"hyrox-app","version":2,"exportedAt":"' + ts + '","weight":[],"workouts":[],"nutrition":[],"sources":null,"sources":[]}';
    refusedBoth(text, 'raw_recovery_file');
  });

  it('constructor.prototype.sources under a top-level wrapper is refused (depth <= 3); nothing written', () => {
    refusedBoth(JSON.stringify(emptyCore({ constructor: { prototype: { sources: sourcesCopies() } } })), 'raw_recovery_file');
  });

  it('an array root (even one that wraps a raw envelope) is refused as not_hyrox and writes nothing', () => {
    refusedBoth(JSON.stringify([emptyCore({ sources: sourcesCopies() })]), 'not_hyrox');
    refusedBoth(JSON.stringify([{ app: 'hyrox-raw-recovery', kind: 'hyrox-raw-recovery', format: 1, sources: sourcesCopies() }]), 'not_hyrox');
  });

  it('type confusion on app/version/kind does not bypass a present marker, and writes nothing when there is no marker either', () => {
    refusedBoth(JSON.stringify(emptyCore({ app: ['hyrox-app'], version: { n: 2 }, warning: 'x' })), 'raw_recovery_file');
    refusedBoth(JSON.stringify(emptyCore({ version: null, sources: sourcesCopies() })), 'raw_recovery_file');
    refusedBoth(JSON.stringify(emptyCore({ kind: true, omitted: {} })), 'raw_recovery_file');
    refusedBoth(JSON.stringify(emptyCore({ app: ['hyrox-app'] })), 'not_hyrox');
  });

  it('a huge/deep nest (iterative, no recursion in the test) with a genuine weight list either restores or refuses; a throw or hang must fail closed and write nothing', () => {
    const nest = (n, leaf) => '{"n":'.repeat(n) + JSON.stringify(leaf) + '}'.repeat(n);
    const weight = [{ id: 'n1', createdAt: ts, date: D, kg: 79 }];
    const text = JSON.stringify(Object.assign(emptyCore({ weight: weight }), { deep: JSON.parse(nest(4000, { v: 1 })) }));
    const { s, st, current, currentExt, before, writes } = liveDevice();
    let p, a, threw = null;
    const t0 = Date.now();
    try { p = st.previewImport(text); } catch (e) { threw = e; }
    const elapsed = Date.now() - t0;
    assert.ok(elapsed < 5000, 'previewImport hung on a 4000-deep nest (' + elapsed + 'ms)');
    if (threw) {
      assert.equal(s.writes, writes, 'a throw must fail closed (preview wrote nothing)');
      assert.equal(snapAll(s), before);
    } else {
      if (p.ok === false) {
        assert.equal(s.writes, writes);
        assert.equal(snapAll(s), before);
      } else {
        a = st.applyImport(text, { confirm: 'REPLACE', expectCurrent: current, expectCurrentExt: currentExt });
        assert.equal(a.ok, true, 'accepted path must restore, not silently fail: ' + JSON.stringify(a));
        assert.equal(st.list('weight')[0].kg, 79);
      }
    }
    // Apply on a fresh live device too, including the throw path.
    const live2 = liveDevice();
    let threw2 = null;
    try {
      const a2 = live2.st.applyImport(text, { confirm: 'REPLACE', expectCurrent: live2.current, expectCurrentExt: live2.currentExt });
      if (!a2.ok) {
        assert.equal(live2.s.writes, live2.writes);
        assert.equal(snapAll(live2.s), live2.before);
      } else {
        assert.equal(live2.st.list('weight')[0].kg, 79);
      }
    } catch (e) {
      threw2 = e;
      assert.equal(live2.s.writes, live2.writes, 'a throw on apply must fail closed and write nothing');
      assert.equal(snapAll(live2.s), live2.before);
      assert.equal(live2.st.list('weight')[0].kg, 80);
    }
    void threw2;
  });
});

describe('DEFECT: an edited emergency raw file can still replace live data when sources is buried deeper than 3 wrapper levels or hidden in an array wrapper', () => {
  it('moving sources to depth 4 (or deeper) still wipes live data; this must be refused', () => {
    const copies = sourcesCopies();
    assertWipesOrReplaces(JSON.stringify(emptyCore({ a: { b: { c: { d: { sources: copies } } } } })));
    assertWipesOrReplaces(JSON.stringify(emptyCore({ a: { b: { c: { d: { e: { sources: copies } } } } } })));
  });

  it('hiding sources inside an array wrapper (the scanner only walks plain objects) still wipes live data; this must be refused', () => {
    const copies = sourcesCopies();
    assertWipesOrReplaces(JSON.stringify(emptyCore({ wrapper: [{ sources: copies }] })));
    assertWipesOrReplaces(JSON.stringify(emptyCore({ meta: { list: [{ sources: copies }] } })));
  });
});

describe('DEFECT: leftover emergency markers moved off the top level (warning, normalExport, omitted, format+state) still let an edited raw file replace live data', () => {
  it('moving warning, normalExport, or omitted under a wrapper or into an array still wipes live data; this must be refused', () => {
    assertWipesOrReplaces(JSON.stringify(emptyCore({ wrapper: { warning: 'This is NOT a normal backup. It is an emergency raw recovery copy.' } })));
    assertWipesOrReplaces(JSON.stringify(emptyCore({ meta: { deep: { normalExport: 'complete' } } })));
    assertWipesOrReplaces(JSON.stringify(emptyCore({ x: { omitted: { daily: 1 } } })));
    assertWipesOrReplaces(JSON.stringify(emptyCore({ wrapper: [{ warning: 'NOT a normal backup' }] })));
  });

  it('moving the format+state combination under a wrapper still wipes live data; this must be refused', () => {
    assertWipesOrReplaces(JSON.stringify(emptyCore({ x: { format: 1, state: { note: 'raw' } } })));
  });
});

describe('DEFECT: planting the emergency sources copies on a Phase 3 record and emptying the core lists still replaces live data', () => {
  // Dawit DECLINED a blanket refusal of any Phase 3 field named "sources", because
  // putRecord stores unknown fields and exportJSON writes them back (a genuine walk
  // with sources: ['x'] must be accepted). This DEFECT is narrower: the emergency
  // copies themselves (array of {key, raw, checksum, length}) are planted on a
  // Phase 3 record and the core lists are emptied. A shape-aware check would close
  // this without false-refusing sources: ['x'].
  it('an emergency-shaped sources array on daily, walks, body, dayStates, or a valid photo meal, with empty core lists, still wipes live data; this must be refused', () => {
    const copies = sourcesCopies();
    assertWipesOrReplaces(JSON.stringify(emptyCore({
      daily: [{ id: 'd1', createdAt: ts, date: D, steps: { state: 'OBSERVED', value: 1 }, sources: copies }],
    })));
    assertWipesOrReplaces(JSON.stringify(emptyCore({
      walks: [{ id: 'w1', createdAt: ts, date: D, durationMin: 30, sources: copies }],
    })));
    assertWipesOrReplaces(JSON.stringify(emptyCore({
      body: [{ id: 'b1', createdAt: ts, date: D, metric: 'waist_cm', state: 'OBSERVED', value: 90, sources: copies }],
    })));
    assertWipesOrReplaces(JSON.stringify(emptyCore({
      dayStates: [{ id: 'ds1', createdAt: ts, date: D, attestation: 'INCOMPLETE', basis: '0:x', sources: copies }],
    })));
    const meal = {
      id: 'm1', createdAt: ts, updatedAt: ts, date: D, label: 'Photo meal',
      source: 'PHOTO_AI', lifecycle: 'CONFIRMED', confirmedAt: ts, eatenFraction: 0.5,
      components: [{ name: 'Rice', role: 'SIDE', kcal: { value: 240, state: 'KNOWN' }, proteinG: { value: 5, state: 'KNOWN' },
        carbsG: { value: null, state: 'UNKNOWN' }, fatG: { value: 0, state: 'KNOWN' }, eatenFraction: 0.5 }],
      sources: copies,
    };
    assertWipesOrReplaces(JSON.stringify(emptyCore({ meals: [meal] })));
  });
});
