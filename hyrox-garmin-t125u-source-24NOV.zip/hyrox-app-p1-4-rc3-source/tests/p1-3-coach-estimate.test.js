'use strict';
// P1.3 Delivery C: Stage A starting estimate (Mifflin-St Jeor x activity), computed proposals with PROVISIONAL screens, Stage B
// personal estimate over aligned completed weeks, reduction and concern rules. Synthetic fixtures only; pure arithmetic, no network.
const test = require('node:test');
const assert = require('node:assert');
const path = require('path');
const fs = require('fs');
const HC = require(path.join(__dirname, '..', 'src', 'data', 'hyrox-coach.js'));

const TD = '2026-11-23'; // Monday (review day); last completed Mon-Sun review week is 16-22 Nov (re-pointed by independent review C2)
const P = (extra) => Object.assign({ heightCm: 178, heightUnit: 'cm', ageYears: 49, ageEnteredOn: '2026-11-01', ageConfirmedOn: '2026-11-01', estimateMethod: 'EQUATION', sexForEquation: 'MALE', activity: 'A2' }, extra || {});
const coach = (pExtra, more) => Object.assign(HC.emptyCoach(), { enabled: true, profile: P(pExtra) }, more || {});
const W = (date, kg) => ({ id: 'w' + date, date, kg, createdAt: date + 'T05:00:00.000Z' });
const add = HC.addDays;
// a synthetic 4-week history: weigh-ins on given weekdays (0=Sun), D5 days on given weekdays with fixed kcal, linear weight trend
function history({ weighDows = [0, 2, 4, 6], d5Dows = [0, 1, 2, 3, 4, 5, 6], kcal = 2300, startKg = 100, kgPerWeek = -0.35, est = 0, weeks = 4, override = {} } = {}) {
  const ws = HC.reviewWeeks(TD, weeks), from = ws[0].start, days = [], weights = [];
  for (let d = from; d <= HC.lastCompletedSunday(TD); d = add(d, 1)) {
    const dw = new Date(d + 'T00:00:00Z').getUTCDay(), t = HC.daysBetween(from, d);
    if (weighDows.includes(dw)) weights.push(W(d, Math.round((startKg + kgPerWeek * t / 7) * 1000) / 1000));
    const o = override[d];
    if (o) days.push(Object.assign({ date: d }, o));
    else days.push(d5Dows.includes(dw) ? { date: d, code: 'D5', kcal, estKcal: est } : { date: d, code: 'D2', kcal: null, estKcal: null });
  }
  return { days, weights };
}

test('P1.3 C: Mifflin-St Jeor matches the published form and the design worked example (synthetic 95 kg, 178 cm, 49 y, male -> 1,823)', () => {
  assert.strictEqual(HC.mifflin(95, 178, 49, 'MALE'), 1822.5);
  assert.strictEqual(Math.round(HC.mifflin(95, 178, 49, 'MALE')), 1823);
  assert.strictEqual(HC.mifflin(95, 178, 49, 'FEMALE'), 1822.5 - 166);
  assert.strictEqual(HC.mifflin(60, 165, 30, 'FEMALE'), 600 + 1031.25 - 150 - 161);
  for (const bad of [[NaN, 178, 49, 'MALE'], [95, 178, 49, null], [95, 178, 49, 'X'], [95, '178', 49, 'MALE']]) assert.strictEqual(HC.mifflin(...bad), null);
});

test('P1.3 C: Stage A uses recent valid dated weights only (mean of last 7 days, else latest within 14, else nothing) and never invents inputs', () => {
  const ws = [W('2026-11-17', 96), W('2026-11-19', 95), W('2026-11-21', 94), W('2026-11-30', 80) /* future: ignored */, { date: '2026-11-20', kg: NaN }, { date: 'bad', kg: 90 }];
  const r = HC.recentWeight(ws, TD);
  assert.deepStrictEqual([r.ok, r.kg, r.days, r.from, r.to, r.basis], [true, 95, 3, '2026-11-17', '2026-11-21', 'MEAN_7D']);
  // several weigh-ins on one day are one day of evidence
  assert.strictEqual(HC.recentWeight([W('2026-11-22', 90), W('2026-11-22', 92)], TD).days, 1);
  const l14 = HC.recentWeight([W('2026-11-01', 99), W('2026-11-12', 97)], TD);
  assert.deepStrictEqual([l14.ok, l14.kg, l14.basis], [true, 97, 'LATEST_14D']);
  const stale = HC.recentWeight([W('2026-11-09', 97)], TD);
  assert.deepStrictEqual([stale.ok, stale.code], [false, 'STALE']);
  assert.strictEqual(HC.recentWeight([], TD).code, 'NONE');
  const e = HC.startingEstimate(coach(), [W('2026-11-21', 95)], TD);
  assert.strictEqual(e.ok, true); assert.strictEqual(e.resting, 1823); assert.strictEqual(e.factor, 1.45);
  assert.strictEqual(e.maintenance, Math.round(1822.5 * 1.45)); // 2643: rounded once, at the end
  assert.strictEqual(e.approximate, true);
  const miss = HC.startingEstimate(coach({ sexForEquation: null, activity: null }), [W('2026-11-01', 95)], TD);
  assert.deepStrictEqual(miss.need, ['the sex used by the equation', 'usual activity', 'a weigh-in in the last 14 days']);
  assert.deepStrictEqual(HC.startingEstimate(coach({ ageConfirmedOn: '2025-11-01' }), [W('2026-11-21', 95)], TD).need, ['age confirmation (yearly)']);
  assert.strictEqual(HC.startingEstimate(coach({ estimateMethod: 'NONE' }), [W('2026-11-21', 95)], TD).code, 'NO_EQUATION');
});

test('P1.3 C: proposal arithmetic — goal offset, protein kept, fat 25 %, carbs = remainder rounded down; macros never exceed kcal', () => {
  const cur = { kcal: 2400, proteinG: 190, proteinFloorG: 170, origin: 'PROVISIONAL' };
  const p = HC.proposal({ maintenance: 2734, resting: 1823, source: 'STAGE_A', weightKg: 95, sex: 'MALE', goalId: 'LOSE_1', current: cur, concerns: [] });
  assert.strictEqual(p.state, 'AVAILABLE');
  assert.deepStrictEqual(p.target, { kcal: 2234, proteinG: 190, fatG: 62, carbsG: 229 }); // fat round(2234*0.25/9)=62; carbs floor((2234-760-558)/4)=229
  assert.ok(HC.macroKcal(p.target) <= p.target.kcal);
  for (let k = 1000; k <= 6000; k += 37) for (const pr of [0, 120, 190, 300]) {
    const m = HC.macrosFor(k, pr); if (m.carbsG >= 0) assert.ok(HC.macroKcal(m) <= k, k + '/' + pr);
  }
  const mt = HC.proposal({ maintenance: 2734, resting: 1823, weightKg: 95, sex: 'MALE', goalId: 'MAINTAIN', current: cur, concerns: [] });
  assert.strictEqual(mt.target.kcal, 2734);
  const gn = HC.proposal({ maintenance: 2734, resting: 1823, weightKg: 95, sex: 'MALE', goalId: 'GAIN_1', current: cur, concerns: [] });
  assert.strictEqual(gn.target.kcal, 3234);
  assert.strictEqual(HC.proposal({ maintenance: 2734, goalId: null }).state, 'NEEDS_INPUT');
});

test('P1.3 C: PROVISIONAL screens withhold computed suggestions and name the rule; LOSE_2 is never computed; entered targets stay possible', () => {
  const cur = { kcal: 2400, proteinG: 190, origin: 'PROVISIONAL' };
  const base = { resting: 1823, weightKg: 95, sex: 'MALE', current: cur, concerns: [] };
  const l2 = HC.proposal(Object.assign({ maintenance: 2734, goalId: 'LOSE_2' }, base));
  assert.strictEqual(l2.state, 'GATED'); assert.ok(l2.gates.some((g) => g.id === 'G-RATE'));
  assert.ok(l2.gates.some((g) => g.id === 'G-DEFICIT'), '1000/2734 = 37 % > 30 %');
  assert.ok(l2.gates.some((g) => g.id === 'G-FLOOR'), '1734 < resting 1823');
  assert.strictEqual(l2.gates.filter((g) => g.id === 'G-RATE').length, 1);
  // floor: female 1,200 vs resting; male 1,500
  const fl = HC.proposal({ maintenance: 1900, resting: 1300, weightKg: 70, sex: 'MALE', goalId: 'LOSE_1', current: cur, concerns: [] });
  assert.deepStrictEqual(fl.gates.map((g) => g.id).filter((x) => x === 'G-FLOOR'), ['G-FLOOR'], '1400 < 1500');
  const ff = HC.proposal({ maintenance: 1900, resting: 1300, weightKg: 70, sex: 'FEMALE', goalId: 'LOSE_1', current: { kcal: 1800, proteinG: 100 }, concerns: [] });
  assert.ok(!ff.gates.some((g) => g.id === 'G-FLOOR'), '1400 >= max(1200, 1300)');
  // deficit screen boundary: exactly 30 % passes, above is withheld
  assert.ok(!HC.proposal({ maintenance: 500 / 0.30, resting: 1000, weightKg: 200, sex: 'MALE', goalId: 'LOSE_1', current: cur, concerns: [] }).gates.some((g) => g.id === 'G-DEFICIT'));
  assert.ok(HC.proposal({ maintenance: 1666, resting: 1000, weightKg: 200, sex: 'MALE', goalId: 'LOSE_1', current: cur, concerns: [] }).gates.some((g) => g.id === 'G-DEFICIT'));
  // rate bands (D-R2 / D-R16): 0.5 % and 0.7 % preferred (no warning); above 0.7 % warned; above 1.0 % withheld
  const rate = (kg) => HC.proposal({ maintenance: 3000, resting: 1600, weightKg: kg, sex: 'MALE', goalId: 'LOSE_1', current: { kcal: 3000, proteinG: 150 }, concerns: [], reductionAllowed: true });
  const kgAt = (share) => HC.KG_PER_LB / share;
  assert.deepStrictEqual([rate(kgAt(0.005)).warnings.length, rate(kgAt(0.005)).state], [0, 'AVAILABLE']);
  assert.deepStrictEqual([rate(kgAt(0.007) + 0.01).warnings.length, rate(kgAt(0.007) + 0.01).state], [0, 'AVAILABLE']);
  assert.deepStrictEqual([rate(kgAt(0.0085)).warnings.length, rate(kgAt(0.0085)).state], [1, 'AVAILABLE']);
  assert.deepStrictEqual([rate(kgAt(0.01) + 0.01).state], ['AVAILABLE']);
  assert.ok(rate(kgAt(0.0101)).gates.some((g) => g.id === 'G-RATE'));
  // no silent low carbohydrate; impossible combinations flagged
  const lc = HC.proposal({ maintenance: 2000, resting: 1400, weightKg: 120, sex: 'MALE', goalId: 'LOSE_1', current: cur, concerns: [] });
  assert.deepStrictEqual(lc.gates.map((g) => g.id), ['LOW_CARB']); assert.strictEqual(lc.target.carbsG, 90);
  const imp = HC.proposal({ maintenance: 2000, resting: 1400, weightKg: 120, sex: 'MALE', goalId: 'MAINTAIN', current: { kcal: 2000, proteinG: 400 }, concerns: [] });
  assert.ok(imp.gates.some((g) => g.id === 'IMPOSSIBLE'));
});

test('P1.3 C: a lower computed target is HELD during a concern or until the weekly review allows it; a higher one is never held', () => {
  const cur = { kcal: 2600, proteinG: 190, origin: 'OWNER_ENTERED', effectiveDate: '2026-10-01' };
  const b = { maintenance: 2734, resting: 1823, weightKg: 95, sex: 'MALE', goalId: 'LOSE_1', current: cur };
  const c1 = HC.proposal(Object.assign({ concerns: ['Two or more readiness flags on 3 days last week.'] }, b));
  assert.deepStrictEqual([c1.state, c1.held.length], ['HELD', 1]);
  const c2 = HC.proposal(Object.assign({ concerns: [], reductionAllowed: false, reductionWhy: 'Needs 2 qualifying weeks.' }, b));
  assert.deepStrictEqual([c2.state, c2.held], ['HELD', ['Needs 2 qualifying weeks.']]);
  const up = HC.proposal(Object.assign({}, b, { current: { kcal: 2000, proteinG: 190 }, concerns: ['x'], reductionAllowed: false }));
  assert.strictEqual(up.state, 'AVAILABLE');
});

// Re-pointed by the independent review (C2, 23 Nov 2026): review weeks are Monday-Sunday, the plan's weeks.
test('P1.3 C: review weeks are completed Monday-Sunday weeks in Qatar dates; a Sunday never counts as complete on that Sunday', () => {
  assert.strictEqual(HC.lastCompletedSunday('2026-11-23'), '2026-11-22'); // Monday review covers the week that just ended
  assert.strictEqual(HC.lastCompletedSunday('2026-11-24'), '2026-11-22');
  assert.strictEqual(HC.lastCompletedSunday('2026-11-22'), '2026-11-15'); // Sunday itself is not finished
  assert.deepStrictEqual(HC.reviewWeeks('2026-11-23', 2), [{ start: '2026-11-09', end: '2026-11-15' }, { start: '2026-11-16', end: '2026-11-22' }]);
});

test('P1.3 C: Stage B reproduces the design arithmetic (2,300 kcal, -0.35 kg/week -> about 2,685) from aligned qualifying weeks only', () => {
  const { days, weights } = history();
  const sb = HC.stageB(days, weights, TD);
  assert.strictEqual(sb.ready, true);
  assert.strictEqual(sb.intakeMean, 2300);
  assert.ok(Math.abs(sb.slopeKgPerWeek + 0.35) < 0.001, String(sb.slopeKgPerWeek));
  assert.strictEqual(sb.maintenance, 2685);
  assert.strictEqual(sb.coverage, 'HIGH'); assert.strictEqual(sb.includedDays, 28); assert.strictEqual(sb.excludedDays, 0);
  assert.deepStrictEqual(sb.window, { from: '2026-10-26', to: '2026-11-22' }); // re-pointed: Monday-Sunday weeks (independent review C2)
  // the current, unfinished week never enters: days and weights after the last completed Sunday change nothing
  const late = HC.stageB(days.concat([{ date: '2026-11-23', code: 'D5', kcal: 9000, estKcal: 0 }]), weights.concat([W('2026-11-23', 60)]), TD);
  assert.strictEqual(late.maintenance, 2685);
});

test('P1.3 C: Stage B uses D5 only — D1-D4, pending and unknown days carry no intake; a confirmed fast is kept apart, never a D5', () => {
  const ov = {};
  ['2026-10-27', '2026-11-03', '2026-11-10', '2026-11-17'].forEach((d) => { ov[d] = { code: 'DF', kcal: null, estKcal: null }; });
  ['2026-10-28', '2026-11-04'].forEach((d) => { ov[d] = { code: 'D4', kcal: 999, estKcal: null }; }); // a stray figure on a non-D5 day is ignored
  ov['2026-11-05'] = { code: 'D2', kcal: 100, estKcal: null };
  const { days, weights } = history({ override: ov });
  const sb = HC.stageB(days, weights, TD);
  assert.strictEqual(sb.ready, true);
  assert.strictEqual(sb.intakeMean, 2300, 'only D5 kcal');
  assert.strictEqual(sb.fastDays, 4); assert.strictEqual(sb.includedDays, 21); assert.strictEqual(sb.excludedDays, 3);
  assert.strictEqual(sb.coverage, 'MEDIUM', 'one week has only 4 D5 days');
});

test('P1.3 C: Stage B gating — each shortfall alone keeps it from showing and is reported exactly; the first week is never extrapolated', () => {
  const two = history({ weighDows: [1, 4] });
  let sb = HC.stageB(two.days, two.weights, TD);
  assert.strictEqual(sb.ready, false); assert.strictEqual(sb.maintenance, undefined);
  assert.match(sb.text, /0 of 4 completed weeks qualify \(3 needed\)/);
  assert.strictEqual(sb.shortfall[0].text, '2 weigh-in days (3 needed)');
  const three = history({ d5Dows: [0, 1, 2] });
  sb = HC.stageB(three.days, three.weights, TD); assert.strictEqual(sb.ready, false); assert.strictEqual(sb.shortfall[0].text, '3 complete days (4 needed)');
  const weekday = history({ d5Dows: [1, 2, 3, 4, 5] });
  sb = HC.stageB(weekday.days, weekday.weights, TD); assert.strictEqual(sb.ready, false); assert.strictEqual(sb.shortfall[0].text, 'no complete weekend day (1 needed)');
  // weigh-in boundaries: 2 days excluded, 3 included
  assert.strictEqual(HC.stageB(history({ weighDows: [1, 3, 5] }).days, history({ weighDows: [1, 3, 5] }).weights, TD).ready, true);
  // 2 of 4 weeks good -> not ready
  const ov = {}; for (let d = '2026-10-25'; d <= '2026-11-07'; d = add(d, 1)) ov[d] = { code: 'D1', kcal: null, estKcal: null };
  const half = history({ override: ov });
  sb = HC.stageB(half.days, half.weights, TD); assert.deepStrictEqual([sb.ready, sb.qualifying], [false, 2]);
  // first week only (a new user): never a personal estimate, whatever the scale did
  const first = history({ kgPerWeek: -1.4 });
  const onlyLast = first.days.map((x) => (x.date < '2026-11-15' ? { date: x.date, code: 'D1', kcal: null, estKcal: null } : x));
  sb = HC.stageB(onlyLast, first.weights.filter((w) => w.date >= '2026-11-15'), TD);
  assert.deepStrictEqual([sb.ready, sb.qualifying], [false, 1]);
});

test('P1.3 C: Stage B reports the estimated share of kcal; missing days are never zero', () => {
  const { days, weights } = history({ est: 575 }); // 25 % of each D5 day estimated
  const sb = HC.stageB(days, weights, TD);
  assert.strictEqual(sb.estimatedShare, 25);
  const f = HC.weekFacts({ start: '2026-11-15', end: '2026-11-21' }, [{ date: '2026-11-15', code: 'D5', kcal: 2000, estKcal: 0 }], []);
  assert.deepStrictEqual([f.d5, f.kcalMean, f.excludedDays, f.meanKg], [1, 2000, 6, null], 'one day averages itself; 6 missing days are not zeros; no weekly weight mean without 3 days');
});

test('P1.3 C: reductions need 2 qualifying slow weeks under the current target, MEDIUM+ coverage and no concern', () => {
  const slow = history({ kgPerWeek: -0.1 });
  const sb = HC.stageB(slow.days, slow.weights, TD);
  const cur = { kcal: 2400, proteinG: 190, effectiveDate: '2026-10-20' };
  assert.deepStrictEqual(HC.reductionCheck(sb, 'LOSE_1', cur, []).allowed, true);
  assert.strictEqual(HC.reductionCheck(sb, 'LOSE_1', cur, ['Recovery flags']).allowed, false);
  assert.strictEqual(HC.reductionCheck(sb, 'MAINTAIN', cur, []).allowed, false);
  assert.match(HC.reductionCheck(sb, 'LOSE_1', { kcal: 2400, proteinG: 190, effectiveDate: '2026-11-10' }, []).why, /2 completed weeks under the current target/);
  const onTrack = history({ kgPerWeek: -0.45 });
  assert.match(HC.reductionCheck(HC.stageB(onTrack.days, onTrack.weights, TD), 'LOSE_1', cur, []).why, /not slower than half/);
  const thin = history({ weighDows: [1, 4] });
  assert.strictEqual(HC.reductionCheck(HC.stageB(thin.days, thin.weights, TD), 'LOSE_1', cur, []).allowed, false);
});

test('P1.3 C: concerns from the existing rules — rapid loss (amber >1 %/wk, red >1.5 %/wk for 2 weeks), low intake, recovery, pain, sessions', () => {
  const fast = history({ startKg: 100, kgPerWeek: -1.2 });
  let c = HC.concerns(HC.stageB(fast.days, fast.weights, TD), fast.days, {});
  assert.deepStrictEqual(c.map((x) => [x.code, x.level]), [['RAPID_LOSS', 'AMBER']]);
  const vfast = history({ startKg: 100, kgPerWeek: -1.7 });
  c = HC.concerns(HC.stageB(vfast.days, vfast.weights, TD), vfast.days, {});
  assert.deepStrictEqual(c.map((x) => [x.code, x.level]), [['RAPID_LOSS', 'RED']]);
  const ok = history({ startKg: 100, kgPerWeek: -0.5 });
  assert.deepStrictEqual(HC.concerns(HC.stageB(ok.days, ok.weights, TD), ok.days, {}), []);
  const low = history({ kcal: 1400 });
  c = HC.concerns(HC.stageB(low.days, low.weights, TD), low.days, { floorKcal: 1500 });
  assert.deepStrictEqual(c.map((x) => x.code), ['LOW_INTAKE']);
  // re-pointed (independent review C3): the sessions concern needs CONFIRMED skips among LOGGED planned slots
  c = HC.concerns(HC.stageB(ok.days, ok.weights, TD), ok.days, { recovery: { flagDays: 3, maxPain: 5, slots: { planned: 4, completed: 1, partial: 0, skipped: 3, unlogged: 0, omitted: 0 } } });
  assert.deepStrictEqual(c.map((x) => x.code), ['RECOVERY', 'PAIN', 'SESSIONS']);
  c = HC.concerns(HC.stageB(ok.days, ok.weights, TD), ok.days, { recovery: { flagDays: 2, maxPain: 4, slots: { planned: 4, completed: 2, partial: 0, skipped: 2, unlogged: 0, omitted: 0 } } });
  assert.deepStrictEqual(c, []);
  // one extreme weigh-in changes nothing
  const one = history({ kgPerWeek: 0 }); one.weights.push(W('2026-11-20', 90));
  assert.deepStrictEqual(HC.concerns(HC.stageB(one.days, one.weights, TD), one.days, {}), []);
});

test('P1.3 C: no expenditure is added — the coach module never reads workouts, steps or Garmin minutes', () => {
  const src = fs.readFileSync(path.join(__dirname, '..', 'src', 'data', 'hyrox-coach.js'), 'utf8').replace(/\/\*[\s\S]*?\*\/|\/\/.*$/gm, '').replace(/'(?:[^'\\]|\\.)*'/g, "''"); // code only, not wording
  assert.doesNotMatch(src, /\b(steps|intensityMin|workouts|sessions|durationMin|activeKcal|garmin)\b/i);
});
