'use strict';
// Phase 3 data-layer tests: extension collections, backward compatibility, backup round-trip, rollback.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const HD = require(path.resolve(__dirname, '../src/data/hyrox-data.js'));

const NOW = new Date('2026-11-11T09:00:00Z');
function mem(fail) {
  const m = {};
  return {
    m,
    getItem(k) { return Object.prototype.hasOwnProperty.call(m, k) ? m[k] : null; },
    setItem(k, v) { if (fail && fail(k, v)) throw new Error('QuotaExceeded'); m[k] = String(v); },
    removeItem(k) { delete m[k]; },
  };
}
const mk = (s) => HD.createStore(s, { now: () => NOW });
const U = { value: null, state: 'UNKNOWN' };
function meal(extra) {
  return Object.assign({ date: '2026-11-11', label: 'Synthetic lunch', source: 'MANUAL', lifecycle: 'CONFIRMED', confirmedAt: NOW.toISOString(),
    components: [{ name: 'Rice', role: 'SIDE', kcal: { value: 240, state: 'ESTIMATED' }, proteinG: { value: 5, state: 'ESTIMATED' }, carbsG: U, fatG: { value: 0, state: 'KNOWN' } }] }, extra || {});
}
function session(extra) {
  return Object.assign({ date: '2026-11-10', title: 'Intervals', status: 'PARTIAL', modified: true, variant: 'ORIGINAL_60', planSlotId: 'v2.1-W1-TUE',
    blocks: [{ kind: 'skierg', label: 'SkiErg', durationSec: 960, machine: true }, { kind: 'run', label: 'Run', distanceM: 400, durationSec: null }] }, extra || {});
}

describe('legacy compatibility', () => {
  it('legacy store/export is byte-compatible when no Phase 3 records exist', () => {
    const s = mem(); const st = mk(s);
    st.addWeight({ date: '2026-11-10', kg: 80 });
    assert.deepEqual(Object.keys(JSON.parse(s.m['hyrox.v1'])), ['version', 'weight', 'workouts', 'nutrition']);
    const exp = JSON.parse(st.exportJSON());
    assert.deepEqual(Object.keys(exp), ['app', 'exportedAt', 'version', 'weight', 'workouts', 'nutrition']);
  });
  it('a Phase 2 backup still imports and leaves no extension keys', () => {
    const s = mem(); const st = mk(s);
    const text = JSON.stringify({ app: 'hyrox-app', version: 1, exportedAt: NOW.toISOString(), weight: [{ id: 'w1', createdAt: NOW.toISOString(), date: '2026-11-10', kg: 80 }], workouts: [], nutrition: [] });
    const p = st.previewImport(text);
    assert.equal(p.ok, true); assert.equal(p.preview.extCounts, undefined);
    const r = st.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current });
    assert.equal(r.ok, true);
    assert.deepEqual(Object.keys(JSON.parse(s.m['hyrox.v1'])), ['version', 'weight', 'workouts', 'nutrition']);
  });
  it('adding Phase 3 records keeps legacy entries and unknown top-level fields', () => {
    const s = mem();
    s.m['hyrox.v1'] = JSON.stringify({ version: 1, weight: [{ id: 'a', createdAt: NOW.toISOString(), date: '2026-11-01', kg: 81 }], workouts: [], nutrition: [], futureField: { x: 1 } });
    const st = mk(s);
    assert.equal(st.putRecord('meals', meal()).ok, true);
    const stored = JSON.parse(s.m['hyrox.v1']);
    assert.deepEqual(stored.futureField, { x: 1 });
    assert.equal(stored.weight.length, 1);
    assert.equal(stored.meals.length, 1);
  });
});

describe('putRecord validation', () => {
  it('saves, reads back and lists a meal; UNKNOWN stays null', () => {
    const st = mk(mem());
    const r = st.putRecord('meals', meal());
    assert.equal(r.ok, true);
    const got = st.records('meals')[0];
    assert.equal(got.components[0].carbsG.value, null);
    assert.equal(got.components[0].fatG.value, 0);
    assert.equal(got.components[0].fatG.state, 'KNOWN');
  });
  it('rejects UNKNOWN with a number and KNOWN without a number', () => {
    const st = mk(mem());
    const bad1 = meal(); bad1.components[0].carbsG = { value: 0, state: 'UNKNOWN' };
    assert.equal(st.putRecord('meals', bad1).ok, false);
    const bad2 = meal(); bad2.components[0].kcal = { value: null, state: 'KNOWN' };
    assert.equal(st.putRecord('meals', bad2).ok, false);
  });
  it('CONFIRMED requires confirmedAt; DRAFT must not have it', () => {
    const st = mk(mem());
    assert.equal(st.putRecord('meals', meal({ confirmedAt: null })).ok, false);
    assert.equal(st.putRecord('meals', meal({ lifecycle: 'DRAFT' })).ok, false);
    assert.equal(st.putRecord('meals', meal({ lifecycle: 'DRAFT', confirmedAt: null })).ok, true);
  });
  it('rejects image bytes anywhere in a record', () => {
    const st = mk(mem());
    assert.equal(st.putRecord('meals', meal({ photo: 'data:image/jpeg;base64,AAAA' })).ok, false);
    assert.equal(st.putRecord('meals', meal({ blob: 'x'.repeat(5000) })).ok, false);
  });
  it('rejects future dates', () => {
    assert.equal(mk(mem()).putRecord('meals', meal({ date: '2026-11-12' })).ok, false);
  });
  it('SKIPPED requires explicit confirmation; statuses are exact enum', () => {
    const st = mk(mem());
    assert.equal(st.putRecord('sessions', session({ status: 'SKIPPED' })).ok, false);
    assert.equal(st.putRecord('sessions', session({ status: 'SKIPPED', skipConfirmed: true })).ok, true);
    assert.equal(st.putRecord('sessions', session({ status: 'DONE' })).ok, false);
  });
  it('keeps the 960 s machine overrun literally', () => {
    const st = mk(mem());
    st.putRecord('sessions', session());
    assert.equal(st.records('sessions')[0].blocks[0].durationSec, 960);
  });
  it('partial and modified are independent', () => {
    const st = mk(mem());
    assert.equal(st.putRecord('sessions', session({ status: 'COMPLETED', modified: true })).ok, true);
    assert.equal(st.putRecord('sessions', session({ status: 'PARTIAL', modified: false })).ok, true);
    const l = st.records('sessions');
    assert.deepEqual(l.map((x) => [x.status, x.modified]).sort(), [['COMPLETED', true], ['PARTIAL', false]]);
  });
  it('daily observation states: only OBSERVED may hold a value', () => {
    const st = mk(mem());
    assert.equal(st.putRecord('daily', { date: '2026-11-11', steps: { state: 'MISSING', value: 0 } }).ok, false);
    assert.equal(st.putRecord('daily', { date: '2026-11-11', steps: { state: 'OBSERVED', value: 0 }, sleepH: { state: 'NOT_TRACKED', value: null } }).ok, true);
  });
  it('edit replaces by id, keeps createdAt and appends a revision', () => {
    const st = mk(mem());
    const a = st.putRecord('meals', meal()).entry;
    const b = st.putRecord('meals', Object.assign({}, a, { label: 'Corrected' })).entry;
    assert.equal(b.id, a.id); assert.equal(b.createdAt, a.createdAt);
    assert.equal(st.records('meals').length, 1);
    assert.equal(st.records('meals')[0].revisions.length, 1);
  });
  it('removeRecord deletes and verifies', () => {
    const st = mk(mem());
    const a = st.putRecord('walks', { date: '2026-11-11', durationMin: 30 }).entry;
    assert.equal(st.removeRecord('walks', a.id), true);
    assert.equal(st.records('walks').length, 0);
    assert.equal(st.removeRecord('walks', 'nope'), false);
  });
  it('write failure reports not saved and leaves storage unchanged', () => {
    let fail = false; const s = mem(() => fail); const st = mk(s);
    st.putRecord('walks', { date: '2026-11-11', durationMin: 30 });
    const before = s.m['hyrox.v1'];
    fail = true;
    const r = st.putRecord('walks', { date: '2026-11-11', durationMin: 31 });
    assert.equal(r.ok, false); assert.ok(r.errors.storage);
    assert.equal(s.m['hyrox.v1'], before);
  });
  it('corrupt existing data is preserved before a Phase 3 write', () => {
    const s = mem(); s.m['hyrox.v1'] = '{broken';
    const st = mk(s);
    assert.equal(st.putRecord('walks', { date: '2026-11-11', durationMin: 30 }).ok, true);
    assert.equal(s.m['hyrox.v1.corrupt-backup'], '{broken');
  });
  it('newer-version data blocks Phase 3 writes', () => {
    const s = mem(); s.m['hyrox.v1'] = JSON.stringify({ version: 3, weight: [] });
    assert.equal(mk(s).putRecord('walks', { date: '2026-11-11', durationMin: 30 }).ok, false);
    assert.equal(JSON.parse(s.m['hyrox.v1']).version, 3);
  });
});

describe('backup round-trip with Phase 3 data', () => {
  function seeded() {
    const s = mem(); const st = mk(s);
    st.addWeight({ date: '2026-11-10', kg: 80 });
    st.putRecord('meals', meal({ ai: { mode: 'MOCK', provider: 'mock-fixture', model: 'mock-fixture-v1', userCorrected: true } }));
    st.putRecord('sessions', session());
    st.putRecord('daily', { date: '2026-11-11', steps: { state: 'OBSERVED', value: 8000 } });
    return { s, st };
  }
  it('export includes Phase 3 lists and no image data', () => {
    const { st } = seeded();
    const text = st.exportJSON(); const exp = JSON.parse(text);
    assert.equal(exp.meals.length, 1); assert.equal(exp.sessions.length, 1); assert.equal(exp.daily.length, 1);
    assert.equal(/data:image|base64/i.test(text), false);
  });
  it('export -> import into a fresh device restores identical Phase 3 data', () => {
    const { st } = seeded();
    const text = st.exportJSON();
    const s2 = mem(); const st2 = mk(s2);
    const p = st2.previewImport(text);
    assert.equal(p.ok, true); assert.deepEqual(p.preview.extCounts, { sessions: 1, meals: 1, daily: 1 });
    assert.deepEqual(Object.keys(s2.m), [], 'preview writes nothing');
    const r = st2.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt });
    assert.equal(r.ok, true);
    assert.deepEqual(st2.records('meals'), st.records('meals'));
    assert.deepEqual(st2.records('sessions'), st.records('sessions'));
  });
  it('invalid Phase 3 record in a backup rejects the whole restore and writes nothing', () => {
    const { st } = seeded();
    const exp = JSON.parse(st.exportJSON());
    exp.meals[0].components[0].kcal = { value: 0, state: 'UNKNOWN' };
    const s2 = mem(); const st2 = mk(s2);
    const p = st2.previewImport(JSON.stringify(exp));
    assert.equal(p.ok, false); assert.equal(p.code, 'invalid_records');
    assert.deepEqual(Object.keys(s2.m), []);
  });
  it('backup containing a photo is rejected', () => {
    const { st } = seeded();
    const exp = JSON.parse(st.exportJSON());
    exp.meals[0].photo = 'data:image/jpeg;base64,/9j/4AAQ';
    assert.equal(mk(mem()).previewImport(JSON.stringify(exp)).ok, false);
  });
  it('stale_plan when Phase 3 data changed since preview', () => {
    const { st } = seeded();
    const text = st.exportJSON();
    const p = st.previewImport(text);
    st.putRecord('walks', { date: '2026-11-11', durationMin: 20 });
    const r = st.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt });
    assert.equal(r.ok, false); assert.equal(r.code, 'stale_plan');
  });
  it('failed write during restore rolls back EXACT prior raw text including Phase 3 data', () => {
    const { st } = seeded();
    const text = st.exportJSON();
    let armed = false; let calls = 0;
    const s2 = mem((k) => armed && k === 'hyrox.v1' && ++calls === 1);
    const st2 = mk(s2);
    st2.putRecord('walks', { date: '2026-11-11', durationMin: 44 });
    const before = s2.m['hyrox.v1'];
    const p = st2.previewImport(text);
    armed = true;
    const r = st2.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt });
    assert.equal(r.ok, false); assert.equal(r.code, 'write_failed'); assert.equal(r.rolledBack, true);
    assert.equal(s2.m['hyrox.v1'], before);
    assert.equal(JSON.parse(s2.m['hyrox.v1.pre-import-backup']).raw, before);
  });
  it('restoring a Phase 2 backup over Phase 3 data keeps an exact pre-import copy of the Phase 3 data', () => {
    const { s, st } = seeded();
    const before = s.m['hyrox.v1'];
    const old = JSON.stringify({ app: 'hyrox-app', version: 1, exportedAt: NOW.toISOString(), weight: [], workouts: [], nutrition: [] });
    const p = st.previewImport(old);
    assert.deepEqual(p.preview.extCounts, {});
    const r = st.applyImport(old, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt, confirmEmptyReplace: true });
    assert.equal(r.ok, true);
    assert.equal(JSON.parse(s.m['hyrox.v1.pre-import-backup']).raw, before);
  });
});
