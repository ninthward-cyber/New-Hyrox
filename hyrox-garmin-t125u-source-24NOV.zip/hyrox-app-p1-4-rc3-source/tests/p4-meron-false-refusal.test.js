'use strict';
// P4 (Meron): false-refusal hunt against Dawit's 9e9f2e1 extended raw-marker check.
// A genuine rich normal export (and a legacy v1, an empty-device export, and a Phase 3
// export) must be accepted and must not be mistaken for an emergency raw file.
// The emergency raw export of the same rich dataset must still be refused, and a
// refusal must write nothing. Synthetic data only; no real AI calls.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { HD, KEY, PRE, mem, O, U, K, backup, restore } = require('./p3-helpers.js');

const NOW = new Date('2026-11-16T09:00:00Z'); // Monday 16 Nov 2026, after the weekend
const ts = NOW.toISOString();
const D = '2026-11-10'; // Tue
const WED = '2026-11-11';
const FRI = '2026-11-13';
const SAT = '2026-11-14';
const SUN = '2026-11-15';
const mk = (s) => HD.createStore(s, { now: () => NOW });
const snapAll = (s) => JSON.stringify(Object.keys(s.m).sort().map((k) => [k, s.m[k]]));
const stripExportedAt = (text) => { const j = JSON.parse(text); delete j.exportedAt; return j; };

// Marker words (and JSON-looking text) must be allowed in notes / labels / text fields.
const MARKER_WORDS = ['sources', 'warning', 'format', 'normalExport', 'omitted', 'kind', 'raw_recovery_file'];
const JSONISH = '{"sources":1}';

function ok(r, label) {
  assert.equal(r && r.ok, true, (label || 'op') + ' failed: ' + JSON.stringify(r));
  return r;
}

// All record types the data layer supports, built with this build's own APIs.
function richDevice() {
  const s = mem();
  const st = mk(s);
  ok(st.addWeight({ date: D, kg: 80.4 }), 'weight');
  ok(st.addWorkout({
    date: D, activity: 'Run ü 走る', durationMin: 42, partial: true,
    notes: 'sources warning format normalExport omitted kind raw_recovery_file ' + JSONISH,
  }), 'workout');
  ok(st.addNutrition({
    date: D, label: 'Lunch format omitted ' + JSONISH, calories: 510, proteinG: 32.5,
  }), 'nutrition');

  ok(st.putRecord('daily', {
    date: D,
    steps: O(8123),
    footPain: O(2),
    stairKneePain: O(1),
    sleepH: O(7.5),
    limp: { state: 'OBSERVED', value: false },
    soreness: O(2),
    rhr: O(60),
    note: 'warning: sore; sources of pain; kind of tired; raw_recovery_file in a note ' + JSONISH,
  }), 'daily');

  ok(st.putRecord('walks', {
    date: D, durationMin: 30, steps: 3000,
    notes: 'easy walk, not a normalExport, omitted nothing, sources: shoes',
  }), 'walks');

  // Weekday session with a variant and runSteps.
  ok(st.putRecord('sessions', {
    date: D, status: 'COMPLETED', modified: false, variant: 'ORIGINAL_60',
    planSlotId: 'v2.1-W1-TUE', runSteps: 5500, runStepsSource: 'DEVICE',
    blocks: [{ kind: 'run', durationSec: 1500, distanceM: 5000, notes: 'kind=run, format of the set' }],
    notes: 'Tuesday ORIGINAL_60; kind and format in a note',
  }), 'session tue');

  // A different variant.
  ok(st.putRecord('sessions', {
    date: WED, status: 'COMPLETED', modified: true, variant: 'SOURCE_25_MIN',
    planSlotId: 'v2.1-W1-WED', runSteps: 2000, runStepsSource: 'MANUAL',
    blocks: [{ kind: 'row', durationSec: 600 }],
    notes: 'SOURCE_25_MIN variant; omitted a station',
  }), 'session wed');

  // Weekend actual work (kept as work, not a source-approved make-up).
  ok(st.putRecord('sessions', {
    date: SAT, status: 'COMPLETED', modified: false, variant: 'NONE',
    blocks: [{ kind: 'run', durationSec: 900 }],
    notes: 'weekend actual work, not a make-up; raw_recovery_file is only a word here ' + JSONISH,
  }), 'session sat');
  ok(st.putRecord('sessions', {
    date: SUN, status: 'PARTIAL', modified: false, variant: 'NONE',
    blocks: [{ kind: 'skierg', durationSec: 400 }],
    notes: 'Sunday actual work',
  }), 'session sun');

  // Manual meal + a photo meal with eaten fractions (data layer supports them).
  ok(st.putRecord('meals', {
    date: D, label: 'Manual bowl (kind of soup, format omitted)', source: 'MANUAL',
    lifecycle: 'CONFIRMED', confirmedAt: ts,
    components: [
      { name: 'Soup sources', role: 'MAIN', kcal: K(180), proteinG: K(8), carbsG: K(20), fatG: K(4) },
    ],
  }), 'manual meal');
  ok(st.putRecord('meals', {
    date: D, label: 'Photo plate warning: spicy ' + JSONISH, source: 'PHOTO_AI',
    lifecycle: 'CONFIRMED', confirmedAt: ts, eatenFraction: 0.75,
    ai: { mode: 'MOCK', provider: 'mock-fixture', model: 'm' },
    components: [
      { name: 'Rice normalExport', role: 'SIDE', eatenFraction: 0.75, kcal: K(240), proteinG: K(5), carbsG: K(53), fatG: K(1) },
      { name: 'Chicken raw_recovery_file', role: 'MAIN', eatenFraction: 0.5, kcal: K(220), proteinG: K(40), carbsG: K(0), fatG: K(5) },
    ],
  }), 'photo meal');

  ok(st.putRecord('body', { date: D, metric: 'waist_cm', state: 'OBSERVED', value: 90 }), 'body');
  ok(st.putRecord('dayStates', { date: D, attestation: 'INCOMPLETE', basis: '0:x' }), 'dayStates');
  ok(st.putRecord('planEvents', { date: '2026-11-09', kind: 'MISSED_MONDAY', week: 1 }), 'planEvents');
  ok(st.putRecord('ownerSettings', { id: HD.SETTINGS_ID, date: D, rhrBaselineBpm: 76 }), 'settings');
  return { s, st };
}

function liveSeeded() {
  const s = mem();
  const st = mk(s);
  ok(st.addWeight({ date: D, kg: 80 }), 'live weight');
  ok(st.putRecord('walks', { date: D, durationMin: 30, steps: 3000 }), 'live walk');
  const p = st.previewImport(st.exportJSON());
  assert.equal(p.ok, true);
  return { s, st, current: p.preview.current, currentExt: p.preview.currentExt, before: snapAll(s), writes: s.writes };
}

function assertAcceptedRoundTrip(text) {
  const { s, st, current, currentExt, before, writes } = liveSeeded();
  const p = st.previewImport(text);
  assert.equal(p.ok, true, 'must not false-refuse: ' + JSON.stringify(p));
  assert.notEqual(p.code, 'raw_recovery_file');
  assert.equal(s.writes, writes, 'preview writes nothing');
  assert.equal(snapAll(s), before);
  const a = st.applyImport(text, { confirm: 'REPLACE', expectCurrent: current, expectCurrentExt: currentExt, confirmEmptyReplace: true });
  assert.equal(a.ok, true, 'direct applyImport must accept: ' + JSON.stringify(a));
  return { s, st, p, a };
}

function assertRefusedNothingWritten(text) {
  const { s, st, current, currentExt, before, writes } = liveSeeded();
  const p = st.previewImport(text);
  assert.equal(p.ok, false, 'preview must refuse');
  assert.equal(p.code, 'raw_recovery_file');
  assert.match(p.message, /emergency raw recovery/i);
  assert.equal(s.writes, writes, 'preview writes nothing');
  assert.equal(snapAll(s), before);
  const a = st.applyImport(text, { confirm: 'REPLACE', expectCurrent: current, expectCurrentExt: currentExt });
  assert.equal(a.ok, false, 'direct applyImport must refuse');
  assert.equal(a.code, 'raw_recovery_file');
  assert.equal(s.writes, writes, 'apply writes nothing');
  assert.equal(snapAll(s), before);
  assert.equal(Object.prototype.hasOwnProperty.call(s.m, PRE), false, 'no pre-import slot');
  assert.equal(st.list('weight').length, 1);
  assert.equal(st.list('weight')[0].kg, 80);
  assert.equal(st.records('walks').length, 1);
  return { p, a };
}

describe('P4 false-refusal: a rich normal export of this build must be accepted and must round-trip', () => {
  it('the new build can generate a rich synthetic dataset covering every record type, with marker words only in text fields', () => {
    const { st } = richDevice();
    const text = st.exportJSON();
    const o = JSON.parse(text);
    assert.equal(o.app, 'hyrox-app');
    assert.equal(o.version, 2);
    assert.equal(o.weight.length, 1);
    assert.equal(o.workouts.length, 1);
    assert.equal(o.nutrition.length, 1);
    assert.equal(o.daily.length, 1);
    assert.equal(o.walks.length, 1);
    assert.equal(o.sessions.length, 4);
    assert.equal(o.meals.length, 2);
    assert.equal(o.body.length, 1);
    assert.equal(o.dayStates.length, 1);
    assert.equal(o.planEvents.length, 1);
    assert.equal(o.ownerSettings.length, 1);
    // Variants, weekend actual work, runSteps, photo eaten fractions are really there.
    const variants = o.sessions.map((x) => x.variant).sort();
    assert.deepEqual(variants, ['NONE', 'NONE', 'ORIGINAL_60', 'SOURCE_25_MIN'].sort());
    assert.ok(o.sessions.some((x) => x.date === SAT && x.status === 'COMPLETED'));
    assert.ok(o.sessions.some((x) => x.runSteps === 5500 && x.runStepsSource === 'DEVICE'));
    const photo = o.meals.find((m) => m.source === 'PHOTO_AI');
    assert.ok(photo);
    assert.equal(photo.eatenFraction, 0.75);
    assert.equal(photo.components[1].eatenFraction, 0.5);
    const daily = o.daily[0];
    assert.equal(daily.steps.value, 8123);
    assert.equal(daily.footPain.value, 2);
    assert.equal(daily.sleepH.value, 7.5);
    // Marker words appear in text fields, not as top-level emergency keys.
    const blob = JSON.stringify(o);
    for (const w of MARKER_WORDS) assert.ok(blob.includes(w), 'rich export contains the word ' + w);
    // JSON-looking text is stored on text fields; JSON.stringify escapes quotes, so
    // assert against the parsed values (the round-trip test covers deep-equal).
    assert.ok(o.workouts[0].notes.includes(JSONISH), 'workout notes keep ' + JSONISH);
    assert.ok(o.daily[0].note.includes(JSONISH), 'daily note keeps ' + JSONISH);
    assert.ok(o.sessions.some((x) => (x.notes || '').includes(JSONISH)), 'a session note keeps ' + JSONISH);
    assert.ok(o.meals.some((m) => (m.label || '').includes(JSONISH)), 'a meal label keeps ' + JSONISH);
    const top = Object.keys(o);
    const forbidden = ['sources', 'warning', 'normalExport', 'omitted', 'omittedTotal', 'kind'];
    for (const k of top) {
      const n = k.normalize('NFKC').replace(/[\u00AD\u180E\u200B-\u200F\u2060-\u2064\uFEFF]/g, '').trim().toLowerCase();
      assert.ok(!forbidden.includes(n), 'top-level key must not be an emergency marker: ' + k);
    }
    assert.equal(typeof o.format, 'undefined');
    assert.equal(typeof o.state, 'undefined');
  });

  it('exporting that rich dataset with this build\'s normal export and importing it is accepted, restores, and deep-equals (minus exportedAt), on preview and on direct applyImport', () => {
    const { st } = richDevice();
    const text = st.exportJSON();
    const { st: st2, p } = assertAcceptedRoundTrip(text);
    assert.deepEqual(stripExportedAt(st2.exportJSON()), stripExportedAt(text));
    // Also restore onto a blank device and compare again.
    const s3 = mem();
    const st3 = mk(s3);
    const a3 = restore(st3, text);
    assert.equal(a3.ok, true, 'blank-device restore: ' + JSON.stringify(a3));
    assert.deepEqual(stripExportedAt(st3.exportJSON()), stripExportedAt(text));
    assert.ok(p.preview);
  });
});

describe('P4 false-refusal: legacy v1, empty-device, and a Phase 3 export are still accepted', () => {
  it('an empty-device export of this build is accepted (existing empty-replace policy)', () => {
    const st = mk(mem());
    const text = st.exportJSON();
    const o = JSON.parse(text);
    assert.equal(o.weight.length, 0);
    assert.equal(o.workouts.length, 0);
    assert.equal(o.nutrition.length, 0);
    const { st: st2 } = assertAcceptedRoundTrip(text);
    assert.equal(st2.list('weight').length, 0);
  });

  it('a legacy v1 backup (weight/workouts/nutrition only, no Phase 3 lists) is accepted and restores', () => {
    const s = mem();
    const st = mk(s);
    ok(st.addWeight({ date: D, kg: 81 }), 'v1 weight');
    ok(st.addWorkout({ date: D, activity: 'Row', durationMin: 20, notes: 'kind of short; sources of effort' }), 'v1 workout');
    ok(st.addNutrition({ date: D, label: 'Snack format', calories: 200, proteinG: 10 }), 'v1 nutrition');
    const text = st.exportJSON();
    const o = JSON.parse(text);
    assert.equal(o.version, 1, 'no Phase 3 collections => legacy v1');
    assert.equal(o.app, 'hyrox-app');
    assert.equal(typeof o.daily, 'undefined');
    const { st: st2 } = assertAcceptedRoundTrip(text);
    assert.equal(st2.list('weight')[0].kg, 81);
    assert.equal(st2.list('workouts').length, 1);
  });

  it('a Phase 3 export generated from /workspace/hyrox-p3/build (read-only; fixture tests/fixtures/p3-phase3-export.json) is still accepted and restores', () => {
    const fixturePath = path.join(__dirname, 'fixtures', 'p3-phase3-export.json');
    const text = fs.readFileSync(fixturePath, 'utf8');
    const o = JSON.parse(text);
    assert.equal(o.app, 'hyrox-app');
    assert.equal(o.version, 2);
    assert.ok(Array.isArray(o.sessions) && o.sessions.length >= 1);
    assert.ok(Array.isArray(o.daily) && o.daily.length >= 1);
    assert.ok(o.sessions.some((x) => x.date === SAT), 'fixture includes weekend actual work');
    const { st: st2 } = assertAcceptedRoundTrip(text);
    assert.equal(st2.list('weight')[0].kg, o.weight[0].kg);
    assert.equal(st2.records('sessions').length, o.sessions.length);
    assert.equal(st2.records('meals').length, o.meals.length);
    // Round-trip the restored Phase 3 data through this build (exportedAt may change).
    const again = st2.exportJSON();
    const p3 = st2.previewImport(again);
    assert.equal(p3.ok, true, 're-export of the restored Phase 3 data must still be accepted: ' + JSON.stringify(p3));
  });
});

describe('P4 false-refusal: the emergency raw export of the same rich dataset is refused and writes nothing', () => {
  it('rawRecoveryExport of the rich dataset is refused by previewImport and by direct applyImport; live data is unchanged', () => {
    const { st } = richDevice();
    const raw = st.rawRecoveryExport();
    assert.equal(raw.ok, true);
    const o = JSON.parse(raw.text);
    assert.equal(o.kind, 'hyrox-raw-recovery');
    assert.ok(Object.prototype.hasOwnProperty.call(o, 'sources'));
    assert.ok(Object.prototype.hasOwnProperty.call(o, 'warning'));
    assertRefusedNothingWritten(raw.text);
  });
});
