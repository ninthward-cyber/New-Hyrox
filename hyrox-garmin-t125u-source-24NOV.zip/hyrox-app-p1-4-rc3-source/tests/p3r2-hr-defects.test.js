'use strict';
// Dawit R2 / D4 resting-HR labels + Meron defects F6, F7, F8. Synthetic data only.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const HW = require(path.resolve(__dirname, '../src/data/hyrox-wellness.js'));
const { KEY, mem, mk, O, ts, backup } = require('./p3-helpers.js');

const T = '2026-11-11';
const day = (date, o) => Object.assign({ id: 'daily-' + date, date }, o);
const hist = ['2026-11-06', '2026-11-07', '2026-11-08', '2026-11-09', '2026-11-10'].map((d) => day(d, { rhr: O(60) }));

describe('D4: owner-configured 76 vs observed 7-day mean', () => {
  it('both are labelled separately; the observed mean is marked as not a v2.1 rule', () => {
    const a = HW.rhrAssessment(85, T, hist, { rhrBaselineBpm: 76, rhrBaselineSource: 'OWNER_DEFAULT' });
    assert.match(a.labels.configured, /Owner-configured/); assert.match(a.labels.observed, /not a v2\.1 rule/);
    assert.deepEqual(a.comparisons.map((c) => [c.basis, c.baseline, c.delta, c.above7]), [['OWNER_CONFIGURED', 76, 9, true], ['OBSERVED_7DAY_MEAN', 60, 25, true]]);
    assert.equal(a.comparisons[1].sourceRule, false);
    assert.equal(a.configured.value, 76); assert.equal(a.observed.value, 60);
  });
  it('two comparisons of one reading = ONE readiness flag (flagCount 1, both bases listed)', () => {
    const r = HW.readiness(T, hist.concat([day(T, { rhr: O(90), sleepH: O(8), soreness: O(1) })]), { rhrBaselineBpm: 76 });
    assert.equal(r.flags.length, 1); assert.equal(r.rhr.flagCount, 1);
    assert.deepEqual(r.rhrFlagBasis, ['OWNER_CONFIGURED', 'OBSERVED_7DAY_MEAN']);
    assert.match(r.guidance, /one flag/); assert.doesNotMatch(r.guidance, /two or more/);
  });
  it('flagBasis per branch: configured only, observed only, none, missing reading', () => {
    assert.deepEqual(HW.rhrAssessment(84, T, [], { rhrBaselineBpm: 76 }).flagBasis, ['OWNER_CONFIGURED']);
    const obsOnly = HW.rhrAssessment(70, T, hist, { rhrBaselineBpm: 76 });
    assert.deepEqual(obsOnly.flagBasis, ['OBSERVED_7DAY_MEAN']); assert.match(obsOnly.flag, /app calculation, not a v2\.1 rule/);
    const none = HW.rhrAssessment(62, T, hist, { rhrBaselineBpm: 76 });
    assert.deepEqual(none.flagBasis, []); assert.equal(none.flagCount, 0);
    const miss = HW.rhrAssessment(null, T, hist, { rhrBaselineBpm: 76 });
    assert.deepEqual(miss.comparisons.map((c) => c.above7), [null, null]); assert.equal(miss.flagCount, 0);
    const noObs = HW.rhrAssessment(80, T, [], { rhrBaselineBpm: 76 });
    assert.equal(noObs.comparisons[1].baseline, null); assert.equal(noObs.comparisons[1].above7, null);
  });
  it('without settings the flag still names its basis; it is never called the v2.1 "weekly baseline"', () => {
    const r = HW.readiness(T, hist.concat([day(T, { rhr: O(70) })]));
    assert.equal(r.flags.length, 1); assert.match(r.flags[0], /observed 7-day mean/); assert.doesNotMatch(r.flags[0], /weekly baseline/);
    assert.deepEqual(r.rhrFlagBasis, ['OBSERVED_7DAY_MEAN']);
    assert.deepEqual(HW.readiness(T, []).rhrFlagBasis, []);
  });
});

describe('F6: NaN / Infinity are refused, never stored as "not recorded"', () => {
  it('walk steps and session runSteps (with or without a source), nested values too; nothing written', () => {
    for (const v of [NaN, Infinity, -Infinity]) {
      const s = mem(); const st = mk(s);
      const w = st.putRecord('walks', { date: T, durationMin: 30, steps: v });
      assert.equal(w.ok, false); assert.match(w.errors.steps, /real number/);
      assert.equal(st.putRecord('sessions', { date: T, status: 'COMPLETED', modified: false, variant: 'NONE', blocks: [], runSteps: v }).ok, false);
      assert.equal(st.putRecord('sessions', { date: T, status: 'COMPLETED', modified: false, variant: 'NONE', blocks: [], runSteps: v, runStepsSource: 'DEVICE' }).ok, false);
      const nested = st.putRecord('sessions', { date: T, status: 'COMPLETED', modified: false, variant: 'NONE', blocks: [{ kind: 'run', durationSec: v }] });
      assert.equal(nested.ok, false); assert.ok(nested.errors['blocks[0].durationSec']);
      assert.equal(st.putRecord('daily', { date: T, steps: { state: 'OBSERVED', value: v } }).ok, false);
      assert.equal(s.m[KEY], undefined, 'nothing written');
    }
  });
  it('ordinary null still means "not recorded" and is accepted', () => {
    assert.equal(mk(mem()).putRecord('walks', { date: T, durationMin: 30, steps: null }).ok, true);
  });
});

describe('F7: a recorded daily step total must be a whole number', () => {
  it('putRecord and import refuse 10.5; 0 and 12000 are fine; non-OBSERVED is untouched', () => {
    const st = mk(mem());
    assert.equal(st.putRecord('daily', { date: T, steps: O(10.5) }).ok, false);
    assert.equal(st.putRecord('daily', { date: T, steps: O(0) }).ok, true);
    assert.equal(st.putRecord('daily', { date: T, steps: O(12000) }).ok, true);
    assert.equal(st.putRecord('daily', { date: T, steps: { state: 'MISSING', value: null } }).ok, true);
    const s = mem(); const st2 = mk(s); st2.addWeight({ date: T, kg: 80 });
    const before = s.m[KEY];
    const p = st2.previewImport(backup({ daily: [{ id: 'd', createdAt: ts, date: T, steps: O(10.5) }] }));
    assert.equal(p.ok, false); assert.equal(s.m[KEY], before);
  });
});

describe('F8: daySteps ignores runSteps on sessions that did not happen', () => {
  const run = (id, status, extra) => Object.assign({ id, date: T, status, modified: false, variant: 'NONE', blocks: [], runSteps: 5000, runStepsSource: 'DEVICE' }, extra);
  it('SKIPPED / NOT_STARTED / unknown status are not counted; IN_PROGRESS / COMPLETED / PARTIAL are', () => {
    for (const st of ['SKIPPED', 'NOT_STARTED', 'BOGUS', undefined]) {
      const r = HW.daySteps(T, { sessions: [run('s', st, { skipConfirmed: true })] });
      assert.equal(r.total, null, String(st)); assert.equal(r.source, null); assert.deepEqual(r.flags, ['NO_STEP_DATA']);
    }
    for (const st of ['IN_PROGRESS', 'COMPLETED', 'PARTIAL']) assert.equal(HW.daySteps(T, { sessions: [run('s', st)] }).total, 5000, st);
    const mix = HW.daySteps(T, { sessions: [run('a', 'COMPLETED'), run('b', 'SKIPPED', { skipConfirmed: true })], walks: [{ id: 'w', date: T, durationMin: 20, steps: 1000 }] });
    assert.equal(mix.total, 6000); assert.equal(mix.runCount, 1);
  });
});
