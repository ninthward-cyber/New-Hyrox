'use strict';
// RC2 review (Claude). Synthetic data only. On RC1 these FAIL:
//  1. fiber/sodium the owner typed lost their "owner entered" origin when copied to / from My foods (only an in-memory
//     WeakMap remembered it), so a later kcal change on that USDA item cleared them;
//  2. restoring a backup gave no warning that it replaces the device's saved foods and favourites;
//  3. ranking: "fries" listed "Fry sauce" first; "french fries" put five chains above the plain food; "burger" ranked
//     Burger King onion rings / shakes / fries among the top results because the brand was treated as the food name.
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('path');
global.window = global;
const R = path.join(__dirname, '..');
require(path.join(R, 'src/data/food-db.js'));
require(path.join(R, 'src/data/food-db-us.js'));
const S = require(path.join(R, 'src/data/hyrox-foodsearch.js'));
const C = require(path.join(R, 'src/data/hyrox-foodcalc.js'));
const ix = S.buildIndex(global.HyroxFoodDb, C.ALIASES, global.HyroxFoodDbUs);
const names = (q, n) => S.search(ix, q).results.slice(0, n || 25).map((r) => r.name);
const first = (q) => S.search(ix, q).results[0];

test('fix 1: an owner-entered fiber/sodium value keeps its origin through My foods (save and reuse, any quantity)', () => {
  const comp = { name: 'Oats bowl', portion: '1 bowl', kcal: { value: 300, state: 'ESTIMATED' }, proteinG: { value: 10, state: 'ESTIMATED' }, carbsG: { value: 50, state: 'ESTIMATED' }, fatG: { value: 5, state: 'ESTIMATED' },
    provenance: { source: 'USDA_FDC', dataset: 'SR', fdcId: 173904, description: 'Oats', portion: '1 cup (81 g)', grams: 81, dbVersion: 'x' },
    fiberG: { value: 9, state: 'ESTIMATED', by: 'OWNER' }, sodiumMg: { value: 5, state: 'ESTIMATED' } };
  const saved = S.myFoodFromComponent(comp, { id: 'mf-1' });
  assert.equal(saved.ok, true);
  assert.deepEqual(saved.food.fiberG, { value: 9, state: 'ESTIMATED', by: 'OWNER' }, 'owner origin kept on the saved food');
  assert.deepEqual(saved.food.sodiumMg, { value: 5, state: 'ESTIMATED' }, 'a USDA-derived value stays unmarked');
  const back = S.myFoodComponent(saved.food, 2);
  assert.deepEqual(back.component.fiberG, { value: 18, state: 'ESTIMATED', by: 'OWNER' });
  assert.deepEqual(back.component.sodiumMg, { value: 10, state: 'ESTIMATED' });
  const listed = S.validMyFoods([saved.food])[0];
  assert.equal(listed.fiberG.by, 'OWNER');
  // only the exact marker is kept; anything else is dropped (never trusted)
  assert.equal(S.myFoodFromComponent(Object.assign({}, comp, { fiberG: { value: 9, state: 'ESTIMATED', by: 'USDA' } })).food.fiberG.by, undefined);
  assert.equal(S.isOwnerExtra({ value: 1, state: 'KNOWN', by: 'OWNER' }), true);
  assert.equal(S.isOwnerExtra({ value: 1, state: 'ESTIMATED' }), false);
});

test('fix 2: restoring a backup warns when it replaces or removes the saved foods / favourites on this device', () => {
  const dev = (mf, fav) => JSON.stringify({ ownerSettings: [Object.assign({ id: 'app-settings' }, mf ? { myFoods: mf } : {}, fav ? { favFoods: fav } : {})] });
  const A = [{ id: 'mf-1', name: 'Oats bowl' }, { id: 'mf-2', name: 'Rice' }], B = [{ id: 'mf-9', name: 'Shake' }];
  assert.match(S.restoreNote(dev(A, ['SR:1']), dev(null, null)), /removes your 2 saved foods and 1 favourite/);
  assert.match(S.restoreNote(dev(A, ['SR:1']), dev(B, [])), /replaces this device's 2 saved foods and 1 favourite with the backup's 1 saved food and 0 favourites/);
  assert.equal(S.restoreNote(dev(A, ['SR:1']), dev(A, ['SR:1'])), null, 'identical lists: no warning');
  assert.equal(S.restoreNote(dev(null, null), dev(B, ['SR:2'])), null, 'nothing on this device to lose: no warning');
  assert.equal(S.restoreNote('not json', dev(B, [])), null);
  assert.match(S.restoreNote(dev(A, null), 'not json'), /removes your 2 saved foods/);
});

test('fix 3: "fries" lists plain French fries first and never "Fry sauce" near the top', () => {
  assert.equal(first('fries').name, 'Potato, french fries, NFS');
  assert.ok(names('fries', 5).every((n) => !/sauce/i.test(n)), names('fries', 5).join(' | '));
  assert.ok(names('fries', 10).filter((n) => /fries/i.test(n)).length >= 8);
});

test('fix 3: "french fries" puts the plain food first and still offers several chains; nothing is chosen by itself', () => {
  const r = S.search(ix, 'french fries');
  assert.equal(r.results[0].name, 'Potato, french fries, NFS');
  assert.equal(r.results[0].restaurant, false);
  assert.ok(new Set(r.results.filter((x) => x.restaurant).map((x) => x.name.split(',')[0])).size >= 3);
  assert.ok(r.results.every((x) => !('selected' in x) && !('component' in x)));
});

test('fix 3: a brand word in a chain name is not the food ("burger" lists burgers, not Burger King fries or shakes)', () => {
  const top = names('burger', 8);
  assert.ok(top.every((n) => /burger/i.test(n.replace(/^BURGER KING,\s*/, ''))), top.join(' | '));
  assert.ok(!top.slice(0, 5).some((n) => /onion rings|shake|french fries/i.test(n)));
  assert.equal(top[0], 'Hamburger, NFS');
  assert.match(first('cheeseburger').name, /cheeseburger/i);
  assert.match(first('veggie burger').name, /^Veggie burger/i);
});

test('fix 3: brand searches and the earlier ranking promises are unchanged', () => {
  assert.equal(first('mcdonalds fries').name, "McDONALD'S, french fries");
  assert.match(first('big mac').name, /big mac/i);
  assert.match(first('burger king whopper').name, /^BURGER KING, WHOPPER/);
  assert.match(first('burger king fries').name, /^BURGER KING, french fries/);
  assert.match(first('rice').name, /^Rice, white, long-grain/);
  assert.match(first('egg').name, /^Egg, whole, raw/);
  assert.match(first('banana').name, /^Bananas, raw/);
  assert.match(first('sweet potato fries').name, /^Sweet potato fries/);
  assert.match(first('home fries').name, /^Potato, home fries/);
});

test('fix 1: the owner marker survives export -> restore on this build and on the Claude P11.2 data layer (older versions keep it)', () => {
  const NOW = new Date('2026-11-19T09:00:00Z');
  const mem = () => { const m = {}; return { getItem: (k) => (k in m ? m[k] : null), setItem(k, v) { m[k] = String(v); }, removeItem(k) { delete m[k]; } }; };
  const K = (v) => ({ value: v, state: 'KNOWN' });
  const comp = { name: 'Banana', role: 'MAIN', portion: '1 medium', preparation: '', eatenFraction: null, kcal: K(105), proteinG: K(1), carbsG: K(27), fatG: K(0),
    fiberG: { value: 3.1, state: 'ESTIMATED' }, sodiumMg: { value: 77, state: 'ESTIMATED', by: 'OWNER' } };
  const meal = { date: '2026-11-19', time: '12:00', label: 'Snack', source: 'MANUAL', description: '', eatenFraction: 1, lifecycle: 'CONFIRMED', confirmedAt: NOW.toISOString(), ai: null, mealCategory: 'SNACKS', components: [comp] };
  const roundTrip = (H, text) => {
    const storage = mem(), st = H.createStore(storage, { now: () => NOW });
    const p = st.previewImport(text); assert.equal(p.ok, true, JSON.stringify(p.errors || p.message));
    const r = st.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt }); assert.equal(r.ok, true, JSON.stringify(r));
    return JSON.parse(H.createStore(storage, { now: () => NOW }).exportJSON());
  };
  const HD = require(path.join(R, 'src/data/hyrox-data.js'));
  const st = HD.createStore(mem(), { now: () => NOW });
  assert.equal(st.putRecord('meals', meal).ok, true);
  const text = st.exportJSON();
  assert.deepEqual(roundTrip(HD, text).meals[0].components[0].sodiumMg, comp.sodiumMg);
  const old = process.env.P113_P112_SRC;
  if (old) {
    const back = roundTrip(require(path.join(old, 'data/hyrox-data.js')), text);
    assert.deepEqual(back.meals[0].components[0].sodiumMg, comp.sodiumMg, 'P11.2 keeps the marker as an unknown field');
    assert.deepEqual(roundTrip(HD, JSON.stringify(back)).meals[0].components[0].sodiumMg, comp.sodiumMg, 'and it comes back to RC2 intact');
  }
});

test('fix 4: the deploy README describes this package (RC2, the 16 files of DEPLOY-FILES.txt, CLI deploy), not Phase 10', () => {
  const fs = require('fs');
  const readme = fs.readFileSync(path.join(R, 'deploy/README-DEPLOY.txt'), 'utf8');
  const files = fs.readFileSync(path.join(R, 'DEPLOY-FILES.txt'), 'utf8').split('\n').map((l) => l.trim()).filter((l) => /^(index\.html|src\/)/.test(l));
  assert.equal(files.length, 20); // RE-POINTED R8 (24 Nov 2026): +src/integrations/garmin-import.js -> 20; Sprint D added hyrox-coach-export.js; P1.3 added hyrox-coach.js
  assert.match(readme, /RC2/); assert.match(readme, /DEPLOY-RC2\.md/); assert.match(readme, /the 19 static app files/);
  for (const f of files) assert.ok(readme.includes(f.replace(/^src\/[a-z]+\//, '')), 'README lists ' + f);
  assert.doesNotMatch(readme, /Phase 10 deploy|12 static|DEPLOY-PHASE10\.md/);
  assert.match(readme, /--functions netlify\/functions/); assert.match(readme, /NOT a drag-and-drop folder/);
  assert.match(readme, /NOT deploy approval/); assert.match(readme, /11 Dec 2026/);
});
