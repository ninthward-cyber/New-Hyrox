'use strict';
// DAWIT 2: byte-exact emergency raw recovery export with an explicit omission warning.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const OLD = require(path.resolve(__dirname, 'fixtures/legacy/hyrox-data-64427c2.js'));
const { HD, NOW, KEY, RECOVERY, PRE, mem, mk, ts, backup, restore } = require('./p3-helpers.js');

// Healthy store holding 2 damaged classic entries, 1 damaged session, odd unicode and an unknown field.
const MIXED = '{"version":2,"weight":[{"id":"w1","createdAt":"' + ts + '","date":"2026-11-10","kg":80},{"kg":"??"},7],' +
  '"workouts":[],"nutrition":[],"sessions":[{"id":"bad","date":"2026-11-10","status":"NOPE"}],' +
  '"note":"caf\\u00e9 \\ud83c\\udfc3 \\ud800 lone"   ,  "extra":{"keep":true}}';
const DAMAGED = '{"version":1,"weight":[],"workouts":[],"nutrition":[],"sessions":{"historic":"keep-me"}}';

describe('rawRecoveryExport', () => {
  it('is read-only: zero writes, nothing changed', () => {
    const s = mem({ [KEY]: MIXED, [RECOVERY]: DAMAGED }); const st = mk(s);
    const r = st.rawRecoveryExport();
    assert.equal(r.ok, true); assert.equal(s.writes, 0);
    assert.equal(s.m[KEY], MIXED); assert.equal(s.m[RECOVERY], DAMAGED);
  });
  it('contains the EXACT stored text of every present key (byte/code-unit exact, incl. lone surrogates and whitespace)', () => {
    const preEnv = JSON.stringify({ kind: 'hyrox-pre-import', savedAt: ts, raw: '{"x":1}  ' });
    const s = mem({ [KEY]: MIXED, [RECOVERY]: DAMAGED, [PRE]: preEnv }); const st = mk(s);
    const r = st.rawRecoveryExport();
    const back = HD.parseRawRecovery(r.text);
    assert.equal(back.ok, true);
    assert.deepEqual(back.sources.map((x) => x.key), [KEY, RECOVERY, PRE]);
    assert.equal(back.sources[0].raw, MIXED); assert.equal(back.sources[1].raw, DAMAGED); assert.equal(back.sources[2].raw, preEnv);
    assert.equal(JSON.parse(back.sources[2].raw).raw, '{"x":1}  ', 'the pre-import copy is still exact inside');
    assert.deepEqual(r.sources, back.sources.map((x) => ({ key: x.key, length: x.raw.length, checksum: HD.rawChecksum(x.raw) })));
    assert.equal(back.sources[0].raw.length, MIXED.length);
  });
  it('states how many records the normal export leaves out, per list', () => {
    const st = mk(mem({ [KEY]: MIXED }));
    const r = st.rawRecoveryExport();
    assert.equal(r.state, 'ok'); assert.equal(r.normalExport, 'partial');
    assert.deepEqual(r.omitted, { weight: 2, sessions: 1 }); assert.equal(r.omittedTotal, 3);
    assert.match(r.warning, /leaves out 3 damaged records \(2 weight, 1 sessions\)/);
    assert.match(r.warning, /NOT a normal backup/);
    // same numbers as the normal export notice
    const sum = st.exportSummary();
    assert.equal(sum.omitted.weight, 2); assert.deepEqual(sum.omittedExt, { sessions: 1 });
    // and the normal export really leaves them out
    const normal = JSON.parse(st.exportJSON());
    assert.equal(normal.weight.length, 1); assert.equal(normal.sessions.length, 0);
    assert.match(r.filename, /^hyrox-RAW-RECOVERY-2026-11-11\.json$/);
  });
  it('works when the normal export is refused (damaged or newer storage)', () => {
    const c = mk(mem({ [KEY]: DAMAGED })).rawRecoveryExport();
    assert.equal(c.ok, true); assert.equal(c.state, 'corrupt'); assert.equal(c.normalExport, 'refused'); assert.equal(c.omitted, null);
    assert.match(c.warning, /damaged, so the normal backup cannot include any of it/);
    assert.throws(() => mk(mem({ [KEY]: DAMAGED })).exportJSON());
    const n = mk(mem({ [KEY]: '{"version":3,"weight":[]}' })).rawRecoveryExport();
    assert.equal(n.ok, true); assert.equal(n.state, 'newer'); assert.equal(HD.parseRawRecovery(n.text).sources[0].raw, '{"version":3,"weight":[]}');
    const g = mk(mem({ [KEY]: 'not json at all {' })).rawRecoveryExport();
    assert.equal(HD.parseRawRecovery(g.text).sources[0].raw, 'not json at all {');
  });
  it('a clean store says nothing is omitted', () => {
    const s = mem(); const st = mk(s); st.addWeight({ date: '2026-11-10', kg: 80 });
    const r = st.rawRecoveryExport();
    assert.equal(r.normalExport, 'complete'); assert.equal(r.omittedTotal, 0); assert.deepEqual(r.omitted, {});
  });
  it('fails safely: nothing stored, storage unavailable, unreadable', () => {
    assert.equal(mk(mem()).rawRecoveryExport().code, 'nothing_stored');
    assert.equal(HD.createStore(undefined).rawRecoveryExport().code, 'storage_unavailable');
    const bad = mem({ [KEY]: MIXED }); bad.getItem = () => { throw new Error('SecurityError'); };
    const r = mk(bad).rawRecoveryExport();
    assert.equal(r.ok, false); assert.equal(r.code, 'storage_unreadable');
    const half = mem({ [KEY]: MIXED }); const g = half.getItem.bind(half);
    half.getItem = (k) => { if (k === RECOVERY) throw new Error('x'); return g(k); };
    assert.equal(mk(half).rawRecoveryExport().ok, false, 'never returns a partial copy as if complete');
  });
  it('the corrupt-backup copy is never overwritten by saving after a raw export', () => {
    const s = mem({ [KEY]: DAMAGED, [RECOVERY]: 'older different copy' }); const st = mk(s);
    st.rawRecoveryExport();
    assert.equal(st.addWeight({ date: '2026-11-10', kg: 80 }).ok, false, 'save refused: a different recovery copy exists');
    assert.equal(s.m[RECOVERY], 'older different copy'); assert.equal(s.m[KEY], DAMAGED);
  });
});

describe('restore semantics for a raw recovery file', () => {
  it('previewImport and applyImport refuse it with raw_recovery_file and write nothing', () => {
    const src = mk(mem({ [KEY]: MIXED })).rawRecoveryExport().text;
    const s = mem(); const st = mk(s); st.addWeight({ date: '2026-11-10', kg: 80 });
    const before = JSON.stringify(s.m), writes = s.writes;
    const p = st.previewImport(src);
    assert.equal(p.ok, false); assert.equal(p.code, 'raw_recovery_file'); assert.match(p.message, /not a normal backup/);
    const a = st.applyImport(src, { confirm: 'REPLACE', expectCurrent: { weight: 1, workouts: 0, nutrition: 0 } });
    assert.equal(a.ok, false); assert.equal(a.code, 'raw_recovery_file');
    assert.equal(JSON.stringify(s.m), before); assert.equal(s.writes, writes);
  });
  it('even a raw copy of perfectly healthy data is refused (no back door around validation)', () => {
    const s = mem(); const st = mk(s); st.addWeight({ date: '2026-11-10', kg: 80 });
    const raw = st.rawRecoveryExport().text;
    assert.equal(mk(mem()).previewImport(raw).code, 'raw_recovery_file');
  });
  it('the older Phase 2 build also refuses it (app is not hyrox-app)', () => {
    const raw = mk(mem({ [KEY]: MIXED })).rawRecoveryExport().text;
    const os = mem(); const p = OLD.createStore(os, { now: () => NOW }).previewImport(raw);
    assert.equal(p.ok, false); assert.equal(os.writes, 0);
  });
  it('the stored text alone (no app field) is not accepted as a backup either', () => {
    assert.equal(mk(mem()).previewImport(MIXED).ok, false);
  });
  it('parseRawRecovery detects edited or truncated copies', () => {
    const t = mk(mem({ [KEY]: MIXED })).rawRecoveryExport().text;
    const o = JSON.parse(t); o.sources[0].raw = o.sources[0].raw.replace('80', '81');
    assert.equal(HD.parseRawRecovery(JSON.stringify(o)).code, 'damaged');
    assert.equal(HD.parseRawRecovery(t.slice(0, t.length - 10)).code, 'not_raw_recovery');
    assert.equal(HD.parseRawRecovery(backup({})).code, 'not_raw_recovery');
  });
  it('a failed normal restore still rolls back to the exact damaged bytes and keeps the exact pre-import copy', () => {
    let armed = false;
    const s = mem({ [KEY]: MIXED }, (k) => { if (k === KEY && armed) { armed = false; return true; } return false; }); // first write fails
    const st = mk(s);
    const text = backup({ weight: [{ id: 'n', createdAt: ts, date: '2026-11-10', kg: 70 }] });
    const p = st.previewImport(text); armed = true;
    const r = st.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt });
    assert.equal(r.ok, false); assert.equal(r.rolledBack, true);
    assert.equal(s.m[KEY], MIXED);
    assert.equal(JSON.parse(s.m[PRE]).raw, MIXED);
    const back = HD.parseRawRecovery(mk(s).rawRecoveryExport().text);
    assert.equal(back.sources.find((x) => x.key === PRE).raw, s.m[PRE]);
  });
  it('a successful restore over damaged data keeps the damaged bytes in the pre-import slot, exportable raw', () => {
    const s = mem({ [KEY]: DAMAGED }); const st = mk(s);
    assert.equal(restore(st, backup({})).ok, true);
    assert.equal(s.m[RECOVERY], DAMAGED);
    const back = HD.parseRawRecovery(st.rawRecoveryExport().text);
    assert.equal(back.sources.find((x) => x.key === RECOVERY).raw, DAMAGED);
    assert.equal(JSON.parse(back.sources.find((x) => x.key === PRE).raw).raw, DAMAGED);
  });
});
