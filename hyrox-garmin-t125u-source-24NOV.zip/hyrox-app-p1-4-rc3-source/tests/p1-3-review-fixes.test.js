'use strict';
// P1.3 independent-review fixes (Claude, Workstream E, 23 Nov 2026) for Grok's P1.3-RC1 (e272258).
// C1 protein-floor identity, C2 Monday-Sunday review weeks, C3 honest session coverage, C4 below-floor own target.
// Synthetic data only. These tests FAIL on e272258 (except the C1 invariants, which pin behaviour that was already right).
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const path = require('path');
const ROOT = path.join(__dirname, '..');
const HC = require(path.join(ROOT, 'src', 'data', 'hyrox-coach.js'));
const HN = require(path.join(ROOT, 'src', 'data', 'hyrox-nutrition.js'));

// ---------- C1: 170 g is the provisional PROTEIN FLOOR, never carbohydrate; unknown is never zero ----------
test('C1: the provisional reference is 2,400 kcal, protein 190 g with a 170 g protein floor; it has no carbohydrate or fat figure', () => {
  assert.strictEqual(HN.PROVISIONAL.kcal, 2400);
  assert.strictEqual(HN.PROVISIONAL.proteinG, 190);
  assert.strictEqual(HN.PROVISIONAL.proteinFloorG, 170);
  assert.strictEqual(HN.PROVISIONAL.carbsG, undefined);
  const ref = HC.targetFor(null, '2026-11-23', HN.PROVISIONAL);
  assert.deepStrictEqual([ref.kcal, ref.proteinG, ref.proteinFloorG, ref.fatG, ref.carbsG, ref.origin], [2400, 190, 170, null, null, 'PROVISIONAL']);
  // carbs and fat stay unknown (null), never 0, and never 170
  assert.notStrictEqual(ref.carbsG, 0); assert.notStrictEqual(ref.carbsG, 170);
  // an own target with protein under 170 g is warned against the PROTEIN floor
  const chk = HC.checkOwnerTarget({ kcal: '2400', proteinG: '160', fatG: '', carbsG: '' }, { sex: 'MALE' });
  assert.ok(chk.warnings.some((w) => w.code === 'PROTEIN_BELOW_REFERENCE_FLOOR' && /Protein/.test(w.text) && /170 g/.test(w.text)));
  assert.ok(!HC.checkOwnerTarget({ kcal: '2400', proteinG: '170', fatG: '', carbsG: '' }, { sex: 'MALE' }).warnings.some((w) => w.code === 'PROTEIN_BELOW_REFERENCE_FLOOR'));
});

test('C1: the shipped notes describe 170 g as the protein floor and never as carbohydrate', () => {
  for (const f of ['CHANGES-P1.3-RC1.md', 'CHANGES-P1.3-RC2.md', 'P1.3-RC2-OWNER-BRIEF.md']) {
    const p = path.join(ROOT, f); if (!fs.existsSync(p)) continue;
    const s = fs.readFileSync(p, 'utf8');
    assert.doesNotMatch(s, /carbs? 170 g/i, f);
    assert.doesNotMatch(s, /2,400 \/ 190 \/ 170/, f + ': ambiguous triple');
  }
  assert.match(fs.readFileSync(path.join(ROOT, 'CHANGES-P1.3-RC2.md'), 'utf8'), /protein 190 g \(protein floor 170 g\)/);
});

// ---------- C2: review weeks are Monday-Sunday (Asia/Qatar dates), the same weeks as the plan and the rest of the app ----------
test('C2: the last completed review week ends on the Sunday before today; Monday is review day; Sunday itself is not finished', () => {
  assert.strictEqual(HC.lastCompletedSunday('2026-11-23'), '2026-11-22'); // Monday: the week that just ended
  assert.strictEqual(HC.lastCompletedSunday('2026-11-24'), '2026-11-22');
  assert.strictEqual(HC.lastCompletedSunday('2026-11-22'), '2026-11-15'); // Sunday: the current week is still open
  assert.strictEqual(HC.lastCompletedSunday('2026-11-28'), '2026-11-22'); // Saturday
  assert.deepStrictEqual(HC.reviewWeeks('2026-11-23', 2), [{ start: '2026-11-09', end: '2026-11-15' }, { start: '2026-11-16', end: '2026-11-22' }]);
  for (const t of ['2026-11-23', '2026-11-25', '2026-11-29', '2026-12-14', '2027-01-01']) {
    HC.reviewWeeks(t, 4).forEach((w) => {
      assert.strictEqual(new Date(w.start + 'T00:00:00Z').getUTCDay(), 1, 'starts Monday ' + w.start);
      assert.strictEqual(new Date(w.end + 'T00:00:00Z').getUTCDay(), 0, 'ends Sunday ' + w.end);
      assert.ok(w.end < t, 'never includes today ' + t);
    });
  }
  assert.strictEqual(HC.isReviewDay('2026-11-23'), true); assert.strictEqual(HC.isReviewDay('2026-11-22'), false);
  // Block 2 benchmark week: Monday 7 Dec - Sunday 13 Dec is reviewed on Monday 14 Dec, the Block 2 start day; it is never mixed with 14 Dec
  assert.deepStrictEqual(HC.reviewWeeks('2026-12-14', 1), [{ start: '2026-12-07', end: '2026-12-13' }]);
});

test('C2: Saturday and Sunday of the same week count together as its weekend complete days; no review text says Sunday-Saturday', () => {
  const days = [{ date: '2026-11-21', code: 'D5', kcal: 2300 }, { date: '2026-11-22', code: 'D5', kcal: 2200 }, { date: '2026-11-16', code: 'D5', kcal: 2100 }, { date: '2026-11-17', code: 'D5', kcal: 2000 }];
  const f = HC.weekFacts({ start: '2026-11-16', end: '2026-11-22' }, days, []);
  assert.deepStrictEqual([f.d5, f.weekendD5], [4, 2]);
  const src = fs.readFileSync(path.join(ROOT, 'src', 'data', 'hyrox-coach.js'), 'utf8') + fs.readFileSync(path.join(ROOT, 'src', 'ui', 'app-ext.js'), 'utf8');
  assert.doesNotMatch(src, /Sunday[–-]Saturday|Sunday review|review on Sunday|Next review Sunday/i);
});

// ---------- C3: unlogged and source-omitted sessions are not skipped sessions ----------
const ok = { weeks: [] };
const rec = (o) => ({ recovery: Object.assign({ flagDays: 0, maxPain: null }, o) });
test('C3: planned sessions that were simply not logged raise no amber concern and are never called skipped; they only hold a reduction', () => {
  const c = HC.concerns(ok, [], rec({ slots: { planned: 5, completed: 0, partial: 0, skipped: 0, unlogged: 5, omitted: 0 } }));
  assert.deepStrictEqual(c.map((x) => [x.code, x.level]), [['SESSION_LOG', 'HOLD']]);
  assert.match(c[0].text, /5 of 5 eligible planned sessions last week are not logged/); // wording re-pointed in RC3 (decision 3)
  assert.match(c[0].text, /unknown/); assert.doesNotMatch(c[0].text, /skipped|completed only|fewer than half/i);
  // status ignores the HOLD item: no amber, no "check recovery"
  const wk = (s, m) => ({ start: s, end: s, weighDays: 4, meanKg: m, weightOk: true, d5: 5, weekendD5: 1 });
  const sb = { weeks: [wk('a', 100), wk('b', 99.55), wk('c', 99.1)] };
  assert.strictEqual(HC.status(sb, c, 'LOSE_1', 'kg').level, 'GREEN');
  // but a lower target for an existing confirmed target is held, with that truthful reason
  const r = HC.reductionCheck({ ready: true, weeks: [] }, 'LOSE_1', { effectiveDate: '2026-10-01' }, c);
  assert.strictEqual(r.allowed, false); assert.match(r.why, /not logged/);
});

test('C3: source-directed omissions leave the denominator; confirmed skips drive the amber concern, measured against LOGGED sessions only', () => {
  // 5 planned: 2 omitted by the source cascade, 3 completed -> nothing to report
  assert.deepStrictEqual(HC.concerns(ok, [], rec({ slots: { planned: 5, completed: 3, partial: 0, skipped: 0, unlogged: 0, omitted: 2 } })), []);
  // 5 planned, all omitted by the source -> nothing to report (not "0 of 5")
  assert.deepStrictEqual(HC.concerns(ok, [], rec({ slots: { planned: 5, completed: 0, partial: 0, skipped: 0, unlogged: 0, omitted: 5 } })), []);
  // 3 skipped (confirmed), 1 completed, 1 unlogged: amber on the confirmed skips, measured on the 4 logged
  let c = HC.concerns(ok, [], rec({ slots: { planned: 5, completed: 1, partial: 0, skipped: 3, unlogged: 1, omitted: 0 } }));
  assert.deepStrictEqual(c.map((x) => [x.code, x.level]), [['SESSIONS', 'AMBER']]);
  assert.match(c[0].text, /3 of the 4 logged planned sessions were skipped/);
  // partial counts as work done
  assert.deepStrictEqual(HC.concerns(ok, [], rec({ slots: { planned: 4, completed: 0, partial: 2, skipped: 2, unlogged: 0, omitted: 0 } })), []);
  // a single logged skip is too little to call a pattern
  assert.deepStrictEqual(HC.concerns(ok, [], rec({ slots: { planned: 4, completed: 0, partial: 0, skipped: 1, unlogged: 1, omitted: 2 } })), []);
  // more than half unlogged AND confirmed skips: both facts, each named for what it is
  c = HC.concerns(ok, [], rec({ slots: { planned: 6, completed: 0, partial: 0, skipped: 2, unlogged: 4, omitted: 0 } }));
  assert.deepStrictEqual(c.map((x) => x.code).sort(), ['SESSIONS', 'SESSION_LOG']);
  // no planned sessions at all (rest week / outside the plan) -> nothing
  assert.deepStrictEqual(HC.concerns(ok, [], rec({ slots: { planned: 0, completed: 0, partial: 0, skipped: 0, unlogged: 0, omitted: 0 } })), []);
  // the old ambiguous inputs (plannedDone / plannedTotal) are no longer read
  assert.deepStrictEqual(HC.concerns(ok, [], rec({ plannedDone: 0, plannedTotal: 4 })), []);
});

// ---------- C4: an own target below the provisional floor is never "on track" ----------
test('C4: a confirmed target below the provisional floor (or the resting estimate) is an amber concern, so status is never "On track"', () => {
  const wk = (s, m) => ({ start: s, end: s, weighDays: 4, meanKg: m, weightOk: true, d5: 5, weekendD5: 1 });
  const sb = { weeks: [wk('a', 100), wk('b', 99.55), wk('c', 99.1)] };
  let c = HC.concerns(sb, [], { floorKcal: 1500, target: { kcal: 1000, origin: 'OWNER_ENTERED' } });
  assert.deepStrictEqual(c.map((x) => [x.code, x.level]), [['LOW_TARGET', 'AMBER']]);
  assert.match(c[0].text, /1,000 kcal/); assert.match(c[0].text, /below the provisional floor of 1,500 kcal/); assert.match(c[0].text, /clinician/);
  const st = HC.status(sb, c, 'LOSE_1', 'kg');
  assert.strictEqual(st.level, 'AMBER'); assert.doesNotMatch(st.text + st.label, /On track/);
  // resting estimate above the general floor is used
  c = HC.concerns(sb, [], { floorKcal: 1500, restingKcal: 1850, target: { kcal: 1700, origin: 'OWNER_ENTERED' } });
  assert.match(c[0].text, /1,850 kcal/);
  // at or above the floor, or the provisional reference: nothing
  assert.deepStrictEqual(HC.concerns(sb, [], { floorKcal: 1500, target: { kcal: 1500, origin: 'OWNER_ENTERED' } }), []);
  assert.deepStrictEqual(HC.concerns(sb, [], { floorKcal: 1500, target: { kcal: 2400, origin: 'PROVISIONAL' } }), []);
  // and no lower computed target is offered while it stands
  const pr = HC.proposal({ maintenance: 2400, resting: 1700, source: 'STAGE_A', weightKg: 100, sex: 'MALE', goalId: 'LOSE_1', current: { kcal: 2000, proteinG: 190 }, concerns: c.length ? c.map((x) => x.text) : ['x'] });
  assert.notStrictEqual(pr.state, 'AVAILABLE');
});

// Re-pointed for P1.3-RC3 (owner decision 1): RC2 accepted a below-floor target after a separate tick; RC3 refuses it.
test('C4: the entered-target check refuses below-floor and below-resting targets (RC3); normal targets are accepted', () => {
  const chk = HC.checkOwnerTarget({ kcal: '1000', proteinG: '190', fatG: '', carbsG: '' }, { sex: 'MALE', restingKcal: 1850, currentKcal: 2400 });
  assert.strictEqual(chk.ok, false);
  assert.strictEqual(HC.checkOwnerTarget({ kcal: '2200', proteinG: '190', fatG: '', carbsG: '' }, { sex: 'MALE', restingKcal: 1850 }).ok, true);
  // persisted values below the data-entry range are refused as invalid, not shown as a target
  const bad = { schema: 1, enabled: true, history: [{ kcal: 900, proteinG: 190, fatG: null, carbsG: null, origin: 'OWNER_ENTERED', effectiveDate: '2026-11-20', confirmedAt: '2026-11-20T05:00:00.000Z' }] };
  assert.strictEqual(HC.readCoach({ nutritionCoach: bad }).valid, false);
  for (const v of ['999', '-1500', '1500.5', 'abc', '6001']) assert.strictEqual(HC.checkOwnerTarget({ kcal: v, proteinG: '190' }, {}).ok, false, v);
});

// ---------- C8: one good first week (4 weigh-ins, 6 complete days, fast early loss) never activates the personal estimate ----------
test('C8 (uses the Monday-Sunday weeks of C2): a single strong first week gives no personal estimate, no trend status and no reduction', () => {
  const TD = '2026-11-23', days = [], weights = [];
  // only the week Mon 16 - Sun 22 has data: 4 weigh-ins falling 1.6 kg (typical early water loss), 6 complete days (D5)
  [['2026-11-16', 100], ['2026-11-18', 99.3], ['2026-11-20', 98.8], ['2026-11-22', 98.4]].forEach(([d, kg]) => weights.push({ date: d, kg }));
  for (let d = '2026-11-16'; d <= '2026-11-22'; d = HC.addDays(d, 1)) days.push(d === '2026-11-19' ? { date: d, code: 'D3', kcal: null, estKcal: null } : { date: d, code: 'D5', kcal: 1900, estKcal: 600 });
  const sb = HC.stageB(days, weights, TD);
  assert.strictEqual(sb.ready, false); assert.strictEqual(sb.qualifying, 1); assert.strictEqual(sb.maintenance, undefined);
  assert.match(sb.text, /1 of 4 completed weeks qualify \(3 needed\)/);
  const st = HC.status(sb, HC.concerns(sb, days, {}), 'LOSE_1', 'kg');
  assert.strictEqual(st.level, 'GRAY'); assert.match(st.text, /One week is not a trend/);
  assert.strictEqual(HC.reductionCheck(sb, 'LOSE_1', { effectiveDate: '2026-11-01' }, []).allowed, false);
  // missing days are not filled in: the unquantified day carries no intake and the fast week is not extrapolated
  const f = sb.weeks[3];
  assert.deepStrictEqual([f.d5, f.excludedDays, f.kcalMean], [6, 1, 1900]);
});

// ---------- packaging of P1.3-RC2 ----------
test('P1.3-RC2 package: label, build folder, notes name the reviewed candidate, the fixes, the rollback order and the iPhone checks', () => {
  const rd = (f) => fs.readFileSync(path.join(ROOT, f), 'utf8');
  assert.match(rd('index.html'), /<meta name="hyrox-release" content="(P1\.3-RC[23]|P1\.4-RC[123])">/); // RE-POINTED by P1.4-RC2 (Sprint B2, 23 Nov 2026); // RE-POINTED by the integrated candidate P1.4-RC1 (23 Nov 2026); // RC3 since 23 Nov // RE-POINTED by P1.4-RC3 (Claude independent QA, 23 Nov 2026)
  assert.match(rd('index.html'), /\['src\/data\/hyrox-coach\.js', 'HyroxCoach'\]/);
  assert.match(rd('tools/build-deploy-package.mjs'), /'hyrox-p1-(3-rc[23]|4-rc[123])-deploy'/); // RE-POINTED by P1.4-RC2 (Sprint B2, 23 Nov 2026); // RE-POINTED by the integrated candidate P1.4-RC1 (23 Nov 2026); // RE-POINTED by P1.4-RC3 (Claude independent QA, 23 Nov 2026)
  const c = rd('CHANGES-P1.3-RC2.md'), d = rd('DEPLOY-P1.3-RC2.md'), b = rd('P1.3-RC2-OWNER-BRIEF.md');
  for (const re of [/e272258/, /d0d7d8ab86a1/, /a90ff6b707a89674e0a0fd2cb2bfcb286515cf6fb7563e891bae6457f83601b0/, /Monday–Sunday/, /unknown/, /UNAVAILABLE/, /Not deployed, not\s+pushed/, /Not Safari, not a physical iPhone/]) assert.match(c, re);
  for (const re of [/not deploy approval/i, /56f7a2c12c998d0c48ce9632764cf77454bd89e56ffab6f5f3411d60ccb2e143/, /d0d7d8ab86a1/, /Confirm without the tick\s+is refused/, /After midnight/, /same origin/, /Monday–Sunday/, /F-1/]) assert.match(d, re);
  assert.match(b, /protein 190 g, with a protein floor of 170 g/); assert.match(b, /Not deployed, not pushed/);
  assert.match(rd('deploy/README-DEPLOY.txt'), /^HYROX Command (P1\.3-RC[23]|P1\.4-RC[123]) deploy package/m); // RE-POINTED by P1.4-RC2 (Sprint B2, 23 Nov 2026); // RE-POINTED by the integrated candidate P1.4-RC1 (23 Nov 2026); // RE-POINTED by P1.4-RC3 (Claude independent QA, 23 Nov 2026)
});
