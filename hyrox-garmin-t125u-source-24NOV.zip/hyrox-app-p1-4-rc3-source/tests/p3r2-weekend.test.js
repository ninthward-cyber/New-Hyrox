'use strict';
// Dawit R2 / D2: no weekend gym make-up; never-stack = two DEMANDING sessions; truthful weekend actuals. Synthetic data only.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const HD = require(path.resolve(__dirname, '../src/data/hyrox-data.js'));
const HP = require(path.resolve(__dirname, '../src/data/hyrox-plan.js'));
const { mem } = require('./p8-helpers.js');

const WEEKDAYS = ['MON', 'TUE', 'WED', 'THU', 'FRI'];
const WEEKENDS = { 1: ['2026-11-21', '2026-11-22'], 2: ['2026-11-28', '2026-11-29'], 3: ['2026-12-05', '2026-12-06'], 4: ['2026-12-12', '2026-12-13'] };
const isWeekend = (d) => [0, 6].includes(new Date(d + 'T00:00:00Z').getUTCDay());
const sess = (o) => Object.assign({ id: 'x' + Math.random().toString(36).slice(2), createdAt: '2026-11-18T08:00:00.000Z', status: 'COMPLETED', modified: false, variant: 'NONE', blocks: [], planSlotId: null }, o);

describe('weekend is never a make-up for a weekday gym session', () => {
  it('rescheduleCheck refuses Sat/Sun for every weekday slot in every week, with the right code', () => {
    for (let w = 1; w <= 4; w++) for (const d of WEEKDAYS) for (const date of WEEKENDS[w]) {
      const r = HP.rescheduleCheck('v2.1-W' + w + '-' + d, date, [], [], '2026-11-16');
      assert.equal(r.ok, false, d + ' -> ' + date);
      assert.equal(r.code, d === 'FRI' ? 'FRIDAY_NO_WEEKEND_MAKEUP' : 'WEEKEND_NO_GYM_MAKEUP');
      assert.match(r.reason, /no weekend make-up/);
    }
  });
  it('rescheduleDates and skipAdvice never offer a weekend date (with and without cascades)', () => {
    const evs = [[], [{ kind: 'MISSED_MONDAY', week: 2 }], [{ kind: 'MISSED_WEDNESDAY', week: 3 }]];
    for (const e of evs) for (const sl of HP.SLOTS) {
      assert.equal(HP.rescheduleDates(sl.id, [], e, '2026-11-16').some(isWeekend), false, sl.id);
      assert.equal(HP.skipAdvice(sl.id, [], e, '2026-11-16').options.RESCHEDULE.dates.some(isWeekend), false, sl.id);
    }
    const a = HP.skipAdvice('v2.1-W1-TUE', [], [], '2026-11-18');
    assert.equal(a.options.RESCHEDULE.available, false); assert.match(a.options.RESCHEDULE.note, /weekends are not gym make-up days/);
  });
  it('a free weekday (cascade-freed Monday) can still be chosen: the option is not removed for weekdays', () => {
    const r = HP.rescheduleCheck('v2.1-W1-TUE', '2026-11-23', [], [{ kind: 'MISSED_MONDAY', week: 2 }], '2026-11-18');
    assert.equal(r.ok, true); assert.equal(r.code, 'OK'); assert.doesNotMatch(r.caution, /weekend/);
  });
  it('other refusal codes', () => {
    const c = (date, today) => HP.rescheduleCheck('v2.1-W1-TUE', date, [], [], today || '2026-11-18').code;
    assert.equal(HP.rescheduleCheck('nope', '2026-11-23', [], [], '2026-11-18').code, 'UNKNOWN_SLOT');
    assert.equal(c('soon'), 'NO_DATE'); assert.equal(c('2026-11-16'), 'PAST'); assert.equal(c('2026-11-17', '2026-11-16'), 'ORIGINAL_DATE');
    assert.equal(c('2026-12-14'), 'OUTSIDE_BLOCK'); assert.equal(c('2026-11-19'), 'PLANNED_SESSION_ON_DAY');
  });
});

describe('Mon/Wed cascades and Friday skip unchanged; optional weekend stays available and is not a make-up', () => {
  it('cascade shapes are exactly as before', () => {
    assert.deepEqual(HP.effectiveWeek(2, [{ kind: 'MISSED_MONDAY', week: 2 }]).days.map((d) => d.show.map((x) => x.slot.day)), [[], ['MON'], ['WED'], ['TUE'], ['FRI']]);
    assert.deepEqual(HP.effectiveWeek(2, [{ kind: 'MISSED_WEDNESDAY', week: 2 }]).days.map((d) => d.show.map((x) => x.slot.day)), [['MON'], ['TUE'], [], ['WED'], ['FRI']]);
    assert.notEqual(HP.effectiveWeek(2, [{ kind: 'MISSED_MONDAY', week: 2 }, { kind: 'MISSED_WEDNESDAY', week: 2 }]).unresolved, null, 'both-missed stays unresolved (HOLD)');
  });
  it('weekendOptions: Saturday light activity from W2, Sunday mobility always; never counted, never a gym make-up', () => {
    const w1 = HP.effectiveWeek(1, []), w2 = HP.effectiveWeek(2, []);
    assert.equal(w1.weekendMakeUp, false);
    assert.deepEqual(w1.weekendOptions.map((o) => [o.day, o.kind, o.available]), [['SAT', 'OPTIONAL_LIGHT_SATURDAY', false], ['SUN', 'SUNDAY_MOBILITY', true]]);
    assert.deepEqual(w2.weekendOptions.map((o) => [o.date, o.available, o.counted, o.gymMakeUp]), [['2026-11-28', true, false, false], ['2026-11-29', true, false, false]]);
    assert.equal(w1.weekend, null); assert.equal(w2.weekend.counted, false);
    assert.match(w1.fridayNote, /no weekend make-up/);
  });
});

describe('a weekend gym workout actually performed is stored truthfully and does not relabel the missed prescription', () => {
  it('the store accepts it; slotStatus keeps SKIPPED and reports it as weekend actual work', () => {
    const st = HD.createStore(mem(), { now: () => new Date('2026-11-21T10:00:00Z') });
    const skip = { date: '2026-11-17', planSlotId: 'v2.1-W1-TUE', status: 'SKIPPED', skipConfirmed: true, skipDecision: 'SKIP_PERMANENT', modified: false, variant: 'NONE', blocks: [], scheduledDate: '2026-11-17' };
    assert.equal(st.putRecord('sessions', skip).ok, true);
    const sat = { date: '2026-11-21', planSlotId: 'v2.1-W1-TUE', status: 'COMPLETED', modified: true, variant: 'OTHER_EXECUTION', blocks: [{ kind: 'run', durationSec: 600 }], rpe: 6 };
    assert.equal(st.putRecord('sessions', sat).ok, true, 'truthful logging is never refused');
    const all = st.records('sessions');
    assert.equal(all.length, 2);
    const s = HP.slotStatus('v2.1-W1-TUE', all, []);
    assert.equal(s.code, 'SKIPPED'); assert.equal(s.skipDecision, 'SKIP_PERMANENT');
    assert.equal(s.offPlan, 'WEEKEND_ACTUAL_NOT_SOURCE_RESCHEDULE'); assert.equal(s.weekendWork.length, 1); assert.equal(s.weekendWork[0].date, '2026-11-21');
    assert.equal(s.rescheduleNotSourceApproved, undefined);
    const sum = HP.summary(all, []);
    assert.equal(sum.SKIPPED, 1); assert.equal(sum.COMPLETED, 0); assert.equal(sum.weekendActual, 1); assert.equal(sum.denominator, 20);
    // the record itself is unchanged
    const stored = all.filter((x) => x.date === '2026-11-21')[0];
    assert.equal(stored.planSlotId, 'v2.1-W1-TUE'); assert.equal(stored.status, 'COMPLETED');
  });
  it('a weekday slot with no other record shows NOT_LOGGED plus the weekend work', () => {
    const s = HP.slotStatus('v2.1-W1-THU', [sess({ planSlotId: 'v2.1-W1-THU', date: '2026-11-22' })], []);
    assert.equal(s.code, 'NOT_LOGGED'); assert.equal(s.weekendWork.length, 1);
  });
  it('weekday work still speaks for the slot as before (no weekendWork field)', () => {
    const s = HP.slotStatus('v2.1-W1-THU', [sess({ planSlotId: 'v2.1-W1-THU', date: '2026-11-19' })], []);
    assert.equal(s.code, 'COMPLETED'); assert.equal(s.weekendWork, undefined);
  });
  it('a weekend Friday benchmark attempt is not the planned benchmark', () => {
    const b = HP.benchmarks([sess({ planSlotId: 'v2.1-W2-FRI', date: '2026-11-28', variant: 'ORIGINAL_60' })]);
    assert.equal(b[0].status, 'NOT_LOGGED'); assert.equal(b[0].comparable, false);
  });
  it('a legacy SKIPPED -> RESCHEDULE to a weekend is kept but flagged as not source-approved', () => {
    const s = HP.slotStatus('v2.1-W1-WED', [sess({ planSlotId: 'v2.1-W1-WED', date: '2026-11-18', status: 'SKIPPED', skipConfirmed: true, skipDecision: 'RESCHEDULE', rescheduledTo: '2026-11-22' })], []);
    assert.equal(s.code, 'SKIPPED'); assert.equal(s.rescheduledTo, '2026-11-22'); assert.equal(s.rescheduleNotSourceApproved, true);
  });
});

describe('never-stack = two DEMANDING sessions; easy walking + a workout is fine (F3)', () => {
  const freeMon = [{ kind: 'MISSED_MONDAY', week: 2 }];
  const chk = (logged) => HP.rescheduleCheck('v2.1-W1-TUE', '2026-11-23', logged, freeMon, '2026-11-18');
  it('isDemandingSession branches', () => {
    assert.equal(HP.isDemandingSession(null), false);
    assert.equal(HP.isDemandingSession(sess({ planSlotId: 'v2.1-W1-THU', rpe: 2, intensity: 'EASY' })), true, 'a programmed gym session is demanding');
    assert.equal(HP.isDemandingSession(sess({ intensity: 'EASY', rpe: 9 })), false, 'owner said easy');
    assert.equal(HP.isDemandingSession(sess({ intensity: 'DEMANDING', rpe: 2 })), true);
    assert.equal(HP.isDemandingSession(sess({ rpe: 2 })), false);
    assert.equal(HP.isDemandingSession(sess({ rpe: 4, blocks: [{ kind: 'walk' }, { kind: 'mobility' }] })), false);
    assert.equal(HP.isDemandingSession(sess({ rpe: 5 })), true);
    assert.equal(HP.isDemandingSession(sess({ rpe: 3, blocks: [{ kind: 'run' }] })), true);
    assert.equal(HP.isDemandingSession(sess({})), true, 'unknown effort counts as demanding');
  });
  it('rescheduleCheck: easy walk session on the day is allowed; a demanding one is refused', () => {
    assert.equal(chk([sess({ date: '2026-11-23', title: 'Easy walk', rpe: 2, blocks: [{ kind: 'walk' }] })]).ok, true);
    const r = chk([sess({ date: '2026-11-23', title: 'Hard spin', rpe: 8 })]);
    assert.equal(r.ok, false); assert.equal(r.code, 'DEMANDING_SESSION_LOGGED');
    assert.equal(chk([sess({ date: '2026-11-23', rpe: 2, status: 'SKIPPED', skipConfirmed: true })]).ok, true, 'a skipped session is not load');
  });
  it('truthful logging of a walk session, a walks[] record and a strength workout on one day is accepted; dayLoad reports it', () => {
    const st = HD.createStore(mem(), { now: () => new Date('2026-11-18T15:00:00Z') });
    assert.equal(st.putRecord('walks', { date: '2026-11-16', durationMin: 30, steps: 3500 }).ok, true);
    assert.equal(st.putRecord('sessions', { date: '2026-11-16', status: 'COMPLETED', modified: false, variant: 'NONE', blocks: [{ kind: 'walk' }], rpe: 2, intensity: 'EASY', title: 'Easy walk' }).ok, true);
    assert.equal(st.putRecord('sessions', { date: '2026-11-16', planSlotId: 'v2.1-W1-MON', status: 'COMPLETED', modified: false, variant: 'ORIGINAL_60', blocks: [], rpe: 7 }).ok, true);
    const l = HP.dayLoad('2026-11-16', st.records('sessions'), []);
    assert.equal(l.demandingLogged.length, 1); assert.equal(l.easyLogged.length, 1); assert.equal(l.stackedDemanding, false); assert.equal(l.flag, null);
    assert.deepEqual(l.planned, ['v2.1-W1-MON']);
  });
  it('two demanding sessions actually done are still stored (truth), and flagged — never created automatically', () => {
    const st = HD.createStore(mem(), { now: () => new Date('2026-11-18T15:00:00Z') });
    assert.equal(st.putRecord('sessions', { date: '2026-11-17', planSlotId: 'v2.1-W1-TUE', status: 'COMPLETED', modified: false, variant: 'ORIGINAL_60', blocks: [] }).ok, true);
    assert.equal(st.putRecord('sessions', { date: '2026-11-17', status: 'COMPLETED', modified: false, variant: 'NONE', blocks: [], rpe: 8, title: 'Extra' }).ok, true);
    const l = HP.dayLoad('2026-11-17', st.records('sessions'), []);
    assert.equal(l.stackedDemanding, true); assert.equal(l.flag, 'TWO_DEMANDING_SESSIONS_LOGGED');
  });
  it('intensity is validated', () => {
    const st = HD.createStore(mem(), { now: () => new Date('2026-11-18T15:00:00Z') });
    assert.equal(st.putRecord('sessions', { date: '2026-11-17', status: 'COMPLETED', modified: false, variant: 'NONE', blocks: [], intensity: 'MEDIUM' }).ok, false);
  });
});
