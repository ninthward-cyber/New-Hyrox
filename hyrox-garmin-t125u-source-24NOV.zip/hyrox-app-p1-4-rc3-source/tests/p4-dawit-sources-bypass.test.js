'use strict';
// P4 (Dawit): regression for Meron's sources-bypass DEFECTs (p4/qa 8eb5fab,
// tests/p4-meron-sources-bypass.test.js) against 5e5d18f, which refused only an exact
// top-level `sources` key. The first describe block is copied from that file with the same
// assertions (her helpers copied too); the rest are Dawit's extras. Synthetic data only.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const { HD, KEY, PRE, mem, mk, O, U, K, ts, backup, restore } = require('./p3-helpers.js');

const D = '2026-11-10';
const badDaily = () => ({
  id: 'daily-' + D, createdAt: ts, updatedAt: ts, date: D,
  footPain: O(11), stairKneePain: O(1), sleepH: O(7),
  limp: { state: 'OBSERVED', value: false }, steps: O(8000), soreness: O(2), rhr: O(60),
});
function seed(lists) {
  const raw = JSON.stringify(Object.assign({
    version: 2,
    weight: [{ id: 'w1', createdAt: ts, date: D, kg: 80 }],
    workouts: [], nutrition: [],
  }, lists));
  const s = mem({ [KEY]: raw });
  return { s, st: mk(s), raw };
}
function rawObj() {
  const r = seed({ daily: [badDaily()] }).st.rawRecoveryExport();
  assert.equal(r.ok, true);
  return JSON.parse(r.text);
}
function editedRaw(mutate) {
  const o = Object.assign({}, rawObj(), { app: 'hyrox-app', version: 2, weight: [], workouts: [], nutrition: [] });
  delete o.kind;
  if (mutate) mutate(o);
  return o;
}
function liveDevice() {
  const s = mem();
  const st = mk(s);
  assert.equal(st.addWeight({ date: D, kg: 80 }).ok, true);
  assert.equal(st.putRecord('walks', { date: D, durationMin: 30, steps: 3000 }).ok, true);
  const p = st.previewImport(st.exportJSON());
  assert.equal(p.ok, true);
  return { s, st, current: p.preview.current, currentExt: p.preview.currentExt, before: snapAll(s), writes: s.writes };
}
const snapAll = (s) => JSON.stringify(Object.keys(s.m).sort().map((k) => [k, s.m[k]]));

function assertWipesOrReplaces(text) {
  const { s, st, current, currentExt, before, writes } = liveDevice();
  const p = st.previewImport(text);
  assert.equal(p.ok, false, 'previewImport must refuse an edited emergency file');
  assert.equal(p.code, 'raw_recovery_file');
  const a = st.applyImport(text, { confirm: 'REPLACE', expectCurrent: current, expectCurrentExt: currentExt });
  assert.equal(a.ok, false, 'applyImport (direct) must refuse an edited emergency file');
  assert.equal(a.code, 'raw_recovery_file');
  assert.equal(s.writes, writes);
  assert.equal(snapAll(s), before);
  assert.equal(st.list('weight').length, 1);
  assert.equal(st.list('weight')[0].kg, 80);
}

// ---- Copied verbatim from p4/qa 8eb5fab (Meron), same assertions ----
describe('DEFECT: an edited emergency raw file can still replace live data if the top-level sources key is renamed, nested, or removed', () => {
  function renamed(key) {
    return JSON.stringify(editedRaw((o) => { const s = o.sources; delete o.sources; o[key] = s; }));
  }

  it('renaming sources to Sources, SOURCES, a spaced or look-alike key, or a zero-width/nbsp variant still wipes live data; this must be refused', () => {
    const keys = [
      'Sources', 'SOURCES', ' sources',
      'sources\u200b', 'sour\u200bces',
      '\u0441ources', // Cyrillic es
      '\u0455ources', // Cyrillic dze
      'sources\u00a0',
      '\ufeffsources',
    ];
    for (const k of keys) assertWipesOrReplaces(renamed(k));
  });

  it('moving sources under a wrapper, to depth 2, or inside a weight/workouts/nutrition entry still lets the file replace live data; this must be refused', () => {
    const copies = rawObj().sources;
    assertWipesOrReplaces(JSON.stringify(editedRaw((o) => { delete o.sources; o.wrapper = { sources: copies }; })));
    assertWipesOrReplaces(JSON.stringify(editedRaw((o) => { delete o.sources; o.meta = { deep: { sources: copies } }; })));
    assertWipesOrReplaces(JSON.stringify(editedRaw((o) => {
      delete o.sources;
      o.weight = [{ id: 'planted', createdAt: ts, date: D, kg: 70, sources: copies }];
    })));
  });

  it('deleting sources but leaving warning/format/normalExport/omitted (still an identifiable edited raw file) wipes live data; this must be refused', () => {
    assertWipesOrReplaces(JSON.stringify(editedRaw((o) => { delete o.sources; })));
  });

  it('stuffing sources under __proto__ after removing the top-level field wipes live data; this must be refused', () => {
    const o = editedRaw((x) => { delete x.sources; });
    const text = JSON.stringify(o).replace(/^{/, '{"__proto__":{"sources":' + JSON.stringify(rawObj().sources) + '},');
    assertWipesOrReplaces(text);
  });

  it('deleting sources and planting a partial weight list replaces live data with that list; this must be refused', () => {
    assertWipesOrReplaces(JSON.stringify(editedRaw((o) => {
      delete o.sources;
      o.weight = [{ id: 'x1', createdAt: ts, date: D, kg: 70 }];
    })));
  });
});

// ---- Dawit extras ----
const MARKERS_ALONE = ['warning', 'omitted', 'omittedTotal', 'normalExport'];
const ALL_MARKERS = ['sources', 'warning', 'format', 'normalExport', 'omitted', 'omittedTotal', 'state'];
const norm = (k) => k.normalize('NFKC').replace(/[\u00AD\u180E\u200B-\u200F\u2060-\u2064\uFEFF]/g, '').trim().toLowerCase();

// Refused on preview and on direct apply; exact refusal shape; zero writes; every key byte-identical.
function refusedBoth(text, keyInMessage) {
  const { s, st, current, currentExt, before, writes } = liveDevice();
  const p = st.previewImport(text);
  assert.deepEqual(Object.keys(p).sort(), ['code', 'errors', 'message', 'ok']);
  assert.equal(p.ok, false); assert.equal(p.code, 'raw_recovery_file'); assert.deepEqual(p.errors, []);
  assert.match(p.message, /emergency raw recovery/i); assert.match(p.message, /not a normal backup/); assert.match(p.message, /nothing was changed/i);
  if (keyInMessage) assert.ok(p.message.includes(keyInMessage), 'message names ' + keyInMessage + ': ' + p.message);
  assert.equal(s.writes, writes, 'preview writes nothing'); assert.equal(snapAll(s), before);
  const a = st.applyImport(text, { confirm: 'REPLACE', expectCurrent: current, expectCurrentExt: currentExt });
  assert.equal(a.ok, false); assert.equal(a.code, 'raw_recovery_file'); assert.deepEqual(a.errors, []);
  assert.equal(a.rolledBack, false); assert.equal(a.backupKey, null);
  assert.equal(a.message, p.message);
  assert.equal(s.writes, writes, 'apply writes nothing'); assert.equal(snapAll(s), before);
  assert.equal(Object.prototype.hasOwnProperty.call(s.m, PRE), false, 'no pre-import slot written');
  assert.equal(st.list('weight')[0].kg, 80); assert.equal(st.records('walks').length, 1);
  return p;
}
function acceptedRestores(text, kg) {
  const { st } = liveDevice();
  const p = st.previewImport(text);
  assert.equal(p.ok, true, 'must not false-refuse: ' + JSON.stringify(p));
  const a = st.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt, confirmEmptyReplace: true });
  assert.equal(a.ok, true);
  if (kg !== undefined) assert.equal(st.list('weight')[0].kg, kg);
  return p;
}
const W79 = [{ id: 'n1', createdAt: ts, date: D, kg: 79 }];

describe('P4 sources-bypass: each emergency-file marker refuses on its own (no sources key at all)', () => {
  for (const m of MARKERS_ALONE) {
    it('a normal-looking backup with a top-level "' + m + '" field is refused on both paths, nothing written', () => {
      refusedBoth(backup({ weight: W79, [m]: m === 'omittedTotal' ? 0 : m === 'omitted' ? {} : 'x' }), '"' + m + '"');
    });
  }
  it('case/zero-width variants of a marker name are refused too (Warning, NORMALEXPORT, omitted+ZWSP)', () => {
    refusedBoth(backup({ Warning: 'x' }), 'warning');
    refusedBoth(backup({ NORMALEXPORT: 'complete' }), 'normalExport');
    refusedBoth(backup({ 'omitted\u200b': {} }), 'omitted');
  });
  it('the untouched raw file keeps its original refusal message', () => {
    const { st } = liveDevice();
    const r = st.previewImport(JSON.stringify(rawObj()));
    assert.equal(r.message, 'This is an emergency raw recovery copy, not a normal backup, so it cannot be restored here. Keep it safe; nothing was changed.');
  });
  it('an exact top-level "sources" field keeps the 5e5d18f message', () => {
    const p = refusedBoth(backup({ sources: [] }), '"sources"');
    assert.match(p.message, /even if it was edited/);
  });
});

describe('P4 sources-bypass: Object.prototype names are not mistaken for markers', () => {
  it('top-level constructor/toString/hasOwnProperty/valueOf fields are accepted as unknown fields', () => {
    acceptedRestores(backup({ weight: W79, constructor: { a: 1 }, toString: 'x', hasOwnProperty: 1, valueOf: null }), 79);
    acceptedRestores(backup({ weight: W79 }).replace(/^{/, '{"__proto__":{"constructor":1},'), 79);
  });
  it('a very long look-alike key is shown shortened in the message', () => {
    const p = refusedBoth(backup({ ['SOURCES' + 'x'.repeat(0)]: [], }));
    assert.ok(p.message.length < 400);
    const q = refusedBoth(backup({ ['\u200b'.repeat(200) + 'Sources']: [] }));
    assert.ok(q.message.length < 400, q.message.length);
  });
});

describe('P4 sources-bypass: "format" collides with a legitimate fixture, so it refuses only in combination', () => {
  it('a genuine backup with format:1 plus source/sourcesCount/kindOfBackup is accepted with a warning and restores', () => {
    const text = backup({ weight: W79, notes: 'hi', source: 'phone', kindOfBackup: 'manual', format: 1, sourcesCount: 2 });
    const p = acceptedRestores(text, 79);
    assert.ok(p.preview.warnings.some((w) => /unknown top-level/i.test(w)), JSON.stringify(p.preview.warnings));
  });
  it('a lone top-level "state" is accepted (not a marker on its own)', () => {
    acceptedRestores(backup({ weight: W79, state: 'ok' }), 79);
  });
  it('format together with the raw-only "state" field is refused', () => {
    refusedBoth(backup({ format: 1, state: 'ok' }), '"format"');
  });
});

describe('P4 sources-bypass: normalized sources-like key at the top level, no other marker', () => {
  const variants = ['Sources', 'SOURCES', ' sources', 'sources ', 'sources\u200b', 'sour\u200bces', 'sources\u00a0', '\ufeffsources',
    '\u200dsources\u2060', 'ｓｏｕｒｃｅｓ' /* fullwidth, NFKC -> sources */, 'SOUR\u00adCES'];
  for (const k of variants) {
    it('key ' + JSON.stringify(k) + ' is refused on both paths', () => {
      refusedBoth(backup({ [k]: [] }), 'sources');
    });
  }
});

describe('P4 sources-bypass: nested sources-like key (item 2), no other marker', () => {
  it('under a top-level wrapper object, at depth 2, and under a JSON "__proto__" key: refused', () => {
    refusedBoth(backup({ wrapper: { sources: [] } }), 'wrapper');
    refusedBoth(backup({ meta: { deep: { Sources: null } } }), 'meta.deep');
    refusedBoth(backup({}).replace(/^{/, '{"__proto__":{"sources":[]},'), '__proto__');
  });
  it('inside a weight/workouts/nutrition entry: refused (those entries only ever hold rule fields)', () => {
    refusedBoth(backup({ weight: [{ id: 'p', createdAt: ts, date: D, kg: 70, sources: [] }] }), 'weight[0]');
    refusedBoth(backup({ nutrition: [{ id: 'p', createdAt: ts, date: D, calories: 1, proteinG: 1, 'SOURCES': 1 }] }), 'nutrition[0]');
  });
  it('wrappers WITHOUT a sources-like key are still accepted (unknown fields are ignored with a warning)', () => {
    acceptedRestores(backup({ weight: W79, meta: { note: 'Ü — 体重', deep: { source: 'phone', sourcesCount: 2 } } }), 79);
  });
  it('DECLINED: a Phase 3 entry with a "sources" field is NOT refused, because putRecord stores it and exportJSON writes it back', () => {
    const s = mem(); const st = mk(s);
    assert.equal(st.putRecord('walks', { date: D, durationMin: 30, steps: 3000, sources: ['x'], note: 'Ü' }).ok, true);
    const text = st.exportJSON();
    assert.deepEqual(JSON.parse(text).walks[0].sources, ['x'], 'the app itself writes it');
    acceptedRestores(text);
  });
});

// A rich normal export: every list type, unicode text, note fields, an ext record with an unknown field.
function richDevice() {
  const s = mem(); const st = mk(s);
  assert.equal(st.addWeight({ date: D, kg: 80.4 }).ok, true);
  assert.equal(st.addWorkout({ date: D, activity: 'Run ü 走る', durationMin: 40, partial: true, notes: 'Ü café — 走る 🏃 "sources" warning' }).ok, true);
  assert.equal(st.addNutrition({ date: D, label: 'شاي format omitted', calories: 500, proteinG: 30.5 }).ok, true);
  const recs = {
    sessions: { date: D, status: 'PARTIAL', modified: false, variant: 'NONE', blocks: [{ kind: 'run', notes: 'zero\u200bwidth', omitted: false }] },
    meals: { date: D, label: 'Lunch ü', source: 'MANUAL', lifecycle: 'CONFIRMED', confirmedAt: ts,
      components: [{ name: 'Rice', role: 'SIDE', kcal: K(240), proteinG: K(5), carbsG: U, fatG: K(0) }] },
    body: { date: D, metric: 'waist_cm', state: 'OBSERVED', value: 90 },
    daily: { date: D, steps: O(8000), note: 'warning: sore' },
    walks: { date: D, durationMin: 30, note: 'normalExport', source: 'phone' },
    dayStates: { date: D, attestation: 'INCOMPLETE', basis: '0:x' },
    planEvents: { date: '2026-11-09', kind: 'MISSED_MONDAY', week: 1 },
    ownerSettings: { id: HD.SETTINGS_ID, date: D, rhrBaselineBpm: 76 },
  };
  for (const t of Object.keys(recs)) assert.equal(st.putRecord(t, recs[t]).ok, true, t);
  return { s, st };
}

describe('P4 sources-bypass: false-refusal check against real normal exports', () => {
  it('a rich normal export has no marker at the top level (normalized), no top-level wrapper objects, and no sources-like key in core entries', () => {
    const { st } = richDevice();
    const o = JSON.parse(st.exportJSON());
    const top = Object.keys(o);
    assert.deepEqual(top.filter((k) => ALL_MARKERS.map((m) => m.toLowerCase()).includes(norm(k))), []);
    assert.deepEqual(top.sort(), ['app', 'exportedAt', 'version', 'weight', 'workouts', 'nutrition', ...HD.EXT_TYPES].sort());
    for (const k of top) assert.ok(typeof o[k] !== 'object' || Array.isArray(o[k]), k + ' is a scalar or a list');
    for (const t of ['weight', 'workouts', 'nutrition']) for (const e of o[t]) assert.ok(!Object.keys(e).some((k) => norm(k) === 'sources'));
  });
  it('the rich normal export round-trips: preview ok, restore ok, counts match, then exports identically (minus exportedAt)', () => {
    const { st } = richDevice();
    const text = st.exportJSON();
    const p = acceptedRestores(text);
    assert.deepEqual(p.preview.counts, { weight: 1, workouts: 1, nutrition: 1 });
    const s2 = mem(); const st2 = mk(s2);
    const a = restore(st2, text);
    assert.equal(a.ok, true);
    const strip = (x) => { const j = JSON.parse(x); delete j.exportedAt; return j; };
    assert.deepEqual(strip(st2.exportJSON()), strip(text));
  });
  it('an empty-device export and a legacy v1 export (no Phase 3 lists) are accepted', () => {
    const st = mk(mem());
    acceptedRestores(st.exportJSON());
    const st1 = mk(mem()); st1.addWeight({ date: D, kg: 81 });
    const t1 = st1.exportJSON();
    assert.equal(JSON.parse(t1).version, 1);
    acceptedRestores(t1, 81);
  });
  it('the emergency export itself writes exactly the marker names used here (keeps the list honest)', () => {
    const keys = Object.keys(rawObj()).sort();
    assert.deepEqual(keys, ['app', 'exportedAt', 'format', 'kind', 'normalExport', 'omitted', 'omittedTotal', 'sources', 'state', 'warning']);
  });
});

describe('ACCEPTED LIMIT (P4-L1, characterization, not a defect): hand-forgery cannot be told apart from a genuine backup', () => {
  it('a Cyrillic look-alike key with every other marker stripped is accepted as a normal backup', () => {
    const { st } = liveDevice();
    const p = st.previewImport(backup({ '\u0441ources': rawObj().sources }));
    assert.equal(p.ok, true);
  });
  it('a file with every marker removed and a planted list previews as a normal backup', () => {
    const { st } = liveDevice();
    const p = st.previewImport(backup({ weight: [{ id: 'x1', createdAt: ts, date: D, kg: 70 }] }));
    assert.equal(p.ok, true);
    assert.deepEqual(p.preview.counts, { weight: 1, workouts: 0, nutrition: 0 });
  });
});
