'use strict';
// Phase 8: the four-week plan is re-anchored (+7 days): Week 1 = 16-22 Nov 2026, Week 4 (deload) = 7-13 Dec 2026,
// Day 0 = Sun 15 Nov, block end = Sun 13 Dec. Slot ids, prescriptions and progression are UNCHANGED.
// Synthetic data only. In-memory storage.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const path = require('node:path');
const HD = require(path.resolve(__dirname, '../src/data/hyrox-data.js'));
const HP = require(path.resolve(__dirname, '../src/data/hyrox-plan.js'));
const HW = require(path.resolve(__dirname, '../src/data/hyrox-wellness.js'));

const sha = (o) => crypto.createHash('sha256').update(JSON.stringify(o)).digest('hex');
const mem = (init) => { const m = Object.assign({}, init || {}); return { m, getItem(k) { return Object.prototype.hasOwnProperty.call(m, k) ? m[k] : null; }, setItem(k, v) { m[k] = String(v); }, removeItem(k) { delete m[k]; } }; };
const at = (iso) => HD.createStore(mem(), { now: () => new Date(iso) });
const atShared = (s, iso) => HD.createStore(s, { now: () => new Date(iso) });
const sess = (over) => Object.assign({ date: '2026-11-16', status: 'COMPLETED', modified: false, variant: 'ORIGINAL_60', blocks: [], title: 'Synthetic', rpe: 7, planSlotId: null }, over);
const dow = (iso) => new Date(iso + 'T00:00:00Z').getUTCDay();

describe('P8 anchor: dates', () => {
  it('constants: Day 0 Sun 15 Nov, Week 1 starts Mon 16 Nov, block ends Sun 13 Dec', () => {
    assert.equal(HP.DAY0, '2026-11-15'); assert.equal(HP.BLOCK_START, '2026-11-16'); assert.equal(HP.BLOCK_END, '2026-12-13');
    assert.equal(dow(HP.DAY0), 0); assert.equal(dow(HP.BLOCK_START), 1); assert.equal(dow(HP.BLOCK_END), 0);
    assert.deepEqual(HP.PREVIOUS_ANCHOR, { blockStart: '2026-11-09', day0: '2026-11-08', blockEnd: '2026-12-06' });
  });
  it('exactly 20 Mon-Fri slots, 4 per... 5 per week; W1 16-20 Nov, W4 7-11 Dec; no 5th week, no Block 2', () => {
    assert.equal(HP.SLOTS.length, 20);
    HP.SLOTS.forEach((s) => assert.ok(dow(s.date) >= 1 && dow(s.date) <= 5, s.id));
    const wk = (w) => HP.SLOTS.filter((s) => s.week === w).map((s) => s.date);
    assert.deepEqual(wk(1), ['2026-11-16', '2026-11-17', '2026-11-18', '2026-11-19', '2026-11-20']);
    assert.deepEqual(wk(2), ['2026-11-23', '2026-11-24', '2026-11-25', '2026-11-26', '2026-11-27']);
    assert.deepEqual(wk(3), ['2026-11-30', '2026-12-01', '2026-12-02', '2026-12-03', '2026-12-04']);
    assert.deepEqual(wk(4), ['2026-12-07', '2026-12-08', '2026-12-09', '2026-12-10', '2026-12-11']);
    assert.equal(HP.SLOTS.filter((s) => s.week > 4).length, 0);
    assert.equal(HP.slotById('v2.1-W5-MON'), null);
  });
  it('slot ids, titles, types, prescriptions, fallbacks and templates are byte-identical to Phase 7 (only dates moved)', () => {
    const o = HP.SLOTS.map((s) => ({ id: s.id, week: s.week, day: s.day, type: s.type, title: s.title, rx: s.prescription, b: s.benchmark, d: s.durationMin }));
    assert.equal(sha(o), 'c5c68dd2b9543281f9a545d5a67d1362a7f957c2d91a202f9f2dbd46d381fd15');
    assert.equal(sha(HP.SLOTS.map((s) => HP.templateBlocks(s.type, s.week))), 'ee97463dd0db2377173abb54f91d32ae21fb7b06098c6060f581593fdf78250d');
    const v = []; HP.SLOTS.forEach((s) => ['SOURCE_45_MIN', 'SOURCE_25_MIN'].forEach((x) => { const p = HP.variantPrescription(s.id, x); if (p) v.push([p.prescription, p.blocks]); }));
    assert.equal(sha(v), '507451ac3dbd34c742383b5d66cc16922662f61d93ab91ac638654fa32e38123');
    assert.equal(HP.SLOTS[0].id, 'v2.1-W1-MON'); assert.equal(HP.SLOTS[19].id, 'v2.1-W4-FRI');
    assert.equal(HP.slotById('v2.1-W2-FRI').benchmark, 1); assert.equal(HP.slotById('v2.1-W4-FRI').benchmark, 2);
    assert.equal(HP.slotById('v2.1-W4-MON').date, '2026-12-07');
  });
  it('blockStatus: pre-block day, Day 0, week edges, Dec 13 boundary, after the block', () => {
    const b = (d) => HP.blockStatus(d);
    assert.equal(b('2026-11-14').active, false);
    assert.equal(b('2026-11-14').text, 'Block v2.1 starts Mon 16 Nov 2026 (source Day 0 Sun 15 Nov).');
    assert.equal(b('2026-11-09').active, false, 'the OLD Week 1 Monday is now before the block');
    assert.equal(b('2026-11-15').active, true); assert.equal(b('2026-11-15').week, 0);
    assert.match(b('2026-11-15').text, /Day 0 \(Sun 15 Nov\)/);
    assert.equal(b('2026-11-16').week, 1); assert.equal(b('2026-11-22').week, 1);
    assert.equal(b('2026-11-23').week, 2); assert.equal(b('2026-11-29').week, 2);
    assert.equal(b('2026-11-30').week, 3); assert.equal(b('2026-12-06').week, 3);
    assert.equal(b('2026-12-07').week, 4); assert.equal(b('2026-12-13').week, 4);
    assert.match(b('2026-12-13').text, /Week 4 of 4\. Ends Sun 13 Dec 2026\./);
    assert.equal(b('2026-12-14').active, false); assert.equal(b('2026-12-14').text, HP.NO_BLOCK_TEXT);
    assert.equal(b('2026-12-07').text.includes('Sun 6 Dec'), false);
  });
  it('weekday vs weekend: only Mon-Fri map to slots; Sat/Sun never do, including 21-22 Nov and 12-13 Dec', () => {
    ['2026-11-21', '2026-11-22', '2026-11-28', '2026-11-29', '2026-12-05', '2026-12-06', '2026-12-12', '2026-12-13', '2026-11-15'].forEach((d) => assert.equal(HP.slotForDate(d), null, d));
    assert.equal(HP.slotForDate('2026-11-16').id, 'v2.1-W1-MON'); assert.equal(HP.slotForDate('2026-12-11').id, 'v2.1-W4-FRI');
    assert.equal(HP.slotForDate('2026-11-09'), null, 'old W1 Monday is not a slot any more');
    assert.deepEqual(HP.weekendOptions(1).map((o) => o.date), ['2026-11-21', '2026-11-22']);
    assert.equal(HP.weekendOptions(1)[0].available, false); assert.equal(HP.weekendOptions(2)[0].available, true);
    assert.deepEqual(HP.weekendOptions(4).map((o) => o.date), ['2026-12-12', '2026-12-13']);
  });
  it('human date helpers (calendar arithmetic only)', () => {
    assert.equal(HP.human('2026-11-16'), 'Mon 16 Nov 2026'); assert.equal(HP.humanShort('2026-12-13'), 'Sun 13 Dec');
  });
});

describe('P8 anchor: Asia/Qatar local date, not device UTC', () => {
  it('Qatar midnight Monday = 21:00Z Sunday: Week 1 starts on the Qatar date', () => {
    assert.equal(HD.todayQatar(new Date('2026-11-15T20:59:59Z')), '2026-11-15');
    assert.equal(HD.todayQatar(new Date('2026-11-15T21:00:00Z')), '2026-11-16');
    assert.equal(HP.blockStatus(HD.todayQatar(new Date('2026-11-15T20:59:59Z'))).week, 0);
    assert.equal(HP.blockStatus(HD.todayQatar(new Date('2026-11-15T21:00:00Z'))).week, 1);
    assert.equal(HP.blockStatus(HD.todayQatar(new Date('2026-12-13T20:59:59Z'))).active, true);
    assert.equal(HP.blockStatus(HD.todayQatar(new Date('2026-12-13T21:00:00Z'))).active, false);
  });
});

describe('P8 anchor: rescheduling boundaries', () => {
  it('cannot reschedule before the block, onto the weekend, or after 13 Dec; boundaries are exact', () => {
    const c = (slot, d, today) => HP.rescheduleCheck(slot, d, [], [], today || '2026-11-16');
    assert.equal(c('v2.1-W1-TUE', '2026-11-15', '2026-11-15').code, 'OUTSIDE_BLOCK', 'Day 0 is before BLOCK_START');
    assert.equal(c('v2.1-W1-TUE', '2026-11-13', '2026-11-12').code, 'OUTSIDE_BLOCK');
    assert.equal(c('v2.1-W1-TUE', '2026-12-14', '2026-11-16').code, 'OUTSIDE_BLOCK');
    assert.equal(c('v2.1-W4-TUE', '2026-12-13', '2026-12-08').code, 'WEEKEND_NO_GYM_MAKEUP');
    assert.equal(c('v2.1-W4-FRI', '2026-12-13', '2026-12-11').code, 'FRIDAY_NO_WEEKEND_MAKEUP');
    assert.equal(c('v2.1-W1-MON', '2026-11-16', '2026-11-16').code, 'ORIGINAL_DATE');
    assert.equal(c('v2.1-W1-TUE', '2026-11-16', '2026-11-17').code, 'PAST');
  });
  it('reschedule dates never include a weekend, a planned day, or a date after Fri 11 Dec', () => {
    const ds = HP.rescheduleDates('v2.1-W1-MON', [], [], '2026-11-16');
    assert.ok(ds.length === 0 || ds.every((d) => dow(d) >= 1 && dow(d) <= 5 && d >= '2026-11-16' && d <= '2026-12-13'));
    assert.equal(ds.length, 0, 'every weekday already holds a planned session');
    const late = HP.rescheduleDates('v2.1-W4-MON', [], [], '2026-12-11');
    assert.equal(late.length, 0);
  });
});

describe('P8 anchor: Mon/Wed cascade, skipped and partial counts on the new dates', () => {
  it('missed Monday W1: Mon->Tue 17 Nov, Tue->Thu 19 Nov, Thu aerobic source-omitted; dates are the new ones', () => {
    const e = HP.effectiveWeek(1, [{ kind: 'MISSED_MONDAY', week: 1, date: '2026-11-16' }]);
    assert.equal(e.days[0].date, '2026-11-16'); assert.equal(e.days[0].show.length, 0);
    assert.equal(e.days[1].show[0].slot.id, 'v2.1-W1-MON'); assert.equal(e.days[3].date, '2026-11-19');
    assert.equal(e.days[3].show[0].slot.id, 'v2.1-W1-TUE'); assert.equal(e.days[3].omitted[0].reason, 'MISSED_MONDAY_CASCADE');
  });
  it('missed Wednesday W4: Wed->Thu 10 Dec, Thu omitted; both missed = unresolved, nothing moved', () => {
    const w = HP.effectiveWeek(4, [{ kind: 'MISSED_WEDNESDAY', week: 4, date: '2026-12-09' }]);
    assert.equal(w.days[3].date, '2026-12-10'); assert.equal(w.days[3].show[0].slot.id, 'v2.1-W4-WED');
    const both = HP.effectiveWeek(4, [{ kind: 'MISSED_WEDNESDAY', week: 4, date: '2026-12-09' }, { kind: 'MISSED_MONDAY', week: 4, date: '2026-12-07' }]);
    assert.ok(both.unresolved); assert.equal(both.days[3].show[0].slot.id, 'v2.1-W4-THU'); assert.equal(both.days[3].omitted.length, 0);
  });
  it('skipped and partial counts: only sessions on/after Day 0 are counted; silence is NOT_LOGGED', () => {
    const s = [sess({ id: 'a', date: '2026-11-16', planSlotId: 'v2.1-W1-MON', status: 'COMPLETED' }),
      sess({ id: 'b', date: '2026-11-17', planSlotId: 'v2.1-W1-TUE', status: 'PARTIAL' }),
      sess({ id: 'c', date: '2026-11-18', planSlotId: 'v2.1-W1-WED', status: 'SKIPPED', skipDecision: 'SKIP_PERMANENT' })];
    const sum = HP.summary(s, []);
    assert.equal(sum.COMPLETED, 1); assert.equal(sum.PARTIAL, 1); assert.equal(sum.SKIPPED, 1); assert.equal(sum.NOT_LOGGED, 17); assert.equal(sum.denominator, 20);
    assert.equal(HP.summary([], []).NOT_LOGGED, 20);
  });
  it('Dec 13 boundary: a Week-4 Sunday session is weekend actual, never a make-up; Dec 14 has no block', () => {
    const s = [sess({ id: 'w', date: '2026-12-13', planSlotId: 'v2.1-W4-THU', status: 'COMPLETED' })];
    const st = HP.slotStatus('v2.1-W4-THU', s, []);
    assert.equal(st.offPlan, 'WEEKEND_ACTUAL_NOT_SOURCE_RESCHEDULE');
    assert.equal(HP.blockStatus('2026-12-14').active, false);
  });
});

describe('P8 anchor: records made under the old dates stay in the data and stay interpretable', () => {
  const OLD = { thu: sess({ id: 'old-thu', date: '2026-11-12', planSlotId: 'v2.1-W1-THU', status: 'COMPLETED' }),
    mon: sess({ id: 'old-mon', date: '2026-11-09', planSlotId: 'v2.1-W1-MON', status: 'SKIPPED', skipConfirmed: true, skipDecision: 'SKIP_PERMANENT' }) };
  it('an old session linked to a slot is a pre-block entry: kept, listed, and not counted as the new slot', () => {
    assert.equal(HP.isPreBlockSession(OLD.thu), true);
    assert.deepEqual(HP.preBlockSessions([OLD.thu, OLD.mon]).map((x) => x.id), ['old-thu', 'old-mon']);
    assert.equal(HP.slotStatus('v2.1-W1-THU', [OLD.thu], []).code, 'NOT_LOGGED');
    assert.equal(HP.slotStatus('v2.1-W1-MON', [OLD.mon], []).code, 'NOT_LOGGED');
    const sum = HP.summary([OLD.thu, OLD.mon], []);
    assert.equal(sum.COMPLETED, 0); assert.equal(sum.SKIPPED, 0); assert.equal(sum.NOT_LOGGED, 20);
    assert.equal(HP.rescheduledOn('2026-11-17', [sess({ id: 'r', date: '2026-11-10', planSlotId: 'v2.1-W1-WED', status: 'SKIPPED', skipDecision: 'RESCHEDULE', rescheduledTo: '2026-11-17' })]).length, 0);
  });
  it('the boundary is Day 0: a session dated Sun 15 Nov or later is current; unlinked sessions are never pre-block', () => {
    assert.equal(HP.isPreBlockSession(sess({ date: '2026-11-14', planSlotId: 'v2.1-W1-MON' })), true);
    assert.equal(HP.isPreBlockSession(sess({ date: '2026-11-15', planSlotId: 'v2.1-W1-MON' })), false);
    assert.equal(HP.isPreBlockSession(sess({ date: '2026-11-10', planSlotId: null })), false);
  });
  it('old plan events do not reshape the new weeks; current ones, and events with no date, still do', () => {
    const oldEv = { kind: 'MISSED_MONDAY', week: 1, date: '2026-11-09', createdAt: '2026-11-12T09:00:00.000Z' };
    assert.equal(HP.isPreBlockEvent(oldEv), true);
    assert.equal(HP.effectiveWeek(1, [oldEv]).days[0].show.length, 1, 'Monday is still shown');
    assert.equal(HP.omissionFor('v2.1-W1-THU', [oldEv]), null);
    assert.equal(HP.skipAdvice('v2.1-W1-MON', [], [oldEv], '2026-11-16').options.ADJUST_WEEK.available, true, 'old cascade does not block a new one');
    assert.equal(HP.effectiveWeek(1, [{ kind: 'MISSED_MONDAY', week: 1, date: '2026-11-16' }]).days[0].show.length, 0);
    assert.equal(HP.effectiveWeek(1, [{ kind: 'MISSED_MONDAY', week: 1 }]).days[0].show.length, 0, 'no date and no createdAt: treated as current');
    assert.equal(HP.isPreBlockEvent({ kind: 'MISSED_MONDAY', week: 1, createdAt: '2026-11-12T09:00:00.000Z' }), true, 'no date: createdAt decides');
    assert.deepEqual(HP.cascadeConflicts(1, [OLD.thu], [oldEv]), []);
  });
  it('STORAGE: old records are never rewritten; export and restore round-trip them byte for byte; History data is intact', () => {
    const s = mem(); const old = atShared(s, '2026-11-13T09:00:00Z');
    assert.equal(old.putRecord('sessions', OLD.thu).ok, true);
    assert.equal(old.putRecord('sessions', OLD.mon).ok, true);
    assert.equal(old.putRecord('planEvents', { id: 'ev-old', kind: 'MISSED_MONDAY', week: 1, date: '2026-11-09' }).ok, true);
    assert.equal(old.addWeight({ date: '2026-11-12', kg: 80 }).ok, true);
    const before = s.m['hyrox.v1'];
    const fresh = atShared(s, '2026-11-16T05:00:00Z');       // the re-anchored build reading the same storage, on Week 1 Monday
    assert.equal(s.m['hyrox.v1'], before, 'reading never writes');
    const ids = fresh.records('sessions').map((x) => x.id).sort();
    assert.deepEqual(ids, ['old-mon', 'old-thu']);
    assert.equal(fresh.records('planEvents').length, 1); assert.equal(fresh.list('weight').length, 1);
    const text = fresh.exportJSON();
    const target = atShared(mem(), '2026-11-16T05:00:00Z');
    const p = target.previewImport(text); assert.equal(p.ok, true, JSON.stringify(p));
    const r = target.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt });
    assert.equal(r.ok, true, JSON.stringify(r));
    const strip = (t) => { const j = JSON.parse(t); delete j.exportedAt; return j; };
    assert.deepEqual(strip(target.exportJSON()), strip(text));
    assert.deepEqual(target.records('sessions').map((x) => x.id).sort(), ids);
    // and they are interpreted as pre-block entries, not as progress
    assert.equal(HP.summary(target.records('sessions'), target.records('planEvents')).COMPLETED, 0);
    assert.equal(HP.preBlockSessions(target.records('sessions')).length, 2);
  });
  it('a P7-format export (old dates) still imports into the re-anchored build', () => {
    const exp = JSON.stringify({ app: 'hyrox-app', version: HD.VERSION, exportedAt: '2026-11-13T09:00:00.000Z', weight: [], workouts: [], nutrition: [],
      sessions: [Object.assign({ createdAt: '2026-11-12T10:00:00.000Z', updatedAt: '2026-11-12T10:00:00.000Z' }, OLD.thu)] });
    const t = atShared(mem(), '2026-11-16T05:00:00Z');
    const p = t.previewImport(exp); assert.equal(p.ok, true, JSON.stringify(p));
    const r = t.applyImport(exp, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt });
    assert.equal(r.ok, true, JSON.stringify(r)); assert.equal(t.records('sessions').length, 1);
  });
});

describe('P8 anchor: step reference weeks follow the same anchor (values unchanged)', () => {
  it('week windows and goals', () => {
    const w = HW.STEP_REFERENCE;
    assert.equal(w.day0, '2026-11-15');
    assert.deepEqual([1, 2, 3, 4].map((k) => [w.weeks[k].from, w.weeks[k].to, w.weeks[k].goal]),
      [['2026-11-16', '2026-11-22', 7000], ['2026-11-23', '2026-11-29', 8000], ['2026-11-30', '2026-12-06', 9000], ['2026-12-07', '2026-12-13', 10000]]);
    assert.equal(w.weeks[4].kind, 'TARGET_IF_TOLERATED');
    assert.equal(HW.stepReferenceGoal('2026-11-14', {}).goal, null, 'pre-block day has no goal');
    assert.equal(HW.stepReferenceGoal('2026-11-15', {}).week, 0);
    assert.equal(HW.stepReferenceGoal('2026-11-16', {}).goal, 7000);
    assert.equal(HW.stepReferenceGoal('2026-12-13', {}).week, 4);
    assert.equal(HW.stepReferenceGoal('2026-12-14', {}).goal, null);
  });
});
