'use strict';
// Meron (QA): OWNER-DECISIONS-t47u.txt Decision 1 — step REFERENCE GOALS
// vs adaptive guidance. Synthetic data only. New file; no src/ or existing-test edits.
// Quotes below are from OWNER-DECISIONS-t47u.txt (relayed by Tewodros as approved)
// and HNC-BASE-v2.1.txt section 6.

const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const HW = require(path.resolve(__dirname, '../src/data/hyrox-wellness.js'));
const { O, MISSING, ts } = require('./p8-helpers.js');

const D = '2026-11-18'; // W1 Wednesday
function addDays(iso, n) {
  const d = new Date(Date.UTC(+iso.slice(0, 4), +iso.slice(5, 7) - 1, +iso.slice(8, 10) + n));
  return d.toISOString().slice(0, 10);
}
const daily = (date, extra) => Object.assign({ id: 'd-' + date, createdAt: ts, date }, extra);
const walk = (id, date, steps) => ({ id, createdAt: ts, date, durationMin: 30, steps });
const run = (id, date, runSteps) => ({
  id, createdAt: ts, date, status: 'COMPLETED', modified: false, variant: 'NONE', blocks: [],
  runSteps, runStepsSource: runSteps == null ? undefined : 'DEVICE',
});


describe('Decision 1 (already on this build): missing is NULL, no catch-up, no inference, no double count', () => {
  // "Missing steps remain unknown, never zero, and no catch-up target is created after a missed day."
  // "Do not infer step counts from distances or workout durations."
  // "Record actual run/walk steps without double counting the reported daily total."
  it('missing steps are null, never 0; a recorded 0 stays 0', () => {
    assert.equal(HW.daySteps(D, { dailies: [], walks: [], sessions: [] }).total, null);
    assert.equal(HW.daySteps(D, { dailies: [daily(D, { steps: MISSING })] }).total, null);
    assert.equal(HW.canonicalSteps(D, [], []).value, null);
    assert.equal(HW.daySteps(D, { dailies: [daily(D, { steps: O(0) })] }).total, 0);
  });

  it('does not infer steps from walk distance/duration or a run without runSteps', () => {
    const r = HW.daySteps(D, {
      walks: [{ id: 'w', createdAt: ts, date: D, durationMin: 60, distanceKm: 5 }],
      sessions: [run('s', D, null)],
    });
    assert.equal(r.total, null);
  });

  it('a recorded daily total wins; walk + run are never added to it (no double count)', () => {
    const r = HW.daySteps(D, {
      dailies: [daily(D, { steps: O(8000) })],
      walks: [walk('w1', D, 3000)],
      sessions: [run('s1', D, 2500)],
    });
    assert.equal(r.total, 8000);
    assert.equal(r.source, 'daily');
    assert.ok(r.flags.includes('WORKOUT_STEPS_NOT_ADDED'));
  });

  it('a missed or low day does not raise a later adaptive target (no catch-up)', () => {
    const settings = { stepBaselineMode: 'MANUAL', stepBaselineManual: 8000 };
    const missed = daily('2026-11-17', { steps: MISSING });
    const ctx = (date) => ({
      dailies: [missed], walks: [], sessions: [], settings, plannedToday: 1, recentSessions: [],
    });
    const today = HW.stepTarget(D, ctx(D));
    const ifRecorded = HW.stepTarget(D, {
      dailies: [daily('2026-11-17', { steps: O(8000) })], walks: [], sessions: [],
      settings, plannedToday: 1, recentSessions: [],
    });
    assert.equal(today.adaptive, ifRecorded.adaptive, 'a missed previous day must not inflate the next adaptive target');
    assert.ok(today.adaptive === null || today.adaptive <= 8000 * 1.10);
    assert.match(today.note || '', /never rise to make up|missed/i);
  });
});

describe('Decision 1: week-specific REFERENCE GOALS are separate from the adaptive guidance target', () => {
  // "encode the approved v2.1 plan's week-specific reference goals: W1 7,000/day, W2 8,000/day, W3 9,000/day, W4 up to 10,000/day only if tolerated"
  it('W1 7000, W2 8000, W3 9000 floors, and W4 10000 as TARGET_IF_TOLERATED (HNC-BASE-v2.1 §6; Decision 1 wording)', () => {
    const g = (date) => HW.stepReferenceGoal(date, {});
    assert.equal(g('2026-11-16').goal, 7000); assert.equal(g('2026-11-16').value, 7000);
    assert.equal(g('2026-11-16').goalKind, 'FLOOR'); assert.equal(g('2026-11-16').week, 1);
    assert.equal(g('2026-11-22').goal, 7000);
    assert.equal(g('2026-11-23').goal, 8000); assert.equal(g('2026-11-29').goal, 8000);
    assert.equal(g('2026-11-30').goal, 9000); assert.equal(g('2026-12-06').goal, 9000);
    const w4 = g('2026-12-07');
    assert.equal(w4.goal, 10000);
    assert.equal(w4.value, 10000);
    assert.equal(w4.goalKind, 'TARGET_IF_TOLERATED');
    assert.equal(w4.week, 4);
    assert.equal(g('2026-12-13').goal, 10000);
    const both = HW.stepGoals('2026-11-23', { dailies: [], walks: [], sessions: [] });
    assert.equal(both.reference.kind, 'REFERENCE_GOAL');
    assert.equal(both.guidance.kind, 'ADAPTIVE_GUIDANCE');
    assert.equal(both.reference.goal, 8000);
  });

  it('the reference goal is separate from the adaptive guidance target; a lowered adaptive target does not satisfy the plan goal', () => {
    const settings = { stepBaselineMode: 'MANUAL', stepBaselineManual: 8000 };
    const date = '2026-11-23'; // W2 floor 8000
    const ctx = {
      dailies: [daily(date, { steps: O(7000) })],
      walks: [], sessions: [], settings, plannedToday: 1,
      recentSessions: [{ date, status: 'COMPLETED', rpe: 8, type: 'INTERVALS' }],
    };
    const ref = HW.stepReferenceGoal(date, ctx);
    const t = HW.stepTarget(date, ctx);
    assert.equal(ref.goal, 8000);
    assert.equal(ref.kind, 'REFERENCE_GOAL');
    assert.equal(t.kind, 'ADAPTIVE_GUIDANCE');
    assert.ok(t.adaptive !== undefined && t.adaptive < 8000, 'adaptive should be lowered on a demanding day, got ' + t.adaptive);
    assert.notEqual(t.adaptive, ref.goal);
    assert.equal(t.met, true, '7000 meets the lowered adaptive target');
    assert.equal(ref.met, false, '7000 does not meet the 8000 reference floor; adaptive must not retroactively satisfy it');
    assert.equal(t.heuristics.fromSource, false);
  });

  it('the 10k readiness gate is kept separate; missing inputs are UNKNOWN, never pass and never 0', () => {
    // Source §6: heel/arch/Achilles pain ≤2/10; no limp; stair knee pain ≤2/10; ≥6 h sleep.
    const pass = HW.step10kGate({ heelArchAchillesPain: 1, limp: false, stairKneePain: 1, sleepH: 7 });
    assert.equal(pass.status, 'PASS');
    assert.equal(pass.pass, true);
    const missingSleep = HW.step10kGate({ footPain: 1, limp: false, stairKneePain: 1 });
    assert.equal(missingSleep.status, 'UNKNOWN');
    assert.equal(missingSleep.pass, false);
    assert.ok(missingSleep.missing.includes('sleepH'));
    const sleepCheck = missingSleep.checks.filter((c) => c.key === 'sleepH')[0];
    assert.equal(sleepCheck.value, null, 'missing is null, never 0');
    assert.notEqual(sleepCheck.value, 0);
    const empty = HW.tenKGate('2026-12-08', []);
    assert.equal(empty.status, 'UNKNOWN');
    assert.equal(empty.pass, false);
    const fail = HW.step10kGate({ footPain: 3, limp: false, stairKneePain: 1, sleepH: 7 });
    assert.equal(fail.status, 'FAIL');
    assert.equal(fail.pass, false);
  });

  it('current behaviour (open owner item): a failed or unknown W4 gate keeps the 10000 goal, marked DO_NOT_FORCE — no lower number is invented', () => {
    // Open question: should a failed W4 gate display a lower floor? Current implementation keeps 10000 and refuses to force it.
    const failed = HW.stepReferenceGoal('2026-12-08', { dailies: [daily('2026-12-08', {
      footPain: O(5), stairKneePain: O(5), limp: { state: 'OBSERVED', value: true }, sleepH: O(5),
    })] });
    assert.equal(failed.goal, 10000);
    assert.equal(failed.status, 'DO_NOT_FORCE');
    assert.ok(failed.doNotForce.includes('READINESS_GATE_FAILED'));
    assert.notEqual(failed.met, true);
    const unknown = HW.stepReferenceGoal('2026-12-08', { dailies: [] });
    assert.equal(unknown.goal, 10000);
    assert.equal(unknown.status, 'DO_NOT_FORCE');
    assert.ok(unknown.doNotForce.includes('READINESS_GATE_UNKNOWN'));
    assert.equal(unknown.gate.status, 'UNKNOWN');
  });
});
