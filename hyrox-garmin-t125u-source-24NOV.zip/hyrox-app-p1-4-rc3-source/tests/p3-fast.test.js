'use strict';
// DAWIT 3: fast-state compatibility. The state contract (code incl. 'DF') is unchanged;
// canonicalCode is an additive D1-D5-only view. Stored data never holds a day code.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const HN = require(path.resolve(__dirname, '../src/data/hyrox-nutrition.js'));
const { HD, KEY, mem, mk, U, K, ts, backup, restore } = require('./p3-helpers.js');

const D = '2026-11-10';
const meal = (o) => Object.assign({ id: 'm' + Math.random().toString(36).slice(2), createdAt: ts, date: D, source: 'MANUAL', lifecycle: 'CONFIRMED', confirmedAt: ts,
  components: [{ name: 'x', role: 'MAIN', kcal: K(500), proteinG: K(30), carbsG: U, fatG: U }] }, o);
const zeroMeal = () => meal({ components: [{ name: 'water', role: 'DRINK', kcal: K(0), proteinG: K(0), carbsG: K(0), fatG: K(0) }] });
const att = (meals, o) => Object.assign({ attestation: 'COMPLETE', basis: HN.dayBasis(meals) }, o);

describe('fast state: DF stays, canonicalCode is D1-D5 only', () => {
  const cases = [
    ['no meals, no answer', [], null, 'D1', 'D1'],
    ['no meals, confirmed fast', [], { fast: 'CONFIRMED_FULL_DAY_FAST' }, 'DF', 'D4'],
    ['only 0-kcal items, confirmed fast', [zeroMeal()], { fast: 'CONFIRMED_FULL_DAY_FAST' }, 'DF', 'D4'],
    ['no meals, "not logged"', [], { attestation: 'INCOMPLETE', fast: 'NOT_LOGGED' }, 'D3', 'D3'],
    ['no meals, complete without fast answer (pre-fast data)', [], {}, 'D4', 'D4'],
    ['meal, complete', [meal()], {}, 'D5', 'D5'],
    ['meal, complete + fast answer (cannot be a fast)', [meal()], { fast: 'CONFIRMED_FULL_DAY_FAST' }, 'D5', 'D5'],
    ['meal, no attestation', [meal()], null, 'D2', 'D2'],
    ['pending meal', [meal({ lifecycle: 'CONSUMED_INTENT', confirmedAt: undefined })], null, 'D2', 'D2'],
  ];
  cases.forEach(([name, meals, a, code, canon]) => {
    it(name + ' -> ' + code + ' / ' + canon, () => {
      const st = HN.dayState(D, meals, a === null ? null : att(meals, a));
      assert.equal(st.code, code); assert.equal(st.canonicalCode, canon);
      assert.ok(HN.CANONICAL_CODES.includes(st.canonicalCode));
      assert.equal(st.fastDay, code === 'DF');
      assert.equal(st.dayKcal, code === 'D5' ? 500 : code === 'DF' ? 0 : null, 'never an invented 0');
    });
  });
  it('code differs from canonicalCode ONLY for an explicitly confirmed fast (DF -> D4)', () => {
    const attSets = [null, {}, { fast: 'CONFIRMED_FULL_DAY_FAST' }, { attestation: 'INCOMPLETE' }, { attestation: 'INCOMPLETE', fast: 'NOT_LOGGED' }];
    const mealSets = [[], [zeroMeal()], [meal()], [meal({ lifecycle: 'DRAFT', confirmedAt: undefined })], [meal({ components: [{ name: 'q', role: 'MAIN', kcal: U, proteinG: U, carbsG: U, fatG: U }] })]];
    mealSets.forEach((ms) => attSets.forEach((a) => {
      const st = HN.dayState(D, ms, a === null ? null : att(ms, a));
      if (st.code !== st.canonicalCode) { assert.equal(st.code, 'DF'); assert.equal(st.canonicalCode, 'D4'); }
      if (st.code === 'DF') assert.equal(a && a.fast, 'CONFIRMED_FULL_DAY_FAST');
    }));
  });
  it('a stale fast answer (food added later) withdraws DF; nothing is inferred from missing meals', () => {
    const a = att([], { fast: 'CONFIRMED_FULL_DAY_FAST' });
    const st = HN.dayState(D, [meal()], a);
    assert.equal(st.staleAttestation, true); assert.notEqual(st.code, 'DF'); assert.equal(st.canonicalCode, st.code);
    assert.equal(HN.dayState(D, [], null).code, 'D1');
  });
  it('stored dayStates hold the answer, never a day code; DF survives export -> import -> reload', () => {
    const s = mem(); const st = mk(s);
    assert.equal(st.putRecord('dayStates', { id: 'ds-' + D, date: D, attestation: 'COMPLETE', basis: HN.dayBasis([]), fast: 'CONFIRMED_FULL_DAY_FAST' }).ok, true);
    assert.equal(/"D[1-5F]"/.test(s.m[KEY]), false);
    const s2 = mem(); assert.equal(restore(mk(s2), st.exportJSON()).ok, true);
    const rec = mk(s2).records('dayStates')[0];
    const ds = HN.dayState(D, [], rec);
    assert.equal(ds.code, 'DF'); assert.equal(ds.canonicalCode, 'D4'); assert.equal(ds.dayKcal, 0);
  });
  it('a dayStates record cannot carry an inconsistent fast answer (import refuses it)', () => {
    const text = backup({ dayStates: [{ id: 'x', createdAt: ts, date: D, attestation: 'INCOMPLETE', basis: '0:x', fast: 'CONFIRMED_FULL_DAY_FAST' }] });
    assert.equal(mk(mem()).previewImport(text).code, 'invalid_records');
  });
  it('averages: DF days are a separate cohort, D4 (not quantified) days excluded', () => {
    const m = meal();
    const states = [HN.dayState(D, [], att([], { fast: 'CONFIRMED_FULL_DAY_FAST' })), HN.dayState(D, [m], att([m], {})), HN.dayState(D, [], att([], {}))];
    assert.deepEqual(states.map((x) => x.code), ['DF', 'D5', 'D4']);
    const a = HN.dayAverages(states);
    assert.equal(a.fastingDays.n, 1); assert.equal(a.eatingDays.n, 1); assert.equal(a.eatingDays.kcalMean, 500); assert.equal(a.excluded.n, 1);
  });
  it('HD.ENUMS.fastAnswer is unchanged', () => {
    assert.deepEqual(HD.ENUMS.fastAnswer, ['CONFIRMED_FULL_DAY_FAST', 'NOT_LOGGED']);
    assert.deepEqual(Object.keys(HN.DAY_LABEL), ['D1', 'D2', 'D3', 'D4', 'D5', 'DF']);
  });
});
