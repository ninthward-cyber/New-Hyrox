'use strict';
// P6 data-disappearance investigation (t75u priority 1). Synthetic data only, data layer only.
// CHARACTERIZATION tests pin what the code does and prove that every "records look missing" path keeps the
// stored bytes. P6 (Dawit, branch p6/data): the former DESIRED todo (status().keyPresent + status().counts) is now
// a passing test, and the two characterisation tests that asserted those fields were ABSENT now assert the new
// truth while still checking that origin / host / displayMode stay absent (the data layer never knows them).
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const HD = require(path.resolve(__dirname, '../src/data/hyrox-data.js'));
const KEY = 'hyrox.v1', REC = 'hyrox.v1.corrupt-backup', SLOT = 'hyrox.v1.pre-import-backup';
const NOW = new Date('2026-11-12T06:00:00Z'), ts = NOW.toISOString();
const mem = (init) => { const m = Object.assign({}, init || {}); return { m, getItem: (k) => (k in m ? m[k] : null), setItem: (k, v) => { m[k] = String(v); }, removeItem: (k) => { delete m[k]; } }; };
const mk = (s) => HD.createStore(s, { now: () => NOW });
const W = (id, kg, date) => ({ id, createdAt: ts, date: date || '2026-11-10', kg });
const MEAL = (id) => ({ id, createdAt: ts, updatedAt: ts, date: '2026-11-11', label: 'Synthetic test meal', source: 'MANUAL', lifecycle: 'CONFIRMED', confirmedAt: ts, eatenFraction: 1,
  components: [{ name: 'Rice', role: 'MAIN', eatenFraction: null, kcal: { value: 200, state: 'KNOWN' }, proteinG: { value: 4, state: 'KNOWN' }, carbsG: { value: 44, state: 'KNOWN' }, fatG: { value: 1, state: 'KNOWN' } }] });
const POPULATED = JSON.stringify({ version: 2, weight: [W('w1', 80)], workouts: [], nutrition: [], meals: [MEAL('m1')] });

describe('P6-DL-1 a different storage context looks exactly like deleted data (origin / container change)', () => {
  it('same storage, new page load / re-auth return: every record is intact', () => {
    const s = mem({ [KEY]: POPULATED });
    mk(s); // first page load
    const again = mk(s); // after a login redirect back to the same origin
    assert.equal(again.status().state, 'ok');
    assert.equal(again.list('weight').length, 1);
    assert.equal(again.records('meals').length, 1);
    assert.equal(s.m[KEY], POPULATED);
  });
  it('a different origin / Safari profile / Home Screen container is a brand-new empty store: state "empty", ok=true, nothing says "new"', () => {
    const original = mem({ [KEY]: POPULATED });
    const other = mem({});
    const st = mk(other).status();
    assert.equal(st.state, 'empty'); assert.equal(st.ok, true);
    assert.deepEqual(Object.keys(st).sort(), ['counts', 'importBackup', 'keyPresent', 'ok', 'persistent', 'recoveryKey', 'state']);
    assert.equal(mk(other).list('weight').length, 0);
    assert.equal(original.m[KEY], POPULATED, 'the original context is untouched');
  });
  it('the data layer exposes key presence and counts, but still no origin, host, display mode or last-write time', () => {
    const st = mk(mem({})).status();
    for (const k of ['origin', 'host', 'hostname', 'displayMode', 'lastWriteAt', 'contextNew']) assert.equal(k in st, false, k);
    for (const k of ['keyPresent', 'counts']) assert.equal(k in st, true, k);
  });
  it('status() says whether the key exists and how many records are stored, so the UI can say "no data in THIS browser context"', () => {
    const st = mk(mem({})).status();
    assert.equal(st.keyPresent, false);
    assert.deepEqual(st.counts, COUNTS0);
  });
});

const COLL = ['weight', 'workouts', 'nutrition', 'sessions', 'meals', 'body', 'daily', 'walks', 'dayStates', 'planEvents', 'ownerSettings'];
const COUNTS0 = { weight: 0, workouts: 0, nutrition: 0, sessions: 0, meals: 0, body: 0, daily: 0, walks: 0, dayStates: 0, planEvents: 0, ownerSettings: 0, total: 0 };

describe('P6-DL-1b status().keyPresent and status().counts (read-only storage context)', () => {
  it('counts use exactly the collection names of the data layer plus total', () => {
    assert.deepEqual(COLL, ['weight', 'workouts', 'nutrition'].concat(HD.EXT_TYPES));
    assert.deepEqual(Object.keys(mk(mem({})).status().counts), COLL.concat('total'));
  });
  it('populated store: key present and every stored record counted per collection', () => {
    const s = mem({ [KEY]: POPULATED });
    const st = mk(s).status();
    assert.equal(st.state, 'ok'); assert.equal(st.keyPresent, true);
    assert.deepEqual(st.counts, Object.assign({}, COUNTS0, { weight: 1, meals: 1, total: 2 }));
    assert.equal(s.m[KEY], POPULATED, 'status() is read-only');
  });
  it('every collection is counted, and the total is their sum', () => {
    const rec = (id) => ({ id, date: '2026-11-10' });
    const raw = {}; COLL.forEach((c, i) => { raw[c] = Array.from({ length: i + 1 }, (_, j) => rec(c + j)); });
    const st = mk(mem({ [KEY]: JSON.stringify(Object.assign({ version: 2 }, raw)) })).status();
    COLL.forEach((c, i) => assert.equal(st.counts[c], i + 1, c));
    assert.equal(st.counts.total, COLL.reduce((a, c, i) => a + i + 1, 0));
  });
  it('DAMAGED / hidden records are counted as stored (a numeric-id weight, a meal without date)', () => {
    const nodate = MEAL('m-nodate'); delete nodate.date;
    const raw = JSON.stringify({ version: 2, weight: [{ id: 5, createdAt: ts, date: '2026-11-10', kg: 80 }, W('ok', 81)], workouts: [], nutrition: [], meals: [nodate] });
    const st = mk(mem({ [KEY]: raw })).status();
    assert.equal(st.counts.weight, 2); assert.equal(st.counts.meals, 1); assert.equal(st.counts.total, 3);
    assert.equal(mk(mem({ [KEY]: raw })).list('weight').length, 1, 'list() still hides the numeric-id entry');
  });
  it('empty-string key: state empty, key present, zero counts (documented: any stored text counts as present, even empty)', () => {
    const st = mk(mem({ [KEY]: '' })).status();
    assert.equal(st.state, 'empty'); assert.equal(st.keyPresent, true); assert.deepEqual(st.counts, COUNTS0);
  });
  it('corrupt: key present, counts null (not zero), bytes untouched', () => {
    const bad = '{"version":2,"weight":[';
    const s = mem({ [KEY]: bad });
    const st = mk(s).status();
    assert.equal(st.state, 'corrupt'); assert.equal(st.keyPresent, true); assert.equal(st.counts, null);
    assert.deepEqual(s.m, { [KEY]: bad });
  });
  it('damaged collection (not a list): corrupt, counts null, damagedList still reported', () => {
    const raw = JSON.stringify({ version: 2, weight: [], meals: { not: 'a list' } });
    const st = mk(mem({ [KEY]: raw })).status();
    assert.equal(st.state, 'corrupt'); assert.equal(st.counts, null); assert.equal(st.damagedList, 'meals'); assert.equal(st.keyPresent, true);
  });
  it('newer schema: key present, counts null', () => {
    const st = mk(mem({ [KEY]: JSON.stringify({ version: 3, weight: [W('w', 80)] }) })).status();
    assert.equal(st.state, 'newer'); assert.equal(st.keyPresent, true); assert.equal(st.counts, null);
  });
  it('unreadable (getItem throws): keyPresent null (unknown), counts null, nothing written, never throws', () => {
    const writes = [];
    const t = { getItem() { throw new Error('SecurityError'); }, setItem(k) { writes.push(k); }, removeItem(k) { writes.push(k); } };
    const st = mk(t).status();
    assert.equal(st.state, 'unreadable'); assert.equal(st.keyPresent, null); assert.equal(st.counts, null);
    assert.deepEqual(writes, []);
  });
  it('unavailable storage (no localStorage at all): keyPresent null, counts null', () => {
    const st = HD.createStore(undefined, { now: () => NOW }).status();
    assert.equal(st.state, 'unavailable'); assert.equal(st.keyPresent, null); assert.equal(st.counts, null);
  });
  it('another browser context is told apart from deletion: empty + keyPresent false + zero counts, while the original keeps its counts', () => {
    const original = mem({ [KEY]: POPULATED }), other = mem({});
    assert.equal(mk(original).status().keyPresent, true);
    assert.equal(mk(other).status().keyPresent, false);
    assert.equal(mk(other).status().counts.total, 0);
    assert.equal(mk(original).status().counts.total, 2);
  });
  it('status() writes nothing, returns no record contents, and is stable across calls', () => {
    const calls = [];
    const s = mem({ [KEY]: POPULATED });
    const t = { getItem: s.getItem, setItem(k, v) { calls.push(['set', k]); s.setItem(k, v); }, removeItem(k) { calls.push(['rm', k]); s.removeItem(k); } };
    const store = mk(t);
    const a = store.status(), b = store.status();
    assert.deepEqual(a, b); assert.deepEqual(calls, []);
    assert.equal(JSON.stringify(a).includes('Synthetic test meal'), false);
    for (const v of Object.values(a.counts)) assert.equal(typeof v, 'number');
  });
  it('pre-existing fields keep their meaning (recovery key, import backup, priorCopy)', () => {
    const s = mem({ [KEY]: POPULATED, [REC]: 'x', [SLOT]: 'not json' });
    const st = mk(s).status();
    assert.equal(st.recoveryKey, REC); assert.equal(st.persistent, true); assert.equal(st.ok, true);
    assert.equal(st.keyPresent, true);
  });
});

describe('P6-DL-3 corrupt hyrox.v1: the first new write replaces the visible data (old bytes survive only in the recovery key)', () => {
  it('damaged text is moved byte-for-byte to the recovery key, then a new entry makes the visible list contain only the new entry', () => {
    const damaged = POPULATED.slice(0, Math.floor(POPULATED.length / 2));
    const s = mem({ [KEY]: damaged });
    const st = mk(s);
    assert.equal(st.status().state, 'corrupt');
    assert.equal(st.list('weight').length, 0);
    const r = st.addWeight({ date: '2026-11-12', kg: 81 });
    assert.equal(r.ok, true);
    assert.equal(s.m[REC], damaged, 'old bytes preserved exactly');
    assert.equal(st.list('weight').length, 1, 'visible data is now only the new entry');
    assert.equal(st.status().state, 'ok');
    assert.equal(st.status().recoveryKey, REC);
  });
  it('a second corruption event cannot overwrite the first recovery copy (write is refused)', () => {
    const s = mem({ [KEY]: '{"version":1,"weight":[', [REC]: 'FIRST-COPY' });
    const r = mk(s).addWeight({ date: '2026-11-12', kg: 81 });
    assert.equal(r.ok, false);
    assert.equal(s.m[REC], 'FIRST-COPY');
    assert.equal(s.m[KEY], '{"version":1,"weight":[');
  });
});

describe('P6-DL-4 entries that exist but are not shown', () => {
  it('a stored classic entry with a numeric id is hidden from list(), kept in storage, counted by the raw export', () => {
    const raw = JSON.stringify({ version: 1, weight: [{ id: 5, createdAt: ts, date: '2026-11-10', kg: 80 }, W('ok', 81)], workouts: [], nutrition: [] });
    const s = mem({ [KEY]: raw }); const st = mk(s);
    assert.equal(st.list('weight').length, 1);
    assert.equal(st.exportSummary().omitted.weight, 1);
    assert.equal(st.rawRecoveryExport().sources[0].length, raw.length);
    assert.equal(s.m[KEY], raw);
  });
  it('a Phase 3 meal with no date is DAMAGED: not in records(), listed only by damagedRecords() (History says "No meals yet.")', () => {
    const m = MEAL('m-nodate'); delete m.date;
    const raw = JSON.stringify({ version: 2, weight: [], workouts: [], nutrition: [], meals: [m] });
    const st = mk(mem({ [KEY]: raw }));
    assert.equal(st.records('meals').length, 0);
    assert.equal(st.damagedRecords().length, 1);
  });
  it('entries dated after "today" (device clock was ahead) are still listed: nothing is date-filtered', () => {
    const raw = JSON.stringify({ version: 1, weight: [W('future', 80, '2026-12-30')], workouts: [], nutrition: [] });
    assert.equal(mk(mem({ [KEY]: raw })).list('weight').length, 1);
  });
});

describe('P6-DL-5 newer schema, unreadable and unavailable storage never destroy data', () => {
  it('schema version 3 is shown as unavailable data, writes are refused, bytes unchanged', () => {
    const raw = JSON.stringify({ version: 3, weight: [W('w', 80)], workouts: [], nutrition: [] });
    const s = mem({ [KEY]: raw }); const st = mk(s);
    assert.equal(st.status().state, 'newer');
    assert.equal(st.list('weight').length, 0);
    assert.equal(st.addWeight({ date: '2026-11-12', kg: 81 }).ok, false);
    assert.equal(s.m[KEY], raw);
  });
  it('getItem throwing (Safari with site data blocked) reads as "unreadable", never as empty, and nothing is written', () => {
    const s = mem({ [KEY]: POPULATED }); const writes = [];
    const t = { getItem() { throw new Error('SecurityError'); }, setItem(k, v) { writes.push(k); }, removeItem(k) { writes.push(k); } };
    const st = mk(t);
    assert.equal(st.status().state, 'unreadable');
    assert.equal(st.addWeight({ date: '2026-11-12', kg: 81 }).ok, false);
    assert.equal(st.remove('weight', 'w1'), false);
    assert.deepEqual(writes, []);
    assert.equal(s.m[KEY], POPULATED);
  });
  it('quota error on save: add fails visibly and the previous text is untouched', () => {
    const s = mem({ [KEY]: POPULATED });
    const full = { getItem: s.getItem, setItem() { throw new Error('QuotaExceededError'); }, removeItem: s.removeItem };
    const r = mk(full).addWeight({ date: '2026-11-12', kg: 81 });
    assert.equal(r.ok, false); assert.match(r.errors.storage, /storage full or blocked/);
    assert.equal(s.m[KEY], POPULATED);
  });
});

describe('P6-DL-6 no code path wipes hyrox.v1', () => {
  it('source audit: the only removeItem(KEY) is the verified rollback of a restore that had no previous data; nothing else deletes the key', () => {
    const src = require('node:fs').readFileSync(path.resolve(__dirname, '../src/data/hyrox-data.js'), 'utf8');
    const rm = src.split('\n').map((l, i) => [i + 1, l]).filter(([, l]) => /removeItem\(/.test(l));
    assert.deepEqual(rm.map(([, l]) => l.trim()).sort(), ["if (prev.value === null) { if (typeof storage.removeItem === 'function') storage.removeItem(BACKUP_KEY); }", 'storage.removeItem(KEY);']);
    const ui = ['../src/ui/app.js', '../src/ui/app-ext.js'].map((f) => require('node:fs').readFileSync(path.resolve(__dirname, f), 'utf8')).join('\n');
    assert.equal(/localStorage\.clear\(|\.clear\(\)/.test(ui.replace(/\/\/.*$/gm, '')), false, 'no localStorage.clear anywhere in the UI');
    assert.deepEqual([...new Set((ui.match(/localStorage\.removeItem\(([A-Z_]+)\)/g) || []))].sort(), ['localStorage.removeItem(DRAFT_KEY)', 'localStorage.removeItem(MEAL_DRAFT_KEY)']); /* RE-POINTED by Sprint B2 (owner decision M1, 23 Nov 2026): + UI-only key hyrox.ui.meal-draft */
  });
});
