'use strict';
// P4 overnight QA (Dawit, owner t59u): backup export/restore integrity attacks that HELD on the
// R2 baseline. Synthetic data only. These lock in safe behaviour; open gaps are documented in
// /workspace/hyrox-p4/dawit-integrity-findings.md, not asserted here.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const { HD, NOW, KEY, RECOVERY, PRE, ts } = require('./p3-helpers.js');

function mapStorage(init) {
  const m = new Map(Object.entries(init || {}));
  return { m, writes: 0, getItem(k) { return m.has(k) ? m.get(k) : null; }, setItem(k, v) { this.writes++; m.set(k, String(v)); }, removeItem(k) { this.writes++; m.delete(k); } };
}
// Fails the Nth storage call (any method) in one of four ways.
function faultyStorage(init, failAt, mode) {
  const m = new Map(Object.entries(init || {}));
  let n = 0;
  const hit = () => ++n === failAt;
  return { m,
    getItem(k) { if (hit()) { if (mode === 'throw') throw new Error('read fault'); } return m.has(k) ? m.get(k) : null; },
    setItem(k, v) {
      if (hit()) {
        if (mode === 'throw') { const e = new Error('The quota has been exceeded.'); e.name = 'QuotaExceededError'; throw e; }
        if (mode === 'silent') return;                       // write dropped, no error
        if (mode === 'partial') { m.set(k, String(v).slice(0, 10)); return; } // torn write
      }
      m.set(k, String(v));
    },
    removeItem(k) { if (hit()) { if (mode === 'throw') throw new Error('remove fault'); if (mode !== 'lie') return; } m.delete(k); } };
}
// 'lie' mode for reads: a getItem AFTER the first returns altered text (read-back mismatch).
function lyingStorage(init, lieAt) {
  const m = new Map(Object.entries(init || {}));
  let n = 0;
  return { m, getItem(k) { const v = m.has(k) ? m.get(k) : null; return ++n === lieAt && v !== null ? v + ' ' : v; },
    setItem(k, v) { m.set(k, String(v)); }, removeItem(k) { m.delete(k); } };
}
const mk = (s) => HD.createStore(s, { now: () => NOW });
const snap = (s) => JSON.stringify([...s.m.entries()].sort());
function restore(st, text) {
  const p = st.previewImport(text);
  if (!p.ok) return p;
  return st.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt });
}
const file = (extra, v) => JSON.stringify(Object.assign({ app: 'hyrox-app', version: v === undefined ? 2 : v, exportedAt: ts, weight: [], workouts: [], nutrition: [] }, extra));
const GOOD = JSON.stringify({ version: 2, weight: [{ id: 'w0', createdAt: ts, date: '2026-11-01', kg: 81.5 }], workouts: [], nutrition: [], daily: [] });
const CORRUPT = '{"version":2,"weight":[tr';
const IMPORT = file({ weight: [{ id: 'w1', createdAt: ts, date: '2026-11-10', kg: 80 }], walks: [{ id: 'k1', createdAt: ts, date: '2026-11-10', durationMin: 30 }] });
const U = { value: null, state: 'UNKNOWN' };
const PHOTO_NO_FRACTION = { id: 'm-legacy', date: '2026-11-10', createdAt: ts, lifecycle: 'CONFIRMED', confirmedAt: ts, source: 'PHOTO_AI',
  components: [{ name: 'rice', role: 'MAIN', kcal: { value: 500, state: 'ESTIMATED' }, proteinG: U, carbsG: U, fatG: U }] };

describe('P4 held: single storage fault at every step of applyImport', () => {
  const SCEN = { good: { [KEY]: GOOD }, empty: {}, corrupt: { [KEY]: CORRUPT },
    corruptWithOlderCopy: { [KEY]: CORRUPT, [RECOVERY]: 'older-corrupt' },
    withPreImportSlot: { [KEY]: GOOD, [PRE]: '{"kind":"hyrox-pre-import","savedAt":"2026-11-01T00:00:00.000Z","raw":"OLD"}' } };
  for (const [name, init] of Object.entries(SCEN)) {
    for (const mode of ['throw', 'silent', 'partial']) {
      it(name + ' / ' + mode + ': never a false ok, previous data exact or rollback_failed with the exact copy kept', () => {
        const orig = Object.prototype.hasOwnProperty.call(init, KEY) ? init[KEY] : null;
        const p = mk(faultyStorage(init, 0, mode)).previewImport(IMPORT);
        assert.equal(p.ok, true);
        let sawOk = false, sawFail = false;
        for (let f = 1; f <= 30; f++) {
          const s = faultyStorage(init, f, mode);
          const r = mk(s).applyImport(IMPORT, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt });
          const key = s.m.has(KEY) ? s.m.get(KEY) : null;
          if (init[RECOVERY] !== undefined) assert.equal(s.m.get(RECOVERY), init[RECOVERY], 'corrupt-backup copy overwritten at f=' + f);
          if (r.ok) {
            sawOk = true;
            const d = JSON.parse(key);
            assert.equal(d.weight[0].id, 'w1'); assert.equal(d.walks.length, 1);
            assert.equal(JSON.parse(s.m.get(PRE)).raw, orig, 'pre-import copy is not the exact previous text at f=' + f);
          } else {
            sawFail = true;
            assert.ok(['backup_failed', 'write_failed', 'verify_failed', 'rollback_failed', 'storage_unreadable'].includes(r.code), r.code);
            if (r.code === 'rollback_failed') {
              assert.equal(JSON.parse(s.m.get(PRE)).raw, orig, 'rollback_failed but the pre-import copy is not exact');
            } else {
              assert.equal(key, orig, 'reported ' + r.code + ' but hyrox.v1 changed at f=' + f);
            }
            if (r.code === 'backup_failed' && init[PRE] !== undefined && mode !== 'partial') assert.equal(s.m.get(PRE), init[PRE]);
          }
        }
        assert.ok(sawOk && sawFail);
      });
    }
  }
  it('read-back mismatch on any later read never yields ok with unverified data', () => {
    for (let f = 2; f <= 20; f++) {
      const s = lyingStorage({ [KEY]: GOOD }, f);
      const st = mk(s);
      const r = st.applyImport(IMPORT, { confirm: 'REPLACE', expectCurrent: { weight: 1, workouts: 0, nutrition: 0 }, expectCurrentExt: { daily: 0 } });
      if (r.ok) assert.equal(JSON.parse(s.m.get(KEY)).weight[0].id, 'w1');
      else if (r.code !== 'rollback_failed' && r.code !== 'stale_plan' && r.code !== 'backup_failed') assert.equal(s.m.get(KEY), GOOD, 'f=' + f + ' ' + r.code);
    }
  });
  it('rollback to "no data" whose removeItem throws is reported as rollback_failed, never ok', () => {
    const m = new Map();
    let keyWrites = 0;
    const s = { getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => { if (k === KEY && ++keyWrites === 1) { m.set(k, 'torn'); return; } m.set(k, String(v)); }, removeItem: () => { throw new Error('nope'); } };
    const r = mk(s).applyImport(IMPORT, { confirm: 'REPLACE', expectCurrent: { weight: 0, workouts: 0, nutrition: 0 } });
    assert.equal(r.ok, false); assert.equal(r.code, 'rollback_failed');
    assert.equal(JSON.parse(m.get(PRE)).raw, null);
  });
});

describe('P4 held: preview, cancel and every refusal write nothing', () => {
  const states = { good: { [KEY]: GOOD }, empty: {}, corrupt: { [KEY]: CORRUPT }, newer: { [KEY]: '{"version":3,"weight":[],"workouts":[],"nutrition":[]}' } };
  const refusals = {
    not_json: '{"app":"hyrox-app",', empty: '', bom: '\ufeff' + IMPORT, too_large: IMPORT + ' '.repeat(HD.IMPORT_LIMITS.maxBytes),
    not_hyrox: '{"app":"other","version":2,"weight":[],"workouts":[],"nutrition":[]}', array: '[]',
    unsupported_version: file({}, 3), string_version: file({}, '2'),
    raw_recovery_kind: JSON.stringify({ kind: 'hyrox-raw-recovery', app: 'hyrox-app', version: 2, weight: [], workouts: [], nutrition: [] }),
    pre_import_envelope: JSON.stringify({ kind: 'hyrox-pre-import', savedAt: ts, raw: GOOD }),
    stored_text_itself: GOOD,
    invalid_records: file({ weight: [{ id: 'w', createdAt: ts, date: '2026-02-30', kg: 80 }] }),
    duplicate_ids: file({ walks: [{ id: 'k', createdAt: ts, date: '2026-11-10', durationMin: 30 }, { id: 'k', createdAt: ts, date: '2026-11-10', durationMin: 31 }] }),
    photo_meal_no_fraction: file({ meals: [PHOTO_NO_FRACTION] }),
    fractional_daily: file({ daily: [{ id: 'd', createdAt: ts, date: '2026-11-10', steps: { state: 'OBSERVED', value: 10.5 } }] }),
    non_list_ext: file({ sessions: { id: 'x' } }),
  };
  for (const [sn, init] of Object.entries(states)) {
    it(sn + ': preview of a valid file, then cancel, writes nothing', () => {
      const s = mapStorage(init); const before = snap(s);
      mk(s).previewImport(IMPORT); mk(s).exportSummary(); mk(s).rawRecoveryExport(); mk(s).status();
      assert.equal(s.writes, 0); assert.equal(snap(s), before);
    });
    for (const [rn, text] of Object.entries(refusals)) {
      it(sn + ': ' + rn + ' is refused by preview and by apply, with zero writes', () => {
        const s = mapStorage(init); const before = snap(s); const st = mk(s);
        const p = st.previewImport(text);
        assert.equal(p.ok, false, rn + ' previewed ok');
        const r = st.applyImport(text, { confirm: 'REPLACE', expectCurrent: { weight: 1, workouts: 0, nutrition: 0 }, expectCurrentExt: { daily: 0 } });
        assert.equal(r.ok, false);
        assert.equal(s.writes, 0); assert.equal(snap(s), before);
      });
    }
  }
  it('not_confirmed and stale_plan write nothing', () => {
    const s = mapStorage({ [KEY]: GOOD }); const before = snap(s); const st = mk(s);
    for (const o of [undefined, {}, { confirm: 'replace' }, { confirm: true }]) assert.equal(st.applyImport(IMPORT, o).code, 'not_confirmed');
    assert.equal(st.applyImport(IMPORT, { confirm: 'REPLACE' }).code, 'stale_plan');
    assert.equal(st.applyImport(IMPORT, { confirm: 'REPLACE', expectCurrent: { weight: 0, workouts: 0, nutrition: 0 } }).code, 'stale_plan');
    assert.equal(s.writes, 0); assert.equal(snap(s), before);
  });
  it('size limit boundary: exactly maxBytes characters is parsed, one more is too_large', () => {
    const base = IMPORT.slice(0, -1);
    const pad = HD.IMPORT_LIMITS.maxBytes - base.length - ',"pad":""}'.length;
    const exact = base + ',"pad":"' + 'a'.repeat(pad) + '"}';
    assert.equal(exact.length, HD.IMPORT_LIMITS.maxBytes);
    assert.equal(mk(mapStorage()).previewImport(exact).ok, true);
    const over = base + ',"pad":"' + 'a'.repeat(pad + 1) + '"}';
    assert.equal(mk(mapStorage()).previewImport(over).code, 'too_large');
  });
  it('deep nesting and huge top-level junk never throw', () => {
    let deep = '1'; for (let i = 0; i < 50000; i++) deep = '[' + deep + ']';
    const t = IMPORT.slice(0, -1) + ',"junk":' + deep + '}';
    const r = mk(mapStorage()).previewImport(t);
    assert.equal(typeof r.ok, 'boolean');
  });
});

describe('P4 held: export -> import -> export preserves records exactly', () => {
  function seed(st) {
    assert.ok(st.addWeight({ date: '2026-11-10', kg: 20 }).ok); assert.ok(st.addWeight({ date: '2026-11-10', kg: 400 }).ok); assert.ok(st.addWeight({ date: '2026-11-09', kg: 80.1 }).ok);
    assert.ok(st.addWorkout({ date: '2026-11-10', activity: 'Ski 🎿 – سكي \u202e', durationMin: 600, partial: true, notes: 'l1\nl2 "q" \\ \u0000 \ud83d lone' }).ok);
    assert.ok(st.addNutrition({ date: '2026-11-10', label: '', calories: 0, proteinG: 0 }).ok);
    assert.ok(st.addNutrition({ date: '2026-11-10', label: 'كبسة', calories: 10000, proteinG: 1000 }).ok);
    assert.ok(st.putRecord('daily', { id: 'daily-2026-11-10', date: '2026-11-10', steps: { state: 'OBSERVED', value: 200000, source: 'DEVICE' }, sleepH: { state: 'OBSERVED', value: 0 },
      pain: { state: 'OBSERVED', value: 10 }, rhr: { state: 'MISSING', value: null }, footPain: { state: 'OBSERVED', value: 0 }, limp: { state: 'OBSERVED', value: false } }).ok);
    assert.ok(st.putRecord('daily', { id: 'daily-2026-11-09', date: '2026-11-09', steps: { state: 'OBSERVED', value: 0, source: 'MANUAL' } }).ok);
    assert.ok(st.putRecord('walks', { date: '2026-11-10', durationMin: 600, steps: 0, stepsSource: 'MANUAL', distanceKm: 100 }).ok);
    assert.ok(st.putRecord('meals', { date: '2026-11-10', lifecycle: 'CONFIRMED', confirmedAt: ts, source: 'PHOTO_AI', eatenFraction: 0, label: '🍛',
      components: [{ name: 'rice', role: 'MAIN', kcal: { value: 0, state: 'KNOWN' }, proteinG: U, carbsG: { value: 2000, state: 'ESTIMATED' }, fatG: U }] }).ok);
    assert.ok(st.putRecord('sessions', { date: '2026-11-10', status: 'COMPLETED', modified: false, variant: 'ORIGINAL_60', runSteps: 0, runStepsSource: 'DEVICE', blocks: [{ kind: 'row', durationSec: 900, distanceM: 0 }] }).ok);
  }
  it('stored records are deep-identical after a restore, the re-export is identical, and repeating it adds nothing', () => {
    const s1 = mapStorage(); const a = mk(s1); seed(a);
    const e1 = a.exportJSON();
    const s2 = mapStorage(); const b = mk(s2);
    assert.equal(restore(b, e1).ok, true);
    const d1 = JSON.parse(s1.m.get(KEY)), d2 = JSON.parse(s2.m.get(KEY));
    assert.deepEqual(d2, d1);
    const strip = (t) => { const o = JSON.parse(t); delete o.exportedAt; return o; };
    assert.deepEqual(strip(b.exportJSON()), strip(e1));
    assert.equal(restore(b, e1).ok, true);
    assert.deepEqual(JSON.parse(s2.m.get(KEY)), d1, 'a second restore of the same file must not duplicate anything');
    // NULL stays NULL and 0 stays 0 through the round trip.
    const day = b.records('daily').find((d) => d.id === 'daily-2026-11-09');
    assert.deepEqual(day.steps, { state: 'OBSERVED', value: 0, source: 'MANUAL' });
    assert.deepEqual(b.records('daily').find((d) => d.id === 'daily-2026-11-10').rhr, { state: 'MISSING', value: null });
    assert.equal(b.records('meals')[0].eatenFraction, 0);
    assert.deepEqual(b.records('meals')[0].components[0].proteinG, U);
  });
  it('key order inside the file does not change what is stored', () => {
    const s1 = mapStorage(); const a = mk(s1); seed(a);
    const o = JSON.parse(a.exportJSON());
    const rev = (x) => Object.fromEntries(Object.entries(x).reverse());
    const shuffled = rev(Object.fromEntries(Object.entries(o).map(([k, v]) => [k, Array.isArray(v) ? v.map(rev) : v])));
    const s2 = mapStorage(); const b = mk(s2);
    assert.equal(restore(b, JSON.stringify(shuffled)).ok, true);
    assert.deepEqual(JSON.parse(s2.m.get(KEY)), JSON.parse(s1.m.get(KEY)));
  });
  it('10000 entries per list restore; 10001 are refused', () => {
    const W = []; for (let i = 0; i < 10000; i++) W.push({ id: 'w' + i, createdAt: ts, date: '2026-11-10', kg: 80 });
    const s = mapStorage(); const st = mk(s);
    assert.equal(restore(st, file({ weight: W }, 1)).ok, true);
    assert.equal(st.list('weight').length, 10000);
    W.push({ id: 'w10000', createdAt: ts, date: '2026-11-10', kg: 80 });
    assert.equal(mk(mapStorage()).previewImport(file({ weight: W }, 1)).code, 'too_many');
    const P = []; for (let i = 0; i < 10001; i++) P.push({ id: 'p' + i, createdAt: ts, date: '2026-11-10', kind: 'MISSED_MONDAY', week: 1 });
    assert.equal(mk(mapStorage()).previewImport(file({ planEvents: P })).ok, false);
  });
});

describe('P4 held: duplicate ids and prototype-style keys in imported JSON', () => {
  it('duplicate ids are refused in classic and Phase 3 lists, including the id "__proto__"', () => {
    const w = (id) => ({ id, createdAt: ts, date: '2026-11-10', kg: 80 });
    const k = (id) => ({ id, createdAt: ts, date: '2026-11-10', durationMin: 30 });
    for (const t of [file({ weight: [w('__proto__'), w('__proto__')] }), file({ walks: [k('constructor'), k('constructor')] }), file({ walks: [k('__proto__'), k('__proto__')] })]) {
      const r = mk(mapStorage()).previewImport(t);
      assert.equal(r.code, 'duplicate_ids');
      assert.equal(r.details[0].code, 'DUPLICATE_ID');
    }
    // The same id in two different collections is allowed (ids are per collection).
    assert.equal(mk(mapStorage()).previewImport(file({ weight: [w('x')], walks: [k('x')] })).ok, true);
  });
  it('"__proto__" / "constructor" keys inside records stay plain data: no pollution, kept on restore', () => {
    const text = '{"app":"hyrox-app","version":2,"exportedAt":"' + ts + '","weight":[{"id":"w","createdAt":"' + ts + '","date":"2026-11-10","kg":80,"__proto__":{"polluted":1}}],' +
      '"workouts":[],"nutrition":[],"walks":[{"id":"k","createdAt":"' + ts + '","date":"2026-11-10","durationMin":30,"__proto__":{"polluted":2,"steps":5},"constructor":{"prototype":{"polluted":3}}}]}';
    const s = mapStorage(); const st = mk(s);
    const p = st.previewImport(text);
    assert.equal(p.ok, true);
    assert.equal(st.applyImport(text, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt }).ok, true);
    assert.equal(({}).polluted, undefined);
    const walk = st.records('walks')[0];
    assert.equal(walk.steps, undefined, 'an inherited steps value leaked into the walk');
    assert.equal(Object.prototype.hasOwnProperty.call(walk, '__proto__'), true);
    assert.equal(st.list('weight')[0].polluted, undefined);
    assert.equal(({}).polluted, undefined);
  });
});

describe('P4 held: schema version, downgrade and v1 meaning', () => {
  it('a version 2 store with Phase 3 data never writes version 1; a newer store refuses every write and the normal export', () => {
    const s = mapStorage(); const st = mk(s);
    assert.ok(st.putRecord('walks', { date: '2026-11-10', durationMin: 30 }).ok);
    assert.equal(JSON.parse(s.m.get(KEY)).version, 2);
    assert.ok(st.addWeight({ date: '2026-11-10', kg: 80 }).ok);
    assert.equal(JSON.parse(s.m.get(KEY)).version, 2);
    const newer = '{"version":3,"weight":[],"workouts":[],"nutrition":[],"futureList":[1]}';
    const n = mapStorage({ [KEY]: newer }); const ns = mk(n);
    assert.equal(ns.addWeight({ date: '2026-11-10', kg: 80 }).ok, false);
    assert.equal(ns.putRecord('walks', { date: '2026-11-10', durationMin: 30 }).ok, false);
    assert.equal(ns.previewImport(file({}, 1)).code, 'storage_newer');
    assert.throws(() => ns.exportJSON());
    const raw = ns.rawRecoveryExport();
    assert.equal(raw.ok, true); assert.equal(HD.parseRawRecovery(raw.text).sources[0].raw, newer);
    assert.equal(n.m.get(KEY), newer); assert.equal(n.writes, 0);
  });
  it('a classic-only v1 backup restores as version 1 with exact field order; NULL vs 0 kept', () => {
    const s = mapStorage(); const st = mk(s);
    const v1 = file({ weight: [{ kg: 80, date: '2026-11-10', createdAt: ts, id: 'w1' }], nutrition: [{ id: 'n1', createdAt: ts, date: '2026-11-10', label: '', calories: 0, proteinG: 0 }] }, 1);
    assert.equal(restore(st, v1).ok, true);
    assert.equal(s.m.get(KEY), '{"version":1,"weight":[{"id":"w1","createdAt":"' + ts + '","date":"2026-11-10","kg":80}],"workouts":[],' +
      '"nutrition":[{"id":"n1","createdAt":"' + ts + '","date":"2026-11-10","label":"","calories":0,"proteinG":0}]}');
  });
  it('a Phase 3 era v1 backup keeps photo-meal confirmation, eaten fraction, MISSING and OBSERVED 0', () => {
    const s = mapStorage(); const st = mk(s);
    const meal = Object.assign({}, PHOTO_NO_FRACTION, { id: 'm-ok', eatenFraction: 0.5 });
    const draft = Object.assign({}, PHOTO_NO_FRACTION, { id: 'm-draft', lifecycle: 'NEEDS_REVIEW', confirmedAt: undefined });
    const t = file({ meals: [meal, draft], daily: [{ id: 'd', createdAt: ts, date: '2026-11-10', steps: { state: 'OBSERVED', value: 0 }, pain: { state: 'MISSING', value: null } }] }, 1);
    assert.equal(restore(st, t).ok, true);
    assert.equal(JSON.parse(s.m.get(KEY)).version, 2);
    const ms = st.records('meals');
    assert.equal(ms.find((m) => m.id === 'm-ok').lifecycle, 'CONFIRMED');
    assert.equal(ms.find((m) => m.id === 'm-ok').eatenFraction, 0.5);
    assert.equal(ms.find((m) => m.id === 'm-draft').lifecycle, 'NEEDS_REVIEW');
    assert.equal(ms.find((m) => m.id === 'm-draft').eatenFraction, undefined);
    assert.deepEqual(st.records('daily')[0].steps, { state: 'OBSERVED', value: 0 });
    assert.deepEqual(st.records('daily')[0].pain, { state: 'MISSING', value: null });
  });
});

describe('P4 held: corrupt-backup copy, pre-import slot and raw recovery', () => {
  it('a different existing corrupt-backup copy is never overwritten by writes or restores', () => {
    const s = mapStorage({ [KEY]: CORRUPT, [RECOVERY]: 'first-corruption' }); const st = mk(s);
    assert.equal(st.addWeight({ date: '2026-11-10', kg: 80 }).ok, false);
    assert.equal(st.putRecord('walks', { date: '2026-11-10', durationMin: 30 }).ok, false);
    assert.equal(restore(st, IMPORT).ok, true);
    assert.equal(s.m.get(RECOVERY), 'first-corruption');
    assert.equal(JSON.parse(s.m.get(PRE)).raw, CORRUPT);
  });
  it('after rollback_failed the raw recovery copy holds the exact previous text and is refused by Restore', () => {
    const m = new Map([[KEY, GOOD]]);
    let keyWrites = 0, lie = false;
    const s = { getItem: (k) => { if (k === KEY && lie) { lie = false; return 'garbled'; } return m.has(k) ? m.get(k) : null; },
      setItem: (k, v) => { if (k === KEY) { keyWrites++; if (keyWrites === 1) { m.set(k, v); lie = true; return; } if (keyWrites === 2) throw new Error('Quota'); } m.set(k, String(v)); },
      removeItem: (k) => m.delete(k) };
    const st = mk(s);
    const r = st.applyImport(IMPORT, { confirm: 'REPLACE', expectCurrent: { weight: 1, workouts: 0, nutrition: 0 }, expectCurrentExt: { daily: 0 } });
    assert.equal(r.code, 'rollback_failed');
    const raw = st.rawRecoveryExport();
    const parsed = HD.parseRawRecovery(raw.text);
    const pre = parsed.sources.find((x) => x.key === PRE);
    assert.equal(JSON.parse(pre.raw).raw, GOOD);
    assert.equal(st.previewImport(raw.text).code, 'raw_recovery_file');
    assert.equal(st.applyImport(raw.text, { confirm: 'REPLACE', expectCurrent: { weight: 1, workouts: 0, nutrition: 0 } }).code, 'raw_recovery_file');
  });
  it('a raw recovery file renamed to app "hyrox-app" or stripped of its kind is still never restored as a backup', () => {
    const s = mapStorage({ [KEY]: GOOD }); const st = mk(s);
    const env = JSON.parse(st.rawRecoveryExport().text);
    for (const t of [Object.assign({}, env, { app: 'hyrox-app' }), Object.assign({}, env, { kind: undefined })]) {
      assert.equal(st.previewImport(JSON.stringify(t)).ok, false);
    }
    assert.equal(s.writes, 0);
  });
  it('legacy CONFIRMED photo meal without an eaten fraction (OWNER HOLD): hidden, reported, kept by unrelated writes, byte-exact in the raw copy', () => {
    const raw = JSON.stringify({ version: 2, weight: [], workouts: [], nutrition: [], meals: [PHOTO_NO_FRACTION] });
    const s = mapStorage({ [KEY]: raw }); const st = mk(s);
    assert.equal(st.records('meals').length, 0);
    assert.deepEqual(st.exportSummary().omittedExt, { meals: 1 });
    assert.equal(JSON.parse(st.exportJSON()).meals.length, 0);
    const rx = st.rawRecoveryExport();
    assert.equal(rx.normalExport, 'partial'); assert.equal(rx.omittedTotal, 1);
    assert.equal(HD.parseRawRecovery(rx.text).sources[0].raw, raw);
    assert.ok(st.putRecord('walks', { date: '2026-11-10', durationMin: 30 }).ok);
    assert.deepEqual(JSON.parse(s.m.get(KEY)).meals, [PHOTO_NO_FRACTION]);
  });
  it('fractional steps (OWNER HOLD): legacy walk restored exactly with a warning; daily total refused with details and zero writes', () => {
    const walk = { id: 'k1', date: '2026-11-10', createdAt: ts, durationMin: 30, steps: 10.5, stepsSource: 'DEVICE' };
    const s = mapStorage(); const st = mk(s);
    const t = file({ walks: [walk] });
    assert.ok(st.previewImport(t).preview.warnings.some((w) => /not a whole number/.test(w)));
    assert.equal(restore(st, t).ok, true);
    assert.deepEqual(JSON.parse(s.m.get(KEY)).walks[0], walk);
    assert.equal(JSON.parse(st.exportJSON()).walks[0].steps, 10.5);
    const s2 = mapStorage({ [KEY]: GOOD }); const before = snap(s2);
    const d = mk(s2).previewImport(file({ daily: [{ id: 'd', date: '2026-11-10', createdAt: ts, steps: { state: 'OBSERVED', value: 10.5 } }] }));
    assert.equal(d.code, 'invalid_records'); assert.equal(d.details[0].field, 'steps.value'); assert.equal(d.details[0].value, 10.5);
    assert.equal(snap(s2), before);
  });
});

describe('P4 held: cross-tab collision detected when counts change', () => {
  it('a second store instance adding a record between preview and apply gives stale_plan and writes nothing', () => {
    const s = mapStorage(); const A = mk(s), B = mk(s);
    assert.ok(A.addWeight({ date: '2026-11-09', kg: 80 }).ok);
    assert.ok(B.putRecord('daily', { id: 'daily-2026-11-10', date: '2026-11-10' }).ok);
    const p = A.previewImport(IMPORT);
    assert.ok(B.addWeight({ date: '2026-11-10', kg: 79 }).ok);
    const before = snap(s);
    assert.equal(A.applyImport(IMPORT, { confirm: 'REPLACE', expectCurrent: p.preview.current, expectCurrentExt: p.preview.currentExt }).code, 'stale_plan');
    const p2 = A.previewImport(IMPORT);
    assert.ok(B.putRecord('walks', { date: '2026-11-10', durationMin: 20 }).ok);
    const before2 = snap(s);
    assert.equal(A.applyImport(IMPORT, { confirm: 'REPLACE', expectCurrent: p2.preview.current, expectCurrentExt: p2.preview.currentExt }).code, 'stale_plan');
    assert.equal(snap(s), before2);
    assert.notEqual(before, before2);
  });
});
