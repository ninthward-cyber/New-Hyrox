'use strict';
// Claude independent review of Phase 11.2 (19 Nov 2026). FAILING-FIRST against the Grok 11.2 tree (ff08c21d…):
//   C-03 typed quantities ("4 boiled eggs", "1 can tuna", "chicken 200g") returned NO match, so the owner was pushed to
//        Manual with kcal unknown. Quantity words are now ignored for matching (never used to set the amount).
//   C-02 validMyFoods only checked id/name; a saved food without a macro object made the My foods list throw.
// Synthetic data, no network, real bundled USDA index.
const test = require('node:test');
const assert = require('node:assert/strict');
global.self = global;
require('../src/data/food-db.js');
const DB = global.HyroxFoodDb;
const FC = require('../src/data/hyrox-foodcalc.js');
const FS = require('../src/data/hyrox-foodsearch.js');
const IX = FS.buildIndex(DB, FC.ALIASES);
const names = (q) => FS.search(IX, q, {}).results.map((r) => r.name);

test('C-03: a typed count or amount does not stop the search (counts and units are not food words)', () => {
  assert.ok(names('4 boiled eggs').some((n) => /^Egg, whole, cooked, hard-boiled/.test(n)), JSON.stringify(names('4 boiled eggs').slice(0, 5)));
  assert.ok(names('1 can tuna').some((n) => /tuna/i.test(n)));
  assert.ok(names('2 eggs').length > 0);
  assert.equal(names('2 eggs')[0], names('eggs')[0]); // same best row as without the count
  assert.ok(names('chicken breast 200g').some((n) => /^Chicken, broilers or fryers, breast/.test(n)));
  assert.ok(names('200 g chicken breast').some((n) => /^Chicken, broilers or fryers, breast/.test(n)));
  assert.ok(names('1/2 cup rice').some((n) => /^Rice, white/.test(n)));
  assert.ok(names('1.5 tbsp peanut butter').some((n) => /^Peanut butter/i.test(n)));
  assert.ok(names('two eggs').length > 0);
});

test('C-03: the typed amount is never applied for the owner: results carry no quantity, and adding still needs an explicit quantity', () => {
  const r = FS.search(IX, '4 boiled eggs', {}).results[0];
  assert.equal(r.qty, undefined); assert.equal(r.quantity, undefined);
  assert.equal(FS.usdaComponent(IX, r.key, FS.servingsFor(IX, r.key)[0], NaN).ok, false);
});

test('C-03: a query made only of numbers/units still searches as typed (nothing is invented, e.g. "00" flour)', () => {
  assert.ok(names('00').some((n) => /Flour, 00/.test(n)));
  assert.deepEqual(FS.search(IX, '2', {}).results.length > 0, FS.search(IX, '2', {}).count > 0);
});

test('C-03 guard: only standalone count/unit words in the QUERY are dropped; food words around them still match', () => {
  assert.ok(names('slice cheese').some((n) => /^Cheese, .*sliced/.test(n))); // sliced cheeses still found
  assert.ok(names('canned tuna').some((n) => /tuna/i.test(n) && /canned/i.test(n))); // "canned" is a food word, not a unit
  assert.ok(names('2 slices pizza').some((n) => /pizza/i.test(n)));
  assert.equal(names('chickpea flour').length > 0, true); // unchanged queries behave as before
  assert.deepEqual(names('banana'), names('1 banana'));
});

test('C-02: validMyFoods normalises each saved food so a damaged or older entry cannot break the list', () => {
  const raw = [
    { id: 'a', name: 'Bare entry' },
    { id: 'b', name: 'Neg', kcal: { value: -5, state: 'KNOWN' }, proteinG: 'x', carbsG: null, fatG: { value: 3, state: 'BOGUS' }, portion: 42 },
    { id: 'c', name: 'Good', portion: '1 bowl', kcal: { value: 400, state: 'KNOWN' }, proteinG: { value: 20, state: 'ESTIMATED' }, carbsG: { value: 50, state: 'ESTIMATED' }, fatG: { value: 10, state: 'KNOWN' }, basis: 'your values',
      provenance: { source: 'USDA_FDC', dataset: 'SR', fdcId: 1, description: 'x', portion: 'p', grams: 10, dbVersion: 'v' } },
    { id: 3, name: 'bad id' }, null, 'str', { id: 'e', name: '   ' },
  ];
  const snap = JSON.stringify(raw);
  const out = FS.validMyFoods(raw);
  assert.equal(JSON.stringify(raw), snap, 'input not mutated');
  assert.deepEqual(out.map((f) => f.id), ['a', 'b', 'c']);
  for (const f of out) for (const k of ['kcal', 'proteinG', 'carbsG', 'fatG']) {
    assert.ok(f[k] && typeof f[k] === 'object', f.id + ' ' + k);
    assert.ok(['KNOWN', 'ESTIMATED', 'UNKNOWN'].includes(f[k].state), f.id + ' ' + k);
    assert.ok(f[k].value === null || (typeof f[k].value === 'number' && f[k].value >= 0), f.id + ' ' + k);
  }
  assert.deepEqual(out[0].kcal, { value: null, state: 'UNKNOWN' }); // never 0
  assert.deepEqual(out[1].kcal, { value: null, state: 'UNKNOWN' });
  assert.equal(typeof out[1].portion, 'string');
  assert.deepEqual(out[2].kcal, { value: 400, state: 'KNOWN' }); // owner values stay as typed
  assert.equal(out[2].provenance.fdcId, 1);
  // a normalised entry is usable end to end
  assert.equal(FS.myFoodComponent(out[0], 1).ok, true);
  assert.equal(FS.myFoodComponent(out[0], 1).component.kcal.value, null);
});
