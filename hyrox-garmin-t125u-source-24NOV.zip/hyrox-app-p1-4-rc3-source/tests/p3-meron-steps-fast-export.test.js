'use strict';
// Meron (QA): owner step / fast / damaged-export rules vs Dawit's implemented
// contracts (dawit-steps-contract.md, dawit-recovery-api.md, dawit-fast-state.md).
// Synthetic data only. Does not edit src/ or existing tests.

const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const HW = require(path.resolve(__dirname, '../src/data/hyrox-wellness.js'));
const HN = require(path.resolve(__dirname, '../src/data/hyrox-nutrition.js'));
const { HD, KEY, mem, mk, O, MISSING, U, K, ts, backup, restore } = require('./p3-helpers.js');

const TODAY = '2026-11-11';
const daily = (extra) => Object.assign({ id: 'daily-' + TODAY, createdAt: ts, date: TODAY }, extra);
const walk = (id, steps, extra) => Object.assign({ id, createdAt: ts, date: TODAY, durationMin: 30, steps }, extra);
const run = (id, runSteps, extra) => Object.assign({
  id, createdAt: ts, date: TODAY, status: 'COMPLETED', modified: false, variant: 'NONE', blocks: [],
  runSteps, runStepsSource: runSteps == null ? undefined : 'DEVICE',
}, extra);

describe('Dawit daySteps / running+walking contract (now implemented)', () => {
  it('a recorded daily total is primary; walk + run are never added', () => {
    const out = HW.daySteps(TODAY, {
      dailies: [daily({ steps: O(8000) })],
      walks: [walk('w1', 3000)],
      sessions: [run('s1', 2500)],
    });
    assert.equal(out.total, 8000);
    assert.equal(out.source, 'daily');
    assert.equal(out.complete, true);
    assert.equal(out.walkSteps, 3000);
    assert.equal(out.runSteps, 2500);
    assert.ok(out.flags.includes('WORKOUT_STEPS_NOT_ADDED'));
    assert.notEqual(out.total, 8000 + 3000 + 2500);
  });

  it('with no daily total, walk + run steps sum as a partial lower bound (no double count)', () => {
    const s = run('s1', 2500);
    const w = walk('w1', 3000);
    const out = HW.daySteps(TODAY, {
      dailies: [daily({ steps: MISSING })],
      walks: [w, w, walk('w-other', 999, { date: '2026-11-10' })],
      sessions: [s, s, run('s-other', 777, { date: '2026-11-10' })],
    });
    assert.equal(out.total, 5500);
    assert.equal(out.source, 'partial_lower_bound');
    assert.equal(out.complete, false);
    assert.equal(out.walkSteps, 3000);
    assert.equal(out.runSteps, 2500);
    assert.equal(out.walkCount, 1);
    assert.equal(out.runCount, 1);
    assert.ok(out.flags.includes('LOWER_BOUND_NOT_DAY_TOTAL'));
  });

  it('nothing recorded => total null, never 0; a recorded 0 is a real 0', () => {
    const empty = HW.daySteps(TODAY, { dailies: [], walks: [], sessions: [] });
    assert.equal(empty.total, null);
    assert.equal(empty.source, null);
    assert.ok(empty.flags.includes('NO_STEP_DATA'));
    assert.equal(HW.daySteps(TODAY, { dailies: [daily({ steps: MISSING })] }).total, null);
    assert.equal(HW.daySteps(TODAY, { dailies: [daily({ steps: O(0) })] }).total, 0);
    const zeroRun = HW.daySteps(TODAY, { sessions: [run('s0', 0)] });
    assert.equal(zeroRun.total, 0);
    assert.equal(zeroRun.source, 'partial_lower_bound');
  });

  it('canonicalSteps still has the old shape and includes run steps when sessions are passed', () => {
    const withRuns = HW.canonicalSteps(TODAY, [], [walk('w1', 3000)], [run('s1', 2500)]);
    assert.equal(withRuns.value, 5500);
    assert.equal(withRuns.partial, true);
    assert.equal(withRuns.detail.source, 'partial_lower_bound');
    const dailyOnly = HW.canonicalSteps(TODAY, [daily({ steps: O(8000) })], [walk('w1', 3000)], [run('s1', 2500)]);
    assert.equal(dailyOnly.value, 8000);
    assert.equal(dailyOnly.partial, false);
  });

  it('import of a bad runSteps rejects the whole file and writes nothing', () => {
    const storeMem = mem();
    const st2 = mk(storeMem);
    st2.addWeight({ date: TODAY, kg: 80 });
    const before = storeMem.m[KEY];
    const writes = storeMem.writes;
    const text = backup({
      sessions: [run('s-ok', 2500), run('s-bad', -1)],
    });
    const p = st2.previewImport(text);
    assert.equal(p.ok, false);
    assert.equal(p.code, 'invalid_records');
    assert.equal(st2.applyImport(text, { confirm: 'REPLACE', expectCurrent: { weight: 1, workouts: 0, nutrition: 0 } }).ok, false);
    assert.equal(storeMem.m[KEY], before);
    assert.equal(storeMem.writes, writes);
    assert.equal(JSON.parse(st2.exportJSON()).weight[0].kg, 80);
  });

  it('run steps on NOT_STARTED or SKIPPED are rejected by putRecord and by import (nothing written)', () => {
    const st = mk(mem());
    const base = { date: TODAY, modified: false, variant: 'NONE', blocks: [], runSteps: 10, runStepsSource: 'DEVICE' };
    assert.equal(st.putRecord('sessions', Object.assign({}, base, { status: 'NOT_STARTED' })).ok, false);
    assert.equal(st.putRecord('sessions', Object.assign({}, base, { status: 'SKIPPED', skipConfirmed: true })).ok, false);
    assert.equal(st.putRecord('sessions', Object.assign({}, base, { status: 'IN_PROGRESS' })).ok, true);
    const storeMem = mem();
    const st2 = mk(storeMem);
    st2.addWeight({ date: TODAY, kg: 80 });
    const before = storeMem.m[KEY], writes = storeMem.writes;
    const text = backup({ sessions: [run('sk', 10, { status: 'SKIPPED', skipConfirmed: true })] });
    const p = st2.previewImport(text);
    assert.equal(p.ok, false);
    assert.equal(p.code, 'invalid_records');
    assert.ok((p.errors || []).some((e) => e.field === 'runSteps'));
    assert.equal(st2.applyImport(text, { confirm: 'REPLACE', expectCurrent: { weight: 1, workouts: 0, nutrition: 0 } }).ok, false);
    assert.equal(storeMem.m[KEY], before);
    assert.equal(storeMem.writes, writes);
  });
});

describe('fast-day contract: D1–D5 stay canonical; DF maps to canonicalCode D4; no invented zero', () => {
  it('an unanswered empty day is D1 with dayKcal null, never 0, and is excluded from eating-day averages', () => {
    const ds = HN.dayState(TODAY, [], null);
    assert.equal(ds.code, 'D1');
    assert.equal(ds.canonicalCode, 'D1');
    assert.equal(ds.dayKcal, null);
    assert.equal(ds.fastDay, false);
    const avg = HN.dayAverages([ds]);
    assert.equal(avg.eatingDays.n, 0);
    assert.equal(avg.eatingDays.kcalMean, null);
    assert.equal(avg.fastingDays.n, 0);
    assert.equal(avg.excluded.n, 1);
  });

  it('a confirmed full-day fast is DF with canonicalCode D4, dayKcal 0, and is tracked apart from eating-day averages', () => {
    const att = { date: TODAY, attestation: 'COMPLETE', basis: HN.dayState(TODAY, [], null).basis, fast: 'CONFIRMED_FULL_DAY_FAST' };
    const ds = HN.dayState(TODAY, [], att);
    assert.equal(ds.code, 'DF');
    assert.equal(ds.canonicalCode, 'D4');
    assert.equal(ds.dayKcal, 0);
    assert.equal(ds.fastDay, true);
    assert.notEqual(ds.code, 'D5');
    const meal = {
      date: TODAY, label: 'Test oats', source: 'MANUAL', lifecycle: 'CONFIRMED', confirmedAt: ts,
      components: [{ name: 'Oats', role: 'MAIN', kcal: K(350), proteinG: K(22.5), carbsG: U, fatG: K(6) }],
    };
    const eating = HN.dayState(TODAY, [meal], { date: TODAY, attestation: 'COMPLETE', basis: HN.dayState(TODAY, [meal], null).basis });
    assert.equal(eating.code, 'D5');
    assert.equal(eating.canonicalCode, 'D5');
    const avg = HN.dayAverages([ds, eating]);
    assert.equal(avg.eatingDays.n, 1);
    assert.equal(avg.eatingDays.kcalMean, 350);
    assert.equal(avg.fastingDays.n, 1);
    assert.deepEqual(avg.fastingDays.dates, [TODAY]);
  });

  it('D1–D5 labels still exist; "food not logged" is not a fast and does not invent 0 kcal', () => {
    const att = { date: TODAY, attestation: 'INCOMPLETE', basis: HN.dayState(TODAY, [], null).basis, fast: 'NOT_LOGGED' };
    const ds = HN.dayState(TODAY, [], att);
    assert.equal(ds.code, 'D3');
    assert.equal(ds.canonicalCode, 'D3');
    assert.equal(ds.dayKcal, null);
    assert.equal(ds.fastDay, false);
    assert.notEqual(ds.code, 'DF');
    assert.deepEqual(HN.CANONICAL_CODES, ['D1', 'D2', 'D3', 'D4', 'D5']);
  });
});

describe('damaged-export recovery (Dawit rawRecoveryExport)', () => {
  it('the normal export omits unusable Phase 3 records; rawRecoveryExport is a byte-exact copy with an omission warning', () => {
    const good = { id: 'ok1', createdAt: ts, date: TODAY, status: 'PARTIAL', modified: false, variant: 'NONE', blocks: [] };
    const broken = { id: 'bad1', createdAt: ts, date: TODAY, status: 'BOGUS' };
    const raw = JSON.stringify({ version: 1, weight: [], workouts: [], nutrition: [], sessions: [good, broken] });
    const s = mem({ [KEY]: raw });
    const st = mk(s);
    assert.deepEqual(st.exportSummary().omittedExt, { sessions: 1 });
    const text = st.exportJSON();
    assert.deepEqual(JSON.parse(text).sessions.map((x) => x.id), ['ok1']);
    assert.equal(JSON.parse(s.m[KEY]).sessions.length, 2, 'the damaged record is still on device');
    const rec = st.rawRecoveryExport();
    assert.equal(rec.ok, true);
    assert.equal(s.writes, 0, 'raw export is read-only');
    assert.equal(rec.normalExport, 'partial');
    assert.equal(rec.omittedTotal, 1);
    assert.equal(typeof rec.warning, 'string');
    assert.match(rec.warning, /omitted|leaves out|damaged|NOT a normal backup/i);
    const parsed = HD.parseRawRecovery(rec.text);
    assert.equal(parsed.ok, true);
    assert.equal(parsed.sources[0].raw, raw);
    assert.equal(parsed.sources[0].raw, s.m[KEY]);
  });

  it('a raw recovery file is refused by normal import (raw_recovery_file) and nothing is written', () => {
    const rawStore = JSON.stringify({
      version: 1, weight: [], workouts: [], nutrition: [],
      sessions: [{ id: 'bad', createdAt: ts, date: TODAY, status: 'BOGUS' }],
    });
    const src = mk(mem({ [KEY]: rawStore })).rawRecoveryExport().text;
    const s = mem();
    const st = mk(s);
    st.addWeight({ date: '2026-11-10', kg: 80 });
    const before = JSON.stringify(s.m), writes = s.writes;
    const p = st.previewImport(src);
    assert.equal(p.ok, false);
    assert.equal(p.code, 'raw_recovery_file');
    const a = st.applyImport(src, { confirm: 'REPLACE', expectCurrent: { weight: 1, workouts: 0, nutrition: 0 } });
    assert.equal(a.ok, false);
    assert.equal(a.code, 'raw_recovery_file');
    assert.equal(JSON.stringify(s.m), before);
    assert.equal(s.writes, writes);
  });
});

describe('FINDING 1 (current behaviour only; owner decision): older CONFIRMED photo meals with no eaten fraction', () => {
  // Documents CURRENT behaviour and nothing more. Whether a pre-owner-rule-2
  // confirmed photo meal should be importable (left unconfirmed, assumed 100%,
  // or refused as now) is an owner decision. This test does not propose a change.
  it('import of a whole file is refused; nothing is written', () => {
    const oldPhoto = {
      id: 'legacy-photo', createdAt: ts, date: TODAY, source: 'PHOTO_AI', lifecycle: 'CONFIRMED', confirmedAt: ts,
      ai: { mode: 'MOCK' },
      components: [{ name: 'rice', role: 'MAIN', kcal: K(400), proteinG: K(10), carbsG: U, fatG: K(0) }],
    };
    const text = backup({ meals: [oldPhoto] }, 1);
    const s = mem();
    const st = mk(s);
    st.addWeight({ date: TODAY, kg: 80 });
    const before = s.m[KEY], writes = s.writes;
    const p = st.previewImport(text);
    assert.equal(p.ok, false);
    assert.equal(p.code, 'invalid_records');
    assert.equal(p.errors[0].field, 'eatenFraction');
    const a = st.applyImport(text, { confirm: 'REPLACE', expectCurrent: { weight: 1, workouts: 0, nutrition: 0 } });
    assert.equal(a.ok, false);
    assert.equal(s.m[KEY], before);
    assert.equal(s.writes, writes);
  });
});
