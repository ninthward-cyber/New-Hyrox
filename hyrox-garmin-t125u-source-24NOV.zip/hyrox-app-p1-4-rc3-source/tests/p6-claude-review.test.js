'use strict';
// Claude Phase 6 independent review: regression tests for the text-estimate matcher. Synthetic text only, real bundled DB.
// FAILS on Grok fd37069: a text match was chosen by itself whenever exactly one USDA food contained every typed word,
// so ordinary words ("bowl", "baked", "sandwich", "cup of") silently chose foods the owner did not mean, with numbers.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('path');
const FC = require(path.resolve(__dirname, '../src/data/hyrox-foodcalc.js'));
const DB = require(path.resolve(__dirname, '../src/data/food-db.json'));

const one = (t) => { const r = FC.estimate(t, DB); assert.equal(r.ok, true); assert.equal(r.items.length, 1, t); return r.items[0]; };
const ALIAS_IDS = new Set(FC.ALIASES.map((a) => a[1] + ':' + a[2]));

describe('Claude P6: a text match is not chosen by itself when the USDA description says more than was typed', () => {
  // Each of these was "matched" with numbers on fd37069 (food shown in the comment).
  const WRONG = [
    ['1 bowl rice', 173339],          // Rice bowl with chicken, frozen entree (428 kcal)
    ['1 rice bowl', 173339],
    ['100g cup of milk', 170866],     // Dessert topping, powdered, prepared with 1/2 cup milk
    ['1 baked egg', 169595],          // Desserts, egg custard, baked (563 g, 586 kcal)
    ['1 baked cheddar', 168005],      // Goldfish crackers, one cracker (0.52 g)
    ['1 mozzarella sandwich', 172107],// HOT POCKETS meatballs & mozzarella
    ['1 serving yogurt', 175226],     // SILK vanilla soy yogurt
    ['1 yogurt bar', 174802],         // Nature Valley granola bar with yogurt coating
    ['100g tub yogurt', 173586],      // Margarine-like spread with yogurt
    ['1 grilled tortilla', 170786],   // Fast food grilled chicken wrap
    ['1 organic oatmeal', 174660],    // QUAKER instant oatmeal organic
  ];
  for (const [t, was] of WRONG) {
    it(`"${t}" is offered for the owner to choose, never counted by itself`, () => {
      const i = one(t);
      assert.equal(i.status, 'ambiguous'); assert.equal(i.chosen, null); assert.equal(i.nutrients, null); assert.equal(i.provenance, null);
      assert.ok(i.candidates.some((c) => c.fdcId === was), 'the food is still offered, so the owner can pick it if it is right');
      const r = FC.estimate(t, DB); assert.equal(r.totals.kcal, 0); assert.equal(r.totals.matchedCount, 0);
      assert.equal(FC.toComponents(r).components.length, 0, 'nothing becomes an estimated component until the owner picks');
    });
  }
  it('the message says one food was found and the owner must check it', () => {
    assert.match(one('1 bowl rice').message, /One USDA food contains all the words you typed .*choose it; nothing is counted/);
  });
  it('picking that food gives the numbers (one tap, same arithmetic as before)', () => {
    const p = FC.estimateItem('1 bowl rice', DB, { fdcId: 173339, dataset: 'SR' });
    assert.equal(p.status, 'matched'); assert.equal(p.chosen.fdcId, 173339); assert.ok(p.nutrients.kcal > 0);
  });
  it('alias foods are unchanged (they choose themselves, with numbers)', () => {
    for (const [t, id, kcal] of [['2 eggs', 171287, 143], ['1 cup rice', 168878, 205], ['1 fried egg', 173423, 90], ['1 baked potato', 170093, 161],
      ['1 cup milk', 171265, 149], ['1 tbsp olive oil', 171413, 119], ['3 dates', 168191, 199], ['150 g chicken breast', 171477, 248]]) {
      const i = one(t); assert.equal(i.status, 'matched', t); assert.equal(i.chosen.fdcId, id, t); assert.equal(i.nutrients.kcal, kcal, t);
    }
  });
  it('a text match whose USDA description has exactly the typed words is still chosen ("1 cup cooked millet")', () => {
    const i = one('1 cup cooked millet'); assert.equal(i.status, 'matched'); assert.equal(i.chosen.description, 'Millet, cooked');
  });
  it('sweep: every alias food with 40 everyday words (15,840 phrases) never chooses a food outside the alias table', () => {
    const words = ['bowl', 'plate', 'glass', 'mug', 'serving', 'portion', 'scoop', 'handful', 'bottle', 'can', 'box', 'pack', 'bar', 'piece of', 'slice of', 'cup of', 'side of',
      'spoon', 'spoons', 'tub', 'jar', 'packet', 'sandwich', 'salad', 'soup', 'juice', 'smoothie', 'shake', 'wrap', 'fried', 'grilled', 'roasted', 'baked', 'steamed', 'spicy',
      'homemade', 'leftover', 'plain', 'fresh', 'organic'];
    let n = 0; const bad = [];
    for (const a of FC.ALIASES) for (const w of words) for (const t of ['1 ' + w + ' ' + a[0][0], '1 ' + a[0][0] + ' ' + w, '100g ' + w + ' ' + a[0][0]]) {
      for (const it of FC.estimate(t, DB).items) {
        n++;
        if (it.status === 'matched' && !ALIAS_IDS.has(it.chosen.dataset + ':' + it.chosen.fdcId)) {
          const words2 = it.chosen.description.toLowerCase().match(/[a-z0-9]+/g);
          bad.push(t + ' -> ' + it.chosen.description + ' (' + words2.length + ' words)');
        }
      }
    }
    assert.equal(n, 15840);
    assert.deepEqual(bad, [], 'no non-alias food may be chosen without the owner');
  });
});
