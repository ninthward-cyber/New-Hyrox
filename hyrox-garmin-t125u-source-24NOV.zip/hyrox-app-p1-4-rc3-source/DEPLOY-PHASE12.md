# Phase 12: deploy and rollback (owner only, after Claude's review and the owner's explicit go-ahead)

**This package is not deploy approval, and it is not approval of Block 2 training content.**
- **Site:** `hyrox-phase7-private-test` (ID `99f0deb7-0526-46f6-b432-9c3bfc2c86d2`). Same steps as DEPLOY-PHASE11.2 sections A–C, with this zip and `SHA256SUMS-phase12.txt`.
- **Changes:** no env change and no migration; data version stays 2. One new static file, `src/data/hyrox-blocks.js` (14 app files).
- **Sizes to expect after deploy:** `src/ui/app-ext.js` 292525 bytes, `src/data/hyrox-blocks.js` 59230 bytes, `src/ui/style.css` 41683 bytes (unchanged).

## Before deploying
1. Settings → **Export JSON backup**, and keep the file.
2. Draft URL checks (a new Safari tab, not the Home Screen icon):
   - Today → **Next training block** → Create draft. It shows "Draft — pending owner approval after 11 Dec".
   - Activation is locked before 11 Dec.
   - Today is unchanged.
   - Delete the draft, then clear that tab's website data.

## Owner device checks (real iPhone Safari; all e2e ran in Chrome emulation, not Safari)
1. **From 11 Dec:** options start at Hold with nothing selected. Review the preview, tick approve, then Activate (confirm).
2. **Mon 14 Dec** after midnight Qatar time: Today shows "Block 2 · Week 1/4". Close and reopen the icon: it is still there.
3. **Steps** on a Block 2 day: "no plan step reference goal (ST0)".
4. **Larger Text / VoiceOver:** the planner fold, the options radios and the confirm dialogs are readable and tappable.

## Rollback (no env change, no migration)
1. **Export a backup before rolling back.**
2. Then publish the previous deploy. Same targets as P11.2 section E; the first rollback target is Claude P11.2 (the build this one replaces).
3. **Tested on the Claude P11.2 (6e2b2cae), Claude P11 (bdab182, zip ffa58d1a) and Claude P10b (34bdf3d) data layers.** A Phase 12 backup restores with `planBlocks`, Block 2 sessions and their skip decisions intact. A normal settings save on those builds keeps `planBlocks`. Exporting there and restoring back on Phase 12 brings Block 2 back.
4. **On an older build, Block 2 is invisible.** The app is Block 1 only and shows "no active block" after 13 Dec. Block 2 workouts appear in History as unlinked.

### Old-build limitations: "export backup before rollback; don't edit Block 2 records on old builds"
- **Editing a skipped Block 2 workout:** on an old build, saving it again removes its skip decision. The cause is the line `if (rec.status !== 'SKIPPED' || !slot) delete skipDecision` (P11.2 app-ext.js:955, P11:912, P10b:816).
- **"Replace the saved settings" for a damaged settings record:** on an old build this rebuilds the record without `planBlocks`. P11 and P10b also drop saved foods.
- **Two tabs open:** on an old build, a Settings save made from a screen opened before another change can overwrite that change (P11.2 and earlier save the copy captured at render).
- **Restoring an older backup that has no Block 2:** this removes Block 2 from the device. Phase 12 warns about this in the restore preview; old builds do not.
