# Phase 11.2 — changes, split by part (base: Claude-reviewed Phase 11, git-archive commit bdab182)

One combined build = all Phase 11.1 scope + Phase 11.2 P0 food search. Each part is its own commit and can be reviewed (or reverted) alone, in order:

| # | Commit | Scope | Status |
|---|---|---|---|
| 1 | `b60b713` | 11.1 P0 — diary after Add > Meal | done |
| 2 | `ba4fec8` | 11.1 P1 — healthy-habit rows on Today | done (water: follow-up, see below) |
| 3 | `0ff6dd0` | 11.1 P1 — Trends presentation | done |
| 4 | `18a2d4d` | 11.2 P0 — Add foods search + My foods | done (FNDDS + fiber/sodium: flagged, not shipped) |
| – | (tools commit) | before/after screenshot script | tooling only |

No change to `functions/` / `netlify/`, `hyrox-data.js`, `hyrox-foodcalc.js`, `food-db.*`, the photo/AI stub or live provider, prices, caps, env, keys or `hyrox.v1` key. Data version stays **2**.

## Part 1 — 11.1 P0: a confirmed Add > Meal save returns to the diary
- Confirm from **Add > Meal** (Manual, Describe, Photo, or Add foods) now lands on **Today**, on the diary of the meal's own date, opens its category row (or **Uncategorized** when no category was chosen), marks the new entry once (yellow bar, not colour alone) and puts keyboard/VoiceOver focus on it. Backdated meals open that day; Today itself keeps today's date.
- Unchanged: History **Edit/Copy** still return to History; **Save draft**/unconfirmed saves still go to History; diary Edit returns to the diary; failed saves stay on the form with every input; discard prompt; Qatar midnight date notice; Phase 10b form reset; tab bar.
- Existing e2e tests: only a `tab-history` click was added where they previously expected to land on History; no assertion removed.

## Part 2 — 11.1 P1: healthy-habit rows on Today ("Today at a glance")
- **Steps**: existing row, now also shows the target (adaptive suggestion or your override) — same computation.
- **Exercise** (new row): recorded sessions for the day with status and minutes, plus walks (count, minutes). No calorie burn. Button **Log workout** opens the existing Add > Workout form.
- **Weight** (new row): latest measured weight on or before the shown day, with its date. A later-dated entry is never shown as current. **Log weight** opens the existing form with the weight field focused.
- Empty days say "not recorded" (never 0). Planned workout and readiness warnings unchanged and still first.
- **Water: no row.** The app has no water-volume field (a "water" meal item is just a food name with 0 kcal). Not invented — follow-up decision for the owner.

## Part 3 — 11.1 P1: Trends presentation
- New **Summary** card with a **4 weeks / 12 weeks / All** switch: latest weight + its date + change since the first measurement in the window; steps this week (average over recorded days, missing days counted as missing, not 0); workouts completed/partial/skipped; nutrition average only over complete, quantified days (otherwise says so).
- Charts get real first/last **date labels** and follow the window. Same calculations; recorded points only — no smoothing, fills, VO2, readiness, expenditure or net-calorie logic.

## Part 4 — 11.2 P0: Add foods (local search, no paid AI)
- Meal form → **Add foods (search)** opens a compact screen for the current meal (title shows category + date): search box, **Search / Recent / Favorites / My foods**, and always-visible **Photo**, **Describe whole meal**, **Enter manually**.
- Search is **in the phone**: new static file `src/data/hyrox-foodsearch.js` (18 KB, 6.8 KB gzip) indexes the existing 8,167-item USDA bundle + existing aliases in memory when the screen opens. Ranking: exact name/alias → word matches → prefixes → light typo tolerance (labelled "Spelling-tolerant match"); recent and favourite foods are ranked up but **never** chosen automatically. **No network request while typing** (tested).
- Each row: name, serving, kcal (est.), source (e.g. "USDA SR Legacy (2018)"). Restaurant rows carry a "Restaurant · US 2018" badge; the detail says it is USDA's 2018 analysis, **not the restaurant's official figure**, and suggests entering the chain's own value manually. Macros and source are in a "Macros and source" fold.
- Tap a row → choose serving (USDA household portions, 100 g, or 1 g) and quantity → live preview → **Add to meal**. Several foods go into the **same draft**; nothing is saved until the usual single **Confirm**. Adding the same food twice asks first. Invalid quantity is refused. Eaten-fraction, restaurant/portion fields, categories, discard prompt, Qatar rollover and Phase 10b reset all unchanged.
- No result → "Enter manually" carries the typed text over with kcal **unknown** (not 0).
- **Save to My foods** is explicit, from a confirmed meal in History (pick which items). It copies the confirmed values and keeps the source / estimate status (USDA estimate stays ESTIMATED; owner-typed values stay as typed). Renaming, editing or deleting a saved food never changes any saved meal (meals hold their own snapshot). Favourites are a list of references.
- Storage: `myFoods` (≤ 200) and `favFoods` are **optional fields on the existing owner-settings record**, data version unchanged (2). Tested: Claude P11, Claude P10b and P9 data layers restore a P11.2 backup and export it again with `myFoods`/`favFoods` intact (not stripped); P11/P10b backups restore unchanged here.
- `meal.source` stays `MANUAL`; USDA components use the existing provenance shape (`USDA_FDC`, real `fdcId`, `dbVersion`). My-foods components keep the provenance they were saved with; owner-typed items get none — **no fake fdcId**.

### Flagged, not shipped in this build
- **FNDDS 2021-2023** compact file (~159 KB gzip): allowed by research, but it would need a new USDA download + a build step + its own tests; not added to keep this build reviewable. Ready as a follow-up (sibling file, own source label).
- **Fiber / sodium**: the shipped USDA bundle has no fiber/sodium columns, so nothing to store yet; arrives with FNDDS. No day totals change either way.
