# P1.3-RC2 — independent review of P1.3-RC1, with fixes

Reviewer: Claude (Workstream E, Independent QA), 23 Nov 2026. Candidate reviewed: Grok's **P1.3-RC1**, final commit `e272258`,
build source id `d0d7d8ab86a1`, source ZIP sha256 `a90ff6b707a89674e0a0fd2cb2bfcb286515cf6fb7563e891bae6457f83601b0`.
Provenance checked: that ZIP is byte-identical to P1.1-RC2 (`6829b05`) plus Grok's six-patch series. **Not deployed, not
pushed.** Data version 2, no migration, no new storage key, no network call, no Block 2 change. Every number marked
provisional in P1.3-RC1 is still provisional: nothing here approves a clinical value.

## What changed against P1.3-RC1
App files: `src/data/hyrox-coach.js`, `src/ui/app-ext.js`, `src/ui/style.css` (rules appended only), `index.html` (load guard, label).

1. **C2 — Monday–Sunday review weeks.** P1.3-RC1 reviewed Sunday–Saturday weeks while the training plan, the Garmin weekly sum
   and every other weekly figure use Monday–Sunday. Now one definition: completed **Monday–Sunday** weeks (Asia/Qatar dates).
   **Monday is review day** and covers the week that ended the day before. On Sunday the week is still open and is not
   judged. Block 2's benchmark week (Mon 7 – Sun 13 Dec) is reviewed on Mon 14 Dec and never mixed with the Block 2 week.
2. **C3 — unlogged is not skipped.** P1.3-RC1 counted every planned slot and turned the status amber ("fewer than half
   completed") when sessions were simply not logged, and counted source-directed omissions as misses. Now, from the plan's
   own slot statuses:
   - *omitted by the plan's own rules* (source cascade) — left out of every count, not a miss;
   - *not logged / not started / left in progress* — **unknown**, never "skipped", never amber. If more than half of the
     week is unlogged, a neutral **HOLD** note says so and only holds a *reduction* of an existing confirmed target;
   - *skipped* — only an explicit, confirmed skip. Amber when at least 2 and more than half of the **logged** planned
     sessions were skipped ("3 of the 4 logged planned sessions were skipped last week"). Partial counts as work done.
3. **C4 — a very low own target is never "on track".** P1.3-RC1 accepted 1,000 kcal with warnings and could then show
   "On track". Now a confirmed own target below the provisional floor (or the resting estimate, if higher) is an amber
   concern on Home and in Trends, names both numbers and says to discuss it with a clinician; no lower target is
   suggested while it stands. Confirming such a target needs a **separate tick** ("This is my own decision…"). The coach
   still never computes or recommends it. Whether to forbid it outright is an owner decision (see the review report).
4. **C6 — coach load failure is visible.** `hyrox-coach.js` is now in the page's load guard. If it fails to load while a coach
   is stored, Home says "Nutrition Coach did not load … the reference below is the provisional one, not your target" and
   Settings shows **UNAVAILABLE — load error**; nothing can be changed and the stored coach is untouched.
5. **C7 — larger text.** The Home macro labels no longer clip at 320 px with page zoom ("PROTEI"); the acknowledgement tick is
   a 44 px target.
6. **C1 — documentation only.** The code always kept 2,400 kcal / protein 190 g (protein floor 170 g). CHANGES-P1.3-RC1.md labelled
   the 170 g figure as carbohydrate and DEPLOY-P1.3-RC1.md gave three bare numbers without saying which is which; both corrected in place (marked). Invariant tests added.

## Reviewed and left as they were (with evidence in the review report)
- **C5** arithmetic: proposals keep protein + fat + carbs ≤ calories at every tested maintenance (1,800–3,000 kcal). With
  protein at 190 g and fat 25 %, any computed target under about 1,750 kcal is withheld by the 130 g carbohydrate screen.
  All thresholds remain provisional placeholders that only withhold or warn.
- **C8** a single week (the owner's first: 4 weigh-ins, 6 complete days, fast early loss) gives no personal estimate, a gray
  "one week is not a trend" status and no reduction (new test).
- **C9** data preservation: Grok's settings, two-tab, restore and rollback tests re-run green; rollback specs re-run on
  older builds (see the report).

## Tests changed
New: `tests/p1-3-review-fixes.test.js`, `tests/e2e/p1-3-review-fixes.spec.js`. Re-pointed (never deleted), each marked
"re-pointed by the independent review": Grok's Sunday–Saturday dates and the "fewer than half" amber in
`p1-3-coach-estimate.test.js`, `p1-3-coach-review.test.js`, `e2e/p1-3-coach-lib.js`, `e2e/p1-3-coach-estimate.spec.js`,
`e2e/p1-3-coach-review.spec.js`. The Stage B browser fixture now gives 2,690 kcal instead of 2,675 (same data, Monday–Sunday
windows; 0.1 kg rounding of stored weights alone moves it about ±15 kcal).

## Limits
Chrome mobile emulation at 320 and 390 px only. Not Safari, not a physical iPhone, not iOS Dynamic Type.
