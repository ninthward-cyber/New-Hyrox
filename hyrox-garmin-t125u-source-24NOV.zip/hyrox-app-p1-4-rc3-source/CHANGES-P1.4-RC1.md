# P1.4-RC1: integrated candidate of the Combined Value Sprint (CHANGES + QA report)

Grok sprint integrator, 23 Nov 2026 (Asia/Qatar).
- **Branch:** `sprint` (local only). **Not deployed, not pushed, no PR, no Netlify, GitHub or Google Cloud write.**
- **Test data:** synthetic only. No live photo call, no Garmin call, no paid call. `test_food_photo_api_live.py` was NOT run.
- **This is not deploy approval.** Gate 5: Claude must QA this full source before anyone asks the owner for device QA or deploy approval.

| | |
|---|---|
| Base | P1.3-RC3 source `b1de280e2a65` (Claude final commit `b198d30`; baseline commit `aa8d48d`) |
| Release label | `P1.4-RC1` |
| **Source id** | **`f7f66257b5fa`** (sha256 over the 19 DEPLOY-FILES app files, path+NUL+bytes+NUL; first 12 hex) |
| Deploy ZIP | `hyrox-app-p1-4-rc1-deploy.zip`, sha256 `d43492de5f807bb63a69a84056cd207a845ff8263570dcd8eafa6931568d49ff` (built twice from a clean `git archive`; byte-identical) |
| App-file sizes | `src/ui/app-ext.js` 408364 B, `src/ui/style.css` 46015 B (RC3: 381646 / 45241) |

## Commits (each separate and revertible, oldest first)

| Commit | What |
|---|---|
| `229a4b5` | **A** P0 photo + note are one meal (CHANGES-SPRINT-A-PHOTO-NOTE.md) |
| `5e160f9` | **B** P1.2 workout-draft recovery hardening on the existing key; meal-draft persistence HELD (CHANGES-SPRINT-B-DRAFT-RECOVERY.md) |
| `4e53cc4` | **C** settings stubs folded into a closed "Advanced / Future integrations" section (CHANGES-SPRINT-C-SETTINGS-FUTURE.md) |
| `7b4c55b` | **D** P1.4 Export for AI Coaching, Files/share fallback only, no OAuth (CHANGES-SPRINT-D-COACH-EXPORT.md) |
| `646c053` | Release label P1.4-RC1, build folder, README-DEPLOY; label tests re-pointed |
| `6fef3af` | Rollback evidence specs (tests/rollback/p1-4-rc1-*.spec.js; outside the normal suite) |
| (docs) | This file, DEPLOY-P1.4-RC1.md, CLAUDE-QA-BRIEF-P1.4-RC1.md. Docs only; no app or packaged file, so the source id is unchanged. |

Files changed against RC3:
- **App and packaged files:** `index.html`, `src/ai/photo-ai.js` (A), `src/ui/app-ext.js` (A–D), `src/ui/style.css` (rules appended), `netlify/lib/openai.mjs` and `netlify/lib/handler.mjs` (A, photo prompt and request only), and the new `src/data/hyrox-coach-export.js` (D).
- **Byte-identical to RC3:**
  - the data layer `hyrox-data.js`, nutrition, coach, plan, `hyrox-blocks.js` (Block 2 lock), morning, wellness, food data and `stubs.js`
  - `food-photo.mjs`, `config.mjs`, `image.mjs`, `store.mjs`, `netlify.toml`, the package files and `make-owner-code.mjs`

## Mandatory gates
- **Fail-first** (logs): A `A1`/`A2`; B `B1` (10 of 13 fail on 229a4b5); C `C1` (2 of 2 fail on 5e160f9); D `D1` (28 of 28 unit fail) and `D2` (10 of 10 browser fail on 4e53cc4).
- **Regression after every commit:** green after each step, so progression continued. QA-A: unit 1606, Chrome 630+1 skip. QA-B: unit 1606, Chrome 643+1 skip.
- **Final candidate on a clean `git archive` of `6fef3af`** (23 Nov 2026, 17:32–17:52 Asia/Qatar):

| Suite | Result |
|---|---|
| Unit (`node --test tests/*.test.js`) | **1634 / 1634 pass** (`QA-F1`) |
| Python photo adapter, fake model, no network | **8 / 8 pass** (`QA-F2`); live test NOT run |
| Chrome e2e full, 3 workers, retries 0 | **655 passed, 1 skipped, 0 failed** (`QA-F3`) |
| F-1 stress, `--repeat-each 15` | **240 / 240** (`QA-F4`) |
| Sprint specs stress (A, B, C, D specs), `--repeat-each 5` | **205 / 205** (`QA-F5`) |
| Rollback, roll-forward and old-backup round trip (4 older builds) | **38 / 40 pass; the 2 others are not applicable** (`QA-F6`, see below) |
| Older data layers refuse a coaching snapshot as `not_hyrox` | **4 / 4** (`evidence/d-older-restore-refusal.log`) |
| Deploy ZIP reproducible (two builds) | identical sha256 |

All browser results are **Chrome emulation, not Safari and not a physical iPhone.**

### Rollback and old-backup round trip (QA-F6)
Older builds: RC3 `b1de280e2a65`, P1.1-RC2, Claude P11.2, RC1. Each was run from its own copy on its own port.

1. **Candidate writes.** The candidate's own data layer writes synthetic storage: the D seed (sessions, CONFIRMED/DRAFT meals, D5 attestation, body, daily, walks, weight, quick entry), an A photo+note meal with item bases and an acknowledgement, and a B draft envelope. The candidate opens it, offers the draft, and exports a backup that keeps every record.
2. **Each older build** opens that storage without error or damaged banner and keeps every record. It exports its own backup with every record (the A acknowledgement is kept). Its Restore preview and confirm accept the **candidate's backup**. The A, B and P1.3 older-build specs also pass on all 4.
3. **Roll-forward.** The candidate opens what each older build wrote back:
   - every record is kept, and the 766 kcal photo meal is shown once;
   - **Export for AI Coaching** still builds a snapshot from it;
   - the candidate restores **each older build's backup** through its preview;
   - the A and P1.3 roll-forward specs pass.
4. **Not applicable (2).** `p1-1-older-build.spec.js` on RC3 and P1.1-RC2 shows "215 lb" where the spec expects "97.5 kg". That spec seeds its own data with `weightUnit: 'lb'` and is written for pre-P1.1 builds that ignore the unit. RC3 and P1.1-RC2 honour lb, which is correct. It passes on P11.2 and RC1. The candidate's data is not involved.

## Explicit table (Gate 4: no blanket green light from Chrome-only tests)

| Item | Status | Evidence / what is missing |
|---|---|---|
| A photo + note are one meal (every named food listed once with basis; "Not accounted for" gates Confirm) | **Done** (Chrome emulation, fake model) | A specs, P0 stress 80/80 then 205/205 combined; the live model's behaviour is unverified |
| B workout draft: Resume, two-step Discard, Qatar start day, invalid/oversized draft, revision conflict, two-tab guard | **Done** (Chrome emulation) | 13 browser tests; older builds still restore the draft (4/4) |
| B meal-draft persistence across reload | **Deferred (HELD)**: needs a new UI key | Options M1–M4 in CHANGES-SPRINT-B; M1 `hyrox.ui.meal-draft` recommended; owner decision |
| C "Advanced / Future integrations" fold | **Done** | 2 tests at 320/390; screenshots |
| D Export for AI Coaching (read-only JSON, categories, range, review, share or download, honest labels) | **Done** (Chrome emulation; share sheet stubbed) | 28 unit + 10 browser tests; no network; no storage change |
| D direct Google Drive upload (OAuth) | **Deferred** | Handover forbids Google Cloud/OAuth now |
| D iOS share sheet offers "Save to Files"/Drive for the JSON (CE-D-02) | **Needs real iPhone QA** | Emulated only |
| D the ChatGPT Drive connector reads the JSON file (plan Step 0, CE-C-01) | **Needs credentials / owner** | Owner's ChatGPT + Drive |
| A real photo analysis with the owner's key | **Needs credentials + real iPhone QA** | No live/paid calls allowed |
| Garmin Personal API import | **Deferred / needs credentials** | Design only (Drive `14iiakuaLe1Jj7urCVBn_zquY7BbwwPU_`); no code; key never handled |
| Safari/WebKit layout, 16 px inputs, larger text, VoiceOver on the new B/C/D UI | **Needs real iPhone QA** | Chrome emulation only |
| Two-tab behaviour in iOS standalone (Home Screen) mode | **Broken-unknown** | The iOS PWA has one window; the `storage` event path is tested in Chrome only |
| "Share again" button in the D panel after a download fallback (no share sheet) | **Broken-unknown (cosmetic)** | It falls back to a download again; the label could confuse; not fixed in this RC |
| Older-build rollback of A/B/D data | **Done** (Chrome emulation) | QA-F6 |

## Hard limits kept
- **Storage:**
  - localStorage v2 and the key list are unchanged (tests enforce the allowed keys).
  - No migration.
  - My Foods, favourites, units, D5 attestation, coach targets, Garmin manual entries and backup/restore are untouched.
  - F-1 is green (240/240).
- **Block 2:** the lock, dates and content are byte-identical.
- **Server and credentials:**
  - Owner access code, API keys, caps/reserve and same-origin are unchanged: config, image, store and food-photo are byte-identical.
  - A changed only the prompt and request shape.
- **D export:** contains no keys, owner code, AI settings, pre-import backup or draft. Tested with planted SECRETS.
