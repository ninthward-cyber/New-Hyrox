# Deploy Phase 10: exact steps (Windows PowerShell)

Only the owner runs these steps, on their own computer, with their own Netlify login.

**Target:** the existing Phase 9 site **`hyrox-phase7-private-test`**, site ID **`99f0deb7-0526-46f6-b432-9c3bfc2c86d2`**. The Phase 5 site is out of scope; do not touch it.

**Env compatibility: no environment variable is added, renamed or removed.** The Phase 9 variables carry over unchanged, and so do the caps, model and key:
- `OPENAI_API_KEY`
- `HYROX_OWNER_CODE_HASH`
- `HYROX_PHOTO_ENABLED`
- the optional `HYROX_*` variables
- caps: $5 total, $3 a month, 20 a day, 300 a month

Do not edit any secret for this deploy.

**Claude P10 review — model and photo-size rules (no new variable):**
- Every photo, single or in a set, must be at most 1600 px on its longest side (the app sends 1280 px).
- Before every call the server proves the request cannot cost more than `HYROX_RESERVE_USD` (default $0.004). With the default `gpt-6-luna` the largest accepted request is about $0.0025 for one photo and $0.0038 for three.
- Every other model in the price table can cost more than $0.004 per call, so it is refused with a message naming `HYROX_RESERVE_USD`. Keep `HYROX_PHOTO_MODEL` unset (default) unless you also raise the reserve deliberately.

Steps 2–4 assume you are in the folder that holds both zips.

## 1. Fresh backup first (iPhone)
1. Open the app from the **same Home Screen icon** you use every day. Its storage is the one that holds your data.
2. Go to Settings → **Export**. Keep the downloaded `.json` file (Files → Downloads), and copy it somewhere safe (iCloud Drive or a computer).
3. Note today's step total and the last meal on the Today screen, so you can compare after the deploy.

## 2. Check the package (PowerShell)
```powershell
cd $HOME\Downloads
Get-FileHash .\hyrox-app-phase10-deploy.zip -Algorithm SHA256
# must equal the hyrox-app-phase10-deploy.zip line in SHA256SUMS
Expand-Archive .\hyrox-app-phase10-deploy.zip -DestinationPath .\hyrox-p10-deploy -Force
cd .\hyrox-p10-deploy\hyrox-phase10-deploy   # holds netlify.toml, package.json, publish\, netlify\
npm ci
```
`npm ci` uses the included lockfile and installs `@netlify/blobs` 11.1.9 only.

## 3. Confirm the site before deploying
```powershell
npx netlify-cli login
npx netlify-cli sites:list --json | ConvertFrom-Json | Where-Object { $_.id -eq '99f0deb7-0526-46f6-b432-9c3bfc2c86d2' } | Select-Object name, url, id
```
The output **must** show `name` = `hyrox-phase7-private-test`. If it shows anything else, or nothing, stop.

## 4. Draft deploy first, with AI off
```powershell
npx netlify-cli deploy --site 99f0deb7-0526-46f6-b432-9c3bfc2c86d2 --dir publish --functions netlify/functions --message "Phase 10 draft"
```
- There is **no `--prod`**, so this makes a *draft URL* only. Production is untouched.
- The CLI must list the function `food-photo`. Copy the **Website draft URL**.

Check the function (replace `<draft>`):
```powershell
curl.exe -s https://<draft>/api/food-photo/status
# expect: {"configured":true,"status":"OK","authRequired":true,"authorized":false}
curl.exe -s -o NUL -w "%{http_code}`n" -X POST https://<draft>/api/food-photo/analyze -H "Content-Type: application/json" -d "{}"
# expect: 401
```

Then open the draft URL in Safari on the iPhone: a **new tab, not the Home Screen icon**. The draft has its own empty storage, and AI stays **off** there because no owner code is entered. Check:
- Today → **Log steps** → Today, Yesterday and Choose date are all there, and a future date is refused.
- Add → Meal → **Description only** and **Manual** both save.
- Add → Meal → Photo + description: choose 2–3 photos, check that labels and Remove work, and **do not analyse**.
- 320-px layout or large text: no sideways scrolling.
- Optional: Settings → Restore your fresh backup from step 1. It must preview and restore with no errors. Afterwards, clear that Safari tab's data (Settings → Safari → Advanced → Website Data → the draft host → Delete).

## 5. Production deploy (same site, after the draft looks right)
```powershell
npx netlify-cli deploy --prod --site 99f0deb7-0526-46f6-b432-9c3bfc2c86d2 --dir publish --functions netlify/functions --message "Phase 10"
curl.exe -s https://hyrox-phase7-private-test.netlify.app/api/food-photo/status
```
On the iPhone, open the Home Screen icon and pull to refresh, or close and reopen it. Your data must still be there; compare with the notes from step 1.

## 6. Owner-device QA (real iPhone Safari; the Chrome-emulation e2e does not cover it)
1. **Quick steps.**
   - Today → Log steps → Today: type a total → Save. The Steps row shows it.
   - Yesterday: type a total. The rest of yesterday's check-in (sleep, pain, RHR) is unchanged; open Add → Check-in for yesterday to verify.
   - Change it again: it asks for the Replace tick.
   - Blank is refused, `0` saves as 0, and a future date is refused.
2. **Butter chicken check, no network.**
   - Settings → AI provider **Mock** → Mock scenario **Butter chicken**.
   - Photo meal with the note "butter chicken, all chicken eaten, 60% sauce" → Run MOCK TEST.
   - The Review lists chicken 100% and sauce 60% after **Use these eaten amounts**, showing **430 kcal, partial**. A second tap changes nothing.
   - Discard the meal, then switch the provider back to **Live**.
3. **One real photo**, only if you approve the spend (about $0.001). Analyse it and confirm the status counter rises by 1.
4. **Two or three photos in one request**, only if you approve (≤ $0.004).
   - Choose 2–3 photos from the library, including one your iPhone stores as **HEIC**; note whether each one previews.
   - Labels: Before / After / Another dish.
   - Tick consent ("THESE N photos … ONE request") → Analyze N photos.
   - One result list appears, and the status counter rises by **1**, not N.
5. **Stale estimate.** After an estimate:
   - Change a food word in the note: a stale warning appears and Confirm is refused.
   - Change only "60%" to "40%": no warning.
6. **Errors.** In airplane mode, Analyze gives a plain offline message and nothing is saved. Open **Details for the owner** on any error: it shows a category and request id only, with no key, photo or note.
7. **Layout.** At 320 px and with large text: photo strip, review box and Quick steps fit with no sideways scroll. Switch tabs quickly during an analysis: no crash, and no second charge.
8. Settings → **Export** again: the file contains no photo and no code.

## 7. Rollback to Phase 9 (corrected deploy, SHA256 `5bac0b1c328672a2ba0ff07c07a4659c9191eb8d04b2ae4950bd338956971d35`)
**Fastest:** Netlify → site `hyrox-phase7-private-test` → **Deploys** → the last Phase 9 production deploy → **Publish deploy**.

**From the zip:**
```powershell
cd $HOME\Downloads
Get-FileHash .\hyrox-app-phase9-deploy.zip -Algorithm SHA256   # must be 5bac0b1c328672a2ba0ff07c07a4659c9191eb8d04b2ae4950bd338956971d35
Expand-Archive .\hyrox-app-phase9-deploy.zip -DestinationPath .\hyrox-p9-rollback -Force
cd .\hyrox-p9-rollback\hyrox-phase9-deploy
npm ci
npx netlify-cli deploy --prod --site 99f0deb7-0526-46f6-b432-9c3bfc2c86d2 --dir publish --functions netlify/functions --message "Rollback to Phase 9"
```
Use whatever name your Phase 9 corrected deploy zip has; the hash is what matters.

No env change is needed either way. Budget counters in Netlify Blobs are kept.

## 8. Data migration: none
- **No migration runs.** The storage format, backup format and `src/data/*` code are byte-identical to Phase 9.
- Phase 10 adds no new saved fields:
  - Per-item eaten amounts use the existing `eatenFraction`, which dates from Phase 3.
  - Quick steps writes the normal `daily-YYYY-MM-DD` check-in record.
  - Photos are never saved.
- **Downgrade is safe.** A test restores a Phase 10 backup with the Phase 9 data layer: the butter-chicken meal reads 430 kcal and 9000 steps. After a rollback, everything you logged in Phase 10 still shows.
- History and plan dates are not changed.
