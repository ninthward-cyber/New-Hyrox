# HYROX Phase 5 — Claude independent review

Date: 12 Nov 2026 · Reviewer: Claude · For: owner approval
Baseline: Grok `9ba6e34`, `hyrox-app-phase5-restore-safety-source-9ba6e34.zip`, SHA-256 `e6ce51ab…2d3a` (verified, matches the Phase 5 manifest).
Status: **local only.** Nothing pushed, merged or deployed. No real photo, no model call, no spending.

## Recommendation

**READY FOR IPHONE TEST. HOLD on merge and deployment.**

- Grok's three Phase 5 safety changes hold up under independent attack (section 2).
- I found and fixed four defects (section 3), each with a test that fails on `9ba6e34` and passes here.
- Not yet verified: real iPhone Safari, Home Screen, VoiceOver and real storage limits.
- The owner-policy items in section 5 are untouched.

## 1. Reproduced (Grok's figures, re-run independently)

| Suite | Grok reported | Unmodified `9ba6e34`, re-run here | Repaired tree |
|---|---|---|---|
| JavaScript unit tests | 902 / 902 | 902 / 902 | **929 / 929** (27 new) |
| Python adapter | 8 / 8 | 8 / 8 | 8 / 8 |
| Chrome, 390×844 phone emulation | 91 pass, 1 skip | 91 pass, 1 skip | **95 pass, 1 skip** (4 new) |

The browser run was reproduced only after mapping a folder path from Grok's own computer (see 3.4). The final run had no access to such paths. Chrome emulation is not Safari or WebKit.

## 2. Verified (Grok's changes, attacked directly at the data layer)

**Empty-backup second confirmation.**
- Every non-`true` value is refused and nothing is written: `"true"`, `1`, `{}`, `[true]`, `new Boolean(true)`, `null`, missing.
- A getter is read exactly once.
- A backup file cannot inject the flag through `__proto__`.
- The check is re-run against live storage when Replace is pressed, so a device that gained data after the preview is still protected.
- These count as populated: damaged-only storage, settings-only storage, plan-event-only storage.
- An "empty" file padded with unknown fields is still treated as empty.

**Pre-import safety copy.**
- Every storage call of a restore was faulted in turn, with six fault types (read throws, read returns nothing, write throws, write silently dropped, half-written, half-written then throws). A second restore then ran.
- A pairwise sweep put one fault in each of two restores (about 1,000 combinations).
- In every case the original data survived: in live storage, in the recovery key, or in the safety copy. The only exception is a first restore that verifiably completed, which is the HOLD retention policy.
- Whenever a restore is blocked, Settings says so and the emergency raw copy contains the safety copy byte-for-byte.

**Non-restorable export labelling.** Never called "verified" or "restorable" when this build's own restore would refuse it; the raw copy stays offered.

**Old backups.** No negative effect found. Phase 2, Phase 3 and round-2 backups still restore, with the existing tests unchanged. The only new step is the extra tick box when an empty backup would wipe a populated device, as approved.

**Today's date.** The "not after today" restore check and the app both use Qatar time, so entries made between midnight and 03:00 are not wrongly refused.

## 3. Repaired

**3.1 The app could not restore its own backup after about eight months of logging (data safety).**
- *Cause.* The normal backup is indented JSON, about twice the stored size, and restore refused any file over 2,000,000 characters.
- *Synthetic test volume.* 4 meals a day, a daily check-in, a daily walk, 5 sessions a week. At that volume the app's own backup crossed the limit at about 245 days; a year produced a 3.0-million-character file.
- *Phase 5's role.* The new check correctly warned "not restorable", so the underlying limit dates back to Phase 2. Phase 5 only made it visible.
- *Fix.* Limit raised to 10,000,000 characters (`IMPORT_LIMITS.maxBytes`). That covers an indented export of anything Safari's site storage can hold. Oversized files are still refused before parsing.
- *Speed.* A 9.4-million-character file is checked in about 0.2 s here.
- *Tests.* A year-long backup now restores exactly onto an empty device, both in the data layer and through the UI.

**3.2 A non-restorable backup looked like a good one once downloaded.**
- *Problem.* The warning was on screen only; the file had the normal name.
- *Fix.* Such a file is now named `hyrox-backup-YYYY-MM-DD-NOT-RESTORABLE.json` and the warning says so.
- *Unchanged.* The file content, the restore rules and the raw copy. Healthy backups keep the normal name.
- This is labelling only, consistent with the "warn, do not repair" recommendation; it decides nothing on owner question 3.

**3.3 The app slowed to about 15 seconds to open, and about 14 seconds per save, with a year of data (iPhone usability).**
- *Cause.* To label each day in History and Trends, the screens re-read and re-validated the entire stored database twice per day shown.
- *Fix.* Within one screen update, each list is now read once. The cache is cleared at the end of the update, at every refresh, and right after every save or delete, so it can never show stale data.
- *Result here.* With a year of data: opening the app 0.6 s, saving 0.45 s, against about 14.5 s and 13.8 s on `9ba6e34`.
- No rendering logic changed. The defect predates Phase 5; it would not show in synthetic iPhone testing, but would in months of real use.

**3.4 Ten test files only worked on Grok's computer.**
- Five browser specs loaded Playwright from `/workspace/hyrox-p2/...`.
- Five files saved screenshots or logs under `/workspace/hyrox-p3|p4|p5/...`; on a Mac these fail for lack of permission.
- Both now use the standard module and the repo's own ignored `tests/out/` folder; environment-variable overrides still work.
- No assertion changed.

### Existing tests edited (exactly)

These six assertions hard-coded the old 2,000,000 limit:
- `hyrox-data.test.js` — the pinned constant (now 10,000,000); "2.1 MB file" (now limit + 100,000); "size limit checked before parsing" and "accepts exactly maxBytes" (now use the constant).
- `p5-dawit-restore-safety.test.js` — the too_large case (now limit + 100,000).
- `p4-dawit-recursive-marker-scan.test.js` — the near-limit timing test, kept at its original 2-million scale because padding to 10 million would break the 300-character notes rule. A new near-limit test covers 10 million.

### One correction to Grok's handover

Grok says a false block needs the finish-marker write *and* its repair to fail. In fact one failed marker write is enough (6 of 72 single faults in my sweep):
- The restore succeeds and reports success.
- The next restore is refused with "an earlier restore did not finish", which is wrong.
- There is no in-app way out (that exit is on HOLD).

No data is lost and the raw copy holds everything. It is documented by a test, not changed.

## 4. Known issues (not fixed here)

- **Real iPhone not tested.** Safari, Home Screen, VoiceOver, tick-box rendering, zoom and real storage quota.
- **Storage quota during a restore.** A restore over existing data needs room for the old copy and the new data at once. With several months of data, that may exceed Safari's per-site storage (thought to be about 5 MB; unverified on the device). If so, the restore stops safely with "backup_failed" and nothing changes. Restoring onto an empty or new device is unaffected.
- **Back-to-back restores.** "Wrong file, then right file" still loses the pre-restore data after a completed restore (HOLD).
- **Settings-only backups.** A backup holding only settings is not "empty" under the approved rule, so it needs only the normal Replace confirmation. Listed by Grok; it is a policy limit, not a defect.
- **Phone-height layout.** At 320×568 the empty-backup warning is taller than the screen, so the tab bar covers its bottom until you scroll. Observed by Grok.
- **Deploy hygiene.** No deployable package has been built. `DEPLOY-FILES.txt` lists the app files; `ai-test-backend/`, `tests/` and `test-results/` (including the earlier real-AI evidence) must never be served.

## 5. Owner-policy items — not decided here

The empty-backup, safety-copy and export questions (completed-restore retention, counting damaged storage as populated, block / warn / repair for non-restorable exports) are unchanged and on HOLD, along with: 17/20, both Monday and Wednesday missed, after 6 Dec, DF vs D1–D5, legacy photo meals, fractional-step restore migration, in-app raw restore, week-4 gate, "demanding", step percentages, missing pain. `PAIN_INVALID` behaviour is unchanged.

The 10-million limit (3.1) is an engineering limit, not a product rule, but it is isolated in its own commit if you would rather decide it yourself.

## 6. How to check

From the extracted `hyrox-app` folder:

```
node --test tests/*.test.js
python -m pytest -q ai-test-backend/test_food_photo_adapter.py
NODE_PATH=<folder with @playwright/test 1.49.1>/node_modules HYROX_CHROME=<path to Chrome> \
  npx playwright test -c tests/playwright.local-chrome.config.js
```

Rebuild from Grok's ZIP: extract `9ba6e34`, `git init`, `git apply --binary claude-p5-review-vs-grok-9ba6e34.patch`. The four fixes are also supplied as separate patches, so any one can be left out.

Extra iPhone checks for this round, beyond Grok's list:
1. Export on clean data. The file is named `hyrox-backup-<date>.json`, without NOT-RESTORABLE.
2. In Files, confirm the backup is saved and opens as text.
3. Delete the app's data (or use a second browser profile), then restore that file. All entries return.
