# HYROX Phase 6 — Claude independent review

Date: 13 Nov 2026 · Reviewer: Claude · For: owner approval
Baseline: Grok `fd37069`, `hyrox-app-phase6-nutrition-source-fd37069.zip`, SHA-256 `d5a1234e…712d` (verified, matches `SHA256SUMS-phase6.txt`). Phase 5 source `58794555…8d43` also verified.
Status: **local only.** Nothing pushed, merged or deployed. No Netlify, no USDA API call, no AI call, no spending.

## Recommendation

**READY FOR IPHONE TEST. HOLD on merge and deployment.**

- Grok's data-loss mitigations, readiness links and backup locks hold up under review (section 2).
- I found and fixed two defects in the nutrition estimate (section 3). Each has tests that fail on `fd37069` and pass here.
- Root cause of the missing data is still **unconfirmed**. I agree with Grok's ranking (section 4).
- Not verified: real iPhone Safari, Home Screen, a real Netlify script-load failure, and what is currently live behind Netlify login.

## 1. Reproduced (Grok's figures, re-run independently)

| Suite | Grok reported | `fd37069` re-run here | Repaired tree |
|---|---|---|---|
| JavaScript unit | 1172/1172, 0 skipped | 1170 pass, **2 skipped**, 0 fail | **1186 pass**, 2 skipped, 0 fail |
| Python adapter (not live) | 8/8 | 8/8 | 8/8 |
| Chrome emulation e2e | 200 pass, 1 skip | 200 pass, 1 skip | **206 pass**, 1 skip |

The 2 skips are the USDA rebuild-reproducibility tests. They need the raw USDA zips, which are not in the source ZIP, and this workspace cannot download them (fdc.nal.usda.gov is blocked here). Grok's machine had the zips. The 1 e2e skip is the existing 320-only zoom test. Browser results are Chrome emulation, **not Safari/WebKit**.

## 2. Verified, no change

- **Backup and restore.** `hyrox-data.js` changes only by +21 additive lines in `status()`. `keyPresent`/`counts` read the already-loaded state, never write, and are wrapped in try/catch. Meron's 17 Phase 4/5 lock tests pass.
- **Load guard.** It checks every required script, including `hyrox-foodcalc.js`, and uses `textContent` only. **Deploy check:** the deployed package `HYROX_Phase5_Private_iPhone_Static_Only.zip` is byte-identical, file by file, to the audited Phase 5 source (10/10 files). It has no `_headers`, `netlify.toml` or Content-Security-Policy, so the inline load-guard script will not be blocked. I could not check what is actually live (Netlify login).
- **Storage banner and Settings check.** These are read-only, never restore, and show the host and Home Screen vs tab.
- **Readiness tile.** Labels come from the live `missing`/`invalid` lists, and each link targets an existing check-in field. No thresholds changed.
- **Food database (independent check, not a rebuild).** 8,167 foods with no duplicate keys, no missing or impossible values, and no portion rows ≤ 0. Energy was compared with 4/4/9 kcal per gram for every food: all outliers are explained (alcohol, fibre, sweeteners, leavening, citrus acids) except one, *Chicken spread* (SR 173858). Its 158 kcal does not fit its macros (≈ 246). That is USDA's figure as built; I could not check it from here, and the food is not in the alias table.
- **Injection.** Typed text and USDA descriptions are always set with `textContent`, never HTML.

## 3. Repaired

**3.1 A text match chose foods the owner did not mean, with numbers (nutrition accuracy).**
- *Cause.* Outside the alias table, a food was chosen by itself when exactly one USDA food contained every typed word. Ordinary extra words often leave exactly one, odd, food.
- *Examples on `fd37069`* (shown as "Estimate", applied with one tap):
  - "1 bowl rice" → frozen chicken rice bowl entree, 340 g, 428 kcal
  - "100g cup of milk" → powdered dessert topping
  - "1 baked egg" → egg custard dessert, 563 g, 586 kcal
  - "1 mozzarella sandwich" → Hot Pockets
  - "1 baked cheddar" → one Goldfish cracker, 0.52 g
- *Sweep.* Every alias food combined with 40 everyday words gives 15,840 phrases. On `fd37069`, 139 of them chose a different food; here, 0 choose a food outside the alias table.
- *Fix.* A text match is chosen by itself only when the USDA description has no words beyond the typed ones (for example "1 cup cooked millet" → "Millet, cooked"). Otherwise the food is offered first and the owner picks it: one tap, same numbers. Alias foods (about 130, such as eggs, rice, milk and chicken breast) are unchanged.
- *Owner rule served:* "no photo required … never guess". This makes the rule stricter; it adds no new rule.

**3.2 Confirmed numbers could differ from the estimate on screen (counting integrity).**
- *Case A.* Apply "2 eggs", then change the quantity to 3: the screen shows 215 kcal, but Confirm saved **143 kcal** (reproduced on `fd37069`).
- *Case B.* Confirm with an estimate showing but not applied: the refusal said only "every component needs a name". When editing an older meal, its old components would be confirmed under a different estimate.
- *Fix.* Draft, intent and Confirm all refuse to save while the estimate on screen is not in the meal, and say what to do. Any edit after applying makes the estimate stale again. A new **Clear estimate** button (≥ 44 px) lets the owner drop an unwanted estimate and enter values by hand. A status note says when the estimate has been added. Wording is now correct when only one food is offered.

### Existing tests edited (exactly)

- `tests/p6-dawit-foodcalc.test.js` — "an unambiguous strong text match … is matched": "100 g duck egg" (USDA "Egg, duck, whole, fresh, raw") is now ambiguous, with duck egg first. Picking it gives the same exact numbers, which the test still asserts. "1 cup cooked millet" still matches, unchanged.
- `tests/p6-dawit-foodcalc-and.test.js` — "the whole phrase is checked before splitting … (ambiguous with no nutrients here)": the assertion now matches its own title (ambiguous, rice-and-beans food first, no nutrients). The split check now reads `candidates[0]` instead of `chosen`.

No other assertion changed. New: `tests/p6-claude-review.test.js` (16 tests; 13 fail on `fd37069`, 3 are alias guards) and `tests/e2e/p6-claude-review.spec.js` (6; all fail on `fd37069`).

## 4. Data disappearance — assessment

I agree with Grok: **root cause unconfirmed**. Nothing in the code deletes `hyrox.v1`, and the deployed files match the audited source. The most likely cause is still a different storage context (RC-1): a different address (for example a deploy-specific Netlify URL after the login redirect), Safari tab vs Home Screen icon, a Private tab, or a re-added icon.

To pin it down, the owner needs to supply three things:
1. The exact address where the first meal was logged.
2. Whether the app was opened from the Home Screen, a Safari tab or a Private tab.
3. Whether the tab bar still worked while History was blank.

Suggestion: open the app from that original context. The new banner and the Settings check will show whether data exists there. If it does, export a backup first.

## 5. Owner decisions — not decided here

1. **Validate `components[].provenance` in backups?** *Proposed:* yes. Check that it is an object with known string/number fields and cap the string lengths (for example description ≤ 200). *Compatibility:* every provenance this build writes passes. *Size:* about 228 characters per estimated component, roughly +1 million stored characters a year at 4 meals × 3 items. Phase 5 measured a year of normal logging at about 1.5 million. That is not a blocker (an overflow shows "Could not save" and loses nothing), but it brings Safari's per-site storage limit closer.
2. **Negative USDA carbohydrate clamped to 0** (10 Foundation rows) — keep.
3. **Root cause** — needs the three facts above.
4. All earlier HOLD items are unchanged.

## 6. Not fixed (recommendations, no wrong numbers)

- A trailing amount is not read ("chicken 200g", "greek yogurt 200g"). The owner sees "choose / no match" and no numbers. Typing "200g chicken" works.
- "1 tsp honey" asks for grams although "1 tbsp honey" and "5 ml honey" work.
- "1 can tuna" and "1 can coke" give no match ("can" is not read as a unit).

## 7. How to check

```
node --test tests/*.test.js
python -m pytest -q ai-test-backend/test_food_photo_adapter.py
NODE_PATH=<folder with @playwright/test 1.49.1>/node_modules HYROX_CHROME=<Chrome> \
  npx playwright test -c tests/playwright.local-chrome.config.js
```

Rebuild from Grok's ZIP: extract `fd37069`, then `git apply --binary claude-p6-review-vs-grok-fd37069.patch`.

Extra iPhone checks this round:
1. Type "1 bowl rice". It asks you to choose, and shows no kcal until you do.
2. Type "2 eggs", press Use these estimates, change 2 → 3, then Confirm. It refuses; press Use again, then Confirm counts 215 kcal.
3. Open the app from the Home Screen and from a Safari tab. Settings → "Where is my data stored?" shows which one holds your records.
