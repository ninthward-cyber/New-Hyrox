# P1.3-RC2: deploy and rollback (owner only, after the owner's explicit go-ahead)

**This package is not deploy approval and not approval of Block 2 training content.** Nobody but the owner deploys.
P1.3-RC2 = Grok's P1.3-RC1 plus the independent review's fixes (CHANGES-P1.3-RC2.md). P1.3-RC1 itself should not be deployed.
- Which build is live on your iPhone is **unknown / not confirmed** — find out in A before anything else. Nothing here assumes
  that P1.1-RC1 or P1.1-RC2 was ever published.
- Site: `hyrox-phase7-private-test` (ID `99f0deb7-0526-46f6-b432-9c3bfc2c86d2`, origin https://hyrox-phase7-private-test.netlify.app).
  Same origin as before, so saved data stays. Never deploy to another origin to "test with real data"; never clear site data.
- Zip: `hyrox-app-p1-3-rc2-deploy.zip`; its SHA256, every file's SHA256 and the **source id** are in `SHA256SUMS-p1-3-rc2.txt`.
- No env change, no migration, data version 2, no new storage key. 18 static app files (one new: `src/data/hyrox-coach.js`).
- **Timing:** Block 2 benchmark 11 Dec, first start Mon 14 Dec. Do not deploy in that week.

## A. Read-only: confirm what is live now
Settings → About this build on the Home Screen icon. If it shows a source id, compare it with this table; otherwise use
Netlify → site → Deploys → Published deploy → file browser sizes:
| Source id | `src/ui/app-ext.js` | `src/ui/style.css` | Live build |
|---|---|---|---|
| `d0d7d8ab86a1` | 378757 | 44680 | P1.3-RC1 (Grok; never approved for release) |
| `3079cb300d1f` | 331044 | 42553 | P1.1-RC2 |
| `6c43fa133f2b` | 329333 | 42553 | P1.1-RC1 |
| shown | 308980 | 42553 | P0-RC3 |
| none | 303150 | 42154 | RC2 |
| none | 302942 | 42154 | RC1 |
| none | 258287 | 41683 | Claude P11.2 |
| none | 223896 | 39561 | Claude P11 |
| anything else | | | stop and report |
Write down the published deploy ID: it is the fastest rollback target.

## B. Backup first (mandatory)
iPhone → the **Home Screen icon** → Settings → **Export JSON backup**. Keep the file and check it is in Files.

## C. Deploy
```powershell
cd $HOME\Downloads
Get-FileHash .\hyrox-app-p1-3-rc2-deploy.zip -Algorithm SHA256   # must equal its line in SHA256SUMS-p1-3-rc2.txt, otherwise STOP
Expand-Archive .\hyrox-app-p1-3-rc2-deploy.zip -DestinationPath .\hyrox-p1-3-rc2 -Force
cd .\hyrox-p1-3-rc2\hyrox-p1-3-rc2-deploy
npm ci
npx netlify-cli login
npx netlify-cli sites:list --json | ConvertFrom-Json | Where-Object { $_.id -eq '99f0deb7-0526-46f6-b432-9c3bfc2c86d2' } | Select-Object name, url, id
# must show hyrox-phase7-private-test, otherwise STOP
npx netlify-cli deploy --site 99f0deb7-0526-46f6-b432-9c3bfc2c86d2 --dir publish --functions netlify/functions --message "P1.3-RC2 draft"
```
Draft URL (new Safari tab, not the icon): synthetic data only, quick look, then clear that tab's website data. Then, only
with your explicit go-ahead, production:
`npx netlify-cli deploy --prod --site 99f0deb7-0526-46f6-b432-9c3bfc2c86d2 --dir publish --functions netlify/functions --message "P1.3-RC2"`.

## D. Smoke test on the Home Screen icon (real iPhone; all browser tests ran in Chrome emulation, not Safari)
1. **Backup and origin:** B done; the address is still `hyrox-phase7-private-test.netlify.app` (same origin as before).
2. **Build label:** Settings → About this build shows `Build P1.3-RC2 · source <id> · …`; the id equals SHA256SUMS-p1-3-rc2.txt.
3. **Data intact:** recent meals, weights (kg/lb as you set), check-ins, workouts and the plan are as before.
4. **Home closeout:** under Nutrition, "All food & drink entered" / "Day is incomplete" for today. Press one → saved and shown;
   pressing the same one again saves nothing new. History still shows per-date controls.
5. **Coach off:** no coach line on Home, no coach card in Trends; reference 2,400 kcal / protein 190 g (protein floor 170 g).
6. **Profile:** Settings → Nutrition Coach → profile → Save; leave and return, then close and reopen the app: still there.
7. **Target Cancel/Confirm:** own target 2,200 → Review → **Cancel** (nothing changes) → Review → **Confirm** ("In use today").
8. **Safeguard:** own target 1,000 → Review → the box "below the provisional floor" appears; **Confirm without the tick
   is refused**; then Cancel. (Do not keep a test target you do not want: confirm your real one afterwards.)
9. **Coach on:** Home shows one status line (colour + icon + words, readable in daylight and with larger text). Trends →
   "Weekly review (coach)" says **Monday–Sunday** and names last Monday–Sunday; sessions you did not log show as
   "not logged (unknown)", not skipped.
10. **Full day:** on a day where you entered everything, press "All food & drink entered" → the day is complete (D5).
11. **After midnight:** leave the app open past midnight (Asia/Qatar), then press a closeout button → it refuses and shows the
    new day. Nothing is saved for the wrong day.
12. **F-1:** Add foods → `banana`, tap the result at once, Quantity 3 → Add → Confirm → 3 × in the diary.
13. **Restore preview:** Export JSON backup → Restore → pick it → preview appears (with a coach line if relevant) → Cancel.
14. Close from the app switcher, reopen from the icon: everything above is still there.

## E. Rollback (no env change, no migration)
Export a backup first. Fastest: Netlify → Deploys → the deploy ID from A → Publish deploy. From a zip (check the hash; same
`npm ci` + `deploy --prod` as in C):
| Order | Target | SHA256 |
|---|---|---|
| 1 | P1.1-RC2 `hyrox-app-p1-1-rc2-deploy.zip` (coach and closeout disappear; their data stays stored) | `56f7a2c12c998d0c48ce9632764cf77454bd89e56ffab6f5f3411d60ccb2e143` |
| 2 | P1.1-RC1 `hyrox-app-p1-1-rc1-deploy.zip` (F-1 present again) | `661aa5b546a72c2e3c9cf54d146da1ac1d00df5280e0e0788b0f3a532833a14c` |
| 3 | P0-RC3 `hyrox-app-p0-rc3-deploy.zip` | `34251d47a6978d80ddac6f4fa157399c8163f083816ea02002e5822fee1593cb` |
| 4 | RC2 `hyrox-app-rc2-deploy.zip` | `3662afd4c1a059a9a2935d6152d6620c44bf23c38cb4032a1361a3ee1d5153cb` |
| 5 | RC1 `hyrox-app-rc1-deploy.zip` | `129583156454de49c3acbf5e2a4d7bae08124ac1862c982f6c6e7b646f409d7c` |
| 6 | Claude P11.2 `hyrox-app-phase11-2-deploy-claude.zip` | `c85d82479e02a6e20a585ac9b9a9418b4ba736792cc98136e011f403b1b85e61` |
What an older build does with P1.3 data (tested in Chrome emulation with P1.1-RC2, RC1 and Claude P11.2 app copies; re-run
for P1.3-RC2 in the independent review):
the coach field, My Foods, favourites and the lb preference stay stored, survive that build's own settings save and its
backup export; roll forward again and P1.3 shows the same confirmed target. The older build does not show the coach.
Do not use "Replace the saved settings" (damaged-settings repair) on P11.2 or older: it keeps only the fields that build
knows and would drop the coach (existing caution, DEPLOY-RC2.md section E). Those cautions and DEPLOY-P0-RC3.md section E
still apply.
Rolling back to P1.3-RC1 is not recommended (it has the defects fixed in P1.3-RC2); if it is ever live, the stored data is
the same shape and P1.3-RC2 reads it unchanged.
