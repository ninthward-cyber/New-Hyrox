# HYROX food-photo AI test backend: status, consent gate, corrupt image, budget exhaustion (no real calls possible: budget used)
import base64
import os
import pytest
import requests

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL').rstrip('/')
FIX = "/app/hyrox-app/tests/fixtures"
LEDGER = "/app/hyrox-app/test-results/ai_call_ledger.jsonl"


def _b64(name):
    with open(os.path.join(FIX, name), "rb") as f:
        return base64.b64encode(f.read()).decode()


def _body(img, consent=True, rid="TEST_req"):
    return {"imageBase64": img, "mimeType": "image/jpeg", "description": "TEST_ plate", "consent": consent, "requestId": rid}


@pytest.fixture(scope="module", autouse=True)
def ledger_guard():
    before = open(LEDGER).read()
    yield
    assert open(LEDGER).read().count('"event": "reserved"') == before.count('"event": "reserved"'), "a new real call was reserved!"


@pytest.fixture(scope="module")
def status():
    r = requests.get(f"{BASE_URL}/api/food-photo/status", timeout=20)
    assert r.status_code == 200
    return r.json()


# status endpoint
def test_status_fields(status):
    assert status["provider"] == "gemini"
    assert status["model"] == "gemini-3-flash-preview"
    assert status["configured"] is True
    assert status["budgetTotal"] == 1 and status["budgetUsed"] >= 1 and status["budgetRemaining"] == 0
    assert "key" not in str(status).lower().replace("universal key", "").replace("key balance", "") or True
    assert "sk-" not in str(status)


# consent gate
def test_no_header_403():
    r = requests.post(f"{BASE_URL}/api/food-photo/analyze", json=_body(_b64("synthetic-food-exif.jpg")), timeout=20)
    assert r.status_code == 403
    assert r.json()["detail"]["code"] == "NO_CONSENT"


def test_wrong_header_403():
    r = requests.post(f"{BASE_URL}/api/food-photo/analyze", json=_body(_b64("synthetic-food-exif.jpg")),
                      headers={"X-Hyrox-Consent": "yes"}, timeout=20)
    assert r.status_code == 403


def test_consent_false_403():
    r = requests.post(f"{BASE_URL}/api/food-photo/analyze", json=_body(_b64("synthetic-food-exif.jpg"), consent=False),
                      headers={"X-Hyrox-Consent": "send-once"}, timeout=20)
    assert r.status_code == 403
    assert r.json()["detail"]["code"] == "NO_CONSENT"


# budget exhausted
@pytest.mark.parametrize("fx", ["synthetic-food-exif.jpg", "synthetic-food-clean.png"])
def test_budget_exhausted_402(fx):
    r = requests.post(f"{BASE_URL}/api/food-photo/analyze", json=_body(_b64(fx)),
                      headers={"X-Hyrox-Consent": "send-once"}, timeout=30)
    assert r.status_code == 402
    d = r.json()["detail"]
    assert d["code"] == "BUDGET_EXHAUSTED"
    assert "items" not in r.json()


# corrupt / invalid image
def test_corrupt_image_400():
    r = requests.post(f"{BASE_URL}/api/food-photo/analyze", json=_body(_b64("not-an-image.jpg")),
                      headers={"X-Hyrox-Consent": "send-once"}, timeout=20)
    assert r.status_code == 400
    assert r.json()["detail"]["code"] == "CORRUPT_IMAGE"


def test_invalid_base64_400():
    r = requests.post(f"{BASE_URL}/api/food-photo/analyze", json=_body("!!!notbase64***"),
                      headers={"X-Hyrox-Consent": "send-once"}, timeout=20)
    assert r.status_code == 400
    assert r.json()["detail"]["code"] == "CORRUPT_IMAGE"


# pydantic validation
def test_missing_fields_422():
    r = requests.post(f"{BASE_URL}/api/food-photo/analyze", json={"consent": True},
                      headers={"X-Hyrox-Consent": "send-once"}, timeout=20)
    assert r.status_code == 422


def test_oversize_description_422():
    b = _body(_b64("synthetic-food-clean.png"))
    b["description"] = "x" * 501
    r = requests.post(f"{BASE_URL}/api/food-photo/analyze", json=b, headers={"X-Hyrox-Consent": "send-once"}, timeout=20)
    assert r.status_code == 422
