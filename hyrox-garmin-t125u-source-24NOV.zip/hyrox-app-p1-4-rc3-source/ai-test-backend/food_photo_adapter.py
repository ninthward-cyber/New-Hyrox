"""Isolated local TEST backend for HYROX food-photo analysis. Not for deployment.

- Holds the model key server-side (never sent to the browser).
- Fails closed: disabled flag, missing key, exhausted call budget or missing consent => no model call.
- Re-encodes the image with Pillow so no EXIF/GPS/XMP reaches the provider.
- Writes a redacted ledger (no image bytes, no key) of every real call.
"""
import asyncio
import base64
import hashlib
import io
import json
import os
import re
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

from fastapi import APIRouter, Header, HTTPException
from PIL import Image
from pydantic import BaseModel, Field

router = APIRouter(prefix="/api/food-photo")
_budget_lock = asyncio.Lock()

MAX_B64_CHARS = 2_200_000
MAX_SIDE = 1280
ITEM_KEYS = {"name", "preparation", "portion", "eatenFraction", "kcal", "proteinG", "carbsG", "fatG", "confidence", "uncertainty", "role"}
ROLES = {"MAIN", "SIDE", "OIL", "SAUCE", "DRINK", "CONDIMENT", "OTHER"}
MAX = {"kcal": 5000, "proteinG": 400, "carbsG": 800, "fatG": 400}
BAD_TEXT = re.compile(r"[<>]|javascript:|[\x00-\x08\x0b\x0c\x0e-\x1f]", re.I)

SYSTEM_PROMPT = (
    "You estimate food in a photo for a personal nutrition log. Respond with ONLY a JSON object, no prose, no code fences. "
    'Schema: {"items":[{"name":str,"role":"MAIN|SIDE|OIL|SAUCE|DRINK|CONDIMENT|OTHER","preparation":str,'
    '"portion":str (household terms e.g. "about one cup"),"eatenFraction":number 0-1 or null,'
    '"kcal":number or null,"proteinG":number or null,"carbsG":number or null,"fatG":number or null,'
    '"confidence":"LOW|MEDIUM|HIGH","uncertainty":str}],"warnings":[str]}. '
    "Use null (never 0) for anything you cannot estimate. Hidden oils, sauces and dressings are usually not knowable: "
    "list them as separate items with null macros and say so in warnings. Never claim precision. "
    "If the image does not show food, return an empty items list and a warning. Do not describe people, places, screens or text in the image."
)


def _cfg():
    return {
        "enabled": os.environ.get("AI_PHOTO_ENABLED", "false").lower() == "true",
        "budget": int(os.environ.get("AI_REAL_CALL_BUDGET", "0")),
        "ledger": Path(os.environ["AI_CALL_LEDGER_PATH"]) if os.environ.get("AI_CALL_LEDGER_PATH") else None,
        "provider": os.environ.get("AI_PHOTO_MODEL_PROVIDER", ""),
        "model": os.environ.get("AI_PHOTO_MODEL", ""),
        "key": os.environ.get("EMERGENT_LLM_KEY", ""),
    }


def _used(ledger) -> int:
    if ledger is None:
        return 10**9  # no ledger configured => treat budget as exhausted (fail closed)
    if not ledger.exists():
        return 0
    return sum(1 for line in ledger.read_text().splitlines() if '"event": "reserved"' in line)


def _ledger(ledger: Path, rec: dict) -> None:
    ledger.parent.mkdir(parents=True, exist_ok=True)
    with ledger.open("a") as f:
        f.write(json.dumps(rec) + "\n")


def _fail(status: int, code: str, message: str):
    raise HTTPException(status_code=status, detail={"code": code, "message": message})


def sanitize_image(b64: str) -> tuple[bytes, int, int]:
    """Decode, verify, drop all metadata by re-encoding pixels only. Returns JPEG bytes."""
    try:
        raw = base64.b64decode(b64, validate=True)
        img = Image.open(io.BytesIO(raw))
        img.verify()
        img = Image.open(io.BytesIO(raw))
        if img.format not in {"JPEG", "PNG", "WEBP"}:
            _fail(400, "UNSUPPORTED_TYPE", "Only JPEG, PNG or WebP images are accepted.")
        img = img.convert("RGB")
    except HTTPException:
        raise
    except Exception:
        _fail(400, "CORRUPT_IMAGE", "The image could not be decoded.")
    img.thumbnail((MAX_SIDE, MAX_SIDE))
    clean = Image.new("RGB", img.size)
    clean.paste(img)
    out = io.BytesIO()
    clean.save(out, format="JPEG", quality=85)
    return out.getvalue(), clean.width, clean.height


def _num_ok(v, mx):
    return v is None or (isinstance(v, (int, float)) and not isinstance(v, bool) and 0 <= v <= mx)


def validate_model_json(obj, provider: str, model: str) -> dict:
    """Strict schema check on model output. Raises ValueError on anything unexpected."""
    if not isinstance(obj, dict) or set(obj) - {"items", "warnings"}:
        raise ValueError("unexpected top-level shape")
    items, warnings = obj.get("items"), obj.get("warnings", [])
    if not isinstance(items, list) or len(items) > 20 or not isinstance(warnings, list):
        raise ValueError("items/warnings invalid")
    for w in warnings:
        if not isinstance(w, str) or len(w) > 300 or BAD_TEXT.search(w):
            raise ValueError("unsafe warning text")
    for it in items:
        if not isinstance(it, dict) or set(it) - ITEM_KEYS:
            raise ValueError("unexpected item fields")
        if not isinstance(it.get("name"), str) or not it["name"].strip() or len(it["name"]) > 80 or BAD_TEXT.search(it["name"]):
            raise ValueError("bad name")
        for k in ("preparation", "portion", "uncertainty"):
            if it.get(k) is not None and (not isinstance(it[k], str) or len(it[k]) > 200 or BAD_TEXT.search(it[k])):
                raise ValueError("bad " + k)
        if it.get("role") is not None and it["role"] not in ROLES:
            raise ValueError("bad role")
        if not _num_ok(it.get("eatenFraction"), 1):
            raise ValueError("bad eatenFraction")
        for k, mx in MAX.items():
            it.setdefault(k, None)
            if not _num_ok(it[k], mx):
                raise ValueError("bad " + k)
        if it.get("confidence") not in {"LOW", "MEDIUM", "HIGH"}:
            raise ValueError("bad confidence")
        vals = [it["kcal"], it["proteinG"], it["carbsG"], it["fatG"]]
        if all(isinstance(v, (int, float)) for v in vals):
            implied = it["proteinG"] * 4 + it["carbsG"] * 4 + it["fatG"] * 9
            if implied > it["kcal"] * 1.6 + 50 or implied < it["kcal"] * 0.4 - 50:
                raise ValueError("inconsistent macros")
    return {"schemaVersion": 1, "provider": provider, "model": model, "items": items,
            "warnings": warnings + ["Real model estimate — approximate, not a measurement. Review every value."]}


def parse_model_text(text: str) -> dict:
    t = text.strip()
    t = re.sub(r"^```(?:json)?\s*|\s*```$", "", t)
    start, end = t.find("{"), t.rfind("}")
    if start < 0 or end < start:
        raise ValueError("no JSON object")
    return json.loads(t[start:end + 1])


async def call_model(cfg: dict, jpeg: bytes, description: str) -> str:
    from emergentintegrations.llm.chat import LlmChat, UserMessage, ImageContent, TextDelta, StreamDone
    chat = LlmChat(api_key=cfg["key"], session_id="hyrox-photo-" + uuid.uuid4().hex, system_message=SYSTEM_PROMPT)
    chat.with_model(cfg["provider"], cfg["model"])
    text = "Estimate the food in this photo."
    if description:
        text += " The user says: " + description[:500]
    msg = UserMessage(text=text, file_contents=[ImageContent(image_base64=base64.b64encode(jpeg).decode())])
    parts = []
    async for ev in chat.stream_message(msg):
        if isinstance(ev, TextDelta):
            parts.append(ev.content)
        elif isinstance(ev, StreamDone):
            break
    return "".join(parts)


class AnalyzeIn(BaseModel):
    imageBase64: str = Field(max_length=MAX_B64_CHARS)
    mimeType: str
    description: str = Field(default="", max_length=500)
    consent: bool
    requestId: str = Field(max_length=64)


@router.get("/status")
async def status():
    c = _cfg()
    used = _used(c["ledger"])
    configured = c["enabled"] and bool(c["key"]) and bool(c["model"]) and c["ledger"] is not None
    return {"mode": "REAL", "configured": configured, "enabled": c["enabled"], "provider": c["provider"], "model": c["model"],
            "budgetTotal": c["budget"], "budgetUsed": used, "budgetRemaining": max(0, c["budget"] - used),
            "terms": "Isolated local test backend. Sanitized image is sent to " + (c["provider"] or "no provider") + " / " +
                     (c["model"] or "no model") + " via the Emergent universal key (billed to the owner's existing key balance). "
                     "The backend keeps only a redacted ledger (no image, no key). Provider-side retention is governed by the provider's API terms."}


@router.post("/analyze")
async def analyze(body: AnalyzeIn, x_hyrox_consent: str = Header(default="")):
    c = _cfg()
    if x_hyrox_consent != "send-once" or body.consent is not True:
        _fail(403, "NO_CONSENT", "Nothing was sent: per-request consent missing.")
    if not c["enabled"] or not c["key"] or not c["model"] or c["ledger"] is None:
        _fail(503, "NOT_CONFIGURED", "Real photo analysis is not configured on this test backend.")
    jpeg, w, h = await asyncio.to_thread(sanitize_image, body.imageBase64)
    async with _budget_lock:
        if _used(c["ledger"]) >= c["budget"]:
            _fail(402, "BUDGET_EXHAUSTED", "The approved real-call budget is used up. Nothing was sent.")
        _ledger(c["ledger"], {"event": "reserved", "at": datetime.now(timezone.utc).isoformat(), "requestId": body.requestId,
                              "imageSha256": hashlib.sha256(jpeg).hexdigest(), "sanitizedBytes": len(jpeg), "width": w, "height": h,
                              "descriptionChars": len(body.description), "provider": c["provider"], "model": c["model"]})
    t0 = time.time()
    try:
        text = await asyncio.wait_for(call_model(c, jpeg, body.description), timeout=40)
    except asyncio.TimeoutError:
        _ledger(c["ledger"], {"event": "timeout", "requestId": body.requestId})
        _fail(504, "TIMEOUT", "The model did not answer in time.")
    except Exception as exc:
        _ledger(c["ledger"], {"event": "provider_error", "requestId": body.requestId, "error": type(exc).__name__})
        _fail(502, "PROVIDER_ERROR", "The model call failed.")
    latency = int((time.time() - t0) * 1000)
    try:
        result = validate_model_json(parse_model_text(text), c["provider"], c["model"])
    except Exception as exc:
        _ledger(c["ledger"], {"event": "invalid_response", "requestId": body.requestId, "latencyMs": latency,
                              "error": str(exc)[:200], "rawResponse": text[:4000]})
        _fail(502, "INVALID_RESPONSE", "The model response failed validation and was discarded.")
    _ledger(c["ledger"], {"event": "completed", "requestId": body.requestId, "latencyMs": latency, "response": result})
    return result
