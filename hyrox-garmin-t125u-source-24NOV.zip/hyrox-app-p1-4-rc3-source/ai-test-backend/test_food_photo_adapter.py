"""Tests for the isolated food-photo test backend. NO real model calls: call_model is replaced by a fake.
Run: cd ai-test-backend && python3 -m pytest -q test_food_photo_adapter.py
"""
import asyncio
import base64
import io
import json
from pathlib import Path

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from PIL import Image

import food_photo_adapter as fpa

FIX = Path(__file__).resolve().parent.parent / "tests" / "fixtures"
EXIF_JPEG = (FIX / "synthetic-food-exif.jpg").read_bytes()
GOOD = {"items": [{"name": "Rice", "role": "SIDE", "portion": "one cup", "eatenFraction": 1, "kcal": 240, "proteinG": 5,
                   "carbsG": 53, "fatG": 1, "confidence": "MEDIUM", "uncertainty": "±30%"},
                  {"name": "Oil", "role": "OIL", "kcal": None, "proteinG": None, "carbsG": None, "fatG": None, "confidence": "LOW"}],
        "warnings": ["oil unknown"]}


@pytest.fixture
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("AI_PHOTO_ENABLED", "true")
    monkeypatch.setenv("AI_REAL_CALL_BUDGET", "1")
    monkeypatch.setenv("AI_CALL_LEDGER_PATH", str(tmp_path / "ledger.jsonl"))
    monkeypatch.setenv("AI_PHOTO_MODEL_PROVIDER", "fake")
    monkeypatch.setenv("AI_PHOTO_MODEL", "fake-model")
    monkeypatch.setenv("EMERGENT_LLM_KEY", "test-key-not-real")
    calls = []

    async def fake(cfg, jpeg, desc):
        calls.append(jpeg)
        return "```json\n" + json.dumps(GOOD) + "\n```"
    monkeypatch.setattr(fpa, "call_model", fake)
    app = FastAPI()
    app.include_router(fpa.router)
    c = TestClient(app)
    c.calls = calls
    c.ledger = tmp_path / "ledger.jsonl"
    return c


def body(**kw):
    b = {"imageBase64": base64.b64encode(EXIF_JPEG).decode(), "mimeType": "image/jpeg", "description": "rice", "consent": True, "requestId": "t1"}
    b.update(kw)
    return b


H = {"X-Hyrox-Consent": "send-once"}


def test_status_reports_budget(client):
    s = client.get("/api/food-photo/status").json()
    assert s["configured"] is True and s["budgetRemaining"] == 1 and "test-key-not-real" not in json.dumps(s)


def test_no_consent_header_or_flag_means_no_call(client):
    assert client.post("/api/food-photo/analyze", json=body()).status_code == 403
    assert client.post("/api/food-photo/analyze", json=body(consent=False), headers=H).status_code == 403
    assert client.calls == []


def test_disabled_means_no_call(client, monkeypatch):
    monkeypatch.setenv("AI_PHOTO_ENABLED", "false")
    r = client.post("/api/food-photo/analyze", json=body(), headers=H)
    assert r.status_code == 503 and r.json()["detail"]["code"] == "NOT_CONFIGURED" and client.calls == []


def test_success_strips_metadata_and_budget_is_enforced(client):
    r = client.post("/api/food-photo/analyze", json=body(), headers=H)
    assert r.status_code == 200, r.text
    out = r.json()
    assert out["schemaVersion"] == 1 and out["items"][1]["kcal"] is None
    sent = client.calls[0]
    assert b"Exif" not in sent and b"SyntheticCam" not in sent and b"synthetic fixture comment" not in sent
    assert not Image.open(io.BytesIO(sent)).getexif()
    r2 = client.post("/api/food-photo/analyze", json=body(requestId="t2"), headers=H)
    assert r2.status_code == 402 and r2.json()["detail"]["code"] == "BUDGET_EXHAUSTED" and len(client.calls) == 1
    led = client.ledger.read_text()
    assert base64.b64encode(EXIF_JPEG).decode()[:200] not in led and "test-key-not-real" not in led


def test_corrupt_image_rejected_without_call(client):
    r = client.post("/api/food-photo/analyze", json=body(imageBase64=base64.b64encode(b"nope").decode()), headers=H)
    assert r.status_code == 400 and client.calls == []


def test_invalid_model_output_discarded(client, monkeypatch):
    async def bad(cfg, jpeg, desc):
        return json.dumps({"items": [{"name": "<script>", "kcal": -1, "confidence": "SURE"}], "warnings": []})
    monkeypatch.setattr(fpa, "call_model", bad)
    r = client.post("/api/food-photo/analyze", json=body(), headers=H)
    assert r.status_code == 502 and r.json()["detail"]["code"] == "INVALID_RESPONSE"


def test_validator_rules():
    with pytest.raises(ValueError):
        fpa.validate_model_json({"items": [{"name": "Salad", "kcal": 50, "proteinG": 100, "carbsG": 100, "fatG": 100, "confidence": "HIGH"}], "warnings": []}, "p", "m")
    with pytest.raises(ValueError):
        fpa.validate_model_json({"items": [], "warnings": [], "extra": 1}, "p", "m")
    ok = fpa.validate_model_json({"items": [{"name": "Water", "kcal": 0, "proteinG": 0, "carbsG": 0, "fatG": 0, "confidence": "HIGH"}], "warnings": []}, "p", "m")
    assert ok["items"][0]["kcal"] == 0


def test_missing_ledger_path_fails_closed(client, monkeypatch):
    monkeypatch.delenv("AI_CALL_LEDGER_PATH")
    assert client.get("/api/food-photo/status").json()["configured"] is False
    r = client.post("/api/food-photo/analyze", json=body(), headers=H)
    assert r.status_code == 503 and client.calls == []
