# HYROX Phase 10: Meal UX, multiple photos and Quick steps

**Baseline:** Claude-corrected Phase 9.
- Source: `hyrox-app-phase9-source.zip`.
- Deploy: `5bac0b1c328672a2ba0ff07c07a4659c9191eb8d04b2ae4950bd338956971d35`, re-verified.

**Spec:** "HYROX Phase 10 — Meal UX, Multiple Photos & Quick Steps", sections 1–6.

**How this was built:**
- Nothing was deployed.
- No Netlify or GitHub login, and no push.
- No OpenAI call. Every provider response is a local stub or mock.
- Synthetic data only.
- Browser tests are **Chrome mobile emulation, not Safari/WebKit**.

## 0. Claude's Phase 9 changes (baseline vs Grok P9 `e44f190`)
- `netlify/lib/handler.mjs`: a successful provider reply **without a usage figure** is now charged the full reservation ($0.004). Before, it was charged $0. Code: `(p.ok || p.billed) ? CFG.reserveUsd : 0`.
- `tests/e2e/p9-photo-live.spec.js`: esbuild is resolved from the installed package. The fixed author path is now only a fallback.
- `tests/p9-claude-review.test.js`: 2 new tests (missing usage is charged; the esbuild path).
- The DEPLOY doc in the source zip is the `e44f190` version.

Phase 10 keeps all of these unchanged.

## 1. Meal UX (P0, §2)
### One editable draft and one review
An AI meal shows one **Review** box (`meal-review-box`). It lists:
- every item, with values marked **(as served)**;
- the eaten amount used for each item;
- the total "Counts as eaten…";
- a **partial** label when any item is unknown. Unknown is never counted as 0.

For AI meals, rows are compact: name, amount, kcal and macros stay visible, and Type, Preparation and certainty fold into "More". Manual, typed and reuse meals are unchanged.

### Eaten amounts from the note
- `AI.noteFractions` is deterministic. It reads phrases such as "all chicken eaten", "60% sauce", "ate half the rice", "three quarters of the rice eaten" and "ate none of the sauce".
- Each phrase is matched to an item by its head noun or its role (sauce/gravy/curry → SAUCE, oil/ghee → OIL, drink/juice → DRINK).
- Matches are shown as suggestions. **Use these eaten amounts** *sets* each item's own amount and never multiplies, so a second tap changes nothing.
- An amount with no matching item is shown, never dropped or guessed.
- Text that describes the food rather than how much was eaten is not read as an amount: "half portion", "2% milk", "a whole chicken breast".

### Served vs consumed
- The model is told that values are for the **served** portion and that items must not overlap (a dish and its own sauce). INSTRUCTIONS gained two sentences, and "Do not guess how much was eaten" is kept.
- Eaten amounts are **stripped** from the note before it is sent (`AI.analysisNote`). The phone shows the note that is actually sent.

### Butter chicken acceptance fixture
- Mock scenario: Settings → Mock scenario → **Butter chicken**.
- Model items: chicken pieces 250 kcal, sauce 300 kcal, ghee unknown.
- The note "butter chicken, all chicken eaten, 60% sauce" gives chicken **100%** and sauce **60%**: 250 + 180 = **430 kcal (partial, ghee unknown)**.
- Applying it twice gives the same result. A meal-level amount covers only items without their own amount. The total is never 250 + 300 + 180.

### Stale estimate
- The basis is the ordered photo ids and labels plus the analysis note.
- If photos are added, removed or relabelled, or the food words in the note change, a **stale** warning appears and *Confirm* is refused. The owner can analyse again or tap **Keep values as mine**, which marks the meal user-corrected.
- Changing only an eaten amount never makes the estimate stale and never calls the API. It recomputes locally.
- Re-analysis asks before it replaces items (P9 confirm is kept) and never confirms a meal.

### Double-count warnings
- SAME_NAME: the same item listed twice, for example the same plate seen in two photos.
- DISH_AND_SAUCE: a whole dish next to its own sauce.

### Data
Nothing new is persisted. Meals use the existing per-item `eatenFraction` from Phase 3. `src/data/*` is **byte-identical** to Phase 9, and a test enforces this.

## 2. Quick "Log steps" on Today (P0, §3)
- A **Log steps** button in the Steps row of Today opens a panel with **Today / Yesterday / Choose date**. Dates are Asia/Qatar.
- It saves only `steps` of that day's check-in, through the same `store.putRecord('daily')` validator and record id `daily-YYYY-MM-DD`. Every other value is copied unchanged.
- Rules:
  - Future dates are refused by both the helper and the store.
  - Blank is refused, so the value stays missing.
  - `0` is saved as zero.
  - Whole numbers only, 0–200 000; commas are allowed.
- Replacing a saved total needs an explicit tick, and the same value again does nothing.
- A **damaged** check-in is never touched here. The panel links to the full check-in, where the existing approval tickbox applies.
- If the panel is open across midnight (Asia/Qatar), Today/Yesterday saves are refused.
- No catch-up targets.

## 3. 1–3 photos in one request (P1, §4)
**Phone:**
- Choose up to 3 photos (library multi-select or camera). Each is stripped of metadata and re-encoded on the device. Encoding steps are 1280 px/0.85 → 0.72 → 1024/0.70 → 800/0.65, stopping at ≤ 500 KB.
- Each photo is labelled: **Same plate / Before eating / After eating / Another dish**.
- A 4th photo is refused, and the same photo is refused twice.
- A photo that cannot be read clears the photo set (the P3 "no stale UI" rule), but **not** the typed draft. Encodes still running for a cleared set are dropped.
- Photos keep the order they were chosen in, whatever order their encodes finish.
- Consent names the count: "Send THESE 3 photos … as ONE request".
- 1 photo uses the **exact P9 request shape**. 2–3 photos use `images:[{imageBase64,mimeType,label}]`.

**Server:**
- `checkImages` checks:
  - 1–3 images;
  - exact keys, and labels from an allowlist;
  - each is a JPEG with no metadata;
  - each ≤ 600 000 bytes and ≤ 1600 px per side;
  - the set ≤ 1 650 000 bytes (same as the P9 single-photo maximum);
  - no duplicates by sha256.
- The body limit (2.4 MB) is **not** raised.
- Idempotency key: sha256 of `{v:2, note, [[label, sha256(image)]…]}`, in order.
  - The same id with the same set replays with no new call.
  - A different order, label or note returns 409.
  - The phone reuses one request id per draft for the same set and note, so a retry never double-charges.
- One request counts as **one call** against 20/day and 300/month. Caps are unchanged: $5 total, $3/month, 20/day, 300/month.

**Worst-case reserve:** recomputed and **unchanged at $0.004 per call**. Each multi request is checked *before* reserving and refused (413) if its bound exceeds the reserve:

```
worst = ((request text chars) + Σ image tokens) × $0.10/1M + 3000 output tokens × $0.50/1M
```

- Request text characters are counted as tokens, an upper bound.
- Image tokens = ⌈w/32⌉ × ⌈h/32⌉ × 2.5. This is above the highest published multiplier, 2.46 (gpt-4.1-nano); gpt-6-luna is not listed in OpenAI's table.

| Case | Worst case |
|---|---|
| 3 × 1600² + 1000-character note | **$0.00377** |
| 3 × 1280² (what the phone sends) | $0.00310 |
| 1 × 1280² | $0.00220 |

**Sources, read 17 Nov 2026:**
- OpenAI pricing: gpt-6-luna $0.10 / $0.50 per 1M tokens.
- OpenAI vision guide: 32-px patches × multiplier, 1.2–2.46.
- Netlify functions: 60 s synchronous limit, 6 MB buffered payload.

## 4. Errors (P1, §5)
- Provider failures are classified server-side into an **allowlist**: KEY_INVALID, MODEL_ACCESS, SCHEMA_REJECTED, REQUEST_REJECTED, QUOTA (→ budget message), RATE_LIMIT, PROVIDER_DOWN, TIMEOUT, NETWORK, INCOMPLETE, REFUSED, INVALID_OUTPUT. Anything else is `other`.
- The response may carry `detail.category`, `providerStatus`, an allowlisted `providerCode` and `providerRequestId` (pattern-checked `x-request-id`). Raw bodies and messages are never passed on.
- The phone shows one plain action per category, for example "check OPENAI_API_KEY in Netlify". A folded **Details for the owner** shows the category, status, code and request id.
- Logs gain `category`, `pStatus`, `pCode`, `pReq` and the image count. There is still no key, code, image, note or raw body in logs.
- No new endpoint.

## 5. Tests
| Suite | Phase 9 corrected (re-run here) | Phase 10 |
|---|---|---|
| JS unit (`node --test tests/*.test.js`) | 1317 pass, 0 fail | **1389 pass, 0 fail** (+39 `p10-function`, +33 `p10-local`) |
| Python adapter | 8 pass | 8 pass |
| Chrome e2e (Chrome emulation, not Safari) | 241 pass, 1 skip | **257 pass, 1 skip** (+16 in `p10-meal-steps.spec.js`; 48/48 on a 3× repeat) |
| `netlify dev --offline` (stub OpenAI) | 12 checks | 12 + 5 P10 checks (3 photos, replay, order → 409, 4 → refused, duplicate → refused), all as expected |

- **No existing assertion was changed or weakened.**
- `test_food_photo_api_live.py` was not run.

**Two existing e2e tests caught P10 regressions, and both were fixed in the app, not the tests:**
- The `meal-review` testid collided with History's button. The review box was renamed `meal-review-box`.
- P3 "a failed second photo clears the old preview and Send": the set is now cleared on a failed photo.

**§6 coverage:**
- Meal lifecycle, partial and unknown totals, served vs consumed, edits and stale estimates, same-plate duplication and dish-plus-sauce, typed, manual and reuse unchanged (existing suites).
- 1, 2 and 3 images, 4+ rejected, malformed, oversize, over 1600 px, per-photo metadata, ordered idempotency, concurrency.
- Cap boundaries (daily 20, month $2.997), every provider error class, missing usage, storage outage.
- Older backup restore, P10 backup on the **P9 data layer**, previous-day step preservation.
- 320 and 390 px, fast navigation.

## 6. Downgrade / rollback risk: **low**
- `src/data/*` is unchanged, the backup format is unchanged, and no new persisted fields exist.
- A test restores a Phase 10 backup (butter-chicken meal with per-item amounts plus quick-logged steps) with the *Phase 9* data layer: the result reads 430 kcal and 9000 steps.
- Photos are never stored.
- Rolling back the deploy only removes the new UI. Saved data stays valid.

## 7. Open owner decisions
1. **Token multiplier for the cost bound.** gpt-6-luna is not in OpenAI's multiplier table. 2.5 (above the published maximum) is used, so 3 photos fit the $0.004 reserve. The first real multi-photo call shows true usage.
2. **Single-photo path.** It is unchanged from P9: ≤ 4096 px per side and ≤ 12 MP, with no cost-bound check. Under the 2.5 bound, a 12-MP single photo would be about $0.0048, above the reserve; under the 1.2 multiplier of the gpt-5/6 families it is about $0.0032. The phone never sends more than 1280 px. Options: keep as is, or also cap single photos at 1600 px. Adding the check to single photos would change a P9 test that uses a custom-priced model, so it was not done.
3. **Owner-device gates.** HEIC multi-select in iOS Safari, and the first real 2–3-photo call, need the owner's iPhone. They are not covered here.
4. **Stripped notes.** Eaten amounts stay on the phone. Should a note that is *only* an amount be sent as an empty note? It currently is.
