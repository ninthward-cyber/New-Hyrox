# Combined Value Sprint — Priority A (P0): photo + note lost food components

Base: P1.3-RC3, Claude final commit `b198d30`, build source id `b1de280e2a65`, source ZIP sha256 `26ea6af0…f2`.
Grok Commander, 23 Nov 2026 (Asia/Qatar). **Not deployed, not pushed.** Data version 2, no migration, no new storage key,
src/data/ byte-identical to RC3, Block 2 untouched, no new service, no live call (stub OpenAI only).

## Bug
Photo of only strawberry yogurt + note "3 eggs, 2 pork patties, and strawberry yogurt" -> only the yogurt was saved.

## Root cause (three defects in series; see ROOT-CAUSE report for line numbers and the stage trace)
1. Request contract (netlify/lib/openai.mjs, RC3 lines 25-35, 46-50, schema 8-23): the model was told to estimate "the food in
   one photo", list each **visible** item and estimate "the portion shown"; the note was only "untrusted data about the meal".
   The schema had no way to say "named in the note, not pictured". A compliant answer lists the yogurt only.
2. Normaliser (openai.mjs RC3 lines 179-183): any item with `notVisible: true` had its numbers forced to null. Meant for hidden
   oil/sauce, it also wiped foods that were named but not pictured, so even when listed they added nothing.
3. Phone (src/ui/app-ext.js RC3 lines 2638-2647; save 2249-2263): the model's list replaced the meal's items and nothing
   compared it with the typed note (noteFractions only reads eaten amounts; it returns `any:false` for this note). Confirm had
   no check, so the loss was silent and the day could even be declared complete (D5) on 150 kcal.

## Fix
- Server: photo(s) and note are ONE meal; every food seen OR named is listed once with `basis` PHOTO / NOTE / BOTH (strict
  schema `hyrox_food_photo_v2`). Note foods keep a labelled estimate (confidence capped at MEDIUM, "Not in the photo: estimated
  from your note"); hidden oil/sauce stays null/LOW. Note fenced `<<<NOTE … NOTE>>>`, fence look-alikes stripped, instructions
  in it ignored. `basis` is returned only when the app asks (`itemBasis: true`), so an RC3 phone still gets the v1 shape.
- Phone: deterministic check of the foods named in the note against the items (no model, no network). Anything not accounted
  for, or a food listed twice, is shown in a conspicuous "Not accounted for" box (role=alert) with **Add as item** (unknown
  values, never 0) or **Already included / not eaten** / **They are separate servings**. Confirm and "I ate this" are refused
  until each line is resolved; Save draft is still allowed (drafts never count). Each review line shows where the item came
  from (photo / your note / photo + your note / added by you) and its confidence + uncertainty. Acknowledgements live on
  `meal.ai.acks`, item provenance on `component.basis` (extra fields; older builds keep them, tested).
- Unchanged: consent, sanitised images, no photo retention, owner code, keys, $0.004 reserve and caps (worst case at the largest
  request now $0.00322, was $0.00309), same-origin, stale-estimate rule, eaten amounts never from the model, one request per analysis.

## Tests
New: `tests/p0-photo-note.test.js` (31), `tests/e2e/p0-photo-note.spec.js` (8 scenarios x 320/390), synthetic fixtures
`tests/fixtures/p0-photo-note-fixtures.js`, rollback specs `tests/rollback/p0-photo-note-*.spec.js`. On unchanged RC3: unit 24 of
31 fail, browser 14 of 16 fail (guards pass, as intended).
Re-pointed (never deleted, each marked "Re-pointed by the P0 sprint photo + note fix"): the three RC2 scope-pin tests (3 files
re-pinned in `tests/fixtures/p0-sprint-photo-pins.json` via `tests/p0-sprint-pins.js`), three request-key assertions (`itemBasis`),
and 3 browser specs whose stub answer does not contain "dal" from their note (they now acknowledge it).

## Limits
Chrome mobile emulation at 320 and 390 px only. Not Safari, not a physical iPhone, not VoiceOver. No live model was called: how
the real model follows the new contract is unverified until one owner-approved analysis.
