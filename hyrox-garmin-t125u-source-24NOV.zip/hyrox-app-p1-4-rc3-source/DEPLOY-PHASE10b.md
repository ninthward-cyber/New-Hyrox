# Phase 10b: owner checks, deploy and rollback (Windows PowerShell + iPhone)

Only the owner runs these steps, with his own logins.

**Site:** `hyrox-phase7-private-test`, site ID `99f0deb7-0526-46f6-b432-9c3bfc2c86d2`. The Phase 5 site is out of scope.

**Nothing changes in env:** no variable, secret, key, model or cap changes. The caps stay at $5 total, $3 a month, 20 a day and 300 a month.

**No migration:** Phase 10b changes only the meal form in `src/ui/app-ext.js`.

> **Never paste into any chat:** your OpenAI key, owner code, any `Authorization` header, photos, or what you ate (the item names in a log or blob). Copy only the numbers asked for below.

## A. Read-only: which build is live now (no change to anything)
1. Netlify → site `hyrox-phase7-private-test` → **Deploys** → the **Published** deploy (18 Nov, 11:50 Qatar, "Build from drop deployment", id `6afd66ab8c61fa7eb0bfa15d`) → **Deploy file browser** / Browse files → `src/ai/photo-ai.js`. Check its size, or open it and search for `foodWords`:

   | `photo-ai.js` | `app-ext.js` | Live build is |
   |---|---|---|
   | 37912 bytes, **has** `function foodWords` | 199400 | **Claude P10** `hyrox-app-phase10-deploy-claude.zip` (911c4b1e…) |
   | 37254 bytes, **no** `foodWords` | 199400 | **Grok P10** `hyrox-app-phase10-deploy.zip` (af019198…) |
   | 37912 | 202806 | Phase 10b (this package) |
   | anything else | | something modified: stop and report the sizes |

   Without the file browser: in a desktop browser **signed in to Netlify**, open `https://hyrox-phase7-private-test.netlify.app/src/ai/photo-ai.js` and press Ctrl+F `foodWords`.
2. To check which zip you dragged in, run this in PowerShell in the folder holding the zip: `Get-FileHash .\<zip you used> -Algorithm SHA256`. Report only the first 8 characters.

## B. Read-only: what has been spent
1. **Function log:** Netlify → Logs → Functions → `food-photo`, last 7 days, search `analyze_`. For each line, copy:
   - time
   - event (`analyze_ok`, `analyze_replay` or `analyze_fail`)
   - `images`
   - `inTok` / `outTok`
   - `costUsd`
   - the first 8 characters of `pReq`
2. **Ledger (exact budget).** In PowerShell:
   ```powershell
   npx netlify-cli login
   npx netlify-cli blobs:get hyrox-photo ledger/v1 --site 99f0deb7-0526-46f6-b432-9c3bfc2c86d2
   ```
   - Copy `total.usd`, `total.calls`, `month.key`, `month.usd`, `month.calls`, `day.key`, `day.calls`, and the **number** of entries in `inflight`.
   - Use only `blobs:get`. **Never** run `blobs:set` or `blobs:delete`, and do not open `idem/…` keys: they hold your meal results.
   - What it tells us:
     - remaining total = $5 − `total.usd`
     - remaining this month = $3 − `month.usd`
     - if `total.calls` is 3, the 17 Nov 17:58 request was billed; its cost is `total.usd` − 0.001068.
   - Alternative, on a desktop browser: open the app → Settings → enter the owner code → F12 → Network → press **Check** → click `status` → Response. Copy only the `usage` block, **not** the request headers.
3. **OpenAI:** platform.openai.com → Usage → 17 and 18 Nov. Copy, per day:
   - model
   - number of requests
   - input and output tokens
   - cost

   OpenAI's figures can lag by hours. The app's figures are **server-logged from provider usage, not an invoice**.

## C. Deploy Phase 10b (only after A shows which build is live)
```powershell
cd $HOME\Downloads
Get-FileHash .\hyrox-app-phase10b-deploy.zip -Algorithm SHA256   # must equal its line in SHA256SUMS-phase10b.txt
Expand-Archive .\hyrox-app-phase10b-deploy.zip -DestinationPath .\hyrox-p10b-deploy -Force
cd .\hyrox-p10b-deploy\hyrox-phase10b-deploy
npm ci
npx netlify-cli login
npx netlify-cli sites:list --json | ConvertFrom-Json | Where-Object { $_.id -eq '99f0deb7-0526-46f6-b432-9c3bfc2c86d2' } | Select-Object name, url, id
# must show hyrox-phase7-private-test, otherwise STOP
npx netlify-cli deploy --site 99f0deb7-0526-46f6-b432-9c3bfc2c86d2 --dir publish --functions netlify/functions --message "Phase 10b draft"
```
1. **Fresh backup first.** On the iPhone, open the Home Screen icon → Settings → **Export**, and keep the file.
2. **Draft check.** Open the *draft URL* in a new Safari tab, not the Home Screen icon. AI stays off there because no code is entered. Check:
   - Add → Meal → Manual: save "test A" → Add → the form is **empty** → save "test B" → History shows **both**.
   - Type something, change tabs, come back: it is still there. Start a new meal: it asks before discarding.
   - Then clear that tab's website data.
3. **Production:**
   ```powershell
   npx netlify-cli deploy --prod --site 99f0deb7-0526-46f6-b432-9c3bfc2c86d2 --dir publish --functions netlify/functions --message "Phase 10b"
   ```
   Open the Home Screen icon and close and reopen it. Your data must still be there.

## D. Owner device QA (real iPhone Safari; the e2e runs in Chrome emulation, not Safari)
1. Two meals in a row (Manual, then Description): after each **Confirm**, Add shows an empty form, and History has both once.
2. Edit an old meal → save → Add: the form is empty, with no old values.
3. Photo meal (Mock provider, no cost) → confirm → Add: no photos, no estimate, consent unticked.
4. Leave the app open past midnight Qatar time, or check the next morning without force-closing: Today shows the new date.
5. Settings → Export → Restore preview: no duplicate meals.
6. Optional paid check, only if you approve about $0.001: one 2–3-photo analysis, then a new meal. The status counter rises by 1.

## E. Rollback (no env change, no migration; budget counters in Blobs are kept)
**Fastest:** Netlify → Deploys → click the deploy to return to → **Publish deploy**. The 18 Nov 11:50 Qatar deploy `6afd66ab8c61fa7eb0bfa15d` is the current P10.

**From a zip** (check the hash first, then run the same `npm ci` and `deploy --prod` commands as in C, inside the unzipped folder):

| Target | Zip | SHA256 |
|---|---|---|
| Claude P10 (probably live now) | `hyrox-app-phase10-deploy-claude.zip` | `911c4b1e4dce2b65c48fb0174f5e55d79b950e86d5246c64d392ba96d39ffad5` |
| Grok P10 | `hyrox-app-phase10-deploy.zip` | `af019198559e08002413367fa043f047924ba6a174809cebe35b080f314bb095` |
| Claude P9 (corrected) | the Phase 9 deploy zip | `5bac0b1c328672a2ba0ff07c07a4659c9191eb8d04b2ae4950bd338956971d35` |

Rolling back brings back the P0 bug (the second meal can be lost) but not any data loss for saved meals.
