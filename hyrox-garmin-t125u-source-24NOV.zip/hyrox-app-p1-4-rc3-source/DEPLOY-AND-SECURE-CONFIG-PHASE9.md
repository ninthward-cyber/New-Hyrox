# Phase 9 — exact deployment and secure configuration (owner steps)

**Nothing here has been done.** Do not deploy until you approve gates A–D (end of this file). Use a **new staging Netlify site**, not the Phase 5 production site.
Times are yours (Asia/Qatar). UI labels on openai.com / netlify.com move around; where I am not certain of an exact label I say so.

## 0. Why this is not drag-and-drop
Dropping a folder or ZIP on Netlify's Deploys page publishes **static files only** — the function would not exist. This package deploys with the Netlify CLI (needs Node ≥ 22.12 on your computer).

## 1. Make the owner access code (on your computer, offline)
```
cd hyrox-phase9-deploy
node tools/make-owner-code.mjs
```
It prints a **code** (`hx1-…`) and a **hash**. Put the code in your password manager (you will type it once on the iPhone). The hash is what goes to Netlify. Never paste the code or the OpenAI key into chat, email or a Netlify *build* log. If the code leaks: generate a new one, replace the hash, redeploy.

## 2. OpenAI: a dedicated, capped project and a restricted key
1. In the OpenAI dashboard create a **new project** (e.g. `hyrox-photo`). Do not reuse a project that has other keys.
2. In that project's **limits/budget** settings set a **monthly budget of $3** and, if offered, a notification at 50 %. In billing settings **turn auto-recharge OFF**. Your prepaid balance ($9.94) is then the absolute ceiling. This is the independent, provider-side cap; the app's own cap is a second layer.
3. Allow only the model you use (`gpt-6-luna`) in the project's model access, if the setting is available.
4. Create a **restricted API key** in that project: permissions **Write on "Model capabilities"/Responses only**, everything else None. (Exact wording may differ.) Copy it once into the Netlify variable below — never into the app, the repo or this chat.
5. Expiry/rotation: note a reminder to rotate the key after the trial.

## 3. Netlify: staging site and environment variables
1. Create a new site for staging (empty). Note its **Site ID** (Site configuration → General).
2. Site configuration → Environment variables → add (scope **Functions**; mark the first two **"contains secret values"** if offered):

| Variable | Value |
|---|---|
| `OPENAI_API_KEY` | the restricted key from step 2 |
| `HYROX_OWNER_CODE_HASH` | the hash from step 1 (64 hex characters) |
| `HYROX_PHOTO_ENABLED` | `true` (anything else, or unset, keeps the provider **OFF**) |

Optional (defaults in brackets): `HYROX_PHOTO_MODEL` [gpt-6-luna], `HYROX_PHOTO_IMAGE_DETAIL` [auto; `low` is cheaper/less accurate], `HYROX_PHOTO_REASONING` [low], `HYROX_TOTAL_USD_CAP` [5], `HYROX_MONTHLY_USD_CAP` [3], `HYROX_DAILY_CALL_CAP` [20], `HYROX_MONTHLY_CALL_CAP` [300], `HYROX_BURST_CAP` [6], `HYROX_MIN_GAP_SECONDS` [4], `HYROX_RESERVE_USD` [0.004], `HYROX_PROVIDER_TIMEOUT_MS` [40000]. Caps cannot exceed the hard ceilings in `config.mjs` even if mistyped. Total env size must stay under Netlify's ~4 KB limit (it is far below).

**To deploy with the provider OFF (recommended first step):** set only the first two, leave `HYROX_PHOTO_ENABLED` unset. The app then shows "not set up yet", nothing can be sent.

## 4. Deploy (the owner logs in; nobody else needs your Netlify credentials)
```
npm ci
npx netlify-cli login
npx netlify-cli deploy --prod --site <STAGING SITE ID> --dir publish --functions netlify/functions
```
`--prod` here means "the staging site's live URL". Env-var edits need a **new deploy** to reach the function. The CLI should list the function `food-photo`.

## 5. Check from your computer (replace the URL; CODE is your owner code)
```
curl -s https://<staging>.netlify.app/api/food-photo/status
#  -> {"configured":true,"status":"OK","authRequired":true,"authorized":false}   (provider OFF: "configured":false / NOT_CONFIGURED)
curl -s -o /dev/null -w "%{http_code}\n" -X POST https://<staging>.netlify.app/api/food-photo/analyze -H "Content-Type: application/json" -d '{}'
#  -> 401  (no code, no storage access, no provider call)
curl -s https://<staging>.netlify.app/api/food-photo/status -H "Authorization: Bearer $CODE"
#  -> "authorized":true plus usage counters
```
Then, **once the gates below are approved**, the first real photo is taken from the iPhone (step 6) and the OpenAI usage page should show about $0.001.

## 6. iPhone QA list (real Safari — not covered by the Chrome-emulation e2e)
Open the staging URL in Safari → Share → Add to Home Screen (the staging site has its own storage; production data is not there).
1. Settings → AI provider → **Live (OpenAI)** → paste the owner code → Save → Check: shows **Ready · 0 photos today**.
2. Add → Meal → Photo + description → **Take photo** (camera) and also **Choose from library**; also a photo your iPhone stores as HEIC — record whether it is accepted (the app re-encodes through the browser canvas; HEIC support in Safari is **unverified** here, and an unreadable photo gives a clear message and sends nothing).
3. Tick the privacy acknowledgement and the per-photo consent → **Analyze photo** → wait (≤ ~40 s) → components appear with the REAL MODEL ESTIMATE badge.
4. Hidden oil/sauce shows as unknown, not zero; edit a gram value; Confirm; it appears in History and Today.
5. Settings → Export → file downloads, contains no photo and no code; Restore the same file on a scratch profile.
6. Airplane mode → Analyze → compact offline message, nothing saved. Wrong code → "code is wrong". Remove the code → asks for it.
7. Portrait photo is upright in the preview. Two rapid taps on Analyze → only one charge (check the status counter).
8. Phone in 320-px-wide layout / Dynamic Type large: no horizontal scroll, buttons reachable.
9. Settings status afterwards shows photo count and remaining $ going down by ≈ $0.001 per photo.

## 7. Kill switch and rotation
- **Instant:** revoke the OpenAI key (dashboard) — analyze then returns a provider error, nothing else is exposed.
- **Clean:** set `HYROX_PHOTO_ENABLED=false` and redeploy (env changes apply on the next deploy).
- **Rotate owner code:** run step 1 again, replace `HYROX_OWNER_CODE_HASH`, redeploy, retype the code on the phone.
- Budget counters live in Netlify Blobs (store `hyrox-photo`); they are not reset by redeploys.

## 8. Rollback
Netlify → Deploys → pick the previous deploy → **Publish deploy**. For the Phase 8 build SHA256 is `422f4e6bade74883f796a4fa364d5e13463aaf07f70d24e5386de633004e0e7b`. Saved meals remain; the function disappears; see CHANGES-PHASE9.md "Downgrade".

## Decisions still open (gates)
- **A. Provider & billing** — approve `gpt-6-luna` on OpenAI, $5 lifetime trial / $3 monthly app caps, project budget set to $3 with auto-recharge off.
- **B. Deploy & authorization method** — approve the owner-access-code design and CLI deploy to a *new staging site*.
- **C. Review** — Claude's independent review of the source zip, the SHA256 list, then the iPhone QA list above, with the Phase 8 rollback.
- **D. Staging** — you separately approve the staging deploy and the first real (paid) call. Until then the candidate ships with the provider **OFF**.
