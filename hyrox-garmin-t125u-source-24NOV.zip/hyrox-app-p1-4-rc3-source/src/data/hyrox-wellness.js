/*
 * hyrox-wellness.js - readiness flags, canonical steps and trend series. Pure functions.
 * Missing data is never treated as safe, healthy or zero.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.HyroxWellness = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var SAFETY = 'Information only — not a diagnosis or fitness clearance. Chest pressure, severe dizziness or fainting, concerning palpitations, disproportionate breathlessness or signs of heat illness need urgent medical assessment.';

  function obs(rec, k) {
    var o = rec && rec[k];
    return o && o.state === 'OBSERVED' && typeof o.value === 'number' ? o.value : null;
  }

  function addDays(iso, n) {
    var d = new Date(Date.UTC(+iso.slice(0, 4), +iso.slice(5, 7) - 1, +iso.slice(8, 10) + n));
    return d.toISOString().slice(0, 10);
  }

  // OBSERVED baseline = mean of OBSERVED RHR in the 7 days before `date`; valid only with >=4 readings.
  // (The owner's CONFIGURED baseline is separate - see rhrAssessment. Neither replaces the other.)
  function rhrBaseline(date, dailies) {
    var from = addDays(date, -7);
    var vals = dailies.filter(function (d) { return d.date >= from && d.date < date; })
      .map(function (d) { return obs(d, 'rhr'); }).filter(function (v) { return v !== null; });
    if (vals.length < 4) return { valid: false, n: vals.length, value: null };
    return { valid: true, n: vals.length, value: Math.round(vals.reduce(function (a, b) { return a + b; }, 0) / vals.length * 10) / 10 };
  }

  // Owner rule 1. Compares a reading with BOTH baselines and says which one is which:
  //   configured -> the owner's own baseline (76 bpm by owner decision until changed); a setting, not a measurement
  //   observed   -> mean of the recorded readings in the previous 7 days; only valid with >=4 readings
  // The flag is raised if the reading is >=7 bpm above EITHER, so configuring a baseline can never
  // switch off the source's weekly-baseline flag, and the observed mean never overrides the owner's value.
  var RHR_LABELS = Object.freeze({
    configured: 'Owner-configured baseline (owner setting; 76 bpm unless changed)',
    observed: 'Observed 7-day mean (app calculation from your readings; not a v2.1 rule)' });
  function rhrAssessment(rhr, date, dailies, settings) {
    var observed = rhrBaseline(date, dailies);
    var cfg = settings && typeof settings.rhrBaselineBpm === 'number' ? settings.rhrBaselineBpm : null;
    var configured = { value: cfg, source: cfg === null ? null : (settings.rhrBaselineSource === 'OWNER_SET' ? 'OWNER_SET' : 'OWNER_DEFAULT') };
    var above = [], basis = [];
    var cfgAbove = rhr !== null && cfg !== null ? rhr >= cfg + 7 : null;
    var obsAbove = rhr !== null && observed.valid ? rhr >= observed.value + 7 : null;
    if (cfgAbove) { above.push('your configured baseline (' + cfg + ' bpm)'); basis.push('OWNER_CONFIGURED'); }
    if (obsAbove) { above.push('the observed 7-day mean (' + observed.value + ' bpm, n=' + observed.n + ') [app calculation, not a v2.1 rule]'); basis.push('OBSERVED_7DAY_MEAN'); }
    function delta(b) { return rhr !== null && b !== null ? Math.round((rhr - b) * 10) / 10 : null; }
    // One reading gives at most ONE readiness flag, whichever comparisons exceed (flagCount <= 1).
    return { reading: rhr, configured: configured, observed: observed, hasBaseline: cfg !== null || observed.valid,
      flag: above.length ? 'Resting HR ≥ 7 bpm above ' + above.join(' and ') : null,
      labels: RHR_LABELS,
      comparisons: [
        { basis: 'OWNER_CONFIGURED', label: RHR_LABELS.configured, baseline: cfg, delta: delta(cfg), above7: cfgAbove },
        { basis: 'OBSERVED_7DAY_MEAN', label: RHR_LABELS.observed, baseline: observed.value, n: observed.n, delta: delta(observed.value), above7: obsAbove, sourceRule: false }
      ],
      flagCount: above.length ? 1 : 0, flagBasis: basis };
  }

  function readiness(date, dailies, settings) {
    var rec = dailies.filter(function (d) { return d.date === date; })[0] || null;
    var flags = [], missing = [];
    var sleep = obs(rec, 'sleepH'), sore = obs(rec, 'soreness'), rhr = obs(rec, 'rhr');
    if (sleep === null) missing.push('sleep'); else if (sleep < 6) flags.push('Sleep under 6 h');
    if (sore === null) missing.push('soreness'); else if (sore >= 6) flags.push('Soreness ≥ 6/10');
    var base = rhrBaseline(date, dailies);
    var ra = rhrAssessment(rhr, date, dailies, settings);
    if (rhr === null) missing.push('resting HR');
    else if (!ra.hasBaseline) missing.push('valid resting-HR baseline (needs ≥4 readings in prior 7 days)');
    else if (ra.flag) flags.push(ra.flag); // always names its basis; the observed mean is never presented as the v2.1 weekly baseline
    var pain = obs(rec, 'pain');
    // Stored values that are invalid (out of range / wrong type) are UNKNOWN: never 0, never "fine".
    var invalid = invalidFields(rec);
    var guidance;
    if (flags.length >= 2) guidance = 'Source rule: two or more flags → easy movement only.';
    else if (flags.length === 1) guidance = 'Source rule: one flag → consider a 20–30% volume reduction (only where data is sufficient).';
    else if (missing.length) guidance = 'No known flags, but some readiness data is missing — readiness cannot be confirmed.';
    else if (invalid.length) guidance = 'No known flags, but a stored value is invalid (' + invalid.join(', ') + ') and is treated as unknown — readiness cannot be confirmed.';
    else guidance = 'No source readiness flags in the recorded data.';
    return { date: date, flags: flags, missing: missing, invalid: invalid, guidance: guidance, baseline: base, rhr: ra,
      painUnknown: invalid.indexOf('pain') !== -1 ? 'The stored pain value is invalid, so pain is unknown (not 0). Do not treat today as pain-free; correct it in the check-in.' : null,
      rhrFlagBasis: rhr !== null && ra.hasBaseline ? ra.flagBasis : [],
      painNote: pain !== null && pain >= 4 ? 'Pain recorded (' + pain + '/10): step increases and intensity should depend on pain/limp — do not push through.' : null,
      safety: SAFETY };
  }

  // Names of the observation fields of a daily record whose stored state is INVALID.
  function invalidFields(rec) {
    if (!rec || typeof rec !== 'object') return [];
    return Object.keys(rec).filter(function (k) { var o = rec[k]; return !!o && typeof o === 'object' && !Array.isArray(o) && o.state === 'INVALID'; });
  }

  // A usable step count is a whole number 0..200000 (same rule as storage). Anything else is
  // ignored and flagged - never rounded, never counted.
  function isStepCount(v) { return typeof v === 'number' && isFinite(v) && Number.isInteger(v) && v >= 0 && v <= 200000; }
  var RUN_STEP_STATUSES = ['IN_PROGRESS', 'COMPLETED', 'PARTIAL'];

  // Owner step rule. The day's steps, never double-counted:
  //   1. a recorded DAILY total wins and nothing is added to it (it already contains walk/run steps);
  //   2. otherwise recorded walk steps + recorded running-session steps (sessions[].runSteps) are summed
  //      as a PARTIAL LOWER BOUND - never a complete day total;
  //   3. otherwise null. Missing is never 0, and nothing is derived from distance or time.
  // Each record id counts once even if passed twice. `sessions` is optional.
  function daySteps(date, ctx) {
    ctx = ctx || {};
    var daily = obs((ctx.dailies || []).filter(function (d) { return d && d.date === date; })[0], 'steps');
    function sumOf(list, key) {
      var seen = Object.create(null), sum = 0, n = 0, bad = 0;
      (list || []).forEach(function (r) {
        if (!r || r.date !== date) return;
        if (typeof r.id === 'string') { if (seen[r.id]) return; seen[r.id] = true; }
        if (!isStepCount(r[key])) { if (typeof r[key] === 'number' || (r._storedDamaged && r._storedDamaged.problems.some(function (p) { return p.field === key; }))) bad++; return; }
        sum += r[key]; n++;
      });
      return { value: n ? sum : null, n: n, bad: bad };
    }
    var w = sumOf(ctx.walks, 'steps');
    // F8: runSteps only count on sessions that actually happened (same rule as validation).
    var r = sumOf((ctx.sessions || []).filter(function (x) { return x && RUN_STEP_STATUSES.indexOf(x.status) !== -1; }), 'runSteps');
    var parts = w.value === null && r.value === null ? null : (w.value || 0) + (r.value || 0);
    var out = { date: date, total: null, source: null, complete: false, daily: daily,
      walkSteps: w.value, walkCount: w.n, runSteps: r.value, runCount: r.n, ignoredInvalid: w.bad + r.bad, flags: [] };
    // A step count that is not a whole number 0..200000 is left out (not rounded) and reported.
    if (w.bad + r.bad) out.flags.push('INVALID_STEP_COUNT_IGNORED');
    if (daily !== null) {
      out.total = daily; out.source = 'daily'; out.complete = true;
      if (parts !== null) out.flags.push('WORKOUT_STEPS_NOT_ADDED');
      if (parts !== null && daily < parts) out.flags.push('DAILY_BELOW_WORKOUT_STEPS');
    } else if (parts !== null) {
      out.total = parts; out.source = 'partial_lower_bound';
      out.flags.push('LOWER_BOUND_NOT_DAY_TOTAL');
    } else {
      out.flags.push('NO_STEP_DATA');
    }
    return out;
  }

  // Older shape kept for existing callers: {value, partial, source:<text>, detail}.
  function canonicalSteps(date, dailies, walks, sessions) {
    var d = daySteps(date, { dailies: dailies, walks: walks, sessions: sessions });
    var text;
    if (d.source === 'daily') text = d.runCount ? 'declared daily total (walk and run steps not added)' : 'declared daily total (walk steps not added)';
    else if (d.source === 'partial_lower_bound') text = (d.runCount ? (d.walkCount ? 'walk and run sessions only' : 'run sessions only') : 'walk sessions only') +
      ' — no daily total recorded, so this is a lower bound';
    else text = 'not recorded';
    return { value: d.total, partial: d.source === 'partial_lower_bound', source: text, detail: d };
  }

  // ---------- owner rule 5: adaptive daily step target ----------
  // The percentages below are app defaults chosen for this build, NOT values from the training
  // source. They are shown to the owner with every target and can be overridden per day.
  var STEP_RULES = Object.freeze({ historyDays: 14, minObservations: 3, lightDayFactor: 1.10,
    afterDemandingFactor: 0.85, highFatigueFactor: 0.70, roundTo: 100,
    sorenessHigh: 6, painHigh: 4, readinessLow: 4, demandingRpe: 7 });

  function roundSteps(n) { return Math.round(n / STEP_RULES.roundTo) * STEP_RULES.roundTo; }

  // Effective adaptive-suggestion rules: app defaults, overridden by validated owner settings.
  // These are engineering defaults, NOT values from HNC-BASE v2.1.
  var RULE_LIMITS = { stepLightDayPct: [0, 30], stepAfterDemandingPct: [-50, 0], stepHighFatiguePct: [-70, 0],
    stepHistoryDays: [7, 28], stepMinObservations: [3, 28] };
  function effectiveRules(settings) {
    function pick(k, dflt) {
      var v = settings && settings[k], r = RULE_LIMITS[k];
      return typeof v === 'number' && isFinite(v) && v >= r[0] && v <= r[1] ? v : dflt;
    }
    return {
      lightDayPct: pick('stepLightDayPct', Math.round((STEP_RULES.lightDayFactor - 1) * 100)),
      afterDemandingPct: pick('stepAfterDemandingPct', Math.round((STEP_RULES.afterDemandingFactor - 1) * 100)),
      highFatiguePct: pick('stepHighFatiguePct', Math.round((STEP_RULES.highFatigueFactor - 1) * 100)),
      historyDays: pick('stepHistoryDays', STEP_RULES.historyDays),
      minObservations: pick('stepMinObservations', STEP_RULES.minObservations),
      demandingRpe: STEP_RULES.demandingRpe
    };
  }
  var HEURISTICS_LABEL = 'App default suggestion — configurable in Settings; NOT from HNC-BASE v2.1';

  // Baseline from actual recent history: median of the declared daily totals in the 14 days before
  // `date`. Days without a recorded total are left out (never counted as 0). MANUAL uses the owner's number.
  function stepBaseline(date, dailies, settings) {
    if (settings && settings.stepBaselineMode === 'MANUAL' && typeof settings.stepBaselineManual === 'number') {
      return { value: settings.stepBaselineManual, source: 'MANUAL', n: null, reason: null };
    }
    var rules = effectiveRules(settings);
    var from = addDays(date, -rules.historyDays);
    var vals = (dailies || []).filter(function (d) { return d.date >= from && d.date < date; })
      .map(function (d) { return obs(d, 'steps'); }).filter(function (v) { return v !== null; }).sort(function (a, b) { return a - b; });
    if (vals.length < rules.minObservations) {
      return { value: null, source: 'AUTO', n: vals.length,
        reason: 'Not enough step history: ' + vals.length + ' recorded daily total(s) in the previous ' + rules.historyDays + ' days, ' + rules.minObservations + ' needed. Record steps or set a manual baseline in Settings.' };
    }
    var mid = Math.floor(vals.length / 2);
    var median = vals.length % 2 ? vals[mid] : (vals[mid - 1] + vals[mid]) / 2;
    return { value: roundSteps(median), source: 'AUTO', n: vals.length, reason: null };
  }

  // ctx: { dailies, walks, settings,
  //        plannedToday: number of sessions the (cascade-aware) plan shows for `date`,
  //        recentSessions: [{date, status, rpe, type}] actual sessions (type = plan slot type or null) }
  // The target depends only on the baseline and on that day's load and recovery. Nothing in here
  // looks at earlier shortfalls, so a missed or low day can never raise a later target.
  function stepTarget(date, ctx) {
    ctx = ctx || {};
    var dailies = ctx.dailies || [];
    var rec = dailies.filter(function (d) { return d.date === date; })[0] || null;
    var base = stepBaseline(date, dailies, ctx.settings);
    var steps = canonicalSteps(date, dailies, ctx.walks, ctx.sessions);
    var yesterday = addDays(date, -1);
    var worked = (ctx.recentSessions || []).filter(function (s) { return s.status === 'COMPLETED' || s.status === 'PARTIAL' || s.status === 'IN_PROGRESS'; });
    var demanding = worked.filter(function (s) {
      if (s.date !== date && s.date !== yesterday) return false;
      if (typeof s.rpe === 'number') return s.rpe >= STEP_RULES.demandingRpe;
      return s.type === 'INTERVALS' || s.type === 'RACE';
    });
    var sore = obs(rec, 'soreness'), pain = obs(rec, 'pain'), ready = obs(rec, 'readiness');
    var badRecovery = invalidFields(rec).filter(function (k) { return k === 'soreness' || k === 'pain' || k === 'readiness'; });
    var fatigue = [];
    if (sore !== null && sore >= STEP_RULES.sorenessHigh) fatigue.push('soreness ' + sore + '/10');
    if (pain !== null && pain >= STEP_RULES.painHigh) fatigue.push('pain ' + pain + '/10');
    if (ready !== null && ready <= STEP_RULES.readinessLow) fatigue.push('readiness ' + ready + '/10');
    var light = !(ctx.plannedToday > 0) && !worked.some(function (s) { return s.date === date; });
    var rules = effectiveRules(ctx.settings);
    var factor = 1, reason = 'Training day: baseline target.';
    if (fatigue.length) { factor = 1 + rules.highFatiguePct / 100; reason = 'Recovery first (' + fatigue.join(', ') + '): target lowered ' + (-rules.highFatiguePct) + '%.'; }
    else if (demanding.length) { factor = 1 + rules.afterDemandingPct / 100; reason = 'Demanding session ' + (demanding.some(function (s) { return s.date === date; }) ? 'today' : 'yesterday') + ': target lowered ' + (-rules.afterDemandingPct) + '%.'; }
    else if (light) { factor = 1 + rules.lightDayPct / 100; reason = 'Light day (no session planned or logged): target raised ' + rules.lightDayPct + '%.'; }
    // Recovery and the v2.1 §6 readiness gate come first: a FAILED gate (any week) or an UNKNOWN gate in
    // Week 4 never lets the suggestion rise above the baseline.
    var gate = tenKGate(date, dailies), gWeek = refWeek(date), gateHold = null;
    if (gate.status === 'FAIL') gateHold = 'READINESS_GATE_FAILED';
    else if (gWeek === 4 && gate.status === 'UNKNOWN') gateHold = 'READINESS_GATE_UNKNOWN';
    if (gateHold && factor > 1) { factor = 1; reason = 'No light-day increase: ' + (gateHold === 'READINESS_GATE_FAILED' ? 'the morning readiness check failed (' + gate.failed.join(', ') + ').' : 'the Week 4 readiness check is incomplete.'); }
    // An invalid stored soreness / pain / readiness value is unknown recovery: never a reason to raise.
    if (badRecovery.length && factor > 1) { factor = 1; reason = 'No light-day increase: the stored ' + badRecovery.join(', ') + ' value is invalid, so recovery is unknown.'; }
    factor = Math.round(factor * 1000) / 1000;
    var unknown = [];
    if (sore === null) unknown.push('soreness'); if (ready === null) unknown.push('readiness');
    if (badRecovery.indexOf('pain') !== -1) unknown.push('pain');
    var adaptive = base.value === null ? null : roundSteps(base.value * factor);
    var ov = rec && typeof rec.stepTargetOverride === 'number' ? rec.stepTargetOverride : null;
    var target = ov !== null ? ov : adaptive;
    var met = target === null || steps.value === null ? null : steps.value >= target ? true : (steps.partial ? null : false);
    return { date: date, target: target, source: ov !== null ? 'OVERRIDE' : adaptive !== null ? 'ADAPTIVE' : 'NONE',
      adaptive: adaptive, override: ov, baseline: base, factor: factor, reason: reason,
      recoveryUnknown: unknown, steps: steps, met: met,
      note: 'Targets never rise to make up for missed or low days. Percentages are app defaults, not source values.',
      kind: 'ADAPTIVE_GUIDANCE', gateHold: gateHold,
      heuristics: { label: HEURISTICS_LABEL, fromSource: false, configurable: true, rules: rules },
      // Conservative fallback: with sparse measured history and no manual baseline, no number is invented.
      fallback: base.value === null && ov === null ? { code: 'SPARSE_HISTORY', target: null,
        text: 'Not enough measured step history for an adaptive suggestion, so none is made (no number is invented). Use the plan reference goal, shown separately, and your own tolerance.' } : null };
  }

  // ---------- owner decision 1 (t47u): v2.1 section 6 REFERENCE GOALS, separate from the adaptive guidance ----------
  var STEP_REFERENCE = Object.freeze({ planVersion: 'v2.1', source: 'HNC-BASE-v2.1 §6', day0: '2026-11-15',
    weeks: Object.freeze({
      1: Object.freeze({ from: '2026-11-16', to: '2026-11-22', goal: 7000, kind: 'FLOOR' }),
      2: Object.freeze({ from: '2026-11-23', to: '2026-11-29', goal: 8000, kind: 'FLOOR' }),
      3: Object.freeze({ from: '2026-11-30', to: '2026-12-06', goal: 9000, kind: 'FLOOR' }),
      4: Object.freeze({ from: '2026-12-07', to: '2026-12-13', goal: 10000, kind: 'TARGET_IF_TOLERATED' }) }),
    gate: Object.freeze({ footPainMax: 2, stairKneePainMax: 2, sleepMinH: 6, limpAllowed: false }) });

  function obsBool(rec, k) {
    var o = rec && rec[k];
    return o && o.state === 'OBSERVED' && typeof o.value === 'boolean' ? o.value : null;
  }

  // v2.1 section 6 morning readiness check from plain values (null/undefined = not recorded).
  // values: { heelArchAchillesPain|footPain, limp, stairKneePain, sleepH }
  function step10kGate(values) {
    values = values || {};
    var G = STEP_REFERENCE.gate;
    function num(v) { return typeof v === 'number' && isFinite(v) ? v : null; }
    // Pain is a 0-10 scale (owner decisions F9 + t54u): ANY reading outside 0-10 (negative or above 10) is
    // invalid, so it is UNKNOWN and can never PASS. A real failure on another input (e.g. limp) still wins.
    function pain(v) { var n = num(v); return n !== null && (n < 0 || n > 10) ? null : n; }
    var rawFoot = values.footPain !== undefined ? values.footPain : values.heelArchAchillesPain;
    var foot = pain(rawFoot);
    var limp = typeof values.limp === 'boolean' ? values.limp : null;
    // Sleep is hours in a day: a value outside 0-24 is invalid (UNKNOWN), never a pass.
    var knee = pain(values.stairKneePain), sleep = num(values.sleepH);
    if (sleep !== null && (sleep < 0 || sleep > 24)) sleep = null;
    function r(bad) { return bad === null ? 'UNKNOWN' : bad ? 'FAIL' : 'PASS'; }
    var checks = [
      { key: 'footPain', label: 'First-step heel/arch/Achilles pain ≤ 2/10', value: foot, limit: G.footPainMax, result: r(foot === null ? null : foot > G.footPainMax) },
      { key: 'limp', label: 'No limp', value: limp, limit: G.limpAllowed, result: r(limp === null ? null : limp) },
      { key: 'stairKneePain', label: 'Stair knee pain ≤ 2/10', value: knee, limit: G.stairKneePainMax, result: r(knee === null ? null : knee > G.stairKneePainMax) },
      { key: 'sleepH', label: 'At least 6 h sleep', value: sleep, limit: G.sleepMinH, result: r(sleep === null ? null : sleep < G.sleepMinH) }
    ];
    var failed = checks.filter(function (c) { return c.result === 'FAIL'; }).map(function (c) { return c.key; });
    var missing = checks.filter(function (c) { return c.result === 'UNKNOWN'; }).map(function (c) { return c.key; });
    var status = failed.length ? 'FAIL' : missing.length ? 'UNKNOWN' : 'PASS';
    // Additive (t54u): inputs that were supplied but are not a valid value (subset of missing).
    var invalid = [];
    if (rawFoot != null && foot === null) invalid.push('footPain');
    if (values.limp != null && limp === null) invalid.push('limp');
    if (values.stairKneePain != null && knee === null) invalid.push('stairKneePain');
    if (values.sleepH != null && sleep === null) invalid.push('sleepH');
    return { status: status, pass: status === 'PASS', checks: checks, failed: failed, missing: missing, invalid: invalid, source: STEP_REFERENCE.source };
  }

  // The same check read from that day's daily record.
  function tenKGate(date, dailies) {
    var rec = (dailies || []).filter(function (d) { return d && d.date === date; })[0] || null;
    var g = step10kGate({ footPain: obs(rec, 'footPain'), limp: obsBool(rec, 'limp'), stairKneePain: obs(rec, 'stairKneePain'), sleepH: obs(rec, 'sleepH') });
    // A stored value marked INVALID was supplied but is unusable: report it as invalid, not merely missing.
    invalidFields(rec).forEach(function (k) { if (g.missing.indexOf(k) !== -1 && g.invalid.indexOf(k) === -1) g.invalid.push(k); });
    g.date = date;
    return g;
  }

  function refWeek(date) {
    if (date === STEP_REFERENCE.day0) return 0;
    for (var w = 1; w <= 4; w++) { var x = STEP_REFERENCE.weeks[w]; if (date >= x.from && date <= x.to) return w; }
    return null;
  }

  // ctx: { dailies, walks, sessions, recentSessions, toughDay }
  // Depends only on the date's plan week and that day's own records: no catch-up, earlier days never change it.
  function stepReferenceGoal(date, ctx) {
    ctx = ctx || {};
    var dailies = ctx.dailies || [];
    var rec = dailies.filter(function (d) { return d && d.date === date; })[0] || null;
    var week = refWeek(date);
    var wk = week ? STEP_REFERENCE.weeks[week] : null;
    var goal = wk ? wk.goal : null;
    var goalKind = week === 0 ? 'BASELINE_DAY' : wk ? wk.kind : 'NONE';
    var gate = tenKGate(date, dailies);
    var steps = daySteps(date, { dailies: dailies, walks: ctx.walks, sessions: ctx.sessions });
    var dnf = [];
    if (week !== null) {
      if (gate.status === 'FAIL') dnf.push('READINESS_GATE_FAILED');
      if (week === 4 && gate.status === 'UNKNOWN') dnf.push('READINESS_GATE_UNKNOWN');
      var pain = obs(rec, 'pain');
      if (pain !== null && pain > 3) dnf.push('PAIN_OVER_3');
      // An invalid stored pain value is unknown pain, so the goal is not pushed and no optional 10k is offered.
      if (invalidFields(rec).indexOf('pain') !== -1) dnf.push('PAIN_INVALID');
      if (readiness(date, dailies, ctx.settings).flags.length) dnf.push('READINESS_FLAGS');
      var tough = ctx.toughDay === true || (ctx.recentSessions || []).some(function (s) {
        if (!s || s.date !== date || ['COMPLETED', 'PARTIAL', 'IN_PROGRESS'].indexOf(s.status) === -1) return false;
        if (typeof s.rpe === 'number') return s.rpe >= STEP_RULES.demandingRpe;
        return s.type === 'INTERVALS' || s.type === 'RACE';
      });
      if (tough) dnf.push('TOUGH_TRAINING_DAY');
    }
    var status = goal === null ? 'NOT_APPLICABLE' : dnf.length ? 'DO_NOT_FORCE' : 'ACTIVE';
    var met = goal === null || steps.total === null ? null : steps.total >= goal ? true : steps.complete ? false : null;
    var opt;
    if (week === null) opt = { offered: false, reason: 'No current approved training block.' };
    else if (week === 4) opt = { offered: false, reason: 'Week 4: 10,000/day is the reference goal itself, only if tolerating volume.' };
    else if (gate.status === 'PASS' && !dnf.length) opt = { offered: true, reason: '10,000 steps is optional, not compulsory (readiness check passed).' };
    else opt = { offered: false, reason: gate.status === 'PASS' ? 'Not today: recovery or training load comes first.' : 'Optional 10k only when the morning readiness check passes; ' + (gate.status === 'FAIL' ? 'it failed (' + gate.failed.join(', ') + ').' : 'it is incomplete.') };
    var note = goal === null
      ? (week === 0 ? 'Day 0: baseline measurement day (v2.1 §6), no step goal.' : 'No current approved training block, so no plan reference goal.')
      : 'Plan reference goal from HNC-BASE v2.1 §6. Shown separately from the adaptive guidance; meeting a lower guidance target does not meet this goal. ' +
        (status === 'DO_NOT_FORCE' ? 'Do not force it today: reduce activity to tolerance. ' : '') + 'Missed steps are never made up on later days.';
    return { date: date, kind: 'REFERENCE_GOAL', planVersion: STEP_REFERENCE.planVersion, source: STEP_REFERENCE.source,
      week: week, goalKind: goalKind, goal: goal, value: goal, status: status, doNotForce: dnf, gate: gate, optional10k: opt,
      steps: steps, met: met, note: note };
  }

  // Both outputs side by side, separately labelled.
  function stepGoals(date, ctx) {
    var ref = stepReferenceGoal(date, ctx);
    return { date: date, reference: ref, guidance: stepTarget(date, ctx), steps: ref.steps,
      note: 'Plan reference goal (v2.1 §6) and adaptive guidance (app suggestion) are separate; neither satisfies the other.' };
  }

  function weekStart(iso) {
    var dow = new Date(iso + 'T00:00:00Z').getUTCDay(); // 0 = Sunday
    return addDays(iso, -((dow + 6) % 7));
  }

  // Weekly step trend and consistency for the `weeks` Mon-Sun weeks ending with the week of `endDate`.
  // Only declared daily totals count as recorded; missing days are reported as missing, never as 0.
  // targetFor(date) -> number|null (optional).
  function weeklySteps(endDate, dailies, targetFor, weeks) {
    var out = [], start = weekStart(endDate);
    for (var w = (weeks || 4) - 1; w >= 0; w--) {
      var ws = addDays(start, -7 * w), vals = [], missing = 0, met = 0, judged = 0, elapsed = 0;
      for (var i = 0; i < 7; i++) {
        var d = addDays(ws, i);
        if (d > endDate) break;
        elapsed++;
        var v = obs((dailies || []).filter(function (x) { return x.date === d; })[0], 'steps');
        if (v === null) { missing++; continue; }
        vals.push(v);
        var t = typeof targetFor === 'function' ? targetFor(d) : null;
        if (typeof t === 'number') { judged++; if (v >= t) met++; }
      }
      out.push({ weekStart: ws, daysElapsed: elapsed, daysRecorded: vals.length, daysMissing: missing,
        mean: vals.length ? Math.round(vals.reduce(function (a, b) { return a + b; }, 0) / vals.length) : null,
        total: vals.length ? vals.reduce(function (a, b) { return a + b; }, 0) : null,
        daysMetTarget: judged ? met : null, daysWithTarget: judged });
    }
    return out;
  }

  // [{date, value}] sorted ascending, only real observations.
  function series(records, getter) {
    return records.map(function (r) { return { date: r.date, value: getter(r) }; })
      .filter(function (p) { return typeof p.value === 'number' && isFinite(p.value); })
      .sort(function (a, b) { return a.date < b.date ? -1 : a.date > b.date ? 1 : 0; });
  }

  function stats(points) {
    if (!points.length) return { n: 0, first: null, last: null, change: null, min: null, max: null };
    var vals = points.map(function (p) { return p.value; });
    return { n: points.length, first: points[0], last: points[points.length - 1],
      change: Math.round((vals[vals.length - 1] - vals[0]) * 10) / 10,
      min: Math.min.apply(null, vals), max: Math.max.apply(null, vals) };
  }

  return { SAFETY: SAFETY, readiness: readiness, rhrBaseline: rhrBaseline, rhrAssessment: rhrAssessment, canonicalSteps: canonicalSteps, daySteps: daySteps,
    STEP_RULES: STEP_RULES, stepBaseline: stepBaseline, stepTarget: stepTarget, weeklySteps: weeklySteps,
    STEP_REFERENCE: STEP_REFERENCE, step10kGate: step10kGate, tenKGate: tenKGate, stepReferenceGoal: stepReferenceGoal,
    stepGoals: stepGoals, RHR_LABELS: RHR_LABELS, effectiveStepRules: effectiveRules,
    series: series, stats: stats, obs: obs };
});
