/*
 * hyrox-nutrition.js - meal totals with KNOWN/ESTIMATED/UNKNOWN provenance and day states D1–D5.
 * Pure functions. UNKNOWN is null, never 0. Only CONFIRMED meals count.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.HyroxNutrition = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var MACROS = ['kcal', 'proteinG', 'carbsG', 'fatG'];
  var PROVISIONAL = { kcal: 2400, proteinG: 190, proteinFloorG: 170,
    note: 'Provisional example targets from the training source — NOT measured TDEE and NOT authorization for automatic adjustment.' };
  var DAY_LABEL = { D1: 'D1 Unlogged', D2: 'D2 In progress', D3: 'D3 Declared incomplete',
    D4: 'D4 Complete, not fully quantified', D5: 'D5 Complete and quantified',
    // Owner rule 3: only an explicit confirmation makes a fasting day. Kept apart from D1-D5 eating days.
    DF: 'Confirmed full-day fast (0 kcal)' };
  var EATEN_PRESETS = [0.25, 0.5, 0.75, 1];
  var CANONICAL_CODES = ['D1', 'D2', 'D3', 'D4', 'D5'];

  function unknown() { return { value: null, state: 'UNKNOWN' }; }
  function macro(v, state) {
    if (v === '' || v === null || v === undefined) return unknown();
    return { value: Number(v), state: state === 'KNOWN' ? 'KNOWN' : 'ESTIMATED' };
  }

  function round1(n) { return Math.round(n * 10) / 10; }

  // Owner rule 2. Fraction of a component actually eaten: the item's own value if set, otherwise the
  // meal-level value. Returns null when nobody has stated it for a photographed meal - a photo is
  // never assumed to have been eaten whole. Non-photo meals default to 1 (the owner typed what they ate).
  function eatenFractionOf(meal, c) {
    if (c && typeof c.eatenFraction === 'number') return c.eatenFraction;
    if (meal && typeof meal.eatenFraction === 'number') return meal.eatenFraction;
    return meal && meal.source === 'PHOTO_AI' ? null : 1;
  }
  function fractionStated(meal) {
    return (meal.components || []).every(function (c) { return eatenFractionOf(meal, c) !== null; });
  }

  // Sum of components * eaten fraction, applied to every macro alike.
  // state: KNOWN | ESTIMATED | PARTIAL (some unknown) | UNKNOWN. An unstated fraction counts as unknown.
  function mealTotals(meal) {
    var out = {};
    MACROS.forEach(function (k) {
      var sum = 0, known = 0, est = 0, unk = 0;
      (meal.components || []).forEach(function (c) {
        var m = c[k];
        var f = eatenFractionOf(meal, c);
        if (!m || m.state === 'UNKNOWN' || m.value === null || f === null) { unk++; return; }
        sum += m.value * f;
        if (m.state === 'KNOWN') known++; else est++;
      });
      var state = unk && !(known + est) ? 'UNKNOWN' : unk ? 'PARTIAL' : est ? 'ESTIMATED' : 'KNOWN';
      out[k] = { value: state === 'UNKNOWN' ? null : round1(sum), state: state, unknownCount: unk };
    });
    return out;
  }

  function completeness(meal) {
    if (meal.lifecycle !== 'CONFIRMED') return null;
    var t = mealTotals(meal);
    return MACROS.every(function (k) { return t[k].state !== 'UNKNOWN' && t[k].state !== 'PARTIAL'; })
      ? 'CONFIRMED_COMPLETE' : 'CONFIRMED_INCOMPLETE';
  }

  // Phase 1/2 entries: kcal + protein known, carbs/fat unknown. Treated as confirmed.
  function legacyToMeal(e) {
    return { id: 'legacy:' + e.id, legacy: true, date: e.date, createdAt: e.createdAt, updatedAt: e.createdAt,
      label: e.label || 'Entry', source: 'MANUAL', lifecycle: 'CONFIRMED', confirmedAt: e.createdAt,
      components: [{ name: e.label || 'Entry', role: 'MAIN', kcal: { value: e.calories, state: 'KNOWN' },
        proteinG: { value: e.proteinG, state: 'KNOWN' }, carbsG: unknown(), fatG: unknown() }] };
  }

  function hash(s) {
    var h = 5381;
    for (var i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0;
    return (h >>> 0).toString(36);
  }

  // Basis changes whenever any confirmed or consumed-intent meal on the day changes.
  function dayBasis(meals) {
    var rel = meals.filter(function (m) { return m.lifecycle === 'CONFIRMED' || m.lifecycle === 'CONSUMED_INTENT'; })
      .map(function (m) { return m.id + '|' + m.lifecycle + '|' + (m.updatedAt || m.createdAt) + '|' + m.date + '|' + JSON.stringify(mealTotals(m)); })
      .sort();
    return rel.length + ':' + hash(rel.join('\n'));
  }

  function dayState(date, mealsForDay, attestation) {
    var meals = mealsForDay.filter(function (m) { return m.date === date; });
    var confirmed = meals.filter(function (m) { return m.lifecycle === 'CONFIRMED'; });
    var pending = meals.filter(function (m) { return m.lifecycle === 'CONSUMED_INTENT'; });
    var drafts = meals.filter(function (m) { return m.lifecycle === 'DRAFT' || m.lifecycle === 'NEEDS_REVIEW'; });
    var basis = dayBasis(meals);
    var stale = !!attestation && attestation.basis !== basis;
    var att = attestation && !stale ? attestation.attestation : null;

    var sub = {};
    MACROS.forEach(function (k) {
      var s = 0, unk = 0, any = false;
      confirmed.forEach(function (m) {
        var t = mealTotals(m)[k];
        if (t.value !== null) { s += t.value; any = true; }
        if (t.unknownCount) unk++;
      });
      sub[k] = { value: any ? round1(s) : null, mealsWithUnknown: unk };
    });

    // Water-only: nothing with calories is recorded (no meals at all, or only confirmed items that
    // are known to be exactly 0 kcal) and nothing is waiting for confirmation or review.
    // This describes what is RECORDED. It is never taken to mean that nothing was eaten.
    var waterOnly = !pending.length && !drafts.length && confirmed.every(function (m) {
      var t = mealTotals(m).kcal;
      return t.state !== 'UNKNOWN' && t.state !== 'PARTIAL' && t.value === 0;
    });
    var fastAnswer = attestation && !stale && attestation.fast ? attestation.fast : null;
    var fastConfirmed = waterOnly && att === 'COMPLETE' && fastAnswer === 'CONFIRMED_FULL_DAY_FAST';

    // canonicalCode: the D1-D5 code computed WITHOUT the fast branch (DAWIT 3, additive). It is what
    // a D1-D5-only consumer would derive from the same stored records; for a confirmed fast it is D4.
    var canonicalCode;
    if (att === 'INCOMPLETE') canonicalCode = 'D3';
    else if (att === 'COMPLETE' && !pending.length) {
      var quantified = confirmed.length > 0 && sub.kcal.mealsWithUnknown === 0 && sub.kcal.value !== null && sub.kcal.value > 0;
      canonicalCode = quantified ? 'D5' : 'D4';
    } else if (!confirmed.length && !pending.length) canonicalCode = 'D1';
    else canonicalCode = 'D2';
    // Unchanged state contract: DF replaces the code only for an explicitly confirmed fast.
    var code = att !== 'INCOMPLETE' && fastConfirmed ? 'DF' : canonicalCode;

    // Full-day calories: a number only for a complete quantified eating day, exactly 0 only for a
    // confirmed fast, otherwise null (unknown) - never 0 because meals are missing.
    var dayKcal = code === 'D5' ? sub.kcal.value : code === 'DF' ? 0 : null;

    return { date: date, code: code, canonicalCode: canonicalCode, label: DAY_LABEL[code], basis: basis, staleAttestation: stale,
      confirmedCount: confirmed.length, pendingCount: pending.length, draftCount: drafts.length,
      subtotal: sub, fullDay: code === 'D5', fastDay: code === 'DF', dayKcal: dayKcal,
      waterOnly: waterOnly, fastAnswer: fastAnswer,
      // The fast-or-not-logged question is still open for this day.
      fastQuestionOpen: waterOnly && fastAnswer === null,
      caveat: code === 'D5' ? 'Complete, quantified day (estimates included where marked).' :
        code === 'DF' ? 'You confirmed a full-day fast: 0 kcal. Tracked with fasting days, not in eating-day averages.' :
        waterOnly ? 'No food is recorded for this day. Calories are unknown (not 0) unless you confirm a full-day fast. Not in any average.' :
        'Known confirmed subtotal only — excludes unknown, unconfirmed and unlogged intake. Not a full-day total.' };
  }

  // Owner rule 3: eating-day averages use complete quantified eating days (D5) only. Confirmed
  // fasting days are a separate cohort. Every other day is excluded - unknown is never averaged as 0.
  function dayAverages(states) {
    function mean(vals) { return vals.length ? round1(vals.reduce(function (a, b) { return a + b; }, 0) / vals.length) : null; }
    var eating = states.filter(function (s) { return s.code === 'D5'; });
    var fasting = states.filter(function (s) { return s.code === 'DF'; });
    return {
      eatingDays: { n: eating.length, kcalMean: mean(eating.map(function (s) { return s.subtotal.kcal.value; })),
        proteinMean: mean(eating.map(function (s) { return s.subtotal.proteinG.value; }).filter(function (v) { return v !== null; })) },
      fastingDays: { n: fasting.length, dates: fasting.map(function (s) { return s.date; }).sort() },
      excluded: { n: states.length - eating.length - fasting.length,
        note: 'Days that are unlogged, in progress, incomplete, not fully quantified or unanswered are excluded, not counted as 0.' }
    };
  }

  // A fast can be confirmed only on a water-only day; drafts and unconfirmed meals must be settled first.
  function canConfirmFast(state) {
    if (state.pendingCount > 0 || state.draftCount > 0) return { ok: false, reason: 'Confirm or delete the unconfirmed meals for this day first.' };
    if (!state.waterOnly) return { ok: false, reason: 'Food with calories (or unknown calories) is recorded for this day, so it is not a full-day fast.' };
    return { ok: true };
  }

  function canAttest(state) {
    if (state.pendingCount > 0) return { ok: false, reason: 'Confirm or discard meals marked "I ate this" first.' };
    return { ok: true };
  }

  return { MACROS: MACROS, PROVISIONAL: PROVISIONAL, DAY_LABEL: DAY_LABEL, unknown: unknown, macro: macro,
    mealTotals: mealTotals, completeness: completeness, legacyToMeal: legacyToMeal, dayBasis: dayBasis,
    dayState: dayState, canAttest: canAttest, EATEN_PRESETS: EATEN_PRESETS, eatenFractionOf: eatenFractionOf,
    fractionStated: fractionStated, dayAverages: dayAverages, canConfirmFast: canConfirmFast, CANONICAL_CODES: CANONICAL_CODES };
});
