# Food database provenance (src/data/food-db.json, src/data/food-db.js)

Generated file. Do not edit by hand. Rebuild with `tools/food-db/build_food_db.py` (see below).

## Sources
| Dataset | Release | Input file (as downloaded, never modified) | sha256 of the input file |
|---|---|---|---|
| USDA FoodData Central, SR Legacy (CSV) | 2018-04 (final release) | `FoodData_Central_sr_legacy_food_csv_2018-04.zip` | `b80817294b8850530aaedf2e515c02593b1824f763a0ff356e5c2081643e6fd0` |
| USDA FoodData Central, Foundation Foods (JSON) | 2026-10-29 | `FoodData_Central_foundation_food_json_2026-10-29.zip` | `dd414cc9f1a132626bad354ef6655972c78b44aff14f16114dc899708663c579` |

Download page: https://fdc.nal.usda.gov/download-datasets (free, no account, no API key). The same hashes are written into `meta.sources[].sha256` of the database, and a test re-checks them when the zips are present.

## Licence and citation
USDA FoodData Central data are in the public domain, published under **CC0 1.0 Universal**. No permission is needed. USDA asks that FoodData Central is cited:
"U.S. Department of Agriculture, Agricultural Research Service. FoodData Central. fdc.nal.usda.gov."
(The same text is in `meta.license` / `meta.citation`.) Show the citation in the UI wherever estimates are explained.

## What is in it
- 8,167 foods: 7,793 SR Legacy (`"SR"`) + 374 Foundation (`"FF"`). `fdcId` is unique per dataset; the pair (dataset, fdcId) is the key.
- Row: `[fdcId, dataset, description, kcal, proteinG, carbsG, fatG, [[amount, "unit text", grams], ...]]`, all values per 100 g.
- Energy: SR nutrient id 1008 (else 2047, else 2048 = Atwater general / specific factors); Foundation number 208 (else 957, else 958). Protein 1003/203, carbohydrate by difference 1005/205, total fat 1004/204.
- Kcal rounded to 1 decimal, macros to 2 decimals (integral values stored as integers). Portions: amount to 4 decimals, grams to 2 decimals; rows with a non-positive amount or weight are dropped. In SR Legacy the unit text is USDA's `modifier` (e.g. "cup, chopped", "large"); in Foundation the measure unit name plus modifier.
- Deterministic: no timestamps, SR rows by fdcId then Foundation rows by fdcId, ASCII-only escapes (safe for `file://` and any charset). Rebuilding twice gives byte-identical files (tested).
- Size: about 1.07 MB raw, about 256 KB gzip for each of the two files. It is a static file, not localStorage, and is loaded only when estimation is used.

## Exclusions (never filled)
A food missing any of energy, protein, carbohydrate or fat is left out, never estimated: 50 Foundation foods (0 SR). The count is in `meta.excludedCount` and per source.

## Caveats (keep these visible to the user)
- Values describe USDA's reference food per 100 g. Real dishes, brands and home cooking vary; every number is an ESTIMATE, always editable, and nothing counts toward day totals until the owner confirms the meal.
- Energy uses Atwater factors and carbohydrate is "by difference"; do not claim laboratory precision. Ten Foundation raw meat/fish rows have a tiny negative carbohydrate-by-difference (-0.06 to -0.7 g, USDA's own value, kept as published in the DB). The estimator counts it as 0 g because the meals validator accepts only 0 or more.
- Foundation Foods lists 263 "RACC" (regulatory reference amount) portion rows. They are kept for completeness but are never chosen automatically.
- SR Legacy is analytic and never updated after 2018. Middle-Eastern and mixed dishes (shawarma, machboos, karak tea, labneh) are patchy or absent: the app answers "no match", it does not guess.
- Branded foods, FNDDS survey dishes and Open Food Facts are not included.

## How to rebuild
```
python3 tools/food-db/build_food_db.py                 # reads /workspace/hyrox-p6/food-data-feasibility/*.zip, writes src/data/food-db.{json,js}
python3 tools/food-db/build_food_db.py --src DIR --out DIR2
```
Python standard library only, no network. After a rebuild run `node --test tests/p6-dawit-food-db.test.js tests/p6-dawit-foodcalc.test.js`; the alias table in `hyrox-foodcalc.js` refers to fdcIds that must still exist (a test checks it).
A new USDA release needs a new `dbVersion`/file names in the script, a review of the 50-60 sample foods against the FDC web pages (Meron), and a re-check of the alias table.

## Deployment
`src/data/food-db.js` (classic script, sets `window.HyroxFoodDb`) and `src/data/hyrox-foodcalc.js` must be added to `DEPLOY-FILES.txt`. `food-db.json` is the canonical artifact for Node tests; the page does not need it.
