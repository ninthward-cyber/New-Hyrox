/*
 * hyrox-plan.js - source-faithful HYROX Block v2.1 (sanitized excerpt), pure functions.
 * 20 programmed Mon–Fri slots, 16 Nov – 11 Dec 2026 (Week 1 = 16–22 Nov, Week 4 deload = 7–13 Dec, block ends Sun 13 Dec).
 * Re-anchored in Phase 8 (+7 days) from 9 Nov – 6 Dec; slot ids (v2.1-W*-DAY) are unchanged. No Block 2.
 * Never invents loads; never auto-skips; cascades only from explicit user plan events.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.HyroxPlan = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var PLAN_VERSION = 'v2.1';
  // Phase 8 re-anchor (owner request 14 Nov 2026): first use is Monday 16 Nov. Same program, same progression,
  // same 20 slots and ids; only the calendar dates moved by +7 days. Asia/Qatar local dates throughout.
  var BLOCK_START = '2026-11-16';   // Monday of Week 1
  var DAY0 = '2026-11-15';          // source Day 0 (Sunday)
  var BLOCK_END = '2026-12-13';     // Sunday of Week 4 (deload)
  var PREVIOUS_ANCHOR = Object.freeze({ blockStart: '2026-11-09', day0: '2026-11-08', blockEnd: '2026-12-06' });
  var NO_BLOCK_TEXT = 'No current approved training block';
  var MACHINE_LIMIT_SEC = 900;
  var DAYS = ['MON', 'TUE', 'WED', 'THU', 'FRI'];
  var MACHINE_KINDS = ['skierg', 'row', 'bike', 'elliptical'];

  var DOW = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  var MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  // 'Mon 16 Nov 2026' from an ISO date (calendar arithmetic only, no time zone involved).
  function human(iso) {
    var d = new Date(Date.UTC(+iso.slice(0, 4), +iso.slice(5, 7) - 1, +iso.slice(8, 10)));
    return DOW[d.getUTCDay()] + ' ' + d.getUTCDate() + ' ' + MON[d.getUTCMonth()] + ' ' + d.getUTCFullYear();
  }
  function humanShort(iso) { return human(iso).slice(0, -5); }

  function addDays(iso, n) {
    var d = new Date(Date.UTC(+iso.slice(0, 4), +iso.slice(5, 7) - 1, +iso.slice(8, 10) + n));
    return d.toISOString().slice(0, 10);
  }

  function strengthA(w) {
    if (w === 1) return ['0–8 min warm-up: easy machine + mobility',
      'Back squat: progressive warm-up, then 2x5 @ RPE 6–7',
      'Bench press 2x5 + chest-supported DB row 2x8–10',
      'Back extension 2x12 + dead bug 2x8/side (optional in W1)',
      'Buffer, then 8 min cooldown', 'No heavy RDL in weeks 1–2'];
    var sets = w === 4 ? '2 work sets @ RPE 6–7 (deload)' : '3x5 @ RPE 7';
    return ['0–8 min warm-up: easy machine + mobility',
      'Back squat: progressive warm-up, then ' + sets,
      'Bench press ' + (w === 4 ? '2 work sets' : '3x5') + ' + chest-supported DB row ' + (w === 4 ? '2' : '3') + 'x8–10',
      'Back extension 2x12 + dead bug 2x8/side', 'Buffer, then 8 min cooldown',
      w === 2 ? 'No heavy RDL in weeks 1–2' : null].filter(Boolean);
  }

  function strengthB(w) {
    var dl = w === 1 ? '2x5 cap RPE 6' : w === 4 ? '2 work sets @ RPE 6–7 (deload)' : '3x5 @ RPE 7, cap RPE 8';
    var s = w === 1 || w === 4 ? '2 sets' : '3 sets';
    return ['Warm-up + hinge drills', 'Deadlift (conventional or trap bar) ' + dl,
      'Overhead press ' + (w === 1 || w === 4 ? '2' : '3') + 'x5 + pull-ups / lat pulldown ' + s + ' of 6–10',
      'Incline DB press 2x8–10 + farmer carries up to 3x30 m', 'Transition and cooldown',
      'RPE 7 ≈ 3 reps in reserve. Record actual loads only.'];
  }

  function intervals(w) {
    var rounds = { 1: 3, 2: 4, 3: 4, 4: 3 }[w];
    var run = w === 3 ? 500 : 400;
    return ['10 min warm-up',
      rounds + ' rounds: ' + run + ' m controlled run @ RPE 6, 250 m SkiErg, 90 s walking rest',
      'Then up to 3 rounds: 15 m sled push + 15 m sled pull, smooth light load, 90 s rest',
      'Record actual equipment, load, splits, omissions and partial completion'];
  }

  function aerobic(w) {
    var rw = { 1: '7x (1 min jog / 1 min walk) + 1 min walk', 2: '5x (2 min jog / 1 min walk)',
      3: '3x (4 min jog / 1 min walk)', 4: '5x (2 min jog / 1 min walk) (as W2)' }[w];
    return ['5 min warm-up', 'Treadmill run-walk ≤15 min: ' + rw,
      'Switch: rower 15 min easy (bike if back is tired)', 'SkiErg 10 min easy',
      'Remaining time: transitions / mobility. Distinct bouts with real machine changes.'];
  }

  function race(w) {
    var rounds = w === 1 ? 1 : 2;
    var bbj = w === 1 ? '5 m' : '10 m';
    var note = { 1: '', 2: ' (BENCHMARK 1)', 3: ' (progress only if recovered)', 4: ' (repeat W2 exactly — BENCHMARK 2)' }[w];
    return ['10 min warm-up',
      rounds + ' round' + (rounds > 1 ? 's' : '') + note + ': 400 m run + 250 m row + 20 m farmer carry + ' + bbj +
        ' burpee broad jumps + 20 m bodyweight lunges + 15 light wall balls',
      'Rest 3–4 min between rounds', 'Optional light sled technique, cooldown'];
  }

  function templateBlocks(type, w) {
    var b = [];
    function add(kind, label, extra) { var o = { kind: kind, label: label }; if (extra) Object.keys(extra).forEach(function (k) { o[k] = extra[k]; }); b.push(o); }
    if (type === 'STRENGTH_A') {
      add('warmup', 'Warm-up');
      ['Back squat', 'Bench press', 'Chest-supported DB row', 'Back extension', 'Dead bug'].forEach(function (x) { add('strength_set', x, { exercise: x, setType: 'WORKING' }); });
      add('cooldown', 'Cooldown');
    } else if (type === 'STRENGTH_B') {
      add('warmup', 'Warm-up / hinge drills');
      ['Deadlift', 'Overhead press', 'Pull-up / lat pulldown', 'Incline DB press'].forEach(function (x) { add('strength_set', x, { exercise: x, setType: 'WORKING' }); });
      add('farmer_carry', 'Farmer carry'); add('cooldown', 'Cooldown');
    } else if (type === 'INTERVALS') {
      add('warmup', 'Warm-up');
      var r = { 1: 3, 2: 4, 3: 4, 4: 3 }[w];
      for (var i = 1; i <= r; i++) { add('run', 'Round ' + i + ' run'); add('skierg', 'Round ' + i + ' SkiErg', { machine: true }); add('walk', 'Round ' + i + ' walk rest'); }
      add('sled_push', 'Sled push'); add('sled_pull', 'Sled pull');
    } else if (type === 'AEROBIC') {
      add('warmup', 'Warm-up'); add('run', 'Treadmill run-walk', { machine: true });
      add('row', 'Rower easy (bike if back tired)', { machine: true }); add('skierg', 'SkiErg easy', { machine: true });
      add('mobility', 'Transitions / mobility');
    } else if (type === 'RACE') {
      add('warmup', 'Warm-up');
      for (var j = 1; j <= (w === 1 ? 1 : 2); j++) {
        add('run', 'R' + j + ' run 400 m'); add('row', 'R' + j + ' row 250 m', { machine: true });
        add('farmer_carry', 'R' + j + ' farmer carry 20 m'); add('burpee_broad_jumps', 'R' + j + ' burpee broad jumps');
        add('lunges', 'R' + j + ' lunges 20 m'); add('wall_balls', 'R' + j + ' wall balls x15');
        if (j === 1 && w > 1) add('rest', 'Rest 3–4 min');
      }
      add('cooldown', 'Cooldown');
    }
    return b;
  }

  var DAY_TYPE_BY_TYPE = { STRENGTH_A: 1, INTERVALS: 1, STRENGTH_B: 1, AEROBIC: 1, RACE: 1 };
  var DAY_TYPE = { MON: ['STRENGTH_A', 'Strength A', strengthA], TUE: ['INTERVALS', 'Run / SkiErg intervals + light sled', intervals],
    WED: ['STRENGTH_B', 'Strength B', strengthB], THU: ['AEROBIC', 'Aerobic HYROX (run-walk / row / SkiErg)', aerobic],
    FRI: ['RACE', 'Race skills', race] };

  function buildSlots() {
    var slots = [];
    for (var w = 1; w <= 4; w++) {
      DAYS.forEach(function (d, i) {
        var t = DAY_TYPE[d];
        slots.push({ id: PLAN_VERSION + '-W' + w + '-' + d, planVersion: PLAN_VERSION, week: w, day: d,
          date: addDays(BLOCK_START, (w - 1) * 7 + i), type: t[0], title: t[1], durationMin: 60,
          prescription: t[2](w), benchmark: d === 'FRI' && (w === 2 || w === 4) ? (w === 2 ? 1 : 2) : null });
      });
    }
    return slots;
  }
  var SLOTS = buildSlots();

  function optionalWeekend(w) {
    if (w === 1) return null;
    return { week: w, date: addDays(BLOCK_START, (w - 1) * 7 + 5), counted: false,
      text: 'Optional (not counted): easy 15 min treadmill + 15 min bike + 15 min elliptical with transitions, OR modest easy jog intervals in an evening walk. Sunday mobility optional. Power Plate = mobility/warm-up only, not cardio or steps.' };
  }

  // Owner decision 2 (t47u): optional weekend activity is NOT a gym make-up and is never counted.
  function weekendOptions(w) {
    var sat = addDays(BLOCK_START, (w - 1) * 7 + 5), sun = addDays(BLOCK_START, (w - 1) * 7 + 6);
    return [
      { date: sat, day: 'SAT', kind: 'OPTIONAL_LIGHT_SATURDAY', available: w >= 2, counted: false, gymMakeUp: false,
        text: w >= 2 ? 'Optional, easy (RPE 3–4): 15 min treadmill + 15 min bike + 15 min elliptical, OR easy jog intervals in the evening walk. Not a make-up for a missed gym session.'
          : 'Week 1: no Saturday machines (source).' },
      { date: sun, day: 'SUN', kind: 'SUNDAY_MOBILITY', available: true, counted: false, gymMakeUp: false,
        text: 'Optional 15–20 min mobility. No gym required. Not a make-up for a missed gym session.' }
    ];
  }
  function isWeekend(iso) { var d = new Date(iso + 'T00:00:00Z').getUTCDay(); return d === 0 || d === 6; }

  function slotById(id) { for (var i = 0; i < SLOTS.length; i++) if (SLOTS[i].id === id) return SLOTS[i]; return null; }
  function slotForDate(date) { return SLOTS.filter(function (s) { return s.date === date; })[0] || null; }

  function blockStatus(date) {
    if (date > BLOCK_END) return { active: false, text: NO_BLOCK_TEXT };
    if (date < DAY0) return { active: false, text: 'Block ' + PLAN_VERSION + ' starts ' + human(BLOCK_START) + ' (source Day 0 ' + humanShort(DAY0) + ').' };
    if (date === DAY0) return { active: true, week: 0, text: 'Block ' + PLAN_VERSION + ' — source Day 0 (' + humanShort(DAY0) + ').' };
    var diff = Math.round((Date.parse(date) - Date.parse(BLOCK_START)) / 86400000);
    var week = Math.floor(diff / 7) + 1;
    return { active: true, week: week, text: 'Block ' + PLAN_VERSION + ' (conditional approval, not medical clearance) — Week ' + week + ' of 4. Ends ' + human(BLOCK_END) + '.' };
  }

  // ---------- Phase 8 re-anchor: how records made under the previous dates (9 Nov – 6 Dec) stay interpretable ----------
  // Nothing is rewritten, moved or deleted. Slot ids (v2.1-W*-DAY) are unchanged; only slot DATES moved by +7 days.
  //  * A saved session keeps its own `date` and appears in History exactly as before. A session linked to a plan slot
  //    but dated BEFORE source Day 0 (15 Nov) was made under the old calendar (staging test use): it is a "pre-block
  //    entry". It is kept and listed, but it does not stand in for the new block's slot (no false progress).
  //  * A saved plan event (missed Monday / Wednesday) keeps its record. One dated before Day 0 (or, with no date,
  //    created before Day 0) belongs to the old calendar and does not reshape the new Week 1-4 schedule.
  // Both rules are pure date comparisons, so they need no stored marker and cannot be applied twice.
  function isPreBlockSession(s) { return !!s && typeof s.planSlotId === 'string' && typeof s.date === 'string' && s.date < DAY0; }
  function isPreBlockEvent(e) {
    if (!e) return false;
    if (typeof e.date === 'string') return e.date < DAY0;
    return typeof e.createdAt === 'string' && e.createdAt.slice(0, 10) < DAY0;
  }
  function preBlockSessions(sessions) { return (sessions || []).filter(isPreBlockSession); }
  function preBlockEvents(events) { return (events || []).filter(isPreBlockEvent); }
  function currentEvents(events) { return (events || []).filter(function (e) { return !isPreBlockEvent(e); }); }

  // Effective weekday schedule for a week given explicit user plan events.
  function effectiveWeek(week, events) {
    var evs = currentEvents(events).filter(function (e) { return e.week === week; });
    var mon = evs.some(function (e) { return e.kind === 'MISSED_MONDAY'; });
    var wed = evs.some(function (e) { return e.kind === 'MISSED_WEDNESDAY'; });
    var slots = SLOTS.filter(function (s) { return s.week === week; });
    var by = {}; slots.forEach(function (s) { by[s.day] = s; });
    var days = slots.map(function (s) { return { date: s.date, day: s.day, show: [{ slot: s, movedFrom: null }], omitted: [] }; });
    var dayIdx = { MON: 0, TUE: 1, WED: 2, THU: 3, FRI: 4 };
    var unresolved = null;
    if (mon && wed) {
      unresolved = 'Both Monday and Wednesday marked missed: the source has no rule for this. Nothing was moved or omitted — decide manually.';
    } else if (mon) {
      days[0].show = [];
      days[1].show = [{ slot: by.MON, movedFrom: 'MON' }];
      days[3].show = [{ slot: by.TUE, movedFrom: 'TUE' }];
      days[3].omitted = [{ slot: by.THU, reason: 'MISSED_MONDAY_CASCADE' }];
    } else if (wed) {
      days[2].show = [];
      days[3].show = [{ slot: by.WED, movedFrom: 'WED' }];
      days[3].omitted = [{ slot: by.THU, reason: 'MISSED_WEDNESDAY_CASCADE' }];
    }
    void dayIdx;
    return { week: week, days: days, unresolved: unresolved, weekend: optionalWeekend(week),
      fridayNote: 'If Friday is missed: skip it, no weekend make-up (source rule). No missed weekday gym session is made up on a weekend. Never stack two hard sessions.',
      weekendMakeUp: false, weekendOptions: weekendOptions(week) };
  }

  function omissionFor(slotId, events) {
    var s = slotById(slotId);
    if (!s || s.day !== 'THU') return null;
    var eff = effectiveWeek(s.week, events);
    var o = eff.days[3].omitted[0];
    return o ? o.reason : null;
  }

  // Statuses that record work actually done (or under way).
  var ACTUAL_WORK = ['COMPLETED', 'PARTIAL', 'IN_PROGRESS'];
  function isActualWork(s) { return !!s && ACTUAL_WORK.indexOf(s.status) !== -1; }

  function byNewest(a, b) { return String(b.updatedAt || b.createdAt) < String(a.updatedAt || a.createdAt) ? -1 : 1; }

  // The session that speaks for a slot: the newest record of actual work if there is one,
  // otherwise the newest record. A later skip / reschedule note never hides work that was done.
  function latestFor(slotId, sessions) {
    var m = (sessions || []).filter(function (x) { return x.planSlotId === slotId && !isPreBlockSession(x); });
    var work = m.filter(isActualWork).sort(byNewest);
    if (work.length) return work[0];
    m.sort(byNewest);
    return m[0] || null;
  }

  // Two independent facts are reported and neither hides the other:
  //   omission -> the source cascade omitted the PRESCRIBED slot (never a user skip)
  //   session  -> what was ACTUALLY logged for the slot, whenever it was entered
  // code is the logged status when a session exists; SOURCE_OMITTED only when nothing was done.
  // Owner decision 2 (t47u): a weekday slot's work actually performed on a Sat/Sun is real ACTUAL work,
  // but it is not a source-approved make-up, so it never relabels the weekday prescription.
  function weekendWorkFor(slotId, sessions) {
    return (sessions || []).filter(function (x) { return x && x.planSlotId === slotId && !isPreBlockSession(x) && isActualWork(x) && typeof x.date === 'string' && isWeekend(x.date); });
  }
  function slotSessions(slotId, sessions) {
    var wk = weekendWorkFor(slotId, sessions);
    return wk.length ? (sessions || []).filter(function (x) { return wk.indexOf(x) === -1; }) : (sessions || []);
  }

  function slotStatus(slotId, sessions, events) {
    var om = omissionFor(slotId, events) || null;
    var weekendWork = weekendWorkFor(slotId, sessions);
    var s = latestFor(slotId, slotSessions(slotId, sessions));
    var out;
    if (!s) out = om ? { code: 'SOURCE_OMITTED', reason: om, omission: om, session: null } : { code: 'NOT_LOGGED', omission: null, session: null };
    else out = slotStatusFor(s, om);
    if (weekendWork.length) {
      out.weekendWork = weekendWork.slice().sort(byNewest);
      out.offPlan = 'WEEKEND_ACTUAL_NOT_SOURCE_RESCHEDULE';
      out.offPlanNote = 'Work logged on a weekend is kept as actual work, but it is not a source-approved make-up; the weekday prescription keeps its own status.';
    }
    return out;
  }

  function slotStatusFor(s, om) {
    var out = { code: s.status, modified: !!s.modified, variant: s.variant, session: s, omission: om };
    if (s.variantKind) out.variantKind = s.variantKind;
    if (typeof s.prescribedDurationMin === 'number') out.prescribedDurationMin = s.prescribedDurationMin;
    if (om) {
      out.reason = om;
      if (s.status === 'NOT_STARTED') out.code = 'SOURCE_OMITTED';
      else if (isActualWork(s)) out.conflict = 'ACTUAL_SESSION_ON_SOURCE_OMITTED_SLOT';
    }
    if (s.status === 'SKIPPED') {
      out.skipDecision = s.skipDecision || null;
      out.rescheduledTo = s.skipDecision === 'RESCHEDULE' ? s.rescheduledTo || null : null;
      if (out.rescheduledTo && isWeekend(out.rescheduledTo)) out.rescheduleNotSourceApproved = true;
    }
    return out;
  }

  // Honest list of places where explicit cascade events and logged sessions disagree.
  // Nothing is changed or hidden; these are shown so the owner can decide.
  function cascadeConflicts(week, sessions, events) {
    var out = [];
    var evs = currentEvents(events).filter(function (e) { return e.week === week; });
    function ev(kind) { return evs.filter(function (e) { return e.kind === kind; })[0] || null; }
    function slot(day) { return SLOTS.filter(function (s) { return s.week === week && s.day === day; })[0]; }
    function after(e, s) { return !!e && !!s && String(e.createdAt || '') > String(s.createdAt || '') ? ' The cascade was entered after this session was logged.' : ''; }
    var mon = ev('MISSED_MONDAY'), wed = ev('MISSED_WEDNESDAY');
    if (mon && wed) return out; // both missed: unresolved by source, nothing is moved or omitted
    [['MON', mon], ['WED', wed]].forEach(function (p) {
      if (!p[1]) return;
      var sl = slot(p[0]), s = latestFor(sl.id, sessions);
      if (isActualWork(s) && s.date <= sl.date) out.push({ slotId: sl.id, code: 'MISSED_DAY_HAS_ACTUAL_SESSION',
        text: sl.title + ' is marked missed, but a session is logged as performed on ' + s.date + ' (' + s.status + '). The log is kept; check whether the cascade should be removed.' + after(p[1], s) });
    });
    var cascade = mon || wed;
    if (cascade) {
      var thu = slot('THU'), ts = latestFor(thu.id, sessions);
      if (isActualWork(ts)) out.push({ slotId: thu.id, code: 'ACTUAL_SESSION_ON_SOURCE_OMITTED_SLOT',
        text: 'Thursday aerobic is omitted by the source cascade, but an actual session is logged for it (' + ts.status + ', performed ' + ts.date + '). The omission applies to the prescription only; the logged work is kept and counted as logged.' + after(cascade, ts) });
    }
    if (mon) {
      var tue = slot('TUE'), us = latestFor(tue.id, sessions);
      if (isActualWork(us) && us.date <= tue.date) out.push({ slotId: tue.id, code: 'MOVED_SLOT_DONE_ON_ORIGINAL_DAY',
        text: 'The cascade moves Tuesday\'s session to Thursday, but it is logged as performed on ' + us.date + '. The log is kept; do not repeat it on Thursday.' + after(mon, us) });
    }
    return out;
  }

  // ---------- owner rule 4: explicit skip -> reschedule / skip permanently / adjust week ----------

  function dayName(iso) { return ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'][new Date(iso + 'T00:00:00Z').getUTCDay()]; }

  // Slots the effective (cascade-aware) schedule shows on a date.
  function plannedOn(date, events) {
    var s = slotForDate(date);
    if (!s) return [];
    var day = effectiveWeek(s.week, events).days.filter(function (d) { return d.date === date; })[0];
    return day ? day.show.map(function (x) { return x.slot; }) : [];
  }

  // Slots whose current record is an explicit skip rescheduled to `date` (and not yet done).
  function rescheduledOn(date, sessions) {
    return SLOTS.filter(function (sl) {
      var s = latestFor(sl.id, sessions);
      return !!s && s.status === 'SKIPPED' && s.skipDecision === 'RESCHEDULE' && s.rescheduledTo === date;
    });
  }

  // Can this slot be rescheduled to `date` without stacking sessions or breaking a source rule?
  // Owner decision 2 (t47u): a logged session is EASY (does not count for "never stack") only when it is
  // not a programmed gym session AND the owner said it was easy, or it was recorded at RPE <= 4 (v2.1 §5
  // "easy RPE 3–4") with only walking / mobility-type blocks. Anything unknown counts as demanding.
  var EASY_BLOCK_KINDS = ['walk', 'mobility', 'warmup', 'cooldown', 'rest'];
  function isDemandingSession(s) {
    if (!s) return false;
    if (slotById(s.planSlotId)) return true;
    if (s.intensity === 'DEMANDING') return true;
    // Phase 8: the owner's own "Moderate" (about RPE 5-6) is NOT easy (v2.1 §5 easy = RPE 3-4), so it counts as hard for the
    // never-stack rule. Conservative: it can never unlock a second session on the day. Not a new threshold.
    if (s.intensity === 'MODERATE') return true;
    if (s.intensity === 'EASY') return false;
    var blocks = Array.isArray(s.blocks) ? s.blocks : [];
    var easyBlocks = blocks.every(function (b) { return b && EASY_BLOCK_KINDS.indexOf(b.kind) !== -1; });
    return !(typeof s.rpe === 'number' && s.rpe <= 4 && easyBlocks);
  }

  function rc(ok, code, text) { var o = { ok: ok, code: code }; o[ok ? 'caution' : 'reason'] = text; return o; }

  function rescheduleCheck(slotId, date, sessions, events, today) {
    var slot = slotById(slotId);
    if (!slot) return rc(false, 'UNKNOWN_SLOT', 'Unknown planned session.');
    if (typeof date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(date)) return rc(false, 'NO_DATE', 'Choose a date.');
    if (date < today) return rc(false, 'PAST', 'A session cannot be rescheduled into the past.');
    if (date === slot.date) return rc(false, 'ORIGINAL_DATE', 'That is the original planned date.');
    if (date > BLOCK_END || date < BLOCK_START) return rc(false, 'OUTSIDE_BLOCK', 'That date is outside block ' + PLAN_VERSION + ' (ends ' + BLOCK_END + '). No later block exists.');
    if (isWeekend(date)) {
      if (slot.day === 'FRI') return rc(false, 'FRIDAY_NO_WEEKEND_MAKEUP', 'Source rule: a missed Friday has no weekend make-up.');
      return rc(false, 'WEEKEND_NO_GYM_MAKEUP', 'Source rule (v2.1): no weekend make-up for a missed weekday HYROX gym session. Optional light Saturday activity (Week 2+) and Sunday mobility are not make-ups. If you do train at the weekend, log it truthfully as what you did.');
    }
    var others = plannedOn(date, events).filter(function (s) { return s.id !== slotId; });
    if (others.length) return rc(false, 'PLANNED_SESSION_ON_DAY', 'That day already has ' + others[0].title + ' planned. Two demanding sessions are never stacked on one day.');
    var moved = rescheduledOn(date, sessions).filter(function (s) { return s.id !== slotId; });
    if (moved.length) return rc(false, 'ALREADY_RESCHEDULED_TO_DAY', 'Another session is already rescheduled to that day. Two demanding sessions are never stacked on one day.');
    var done = (sessions || []).filter(function (s) { return s.date === date && isActualWork(s) && s.planSlotId !== slotId && isDemandingSession(s); });
    if (done.length) return rc(false, 'DEMANDING_SESSION_LOGGED', 'A demanding session is already logged on that day. Two demanding sessions are never stacked on one day.');
    return rc(true, 'OK', 'This is outside the approved Monday/Wednesday cascade, so it is your decision. It uses a free weekday; drop it if recovery, soreness or pain is not good that day.');
  }

  // Informational only: what a day holds. Never blocks logging what was actually done.
  function dayLoad(date, sessions, events) {
    var actual = (sessions || []).filter(function (s) { return s && s.date === date && isActualWork(s); });
    var dem = actual.filter(isDemandingSession), easy = actual.filter(function (s) { return !isDemandingSession(s); });
    var stacked = dem.length >= 2;
    return { date: date, planned: plannedOn(date, events).map(function (s) { return s.id; }),
      demandingLogged: dem.map(function (s) { return s.id; }), easyLogged: easy.map(function (s) { return s.id; }),
      stackedDemanding: stacked, flag: stacked ? 'TWO_DEMANDING_SESSIONS_LOGGED' : null };
  }

  function rescheduleDates(slotId, sessions, events, today) {
    var out = [], from = today > BLOCK_START ? today : BLOCK_START;
    for (var d = from; d <= BLOCK_END; d = addDays(d, 1)) {
      if (rescheduleCheck(slotId, d, sessions, events, today).ok) out.push(d);
    }
    return out;
  }

  // What the app recommends when the owner explicitly skips a planned session. It never decides.
  function skipAdvice(slotId, sessions, events, today) {
    var slot = slotById(slotId);
    if (!slot) return null;
    var evs = currentEvents(events).filter(function (e) { return e.week === slot.week; });
    var hasMon = evs.some(function (e) { return e.kind === 'MISSED_MONDAY'; }), hasWed = evs.some(function (e) { return e.kind === 'MISSED_WEDNESDAY'; });
    var adjust = { available: false, kind: null, note: 'The source defines a week adjustment only for a missed Monday or Wednesday.' };
    if (slot.day === 'MON' || slot.day === 'WED') {
      var kind = slot.day === 'MON' ? 'MISSED_MONDAY' : 'MISSED_WEDNESDAY';
      var mine = slot.day === 'MON' ? hasMon : hasWed, other = slot.day === 'MON' ? hasWed : hasMon;
      adjust.kind = kind;
      if (mine) adjust.note = 'The source cascade for this day is already applied.';
      else if (other) adjust.note = 'The other of Monday/Wednesday is already marked missed this week. The source has no rule for both, so nothing can be adjusted automatically.';
      else if (slot.date > today) adjust.note = 'A future session cannot be marked missed.';
      else {
        adjust.available = true;
        adjust.note = slot.day === 'MON'
          ? 'Approved source cascade: Strength A moves to Tuesday, Tuesday\'s intervals move to Thursday, Thursday aerobic is omitted by source rule.'
          : 'Approved source cascade: Strength B moves to Thursday, Thursday aerobic is omitted by source rule.';
      }
    }
    var dates = rescheduleDates(slotId, sessions, events, today);
    var reschedule = { available: dates.length > 0, dates: dates,
      note: dates.length ? 'Free days without another session: ' + dates.join(', ') + '. Outside the approved cascade - your decision.'
        : (slot.day === 'FRI' ? 'Source rule: a missed Friday has no weekend make-up, and every other day already has a session.'
          : 'No free weekday is left without stacking two demanding sessions, and weekends are not gym make-up days (source v2.1).') };
    var omitted = omissionFor(slotId, events);
    var recommended = adjust.available ? 'ADJUST_WEEK' : 'SKIP_PERMANENT';
    var why = adjust.available ? 'Recommended: adjust the rest of the week with the approved source cascade.'
      : slot.day === 'FRI' ? 'Recommended: leave it skipped. Source rule: no weekend make-up for a missed Friday.'
      : 'Recommended: leave it skipped. That never stacks sessions or costs a recovery day.';
    if (omitted) why = 'This session is already omitted by the source cascade (' + omitted + '); it does not need to be skipped. ' + why;
    return { slotId: slotId, day: slot.day, sourceOmission: omitted || null, recommended: recommended, recommendation: why,
      options: { RESCHEDULE: reschedule, SKIP_PERMANENT: { available: true, note: 'Stays skipped. The original planned session is kept for the record.' }, ADJUST_WEEK: adjust } };
  }

  // ---------- owner decision 3 (t47u): HNC-BASE v2.1 section 9 busy-day fallbacks ----------
  var VARIANT_SOURCE = 'HNC-BASE-v2.1 §9';
  var VARIANT_MINUTES = { ORIGINAL_60: 60, SOURCE_45_MIN: 45, SOURCE_25_MIN: 25 };
  var STATION_OPTIONS = { INTERVALS: ['SkiErg', 'Sled push', 'Sled pull'], AEROBIC: ['Rower', 'SkiErg', 'Bike'],
    RACE: ['Row', 'Farmer carry', 'Burpee broad jumps', 'Lunges', 'Wall balls'] };
  function isStrengthType(t) { return t === 'STRENGTH_A' || t === 'STRENGTH_B'; }
  function mainLiftSets(w) { return w === 2 || w === 3 ? 3 : 2; } // v2.1 §4: W1 2x5, W2–3 3x5, W4 2 work sets

  function variantKindFor(type, variant) {
    if (variant === 'ORIGINAL_60') return 'ORIGINAL';
    if (variant === 'SOURCE_45_MIN') return isStrengthType(type) ? 'MAIN_LIFT_45' : 'MAIN_CIRCUIT_45';
    if (variant === 'SOURCE_25_MIN') return isStrengthType(type) ? 'STRENGTH_25' : 'HYROX_25';
    return null;
  }

  function blk(kind, label, extra) { var o = { kind: kind, label: label }; if (extra) Object.keys(extra).forEach(function (k) { o[k] = extra[k]; }); return o; }
  var UNSPEC = { optional: true, sourceStatus: 'UNSPECIFIED' };

  // Template blocks for a fallback. Actual values (sets, reps, loadKg, distanceM, durationSec) are never filled.
  function variantBlocks(type, w, variant) {
    var kind = variantKindFor(type, variant);
    if (!kind || !DAY_TYPE_BY_TYPE[type] || !(w >= 1 && w <= 4)) return null;
    if (kind === 'ORIGINAL') return templateBlocks(type, w);
    var A = type === 'STRENGTH_A';
    if (kind === 'MAIN_LIFT_45') {
      return [blk('warmup', A ? 'Warm-up' : 'Warm-up / hinge drills'),
        blk('strength_set', A ? 'Back squat' : 'Deadlift', { exercise: A ? 'Back squat' : 'Deadlift', setType: 'WORKING', prescribedSets: mainLiftSets(w), sourceStatus: 'SOURCE' }),
        blk('strength_set', A ? 'Bench press' : 'Overhead press', Object.assign({ exercise: A ? 'Bench press' : 'Overhead press', setType: 'WORKING' }, UNSPEC)),
        blk('strength_set', A ? 'Chest-supported DB row' : 'Pull-up / lat pulldown', Object.assign({ exercise: A ? 'Chest-supported DB row' : 'Pull-up / lat pulldown', setType: 'WORKING' }, UNSPEC)),
        blk('cooldown', 'Cooldown')];
    }
    if (kind === 'STRENGTH_25') {
      var lifts = A ? ['Back squat', 'Bench press'] : ['Deadlift', 'Overhead press'];
      return [blk('warmup', 'Brief warm-up')].concat(lifts.map(function (x) {
        return blk('strength_set', x, { exercise: x, setType: 'WORKING', prescribedSets: 2, sourceStatus: 'SOURCE' });
      }));
    }
    if (kind === 'MAIN_CIRCUIT_45') {
      var b = templateBlocks(type, w).filter(function (x) { return !(type === 'AEROBIC' && x.kind === 'mobility'); });
      b.forEach(function (x) { if (x.kind === 'sled_push' || x.kind === 'sled_pull') { x.optional = true; x.sourceStatus = 'UNSPECIFIED'; } });
      if (type !== 'RACE') b.push(blk('cooldown', 'Cooldown'));
      return b;
    }
    // HYROX_25: 5 min warm-up, two short run + station rounds, 3 min cooldown. Distances and stations unspecified.
    var out = [blk('warmup', 'Warm-up 5 min', { prescribedDurationSec: 300, sourceStatus: 'SOURCE' })];
    for (var r = 1; r <= 2; r++) {
      out.push(blk('run', 'Round ' + r + ' short run (distance not specified)', { sourceStatus: 'SOURCE' }));
      out.push(blk('other', 'Round ' + r + ' station (choose; not specified)', { sourceStatus: 'UNSPECIFIED', stationOptions: STATION_OPTIONS[type].slice() }));
    }
    out.push(blk('cooldown', 'Cooldown 3 min', { prescribedDurationSec: 180, sourceStatus: 'SOURCE' }));
    return out;
  }

  // The section 9 prescription for a planned slot. null for an unknown slot or a variant without one.
  function variantPrescription(slotId, variant) {
    var slot = typeof slotId === 'string' ? slotById(slotId) : (slotId && slotById(slotId.id));
    var kind = slot ? variantKindFor(slot.type, variant) : null;
    if (!kind) return null;
    var w = slot.week, A = slot.type === 'STRENGTH_A', keep = [], drop = [], unspecified = [], lines = [];
    if (kind === 'ORIGINAL') { lines = slot.prescription.slice(); keep = ['Full 60-minute session']; }
    else if (kind === 'MAIN_LIFT_45') {
      var main = (A ? strengthA(w) : strengthB(w))[1];
      lines = [A ? '0–8 min warm-up: easy machine + mobility' : 'Warm-up + hinge drills', 'Main lift — ' + main,
        'Optional, not specified by §9: ' + (A ? 'bench press + chest-supported DB row' : 'overhead press + pull-ups / lat pulldown') + ' if time allows',
        'Accessories omitted (§9: drop accessories)', 'Cooldown'];
      keep = ['Main lift: ' + (A ? 'back squat' : 'deadlift')];
      drop = A ? ['Back extension', 'Dead bug'] : ['Incline DB press', 'Farmer carries'];
      unspecified = [{ key: 'secondaryCompound', text: 'Whether the ' + (A ? 'bench press + row' : 'overhead press + pull-up/pulldown') + ' block stays in the 45-minute version is not specified by §9.' },
        { key: 'durations', text: 'Exact minutes per part are not specified for the 45-minute version.' }];
    } else if (kind === 'STRENGTH_25') {
      var pair = A ? ['Back squat', 'Bench press'] : ['Deadlift', 'Overhead press'];
      lines = ['Brief warm-up', pair[0] + ': 2 working sets', pair[1] + ': 2 working sets',
        'Reps, loads and RPE are not set by the 25-minute rule: record what you actually do.'];
      keep = pair.map(function (x) { return x + ' (2 working sets)'; });
      drop = A ? ['Chest-supported DB row', 'Back extension', 'Dead bug'] : ['Pull-ups / lat pulldown', 'Incline DB press', 'Farmer carries'];
      unspecified = [{ key: 'repsLoadRpe', text: 'Reps, load and RPE for the 2 working sets are not specified.' },
        { key: 'warmupDuration', text: 'Warm-up length is not specified.' }];
    } else if (kind === 'MAIN_CIRCUIT_45') {
      if (slot.type === 'INTERVALS') {
        var iv = intervals(w);
        lines = [iv[0], iv[1], 'Optional, not specified by §9: sled push + pull', 'Cooldown'];
        keep = ['Run + SkiErg rounds for the week']; unspecified = [{ key: 'sled', text: 'Whether the sled push/pull stays in the 45-minute version is not specified by §9.' }];
      } else if (slot.type === 'AEROBIC') {
        var ae = aerobic(w);
        lines = [ae[0], ae[1], ae[2], ae[3], 'Extra transitions / mobility time trimmed to fit'];
        keep = ['Run-walk, rower and SkiErg bouts']; drop = ['Extra transitions / mobility time'];
      } else {
        var rc2 = race(w);
        lines = [rc2[0], rc2[1]].concat(w === 1 ? [] : [rc2[2]]).concat(['Cooldown']);
        keep = ['Race-skills round(s) for the week']; drop = ['Optional light sled technique'];
      }
      unspecified.push({ key: 'durations', text: 'Exact minutes per part are not specified for the 45-minute version.' });
    } else {
      lines = ['5 min warm-up', '2 short rounds: run + one station (run distance and station not specified by §9 — choose and record what you do)', '3 min cooldown'];
      keep = ['5 min warm-up', '2 short run + station rounds', '3 min cooldown'];
      drop = ['Rest of the full session'];
      unspecified = [{ key: 'runDistance', text: 'Run distance per round is not specified.' },
        { key: 'station', text: 'Station choice is not specified; options from this session: ' + STATION_OPTIONS[slot.type].join(', ') + '.' }];
    }
    if (slot.benchmark && kind !== 'ORIGINAL') lines.push('Benchmark ' + slot.benchmark + ' needs the full session: this fallback is not benchmark-comparable.');
    return { slotId: slot.id, week: w, day: slot.day, type: slot.type, variant: variant, variantKind: kind,
      prescribedDurationMin: VARIANT_MINUTES[variant], source: kind === 'ORIGINAL' ? 'HNC-BASE-v2.1 §4–5' : VARIANT_SOURCE,
      keep: keep, drop: drop, unspecified: unspecified, prescription: lines, blocks: variantBlocks(slot.type, w, variant) };
  }

  // A loggable draft. Never COMPLETED, never pre-filled with an actual duration, loads, splits or reps.
  function variantDraft(slotId, variant, date) {
    var p = variantPrescription(slotId, variant);
    if (!p) return null;
    var slot = slotById(p.slotId);
    return { date: date || slot.date, planSlotId: slot.id, planVersion: PLAN_VERSION, scheduledDate: slot.date,
      title: slot.title + (variant === 'ORIGINAL_60' ? '' : ' — ' + p.prescribedDurationMin + '-min source fallback'),
      status: 'NOT_STARTED', modified: false, variant: variant, variantKind: p.variantKind,
      prescribedDurationMin: p.prescribedDurationMin, durationMin: null, blocks: p.blocks };
  }

  // Machine continuity compliance: never splits or clips the recorded value.
  function machineCompliance(block) {
    if (!block) return null;
    var isMachine = block.machine === true || MACHINE_KINDS.indexOf(block.kind) !== -1;
    if (!isMachine) return null;
    var d = block.durationSec;
    if (typeof d !== 'number' || !isFinite(d)) return 'UNVERIFIED';
    if (block.claimWithinLimit === true && d > MACHINE_LIMIT_SEC) return 'CONFLICT';
    return d > MACHINE_LIMIT_SEC ? 'OVERRUN' : 'WITHIN_LIMIT';
  }

  function summary(sessions, events) {
    var c = { denominator: SLOTS.length, NOT_LOGGED: 0, NOT_STARTED: 0, IN_PROGRESS: 0, COMPLETED: 0, PARTIAL: 0,
      SKIPPED: 0, SOURCE_OMITTED: 0, modified: 0, fallback: 0, omittedWithActual: 0, rescheduledPending: 0,
      planned: SLOTS.length, qualifyingNumerator: null, numeratorStatus: 'OWNER_DECISION_PENDING', weekendActual: 0,
      variants: { SOURCE_45_MIN: {}, SOURCE_25_MIN: {} } };
    SLOTS.forEach(function (s) {
      var st = slotStatus(s.id, sessions, events);
      c[st.code] = (c[st.code] || 0) + 1;
      if (st.conflict) c.omittedWithActual++;
      if (st.code === 'SKIPPED' && st.skipDecision === 'RESCHEDULE') c.rescheduledPending++;
      if (st.session && st.session.modified) c.modified++;
      if (st.session && (st.session.variant === 'SOURCE_45_MIN' || st.session.variant === 'SOURCE_25_MIN')) {
        c.fallback++;
        var vc = c.variants[st.session.variant];
        vc[st.session.status] = (vc[st.session.status] || 0) + 1;
      }
      if (st.weekendWork) c.weekendActual += st.weekendWork.length;
    });
    c.note = 'Denominator is the original 20 slots (make-ups never add slots). Official ≥17/20 numerator rule is an OPEN owner decision; fallback (45/25 min) completions are shown separately, not as standard 60-min completions.';
    return c;
  }

  function benchmarks(sessions) {
    return [1, 2].map(function (n) {
      var slot = SLOTS.filter(function (s) { return s.benchmark === n; })[0];
      var s = latestFor(slot.id, slotSessions(slot.id, sessions));
      return { benchmark: n, slotId: slot.id, date: slot.date, status: s ? s.status : 'NOT_LOGGED',
        durationMin: s && typeof s.durationMin === 'number' ? s.durationMin : null,
        comparable: !!s && s.status === 'COMPLETED' && !s.modified && s.variant === 'ORIGINAL_60' };
    });
  }

  return { PLAN_VERSION: PLAN_VERSION, BLOCK_START: BLOCK_START, DAY0: DAY0, BLOCK_END: BLOCK_END, PREVIOUS_ANCHOR: PREVIOUS_ANCHOR,
    isPreBlockSession: isPreBlockSession, isPreBlockEvent: isPreBlockEvent, preBlockSessions: preBlockSessions, preBlockEvents: preBlockEvents,
    human: human, humanShort: humanShort, NO_BLOCK_TEXT: NO_BLOCK_TEXT,
    MACHINE_LIMIT_SEC: MACHINE_LIMIT_SEC, SLOTS: SLOTS, slotById: slotById, slotForDate: slotForDate,
    blockStatus: blockStatus, effectiveWeek: effectiveWeek, slotStatus: slotStatus, machineCompliance: machineCompliance,
    summary: summary, benchmarks: benchmarks, templateBlocks: templateBlocks, addDays: addDays, omissionFor: omissionFor,
    latestFor: latestFor, isActualWork: isActualWork, cascadeConflicts: cascadeConflicts, plannedOn: plannedOn,
    rescheduledOn: rescheduledOn, rescheduleCheck: rescheduleCheck, rescheduleDates: rescheduleDates, skipAdvice: skipAdvice,
    isDemandingSession: isDemandingSession, dayLoad: dayLoad, weekendOptions: weekendOptions,
    VARIANT_SOURCE: VARIANT_SOURCE, variantPrescription: variantPrescription, fallbackPrescription: variantPrescription,
    variantBlocks: variantBlocks, variantDraft: variantDraft };
});
