# Changelog

## Phase 9 (candidate, provider OFF until activated)
- Real photo-to-macros via a same-origin Netlify Function calling OpenAI (gpt-6-luna); owner access code; durable budget caps; new 'Live' provider. See CHANGES-PHASE9.md.

## Phase 7 provenance-validation patch (Grok, 2026-11-13) — LOCAL ONLY, not merged, not deployed

Baseline: Claude Phase 6 review source (sha256 58e79d96...). Owner decision P6-1 only; no other change.

- The meals validator now checks the optional components[].provenance on save, preview and restore: a plain record, known fields typed and length-limited, `source` + `fdcId` required, optional clamp marker `carbsClampedToZero: true` and `note`, at most 6 extra fields (safe name, short scalar value, kept exactly), `__proto__`/`constructor`/`prototype` refused, total at most 2048 characters. Refused backups change nothing and name the exact field. Backups without provenance restore as before.
- One Phase 6 characterisation test (tests/p6-dawit-components.test.js, "validator NOT changed") now expects the refusal it used to document as an open choice.

## Phase 6 independent review (Claude, 2026-11-13) — LOCAL ONLY, not merged, not deployed

Baseline: Grok fd37069. Details: CLAUDE-QA-REPORT-P6.md.

Fixed
- Text estimate: a non-alias food is chosen by itself only when its USDA description has no words beyond the typed ones; otherwise the owner picks it (one tap). Stops e.g. "1 bowl rice" -> frozen chicken rice bowl entree, "1 baked egg" -> egg custard.
- Meal form: Draft / intent / Confirm refuse to save while the estimate on screen is not in the meal (stale after any edit). Fixes confirming 143 kcal while 215 kcal was shown. New "Clear estimate" button.

Verified (no change): backup/restore locks, load guard, read-only storage diagnostics, readiness links, food DB consistency; deployed Phase 5 package matches the audited source file by file.

## Phase 5 independent review (Claude, 2026-11-12) — LOCAL ONLY, not merged, not deployed

Baseline: Grok 9ba6e34. Details: CLAUDE-QA-REPORT-P5.md.

Fixed
- Restore size limit 2,000,000 -> 10,000,000 characters: this build's own indented backup of ~8+ months of daily logging was refused by its own restore.
- A backup this build would refuse is downloaded as hyrox-backup-<date>-NOT-RESTORABLE.json (content unchanged).
- Detailed screens read each stored list once per screen update instead of once per day shown: with a year of data, open ~15 s -> ~0.6 s, save ~14 s -> ~0.45 s.
- Test portability: no test depends on Grok's /workspace paths any more.

Verified (no change): empty-backup second confirmation cannot be bypassed at the data layer; the only pre-import copy survives single and pairwise storage-fault sweeps; non-restorable exports are never called restorable.


## Phase 3 round 2 independent review (Claude, 2026-11-11) — LOCAL ONLY, not merged, not deployed

Baseline: Grok ed7ad84. Details: CLAUDE-QA-REPORT-R2.md.

Fixed
- A stored check-in with one out-of-range value is no longer hidden whole: valid values stay in use, the bad field is INVALID/unknown and named, the stored text is untouched until the owner approves a correction.
- Saving or deleting can no longer silently replace a stored record that is not valid as stored (explicit approval required).
- Invalid pain never reads as "no flags"; it holds the reference goal and cancels a target raise.
- New fractional walk step counts are refused; legacy ones are kept exactly, flagged and never counted or rounded.
- 10k gate: sleep outside 0-24 h is invalid/UNKNOWN (it used to pass).
- Damaged saved settings can be replaced with approval; resting-HR difference rounding; compiled caches removed.

Added
- "Records needing attention" list (exact field, stored value, rule). store.damagedRecords(), classifyExtRecord.
- Normal backup keeps salvaged records with the bad field marked INVALID and the original noted; export notice and raw-copy warning say so.
- Today at a glance; bottom navigation bar on phones; visual refresh (appearance only).

Unchanged on purpose (owner decisions on hold)
- Old confirmed photo meals without an eaten amount; DF day state; raw-copy restore; restore of old backups with fractional walk counts; 17/20; both-missed; post-6-Dec.


## Phase 3 independent QA repair (Claude, 2026-11-11) — LOCAL ONLY, not merged, not deployed

Fixed
- P0-A: a Phase 3 collection stored in a damaged (non-list) form is now classified as damaged data. Nothing overwrites it without a byte-exact recovery copy; if that copy cannot be made the save is refused.
- P0-A: damaged records inside a Phase 3 list are hidden from screens, kept in storage, reported and left out of exports (so every export can be restored).
- P0-B: a source-omitted Thursday no longer hides a session that was actually logged. Omission (prescription) and logged session (actual) are reported independently; cascade/log conflicts are shown.
- A later skip record no longer hides work that was actually done for the same slot.
- Storage banner now refreshes after detailed saves/deletes.
- History rows with several badges overflowed a 390 px screen and covered the "Review & confirm" button; they now wrap.

Added (owner rules of 2026-11-11)
- Configurable resting-HR baseline, default 76 bpm; configured and observed baselines shown separately.
- Meal-level eaten amount (25/50/75/100% or custom) applied to every macro, item-level override, no default for photographed meals, confirm refused until stated.
- Water-only day question; only a confirmed full-day fast records 0 kcal; fasting days tracked separately from eating-day averages.
- Skip decision (reschedule / skip permanently / adjust week) with a safe recommendation; source cascade unchanged.
- Adaptive daily step target with configurable baseline, per-day override, weekly trend and consistency.

Changed
- Schema version: data and backups that contain Phase 3 collections are now version 2 (classic-only data stays version 1). The Phase 2 build refuses version 2 instead of silently discarding the new collections.
- Selecting the real-model photo provider needs an explicit confirmation and is labelled as not approved for real photos.


## Unreleased - data-loss fixes (2026-11-10, local only, not pushed)
- Saves now read back what was written; any storage failure (blocked, full, unreadable, in-memory
  fallback) returns an error and is never reported as saved.
- Damaged stored data is no longer overwritten: it is copied unchanged to `hyrox.v1.corrupt-backup`
  before any new save, and saving is refused if that copy cannot be made. Unreadable storage or data
  from a newer version blocks saving entirely. Unknown fields and malformed entries are kept on save.
- A banner explains storage problems; export refuses instead of producing an empty backup.
- Stored data format for `hyrox.v1` is unchanged. Tests: 50 (15 new regression tests).

## 0.1.0 - Phase 1 prototype (2026-11-10, local only, not pushed)
- Weight log (kg, date) with history and delete. (Liya UI, Dawit data)
- Workout log: date, activity, duration (min), partial-session flag, notes; history with Partial badge.
- Nutrition entries (optional label, calories, protein) with daily totals.
- Browser-local storage (localStorage `hyrox.v1`), survives refresh; corrupt data falls back to empty.
- Export JSON backup download.
- Validation on all inputs; Asia/Qatar dates; future dates rejected.
- Responsive layout for iPhone Safari (390px), 16px inputs to avoid iOS zoom, safe-area insets.
- Tests: 35 Node unit tests (node:test, no dependencies), headless Chrome mobile screenshot,
  manual iPhone checklist. (Meron)
- Known limits: no JSON import/restore yet; no automated Safari (WebKit) UI tests (Playwright not approved).

## Phase 3 (Emergent isolated build, 2026-11-11, base 64427c2) — unmerged
- Tabs Today/Add/History/Trends/Settings; classic forms kept under Add.
- Training plan v2.1 (20 slots), explicit missed-Mon/Wed cascade, planned vs actual.
- Detailed workout sessions with exact status enum, modified flag, variants, ordered blocks, 900 s machine compliance.
- Waist, daily check-in (observation states), walks, readiness flags, canonical steps.
- Meals with components and KNOWN/ESTIMATED/UNKNOWN macros, lifecycle, D1–D5 day states with invalidation.
- Photo + AI food analysis: sanitization, consent gates, provider-neutral adapter (none / MOCK TEST / local test backend).
- Trends; integration stubs (not activated). Backup export/import extended to Phase 3 lists with unchanged rollback.
