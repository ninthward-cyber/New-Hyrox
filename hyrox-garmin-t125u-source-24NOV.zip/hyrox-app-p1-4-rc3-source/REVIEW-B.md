# REVIEW-B — Branch B (Phase 12: Block 2 planner)

Reviewer: Grok Bot (independent RC1 reviewer), 19 Nov 2026 (Asia/Qatar, UTC+3). Owner instruction t100u.
Input (read-only, not modified): /workspace/hyrox-p12/app, branch p12/integration, HEAD 7b7170c, base e86371a (tree = Claude
P11.2 source zip 6e2b2cae…). Binding decisions D1–D12: /workspace/hyrox-p12/design/CC-BLOCK2-RESPONSE-19NOV.txt.
Reviewed copy: /workspace/hyrox-rc1 rc1/b-p12 (cherry-picked onto rc1/baseline, tree identical to B) → rc1/b-review.

Labels: CONFIRMED / INFERRED / UNKNOWN as in REVIEW-A.

## Verdict
One MEDIUM defect (B-01, approval integrity) found and repaired with a fail-first two-tab e2e. No CRITICAL/HIGH. Activation
date rules, Block 1 history and settings persistence verified, including a simulated-December test suite (test clock only).

## Defects and repairs
| ID | Severity | Status | Finding | Repair |
|---|---|---|---|---|
| B-01 | MEDIUM | CONFIRMED (fail-first, rc1-logs/B-failfirst-rc1-review-b01*.txt) | The "I reviewed the preview" approval tick could be checked without ever opening the preview, and a tick stayed valid after the draft content changed (in this tab or another tab / a restore) — the activation then went through for content the owner had not seen (the preview-hash guard only compared against the hash rendered on that screen). | db1c63b: the tick is enabled only after the preview was opened for the current content (`seenHash === hashAtRender`) and is bound to that content (`approvedHash`); a stale tick is cleared with note `planner-approval-cleared`; hint `planner-approve-needs-preview`. p12-planner 11-Dec flow gained one preview click (additive). Test tests/e2e/rc1-review-b01.spec.js (two pages, 390/320). |

## Focus areas
### Block 2 activation — CONFIRMED (simulated December, Playwright test clock only; rc1-activation-clock.spec.js)
| Case | Result |
|---|---|
| 10 Dec 23:59:59 +03 | refused in UI (approve + activate disabled, "Activation opens on…"); engine `BEFORE_DECISION_DATE` with the app's own today |
| 11 Dec 00:00:00 +03 | allowed; activates for Mon 14 Dec; activatedAt 2026-12-10T21:00Z (= 00:00 Qatar); 11 Dec still Block 1 W4; no planEvents |
| late Monday start (21 Dec) | 14–20 Dec "not counted and not missed"; W1 = 21 Dec; end 17 Jan; 20 slots all NOT_LOGGED (denominator 20) |
| midnight 13→14 Dec (running clock, no reload; visibilitychange new-day check) | Block 1 W4 → "Mon 14 Dec · Block 2 · Week 1/4", Strength A |
| 10 Jan 23:59:59 → 11 Jan 00:00 | Week 4/4 → "no active block", planner "Finished"; nothing auto-created (no rollover) |
| Block 1 last day (Fri 11 Dec) + Block 2 first day (Mon 14 Dec) | each log stays in its own block (v2.1-W4-FRI / <block>-W1-MON, planVersion v2.1 / b2-hold-1); Block 1 SLOTS unchanged; summaries 1/20 each |
| duplicate activation in two tabs | second tab "Not saved" (settings stamp STALE); exactly one ACTIVATED, activatedAt of the first |
| backup/restore of an active block | export → wipe → restore preview "Plan blocks differ" → restored → reload: planBlocks deep-equal, foods equal, Block 2 W1 shown |
| downgrade after activation (Claude P11.2, Claude P11, P10b, verified packages, same origin) | old build Settings save + export keeps planBlocks, myFoods, the Block 2 session link, version 2; back in RC1 Block 2 active, session shown Partial |
| no override in deploy | tests/rc1-no-override.test.js builds the package and greps all 16 publish/ files: no location.search/hash/href, URLSearchParams, hashchange/popstate, debugger, debug/test/fake-clock names, Date replacement, window.__ hooks, sessionStorage/cookie, unknown storage keys; FIRST_START '2026-12-14', DECISION_FROM '2026-12-11', `today()` = `HD.todayQatar()` |

All at 390 px; the refuse/allow and midnight cases also at 320 px. Chrome emulation, not Safari.

### Settings persistence — CONFIRMED / INFERRED
Writers of the single settings record and how they behave (read in code; each covered by an e2e):
- `saveFoodPrefs` (My foods / favourites): fresh re-read, keeps planBlocks — CONFIRMED (rc1-cross, including a tab whose screen
  predates the activation).
- Baselines / Settings save: fresh re-read; the data layer refuses to overwrite a damaged record without `approveCorrection` —
  CONFIRMED (p12-planner stale-screen test; rc1-cross).
- Damaged-settings Replace: `repairCarry` keeps every other valid field (planBlocks, myFoods, favFoods, future fields); a corrupt
  planBlocks value is reported, never overwritten — CONFIRMED (p12-planner D9 tests; integrated p11-3 test flipped).
- `HB.writeBlocks` (create / revise / approve / activate / events): fresh read, settings stamp check, read-back — CONFIRMED (two-tab
  tests: food write in tab A makes tab B's activation STALE; nothing lost).
- Cascade-event buttons pass no expectStamp — INFERRED OK: `addEvent` re-checks the fresh record.
- Export/restore/reopen — CONFIRMED (above). Downgrade to Claude P11.2/P11/P10b — CONFIRMED (above).

### Block 1 history — CONFIRMED
Block 1 slot ids/plan content unchanged (byte-pinned in p12 unit tests; SLOTS deep-equal in RC1 test); Block 1 logs keep
planVersion v2.1; Block 2 never writes legacy planEvents.

### Low / documented notes (not repaired)
- INFERRED LOW: overlap check ignores invalid activated blocks (only a hand-corrupted record could hit it).
- INFERRED cosmetic: `HP.rescheduleCheck` is bounded to Block 1; its text "No later block exists" is in a pinned Block 1 file.
- CONFIRMED by design (D-decisions): Block 2 "hold" content ≤ Block 1 ceiling (e.g. W2/W3 Tue 400 m vs Block 1 W3 500 m); the
  preview diff omits Block 1 W2's "No heavy RDL in weeks 1–2" line (it is a weeks-1–2 note).
- Documented old-build limits: editing a SKIPPED Block 2 session in an old build drops its skipDecision; the old (Claude P11.2)
  damaged-settings Replace drops planBlocks. Hence the rollback rule "don't edit Block 2 records on old builds".
- INFERRED LOW: restore preview warns about plan blocks only, not about saved foods being replaced.

## Tests on B (before integration, Chrome emulation, not Safari)
Unit 1449/1449, 0 skip. e2e 397 pass, 1 skip (same pre-existing p4 "150% page-zoom proxy"), 1 fail = p8-today 390 layout timeout
while A and B ran in parallel; rerun 3× → 30/30 (rc1-logs/B-e2e-rerun-p8-today-x3.txt). Not a product defect.
