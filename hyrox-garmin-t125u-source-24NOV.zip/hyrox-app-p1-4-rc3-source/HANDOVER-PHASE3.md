> NOTE (2026-11-11): this is Emergent's original Phase 3 handover, kept unchanged below for the record. Parts of it are superseded by the independent QA repair — see CLAUDE-QA-REPORT.md and the top entry of CHANGELOG.md.

# HYROX Phase 3 handover (Emergent isolated build) — for Claude Code review

Base: supplied Phase 2 local integration HEAD **64427c2** (`64427c22046b6d096ebcf7323dd54ccd0ea72b89`, from the inner ZIP comment).
Base ZIP: `hyrox-app-phase2-p0-64427c2.zip`, SHA-256 `8533f8f1c271ee7d0b5f147a1fb37c3541594f4a8cbc3643c43ff7696961d11a`.
The expanded `executable_source/` was byte-identical to the inner ZIP (`diff -r`) before work began.
Nothing was pushed, merged or deployed. The only preview was a private Emergent test URL that served the static files for automated tests.

## 1. Compatibility note (read first)
- Stack is unchanged: static HTML/CSS/JS and localStorage, no build step and no package.json. Phase 3 adds 6 classic `<script>` files.
- The storage key is still `hyrox.v1`, and `VERSION` is still 1. Seven optional top-level arrays were added to the same object: `sessions`, `meals`, `body`, `daily`, `walks`, `dayStates`, `planEvents`. They are written **only when used**, so legacy data and Phase 2 backups stay byte-compatible. A test asserts the exact key order for legacy-only data.
- Legacy `weight`/`workouts`/`nutrition` validation is untouched. Classic nutrition entries are read as CONFIRMED meals (kcal/protein KNOWN, carbs/fat UNKNOWN); they are never migrated or rewritten.
- `parseImport` validates Phase 3 lists strictly. One invalid record rejects the whole restore, as Phase 2 does. Unknown fields *inside* Phase 3 records are preserved. Image data or any string over 4000 chars is rejected anywhere in a record.
- `previewImport` adds `extCounts`/`currentExt` only when Phase 3 data exists on either side. `applyImport` accepts an optional `expectCurrentExt` (stale-plan check). The exact-raw rollback, pre-import slot, corrupt-data preservation and every Phase 2 error code are unchanged. All 178 original tests still pass unmodified.
- **Forward-compat caveat:** the old 64427c2 build restoring a Phase 3 backup would ignore the new lists (with an "unknown top-level fields" warning), and those records would be lost on that device. Do not restore Phase 3 backups into the old build.
- The photo-AI setting is stored separately under `hyrox.ai-settings`. It is not part of `hyrox.v1` and never exported. No image bytes are ever stored.

## 2. How to run
- App: open `index.html`, or serve the folder: `node tests/static-server.js` (port 4173).
- Unit tests: `node --test tests/*.test.js` → **245 pass / 0 fail** (178 original + 67 new).
- E2E (needs `@playwright/test` 1.49 installed somewhere): `NODE_PATH=<dir>/node_modules npx playwright test -c tests/playwright.emergent.config.js` → **30 pass / 0 fail** (15 tests × WebKit 18.2 with iPhone 13 emulation + Chromium mobile). The original `tests/playwright.config.js` is kept; it expects `/usr/bin/google-chrome`.
- AI test backend (optional, never deploy): `ai-test-backend/food_photo_adapter.py` is a FastAPI `APIRouter`. Unit tests use a fake model: `cd ai-test-backend && python3 -m pytest -q test_food_photo_adapter.py` → **8 pass**. `test_food_photo_api_live.py` (written by the QA agent) runs against a running server → **10 pass**.
- Required env for the backend: `AI_PHOTO_ENABLED`, `AI_REAL_CALL_BUDGET`, `AI_CALL_LEDGER_PATH` (if unset, it fails closed), `AI_PHOTO_MODEL_PROVIDER`, `AI_PHOTO_MODEL`, `EMERGENT_LLM_KEY`. No key is in this source tree.
- Raw outputs are in `test-results/`.

## 3. Feature matrix
| Feature | Status | Files / tests |
|---|---|---|
| Backup export/import, preview/cancel, exact rollback, corrupt preservation | ALREADY PRESENT (preserved, regression-tested, extended to Phase 3 lists) | `src/data/hyrox-data.js`; `tests/hyrox-data.test.js`, `tests/import-adversarial.test.js`, `tests/ext-data.test.js`, `e2e/p0-flows.spec.js` |
| Classic weight/workout/kcal-protein forms | ALREADY PRESENT (moved under Add → Quick log / Weight & waist) | `index.html`, `src/ui/app.js` |
| Tabs Today/Add/History/Trends/Settings, iPhone layout, honest save feedback (read-back verified) | NEWLY IMPLEMENTED | `src/ui/app-ext.js`, `style.css`; `e2e/p3-flows.spec.js` |
| Plan v2.1: 20 slots, week-specific prescriptions, planned vs actual, Day 0, block end text, no Block 2 | NEWLY IMPLEMENTED | `src/data/hyrox-plan.js`; `tests/domain.test.js` |
| Missed Mon/Wed cascade (explicit only), both-missed unresolved, no auto-skip | NEWLY IMPLEMENTED | `hyrox-plan.js effectiveWeek`; `domain.test.js` |
| Detailed workout log: exact status enum, independent modified flag, variants, ordered blocks (run/walk/sled/SkiErg/row/bike/elliptical/carries/lunges/wall balls/BBJ/strength sets), load/RPE/notes, omissions, edit/delete, revisions | NEWLY IMPLEMENTED | `app-ext.js`, `hyrox-data.js sessions`; `ext-data.test.js`, `p3-flows.spec.js` |
| 900 s machine compliance WITHIN_LIMIT/OVERRUN/UNVERIFIED/CONFLICT (960 s kept literally) | NEWLY IMPLEMENTED | `hyrox-plan.js machineCompliance`; tests |
| Waist, daily check-in (steps/sleep/quality/soreness/pain/readiness/RHR) with OBSERVED/MISSING/DECLINED/NOT_TRACKED, walks | NEWLY IMPLEMENTED | `hyrox-wellness.js`, `app-ext.js` |
| Readiness flags (sleep <6, soreness ≥6, RHR ≥ baseline+7 with ≥4 readings) + safety copy | NEWLY IMPLEMENTED (the baseline rule is an assumption — see §5) | `hyrox-wellness.js`; `domain.test.js` |
| Canonical steps (walk steps never added) | NEWLY IMPLEMENTED | `hyrox-wellness.js canonicalSteps` |
| Nutrition: components (oil/sauce/drink…), household portions, eaten fraction, 4 macros each KNOWN/ESTIMATED/UNKNOWN, null ≠ 0 | NEWLY IMPLEMENTED | `hyrox-nutrition.js`, `app-ext.js` |
| Lifecycle DRAFT / NEEDS_REVIEW / CONSUMED_INTENT / CONFIRMED; only CONFIRMED counted | NEWLY IMPLEMENTED | tests + e2e |
| Day states D1–D5, attestation, invalidation on edit/delete/redate/intent change, pending suppression | NEWLY IMPLEMENTED | `hyrox-nutrition.js dayState`; e2e D5→D2 |
| Meal edit / copy-to-draft / reuse / delete | NEWLY IMPLEMENTED | `app-ext.js` |
| Description-only meal (manual components, household portions) | NEWLY IMPLEMENTED (no text-AI) | — |
| Description-only **AI** estimate | BLOCKED / stub only | `src/integrations/stubs.js` |
| **Photo capture/library, food-only guidance, in-memory preview, EXIF/GPS strip (canvas re-encode + byte strip, then server Pillow re-encode), one-time privacy ack + per-photo Send, editable estimate, confirm, history** | NEWLY IMPLEMENTED — **MOCK-TESTED** (unit + e2e) | `src/ai/photo-ai.js`, `app-ext.js photoBlock`; `tests/photo-ai.test.js`, `p3-flows.spec.js` |
| Photo AI with a real model | **REAL MODEL VERIFIED ONCE** (one owner-approved synthetic, drawn image → `gemini-3-flash-preview` via the local test backend, HTTP 200, schema-valid, honest LOW confidence/nulls). Budget is now exhausted (402). Accuracy is NOT validated; production use is BLOCKED pending owner approval | `test-results/real-ai-call-response.json`, `ai_call_ledger.jsonl` (redacted) |
| Trends: weight, waist, steps, sleep, soreness, RHR, D5-only kcal, protein known-subtotal, plan summary, benchmarks (comparable flag), strength top-set load, run pace | NEWLY IMPLEMENTED (simple SVG) | `app-ext.js renderTrends` |
| Owner login, cloud sync, Garmin/Apple Health, licensed food catalogue | INTERFACE STUB ONLY — NOT ACTIVATED | `src/integrations/stubs.js` |
| Real iPhone Safari / Home-Screen | NOT DONE (owner manual: `tests/IPHONE-SAFARI-P2-CHECKLIST.md`). WebKit-emulation is not iPhone proof | — |
| Official 17/20 numerator, missed-both rule, step targets | OPEN owner decisions (UI shows them as open) | — |

## 4. Security / data-loss review (focused)
- Saves: every Phase 3 write goes through `loadForWrite` → validate → `save` with exact read-back. Failure shows "Not saved: …" and storage is unchanged (tested with a quota fault). Corrupt data is preserved first; newer-version data blocks writes.
- Restore: Phase 2 logic is untouched. Phase 3 lists live inside the same raw text, so exact rollback covers them (tested with write-fault injection). Stale-plan detection includes Phase 3 counts.
- XSS: all rendering uses `textContent` and DOM nodes; there is no `innerHTML` in new code. AI text is rejected if it contains `<`, `>`, `javascript:` or control characters, on both client and server.
- Photos: they are never written to localStorage, backups or logs. Object URLs are revoked on discard, save or `pagehide`. Send requires the privacy ack plus a per-photo checkbox and sanitized bytes with no APP1–15/COM segments. Requests are single-flight. The mock never touches the network. The browser holds no keys.
- Backend: requires the consent header and flag, checks enabled/key/model/ledger, enforces the budget under an async lock and reserves before calling, and writes a redacted ledger (sha256 only, no image, no key). It is not hardened for internet exposure (no auth, no rate limit). **Never deploy as-is.**
- Remaining risks: localStorage is not crash-atomic; concurrent tabs can race (as in Phase 2); Safari tab vs Home-Screen storage separation is untested; ledger reads are O(n) (fine for a test).

## 5. Known limitations / review targets for Claude
1. `app-ext.js` (855 lines) and `app.js` exceed the 700-line guideline. Split into today/add-workout/add-meal/history/trends/settings modules if desired; behaviour is covered by the e2e tests.
2. The RHR "valid personal weekly baseline" is implemented as the mean of ≥4 OBSERVED readings in the prior 7 days. This is an app assumption, not source text; the owner should confirm it.
3. `eatenFraction` multiplies component macros (macros = portion as described). Confirm this semantic.
4. The D5 rule: COMPLETE attestation, no pending meals, every confirmed meal has no UNKNOWN kcal, and total kcal > 0. A water-only day is D4.
5. Cascade buttons are disabled for future slots. Events only re-label the schedule; they never write SKIPPED.
6. Date provenance: measurement date + `createdAt`/`updatedAt` + `revisions` (last 20). There is no time-of-day for body metrics.
7. The 45/25-minute fallback content is not templated (the variant is selectable). The source fallback text is shown in the brief only.
8. Charts are minimal and not interactive. Accessibility: labels/aria are present but there is no screen-reader audit.

## 6. Instructions for Claude Code (Windows)
1. Unzip; `git init` on top of a fresh checkout of 64427c2 and apply `phase3-vs-64427c2.patch` (`git apply --binary`), or use the ZIP tree directly.
2. `node --test tests/*.test.js` (expect 245/0). Run the Playwright suite with your local WebKit/Chromium.
3. Review `src/data/hyrox-data.js` diff first (data contract), then `hyrox-nutrition.js`, `hyrox-plan.js`, `photo-ai.js`, `app-ext.js`.
4. Do a manual iPhone Safari pass (camera/library picker, HEIC from the camera, export/restore in Safari and Home-Screen modes).
5. Decide whether `ai-test-backend/` belongs in the repo, or stays out until a provider is approved.
6. Owner-controlled PR/merge only.
