# Sprint D: P1.4 Export for AI Coaching (manual, read-only, Files/share fallback; no OAuth)

Grok sprint integrator, 23 Nov 2026. Sprint D is a separate, revertible commit. Synthetic data only. Browser evidence is Chrome emulation, not Safari. The iPhone share sheet is EMULATED.

## Contract used
- **HNC-E-COACH-001 v1.0** (Claude planning doc, 22 Nov 2026): schema section 6, privacy section 7, labels section 9, tests section 10.
- **CC decision log:**
  - Manual "Export for AI Coaching", read-only versioned JSON, selected categories and date range, review step.
  - Native Files/share as the minimum path. No sync, backup or import.
  - Unique file names. Distinguish "file prepared" from a proven upload.
  - No keys, tokens or raw photos.
  - Profile, health, symptoms and notes OFF by default.
- **Handover:**
  - Do NOT set up Google OAuth or a direct Drive provider. Implement the fallback first.
  - Defer with documentation rather than ship a half-tested feature.
- **Decisions taken (the plan's D-1..D-9):**

  | Decision | Choice |
  |---|---|
  | D-1 name | "Export for AI Coaching" |
  | D-3 defaults | training, nutrition, body, steps, goals ON; recovery, symptoms, free text OFF |
  | D-4 range | 14 days default; 7, 28 or custom |
  | D-5 remember selection | NO (stateless; no new storage key) |
  | D-8 saved foods / favourites | NO |
  | D-6, D-7, D-9 | Owner and ChatGPT side; not app code |

## What was built
- **New module `src/data/hyrox-coach-export.js`** (pure; no storage writes, no network):
  - `collect(store, deps)` uses only the store's read methods.
  - `build(input, opts)` returns the snapshot, its text and a unique file name `hyrox-coaching-YYYYMMDD-HHMMSS-xxxx.json` (Qatar time).
  - The envelope follows plan section 6: `kind`, `coachSchemaVersion` 1.0, `notABackup`, `snapshotId`, `generatedAt` +03:00, `range`, `selection`, `coverage`, `unavailable` (water etc.: NOT_RECORDED_IN_APP), `semantics`, the categories, and `derived` (weightChange, eatingDayAverage over D5 days only).
  - Unknown stays null. States are copied as stored. Day codes and meal totals come from the app's own `dayState` / `mealTotals`.
  - Only CONFIRMED meals carry numbers. Unconfirmed meals are exported as id/date/lifecycle only.
  - DAMAGED records are left out and counted. SALVAGED and LEGACY records are marked.
  - Planned slots come from Block 1 and ACTIVATED later blocks only; dates with no active plan are listed as `noActivePlanDates`.
- **One deviation from the plan's field names:** the workout block field `omitted` is exported as `omittedByOwner`. The data layer's restore treats any `omitted` key as an emergency-copy marker. With the rename, a snapshot is refused as "not a HYROX tracker backup" instead of as an emergency copy.
- **Settings card "Export for AI Coaching":**
  - Date range, eight category switches (free-text warning), and a live preview of counts ("No file exists yet").
  - "Create snapshot" builds the file, then hands it to `navigator.share` when `canShare({files})` accepts it. Otherwise it uses the existing download path.
  - Honest labels: handed to share sheet / share cancelled / download fallback / download started / error / storage refused / nothing in range.
  - The feature never says "synced", "uploaded", "saved to Drive" or "backed up".
  - Share again / Download instead / Discard.
  - Leaving Settings drops the snapshot and the selection. One file per tap.
- **Packaging:**
  - `index.html` gains a script tag and a load-guard entry. `DEPLOY-FILES.txt` and `deploy/README-DEPLOY.txt` go from 18 to 19 app files. The build tool expects 19.
  - The existing count tests were re-pointed with a marker comment.
- **Unchanged:**
  - `hyrox-data.js`, `hyrox-nutrition.js`, `hyrox-coach.js`, `hyrox-blocks.js`, `hyrox-plan.js`, photo-ai and every netlify file.
  - No storage key, data-version or backup-format change, and no migration.

## Tests
- **Unit:** `tests/p1-4-coach-export.test.js`, 28 tests covering CE-U-01..25 plus the empty range, goals and forbidden-word checks. Fixture: `tests/fixtures/p1-4-coach-export-seed.js`, built with the real data layer.
- **Browser:** `tests/e2e/p1-4-coach-export.spec.js`, 10 tests:
  - CE-E-01 at 320 and 390 px
  - CE-E-02/06/09: shared file content, zero network requests, storage and backup unchanged, restore refuses the snapshot
  - CE-E-03 cancelled
  - CE-E-04 and 04b fallback
  - CE-E-05 error
  - CE-E-06b offline
  - CE-E-08 navigation and double tap
  - nothing in range
- **Fail-first on 4e53cc4:**
  - Unit: 28 of 28 fail (module absent).
  - Browser: see `logs/D2-failfirst-browser-on-4e53cc4.log`.
- **Older data layers** (RC3, P1.1-RC2, Claude P11.2, RC1) also refuse the snapshot as not_hyrox: `evidence/d-older-restore-refusal.log`.

## Not verified (needs the owner / a real iPhone)
- CE-D-02: whether iOS offers Save to Files / Drive for a JSON file from the Home Screen app.
- CE-C-01: whether the ChatGPT Drive connector reads the JSON file contents (Step 0 of the plan).
- Direct Drive upload (OAuth) is NOT built. The owner said yes in the decision log, but the handover requires the fallback first and no Google Cloud configuration.
