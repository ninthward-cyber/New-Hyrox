# Sprint B2: unsaved MEAL draft recovery (P1.2, owner decision M1)

Grok sprint integrator, 23 Nov 2026 (Asia/Qatar). It is one separate, revertible commit on `sprint`, on top of P1.4-RC1 `0ce77df`. Synthetic data only.
Browser evidence is Chrome emulation, not Safari and not a physical iPhone.

## Owner decision
The owner chose option M1: a new UI-only key, **`hyrox.ui.meal-draft`**.
- `hyrox.v1`, data version 2, backups and restore are unchanged. There is no migration.
- The storage-key allow-list tests now include this one key and carry `RE-POINTED by Sprint B2` comments:
  - `p1-1-package`
  - `rc1-no-override`
  - `p6-dataloss-probes` (removeItem audit)

## Behaviour (`src/ui/app-ext.js`; the only app file changed)

**What is kept**
- An unfinished meal on Add > Meal is auto-saved after each input, change or click, and when the page is hidden or closed. This covers the description, items, portions, quantities from Add foods, amounts and edits of a saved meal.
- The copy is **bounded at 200,000 characters**. If a meal grows past that, the last copy that fitted is kept and the form says so.
- An envelope is stored with the meal: `{v, kind, savedAt, day (Asia/Qatar start date), draftId, baseUpdatedAt, photoCount, estimatePending, ctx (diary logger), fromHistory, ms}`.
- The draft never goes into `hyrox.v1`, so it never counts. Day totals, D5 and History are unchanged until the meal is confirmed (tested byte-for-byte).

**What is never stored**
- Photo files, bytes, or data/blob URLs. Photo-type fields are dropped and any `data:`/`blob:` string is emptied.
- The owner access code or any credential-like value from AI settings. If the code was typed into the meal, the text says `[removed]` instead.
- Photos must be attached again. This is said on Today ("It had 2 photos… attach them again after Resume") and on the restored form.
- The items that were already analysed are kept, and so are the A-fix "Not accounted for" acknowledgements.

**Resume and Discard**
- A stored draft is restored **only** by an explicit **Resume unsaved meal** on Today or on Add > Meal.
- **Discard…** is two steps: "Yes, discard it" or "Keep it".
- A damaged draft (bad JSON, wrong shape or too large) offers Discard only. The app opens normally and nothing is restored or counted.

**When the draft is cleared**
- Only by a verified save, or by an explicit Discard: the dialog, the note, or "Load the saved version" after a conflict.
- A refused save (validation, or the A gate), a failed save (storage error), leaving the form, switching tabs or a reload keep it.

**Interpretation for review (Claude and the owner):** "Save draft" and "I ate this (confirm later)" are verified saves into `hyrox.v1`.
- They store the meal as an uncounted record in the diary, so the local copy is cleared to prevent a duplicate.
- The record itself still does not count until it is confirmed.
- If the owner wants the local copy kept until CONFIRMED only, that is a one-line change.

**Midnight (Asia/Qatar)**
- A meal started at 23:50 keeps its date after midnight. The note says "Started on Tue 17 Nov (Qatar date). Its meal date stays …".
- The existing "not today" warning is shown too.

**Conflicts**
- Before an edit replaces a saved meal, the app checks the stored `updatedAt` against the edit's base. This applies whether the edit is live or resumed.
- If the meal was changed in another tab or by a restore, or deleted, nothing is replaced silently. The owner chooses "Keep my version (replace it)" or "Load the saved version".

**Duplicates**
- If another tab confirms or discards the same unsaved meal, this tab shows "saved or discarded in another tab". Confirm is refused until the owner picks "Discard this copy" or "Keep it as a separate meal".
- An earlier draft that waits is never overwritten by a new meal typed before Resume or Discard.
- A second tap on Confirm saves nothing. After Confirm and a reload, nothing is offered again.

**Rollback**
- Older builds (RC3, P1.1-RC2, Claude P11.2, RC1) ignore the key. They never count or show it, never put it in their backups, and leave it byte-identical.
- Back on the candidate, the draft is still offered and resumes exactly.

## Tests
- **Unit:** `tests/p1-2b-meal-draft.test.js`, 5 tests: key and bound, data layer unaware, sanitiser, clear paths, Resume-only restore.
- **Browser:** `tests/e2e/p1-2b-meal-draft.spec.js`, 18 tests:
  - reload, Resume and Confirm, and two-step Discard (each at 320 and 390 px)
  - failed, refused or navigation does not clear
  - "Save draft"
  - Add foods quantity
  - photos and reattach
  - A gate and owner code
  - midnight
  - conflict "keep mine", with resume
  - conflict "load saved"
  - 3 damaged drafts
  - two-tab duplicate
  - a waiting draft is not overwritten
  - backup and restore
- **Rollback:** `tests/rollback/p1-2b-meal-draft-older-build.spec.js` and `p1-2b-meal-draft-rollforward.spec.js`.
- **Fail-first on `0ce77df`:**
  - Unit: 4 of 5 fail. The 5th, "data layer unaware", is a guard that was already true.
  - Browser: all 18 fail (`logs/B2-2-failfirst-browser-on-0ce77df.log`).

## Not verified (needs a real iPhone)
- iOS standalone (Home Screen) `pagehide`/`visibilitychange` timing when the app is swiped away.
- The storage-full behaviour of Safari.
- The two-tab case, which iOS standalone mode does not normally allow.
