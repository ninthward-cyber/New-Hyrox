# Phase 12: Block 2 planner (base: Claude P11.2 source, zip sha256 6e2b2cae…62bd7, commit e86371a)

This is a release candidate for Claude's review. It is **not** deploy approval, and it does **not** approve any training content. Block 2 content stays "Draft — pending owner approval after 11 Dec". The owner approves it in the app after Benchmark 2 (11 Dec).

| # | Commit | Scope |
|---|---|---|
| 1 | `f98f9ab` | Engine: new file `src/data/hyrox-blocks.js` + unit tests (`tests/p12-blocks.test.js`); script tag and load-guard entry; 14 app files |
| 2 | `8bccae4` | UI (`app-ext.js`, `app.js`): block-aware Today, calendar, session form, History and Trends; planner fold; field-preserving settings writer; restore-preview warning |
| 3 | `dbdb1a7` | e2e `tests/e2e/p12-planner.spec.js` at 390 and 320 px (Chrome emulation, not Safari) |
| 4 | `caaf3a7` | D9 fail-first e2e for the damaged-settings Replace path; docs |
| 5 | `653dbd4` | Revise controls redraw in place (focus kept) |

## Unchanged
- **Files:** every existing `src/data/*` file is byte-identical to Claude P11.2. That covers Block 1 (v2.1 slots, ids, dates, planEvents, rules), the data layer, readiness and wellness, food DB and foodcalc.
- **Data:** data version stays 2. No new collection and no new enum value.
- **Server side:** no change to `netlify/`, `functions/`, photo AI, reserve/caps, same-origin protection, env, keys or historical records.

## What it does (D1–D12 from CC-BLOCK2-RESPONSE-19NOV)
- **Storage (D9).** Later blocks live in the optional settings field `ownerSettings[app-settings].planBlocks`. Each block is self-contained:
  - id `b-YYYYMMDD-xxxx` and explicit dates
  - a 20-slot snapshot
  - its own missed-day `events` (never the legacy week-only `planEvents`)
  - append-only `revisions`
  - the owner's approval record
- **Invalid data.** An invalid block is reported and ignored, but kept exactly as stored. A non-list `planBlocks` is reported, and the planner refuses to write over it.
- **Template (D1).** The template is the conservative Hold:
  - Weeks 1–3 sit at the Block 1 W2/W3 prescriptions, which are the ceiling.
  - Week 4 is the deload.
  - The Week 4 Friday is Benchmark 3, using the same protocol. A modified Benchmark 3 is shown as not comparable.
  - Hold never raises a load.
- **Options (D2).** Options are I1/I2/A1 running, R1L/R1W race and S1 lifting.
  - They are locked before 11 Dec and never pre-selected; the default is Hold everywhere.
  - Picking both a running and a lifting increase shows the v2.1 §10 warning and needs an explicit confirm.
  - Changing options clears the approval.
- **Lifecycle.** Each step is a separate owner action:
  - Create a draft (inactive, with no effect anywhere).
  - Preview it: 4 weeks, diff against the Block 1 reference, closures and rules.
  - Approve it with a tick.
  - Activate it with a confirm. Activation is guarded against stale content (preview hash), stale screens (settings stamp), duplicate activation, overlap, a past start and dates before 11 Dec.
  - Cancel (only before the start) or end early (from tomorrow; later sessions show "not in plan").
  - Nothing rolls over automatically. No AI.
- **Start (D3/D4).** Mondays only, from Mon 14 Dec. No early start and no overlap. A later Monday is allowed; the gap days are shown as "not counted and not missed".
- **Closures and weekends (D5–D7).**
  - D5: 18 Dec, 25 Dec and 1 Jan are flagged as possible closures only.
  - D6: the optional easy Saturday and Sunday mobility are uncounted, with no weekend make-up.
  - D7: Block 2 days show "no plan step reference goal (ST0); 10,000/day is not assumed". Adaptive step guidance is unchanged.
- **Revisions (D10).** Only for future sessions with no record of any status. The kinds are planned rest (a status of its own, not skip or omission), lower-impact, reduced volume, the 45/25 fallbacks, or owner-written text (marked as such, refused in the deload week). The 20-slot denominator is kept.
- **Open counting rules (D11).** The 17/20 numerator and the both-Monday-and-Wednesday-missed rule stay open owner decisions; the app shows them as such.
- **Same rules as Block 1, scoped to the block:**
  - never stack two hard sessions
  - reschedule only inside the block, never on a weekend, never onto a planned-rest day
  - skip advice and the source cascade
  - the fallback-family save guard
  - every continuous machine bout ≤ 15 min (tested on every slot, option, fallback and revision)
- **Readiness.** Readiness, pain and stop rules are untouched; readiness is plan-independent.
- **Midnight.** Day boundaries are Asia/Qatar midnight: 13/14 Dec and 10/11 Jan are tested.

## Settings writers (shared with P11.3)
- **Baselines save:** now re-reads the stored record at click time. The P11.2 save wrote the copy captured when the screen was drawn, and the fail-first e2e shows this dropping saved foods or plan blocks written meanwhile.
- **Damaged-settings Replace:** keeps every other valid field (`HB.repairCarry`: plan blocks, foods, later-version fields), not only myFoods/favFoods.
- **Add foods `saveFoodPrefs`:** already re-read fresh; unchanged.
- **Planner writes:** go through `HB.writeBlocks`, which does a fresh read, changes only `planBlocks`, refuses on damaged settings, uses a stale stamp and verifies by read-back.

## Restore
The restore preview adds a line (`import-preview-plan-blocks`) when the backup's plan blocks differ from the device's. This includes an older backup that has none, which would remove Block 2 from the device.

## Integration with P11.3 (food branch, HEAD 966217a; not touched by this branch)
- **No functional overlap.** P11.3 changes no settings writer. All three settings writers are field-preserving here:
  - baselines save: fresh read at click time
  - damaged-settings Replace: `HB.repairCarry` keeps planBlocks, myFoods, favFoods and any unrelated or later field
  - `saveFoodPrefs`: unchanged
- **Fail-first evidence for the D9 repair-path fix:** e2e "C-01 path (D9 fail-first…)". On baseline e86371a, `planBlocks` comes back `undefined` after Replace (`failfirst-e2e-c01.txt`).
- **Expected textual conflicts when merging:**
  - `index.html`: script tags and the load-guard `need` list. Both branches add scripts: here `hyrox-blocks.js`; in P11.3 `hyrox-fibersodium.js` and `food-db-us.js`.
  - `DEPLOY-FILES.txt` and `tools/build-deploy-package.mjs`: the app-file count. It is 14 here; it becomes 14 + P11.3's additions.
  - `src/ui/app-ext.js`: the module-refs line at the top (`HB` here, `FSX` there). P11.3's hunks are in the meal diary and Add foods area (about P11.2 lines 500–2075); this branch's are at about lines 8–330, 740–1110, 2400, 2620 and 2700–2790. No overlap is expected beyond the header line.
  - `tests/p12-blocks.test.js` pins `hyrox-foodsearch.js` to its P11.2 sha. P11.3 changes that file, so update that one pin to the reviewed P11.3 sha at integration. Every other pin stays.
- **Integrate on the latest Claude-reviewed source**, then re-run the full JS, Python-stub and e2e suites.
