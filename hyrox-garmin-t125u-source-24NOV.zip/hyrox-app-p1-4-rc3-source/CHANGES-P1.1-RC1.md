# P1.1-RC1 — morning log, Garmin intensity minutes, kg/lb preference

Base: P0-RC3 full source `hyrox-app-p0-rc3-source.zip` sha256 `ccea61fc22460ac9c82e6d8c31da8292d38aeb27c29ebd1dcb523bbd8b06b45e`
(local commit `fefa19366150dc2590fe6b7a5a69cd38b5594818`, build source id `d91ba1f1d685`). Not rebuilt from RC2.
Authorised by the owner on 22 Nov 2026 (P1.1 Execution Handoff) for local implementation and testing only.
**Not deployed, not pushed, no provider or account touched.** Release stays with the owner.

Data version stays 2. No migration. No new storage key. No env/secret/key/model/price/cap change.
App files changed: `index.html`, `src/ui/app.js`, `src/ui/app-ext.js`. One new app file: `src/data/hyrox-morning.js`
(17 app files, was 16). `src/ui/style.css` is byte-identical to P0-RC3. The data layer, nutrition, plan, the Block 2 lock,
wellness, estimator, food data, photo AI and every `netlify/` file are byte-identical to RC2 (same 20 pins as P0-RC3).
F-1 (quantity race in Add foods) is **not touched**: no fix authority was given. It is reported separately.

## What changed
1. **Add > Morning — one optional morning log.** Pick the morning (Today / Yesterday / Other date). For that morning:
   weight, waist, sleep, resting HR. For the day before (date shown): whole-day steps and Garmin intensity minutes.
   - It writes through the existing validated paths and record identities only: weight → classic weight list (kg);
     waist → `body` record; sleep + resting HR → that morning's check-in `daily-<date>`; steps + intensity → the previous
     day's check-in `daily-<date-1>`.
   - Fields show what is saved. **Blank changes nothing** (never 0, never a delete). **0 is saved only when typed.**
   - Edits upsert: one check-in per date (same id, every other value kept, including values this build does not know);
     one waist record per date (same id); one weight per date (the new entry is added first, then the one earlier entry
     for that date is removed, so a failure never loses the old value).
   - Everything is checked first; if any field is not valid, nothing is written. If storage fails part-way, the message
     says exactly what was saved and what was not.
   - A future date is refused. A form left open across Asia/Qatar midnight refuses to save and redraws for the new day.
   - It does not touch what it should not: several weights or waists already on that date → that field is locked with a
     pointer to Quick log / History; a check-in with an invalid stored value → locked with a link to the full check-in
     (the existing approve-correction rule).
   - Check-in, Weight & waist, Quick log, Walk and Today > Log steps are unchanged and still work.
2. **Garmin intensity minutes.** One whole number per day (0–2,880), typed as Garmin shows it. Garmin already counts
   vigorous minutes double: 30 moderate + 8 vigorous = **46**. The app never multiplies it. Stored on that day's check-in
   as `intensityMin: { state: "OBSERVED", value: 46, source: "GARMIN_MANUAL" }`.
   - **Trends > Intensity minutes — weekly:** Monday–Sunday (Asia/Qatar) sum for the last 4 weeks, with the number of days
     recorded, days not recorded, and the 150 moderate-equivalent reference. Missing days are not estimated or scaled.
     A week with no value is "unknown, not 0". The week in progress counts only the days so far.
   - Never merged with workouts, sessions, walks, steps or calories. Workout records are untouched.
   - A stored value that is not valid (wrong type, out of range, wrong source) is read as unknown, shown as "not valid
     (not counted)", never as 0, and can be corrected in the morning log.
3. **Settings > Units — kg or lb for body weight.** Display and input only. Stored weights stay kg with one decimal;
   backups stay kg. Pounds are worked out from the stored kg each time (1 lb = 0.45359237 kg), so switching units or
   re-saving what is shown never changes a stored value (tested for every storable weight, 20.0–400.0 kg).
   Applies to Today's weight row, Trends (summary, change, chart), Quick log (list, input) and the morning log.
   Saved as `weightUnit: "lb"` on the existing settings record, read fresh at save time so baselines, saved foods,
   favourites and plan blocks are kept. Choosing kg removes the field again.
4. Release label `P1.1-RC1`; the load guard also checks the new file.

Today (Home) is unchanged: no new card, no new control.

## Design decisions (stated so they can be overruled)
- **Data layer untouched.** `hyrox-data.js` keeps fields it does not know (proven for RC2 and for the P11.2, P11, P10b and
  P9 data layers). That avoids a schema change and keeps rollback safe, but it means the data layer does not validate
  `intensityMin`; `hyrox-morning.js` validates on write and on every read instead.
- **Unit preference inside the settings record**, not a new browser key: it travels with a backup/restore and needs no
  change to the storage-key allow-list.
- **Morning = today; steps and intensity = the day before.** Both dates are printed on the form.
- **150/week** is shown as a general reference, labelled "not a target from plan v2.1 and not medical advice".

## Known limits
- A weight typed in pounds is stored as the nearest 0.1 kg, so it can read back up to 0.1 lb different from what was typed
  (e.g. 216.2 lb → 98.1 kg → 216.3 lb). It does not drift further.
- Older builds (RC2 and earlier) keep both new fields and restore them, but do not show intensity minutes and show weight
  in kg. Their History/Check-in screens do not display the field; saving a check-in there keeps it.
- The History and Check-in screens of this build do not show or edit intensity minutes; the morning log (any date) does.
  Removing a recorded value has no button yet — type the corrected value (0 if it truly was zero).
- Garmin is not connected. Nothing is imported; the number is whatever was typed.
- Tested in Chrome mobile emulation only. Not Safari, not a physical iPhone.
