# Sprint C: Settings, "Not activated (stub)" entries

- **What changed:**
  - The five inactive integration placeholders now sit in ONE closed section, "Advanced / Future integrations (5, none active)", at the end of Settings.
  - The five placeholders are: owner-only login, cloud sync/backup, Garmin/Apple Health import, licensed food catalogue, and description-only AI estimate.
  - Each item shows "Not active" and one plain sentence.
  - The description-only AI line says that Photo analysis is a separate feature that works.
- **What did not change:**
  - `src/integrations/stubs.js` is untouched. Every interface still answers NOT_ACTIVATED without a network call.
  - The section has no buttons, links or inputs, and claims no "connected" status.
  - No backend, secrets or OAuth were touched.
  - Photo analysis and Nutrition Coach settings stay where they were, visible without opening anything.
- **Test:** `tests/e2e/sprint-c-settings-future.spec.js` (320 and 390 px).
  - Checks the section is closed and opens from the keyboard.
  - Checks there are no interactive elements inside, no "connected" or "(stub)" text, and no horizontal overflow.
  - Checks that working settings are visible and that the stubs still answer NOT_ACTIVATED.
  - Fail-first on 5e160f9: 2 of 2 fail.
- **Real iPhone:** check VoiceOver announcement of the collapsed/expanded state, and Larger Text.
