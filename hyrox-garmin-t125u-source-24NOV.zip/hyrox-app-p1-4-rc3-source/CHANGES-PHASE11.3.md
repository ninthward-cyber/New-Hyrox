# Phase 11.3 — free US food list + optional fiber/sodium (on Claude P11.2)

Base: Claude P11.2 source `6e2b2cae…` (deploy `c85d8247…`), commit `96832ff`. Every Claude repair C-01..C-06 kept. No deploy, no env, no provider/key/model/price/cap change, no photo-AI change. Data version stays 2; meals from search stay `source: MANUAL`.

## Part 1: free US food expansion (commits 4414bb5, 29e5bc2, + meta rename)
- New static file `src/data/food-db-us.js` (+ `.json`): **USDA FNDDS 2021-2023** (FoodData Central Survey release 2024-10-31, CC0), 5,431 of 5,432 foods (only "Milk, human" left out), real fdcIds, USDA portions (no "guideline amount" rows; "Quantity not specified" → "serving (USDA default, quantity not specified)"). It also carries fiber/sodium for the original SR Legacy/Foundation foods.
- It is built by `tools/food-db/build_food_db_us.py`. The build pins the sha256 of the input zip and is deterministic (a test rebuilds it byte for byte). The source URL, date, FDC IDs and portions are recorded in `meta` and in `src/data/FOOD-DB-US-PROVENANCE.md`.
- The original `food-db.js` is **byte-identical**: still 8,167 foods. Search now covers **13,598 foods**, all offline. The US file loads once when Add foods opens. If it fails, search falls back to the 8,167 foods and says so.
- **Duplicates:** never merged. There are 105 identical names across lists; each row keeps its own dataset label.
- **Chain items:**
  - FN chain dishes are labelled "Chain item · USDA survey estimate (US)".
  - SR chain items are labelled "Restaurant · US 2018".
  - Generic fast-food/restaurant dishes are labelled "Restaurant-style · generic USDA".
  - Details for chain items say the value is not the restaurant's official figure and may differ in Qatar branches. To use the official figure, enter it manually, confirm it, then Save to My foods.
  - No chain data was scraped or bundled.
- **Ranking:** a name whose leading part is the typed food ranks up. A dropped unit word that the name spells out also helps ("1 can tuna" → "canned").
- **Chain dish default portion:** the portion that names the dish now comes first. Only Big Mac's order changed: the default was Mac Jr 135 g and is now Big Mac 205 g.
- Size: `food-db-us.js` is 1.25 MB raw, about 193 KB gzip. Together with `food-db.js` (256 KB gzip) the food data is about 449 KB gzip.
- **Not done:** a Branded subset (the files are hundreds of MB and curating them would be subjective) and Qatar-specific foods.

## Part 2: optional fiber (g) and sodium (mg) (commit da09e60)
- New pure module `src/data/hyrox-fibersodium.js`. `hyrox-data.js` and `hyrox-nutrition.js` are unchanged (their bytes are pinned by the P9/P10 contract tests). As a result, invalid stored values are **treated as unknown when read**, not rejected on save.
- Per item, the value is `{value, state}`. A blank field is not stored, which means unknown. A blank is never stored as 0.
- USDA values are stored as ESTIMATED and scaled to the grams chosen. The eaten fraction is applied once, in totals, using the same rule as kcal.
- Day line (Today diary):
  - "unknown (0 of N items known)"
  - "X known subtotal — incomplete (k of N items known)"
  - "X so far (…)"
  - "X — complete day total (…)", only when the day is declared complete (D4/D5) **and** every confirmed eaten item has a value
  - ", estimates included" is added when any value is an estimate
- No targets. kcal, macros and day states are unchanged.
- Meal form: an optional "Fiber & sodium" fold per item, plus meal totals. Add foods detail shows fiber and sodium. Describe estimates get USDA values.
- Changing an item's kcal or macro number removes its USDA source note **and** its USDA fiber/sodium.
- My foods keeps typed or USDA values and scales them by quantity.

## Shared settings-writer note (for Phase 12 integration)
- **No settings writer or repair path was changed in 11.3.**
- Save to My foods, favourite, rename and delete use the existing `saveFoodPrefs` (a deep copy of the record), so unknown fields such as a future `planBlocks` survive. This is e2e-tested. A normal Settings save also keeps them (tested).
- **Unchanged from Claude P11.2:** the damaged-settings "Replace" path (C-01) keeps only `myFoods` and `favFoods`. Any other field, e.g. `planBlocks`, is dropped. This is pinned by an "INTEGRATION NOTE" e2e test. Phase 12 should extend `rawSettingsFoodLists` / `set-save` and then flip that test.

## Other
- The empty-query count shows thousands separators ("13,598 foods").
- `tests/e2e/p11-2-food-search.spec.js` (Big Mac flow) now picks the SR row by name, because the FNDDS "Big Mac (McDonalds)" now ranks above it.
- 15 deploy files (was 13): + `src/data/food-db-us.js`, `src/data/hyrox-fibersodium.js`.
- Water is still deferred. No plan changes.
