# P1.3-RC3 — owner-approved Command Center decisions on P1.3-RC2

Base: P1.3-RC2, final commit `a5f2862bc8280d33ecb8eeddfc7310dbb1a2da9e`, build source id `686c3be0836b`, source ZIP sha256
`5016d0ff70ca7048d8226597201e1c2b5db57db45ecf81c392d2fd659fa0d7bc`. Decisions: Command Center review of P1.3-RC2 (23 Nov 2026),
items 1 and 5 approved by the owner the same day; items 3 and 4 accepted by Command Center as worded.
**Not deployed, not pushed.** Data version 2, no migration, no new storage key, no network call, no Block 2 change.
App files changed: `src/data/hyrox-coach.js`, `src/ui/app-ext.js`. Every number marked provisional stays provisional.

## Changes
1. **Own targets below the provisional floor are refused** (decision 1). The floor is the higher of 1,500 kcal (men, and when no
   sex is given) / 1,200 kcal (women) and the exact resting estimate. The message names both numbers, says the floor is a
   provisional product default and not a medical rule, and that a lower target would need a separate clinician-supervised
   arrangement. Nothing is clamped or changed. A target already stored below the floor (confirmed in RC2, or in a restored
   backup) is kept as stored and stays an amber "below the provisional floor" concern. The RC2 acknowledgement tick is gone.
2. **Estimates are shown rounded to the nearest 50 kcal** (decision 5), ties up: the starting maintenance and resting
   estimates and the personal estimate, each labelled "shown rounded to the nearest 50 kcal". Display only: the stored
   figures, the "Calculation (exact figures)" line, suggested targets (what a Confirm stores), own targets and every alert
   boundary stay exact. Example: starting estimate shown "about 2,650 kcal" (exact 2,643); suggestion 2,143 kcal, stored 2,143.
3. **The hold note shows numerator, denominator and exclusions** (decision 3): "3 of 3 eligible planned sessions last week are
   not logged …; 2 omitted by the plan's own rules are excluded."
4. **A first suggestion names the reference that stays in force** (decision 4): the starting estimate shows the assumed
   activity in words, and the suggestion says the provisional 2,400 kcal / protein 190 g (protein floor 170 g) reference
   stays until the owner confirms. Never a measured maintenance; 2 lb/week is never computed.

## Tests
New: `tests/p1-3-rc3.test.js` (6), `tests/e2e/p1-3-rc3.spec.js` (4 scenarios × 320/390 px, incl. the Qatar Monday-midnight
week change). On P1.3-RC2: unit 5 of 6 fail, browser 6 of 8 fail; the guards pass, as intended. Re-pointed (never deleted):
Grok's low-target unit and browser cases (1,300 kcal is now refused), the starting-estimate wording, and the RC2 tick tests.

## Not changed here
The photo-analysis 401 seen on the live site is a separate incident; this candidate does not touch the server or the photo
code (the 20 pinned files are byte-identical to RC2). Diagnosis steps are in the review report.

## Limits
Chrome mobile emulation at 320 and 390 px only. Not Safari, not a physical iPhone, not iOS Dynamic Type.
