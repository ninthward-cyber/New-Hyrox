# RC2: deploy and rollback (owner only, after the owner's explicit go-ahead)

**This package is not deploy approval and not approval of Block 2 training content.** Nobody but the owner deploys.
- Site: `hyrox-phase7-private-test` (ID `99f0deb7-0526-46f6-b432-9c3bfc2c86d2`).
- Zip: `hyrox-app-rc2-deploy.zip`; its SHA256 and every file's SHA256 are in `SHA256SUMS-rc2.txt`.
- No env change, no migration, data version 2. 16 static app files. Sizes after deploy: `src/ui/app-ext.js` 303150 bytes,
  `src/ui/style.css` 42154 bytes (unchanged from RC1), `src/ui/app.js` 70398 bytes, `src/data/hyrox-foodsearch.js` 30807 bytes.
- RC2 = RC1 + four review fixes (CHANGES-RC2.md). The Block 2 activation lock (`src/data/hyrox-blocks.js`) is byte-identical to RC1.

## A. Read-only: confirm what is live now (identity)
Netlify → site → Deploys → Published deploy → file browser sizes:
| `src/ui/app-ext.js` | `src/ui/style.css` | Live build |
|---|---|---|
| 258287 | 41683 | **Claude P11.2** (`c85d8247…`) — expected if RC1 was never deployed |
| 302942 | 42154 | RC1 (`12958315…`) — expected if RC1 was deployed |
| 223896 | 39561 | Claude P11 (`b8275adb…`) — stop and ask before continuing |
| 303150 | 42154 | RC2 already live — stop |
| anything else | | stop and report the sizes |
Write down the published deploy ID: it is the fastest rollback target.

## B. Backup first (mandatory)
iPhone → the **Home Screen icon** (same origin as your data, not a Safari tab) → Settings → **Export JSON backup**. Keep the file.

## C. Deploy
```powershell
cd $HOME\Downloads
Get-FileHash .\hyrox-app-rc2-deploy.zip -Algorithm SHA256   # must equal its line in SHA256SUMS-rc2.txt, otherwise STOP
Expand-Archive .\hyrox-app-rc2-deploy.zip -DestinationPath .\hyrox-rc2-deploy -Force
cd .\hyrox-rc2-deploy\hyrox-rc2-deploy
npm ci
npx netlify-cli login
npx netlify-cli sites:list --json | ConvertFrom-Json | Where-Object { $_.id -eq '99f0deb7-0526-46f6-b432-9c3bfc2c86d2' } | Select-Object name, url, id
# must show hyrox-phase7-private-test, otherwise STOP
npx netlify-cli deploy --site 99f0deb7-0526-46f6-b432-9c3bfc2c86d2 --dir publish --functions netlify/functions --message "RC2 draft"
```
Draft URL (new Safari tab, not the icon): quick look only, then clear that tab's website data. Then production:
`npx netlify-cli deploy --prod --site 99f0deb7-0526-46f6-b432-9c3bfc2c86d2 --dir publish --functions netlify/functions --message "RC2"`.
Check the file sizes in the Netlify file browser equal the ones above.

## D. Smoke test on the Home Screen icon (real iPhone Safari; all e2e ran in Chrome emulation, not Safari)
1. Add foods → `4 boiled eggs` → an egg row (hard-boiled / boiled egg) with 4 × portion; Add → kcal and sodium shown, marked estimate.
2. Add foods → `1 can tuna` → canned tuna first.
3. **No network during search:** airplane mode on, search again → results still appear; airplane mode off.
4. **RC2 checks:** Add foods → `fries` → "Potato, french fries, NFS" first (not "Fry sauce"); `french fries` → the same
   first, chains still listed below; `burger` → "Hamburger, NFS" first. On a USDA item type a sodium number, Confirm,
   reopen it (History → Edit), change kcal → your sodium stays, USDA fiber clears with its note.
5. **Diary return:** Confirm the meal → lands on Today, diary open, the meal shown once.
6. **Saved foods survive:** History → Save to My foods → Settings → Save → Export → Restore preview: My foods still listed
   (do not confirm the restore unless you want to). RC2: restoring an older backup without saved foods now warns
   "Restoring removes your N saved foods …" in the preview — read it before you confirm. Reopen the icon → My foods still there with fiber/sodium.
   (If Settings ever shows "settings need attention" → Replace, your saved foods and plan blocks are kept.)
7. **Block 2 draft preview (before 11 Dec):** Today → Next training block → Create draft → "Draft — pending owner approval
   after 11 Dec"; Show preview opens; the approve tick and Activate are locked. Today itself is unchanged (Block 1). You may
   keep or delete the draft.
8. From 11 Dec: open the preview, then tick approve, Activate (confirm). Mon 14 Dec after midnight Qatar: "Block 2 · Week 1/4".

## E. Rollback (no env change, no migration) — export a backup before rollback; don't edit Block 2 records on old builds
Fastest: Netlify → Deploys → the deploy ID you wrote down in A → Publish deploy. From a zip (check the hash; same `npm ci`
+ `deploy --prod` as in C):
| Order | Target | SHA256 |
|---|---|---|
| 1 | RC1 `hyrox-app-rc1-deploy.zip` | `129583156454de49c3acbf5e2a4d7bae08124ac1862c982f6c6e7b646f409d7c` |
| 2 | Claude P11.2 `hyrox-app-phase11-2-deploy-claude.zip` | `c85d82479e02a6e20a585ac9b9a9418b4ba736792cc98136e011f403b1b85e61` |
| 3 | Claude P11 `hyrox-app-phase11-deploy…` | `b8275adb58a5f435983be4b7752714c45e13ed04ed12c18ae37a5406fe458b82` |
| 4 | P10b `hyrox-app-phase10b-deploy…` | `da206f891229ae43b73a04722d2a2a37f2ca92aba7df31accbf19c2016e8cf72` |
On those builds (tested same-origin in Chrome emulation): Block 2 is invisible (Block 1 only; "no active block" after 13 Dec),
Block 2 workouts show as unlinked; a normal Settings save and export keep planBlocks, saved foods and fiber/sodium fields.
**Do not** edit a skipped Block 2 workout there (drops its skip decision) and **do not** use "Replace the saved settings" there
(rebuilds the record without planBlocks; P11/P10b also without saved foods). Redeploying RC2 brings Block 2 back. RC2's owner marker on typed fiber/sodium (`by: "OWNER"` inside the value) is kept
through backup and restore by the RC1 and Claude P11.2 data layers (tested); editing that number in an older build's
form rewrites it without the marker (not tested in those UIs). RC1 and older builds also lack the saved-foods restore
warning, and RC1 again treats a typed value on a USDA item as USDA-derived once the meal is reopened.
