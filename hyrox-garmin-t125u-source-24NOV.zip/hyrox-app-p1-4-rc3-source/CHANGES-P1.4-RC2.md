# P1.4-RC2: P1.4-RC1 + Sprint B2 (unsaved meal draft, owner decision M1) — CHANGES + QA report

Grok sprint integrator, 23 Nov 2026 (Asia/Qatar).
- **Branch:** `sprint` (local only). **Not deployed, not pushed, no PR, no Netlify, GitHub or Google Cloud write.**
- **Test data:** synthetic only. No live photo call, no Garmin call, no paid call. `test_food_photo_api_live.py` was NOT run.
- **This is not deploy approval.** Gate 5: Claude must QA this full source (CLAUDE-QA-BRIEF-P1.4-RC2.md) before anyone asks the owner for device QA or deploy approval.

| | |
|---|---|
| Base | P1.4-RC1 (`0ce77df`, source `f7f66257b5fa`) |
| Release label | `P1.4-RC2` |
| **Source id** | **`bcbc7b4d2959`** (sha256 over the 19 DEPLOY-FILES app files, path+NUL+bytes+NUL; first 12 hex) |
| Deploy ZIP | `hyrox-app-p1-4-rc2-deploy.zip`, sha256 `6a4d7523e9eed96aa22d0d87e9655074eb04acb33b8153b681972e1b66d36c67` (built twice from a clean `git archive`; byte-identical) |
| App-file sizes | `src/ui/app-ext.js` 425996 B, `src/ui/style.css` 46015 B (RC1: 408364 / 46015) |
| Files changed vs RC1 deploy package | `publish/src/ui/app-ext.js` (B2), `publish/index.html` (label), `README-DEPLOY.txt`. Everything else byte-identical, incl. `hyrox-data.js`, Block 2, netlify functions/lib |

## Commits (oldest first; each separate and revertible)
| Commit | What |
|---|---|
| `03ee3db` | **B2** unsaved meal draft in UI-only key `hyrox.ui.meal-draft` (CHANGES-SPRINT-B2-MEAL-DRAFT.md). Only app file: `src/ui/app-ext.js`. New tests; 4 existing tests re-pointed (`RE-POINTED by Sprint B2`) |
| `ccaec62` | Release label P1.4-RC2, build folder `hyrox-p1-4-rc2-deploy`, README-DEPLOY; label tests re-pointed |
| (docs) | This file, DEPLOY-P1.4-RC2.md, CLAUDE-QA-BRIEF-P1.4-RC2.md. Docs only; source id unchanged |

Re-pointed existing tests (all marked): `tests/p1-1-package.test.js`, `tests/rc1-no-override.test.js`, `tests/p6-dataloss-probes.test.js` (allowed-key list / removeItem audit gain the one new key), and `tests/e2e/p6-meron-estimate-flow.spec.js` ("estimating writes nothing" now means no DATA key changes; the owner now wants the unfinished meal auto-saved in the UI key, which the spec checks separately).

## Owner safeguards → enforcement → tests
| Safeguard | Code | Test |
|---|---|---|
| Auto-save descriptions, portions, quantities, edits; bounded | `saveMealDraft` (input/change/click, pagehide, visibilitychange); 200000 chars | e2e reload/Resume (320+390), Add-foods 2× banana, edit of saved meal; unit key+bound |
| Restore only with explicit Resume or Discard | `resumeMealDraft`, `mealDraftNote` (two-step Discard) | e2e FAIL-FIRST reload, two-step Discard (320+390); unit "Resume-only" |
| No photo bytes/data URLs, owner code, credentials | `MD_DROP_KEYS`, `mdSanitize`, `mdSecrets` | e2e photos (no `data:`/base64; photoCount 2; reattach notice), A-gate test (owner code → `[removed]`); unit sanitiser |
| Clear only after verified save or explicit Discard | 4 call sites: save res.ok, Discard dialog, note Discard, conflict "Load saved" | e2e failed/refused/navigation/reload keep it; unit counts call sites |
| Never counted until confirmed | draft never written to `hyrox.v1` | e2e subtotal 500 → 1400 only after Confirm; `hyrox.v1` byte-identical while a draft exists |
| Existing meals, backups, history untouched | `hyrox-data.js` byte-identical | e2e backup export/restore; unit "data layer unaware" |
| Qatar date + midnight | envelope `day` = Qatar start date; meal date never moved | e2e 23:50 → 00:10 |
| Revision conflict vs another tab | `mealConflict` (stored `updatedAt` vs base) | e2e keep-mine (also after reload+Resume), load-saved |
| Invalid / corrupt draft | `loadMealDraft` → invalid note, Discard only | e2e bad JSON, wrong shape, oversize |
| Duplicate prevention | storage listener on `draftId`, double-Confirm guard, waiting draft never overwritten | e2e two tabs, waiting draft |
| A-fix gate after Resume | acks kept; unapplied estimate not stored (flagged) | e2e A-gate survives Resume |
| Rollback to older builds | key unknown to them | rollback spec on 4 older builds + roll-forward |
| 320/390 px | — | e2e at both widths; screenshots |

## Interpretations for owner/Claude review
1. "Save draft" and "I ate this (confirm later)" are verified saves into `hyrox.v1` (uncounted DRAFT/intent records), so the local copy is cleared there too (keeping it would duplicate). One-line change if the owner wants the local copy kept until CONFIRMED.
2. Returning the form to its start state removes this session's own stored copy.
3. Add-foods screen: the quantity being typed is kept once "Done" adds the item.
4. A waiting earlier draft blocks auto-save of a new meal until it is resumed or discarded (said on screen).

## QA
- **Fail-first on a clean archive of `0ce77df`** (RC1, before B2): unit 4 of 5 fail (`B2-1`; the 5th is a guard that was already true), browser **18 of 18 fail** (`B2-2`).
- **Final candidate on a clean `git archive` of `ccaec62`** (23 Nov 2026, 18:42–19:05 Asia/Qatar):

| Suite | Result |
|---|---|
| Unit (`node --test tests/*.test.js`) | **1639 / 1639 pass** (`QA-G1`) |
| Python photo adapter, fake model, no network | **8 / 8 pass** (`QA-G2`); live test NOT run |
| Chrome e2e full, 3 workers, retries 0 | **673 passed, 1 skipped (pre-existing), 0 failed** (`QA-G3`) |
| F-1 stress, `--repeat-each 15` | **240 / 240** (`QA-G4`) |
| Sprint specs stress (A, B, C, D, B2), `--repeat-each 5` | **295 / 295 twice (`QA-G5b`, `QA-G5c`, full output). The first run (`QA-G5a`) gave 291 / 295 in 8.3 min instead of ~1.7 min while the shared box was heavily loaded; that script kept only the summary, so the 4 failures are not identified beyond 3 names in the tail (one each in the A, B-workout and B2 specs). Treated as load flakes, but reported, not hidden** (`QA-G5`) |
| Rollback, roll-forward and old-backup round trip (4 older builds; now incl. B2) | **39 / 41 pass; the 2 others are the same not-applicable `p1-1-older-build` lb/kg cases as RC1 (RC3, P1.1-RC2 honour lb). New B2 checks: older-build 4/4, roll-forward 4/4; the integrated storage now also carries a meal draft through every older build** (`QA-G6`) |
| Deploy ZIP reproducible (two builds) | identical sha256 |

All browser results are **Chrome emulation, not Safari and not a physical iPhone.** 

Earlier attempts (logs kept, not hidden):
- On `1290d7e` (pre-amend B2): Chrome full found **4 failures in `p6-meron-estimate-flow.spec.js`** ("estimating writes nothing" saw the new draft key). Re-pointed inside the B2 commit (`03ee3db`); 12/12 since.
- First attempt on `ccaec62` (`logs/rc2-attempt1/`): unit, python and Chrome as above; F-1 237/240 (3 press-timing tests; 3.7 min, run while processes of an aborted run were still ending; F-1 alone ×5 = 80/80 and the final ×15 = 240/240); the rollback candidate-write step failed because of a path bug in the QA script's storage generator (fixed; not an app issue).
- Screenshots were taken from a clean archive of `1290d7e`, whose app files are byte-identical to `ccaec62`.

## Explicit table (Gate 4) — changes against RC1
| Item | Status | Evidence / what is missing |
|---|---|---|
| **B2 unsaved meal draft (M1): auto-save, Resume/Discard, no photos/secrets, clear rules, never counted, backups untouched, conflict, duplicates, midnight, corrupt drafts, A gate after Resume** | **Done** (Chrome emulation) | 5 unit + 18 browser tests (fail-first 18/18 on RC1); stress ×5; rollback 4/4 + roll-forward 4/4 |
| B2 auto-save when the iOS Home Screen app is swiped away (`pagehide`/`visibilitychange` timing) | **Needs real iPhone QA** | Chrome emulation fires these reliably; iOS standalone may not. Input/change autosave covers typed text before that |
| B2 Safari storage-full / private-mode behaviour | **Needs real iPhone QA** | Too-big path tested in Chrome only |
| B2 two-tab guard in iOS standalone mode | **Broken-unknown** | iOS PWA has one window; tested in Chrome tabs only |
| B meal-draft persistence across reload | **was Deferred (HELD) → now Done** in B2 | owner decision M1 |
| All other RC1 rows (A, B workout, C, D, Drive OAuth deferred, CE-D-02 share sheet, ChatGPT connector, live photo, Garmin, Safari layout, "Share again" cosmetic, older-build rollback) | **unchanged** | see CHANGES-P1.4-RC1.md |

## Hard limits kept
- `hyrox.v1` data version 2, data layer byte-identical, no migration; exactly one new UI-only key (allowed-key tests enforce the list).
- Block 2 lock/dates/content, owner access code, API keys, caps/reserve, same-origin: unchanged (netlify files byte-identical to RC1).
- D export never reads localStorage directly (store read methods only), so it cannot include the meal draft.
