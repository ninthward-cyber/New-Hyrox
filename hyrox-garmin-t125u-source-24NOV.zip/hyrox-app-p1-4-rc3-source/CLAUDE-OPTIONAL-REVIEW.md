# Optional Claude review — RC1 residual risks (short)

Not required for deploy; the owner decides. Everything below was tested only in **Chrome mobile emulation (390/320 px), not
Safari/WebKit and not a real iPhone**.

## Worth a second look (highest first)
1. **B-01 repair (approval binding, app-ext.js draftPanel).** The tick is enabled after `seenHash === hashAtRender` and bound via
   `approvedHash`. Check: VoiceOver/Larger Text reading of the disabled tick + hint `planner-approve-needs-preview`; that no
   path re-enables the tick after a re-render without the preview being open.
2. **A-01 repair (loadFoodDbUs).** Shared in-flight load + retry after failure. Check the Safari behaviour of a removed failed
   `<script>` and a re-add (WebKit may cache the failure); a slow 3G first load while Describe and Add foods both wait.
3. **A-02 repair.** `typedExtra` is an in-memory WeakMap: after reopening a saved meal, previously typed fiber/sodium on a USDA
   item are treated as USDA-derived again and a kcal change clears them (with the note). Acceptable? (LOW.)
4. **Midnight / resume.** New-day refresh relies on the existing visibilitychange/focus check. Tested with a fast-forwarded
   test clock; iOS suspending a Home Screen app overnight is UNKNOWN until checked on the phone on 14 Dec.

## Residual risks / owner items
- Real iPhone only: Home Screen icon resume after midnight Qatar on Sun 13 → Mon 14 Dec; Larger Text/VoiceOver on the planner
  fold and confirm dialogs; airplane-mode search; storage size with the 1.3 MB US file cached.
- Old builds: don't edit skipped Block 2 sessions or use damaged-settings Replace on Claude P11.2/P11/P10b (documented).
- Restore preview warns about plan blocks but not explicitly about saved foods being replaced (LOW).
- Ranking oddity: "fries" → "Fry sauce" first (LOW). Sodium × absurd quantity > 100000 mg reads unknown (LOW).
- Block 2 training content (hold) is the planner's D1–D12 output; the owner's approval of that content is separate.
