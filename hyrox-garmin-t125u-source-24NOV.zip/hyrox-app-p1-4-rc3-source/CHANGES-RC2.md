# RC2 — RC1 + four targeted review fixes (Claude)

Base: RC1 source `8e509245…` (rc1/integration `01b1e85d`), deploy `12958315…`. Data version stays 2. No migration, no
env/secret/key/model/price/cap change, no new storage key, no new feature, no paid call. Same 16 static app files.
Changed app files: `src/data/hyrox-foodsearch.js`, `src/ui/app-ext.js`, `src/ui/app.js`. Byte-identical to RC1:
`src/data/hyrox-blocks.js` (Block 2 activation lock), `hyrox-data.js`, `hyrox-foodcalc.js`, `food-db*.js`,
`hyrox-fibersodium.js`, `hyrox-plan.js`, `hyrox-nutrition.js`, `hyrox-wellness.js`, `photo-ai.js`, `style.css`,
`index.html`, every `netlify/` file.

| # | Fix | Change |
|---|---|---|
| 1 | Owner fiber/sodium provenance | A typed value is stored as `{value, state, by: "OWNER"}` (RC1 kept the origin only in an in-memory WeakMap, lost on reopen/reload). Kept by Edit, Copy, My foods (save, rename, reuse at any quantity), backup and restore. A kcal/macro change on a USDA item still clears USDA-derived fiber/sodium, never an owner value. Only the exact marker is trusted. Values typed under RC1 have no marker and behave as in RC1. |
| 2 | Restore warning | The restore preview adds `import-preview-saved-foods` when the backup would remove or replace this device's saved foods / favourites (restore replaces the whole settings record). No warning when the device has none or the lists are identical. Read-only; nothing is written. |
| 3 | Search ranking | Brand words in chain names are no longer treated as the food name; chain items rank below plain foods unless a brand word is typed; an "-ies" plural the name spells out ranks above a different word with that stem; search-only shortcuts "fries"/"french fries" → *Potato, french fries, NFS* and "burger"/"hamburger" → *Hamburger, NFS* (labelled, never chosen by themselves; the estimator's aliases are unchanged). Top-3 changed for 6 of 83 sampled queries, all intended (log: ranking-diff-top3.txt). |
| 4 | Deploy README | `deploy/README-DEPLOY.txt` described the Phase 10 package (12 files, DEPLOY-PHASE10.md). Rewritten for RC2: 16 files, CLI deploy, DEPLOY-RC2.md, Block 2 lock unchanged. |

Tests: `tests/rc2-review.test.js` (8; 6 fail on RC1, 2 guard unchanged behaviour), `tests/e2e/rc2-review.spec.js`
(6; all fail on RC1). Updated: the food-search byte pin in `tests/p12-blocks.test.js`, and two stored-shape expectations
(`p11-3-fibersodium.spec.js`, `p11-3-food-us.spec.js`) now include `by: "OWNER"` for a typed value.
