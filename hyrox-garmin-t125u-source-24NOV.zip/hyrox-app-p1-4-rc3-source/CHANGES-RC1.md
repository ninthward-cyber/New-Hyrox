# RC1 — P11.3 food + Phase 12 Block 2 planner, independently reviewed and integrated

Base: Claude P11.2 source (zip 6e2b2cae…, deploy c85d8247…); Claude repairs C-01..C-06 kept (their tests pass unchanged).
Data version stays 2. No migration, no env/secret/key/model/price/cap change, no new storage key. 16 static app files
(Claude P11.2's 13 + `src/data/food-db-us.js`, `src/data/hyrox-fibersodium.js`, `src/data/hyrox-blocks.js`).

## Contents
- **A — P11.3 food** (p11-3/integration 966217a): free USDA FNDDS US foods (5,431; search over 13,598 offline), optional
  per-item fiber/sodium (unknown never 0). See CHANGES-PHASE11.3.md.
- **B — Phase 12 planner** (p12/integration 7b7170c): Block 2 draft → preview → approval → activation from 11 Dec for a
  Monday start ≥ 14 Dec; field-preserving settings writers; damaged-settings repair carry. See CHANGES-PHASE12.md.

## RC1 review repairs (one commit each, fail-first tests)
| ID | Sev | Commit | Change |
|---|---|---|---|
| A-01 | LOW | b556a29 | US food file loaded once (shared in-flight load, no second `<script>`); a failed load is retried on the next Add foods open |
| A-02 | LOW | 8680c45 | owner-typed fiber/sodium kept when kcal/macros change; only USDA-derived values cleared |
| B-01 | MEDIUM | db1c63b | Block 2 approval tick only after the preview was opened for the current content; tick bound to that content hash; cleared (with a note) when the draft changes |

## Integration (rc1/integration)
- 60f6c4c merge A; 18b4a13 merge B. Conflicts resolved: DEPLOY-FILES.txt (16 files), tools/build-deploy-package.mjs
  (16, `build/hyrox-rc1-deploy`); index.html and the app-ext.js module header auto-merged (blocks after plan, fibersodium after
  foodsearch; load guard requires HyroxBlocks, FiberSodium optional as in A); Phase 12 foodsearch byte pin moved to the reviewed
  P11.3 hash 28e136b2…; the P11.3 "INTEGRATION NOTE" e2e flipped (Replace now keeps planBlocks).
- New tests: tests/rc1-no-override.test.js (deploy grep), tests/e2e/rc1-activation-clock.spec.js (simulated December, test
  clock only), tests/e2e/rc1-cross.spec.js (food writers × active Block 2, two tabs, Block 2 diary with US search),
  rc1-review-a01/a02/b01 specs.

## What the app does NOT contain
No date override, flag, query parameter or debug hook (enforced by rc1-no-override.test.js on the built publish/ files).
Block 1 content, historical record semantics, photo AI and same-origin protection unchanged.
